import { createSettingsSync } from '../sync/settings-client.js';
import { verifyLicenseKey } from '../licensing/key.js';
import { chooseLocale, currentTimeZone } from '../i18n/detect.js';
const UI_STATE_KEY = 'ui.state';
const BUY_URL = Object.freeze({ ru: 'https://eshario.com/ru/buy/', en: 'https://eshario.com/buy/' });
let messages = null;
const msg = (key, args) => {
const entry = messages?.[key];
const own = entry?.message;
if (typeof own === 'string' && own !== '') {
const named = entry.placeholders ?? {};
const pick = (index) => String(args?.[Number(index) - 1] ?? '');
return own
.replace(/\$([A-Za-z0-9_]+)\$/g, (whole, name) => {
const content = named[String(name).toLowerCase()]?.content;
const index = typeof content === 'string' ? /^\$(\d)$/.exec(content)?.[1] : null;
return index === undefined || index === null ? whole : pick(index);
})
.replace(/\$(\d)/g, (whole, index) => (args?.[Number(index) - 1] === undefined ? whole : pick(index)));
}
return chrome.i18n.getMessage(key, args) || key;
};
async function storedLocale() {
try {
const stored = await chrome.storage.local.get(UI_STATE_KEY);
const locale = stored?.[UI_STATE_KEY]?.locale;
return typeof locale === 'string' ? locale : null;
} catch { return null; } /* хранилище недоступно — решает лестница */
}
async function chosenLocale() {
return chooseLocale(await storedLocale(), navigator.languages, currentTimeZone());
}
async function rememberLocale(locale) {
const stored = await chrome.storage.local.get(UI_STATE_KEY);
const state = stored?.[UI_STATE_KEY];
const next = typeof state === 'object' && state !== null ? { ...state, locale } : { locale };
await chrome.storage.local.set({ [UI_STATE_KEY]: next });
}
async function applyLocale() {
const locale = await chosenLocale();
try {
const response = await fetch(chrome.runtime.getURL(`_locales/${locale}/messages.json`));
messages = await response.json();
} catch { messages = null; }
document.querySelectorAll('[data-i18n]').forEach((node) => {
node.textContent = msg(node.dataset.i18n);
});
document.querySelectorAll('[data-i18n-title]').forEach((node) => {
node.title = msg(node.dataset.i18nTitle);
});
return locale;
}
const WORDS = {
'invalid-credentials': 'accountBadCredentials',
'rate-limited': 'accountTooManyTries',
network: 'accountNoNetwork',
'invalid-input': 'accountShortPassword',
'no-response': 'accountNoAnswer',
'account-blocked': 'accountBlocked',
};
function dateOf(ms) {
const date = new Date(ms);
const pad = (value) => String(value).padStart(2, '0');
return `${pad(date.getDate())}.${pad(date.getMonth() + 1)}.${date.getFullYear()}`;
}
async function rightOf(entitlement) {
if (typeof entitlement !== 'string' || entitlement === '') return { ok: false, exp: null, none: true };
try {
const result = await verifyLicenseKey(entitlement, { now: Date.now() });
return { ok: result.ok === true, exp: result.exp ?? null, none: false };
} catch {
return { ok: false, exp: null, none: false };
}
}
async function doorOf() {
try {
const tab = await chrome.tabs?.getCurrent?.();
return tab === undefined || tab === null ? 'popup' : 'tab';
} catch {
return 'popup';
}
}
export async function startAccountUi() {
document.documentElement.dataset.shell = await doorOf();
const locale = await applyLocale();
let current = locale;
const byId = (id) => document.getElementById(id);
const status = byId('status');
const syncStatus = byId('sync-status');
const syncConflict = byId('sync-conflict');
const syncButtons = [...document.querySelectorAll('#settings-sync button')];
const send = (method, params) => chrome.runtime.sendMessage({ method, params })
.then((value) => value || { ok: false, reason: 'no-response' },
() => ({ ok: false, reason: 'network' }));
let cloudUiDropped = false;
function dropCloudUi() {
if (cloudUiDropped) return;
cloudUiDropped = true;
const nodes = [
byId('account-actions'),
byId('settings-sync'),
byId('signin'),
...document.querySelectorAll('main form'),
];
for (const node of nodes) node?.remove();
}
function reflect(value) {
const signedIn = value?.ok === true && value.authenticated === true;
for (const node of document.querySelectorAll('[data-when]')) {
node.hidden = node.dataset.when === (signedIn ? 'out' : 'in');
}
}
const buy = byId('buy');
const links = byId('links');
function say(text, state, rightWorks = false) {
status.textContent = text;
status.dataset.state = state;
if (buy !== null) buy.hidden = rightWorks;
if (links !== null) links.hidden = rightWorks;
}
async function show(value) {
if (value?.configured === false) {
dropCloudUi();
say(msg('accountNotConfigured'), 'plain');
return;
}
reflect(value);
if (value?.ok !== true) {
say(msg(WORDS[value?.reason] ?? 'accountError'), 'error');
return;
}
if (value.authenticated === true) {
const hint = value.account?.hint ?? '';
const right = await rightOf(value.entitlement);
if (right.none) {
say(msg('accountFree', [hint]), 'free');
return;
}
if (!right.ok) {
say(msg('accountCheckFailed'), 'error');
return;
}
const until = dateOf(right.exp);
say(value.cached === true
? `${msg('accountPremiumUntil', [until, hint])} ${msg('accountOffline', [until])}`
: msg('accountPremiumUntil', [until, hint]),
value.cached === true ? 'offline' : 'premium', true);
return;
}
say(msg('accountSignedOut'), 'free');
}
const refresh = () => send('account.status', { force: true }).then(show);
const settingsSync = syncStatus === null ? null : createSettingsSync({
area: chrome.storage.local,
transport: {
read: () => send('account.settings.read'),
write: (payload) => send('account.settings.write', payload),
},
});
async function runSync(resolution = null) {
syncButtons.forEach((button) => { button.disabled = true; });
try {
const value = await settingsSync.run({ resolution });
if (value?.reason === 'conflict') {
syncStatus.textContent = msg('accountSyncConflict');
syncConflict.hidden = false;
return;
}
syncConflict.hidden = true;
syncStatus.textContent = value?.ok === true
? msg('accountSyncDone', [String(value.revision)])
: msg('accountSyncError');
} finally {
syncButtons.forEach((button) => { button.disabled = false; });
}
}
byId('refresh')?.addEventListener('click', refresh);
byId('logout')?.addEventListener('click', () => send('account.logout').then(show));
byId('sync-now')?.addEventListener('click', () => runSync());
byId('sync-cloud')?.addEventListener('click', () => runSync('cloud'));
byId('sync-local')?.addEventListener('click', () => runSync('local'));
byId('login')?.addEventListener('submit', (event) => {
event.preventDefault();
const password = byId('password');
send('account.login', {
email: byId('email').value,
password: password.value,
}).then((value) => {
password.value = '';
show(value);
});
});
byId('recovery-start')?.addEventListener('submit', (event) => {
event.preventDefault();
send('account.recovery.start', {
email: byId('recovery-email').value,
}).then((value) => {
status.textContent = value?.ok === true
? msg('accountRecoveryAccepted') : msg('accountError');
});
});
byId('recovery-complete')?.addEventListener('submit', (event) => {
event.preventDefault();
const password = byId('new-password');
send('account.recovery.complete', {
token: byId('recovery-token').value,
password: password.value,
}).then((value) => {
password.value = '';
status.textContent = value?.ok === true
? msg('accountRecoveryDone') : msg('accountError');
});
});
const recoveryToggle = byId('recovery-toggle');
const recoveryForms = byId('recovery-forms');
const loginForm = byId('login');
recoveryToggle?.addEventListener('click', () => {
const opened = recoveryForms.hidden;
recoveryForms.hidden = !opened;
if (loginForm !== null) loginForm.hidden = opened;
recoveryToggle.setAttribute('aria-expanded', String(opened));
recoveryToggle.textContent = msg(opened ? 'accountRecoveryBack' : 'accountRecoveryTitle');
});
const langButtons = [...document.querySelectorAll('.lang[data-locale]')];
const markLanguage = (active) => {
for (const node of langButtons) {
node.setAttribute('aria-pressed', String(node.dataset.locale === active));
}
};
const useLocale = (next) => {
if (buy !== null) buy.href = BUY_URL[next] ?? BUY_URL.en;
if (recoveryToggle !== null && recoveryForms !== null && !recoveryForms.hidden) {
recoveryToggle.textContent = msg('accountRecoveryBack');
}
markLanguage(next);
};
useLocale(locale);
for (const node of langButtons) {
node.addEventListener('click', async () => {
const next = node.dataset.locale;
if (next === current) return;
current = next;
await rememberLocale(next);
useLocale(await applyLocale());
await refresh();
});
}
await refresh();
}
