import{screenPrototype}from'./screen-door.js'
export const QUICK_LIST_DOOR=Object.freeze({name:'quick-list-panel',
declares:['_onList','_onOpen'],methods:['setItem']})
const installations=new WeakMap()
export const COLUMN_SELECTOR='.DetailView'
export const PANEL_SELECTOR='.DetailPanel'
export const CARD_SELECTOR='.detail-carousel'
export const MENU_SELECTOR='.ut-button-group'
export const LISTING_SELECTOR='.ut-quick-list-panel-view'
export const LISTING_BODY_SELECTOR='.panelActions'
export const LISTING_ROW_SELECTOR='.panelActionRow'
export const PRICE_INPUT_SELECTOR='input.ut-number-input-control'
export const SPINNER_SELECTOR='.ut-numeric-input-spinner-control'
export const SPINNER_DOWN_SELECTOR='.decrement-value'
export const DURATION_SELECTOR='.ut-drop-down-control'
const METADATA_SELECTOR='.ut-item-details--metadata'
const AUCTION_INFO_SELECTOR='.auctionInfo'
const SQUAD_INDICATOR_SELECTOR='.ut-item-details--squad-indicator'
const AIR_SELECTORS=Object.freeze([AUCTION_INFO_SELECTOR,SQUAD_INDICATOR_SELECTOR,METADATA_SELECTOR,CARD_SELECTOR,PANEL_SELECTOR])
const AIR_PROPS=Object.freeze(['marginTop','marginBottom','paddingTop','paddingBottom'])
const AIR_GAP=4
export function overflowBelow(node){if(typeof node?.getBoundingClientRect!=='function')return 0
const doc=node.ownerDocument??null
const win=doc?.defaultView??null
let bottom=Number(win?.innerHeight)||Number(doc?.documentElement?.clientHeight)||0
if(bottom<=0)return 0
for(let parent=node.parentElement;parent;parent=parent.parentElement){let overflow=''
try{overflow=String(win?.getComputedStyle?.(parent)?.overflowY??'')}catch{}
if((overflow==='auto'||overflow==='scroll')&&parent.scrollHeight>parent.clientHeight){bottom=Math.min(bottom,parent.getBoundingClientRect().bottom)
break}}
return Math.ceil(node.getBoundingClientRect().bottom-bottom+AIR_GAP)}
export function trimNativeAir(input={}){const{column}=input
const needed=Math.ceil(Number(input.needed)||0)
const records=[]
if(!column||typeof column.querySelectorAll!=='function'||needed<=0)return{trimmed:0,records}
const win=input.win??column.ownerDocument?.defaultView??null
if(typeof win?.getComputedStyle!=='function')return{trimmed:0,records}
let left=needed
let trimmed=0
for(const node of airNodes(column)){if(left<=0)break
for(const prop of AIR_PROPS){if(left<=0)break
let current=0
try{current=Math.floor(Number.parseFloat(win.getComputedStyle(node)[prop])||0)}catch{}
if(current<=0)continue
const cut=Math.min(current,left)
records.push({node,prop,value:node.style[prop]??''})
node.style[prop]=`${current-cut}px`
trimmed+=cut
left-=cut}}
return{trimmed,records}}
function airNodes(column){const nodes=[]
for(const selector of AIR_SELECTORS){for(const node of column.querySelectorAll(selector)){if(node?.style)nodes.push(node)}}
if(column.style)nodes.push(column)
return nodes}
export function clearNativeAir(column){return trimNativeAir({column,needed:Number.MAX_SAFE_INTEGER})}
export function restoreNativeAir(records){const list=records??[]
for(let i=list.length-1;i>=0;i-=1){try{list[i].node.style[list[i].prop]=list[i].value}catch{}}
return true}
export function columnOf(root){const panel=typeof root?.closest==='function'?root.closest(PANEL_SELECTOR):null
let node=(panel??root)?.parentElement??null
const doc=root?.ownerDocument??null
for(let depth=0;node&&depth<3;depth+=1,node=node.parentElement){if(node===doc?.body||node===doc?.documentElement)break
if(typeof node.querySelector==='function'&&node.querySelector(CARD_SELECTOR))return{node,header:true}}
return panel?{node:panel,header:false}:null}
export function rowsHostOf(root){const parent=root?.parentElement??null
return parent&&typeof parent.insertBefore==='function'?parent:null}
export function installQuickListCapture(win,onItem=()=>{}){const proto=screenPrototype(win,QUICK_LIST_DOOR)
if(!proto||typeof proto.setItem!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let installation=installations.get(proto)
if(!installation){const original=proto.setItem
const listeners=new Set()
const wrapped=function(item){const result=original.call(this,item)
let view=null
let root=null
try{view=typeof this.getView==='function'?this.getView():null}catch{}
try{root=typeof view?.getRootElement==='function'?view.getRootElement():null}catch{}
if(item&&typeof item==='object'&&root){for(const listener of listeners){try{listener({item,view,root,controller:this})}catch{}}}
return result}
proto.setItem=wrapped
installation={original,wrapped,listeners}
installations.set(proto,installation)}
installation.listeners.add(onItem)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.listeners.delete(onItem)
if(installation.listeners.size===0&&proto.setItem===installation.wrapped){proto.setItem=installation.original
installations.delete(proto)}}}}
export function readListingItem(item){const read=(fn,fallback=null)=>{try{const value=fn()
return value===undefined?fallback:value}catch{return fallback}}
const number=(value)=>(Number.isSafeInteger(Number(value))&&Number(value)>0?Number(value):null)
return{id:number(read(()=>item?.id)),definitionId:number(read(()=>item?.definitionId)),name:cleanName(read(()=>item?.getStaticData?.()?.name))||cleanName(read(()=>item?.displayName))||cleanName(read(()=>item?.name)),tradeable:read(()=>item?.isTradeable?.()===true,false),limits:readLimits(read(()=>item?.getPriceLimits?.()??null)),lastSalePrice:number(read(()=>item?.lastSalePrice))}}
function readLimits(limits){if(!limits||typeof limits!=='object')return null
const minimum=Number(limits.minimum)
const maximum=Number(limits.maximum)
if(!Number.isSafeInteger(minimum)||!Number.isSafeInteger(maximum))return null
if(minimum<1||maximum<minimum)return null
return{minimum,maximum}}
export function readListingPrices(root){const inputs=root?.querySelectorAll?.(PRICE_INPUT_SELECTOR)
const list=inputs?Array.from(inputs):[]
return{startingBid:parseCoins(list[0]?.value),buyNow:parseCoins(list[1]?.value)}}
export function parseCoins(text){if(typeof text!=='string')return null
const digits=text.replace(/[^0-9]/g,'')
if(digits==='')return null
const value=Number(digits)
return Number.isSafeInteger(value)&&value>0?value:null}
export function applyListingPrices(view,prices){if(!view||typeof view.setBuyNowValue!=='function'||typeof view.setBidValue!=='function')return false
const buyNow=Number(prices?.buyNow)
const startingBid=Number(prices?.startingBid)
if(!Number.isSafeInteger(buyNow)||!Number.isSafeInteger(startingBid))return false
if(!(buyNow>startingBid)||startingBid<1)return false
try{view.setBuyNowValue(buyNow)
view.setBidValue(startingBid)}catch{return false}
return true}
export function applyListingDuration(view,seconds){const picker=view?._durationPicker
if(!picker||typeof picker.setIndexByValue!=='function')return false
const value=Number(seconds)
if(!Number.isSafeInteger(value)||value<=0)return false
try{return picker.setIndexByValue(value)===true}catch{return false}}
export function readListingDuration(view){const picker=view?._durationPicker
if(!picker)return null
try{const value=Number(picker.value)
return Number.isSafeInteger(value)&&value>0?value:null}catch{return null}}
export function hasDurationControl(view){return typeof view?._durationPicker?.setIndexByValue==='function'}
export function isListingOpen(root){const body=root?.querySelector?.(LISTING_BODY_SELECTOR)
return body?.classList?.contains?.('open')===true}
export function openListingPanel(view,root){if(typeof view?.open!=='function')return false
if(root&&root.isConnected===false)return false
try{view.open()}catch{return false}
return true}
function cleanName(value){return typeof value==='string'?value.trim().replace(/\s+/g,' '):''}
