export function appBusy(win){const shield=win?.gClickShield
if(!shield||typeof shield.isShowing!=='function')return null
try{return shield.isShowing()===true}catch{return null}}
