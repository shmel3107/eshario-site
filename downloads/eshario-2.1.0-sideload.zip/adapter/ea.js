import{itemPiles,pileValue} from './tables.js'
import{criteriaClass} from './search.js'
import{EaRequestError,requestData,toPromise} from './observable.js'
import{applyCriteria,createLotFilter} from './search.js'
import{splitCriteria} from '../features/filters.js'
import{reviewAction,DoorRefusedError,ALLOWED,UNKNOWN} from './action-door.js'
import{marketPageSize,catchNextSearch} from './market-search.js'
export function pileNameOf(win,pile){if(pile===undefined||pile===null)return null
const table=itemPiles(win)
for(const name of['CLUB','TRANSFER','STORAGE']){if(table[name]===pile)return name}
return null}
export function pileValueOf(win,name){return pileValue(win,name)}
export function localizeNumber(win,value){const box=win?.services?.Localization
if(typeof box?.localizeNumber!=='function')return null
try{const out=box.localizeNumber(value)
return typeof out==='string'&&out!==''?out:null}catch{return null}}
export function getEaServices(win=globalThis){const services=win?.services
if(!services||typeof services!=='object'){throw new Error('adapter: приложение EA не найдено в page context')}
return services}
export function isEaReady(win=globalThis){return Boolean(win?.services?.Item)}
const DECISIVE_CRITERIA=Object.freeze(['defId','maxBuy','minBuy','maxBid','minBid'])
export function toSearchCriteria(win,criteria){
const Criteria=criteriaClass(win)
if(typeof Criteria!=='function')return criteria
if(criteria instanceof Criteria)return criteria
const dto=new Criteria()
const result=applyCriteria(dto,splitCriteria(criteria??{}).server)
const lost=[...result.rejected.map((row)=>row.field),...result.failed.map((row)=>row.field)]
.filter((field)=>DECISIVE_CRITERIA.includes(field))
if(lost.length>0)throw new Error(`adapter: EA не приняла условия поиска: ${lost.join(', ')}`)
return dto}
export function searchTypeOf(item){let type
try{type=item?.getSearchType?.()}catch{return null}
return typeof type==='string'&&type!==''?type:null}
export function createItemAdapter(services,win=globalThis){const item=services?.Item
if(!item) throw new Error('adapter: services.Item недоступен')
const judged=(request,run)=>{const review=reviewAction({...request,win})
return review.verdict===ALLOWED?run():Promise.reject(new DoorRefusedError(review))}
return{
searchTransferMarket:(criteria,page)=>requestData(item.searchTransferMarket(toSearchCriteria(win,criteria),page),'поиск по рынку'),
lotFilter:(criteria)=>createLotFilter(criteria,win),
pageSize:()=>marketPageSize(win),
catchSearch:(deps)=>catchNextSearch(win,deps),
clearMarketCache:()=>{if(typeof item.clearTransferMarketCache!=='function')return false
item.clearTransferMarketCache()
return true},
bid:(lot,amount,intent=null)=>judged({action:intent==='buy'||intent==='bid'?intent:null,lot,amount},
()=>requestData(item.bid(lot,amount),'ставка')),
list:(itemData,startingBid,buyNowPrice,duration,origin=null)=>judged({action:'list',items:[itemData],fresh:origin?.fresh,rows:origin?.rows??null},
()=>requestData(item.list(itemData,startingBid,buyNowPrice,duration),'выставление лота')),
move:(items,pile)=>judged({action:'move',destination:pileNameOf(win,pile),items:Array.isArray(items)?items:[]},
()=>requestData(item.move(items,pile),'перемещение')),
discard:(items)=>judged({action:'discard',items:Array.isArray(items)?items:[]},
()=>requestData(item.discard(items),'быстрая продажа')),
relist:(rows)=>judged({action:'relist',rows:Array.isArray(rows)?rows:null},
()=>requestData(item.relistExpiredAuctions(),'переставление лотов')),
clear:(rows,one=null)=>judged({action:'clear',rows:Array.isArray(rows)?rows:null},
()=>requestData(one===null||one===undefined?item.clearSoldItems():item.clearSoldItems(one),'очистка проданного')),
review:(request)=>reviewAction({...request,win}),
requestMarketData:(itemData)=>requestData(item.requestMarketData(itemData),'рыночные данные'),
searchStorageItems:async(criteria)=>{if(typeof item.searchStorageItems!=='function'){throw new Error('adapter: searchStorageItems недоступен')}
const response=await requestData(item.searchStorageItems(criteria),'хранилище дубликатов'
)
if(!response
||typeof response!=='object'
||Array.isArray(response)
||!Array.isArray(response.items)
||typeof response.endOfList!=='boolean'
){throw new EaRequestError('хранилище дубликатов: EA вернула неизвестную форму ответа',{response})}
return{items:response.items,endOfList:response.endOfList}},
requestTransferItems:()=>requestData(item.requestTransferItems(),'трансферный список'),
requestUnassignedItems:()=>requestData(item.requestUnassignedItems(),'непринятые предметы'),
requestWatchedItems:()=>requestData(item.requestWatchedItems(),'список наблюдения'),
raw:(observable)=>toPromise(observable)}}
export function createClubAdapter(services){const club=services?.Club
if(!club) throw new Error('adapter: services.Club недоступен')
return{
ready:()=>typeof club.search==='function'&&typeof club.getStats==='function',
search:async(criteria)=>{if(typeof club.search!=='function'){throw new Error('adapter: services.Club.search недоступен')}
const response=await requestData(club.search(criteria),'предметы клуба')
if(!response
||typeof response!=='object'
||Array.isArray(response)
||!Array.isArray(response.items)
||typeof response.retrievedAll!=='boolean'
){throw new EaRequestError('предметы клуба: EA вернула неизвестную форму ответа',{response})}
return{items:response.items,retrievedAll:response.retrievedAll}},
stats:async()=>{if(typeof club.getStats!=='function'){throw new Error('adapter: services.Club.getStats недоступен')}
const response=await requestData(club.getStats(),'счётчики клуба')
const list=response?.stats
if(!Array.isArray(list)){throw new EaRequestError('счётчики клуба: EA вернула неизвестную форму ответа',{response})}
const out=[]
for(const row of list){const type=row?.type
const count=row?.count
if(typeof type!=='string'||type===''||!Number.isSafeInteger(count)||count<0){throw new EaRequestError('счётчики клуба: EA вернула неизвестную строку счётчика',{response})}
out.push({type,count})}
return out}}}
export function createClubMemory(win=globalThis){const repo=()=>{try{return win?.repositories?.Item?.getClub?.()??null}catch{return null}}
return{
item(id){const club=repo()
if(!club||typeof club.getItem!=='function')return null
const key=Number(id)
if(!Number.isFinite(key))return null
try{return club.getItem(null,null,key)??null}catch{return null}},
stats(){const club=repo()
if(!club||typeof club.getStats!=='function')return null
let raw=null
try{raw=club.getStats()}catch{return null}
if(!raw)return null
const out=[]
try{for(const row of raw){const type=row?.type
const count=row?.count
if(typeof type!=='string'||type===''||!Number.isSafeInteger(count)||count<0)return null
out.push({type,count})}}catch{return null}
return out.length>0?out:null},
statsStamp(){const club=repo()
if(!club)return null
let raw=null
try{raw=club.statsCacheTimestamp}catch{return null}
if(typeof raw!=='number'||!Number.isFinite(raw)||raw<=0)return null
return raw},
hasStats(){const club=repo()
if(!club||typeof club.hasStats!=='function')return null
try{const ok=club.hasStats()
return typeof ok==='boolean'?ok:null}catch{return null}}}}
export function createStorageMemory(win=globalThis){const box=()=>{try{return win?.repositories?.Item?.getStorage?.()??null}catch{return null}}
return{
item(id){const pile=box()
if(!pile||typeof pile.get!=='function')return null
const key=Number(id)
if(!Number.isFinite(key))return null
try{return pile.get(key)??null}catch{return null}}}}
export function createPackAdapter(win=globalThis){const owned=new Map()
const opening=new Set()
let pickEntities=[]
let pickAvailable=0
let confirmingPicks=false
let pickConfirmUncertain=false
let unassignedEntities=[]
let unassignedDtos=[]
let unassignedLoaded=false
let movingUnassigned=false
const clearUnassigned=()=>{unassignedEntities=[]
unassignedDtos=[]
unassignedLoaded=false}
const pickDto=(item,index)=>({index,definitionId:item?.definitionId,rating:item?.rating,tradable:item?.tradable})
const unassignedDto=(raw,index)=>{const Slot=win?.UTSquadSlotEntity
const item=typeof Slot==='function'&&raw instanceof Slot?raw.item:raw
if(!Number.isSafeInteger(item?.id)||item.id<0||!Number.isSafeInteger(item.definitionId)
||item.definitionId<1||typeof item.tradable!=='boolean'
||!Number.isSafeInteger(item.discardValue)||item.discardValue<0)return null
const methods=[['movable','isMovable'],['misc','isMiscItem'],['storable','isStorable'],['vanity','isVanityItem'],['duplicate','isDuplicate'],['tradeableDuplicate','isTradeableDuplicate'],['untradeableDuplicate','isUnTradeableDuplicate'],['discardable','isDiscardable'],['duplicateLoan','isDuplicateLoanPlayer']]
const dto={index,id:item.id,definitionId:item.definitionId,tradable:item.tradable,discardValue:item.discardValue}
try{for(const[field,method]of methods){if(typeof item[method]!=='function') return null
dto[field]=item[method]()
if(typeof dto[field]!=='boolean') return null}}catch{return null}
return{item,dto}}
return{async list(){const store=getEaServices(win).Store
const all=win?.PurchasePackType?.ALL
if(!store||typeof store.getPacks!=='function'||all===undefined){throw new Error('adapter: services.Store.getPacks недоступен')}
const raw=await toPromise(store.getPacks(all,true,true))
if(raw?.success!==true||!Array.isArray(raw?.response?.packs)){throw new EaRequestError('packs: EA вернула неизвестную форму ответа',{response:raw})}
const result=raw.response.packs
.filter((p)=>p?.isMyPack===true&&Number.isSafeInteger(p.id)
&&p.id>=0&&typeof p.tradable==='boolean'&&typeof p.isPlayerPickPack==='boolean')
.map((p)=>({id:p.id,tradable:p.tradable,playerPick:p.isPlayerPickPack,key:`${p.id}:${p.tradable ? 1:0}`
}))
owned.clear()
for(const item of result){const entity=raw.response.packs.find((p)=>p?.id===item.id&&p?.tradable===item.tradable&&p?.isMyPack===true)
owned.set(item.key,entity)}
return result},async unassigned(){if(movingUnassigned) throw new EaRequestError('unassigned PURCHASED: move in progress')
clearUnassigned()
const item=getEaServices(win).Item
const request=item?.requestUnassignedItems
if(typeof request!=='function'){throw new EaRequestError('unassigned PURCHASED: adapter unavailable')}
const raw=await toPromise(request.call(item))
if(raw?.success!==true||!raw.response||typeof raw.response!=='object'
||Array.isArray(raw.response)||!Array.isArray(raw.response.items)){throw new EaRequestError('unassigned PURCHASED: EA returned unknown response form',{response:raw})}
const mapped=raw.response.items.map(unassignedDto)
if(mapped.some((entry)=>!entry)){throw new EaRequestError('unassigned PURCHASED: EA returned unknown item form')}
unassignedEntities=mapped.map((entry)=>entry.item)
unassignedDtos=mapped.map((entry)=>entry.dto)
unassignedLoaded=true
return{count:unassignedDtos.length,items:unassignedDtos}},reviewUnassigned(indices){if(!unassignedLoaded) return{ok:false,reason:'stale'}
if(!Array.isArray(indices)||new Set(indices).size!==indices.length
||indices.some((index)=>!Number.isSafeInteger(index)||index<0
||!unassignedEntities[index])) return{ok:false,reason:'invalid'}
return{ok:true,reason:null,items:indices.map((index)=>unassignedDtos[index])}},reviewUnassignedPlan(plan){if(!unassignedLoaded) return{ok:false,reason:'stale'}
const groups=['club','transfer','storage']
if(!plan||groups.some((name)=>!Array.isArray(plan[name]))){return{ok:false,reason:'invalid'}}
const all=groups.flatMap((name)=>plan[name])
const checked=this.reviewUnassigned(all)
if(!all.length||!checked.ok) return checked.ok?{ok:false,reason:'invalid'}:checked
try{if(plan.club.some((i)=>unassignedEntities[i].isMovable()!==true)
||plan.transfer.some((i)=>unassignedEntities[i].isTradeableDuplicate()!==true)
||plan.storage.some((i)=>unassignedEntities[i].isStorable()!==true
||unassignedEntities[i].isUnTradeableDuplicate()!==true)){return{ok:false,reason:'incompatible'}}} catch{return{ok:false,reason:'incompatible'}}
for(const[destination,pileName] of[['club','CLUB'],['transfer','TRANSFER'],['storage','STORAGE']]){const indices=plan[destination]
if(!indices.length)continue
const review=reviewAction({win,action:'move',destination:pileName,
items:indices.map((index)=>unassignedEntities[index])})
if(review.verdict===ALLOWED)continue
if(review.reason==='capacity')return{ok:false,reason:'capacity',destination,fits:review.fits,need:review.need}
if(review.reason==='feature-off')return{ok:false,reason:'feature-off',destination}
if(review.reason==='predicate')return{ok:false,reason:'incompatible',destination}
return{ok:false,reason:'guard-unavailable',destination}}
return{ok:true,reason:null}},async moveUnassigned(destination,indices){if(movingUnassigned) return{ok:false,reason:'busy'}
const spec={club:['CLUB',false],transfer:['TRANSFER',false],storage:['STORAGE',true]}[destination]
if(!spec) return{ok:false,reason:'invalid'}
const plan={club:[],transfer:[],storage:[]}
plan[destination]=indices
const review=this.reviewUnassignedPlan(plan)
if(!review.ok)return review
const service=getEaServices(win).Item
const pile=pileValue(win,spec[0])
if(typeof service?.move!=='function'||pile===undefined){return{ok:false,reason:'guard-unavailable'}}
const entities=indices.map((index)=>unassignedEntities[index])
const expected=entities.map((item)=>item.id)
if(new Set(expected).size!==expected.length) return{ok:false,reason:'invalid'}
movingUnassigned=true
clearUnassigned()
try{const request=spec[1]
?service.move(entities,pile,true):service.move(entities,pile)
const raw=await toPromise(request)
const ids=raw?.data?.itemIds
if(raw?.success!==true||!Array.isArray(ids)
||ids.length!==expected.length||new Set(ids).size!==ids.length
||ids.some((id)=>!expected.includes(id))){return{ok:false,reason:'uncertain'}}
return{ok:true,reason:null,count:ids.length}}finally{movingUnassigned=false}},async discardUnassigned(expected,allow){if(movingUnassigned)return{ok:false,reason:'busy'}
if(!unassignedLoaded)return{ok:false,reason:'stale'}
if(!Array.isArray(expected)||!expected.length||!Array.isArray(allow)
||new Set(allow).size!==allow.length
||allow.some((id)=>!Number.isSafeInteger(id)||id<1)
||new Set(expected.map((x)=>x?.id)).size!==expected.length){return{ok:false,reason:'invalid'}}
const matches=expected.map((x)=>{const found=unassignedDtos.map((dto,index)=>({dto,index}))
.filter(({dto})=>dto.id===x?.id&&dto.definitionId===x?.definitionId
&&dto.discardValue===x?.discardValue);
return found.length===1?found[0]:null})
if(matches.some((x)=>!x))return{ok:false,reason:'stale'}
try{if(matches.some(({dto,index})=>!allow.includes(dto.definitionId)
||unassignedEntities[index].isDiscardable()!==true
||unassignedEntities[index].isDuplicateLoanPlayer()!==false)){return{ok:false,reason:'incompatible'}}}catch{return{ok:false,reason:'incompatible'}}
const service=getEaServices(win).Item
const discard=service?.discard
if(typeof discard!=='function')return{ok:false,reason:'guard-unavailable'}
const entities=matches.map(({index})=>unassignedEntities[index])
const ids=entities.map((item)=>item.id)
const review=reviewAction({win,action:'discard',items:entities})
if(review.verdict!==ALLOWED){return{ok:false,reason:review.verdict===UNKNOWN?`door-${review.reason}`:review.reason,door:review}}
movingUnassigned=true
clearUnassigned()
try{let raw
try{raw=await toPromise(discard.call(service,entities))}
catch{return{ok:false,reason:'uncertain'}}
const got=raw?.data?.itemIds
if(raw?.success!==true||!Array.isArray(got)||got.length!==ids.length
||new Set(got).size!==got.length||got.some((id)=>!ids.includes(id))){return{ok:false,reason:'uncertain'}}
return{ok:true,reason:null,count:got.length}}finally{movingUnassigned=false}},async pendingPicks(){const services=getEaServices(win)
let user
try{user=services.User?.getUser?.()}catch{user=null}
const pending=user?.hasPlayerPicksPending
pickEntities=[]
pickAvailable=0
pickConfirmUncertain=false
if(typeof pending!=='boolean'){throw new EaRequestError('player picks: состояние EA недоступно')}
if(!pending)return{items:[],availablePicks:0}
const request=services.Item?.requestPendingPlayerPickItemSelection
if(typeof request!=='function'){throw new EaRequestError('player picks: адаптер EA недоступен')}
const raw=await toPromise(request.call(services.Item))
const items=raw?.response?.items
const availablePicks=raw?.response?.availablePicks
if(raw?.success!==true||!Array.isArray(items)||items.length===0
||!Number.isSafeInteger(availablePicks)||availablePicks<1
||availablePicks>items.length){throw new EaRequestError('player picks: EA вернула неизвестную форму ответа',{response:raw})}
const result=items.map(pickDto)
if(result.some((item)=>!Number.isSafeInteger(item.definitionId)||item.definitionId<0
||!Number.isSafeInteger(item.rating)||item.rating<0||typeof item.tradable!=='boolean')){throw new EaRequestError('player picks: EA вернула неизвестную форму предмета')}
pickEntities=[...items]
pickAvailable=availablePicks
return{items:result,availablePicks}},reviewPicks(indices){if(pickEntities.length===0) return{ok:false,reason:'stale'}
if(!Array.isArray(indices)||indices.length!==pickAvailable){return{ok:false,reason:'incomplete'}}
if(new Set(indices).size!==indices.length
||indices.some((index)=>!Number.isSafeInteger(index)||index<0||!pickEntities[index])){return{ok:false,reason:'invalid'}}
return{ok:true,reason:null,items:indices.map((index)=>pickDto(pickEntities[index],index))}},async confirmPicks(indices){if(confirmingPicks) return{ok:false,reason:'busy'}
if(pickConfirmUncertain) return{ok:false,reason:'uncertain'}
if(pickEntities.length===0) return{ok:false,reason:'stale'}
if(!Array.isArray(indices)||indices.length!==pickAvailable){return{ok:false,reason:'incomplete'}}
if(new Set(indices).size!==indices.length
||indices.some((index)=>!Number.isSafeInteger(index)||index<0||!pickEntities[index])){return{ok:false,reason:'invalid'}}
const services=getEaServices(win)
let user
try{user=services.User?.getUser?.()}catch{user=null}
const confirm=services.Item?.confirmPlayerPickItemSelection
if(user?.hasPlayerPicksPending!==true||typeof confirm!=='function'){return{ok:false,reason:'guard-unavailable'}}
confirmingPicks=true
pickConfirmUncertain=true
try{const entities=indices.map((index)=>pickEntities[index])
const raw=await toPromise(confirm.call(services.Item,entities))
if(raw?.success!==true||!Array.isArray(raw?.data?.rewards)){throw new EaRequestError('player picks confirm: EA вернула неизвестную форму ответа',{response:raw})}
const rewards=raw.data.rewards.length
pickEntities=[]
pickAvailable=0
pickConfirmUncertain=false
return{ok:true,reason:null,rewards}}finally{confirmingPicks=false}},async open(key){const pack=owned.get(key)
if(!pack) return{ok:false,reason:'not-found'}
if(opening.has(key)) return{ok:false,reason:'busy'}
const pile=pileValue(win,'PURCHASED')
const repository=win?.repositories?.Item
if(pile===undefined||typeof repository?.numItemsInCache!=='function'){return{ok:false,reason:'guard-unavailable'}}
let count
try{count=repository.numItemsInCache(pile)}catch{count=null}
if(!Number.isSafeInteger(count)||count<0) return{ok:false,reason:'guard-unavailable'}
if(count>0) return{ok:false,reason:'unassigned'}
if(typeof pack.isPlayerPickPack!=='boolean'||typeof pack.open!=='function'
||pack.open.length!==0) return{ok:false,reason:'guard-unavailable'}
if(pack.isPlayerPickPack){const user=getEaServices(win).User?.getUser?.()
if(typeof user?.hasPlayerPicksPending!=='boolean'){return{ok:false,reason:'guard-unavailable'}}
if(user.hasPlayerPicksPending) return{ok:false,reason:'pending-picks'}
return{ok:false,reason:'player-pick-unsupported'}}
opening.add(key)
try{const raw=await toPromise(pack.open())
if(raw?.success!==true||!Array.isArray(raw?.response?.items)){throw new EaRequestError('packs open: EA вернула неизвестную форму ответа',{response:raw})}
owned.delete(key)
return{ok:true,reason:null,items:raw.response.items}}finally{opening.delete(key)}}}}
export function createAdapter(win=globalThis){const services=getEaServices(win)
return{item:createItemAdapter(services,win),
club:services.Club?createClubAdapter(services):null}}
