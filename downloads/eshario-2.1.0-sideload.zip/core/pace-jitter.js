export const LIST_PAUSE_MIN_MS=1000
export const LIST_PAUSE_MAX_MS=1300
const STEPS=LIST_PAUSE_MAX_MS-LIST_PAUSE_MIN_MS+1
export function listPauseMs(random){const draw=typeof random==='function'?random:Math.random
let roll=NaN
try{roll=draw()}catch{return LIST_PAUSE_MAX_MS}
if(typeof roll!=='number'||!Number.isFinite(roll))return LIST_PAUSE_MAX_MS
const inside=Math.min(1,Math.max(0,roll))
return Math.min(LIST_PAUSE_MAX_MS,LIST_PAUSE_MIN_MS+Math.floor(inside*STEPS))}
