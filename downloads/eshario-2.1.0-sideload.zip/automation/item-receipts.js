export function itemIdsReceiptMatches(data,items){if(!data
||typeof data!=='object'
||Array.isArray(data)
||!Array.isArray(data.itemIds)
||!Array.isArray(items)
||items.length===0){return false}
const isId=(id)=>((typeof id==='number'&&Number.isFinite(id))
||(typeof id==='string'&&id!==''))
const expectedIds=items.map((item)=>item?.id)
if(expectedIds.some((id)=>!isId(id))||data.itemIds.some((id)=>!isId(id)))return false
const expected=new Set(expectedIds)
const received=new Set(data.itemIds)
if(expected.size!==expectedIds.length
||received.size!==data.itemIds.length
||received.size!==expected.size)return false
return expectedIds.every((id)=>received.has(id))}
export function moveReceiptMatches(data,items){return itemIdsReceiptMatches(data,items)}
