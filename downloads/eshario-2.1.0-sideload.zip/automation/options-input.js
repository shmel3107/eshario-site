import{parseLimitInput} from './limits-input.js'
import{ITEM_PILE} from '../features/club-analysis.js'
import{POLICY_FIELDS,parsePurchasePolicy} from './purchase-policy.js'
export{POLICY_FIELDS} from './purchase-policy.js'
export const OPTION_FIELDS=Object.freeze([{key:'maxPrice',labelKey:'automation.option.maxPrice',scale:1,unitKey:null,target:'maxPrice'},{key:'maxBid',labelKey:'automation.option.maxBid',scale:1,unitKey:null,target:'maxBid'},{key:'resaleMarginPercent',labelKey:'automation.option.resaleMargin',scale:1,unitKey:'seller.field.percent',target:'immediateList.marginPercent'},{key:'resaleMinProfit',labelKey:'automation.option.resaleMinProfit',scale:1,unitKey:null,target:'immediateList.minProfit'},{key:'searchDelaySec',labelKey:'automation.option.searchDelay',scale:1000,unitKey:'automation.option.seconds',target:'searchDelayMs'},{key:'buyDelaySec',labelKey:'automation.option.buyDelay',scale:1000,unitKey:'automation.option.seconds',target:'buyDelayMs'},{key:'jitterSec',labelKey:'automation.option.jitter',scale:1000,unitKey:'automation.option.seconds',target:'jitterMs'},{key:'breakWorkMin',labelKey:'automation.option.breakWork',scale:60_000,unitKey:'automation.limit.minutes',target:'breaks.workMs'},{key:'breakRestMin',labelKey:'automation.option.breakRest',scale:60_000,unitKey:'automation.limit.minutes',target:'breaks.restMs'}].map(Object.freeze))
export const ADVANCED_OPTION_FIELDS=Object.freeze([{key:'maxPerSearch',scale:1,target:'maxPerSearch'},
{key:'matchGuard',scale:1,target:'matchGuard'},
{key:'snipeKeyThreshold',scale:1,target:'snipeKeyThreshold'}].map(Object.freeze))
export const AFTER_BUY_KEY='afterBuy'
export const CONFIRM_EACH_RUN='confirmEachRun'
export const CONFIRM_EACH_RUN_DEFAULT=true
export const RATING_SEARCH_NOW='ratingSearchNow'
export const RATING_SEARCH_NOW_DEFAULT=true
export const AFTER_BUY=Object.freeze({TRANSFER_LIST:'transferList',TRANSFER_LIST_NOW:'transferListNow',UNASSIGNED:'unassigned',CLUB:'club'})
export const AFTER_BUY_DEFAULT=AFTER_BUY.TRANSFER_LIST
export const AFTER_BUY_PILE=Object.freeze({[AFTER_BUY.TRANSFER_LIST]:ITEM_PILE.TRANSFER,[AFTER_BUY.TRANSFER_LIST_NOW]:ITEM_PILE.TRANSFER,[AFTER_BUY.UNASSIGNED]:null,[AFTER_BUY.CLUB]:ITEM_PILE.CLUB})
export function afterBuyOf(value){return Object.hasOwn(AFTER_BUY_PILE,value)?value:AFTER_BUY_DEFAULT}
const LEGACY_MOVE_TO_CLUB='moveToClub'
const LEGACY_IMMEDIATE_LIST='listAfterBuy'
function destinationOf(stored,slider){if(stored?.[LEGACY_MOVE_TO_CLUB]===true)return AFTER_BUY.CLUB
if(stored?.[LEGACY_IMMEDIATE_LIST]===true)return AFTER_BUY.TRANSFER_LIST_NOW
return afterBuyOf(slider)}
export const ALLOW_UNASSIGNED_OVERFLOW='allowUnassignedOverflow'
export const BOOLEAN_OPTION_KEYS=Object.freeze([ALLOW_UNASSIGNED_OVERFLOW,CONFIRM_EACH_RUN,RATING_SEARCH_NOW])
export const MOVE_TARGET=ITEM_PILE.CLUB
export function sanitizeOptionInput(stored){const out={[ALLOW_UNASSIGNED_OVERFLOW]:stored?.[ALLOW_UNASSIGNED_OVERFLOW]===true,
[CONFIRM_EACH_RUN]:stored?.[CONFIRM_EACH_RUN]!==false,
[RATING_SEARCH_NOW]:stored?.[RATING_SEARCH_NOW]!==false}
for(const field of OPTION_FIELDS){const value=stored?.[field.key]
out[field.key]=typeof value==='string'?value:''
}
for(const field of POLICY_FIELDS){const value=stored?.[field.key]
out[field.key]=typeof value==='string'?value:''
}
for(const field of ADVANCED_OPTION_FIELDS){const value=stored?.[field.key]
out[field.key]=typeof value==='string'?value:''
}
out[AFTER_BUY_KEY]=destinationOf(stored,stored?.[AFTER_BUY_KEY])
return out}
export function defaultOptionInput(){return sanitizeOptionInput(null)}
export function parseOptions(input={}){const options={}
const errors=[]
for(const field of OPTION_FIELDS){const parsed=parseLimitInput(input?.[field.key],{fraction:field.scale>1})
if(!parsed.ok){errors.push({key:field.key,reason:parsed.reason})
continue}
if(parsed.value===null)continue
setPath(options,field.target,Math.round(parsed.value*field.scale))}
for(const field of ADVANCED_OPTION_FIELDS){const parsed=parseLimitInput(input?.[field.key])
if(!parsed.ok){errors.push({key:field.key,reason:parsed.reason})
continue}
if(parsed.value===null)continue
setPath(options,field.target,parsed.value*field.scale)}
options[AFTER_BUY_KEY]=destinationOf(input,input?.[AFTER_BUY_KEY])
const purchase=parsePurchasePolicy(input)
errors.push(...purchase.errors)
if(Object.values(purchase.policy).some((value)=>Array.isArray(value)&&value.length>0)){options.purchasePolicy=purchase.policy}
if(options[AFTER_BUY_KEY]===AFTER_BUY.TRANSFER_LIST_NOW){options.immediateList??={}
options.immediateList.enabled=true}
if(options[AFTER_BUY_KEY]===AFTER_BUY.CLUB){options.moveTo=MOVE_TARGET}
if(input?.[ALLOW_UNASSIGNED_OVERFLOW]===true){options.allowUnassignedOverflow=true}
options[CONFIRM_EACH_RUN]=input?.[CONFIRM_EACH_RUN]!==false
return{options,errors}}
export function optionsToInput(options={}){const out={[ALLOW_UNASSIGNED_OVERFLOW]:options?.allowUnassignedOverflow===true,
[CONFIRM_EACH_RUN]:options?.[CONFIRM_EACH_RUN]!==false}
for(const field of OPTION_FIELDS){const value=getPath(options,field.target)
out[field.key]=typeof value==='number'&&Number.isFinite(value)
?String(value / field.scale)
:''
}
for(const field of POLICY_FIELDS){const value=options?.purchasePolicy?.[field.key];
out[field.key]=Array.isArray(value)?value.join(', '):(typeof value==='string'?value:'')
}
for(const field of ADVANCED_OPTION_FIELDS){const value=getPath(options,field.target)
out[field.key]=typeof value==='number'&&Number.isFinite(value)
?String(value / field.scale)
:''
}
out[AFTER_BUY_KEY]=options?.immediateList?.enabled===true?AFTER_BUY.TRANSFER_LIST_NOW
:(options?.moveTo===MOVE_TARGET?AFTER_BUY.CLUB:afterBuyOf(options?.[AFTER_BUY_KEY]))
return out}
export function bidsEnabled(input={}){const parsed=parseLimitInput(input?.maxBid);
return parsed.ok&&typeof parsed.value==='number'&&parsed.value>0}
function setPath(target,path,value){const parts=path.split('.');
let node=target;
for(const part of parts.slice(0,-1)){if(!node[part]||typeof node[part]!=='object') node[part]={};
node=node[part]}
node[parts.at(-1)]=value}
function getPath(source,path){let node=source;
for(const part of path.split('.')){if(!node||typeof node!=='object') return undefined;
node=node[part]}
return node}
