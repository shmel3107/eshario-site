import{sellPriceFor,startingBidFor,NO_SALE} from './pricing.js'
import{isSoldAuction} from '../adapter/action-door.js'
export{isSoldAuction}
export const ACTION=Object.freeze({LIST:'list',QUICK_SELL:'quickSell',KEEP:'keep'
})
const isMoney=(value)=>typeof value==='number'&&Number.isFinite(value)&&value>=0
export function discardValueOf(item){const value=item?.discardValue
return isMoney(value)?value:0}
export function isDiscardable(item){if(typeof item?.isDiscardable!=='function') return false
try{return item.isDiscardable()===true}catch{return false}}
export function marketPriceOf(item,lookup){if(typeof lookup==='function'){const found=lookup(item)
if(isMoney(found)&&found>0)return found}
if(typeof item?.getMarketAverage==='function'){try{const average=item.getMarketAverage()
if(isMoney(average)&&average>0)return average}catch{
}}
return null}
export function planSales(items,opts={}){if(!Array.isArray(items))return[]
const allowQuickSell=opts.allowQuickSell===true
const quickSellBelow=isMoney(opts.quickSellBelow)?opts.quickSellBelow:0
const plan=[]
for(const item of items){if(!item||typeof item!=='object'){plan.push({item,action:ACTION.KEEP,price:null,startingBid:null,reason:'not-an-item'})
continue}
const marketPrice=marketPriceOf(item,opts.marketPrice)
const boughtFor=typeof opts.buyPrice==='function'
?opts.buyPrice(item)
:item.lastSalePrice
const priced=sellPriceFor({marketPrice:marketPrice??0,
buyPrice:isMoney(boughtFor)?boughtFor:0,marginPercent:opts.marginPercent,minProfit:opts.minProfit})
if(priced.ok){plan.push({item,action:ACTION.LIST,price:priced.price,startingBid:startingBidFor(priced.price,{discountPercent:opts.bidDiscountPercent}),reason:null,profit:priced.profit})
continue}
if(allowQuickSell&&quickSellBelow>0){const discard=discardValueOf(item)
const worth=marketPrice??discard
if(worth>0
&&worth<quickSellBelow
&&discard>0
&&isDiscardable(item)){plan.push({item,action:ACTION.QUICK_SELL,price:discard,startingBid:null,reason:priced.reason})
continue}}
plan.push({item,action:ACTION.KEEP,price:null,startingBid:null,reason:priced.reason})}
return plan}
export function auctionOf(item){if(!item||typeof item!=='object') return null
if(typeof item.getAuctionData==='function'){try{const data=item.getAuctionData()
if(data&&typeof data==='object') return data}catch{return null}}
return null}
export function saleOf(item){const auction=auctionOf(item)
if(!isSoldAuction(auction))return null
const bid=auction.currentBid
if(isMoney(bid)&&bid>0){return{tradeId:tradeIdOf(auction,item),coins:bid,exact:true,item}}
const asked=[auction.buyNowPrice,auction.startingBid].find((v)=>isMoney(v)&&v>0)
if(asked===undefined)return null
return{tradeId:tradeIdOf(auction,item),coins:asked,exact:false,item}}
export function soldSalesOf(items){if(!Array.isArray(items))return[]
const out=[]
for(const item of items){const sale=saleOf(item)
if(sale!==null)out.push(sale)}
return out}
export function soldRowsOf(items){if(!Array.isArray(items))return[]
const out=[]
for(const item of items){const auction=auctionOf(item)
if(!isSoldAuction(auction))continue
out.push({tradeId:tradeIdOf(auction,item),item})}
return out}
function tradeIdOf(auction,item){for(const value of[auction?.tradeId,item?.id]){if(typeof value==='number'&&Number.isFinite(value)) return String(value)
if(typeof value==='string'&&value!=='') return value}
return null}
export function summarize(plan){const out={list:0,quickSell:0,keep:0,expectedProceeds:0,reasons:{}}
for(const row of plan??[]){if(row.action===ACTION.LIST){out.list+=1
out.expectedProceeds+=typeof row.profit==='number'?row.profit:0}else if(row.action===ACTION.QUICK_SELL)out.quickSell+=1
else{out.keep+=1
const reason=row.reason??NO_SALE.NO_PRICE
out.reasons[reason]=(out.reasons[reason]??0)+1}}
return out}
