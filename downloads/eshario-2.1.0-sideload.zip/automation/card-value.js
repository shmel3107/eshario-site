import{rarityOf,tierOf,leagueOf,nationOf,clubOf,linkedClubOf,needOf,REQUIREMENT_KEY,COMPARE} from './sbc-requirements.js'
import{squadRatingBounds,FIELD_PLAYERS} from './squad-rating.js'
import{tradabilityOf} from '../features/club-analysis.js'
export const EA_TAX_RATE=0.05
export const netSaleOf=(price)=>isNum(price)&&price>0?Math.floor(price*(1-EA_TAX_RATE)):null
const isNum=(value)=>typeof value==='number'&&Number.isFinite(value)
export function ladderPriceAt(ladder,rating,opts={}){if(!Array.isArray(ladder)||!isNum(rating))return null
const raw=opts?.raw===true
let best=null
for(const step of ladder){if(!isNum(step?.rating)||step.rating<rating)continue
const price=raw&&Array.isArray(step.picks)&&isNum(step.picks[0]?.price)?step.picks[0].price:step.price
if(!isNum(price))continue
if(best===null||price<best)best=price}
return best}
export function demandClasses(parsedRequirements){const classes=new Map()
const ids=(values)=>{const list=[...new Set((Array.isArray(values)?values:[]).filter(isNum))].sort((a,b)=>a-b)
return list.length>0?list:null}
const partOf=(key,value,values,compare)=>{switch(key){
case REQUIREMENT_KEY.PLAYER_RARITY:{const rarities=ids(values)
return rarities?{rarities}:'dead'}
case REQUIREMENT_KEY.PLAYER_RARITY_GROUP:{const rarityGroups=ids(values)
return rarityGroups?{rarityGroups}:'dead'}
case REQUIREMENT_KEY.PLAYER_MIN_OVR:return isNum(value)?{minRating:value}:'dead'
case REQUIREMENT_KEY.PLAYER_EXACT_OVR:return isNum(value)?{exactRating:value}:'dead'
case REQUIREMENT_KEY.PLAYER_MAX_OVR:return isNum(value)?{maxRating:value}:'dead'
case REQUIREMENT_KEY.PLAYER_LEVEL:return isNum(value)?{tier:value}:'dead'
case REQUIREMENT_KEY.PLAYER_QUALITY:return compare===COMPARE.EXACT&&isNum(value)?{tier:value}:null
case REQUIREMENT_KEY.LEAGUE_ID:{const leagues=ids(values)
return leagues?{leagues}:'dead'}
case REQUIREMENT_KEY.NATION_ID:{const nations=ids(values)
return nations?{nations}:'dead'}
case REQUIREMENT_KEY.CLUB_ID:{const clubs=ids(values)
return clubs?{clubs}:'dead'}
case REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS:
case REQUIREMENT_KEY.PLAYER_TRADABILITY:return null
default:return null}}
const add=(cls,slots)=>{if(cls===null)return
const key=JSON.stringify(Object.entries(cls).sort(([a],[b])=>a<b?-1:1))
const demand=isNum(slots)&&slots>0?slots:0
const held=classes.get(key)
if(held===undefined)classes.set(key,{...cls,slots:demand})
else held.slots+=demand}
for(const req of Array.isArray(parsedRequirements)?parsedRequirements:[]){
if(Array.isArray(req?.combined)){let merged={}
for(const entry of req.combined){const part=partOf(entry?.key,entry?.value,entry?.value===undefined?null:[entry.value],COMPARE.EXACT)
if(part==='dead'||(part===null&&entry?.key!==REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS&&entry?.key!==REQUIREMENT_KEY.PLAYER_TRADABILITY)){merged=null
break}
if(part===null)continue
for(const [field,value] of Object.entries(part)){if(merged[field]===undefined){merged[field]=value
continue}
if(Array.isArray(merged[field])&&Array.isArray(value))merged[field]=ids(merged[field].concat(value))
else if(field==='minRating')merged[field]=Math.max(merged[field],value)
else if(field==='maxRating')merged[field]=Math.min(merged[field],value)
else if(merged[field]!==value){merged=null}
if(merged===null)break}
if(merged===null)break}
if(merged!==null&&Object.keys(merged).length>0)add(merged,req?.count)
continue}
const part=partOf(req?.key,req?.value,Array.isArray(req?.values)&&req.values.length>0?req.values:(isNum(req?.value)?[req.value]:null),req?.compare)
if(part!=='dead')add(part,req?.count)}
return[...classes.values()]}
export function classCoversCard(card,cls,prices){if(!cls||typeof cls!=='object')return false
let checked=false
const rarity=rarityOf(card)
const rating=Number(card?.rating)
if(Array.isArray(cls.rarities)){checked=true
if(!cls.rarities.includes(rarity))return false}
if(Array.isArray(cls.rarityGroups)){checked=true
const groups=prices?.rarityGroups?.[rarity]
if(!Array.isArray(groups)||!cls.rarityGroups.some((g)=>groups.includes(g)))return false}
if(isNum(cls.minRating)){checked=true
if(!Number.isFinite(rating)||rating<cls.minRating)return false}
if(isNum(cls.exactRating)){checked=true
if(rating!==cls.exactRating)return false}
if(isNum(cls.maxRating)){checked=true
if(!Number.isFinite(rating)||rating>cls.maxRating)return false}
if(isNum(cls.tier)){checked=true
if(tierOf(card)!==cls.tier)return false}
if(Array.isArray(cls.leagues)){checked=true
if(!cls.leagues.includes(leagueOf(card)))return false}
if(Array.isArray(cls.nations)){checked=true
if(!cls.nations.includes(nationOf(card)))return false}
if(Array.isArray(cls.clubs)){checked=true
if(!cls.clubs.includes(clubOf(card)))return false}
return checked}
export function classPrice(cls,prices){if(!cls||typeof cls!=='object')return null
const stepFits=(rating)=>{if(!isNum(rating))return false
if(isNum(cls.minRating)&&rating<cls.minRating)return false
if(isNum(cls.exactRating)&&rating!==cls.exactRating)return false
if(isNum(cls.maxRating)&&rating>cls.maxRating)return false
if(isNum(cls.tier)&&tierOf({rating})!==cls.tier)return false
return true}
let best=null
const take=(price)=>{if(isNum(price)&&(best===null||price<best))best=price}
const bounded=(ladder)=>{if(!Array.isArray(ladder))return
for(const step of ladder){if(stepFits(step?.rating))take(step?.price)}}
if(Array.isArray(cls.rarities)&&cls.rarities.length>0){for(const id of cls.rarities){const flat=prices?.byRarity?.[id]
if(isNum(flat))take(flat)
else bounded(prices?.rarityLadders?.[id])}
return best}
if(Array.isArray(cls.rarityGroups)&&cls.rarityGroups.length>0){const dict=prices?.rarityGroups
if(dict===null||dict===undefined||typeof dict!=='object')return null
for(const [flag,groups] of Object.entries(dict)){if(!Array.isArray(groups)||!groups.some((g)=>cls.rarityGroups.includes(g)))continue
const flat=prices?.byRarity?.[flag]
if(isNum(flat))take(flat)
else bounded(prices?.rarityLadders?.[flag])}
return best}
if(Array.isArray(cls.leagues)&&cls.leagues.length>0){for(const id of cls.leagues)bounded(prices?.leagueLadders?.[id])
return best}
if(Array.isArray(cls.nations)&&cls.nations.length>0){for(const id of cls.nations)bounded(prices?.nationLadders?.[id])
return best}
if(Array.isArray(cls.clubs)&&cls.clubs.length>0){for(const id of cls.clubs)bounded(prices?.clubLadders?.[id])
return best}
if(isNum(cls.minRating)&&cls.exactRating===undefined&&cls.maxRating===undefined&&cls.tier===undefined)return mergedPriceAt(prices,cls.minRating,false)
if(isNum(cls.exactRating)||isNum(cls.maxRating)||isNum(cls.tier)){for(const rung of cachedFutureRungs(prices,false)??[])if(stepFits(rung?.rating))take(rungFloor(rung))
return best}
return null}
export const FUTURE_RATING_FLOOR=83
export const FUTURE_RATING_CEILING=94
const FUTURE_TRIES=200
const FUTURE_COST_CACHE=new WeakMap()
function futureThresholds(ctx){const set=new Set()
for(let x=FUTURE_RATING_FLOOR;x<=FUTURE_RATING_CEILING;x+=1)set.add(x)
for(const value of Array.isArray(ctx?.futureRatings)?ctx.futureRatings:[]){const x=Math.round(Number(value))
if(Number.isFinite(x)&&x>=60&&x<=99)set.add(x)}
return set}
function knownCopiesOf(step,prices){const seen=prices===null?0:prices.length
if(isNum(step?.count)&&step.count>seen)return Math.floor(step.count)
return seen>0?seen:null}
function ladderRungsOf(ladder,raw){const byRating=new Map()
for(const step of Array.isArray(ladder)?ladder:[]){if(!isNum(step?.rating))continue
let prices=null
if(Array.isArray(step.picks)){prices=[]
for(const pick of step.picks)if(isNum(pick?.price)&&pick.price>0)prices.push(pick.price)
if(prices.length===0)prices=null
else if(raw!==true&&isNum(step.price)&&step.price>0)prices=[step.price,...prices.slice(1)]}
const flat=isNum(step?.price)&&step.price>0?step.price:null
if(prices===null&&flat===null)continue
const entry={rating:step.rating,price:flat,prices,copies:knownCopiesOf(step,prices)}
const held=byRating.get(step.rating)
const entryFloor=prices?prices[0]:flat
const heldFloor=held===undefined?null:(held.prices?held.prices[0]:held.price)
if(heldFloor===null||entryFloor<heldFloor)byRating.set(step.rating,entry)}
return[...byRating.values()].sort((a,b)=>a.rating-b.rating)}
function squadLadderCost(rungs,x){if(!Array.isArray(rungs)||rungs.length===0)return null
const taken=rungs.map(()=>0)
const nextPrice=(i)=>{const rung=rungs[i]
if(rung.prices)return taken[i]<rung.prices.length?rung.prices[taken[i]]:null
return rung.price}
const lastPrice=(i)=>{const rung=rungs[i]
return rung.prices?rung.prices[taken[i]-1]:rung.price}
const bought=[]
for(let s=0;s<FIELD_PLAYERS;s+=1){let best=-1
let bestPrice=null
for(let i=0;i<rungs.length;i+=1){const price=nextPrice(i)
if(price===null)continue
if(bestPrice===null||price<bestPrice){bestPrice=price
best=i}}
if(best<0)return null
taken[best]+=1
bought.push(best)}
for(let guard=0;guard<FUTURE_TRIES;guard+=1){
if(squadRatingBounds({field:bought.map((i)=>rungs[i].rating)}).rating>=x)return bought.map((i,b)=>({rating:rungs[i].rating,price:priceOfCopy(rungs,taken,bought,b)}))
let low=-1
for(let b=0;b<bought.length;b+=1)if(low<0||rungs[bought[b]].rating<rungs[bought[low]].rating)low=b
if(low<0)return null
const from=bought[low]
let move=-1
let moveRate=null
for(let i=0;i<rungs.length;i+=1){if(rungs[i].rating<=rungs[from].rating)continue
const price=nextPrice(i)
if(price===null)continue
const rate=(price-lastPrice(from))/(rungs[i].rating-rungs[from].rating)
if(moveRate===null||rate<moveRate){moveRate=rate
move=i}}
if(move<0)return null
taken[from]-=1
taken[move]+=1
bought[low]=move}
return null}
function priceOfCopy(rungs,taken,bought,b){const rung=rungs[bought[b]]
if(!rung.prices)return rung.price
let copy=0
for(let s=0;s<b;s+=1)if(bought[s]===bought[b])copy+=1
return rung.prices[copy]}
function cachedDearestBelow(ladder,rungs,x,raw){let map=FUTURE_COST_CACHE.get(ladder)
if(map===undefined){map=new Map()
FUTURE_COST_CACHE.set(ladder,map)}
const key=`${x}:${raw?1:0}`
if(!map.has(key)){const squad=squadLadderCost(rungs,x)
if(squad===null)map.set(key,null)
else{squad.sort((a,b)=>a.rating-b.rating)
let running=null
map.set(key,squad.map((member)=>{running=running===null||member.price>running?member.price:running
return{rating:member.rating,dearest:running}}))}}
const held=map.get(key)
return held===null?null:(rating)=>{let best=null
for(const member of held){if(member.rating>rating)break
best=member.dearest}
return best}}
const MERGE_MIN_COPIES=2
const DENSE_MIN=10
const GAP_X=10
let DROPPED_FLOORS=0
export function droppedFloorCount(){return DROPPED_FLOORS}
export function futureRungsOf(prices,raw){const merged=new Map()
const floorOf=(entry)=>entry.prices?entry.prices[0]:entry.price
const thin=(entry)=>Array.isArray(entry.prices)&&entry.prices.length<MERGE_MIN_COPIES
const base=ladderRungsOf(prices?.ladder,raw)
const dense=new Map()
for(const entry of base)if(isNum(entry.copies)&&entry.copies>=DENSE_MIN)dense.set(entry.rating,floorOf(entry))
const outvoted=(candidate,rating)=>{const floor=dense.get(rating)
return floor!==undefined&&isNum(candidate)&&candidate>0&&floor>=GAP_X*candidate}
const admit=(entry)=>{if(!Array.isArray(entry.prices)){if(!outvoted(entry.price,entry.rating))return entry
DROPPED_FLOORS+=1
return null}
let cut=0
while(cut<entry.prices.length&&outvoted(entry.prices[cut],entry.rating)){cut+=1
DROPPED_FLOORS+=1}
if(cut===0)return entry
return cut>=entry.prices.length?null:{...entry,prices:entry.prices.slice(cut)}}
const consider=(rungs,family)=>{for(const entry of rungs){let one=entry
if(family){if(thin(one))continue
one=admit(one)
if(one===null)continue}
const held=merged.get(one.rating)
if(held===undefined||floorOf(one)<floorOf(held))merged.set(one.rating,one)}}
consider(base,false)
const families=prices?.rarityLadders
if(families&&typeof families==='object')for(const key of Object.keys(families))consider(ladderRungsOf(families[key],raw),true)
return[...merged.values()].sort((a,b)=>a.rating-b.rating)}
const FAMILIES_KEY='families'
function cachedFutureRungs(prices,raw){const ladder=prices?.ladder
if(!Array.isArray(ladder)||ladder.length===0)return null
const families=prices?.rarityLadders
let map=FUTURE_COST_CACHE.get(ladder)
if(map===undefined||map.get(FAMILIES_KEY)!==families){map=new Map()
map.set(FAMILIES_KEY,families)
FUTURE_COST_CACHE.set(ladder,map)}
const key=`rungs:${raw?1:0}`
if(!map.has(key))map.set(key,futureRungsOf(prices,raw))
return map.get(key)}
function rungFloor(rung){const floor=rung?.prices?rung.prices[0]:rung?.price
return isNum(floor)&&floor>0?floor:null}
function mergedPriceAt(prices,rating,raw){if(!isNum(rating))return null
const rungs=cachedFutureRungs(prices,raw)
if(rungs===null)return null
let floor=null
for(const rung of rungs){if(rung.rating<rating)continue
const bottom=rungFloor(rung)
if(bottom!==null&&(floor===null||bottom<floor))floor=bottom}
return floor}
function futureFloorOf(card,prices,raw,future){const rating=Math.round(Number(card?.rating))
if(!Number.isFinite(rating)||rating<=0)return null
const rungs=cachedFutureRungs(prices,raw)
if(rungs===null||rungs.length===0)return null
if(future===null)return null
const top=rungFloor(rungs[rungs.length-1])
return{cost:top!==null&&top>future?top:future,path:'future'}}
function futurePriceOf(card,prices,ctx,raw){const rating=Math.round(Number(card?.rating))
if(!Number.isFinite(rating)||rating<=0)return null
const ladder=prices?.ladder
const rungs=cachedFutureRungs(prices,raw)
if(rungs===null||rungs.length===0)return null
let best=null
for(const x of futureThresholds(ctx)){const dearestBelow=cachedDearestBelow(ladder,rungs,x,raw)
if(dearestBelow===null)continue
const displaced=dearestBelow(rating)
if(isNum(displaced)&&displaced>0&&(best===null||displaced>best))best=displaced}
if(best!==null){for(const rung of rungs){if(rung.rating<rating)continue
const cap=rung.prices?rung.prices[rung.prices.length-1]:rung.price
if(isNum(cap)&&cap<best)best=cap
break}}
return best}
function stockFactorOf(cls){const demand=isNum(cls?.slots)&&cls.slots>0?cls.slots:null
const supply=isNum(cls?.supply)&&cls.supply>0?cls.supply:null
if(demand===null||supply===null||supply<=demand)return 1
return demand/supply}
export const DUPLICATE_DISCOUNT=0.1
function dearestLadderPrice(ladder){let best=null
for(const step of Array.isArray(ladder)?ladder:[]){if(!isNum(step?.rating)||!isNum(step?.price))continue
if(best===null||step.price>best)best=step.price}
return best}
export const RARE_PREMIUM=1.5
export const RUNG_TRUST=3
export function burnCostOf(card,prices,ctx={}){return explainBurnOf(card,prices,ctx).cost}
export function explainBurnOf(card,prices,ctx={}){
if(card?.virtual===true)return isNum(card.buyPrice)&&card.buyPrice>0?{cost:card.buyPrice,path:'buy',future:null}:{cost:Number.POSITIVE_INFINITY,path:'unknown',future:null}
const untradeable=tradabilityOf(card)==='untradeable'
if(!untradeable&&ctx.__replacementView!==true){
const price=typeof ctx.priceOf==='function'?safePrice(ctx.priceOf,card):null
const known=price??(isNum(card?.lastSalePrice)?card.lastSalePrice:null)
const net=netSaleOf(known)
return net===null?{cost:Number.POSITIVE_INFINITY,path:'unknown',future:null}:{cost:net,path:'sale',gross:known,future:null}}
const raw=ctx.__searchRaw===true
const mergedRung=mergedPriceAt(prices,Number(card?.rating),raw)
let cost=mergedRung
let path=cost===null?'unknown':'ladder'
const aboveLadder=cost===null
const future=futurePriceOf(card,prices,ctx,raw)
if(aboveLadder){const floor=futureFloorOf(card,prices,raw,future)
if(floor!==null){cost=floor.cost
path=floor.path}}
const rarity=rarityOf(card)
const notCommon=isNum(rarity)&&rarity>=1
if(notCommon){
const judgeable=Array.isArray(ctx.classes)&&ctx.classes.length>0
&&prices?.rarityGroups!==null&&typeof prices?.rarityGroups==='object'
&&Array.isArray(prices.rarityGroups[rarity])
if(!judgeable){
const ownLadder=prices?.rarityLadders?.[rarity]
let own=ladderPriceAt(ownLadder,Number(card?.rating),{raw})
if(own===null&&aboveLadder)own=dearestLadderPrice(ownLadder)
if(own!==null){if(cost===null||own>=cost)path='rarity-ladder'
cost=cost===null?own:Math.max(cost,own)}
else if(cost!==null){cost=Math.round(cost*RARE_PREMIUM)
path='rare-premium'}}}
let classLive=false
for(const cls of Array.isArray(ctx.classes)?ctx.classes:[]){if(!classCoversCard(card,cls,prices))continue
const price=classPrice(cls,prices)
if(!isNum(price))continue
classLive=true
const stock=stockFactorOf(cls)
const held=stock<1?Math.max(1,Math.round(price*stock)):price
if(cost===null||held>cost){cost=held
path=held<price?'class-surplus':'class'}}
if(classLive&&mergedRung!==null&&ctx.__noRarityFloor!==true){const ownRung=ladderPriceAt(prices?.rarityLadders?.[rarity],Number(card?.rating))
const shownRung=raw?mergedPriceAt(prices,Number(card?.rating),false):mergedRung
if(ownRung!==null&&shownRung!==null){const floor=Math.min(ownRung,RUNG_TRUST*shownRung)
if(cost===null||floor>cost){cost=floor
path='rarity-floor'}}}
const beats=untradeable?future>cost:future>=cost*SELL_SWAP_ADVANTAGE
if(future!==null&&cost!==null&&path!=='future'&&beats){cost=future
path='future'}
const duplicate=typeof ctx.isDuplicate==='function'&&ctx.isDuplicate(card)===true
if(duplicate){
if(cost===null)return{cost:Number.POSITIVE_INFINITY,path:'duplicate',of:'unknown',future}
return{cost:Math.max(1,Math.round(cost*(1-DUPLICATE_DISCOUNT))),path:'duplicate',of:path,future}}
return cost===null?{cost:Number.POSITIVE_INFINITY,path:'unknown',future}:{cost,path,future}}
function safePrice(priceOf,card){try{const price=priceOf(card)
return isNum(price)&&price>0?price:null}catch{return null}}
export const REPLACEMENT_DISCOUNT=EA_TAX_RATE
const REPLACEMENT_PATHS=new Set(['ladder','rarity-ladder','rare-premium','class','class-surplus','rarity-floor','future','duplicate'])
export const SELL_SWAP_ADVANTAGE=2
export function searchBurnOf(card,prices,ctx={}){const explained=explainBurnOf(card,prices,{...ctx,__searchRaw:true})
if(explained.path==='sale'){
const replacement=explainBurnOf(card,prices,{...ctx,__searchRaw:true,__replacementView:true})
if(Number.isFinite(replacement.cost)&&REPLACEMENT_PATHS.has(replacement.path)&&explained.cost<replacement.cost*SELL_SWAP_ADVANTAGE){return Math.min(explained.cost,Math.max(1,Math.round(replacement.cost*(1-REPLACEMENT_DISCOUNT))))}
return explained.cost}
if(!Number.isFinite(explained.cost)||!REPLACEMENT_PATHS.has(explained.path))return explained.cost
return Math.max(1,Math.round(explained.cost*(1-REPLACEMENT_DISCOUNT)))}
export function virtualBuysFrom(prices,opts={}){const copies=isNum(opts.copies)&&opts.copies>0?Math.min(Math.floor(opts.copies),11):11
const out=[]
const linkedTeam=typeof opts.linkedTeam==='function'?opts.linkedTeam:undefined
const bucketBuys=bucketCandidates(prices,opts.requirements,{copies,linkedTeam})
const covered={leagueId:new Set(),nationId:new Set(),teamId:new Set()}
for(const one of bucketBuys){covered.leagueId.add(one.leagueId)
covered.nationId.add(one.nationId)
covered.teamId.add(one.teamId)}
const emit=(step,key,extra)=>{const picks=Array.isArray(step.picks)?step.picks:null
const total=picks?Math.min(copies,picks.length):copies
for(let copy=0;copy<total;copy+=1){let price=step.price
let attrs=step.attrs
if(picks){const pick=picks[copy]
if(!pick||!isNum(pick.price)||pick.price<=0)continue
price=pick.price
attrs=pick.attrs}
out.push({id:`buy:${key}:${copy}`,virtual:true,isPlayer:()=>true,rating:step.rating,buyPrice:price,
lastSalePrice:price,tradable:true,...(attrs&&typeof attrs==='object'?attrs:{}),...extra})}}
for(const step of Array.isArray(prices?.ladder)?prices.ladder:[]){if(!isNum(step?.rating)||!isNum(step?.price)||step.price<=0)continue
emit(step,String(step.rating),{})}
const dictionary=prices?.rarityGroups&&typeof prices.rarityGroups==='object'?prices.rarityGroups:null
for(const rarity of neededRarities(opts.requirements,dictionary)){const ladder=prices?.rarityLadders?.[rarity]
if(!Array.isArray(ladder))continue
const known=Array.isArray(dictionary?.[rarity])?dictionary[rarity].filter(isNum):[]
for(const step of ladder){if(!isNum(step?.rating)||!isNum(step?.price)||step.price<=0)continue
emit(step,`r${rarity}:${step.rating}`,known.length>0?{rareflag:rarity,groups:[...known]}:{rareflag:rarity})}}
for(const dim of IDENTITY_BUYS){const ladders=prices?.[dim.prop]
if(!ladders||typeof ladders!=='object')continue
const wide=dim.key===REQUIREMENT_KEY.CLUB_ID&&linkedTeam!==undefined
for(const[value,combinedOnly] of neededIdentity(opts.requirements,dim.key)){
const says=identitySaysOf(dim.key,linkedTeam,combinedOnly)
for(const raw of wide?laddersFor(ladders,value,says):(Array.isArray(ladders[value])?[value]:[])){
if(covered[dim.field].has(raw))continue
for(const step of ladders[raw]){if(!isNum(step?.rating)||!isNum(step?.price)||step.price<=0)continue
emit(step,`${dim.tag}${raw}:${step.rating}`,{[dim.field]:raw})}}}}
for(const one of bucketBuys)out.push(one)
return out}
function laddersFor(ladders,value,says){const out=[]
if(Array.isArray(ladders[value])&&says(value,value))out.push(value)
for(const key of Object.keys(ladders)){const raw=Number(key)
if(!isNum(raw)||raw===value||!Array.isArray(ladders[key]))continue
if(says(raw,value))out.push(raw)}
return out}
const IDENTITY_BUYS=[
{key:REQUIREMENT_KEY.LEAGUE_ID,prop:'leagueLadders',field:'leagueId',tag:'l'},
{key:REQUIREMENT_KEY.NATION_ID,prop:'nationLadders',field:'nationId',tag:'n'},
{key:REQUIREMENT_KEY.CLUB_ID,prop:'clubLadders',field:'teamId',tag:'c'}]
function neededIdentity(requirements,key){const out=new Map()
const add=(value,combined)=>{if(!isNum(value)||value<=0)return
out.set(value,(out.get(value)??true)&&combined)}
for(const req of Array.isArray(requirements)?requirements:[]){if(req?.key===key)for(const value of Array.isArray(req.values)?req.values:[])add(value,false)
for(const entry of Array.isArray(req?.combined)?req.combined:[])if(entry?.key===key)add(entry.value,true)}
return out}
const identitySaysOf=(key,linkedTeam,combinedOnly)=>{if(key!==REQUIREMENT_KEY.CLUB_ID||typeof linkedTeam!=='function')return(raw,value)=>raw===value
if(combinedOnly===true)return(raw,value)=>linkedClubOf({teamId:raw},linkedTeam)===value
return(raw,value)=>{const club=linkedClubOf({teamId:raw},linkedTeam)
return club===value||club===linkedClubOf({teamId:value},linkedTeam)}}
function neededRarities(requirements,rarityGroups){const out=new Set()
for(const req of Array.isArray(requirements)?requirements:[]){if(req?.key===REQUIREMENT_KEY.PLAYER_RARITY){for(const value of Array.isArray(req.values)?req.values:[])if(isNum(value))out.add(value)}
if(req?.key===REQUIREMENT_KEY.PLAYER_RARITY_GROUP&&rarityGroups){const wanted=Array.isArray(req.values)?req.values:[]
for(const key of Object.keys(rarityGroups)){const rarity=Number(key)
if(!Number.isSafeInteger(rarity)||rarity<0)continue
const member=Array.isArray(rarityGroups[key])?rarityGroups[key]:[]
if(member.some((group)=>wanted.includes(group)))out.add(rarity)}}}
return out}
export const CLUSTER_LEAGUES=3
export const CLUSTER_NATIONS=3
export const CLUSTER_CLUBS=3
export const LEAGUE_RANK=8
export const NATION_RANK=8
export const CLUB_RANK=4
export const BUCKET_RUNG_KEEP=3
export const BUCKET_COPIES=2
const BUCKET_FLOOR_DEPTH=10
const NAMELESS_KEYS=new Set([REQUIREMENT_KEY.CHEMISTRY_POINTS,REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS,REQUIREMENT_KEY.SAME_LEAGUE_COUNT,REQUIREMENT_KEY.SAME_NATION_COUNT,REQUIREMENT_KEY.SAME_CLUB_COUNT,REQUIREMENT_KEY.LEAGUE_COUNT,REQUIREMENT_KEY.NATION_COUNT,REQUIREMENT_KEY.CLUB_COUNT])
export const BUCKET_KEYS=new Set([...NAMELESS_KEYS,REQUIREMENT_KEY.LEAGUE_ID,REQUIREMENT_KEY.NATION_ID,REQUIREMENT_KEY.CLUB_ID])
const BUCKET_DIMS=[
{prop:'leagueId',plan:'leagues',clusters:CLUSTER_LEAGUES,rank:LEAGUE_RANK,idKey:REQUIREMENT_KEY.LEAGUE_ID,sameKey:REQUIREMENT_KEY.SAME_LEAGUE_COUNT,countKey:REQUIREMENT_KEY.LEAGUE_COUNT},
{prop:'nationId',plan:'nations',clusters:CLUSTER_NATIONS,rank:NATION_RANK,idKey:REQUIREMENT_KEY.NATION_ID,sameKey:REQUIREMENT_KEY.SAME_NATION_COUNT,countKey:REQUIREMENT_KEY.NATION_COUNT},
{prop:'teamId',plan:'clubs',clusters:CLUSTER_CLUBS,rank:CLUB_RANK,idKey:REQUIREMENT_KEY.CLUB_ID,sameKey:REQUIREMENT_KEY.SAME_CLUB_COUNT,countKey:REQUIREMENT_KEY.CLUB_COUNT}]
const isId=(value)=>isNum(value)&&value>0
function requirementsHave(requirements,keys){for(const req of Array.isArray(requirements)?requirements:[]){if(keys.has(req?.key))return true
for(const entry of Array.isArray(req?.combined)?req.combined:[])if(keys.has(entry?.key))return true}
return false}
export function topNeed(requirements,key,min){let best=null
for(const req of Array.isArray(requirements)?requirements:[]){if(req?.key!==key||req.compare===COMPARE.LOWER)continue
const need=needOf(req)
if(isNum(need)&&need>=min&&(best===null||need>best))best=need}
return best}
function bucketsOf(prices){const out=[]
for(const raw of Array.isArray(prices?.buckets)?prices.buckets:[]){if(!isNum(raw?.rating)||raw.rating<=0)continue
if(!isNum(raw?.rareflag)||raw.rareflag<0)continue
if(!isId(raw?.leagueId)||!isId(raw?.nationId)||!isId(raw?.teamId))continue
const picks=Array.isArray(raw.picks)?raw.picks:[]
const good=[]
for(let i=0;i<picks.length;i+=1){const price=picks[i]?.price
if(isNum(price)&&price>0)good.push(i)}
if(good.length===0)continue
out.push({raw,picks,good,floor:picks[good[0]].price})}
return out}
function compareBuckets(a,b){for(const field of ['leagueId','nationId','teamId','rareflag'])if(a.raw[field]!==b.raw[field])return a.raw[field]-b.raw[field]
return 0}
function bucketPlan(prices,requirements,opts={}){const copies=isNum(opts?.copies)&&opts.copies>0?Math.min(Math.floor(opts.copies),11):11
const linkedTeam=typeof opts?.linkedTeam==='function'?opts.linkedTeam:undefined
const buckets=bucketsOf(prices)
const plan={spoke:false,leagues:[],nations:[],clubs:[],picked:[],candidates:0}
if(buckets.length===0||!requirementsHave(requirements,BUCKET_KEYS))return plan
plan.spoke=true
const rating=topNeed(requirements,REQUIREMENT_KEY.TEAM_RATING,1)
const floor=rating===null?null:rating-BUCKET_FLOOR_DEPTH
const nameless=requirementsHave(requirements,NAMELESS_KEYS)
const kept=new Set()
let cap=BUCKET_COPIES
for(const dim of BUCKET_DIMS){const same=topNeed(requirements,dim.sameKey,2)
if(same!==null&&same>cap)cap=same
const chosen=new Map(neededIdentity(requirements,dim.idKey))
if(nameless)for(const value of rankedValues(buckets,dim,floor,same??dim.rank,dim.clusters))chosen.set(value,false)
plan[dim.plan]=[...chosen.keys()].sort((a,b)=>a-b)
for(const[value,combinedOnly] of chosen)keepCluster(buckets,dim,value,kept,identitySaysOf(dim.idKey,linkedTeam,combinedOnly))
const diverse=topNeed(requirements,dim.countKey,2)
if(diverse!==null)for(const one of diverseBuckets(buckets,dim,diverse))kept.add(one)}
cap=Math.min(cap,copies)
for(const one of buckets){if(!kept.has(one))continue
const list=one.good.filter((index)=>index<cap)
if(list.length===0)continue
plan.picked.push({bucket:one,copies:list})
plan.candidates+=list.length}
return plan}
function rankedValues(buckets,dim,floor,size,limit){const by=new Map()
for(const one of buckets){if(floor!==null&&one.raw.rating<floor)continue
const value=one.raw[dim.prop]
let list=by.get(value)
if(list===undefined){list=[]
by.set(value,list)}
for(const index of one.good)list.push(one.picks[index].price)}
const scored=[]
for(const[value,list]of by){if(list.length<size)continue
list.sort((a,b)=>a-b)
let sum=0
for(let i=0;i<size;i+=1)sum+=list[i]
scored.push({value,sum})}
scored.sort((a,b)=>a.sum!==b.sum?a.sum-b.sum:a.value-b.value)
return scored.slice(0,limit).map((one)=>one.value)}
function keepCluster(buckets,dim,value,kept,says){const rungs=new Map()
for(const one of buckets){if(!says(one.raw[dim.prop],value))continue
const list=rungs.get(one.raw.rating)
if(list===undefined)rungs.set(one.raw.rating,[one])
else list.push(one)}
for(const list of rungs.values()){list.sort((a,b)=>a.floor!==b.floor?a.floor-b.floor:compareBuckets(a,b))
for(const one of list.slice(0,BUCKET_RUNG_KEEP))kept.add(one)}}
function diverseBuckets(buckets,dim,need){const best=new Map()
for(const one of buckets){const value=one.raw[dim.prop]
const held=best.get(value)
if(held===undefined||one.floor<held.floor||(one.floor===held.floor&&compareBuckets(one,held)<0))best.set(value,one)}
return[...best.values()].sort((a,b)=>a.floor!==b.floor?a.floor-b.floor:a.raw[dim.prop]-b.raw[dim.prop]).slice(0,need)}
function bucketCandidates(prices,requirements,opts){const out=[]
for(const{bucket,copies} of bucketPlan(prices,requirements,opts).picked){const raw=bucket.raw
for(const copy of copies){const pick=bucket.picks[copy]
out.push({...(pick.attrs&&typeof pick.attrs==='object'?pick.attrs:{}),
id:`buy:g${raw.leagueId}.${raw.nationId}.${raw.teamId}.${raw.rating}.${raw.rareflag}:${copy}`,
virtual:true,isPlayer:()=>true,rating:raw.rating,rareflag:raw.rareflag,
leagueId:raw.leagueId,nationId:raw.nationId,teamId:raw.teamId,
buyPrice:pick.price,lastSalePrice:pick.price,tradable:true})}}
return out}
export function bucketPlanOf(prices,requirements,opts={}){const plan=bucketPlan(prices,requirements,opts)
return{spoke:plan.spoke,leagues:plan.leagues,nations:plan.nations,clubs:plan.clubs,buckets:plan.picked.length,candidates:plan.candidates}}
