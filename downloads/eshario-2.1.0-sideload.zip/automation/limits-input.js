import{LIMIT_KEYS} from './stop-conditions.js'
export const LIMIT_FIELDS=Object.freeze([{key:'minCoins',labelKey:'automation.limit.minCoins',scale:1,unitKey:null},{key:'maxSpend',labelKey:'automation.limit.maxSpend',scale:1,unitKey:null},{key:'maxLossCoins',labelKey:'automation.limit.maxLossCoins',scale:1,unitKey:null},{key:'maxPurchases',labelKey:'automation.limit.maxPurchases',scale:1,unitKey:null},{key:'maxActions',labelKey:'automation.limit.maxActions',scale:1,unitKey:null},{key:'maxSearches',labelKey:'automation.limit.maxSearches',scale:1,unitKey:null},{key:'maxDurationMs',labelKey:'automation.limit.maxDuration',scale:60_000,unitKey:'automation.limit.minutes'}].map(Object.freeze))
const SEPARATORS=/[\s  ,']/g
const FRACTION_SEPARATORS=/[\s  ']/g
export function parseLimitInput(text,opts={}){const fraction=opts?.fraction===true
if(text===null||text===undefined)return{ok:true,value:null,reason:null}
if(typeof text==='number'){return Number.isFinite(text)&&text>=0
?{ok:true,value:text,reason:null}
:{ok:false,value:null,reason:'not-a-number'}}
if(typeof text!=='string') return{ok:false,value:null,reason:'not-a-number'}
const cleaned=text.replace(fraction?FRACTION_SEPARATORS:SEPARATORS,'')
if(cleaned==='') return{ok:true,value:null,reason:null}
const said=fraction?cleaned.replace(',','.'):cleaned
const shape=fraction?/^\d+(\.\d{1,2})?$/:/^\d+$/
if(!shape.test(said)){
return{ok:false,value:null,reason:/^-\d+$/.test(cleaned)?'negative':'not-a-number'}}
const value=Number(said)
if(!Number.isFinite(value)) return{ok:false,value:null,reason:'not-a-number'}
if(!Number.isSafeInteger(Math.round(value))) return{ok:false,value:null,reason:'too-big'}
return{ok:true,value,reason:null}}
export const SAFE_LIMIT_DEFAULTS=Object.freeze({maxActions:45,maxDurationMs:16*60_000})
export function parseLimits(input={},opts={}){const limits={}
const errors=[]
const defaults=opts?.defaults===null?{}:(opts?.defaults??SAFE_LIMIT_DEFAULTS)
for(const field of LIMIT_FIELDS){const raw=input?.[field.key]
const parsed=parseLimitInput(raw,{fraction:field.scale>1})
if(!parsed.ok){errors.push({key:field.key,reason:parsed.reason})
continue}
if(parsed.value!==null){limits[field.key]=Math.round(parsed.value*field.scale)
continue}
if(Object.hasOwn(defaults,field.key))limits[field.key]=defaults[field.key]}
return{limits,errors}}
export function limitsToInput(limits={}){const out={}
for(const field of LIMIT_FIELDS){const value=limits?.[field.key]
out[field.key]=typeof value==='number'&&Number.isFinite(value)
?String(value / field.scale)
:''
}
return out}
export const COVERS_ALL_LIMITS=LIMIT_FIELDS.length===LIMIT_KEYS.length;
