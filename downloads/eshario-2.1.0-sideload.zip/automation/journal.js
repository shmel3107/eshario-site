import{createCachedProvider} from '../core/storage-provider.js'
export const JOURNAL_LIMIT=200
export const JOURNAL_KEY='automation.journal'
export const JOURNAL_READ='journal.read'
export const JOURNAL_WRITE='journal.write'
export const FLUSH_EVERY=20
export const FLUSH_AFTER_MS=10_000
export function sanitizeJournal(stored){if(!Array.isArray(stored))return[]
const out=[]
for(const raw of stored){const entry=sanitizeEntry(raw)
if(entry===null)return[]
out.push(entry)}
return out.slice(Math.max(0,out.length-JOURNAL_LIMIT))}
function sanitizeEntry(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw)) return null
if(typeof raw.event!=='string'||raw.event==='') return null
if(typeof raw.source!=='string'||raw.source==='') return null
if(!Number.isFinite(raw.at))return null
if(!Number.isFinite(raw.seq)||raw.seq<=0)return null
if(!Number.isFinite(raw.count)||raw.count<1)return null
if(raw.item!==null&&typeof raw.item!=='string') return null
if(raw.detail!==null&&typeof raw.detail!=='string') return null
if(raw.price!==null&&!(typeof raw.price==='number'&&Number.isFinite(raw.price)&&raw.price>0)) return null
return{seq:Math.floor(raw.seq),at:raw.at,source:raw.source,event:raw.event,item:raw.item,price:raw.price,detail:raw.detail,count:Math.floor(raw.count)}}
export function createBridgeJournalProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function') throw new Error('journal: мост недоступен')
return createCachedProvider({fetch:()=>bridge.request(JOURNAL_READ),push:(value)=>bridge.request(JOURNAL_WRITE,value),sanitize:sanitizeJournal,fallback:()=>[],onError:opts.onError})}
export const BUYER='buyer'
export const SELLER='seller'
export function itemLabel(item){if(!item||typeof item!=='object') return null
const raw=item.displayName??item.name??item.commonName
const name=typeof raw==='string'&&raw.trim()!==''?raw.trim():null
const rating=Number(item.rating)
if(name===null)return Number.isFinite(rating)&&rating>0?String(rating):null
return Number.isFinite(rating)&&rating>0?`${name} ${rating}`:name}
function priceOf(payload){const value=payload?.price
return typeof value==='number'&&Number.isFinite(value)&&value>0?value:null}
function detailOf(event,payload){if(event==='failure'){const stage=payload?.stage?String(payload.stage):null
const category=payload?.category?String(payload.category):null
if(stage&&category) return `${stage}: ${category}`
return category??stage}
if(event==='stopped') return payload?.reason?String(payload.reason):null
if(event==='moved') return payload?.pile===undefined||payload?.pile===null?null:String(payload.pile)
if(event==='relisted'||event==='cleared'){return Number.isFinite(payload?.count)?String(payload.count):null}
if(event==='planned'){return Number.isFinite(payload?.plan)?String(payload.plan):null}
if(event==='would-sell'||event==='listed'||event==='quick-sold'){return payload?.action?String(payload.action):null}
return null}
export function createJournal(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('journal: нужны часы (правило 6 NIGHT_BRIEF)')}
const limit=Number.isFinite(deps.limit)&&deps.limit>0?Math.floor(deps.limit):JOURNAL_LIMIT
const provider=deps.provider??null
const flushEvery=Number.isFinite(deps.flushEvery)&&deps.flushEvery>0
?Math.floor(deps.flushEvery):FLUSH_EVERY
const flushAfterMs=Number.isFinite(deps.flushAfterMs)&&deps.flushAfterMs>=0
?deps.flushAfterMs:FLUSH_AFTER_MS
let entries=[]
let seq=0
let pending=0
let flushedAt=clock.now()
if(provider){try{entries=sanitizeJournal(provider.read())}catch{entries=[]}
if(entries.length>limit)entries.splice(0,entries.length-limit)
for(const entry of entries)if(entry.seq>seq)seq=entry.seq}
function flush(){pending=0
flushedAt=clock.now()
if(!provider)return false
try{provider.write(entries.map((e)=>({...e})))
return true}catch{
return false}}
function maybeFlush(event){if(!provider)return
pending+=1
if(event==='stopped'||pending>=flushEvery||clock.now()-flushedAt>=flushAfterMs){flush()}}
const copy=(entry)=>({...entry})
const same=(a,b)=>a.source===b.source&&a.event===b.event
&&a.item===b.item&&a.price===b.price&&a.detail===b.detail
function collapseTail(){if(entries.length<2)return
const last=entries[entries.length-1]
const prev=entries[entries.length-2]
if(!same(last,prev))return
prev.count+=last.count
prev.at=last.at
entries.pop()}
function push(entry){entries.push(entry)
collapseTail()
if(entries.length>limit)entries.splice(0,entries.length-limit)
return entry}
function record(source,event,payload){if(typeof event!=='string'||event==='') return null
const at=clock.now()
if(event==='found'){const last=entries[entries.length-1]
if(last&&last.source===source&&last.event==='search'&&last.detail===null){const total=Number.isFinite(payload?.total)?payload.total:0
const affordable=Number.isFinite(payload?.affordable)?payload.affordable:0
last.detail=`${affordable}/${total}`
last.at=at
collapseTail()
maybeFlush(event)
return null}}
seq+=1
const entry=push({seq,at,source:String(source),event,item:itemLabel(payload?.item),price:priceOf(payload),detail:detailOf(event,payload),count:1})
maybeFlush(event)
return entry}
return{limit,
size:()=>entries.length,
clear(){entries=[];flush()},
flush,
pending:()=>pending,
record,
for(source){return{record:(event,payload)=>record(source,event,payload)}},
view(n){const take=Number.isFinite(n)&&n>0?Math.floor(n):entries.length
const shown=entries.slice(Math.max(0,entries.length-take))
return{now:clock.now(),total:entries.length,entries:shown.map(copy).reverse()}}}}
