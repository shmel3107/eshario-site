export const LIMIT_KEYS=Object.freeze(['maxPurchases','minCoins','maxSpend','maxLossCoins','maxActions','maxSearches','maxDurationMs'
])
export const CHECK_ORDER=Object.freeze(['minCoins','maxSpend','maxLossCoins','maxPurchases','maxActions','maxSearches','maxDurationMs'
])
const STATE_FIELD=Object.freeze({minCoins:'coins',maxSpend:'spent',maxLossCoins:'loss',maxPurchases:'purchases',maxActions:'actions',maxSearches:'searches',maxDurationMs:'startedAt'
})
const REASON=Object.freeze({minCoins:'out-of-coins',maxSpend:'spend-limit',maxLossCoins:'loss-limit',maxPurchases:'purchase-limit',maxActions:'action-limit',maxSearches:'search-limit',maxDurationMs:'time-limit'
})
const PURCHASE_PROJECTION=Object.freeze([{key:'minCoins',field:'coins',required:['coins'],reason:'out-of-coins',project:(state,price)=>state.coins-price,exceeds:(next,limit)=>next<limit},{key:'maxSpend',field:'spent',required:['spent'],reason:'spend-limit',project:(state,price)=>state.spent+price,exceeds:(next,limit)=>next>limit},{key:'maxLossCoins',field:'loss',required:['loss','spent','earned'],reason:'loss-limit',project:(state,price)=>Math.max(0,state.spent+price-state.earned),exceeds:(next,limit)=>next>limit}].map(Object.freeze))
const isCount=(value)=>typeof value==='number'&&Number.isFinite(value)&&value>=0
const isMoney=(value)=>Number.isSafeInteger(value)&&value>=0
const MONEY_LIMITS=Object.freeze(['minCoins','maxSpend','maxLossCoins'])
export function normalizeLimits(limits={}){if(limits===null||typeof limits!=='object'||Array.isArray(limits)){throw new Error('stop: лимиты должны быть объектом')}
const out={}
for(const[key,value]of Object.entries(limits)){if(!LIMIT_KEYS.includes(key)){throw new Error(`stop: неизвестный лимит «${key}»`)}
if(value===undefined||value===null)continue
if(!(MONEY_LIMITS.includes(key)?isMoney(value):isCount(value))){throw new Error(`stop: лимит «${key}» должен быть неотрицательным числом, а не ${JSON.stringify(value)}`)}
out[key]=value}
return out}
export function createStopConditions(limits={},deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('stop: нужны часы (правило 6 NIGHT_BRIEF)')}
const active=normalizeLimits(limits)
function shouldStop(state){
if(state&&state.captcha===true) return{stop:true,reason:'captcha'}
if(!state||typeof state!=='object'||Array.isArray(state)){return{stop:true,reason:'bad-state',detail:{field:null}}}
for(const key of CHECK_ORDER){if(!Object.hasOwn(active,key))continue
const field=STATE_FIELD[key]
const value=state[field]
if(!(MONEY_LIMITS.includes(key)?isMoney(value):isCount(value))){
return{stop:true,reason:'bad-state',detail:{field,limit:key}}}
const limit=active[key]
const hit=key==='minCoins'
?value<=limit
:(key==='maxDurationMs'?clock.now()-value>=limit:value>=limit)
if(hit){return{stop:true,reason:REASON[key],detail:key==='maxDurationMs'
?{limit,elapsed:clock.now()-value}
:{limit,value}}}}
return{stop:false,reason:null}}
function shouldStopBeforePurchase(state,price){if(!state||typeof state!=='object'||Array.isArray(state)){return{stop:true,reason:'bad-state',detail:{field:null}}}
if(!isMoney(price)){return{stop:true,reason:'bad-state',detail:{field:'purchasePrice'}}}
for(const rule of PURCHASE_PROJECTION){if(!Object.hasOwn(active,rule.key))continue
for(const field of rule.required){if(!isMoney(state[field])){return{stop:true,reason:'bad-state',detail:{field,limit:rule.key}}}}
const limit=active[rule.key]
const value=state[rule.field]
const projected=rule.project(state,price)
if(rule.exceeds(projected,limit)){return{stop:true,reason:rule.reason,detail:{limit,value,projected,price}}}}
return{stop:false,reason:null}}
function shouldStopBeforeAction(state){if(state&&state.captcha===true) return{stop:true,reason:'captcha'}
if(!state||typeof state!=='object'||Array.isArray(state)){return{stop:true,reason:'bad-state',detail:{field:null}}}
for(const key of['maxActions','maxDurationMs']){if(!Object.hasOwn(active,key))continue
const field=STATE_FIELD[key]
const value=state[field]
if(!isCount(value)){return{stop:true,reason:'bad-state',detail:{field,limit:key}}}
const limit=active[key]
const measured=key==='maxDurationMs'?clock.now()-value:value
if(measured>=limit){return{stop:true,reason:REASON[key],detail:key==='maxDurationMs'
?{limit,elapsed:measured}
:{limit,value}}}}
return{stop:false,reason:null}}
function shouldStopBeforeBid(state,amount){if(!state||typeof state!=='object'||Array.isArray(state)){return{stop:true,reason:'bad-state',detail:{field:null}}}
if(!isMoney(amount)){return{stop:true,reason:'bad-state',detail:{field:'bidAmount'}}}
if(!Object.hasOwn(active,'minCoins')){return{stop:false,reason:null}}
if(!isMoney(state.coins)){return{stop:true,reason:'bad-state',detail:{field:'coins',limit:'minCoins'}}}
const limit=active.minCoins
const projected=state.coins-amount
if(projected<limit){return{stop:true,reason:'out-of-coins',detail:{limit,value:state.coins,projected,price:amount}}}
return{stop:false,reason:null}}
return{shouldStop,shouldStopBeforeAction,shouldStopBeforePurchase,shouldStopBeforeBid,
limits:()=>({...active}),
active:()=>Object.keys(active).sort()}}
