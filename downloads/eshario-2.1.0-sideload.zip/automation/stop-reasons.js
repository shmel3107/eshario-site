export const STOP_REASON_KEYS=Object.freeze({captcha:'automation.stop.captcha',fatal:'automation.stop.fatal','out-of-coins':'automation.stop.outOfCoins','spend-limit':'automation.stop.spendLimit','loss-limit':'automation.stop.lossLimit','purchase-limit':'automation.stop.purchaseLimit','search-limit':'automation.stop.searchLimit','action-limit':'automation.stop.actionLimit','time-limit':'automation.stop.timeLimit','bad-state':'automation.stop.badState','unassigned-full':'automation.stop.unassignedFull','unassigned-unavailable':'automation.stop.unassignedUnavailable',cancelled:'automation.stop.cancelled','iteration-cap':'automation.stop.iterationCap',
throttled:'automation.stop.throttled','place-failed':'automation.stop.placeFailed','save-failed':'automation.stop.saveFailed','day-budget':'automation.stop.dayBudget','search-hour':'automation.stop.searchHour','market-budget':'automation.stop.marketBudget','market-rest':'automation.stop.marketRest','hour-cap':'automation.stop.hourCap',
'counter-unavailable':'automation.stop.counterUnavailable',
'market-off':'automation.stop.marketOff','market-unreadable':'automation.stop.marketUnreadable',
'session-over':'automation.stop.sessionOver','consent-required':'automation.stop.consentRequired',
'too-many-matches':'automation.stop.tooManyMatches','filter-changed':'automation.stop.filterChanged',
unknown:'automation.stop.unknown'
})
export const CRITICAL_STOPS=Object.freeze(['captcha','throttled','fatal','bad-state'])
export const isCriticalStop=(reason)=>CRITICAL_STOPS.includes(reason)
export function stopReasonKey(reason){return Object.hasOwn(STOP_REASON_KEYS,reason)?STOP_REASON_KEYS[reason]:'automation.stop.unknown'
}
