import{MIN_PRICE,nextPrice} from '../features/price-grid.js'
import{createBreakSchedule} from './breaks.js'
import{itemIdsReceiptMatches,moveReceiptMatches} from './item-receipts.js'
import{ACTION,planSales} from './sell-plan.js'
import{purchasePolicyProblems,rankPurchaseCandidates} from './purchase-policy.js'
import{extractItems} from './seller.js'
import{isDoorRefusal,isLotRefusal,ALLOWED,UNKNOWN as DOOR_UNKNOWN} from '../adapter/action-door.js'
import{createLotFilter} from '../adapter/search.js'
import{THROTTLED,COUNTER_UNAVAILABLE,restMarketAfterThrottle,askBudgetRound,readBudgetRound} from '../features/day-budget.js'
import{AFTER_BUY_DEFAULT,AFTER_BUY_PILE,afterBuyOf} from './options-input.js'
import{proceedsOf} from './pricing.js'
import{lootNameOf} from '../features/hunt-loot.js'
import{markListed} from './listed-mark.js'
const BID_STAGES=Object.freeze(['buy','bid'])
export const MAX_ITERATIONS=100_000
export const DEFAULT_SEARCH_BAND_MS=Object.freeze({minMs:2_500,maxMs:4_000})
export const DEFAULT_SEARCH_DELAY_MS=(DEFAULT_SEARCH_BAND_MS.minMs+DEFAULT_SEARCH_BAND_MS.maxMs)/2
export const DEFAULT_SEARCH_PAGE=1
export function searchPageOf(value){if(!Number.isFinite(value))return DEFAULT_SEARCH_PAGE
return Math.max(1,Math.trunc(value))}
export const DEFAULT_JITTER_MS=(DEFAULT_SEARCH_BAND_MS.maxMs-DEFAULT_SEARCH_BAND_MS.minMs)/2
export const SAFE_PAUSE_FLOOR_MS=2_500
export function defaultRhythmProblems(band=DEFAULT_SEARCH_BAND_MS,
jitterMs=DEFAULT_JITTER_MS,floorMs=SAFE_PAUSE_FLOOR_MS){const bad=[]
const min=Number(band?.minMs)
const max=Number(band?.maxMs)
if(!Number.isFinite(min)||!Number.isFinite(max)||min>max)return['band']
if(min<floorMs)bad.push('band-min')
const middle=(min+max)/2
const jitter=Number.isFinite(jitterMs)?Math.abs(jitterMs):0
if(middle-jitter<floorMs)bad.push('jitter')
return bad}
export const WORK_MS=5*60_000
export const BREAK_MS=90_000
export const BREAK_JITTER_MS=30_000
export const SESSION_MS=15*60_000
export const SESSION_PHASE=Object.freeze({WORK:'work',BREAK:'break',ASK:'ask'})
export const SESSION_OVER='session-over'
export const MAX_PER_SEARCH_DEFAULT=1
export const MATCH_GUARD_DEFAULT=5
export const TOO_MANY_MATCHES='too-many-matches'
export const STANDARD_UNASSIGNED_LIMIT=5
const TRACKED_BID_LIMIT=1000
export function jitterFor(iteration,spread){if(!Number.isFinite(spread)||spread<=0)return 0
const wave=Math.abs(Math.sin((iteration+1)*12.9898)*43758.5453)
const frac=wave-Math.floor(wave)
return Math.round((frac*2-1)*spread)}
export function extractLots(data){if(data
&&typeof data==='object'
&&!Array.isArray(data)
&&Array.isArray(data.items)){return data.items}
return null}
export function receiptShapeOf(value){if(value===null||value===undefined)return String(value)
if(Array.isArray(value))return `array(${value.length})`
if(typeof value!=='object')return typeof value
const parts=[]
for(const key of Object.keys(value).slice(0,8)){let said='?'
try{const one=value[key]
said=one===null?'null':(Array.isArray(one)?`array(${one.length})`:typeof one)}catch{said='throw'}
parts.push(`${key}=${said}`)}
return parts.length===0?'{}':parts.join(' ')}
export function bidReceiptOf(data){if(data
&&typeof data==='object'
&&!Array.isArray(data)
&&Number.isSafeInteger(data.coins)
&&data.coins>=0
&&Array.isArray(data.items)
&&data.items.length>0
&&data.items.every((item)=>item&&typeof item==='object')){return{coins:data.coins,items:data.items}}
if(data
&&typeof data==='object'
&&!Array.isArray(data)
&&Array.isArray(data.itemIds)
&&data.itemIds.length>0){return{coins:null,items:[],itemIds:[...data.itemIds]}}
return null}
export const PROVEN_REFUSALS=Object.freeze(['gone','out-of-coins','captcha','fatal','throttled','card-throttled'])
export function bidOutcome(answer){const category=typeof answer?.category==='string'?answer.category:null
if(category!==null)return PROVEN_REFUSALS.includes(category)?'refused':'unknown'
const receipt=answer?.receipt
return receipt===null||receipt===undefined?'unknown':'bought'}
export function unassignedCountOf(data){return data&&typeof data==='object'&&!Array.isArray(data)
&&Array.isArray(data.items)
?data.items.length
:null}
export function auctionOf(lot){if(typeof lot?.getAuctionData==='function'){try{const auction=lot.getAuctionData()
if(auction&&typeof auction==='object') return auction}catch{return null}}
return null}
function auctionTradeId(auction){const value=auction?.tradeId
if(typeof value==='number'&&Number.isFinite(value))return String(value)
if(typeof value==='string'&&value!=='')return value
return null}
function auctionIsOutbid(auction){if(typeof auction?.isOutbid==='function'){try{return auction.isOutbid()===true}catch{return false}}
return auction?.bidState==='outbid'}
export function buyNowPriceOf(lot){const value=auctionOf(lot)?.buyNowPrice
return typeof value==='number'&&Number.isFinite(value)&&value>0?value:null}
export function currentBidOf(lot){const value=auctionOf(lot)?.currentBid
return typeof value==='number'&&Number.isFinite(value)&&value>=0?value:null}
function startingBidOf(lot){const value=auctionOf(lot)?.startingBid
return typeof value==='number'&&Number.isFinite(value)&&value>0?value:null}
export function pileOrNull(value){if(typeof value==='number'&&Number.isFinite(value)) return value
if(typeof value==='string'&&value!=='') return value
return null}
export const CAP_TARGET='target-cap'
export const CAP_OPTIONS='max-price'
export function targetCapOf(criteria){const said=Number(criteria?.maxBuy)
return Number.isSafeInteger(said)&&said>0?said:null}
export function buyCeilingOf(criteria,maxPrice){const settings=Number.isFinite(maxPrice)?maxPrice:Infinity
const said=targetCapOf(criteria)
const goal=said===null?Infinity:said
if(said===null)return{cap:settings,goal,source:Number.isFinite(settings)?CAP_OPTIONS:null}
return said<=settings?{cap:said,goal,source:CAP_TARGET}:{cap:settings,goal,source:CAP_OPTIONS}}
export function priceCapMissing(filters,maxPrice){const list=Array.isArray(filters)?filters.filter(Boolean):[]
return list.length===0||list.some((one)=>!Number.isFinite(buyCeilingOf(one,maxPrice).cap))}
export function bidPriceFor(lot,maxBid,liveMin=null){if(!Number.isFinite(maxBid)||maxBid<=0)return null
const current=currentBidOf(lot)
if(current===null)return null
const next=current===0?startingBidOf(lot):nextPrice(current)
if(next===null||next>maxBid)return null
if(next<MIN_PRICE&&Number.isSafeInteger(liveMin)&&next<liveMin)return null
return next}
const statusOf=(err)=>(typeof err?.status==='number'?err.status:null)
const isMoney=(value)=>Number.isSafeInteger(value)&&value>=0
export function overflowSafetyProblems(options={},stop={}){if(options?.allowUnassignedOverflow!==true)return[]
let limits={}
try{limits=typeof stop?.limits==='function'?stop.limits():{}}catch{limits={}}
const problems=[]
const maxPrice=options?.maxPrice
const maxPurchases=limits?.maxPurchases
const maxSpend=limits?.maxSpend
if(!Number.isFinite(maxPrice)||maxPrice<=0) problems.push('maxPrice')
if(!Number.isSafeInteger(maxPurchases)||maxPurchases<=0){problems.push('maxPurchases')}
if(!Number.isFinite(maxSpend)||maxSpend<=0){problems.push('maxSpend')}else if(Number.isFinite(maxPrice)
&&maxPrice>0
&&Number.isSafeInteger(maxPurchases)
&&maxPurchases>0
&&maxSpend<maxPrice*maxPurchases){problems.push('maxSpend')}
return[...new Set(problems)]}
function cardNumbersOf(criteria){const raw=criteria?.defId
if(!Array.isArray(raw))return[]
const out=[]
for(const value of raw){const id=Number(value)
if(!Number.isSafeInteger(id)||id<=0)continue
if(!out.includes(id))out.push(id)}
return out}
export function searchRing(filters){const list=Array.isArray(filters)?filters:[]
const ring=[]
for(let index=0;index<list.length;index+=1){const criteria=list[index]
const cards=cardNumbersOf(criteria)
if(cards.length<2){ring.push({set:index,defId:cards.length===1?cards[0]:null,criteria})
continue}
for(const id of cards)ring.push({set:index,defId:id,criteria:{...criteria,defId:[id]}})}
return ring}
export function createSniper(deps={}){const{market,session,stop,clock,filters}=deps
if(!market||typeof market.searchTransferMarket!=='function'||typeof market.bid!=='function'){throw new Error('sniper: нужен рынок с searchTransferMarket и bid')}
if(!session
||typeof session.snapshot!=='function'
||typeof session.recordAction!=='function'
){throw new Error('sniper: нужна сессия')}
if(!stop
||typeof stop.shouldStop!=='function'
||typeof stop.shouldStopBeforePurchase!=='function'
||typeof stop.shouldStopBeforeBid!=='function'
){throw new Error('sniper: нужны условия остановки')}
if(!clock||typeof clock.sleep!=='function') throw new Error('sniper: нужны часы (правило 6 NIGHT_BRIEF)')
if(!Array.isArray(filters)||filters.length===0) throw new Error('sniper: нужен хотя бы один набор фильтров')
const ring=searchRing(filters)
const ringSearches=ring.map(()=>0)
let lastSearchAt=null
const handPort=typeof deps.handOnScreen==='function'?deps.handOnScreen:null
const handOnScreen=()=>{if(handPort===null)return false
try{return handPort()===true}catch{return false}}
let yields=0
let yielding=false
let searchCounterRetried=false
let overTargetCap=0
let overMaxPrice=0
let misses=0
let lastMiss=null
const options=deps.options??{}
const coinBalance=typeof deps.coinBalance==='function'?deps.coinBalance:null
const budget=deps.budget??null
const budgetSearch=()=>(budget!==null&&typeof budget.search==='function'?budget.search():null)
const budgetCall=(count=1)=>(budget!==null&&typeof budget.call==='function'?budget.call(count):null)
const budgetWarm=(count)=>(budget!==null&&typeof budget.warm==='function'
?budget.warm(count)
:Promise.resolve(null))
const budgetSettle=async(opts)=>{if(budget===null||typeof budget.settle!=='function')return null
try{return await budget.settle(opts)}catch{return null}}
const budgetDoors={warm:(count)=>budgetWarm(count),take:(count)=>budgetCall(count),
settle:()=>budgetSettle({market:false})}
const spendRound=(count=1)=>askBudgetRound(budgetDoors,count)
const readRound=(count=1)=>readBudgetRound(budgetDoors,count)
const buyRatePort=()=>{const said=typeof deps.buyRate==='function'?deps.buyRate():deps.buyRate
return said&&typeof said.take==='function'?said:null}
const takeBidSlot=()=>{const rate=buyRatePort()
return rate===null?COUNTER_UNAVAILABLE:rate.take()}
const releaseBidSlot=()=>{const rate=buyRatePort()
if(rate!==null&&typeof rate.release==='function')rate.release()}
const settleBidSlot=async()=>{const rate=buyRatePort()
if(rate===null||typeof rate.settle!=='function')return null
try{const said=await rate.settle()
return typeof said==='string'?said:null}catch{return COUNTER_UNAVAILABLE}}
const lotFilters=new Map()
const filterFor=(index)=>{if(lotFilters.has(index))return lotFilters.get(index)
const criteria=ring[index]?.criteria
const sieve=typeof market.lotFilter==='function'
?market.lotFilter(criteria)
:createLotFilter(criteria)
lotFilters.set(index,sieve)
return sieve}
const rotationState=()=>({size:ring.length,
seats:ring.map((seat,index)=>({set:seat.set,defId:seat.defId,searches:ringSearches[index]}))})
function ratingOf(item){let raw=null
try{raw=Number(item?.rating)}catch{return null}
return Number.isSafeInteger(raw)&&raw>0?raw:null}
const filterState=()=>{const fields=new Set(),unsupported=new Set(),reasons={}
let seen=0,kept=0
for(const sieve of lotFilters.values()){let one=null
try{one=sieve.state()}catch{one=null}
if(one===null)continue
for(const name of one.fields)fields.add(name)
for(const name of one.unsupported)unsupported.add(name)
for(const[name,count]of Object.entries(one.reasons))reasons[name]=(reasons[name]??0)+count
seen+=one.seen
kept+=one.kept}
return{fields:[...fields].sort(),unsupported:[...unsupported].sort(),
seen,kept,dropped:seen-kept,reasons,
overTargetCap,overMaxPrice,
misses,miss:lastMiss===null?null:{...lastMiss}}}
const onEvent=typeof deps.onEvent==='function'?deps.onEvent:()=>{}
const emit=(name,payload)=>{try{onEvent(name,payload)}catch{
}}
const maxPrice=Number.isFinite(options.maxPrice)?options.maxPrice:Infinity
const searchDelayMs=Number.isFinite(options.searchDelayMs)?options.searchDelayMs:DEFAULT_SEARCH_DELAY_MS
const buyDelayMs=Number.isFinite(options.buyDelayMs)?options.buyDelayMs:500
const jitterMs=Number.isFinite(options.jitterMs)?options.jitterMs:DEFAULT_JITTER_MS
const page=searchPageOf(options.page)
const iterationCap=Number.isFinite(options.maxIterations)?options.maxIterations:MAX_ITERATIONS
const maxBid=Number.isFinite(options.maxBid)?options.maxBid:0
const allowUnassignedOverflow=options.allowUnassignedOverflow===true
const purchasePolicy=options.purchasePolicy??{}
const policyProblems=purchasePolicyProblems(options.purchasePolicy)
if(policyProblems.length>0){throw new Error(`sniper: неверная purchase policy: ${policyProblems.join(', ')}`)}
const overflowProblems=overflowSafetyProblems(options,stop)
if(overflowProblems.length>0){throw new Error(`sniper: overflow требует безопасные пределы: ${overflowProblems.join(', ')}`)}
const maxPerSearch=Number.isSafeInteger(options.maxPerSearch)&&options.maxPerSearch>0
?options.maxPerSearch
:MAX_PER_SEARCH_DEFAULT
const matchGuard=Number.isSafeInteger(options.matchGuard)&&options.matchGuard>=0
?options.matchGuard
:MATCH_GUARD_DEFAULT
const explicitMoveTo=pileOrNull(options.moveTo)
const immediateList=options.immediateList?.enabled===true
?options.immediateList
:null
if(immediateList&&explicitMoveTo!==null){throw new Error('sniper: immediate list несовместим с moveTo')}
const afterBuy=afterBuyOf(options.afterBuy)
const moveTo=explicitMoveTo!==null
?explicitMoveTo
:(immediateList!==null?null:AFTER_BUY_PILE[afterBuy])
if(immediateList
&&(typeof market.requestMarketData!=='function'
||typeof market.list!=='function'
)){throw new Error('sniper: immediate list требует requestMarketData и list')}
const breakInput=options.breaks??{}
const breaks=createBreakSchedule({workMs:WORK_MS,restMs:BREAK_MS,
jitterMs:Number.isFinite(breakInput.restMs)?0:BREAK_JITTER_MS,...breakInput})
const sessionMs=Number.isFinite(options.sessionMs)&&options.sessionMs>0
?options.sessionMs
:SESSION_MS
const startedAt=clock.now()
let askContinue=false
let iteration=0
let cursor=0
let answers=0
let running=false
let cancelled=false
let wakeCall=null
let wakeSignal=null
const armWake=()=>{wakeSignal=new Promise((resolve)=>{wakeCall=resolve})}
armWake()
const wakeUp=()=>{if(wakeCall===null)return
const call=wakeCall
wakeCall=null
call()}
const nap=(ms)=>{if(cancelled)return Promise.resolve()
return Promise.race([clock.sleep(ms),wakeSignal])}
const acceptedBids=new Map()
const rememberAcceptedBid=(lot,price)=>{const tradeId=auctionTradeId(auctionOf(lot))
if(tradeId===null)return
acceptedBids.delete(tradeId)
acceptedBids.set(tradeId,price)
while(acceptedBids.size>TRACKED_BID_LIMIT){acceptedBids.delete(acceptedBids.keys().next().value)}}
const reportObservedOutbids=(lots)=>{for(const lot of lots){const auction=auctionOf(lot)
const tradeId=auctionTradeId(auction)
if(tradeId===null||!acceptedBids.has(tradeId)||!auctionIsOutbid(auction))continue
const price=acceptedBids.get(tradeId)
acceptedBids.delete(tradeId)
session.recordOutbid()
emit('outbid',{price,item:lot,tradeId})}}
const searchesLeftToday=()=>{if(budget===null||typeof budget.searchesLeft!=='function')return null
try{const said=budget.searchesLeft()
return Number.isSafeInteger(said)&&said>=0?said:null}catch{return null}}
const nextRestAt=()=>{if(!breaks.isEnabled())return startedAt+sessionMs
const cycleMs=breaks.workMs+breaks.restMs
const cycle=Math.floor(Math.max(0,clock.now()-startedAt)/cycleMs)
return Math.min(startedAt+sessionMs,startedAt+cycle*cycleMs+breaks.workMs)}
const sessionState=()=>{const now=clock.now()
const left=searchesLeftToday()
if(askContinue){return{startedAt,phase:SESSION_PHASE.ASK,nextChangeAt:startedAt+sessionMs,
askContinue:true,searchesLeftToday:left,yielding,yields}}
const rest=breaks.shouldRest(Math.max(0,now-startedAt))
return rest.rest
?{startedAt,phase:SESSION_PHASE.BREAK,nextChangeAt:now+rest.forMs,askContinue:false,searchesLeftToday:left,yielding,yields}
:{startedAt,phase:SESSION_PHASE.WORK,nextChangeAt:nextRestAt(),askContinue:false,searchesLeftToday:left,yielding,yields}}
const summaryState=()=>{const stats=session.stats()
const caught=session.isDryRun()?stats.wouldBuy:stats.purchases
const priced=Number.isSafeInteger(stats.listings)?stats.listings:0
const off=immediateList===null?'no-sale-price':(priced<caught?'partial':null)
return{caught,spent:stats.spent,lastSearchAt,
expectedProfit:off===null&&caught>0?proceedsOf(stats.listedValue)-stats.spent:null,
expectedProfitOff:caught===0?'nothing-caught':off,
searchesLeft:searchesLeftToday()}}
const pause=(base)=>nap(Math.max(0,base+jitterFor(iteration,jitterMs)))
const restMarket=(stage)=>{const done=restMarketAfterThrottle(budget)
if(done)emit('rest-market',{stage})
return done}
const throttleStop=(failure,stage)=>{if(failure?.category!==THROTTLED)return null
restMarket(stage)
return{reason:THROTTLED,detail:{stage}}}
const reserveAction=async(stage)=>{if(session.isDryRun())return null
if(cancelled)return{reason:'cancelled',detail:{stage}}
const before=typeof stop.shouldStopBeforeAction==='function'
?stop.shouldStopBeforeAction(session.snapshot())
:stop.shouldStop(session.snapshot())
if(before.stop&&before.reason!=='search-limit'){return{reason:before.reason,detail:{...(before.detail??{}),stage}}}
let bidSlot=false
if(BID_STAGES.includes(stage)){const hour=takeBidSlot()
if(hour!==null){emit('failure',{stage,category:hour})
return{reason:hour,detail:{stage}}}
bidSlot=true
const settled=await settleBidSlot()
if(settled!==null){releaseBidSlot()
emit('failure',{stage,category:settled})
return{reason:settled,detail:{stage,door:'settle'}}}}
const money=await spendRound(1)
if(money!==null){if(bidSlot)releaseBidSlot()
emit('failure',{stage,category:money.reason})
return{reason:money.reason,detail:{stage,door:money.door}}}
if(cancelled){if(bidSlot)releaseBidSlot()
return{reason:'cancelled',detail:{stage}}}
session.recordAction()
return null}
const refreshCoins=(stage)=>{if(session.isDryRun())return null
let value
if(coinBalance===null){value=session.snapshot()?.coins}else{try{value=coinBalance()}catch{value=null}}
if(!isMoney(value)){return{reason:'bad-state',detail:{field:'coins',stage}}}
session.setCoins(value)
return null}
const unknownWrite=(price,category,stage,spend)=>{const before=session.snapshot()?.coins
session.recordUnknown(price,spend)
const expected=isMoney(before)&&isMoney(price)?Math.max(0,before-price):null
let live=null
if(coinBalance===null){live=session.snapshot()?.coins}else{try{live=coinBalance()}catch{live=null}}
const seen=isMoney(live)?live:null
emit('bid-unknown',{stage,price,category,expected,live:seen,matched:expected!==null&&seen!==null&&seen===expected})
return{reason:'bad-state',detail:{stage,field:'bid-outcome',category,price,expected,live:seen}}}
const moveBought=async(lot)=>{if(!moveTo||typeof market.move!=='function') return{moved:false}
const reserved=await reserveAction('move')
if(reserved)return reserved
try{const receipt=await market.move([lot],moveTo)
if(!moveReceiptMatches(receipt,[lot])){return{reason:'bad-state',detail:{stage:'move',field:'itemIds'}}}
session.recordMove(1)
emit('moved',{pile:moveTo,afterBuy})
return{moved:true}}catch(err){
if(isDoorRefusal(err)){emit('door',{stage:'move',verdict:err.door?.verdict,reason:err.door?.reason,fits:err.door?.fits,need:err.door?.need})
return{moved:false}}
const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'move',category:failure.category})
const halt=throttleStop(failure,'move')
if(halt)return halt
return['captcha','fatal','out-of-coins'].includes(failure.category)
?{reason:failure.category,detail:{stage:'move'}}
:{moved:false}}}
const listBought=async(lot,buyPrice)=>{if(immediateList===null)return null
let stage='market-data'
const permit=await readRound(1)
if(permit!==null)return{reason:permit.reason,detail:{stage,door:permit.door}}
try{const response=await market.requestMarketData(lot)
if(!response
||typeof response!=='object'
||Array.isArray(response)
||!Array.isArray(response.marketData)){return{reason:'bad-state',detail:{stage,field:'marketData'}}}
emit('market-data',{item:lot})
if(cancelled) return{reason:'cancelled'}
const row=planSales([lot],{...immediateList,buyPrice:()=>buyPrice})[0]
if(row?.action!==ACTION.LIST){return{reason:'bad-state',detail:{stage:'immediate-list',field:row?.reason??'price'}}}
if(session.isDryRun()){session.recordListing(row.price)
emit('would-sell',{action:ACTION.LIST,price:row.price,item:lot})
return null}
let rows=null
if(typeof market.requestTransferItems==='function'){stage='transfer-list'
const listSlot=budgetCall(1)
if(listSlot!==null)return{reason:listSlot,detail:{stage}}
const listSettled=await budgetSettle({market:false})
if(listSettled!==null)return{reason:listSettled,detail:{stage}}
rows=extractItems(await market.requestTransferItems())}
const blocked=await reserveAction('immediate-list')
if(blocked)return blocked
stage='immediate-list'
const receipt=await market.list(lot,row.startingBid??row.price,row.price,3600,{fresh:true,rows})
if(!itemIdsReceiptMatches(receipt,[lot])){return{reason:'bad-state',detail:{stage,field:'itemIds'}}}
session.recordListing(row.price)
markListed(lot)
emit('listed',{price:row.price,item:lot})
return null}catch(err){
if(isDoorRefusal(err)){emit('door',{stage:'immediate-list',verdict:err.door?.verdict,reason:err.door?.reason,fits:err.door?.fits,need:err.door?.need})
return{reason:'list-blocked',detail:{stage:'immediate-list',door:err.door?.reason??null}}}
const failure=session.recordFailure(statusOf(err))
emit('failure',{stage,category:failure.category,price:buyPrice,item:lot})
const halt=throttleStop(failure,stage)
if(halt)return halt
const reason=['captcha','fatal','out-of-coins'].includes(failure.category)
?failure.category
:'bad-state'
return{reason,detail:{stage}}}}
const askDoor=(request)=>(typeof market.review==='function'
?market.review(request)
:{verdict:DOOR_UNKNOWN,reason:'no-judge',need:1,fits:null})
const liveBidFloor=()=>{const said=askDoor({action:'bid-grid'})
return said?.verdict===ALLOWED&&Number.isSafeInteger(said?.floor)?said.floor:null}
const doorStop=(stage,review)=>{emit('door',{stage,verdict:review?.verdict,reason:review?.reason,
fits:review?.fits,need:review?.need,used:review?.used,size:review?.size,coins:review?.coins})
return isLotRefusal(review)
?null
:{reason:stage==='bid'?'bid-blocked':'buy-blocked',detail:{stage,door:review?.reason??null}}}
const readUnassigned=async()=>{if(typeof market.requestUnassignedItems!=='function'){emit('failure',{stage:'unassigned',category:'unavailable'})
return{stop:{reason:'unassigned-unavailable',detail:{stage:'unassigned'}},count:null}}
const permit=await readRound(1)
if(permit!==null){emit('failure',{stage:'unassigned',category:permit.reason})
return{stop:{reason:permit.reason,detail:{stage:'unassigned',door:permit.door}},count:null}}
try{const count=unassignedCountOf(await market.requestUnassignedItems())
if(count===null){emit('failure',{stage:'unassigned',category:'bad-shape'})
return{stop:{reason:'unassigned-unavailable',detail:{stage:'unassigned'}},count:null}}
return{stop:null,count}}catch(err){const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'unassigned',category:failure.category})
const halt=throttleStop(failure,'unassigned')
if(halt)return{stop:halt,count:null}
const reason=['captcha','fatal','out-of-coins'].includes(failure.category)
?failure.category
:'unassigned-unavailable'
return{stop:{reason,detail:{stage:'unassigned'}},count:null}}}
const unassignedGate=()=>{let seen=null
return async(allowOverflow,own)=>{if(allowOverflow===true)return null
if(seen===null){const said=await readUnassigned()
if(said.stop!==null)return said.stop
seen=said.count}
const count=seen+(Number.isSafeInteger(own)&&own>0?own:0)
return count>=STANDARD_UNASSIGNED_LIMIT
?{reason:'unassigned-full',detail:{stage:'unassigned',count,limit:STANDARD_UNASSIGNED_LIMIT}}
:null}}
const finish=(reason,detail)=>{running=false
yielding=false
const result={reason,detail:detail??null,stats:session.stats(),iterations:iteration,filter:filterState(),
session:sessionState(),summary:summaryState(),rotation:rotationState()}
emit('stopped',result)
return result}
return{isRunning:()=>running,
cancel(){cancelled=true
wakeUp()},
filterAt:(n)=>ring[n%ring.length].criteria,
filterState,
rotationState,
sessionState,
summaryState,
async run(){running=true
cancelled=false
armWake()
const rate=buyRatePort()
if(rate!==null&&typeof rate.load==='function'){try{await rate.load()}catch{
}}
const settleCycle=async()=>{if(cancelled)return{reason:'cancelled'}
const after=stop.shouldStop(session.snapshot())
if(after.stop)return{reason:after.reason,detail:after.detail}
if(clock.now()-startedAt>=sessionMs){askContinue=true
return{reason:SESSION_OVER,detail:{askContinue:true,sessionMs}}}
if(iteration+1>=iterationCap)return{reason:'iteration-cap',detail:{cap:iterationCap}}
await pause(searchDelayMs)
return null}
for(;iteration<iterationCap;iteration+=1){if(cancelled) return finish('cancelled')
const cycleCoins=refreshCoins('cycle')
if(cycleCoins)return finish(cycleCoins.reason,cycleCoins.detail)
const before=stop.shouldStop(session.snapshot())
if(before.stop)return finish(before.reason,before.detail)
if(clock.now()-startedAt>=sessionMs){askContinue=true
return finish(SESSION_OVER,{askContinue:true,sessionMs})}
const rest=breaks.shouldRest(clock.now()-startedAt)
if(rest.rest){session.recordRest()
emit('rest',{forMs:rest.forMs,cycle:rest.cycle})
await nap(rest.forMs)
continue}
const seatIndex=cursor%ring.length
const seat=ring[seatIndex]
const criteria=seat.criteria
const marketDoor=askDoor({action:'market'})
if(marketDoor?.verdict!==ALLOWED){const reason=marketDoor?.reason==='market-off'?'market-off':'market-unreadable'
emit('door',{stage:'market',verdict:marketDoor?.verdict,reason:marketDoor?.reason})
return finish(reason,{stage:'search',door:marketDoor?.reason??null})}
if(handOnScreen()){if(!yielding){yielding=true
yields+=1
emit('waiting',{stage:'search',reason:'hand-on-screen',forMs:searchDelayMs})}
await pause(searchDelayMs)
continue}
yielding=false
const slot=budgetSearch()
if(slot==='budget'){emit('waiting',{stage:'search',reason:slot,forMs:searchDelayMs})
await pause(searchDelayMs)
continue}
if(slot===COUNTER_UNAVAILABLE&&!searchCounterRetried){searchCounterRetried=true
emit('waiting',{stage:'search',reason:slot,forMs:searchDelayMs})
await pause(searchDelayMs)
continue}
if(slot!==null)return finish(slot,{stage:'search'})
searchCounterRetried=false
const settledSearch=await budgetSettle({market:true})
if(settledSearch!==null)return finish(settledSearch,{stage:'search',door:'settle'})
let cleared=false
try{cleared=typeof market.clearMarketCache==='function'&&market.clearMarketCache()===true}catch{cleared=false}
if(!cleared)return finish('bad-state',{stage:'cache-clear'})
session.recordSearch()
lastSearchAt=clock.now()
cursor+=1
ringSearches[seatIndex]+=1
emit('search',{iteration,criteria,defId:seat.defId})
let lots
try{lots=extractLots(await market.searchTransferMarket(criteria,page))
if(lots===null){return finish('bad-state',{stage:'search',field:'items'})}}catch(err){const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'search',category:failure.category})
const halt=throttleStop(failure,'search')
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop) return finish(failure.category,{stage:'search'})
const settledAfterFailure=await settleCycle()
if(settledAfterFailure)return finish(settledAfterFailure.reason,settledAfterFailure.detail)
continue}
answers+=1
reportObservedOutbids(lots)
const sieve=filterFor(seatIndex)
const passed=lots.filter((lot)=>{try{return sieve.keep(lot)===true}catch{return false}})
const ceiling=buyCeilingOf(criteria,maxPrice)
const selected=rankPurchaseCandidates(passed.map((lot)=>({lot})),purchasePolicy,{byPrice:false})
const priced=rankPurchaseCandidates(selected.eligible.map(({lot})=>({lot,price:buyNowPriceOf(lot)})),purchasePolicy).eligible
const affordable=priced.filter((entry)=>entry.price!==null&&entry.price<=ceiling.cap)
if(matchGuard>0&&answers===1&&affordable.length>=matchGuard){emit('guard',{stage:'search',reason:TOO_MANY_MATCHES,matched:affordable.length,guard:matchGuard})
return finish(TOO_MANY_MATCHES,{stage:'search',matched:affordable.length,guard:matchGuard})}
for(const entry of priced){if(entry.price===null||entry.price<=ceiling.cap)continue
if(ceiling.source===CAP_TARGET)overTargetCap+=1
else overMaxPrice+=1}
const bidLots=selected.eligible.map(({lot})=>lot)
session.recordPolicySkipped?.(selected.skipped)
emit('found',{iteration,total:lots.length,kept:passed.length,dropped:lots.length-passed.length,
affordable:affordable.length,policySkipped:selected.skipped,
overTargetCap,overMaxPrice,ceiling:Number.isFinite(ceiling.cap)?ceiling.cap:null,capFrom:ceiling.source})
const guardPile=unassignedGate()
let boughtThisSearch=0
let pileGrew=0
for(const entry of affordable){if(cancelled) return finish('cancelled')
if(boughtThisSearch>=maxPerSearch){emit('per-search-cap',{cap:maxPerSearch,skipped:affordable.length-boughtThisSearch})
break}
const beforeBuy=stop.shouldStop(session.snapshot())
if(beforeBuy.stop&&beforeBuy.reason!=='search-limit'){return finish(beforeBuy.reason,beforeBuy.detail)}
const unassigned=await guardPile(allowUnassignedOverflow,pileGrew)
if(unassigned)return finish(unassigned.reason,unassigned.detail)
const liveCoins=refreshCoins('buy')
if(liveCoins)return finish(liveCoins.reason,liveCoins.detail)
const beforePurchase=stop.shouldStopBeforePurchase(session.snapshot(),entry.price)
if(beforePurchase.stop){return finish(beforePurchase.reason,beforePurchase.detail)}
if(session.isDryRun()){
session.recordPurchase(entry.price)
boughtThisSearch+=1
if(immediateList===null&&moveTo===null)pileGrew+=1
emit('would-buy',{price:entry.price,item:entry.lot})
if(moveTo!==null)emit('would-move',{pile:moveTo,afterBuy})
const listed=await listBought(entry.lot,entry.price)
if(listed?.reason)return finish(listed.reason,listed.detail)}else{
const door=askDoor({action:'buy',lot:entry.lot,amount:entry.price})
if(door.verdict!==ALLOWED){const stop=doorStop('buy',door)
if(stop)return finish(stop.reason,stop.detail)
continue}
const reserved=await reserveAction('buy')
if(reserved)return finish(reserved.reason,reserved.detail)
try{const answer=await market.bid(entry.lot,entry.price,'buy')
const receipt=bidReceiptOf(answer)
const mine=receipt!==null&&Array.isArray(receipt.itemIds)
?itemIdsReceiptMatches(answer,[entry.lot])
:true
if(receipt===null||!mine){
emit('failure',{stage:'buy',category:`расписка не понята: ${receiptShapeOf(answer)} совпало=${mine?'да':'нет'}`,
price:entry.price,item:entry.lot})
return finish('bad-state',{stage:'buy',field:'bid-result',shape:receiptShapeOf(answer)})}
session.recordPurchase(entry.price)
boughtThisSearch+=1
emit('bought',{price:entry.price,item:entry.lot})
const listed=await listBought(entry.lot,entry.price)
if(listed?.reason)return finish(listed.reason,listed.detail)
const moved=await moveBought(entry.lot)
if(moved?.reason)return finish(moved.reason,moved.detail)
if(immediateList===null&&moved?.moved!==true)pileGrew+=1
const synced=refreshCoins('buy-response')
if(synced)return finish(synced.reason,synced.detail)}catch(err){
if(isDoorRefusal(err)){if(isLotRefusal(err.door)){if(typeof session.releaseAction!=='function'){return finish('bad-state',{stage:'buy',field:'action-slot'})}
session.releaseAction()}
const stop=doorStop('buy',err.door)
if(stop)return finish(stop.reason,stop.detail)
continue}
const failure=session.recordFailure(statusOf(err))
if(failure.category==='gone'){misses+=1
lastMiss={name:lootNameOf(entry.lot),rating:ratingOf(entry.lot),price:entry.price}}
emit('failure',{stage:'buy',category:failure.category,price:entry.price,item:entry.lot})
if(bidOutcome({category:failure.category})==='unknown'){const said=unknownWrite(entry.price,failure.category,'buy',true)
return finish(said.reason,said.detail)}
const halt=throttleStop(failure,'buy')
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop) return finish(failure.category,{stage:'buy'})
continue}}
await pause(buyDelayMs)}
if(maxBid>0){for(const lot of bidLots){if(cancelled) return finish('cancelled')
const beforeBid=stop.shouldStop(session.snapshot())
if(beforeBid.stop&&beforeBid.reason!=='search-limit'){return finish(beforeBid.reason,beforeBid.detail)}
const price=bidPriceFor(lot,Math.min(maxBid,ceiling.goal),liveBidFloor())
if(price===null)continue
const unassigned=await guardPile(false,pileGrew)
if(unassigned)return finish(unassigned.reason,unassigned.detail)
const liveCoins=refreshCoins('bid')
if(liveCoins)return finish(liveCoins.reason,liveCoins.detail)
const beforeBidAmount=stop.shouldStopBeforeBid(session.snapshot(),price)
if(beforeBidAmount.stop){return finish(beforeBidAmount.reason,beforeBidAmount.detail)}
if(session.isDryRun()){
session.recordBid(price)
emit('would-bid',{price,item:lot})}else{
const door=askDoor({action:'bid',lot,amount:price})
if(door.verdict!==ALLOWED){const stop=doorStop('bid',door)
if(stop)return finish(stop.reason,stop.detail)
continue}
const reserved=await reserveAction('bid')
if(reserved)return finish(reserved.reason,reserved.detail)
try{const receipt=bidReceiptOf(await market.bid(lot,price,'bid'))
if(bidOutcome({receipt})==='unknown'){const said=unknownWrite(price,'bid-result','bid',false)
return finish(said.reason,{...said.detail,field:'bid-result'})}
session.recordBid(price)
rememberAcceptedBid(lot,price)
const synced=refreshCoins('bid-response')
if(synced)return finish(synced.reason,synced.detail)
emit('bid',{price,item:lot})}catch(err){
if(isDoorRefusal(err)){if(isLotRefusal(err.door)){if(typeof session.releaseAction!=='function'){return finish('bad-state',{stage:'bid',field:'action-slot'})}
session.releaseAction()}
const stop=doorStop('bid',err.door)
if(stop)return finish(stop.reason,stop.detail)
continue}
const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'bid',category:failure.category})
if(bidOutcome({category:failure.category})==='unknown'){const said=unknownWrite(price,failure.category,'bid',false)
return finish(said.reason,said.detail)}
const halt=throttleStop(failure,'bid')
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop) return finish(failure.category,{stage:'bid'})
continue}}
await pause(buyDelayMs)}}
const settled=await settleCycle()
if(settled)return finish(settled.reason,settled.detail)}
return finish('iteration-cap',{cap:iterationCap})}}}
