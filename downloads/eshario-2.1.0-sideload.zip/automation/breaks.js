export function createBreakSchedule(opts={}){const num=(value,fallback)=>(typeof value==='number'&&Number.isFinite(value)&&value>=0?value:fallback)
const workMs=num(opts.workMs,0)
const restMs=num(opts.restMs,0)
const jitterMs=num(opts.jitterMs,0)
const enabled=workMs>0&&restMs>0
const cycleMs=enabled?workMs+restMs:0
return{isEnabled:()=>enabled,workMs,restMs,
shouldRest(elapsedMs){if(!enabled)return{rest:false,forMs:0,cycle:0}
const elapsed=typeof elapsedMs==='number'&&Number.isFinite(elapsedMs)&&elapsedMs>=0
?elapsedMs
:0
const cycle=Math.floor(elapsed / cycleMs);
const position=elapsed-cycle*cycleMs;
if(position<workMs)return{rest:false,forMs:0,cycle};
const rest=Math.max(0,restMs+jitterFor(cycle,jitterMs));
const forMs=workMs+rest-position;
return forMs>0?{rest:true,forMs,cycle}:{rest:false,forMs:0,cycle}}}}
export function jitterFor(cycle,spread){if(!Number.isFinite(spread)||spread<=0)return 0;
const wave=Math.abs(Math.sin((cycle+1)*78.233)*43758.5453);
const frac=wave-Math.floor(wave);
return Math.round((frac*2-1)*spread)}
