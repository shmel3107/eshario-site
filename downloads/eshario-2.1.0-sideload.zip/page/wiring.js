import{installHotkeys} from '../features/hotkey-binding.js'
import{confirmButton,ownConfirmButton,visibleDialogs,pressNode,pressTarget,layerVisible} from '../features/hotkey-bind.js'
import{HOTKEY_ACTIONS} from '../features/hotkeys.js'
import{publishLiveCriteria} from '../features/filter-actions.js'
import{readMarketFilterCriteria,restoreLiveMarketCriteria} from '../adapter/market-screen.js'
import{startAutologin,createLandingWatch} from '../features/autologin-actions.js'
import{createLandingDoor} from '../adapter/landing.js'
import{findMinBin,countListings,minBinLabel,minBinTarget} from '../features/min-bin.js'
import{listAtMinNotice} from '../features/sell-sidebar.js'
import{enhanceTransferList} from '../features/transfer-list.js'
import{forgetPurchases} from '../features/purchase-log.js'
import{installItemEvidenceCapture,itemForEvidenceRow} from '../features/item-evidence.js'
import{enhancePriceBadges,relabelPriceBadges,dropAllPriceBadges,notePriceBadgeCard,priceBadgePeek} from '../features/price-badges.js'
import{installSbcSetCapture} from '../adapter/sbc-set.js'
import{installSbcHubCapture} from '../adapter/sbc-hub.js'
import{installStorageScreenCapture} from '../adapter/storage-screen.js'
import{installSelectedPlayerCapture,selectedPlayerRecord} from '../features/selected-player.js'
import{searchTypeOf} from '../adapter/ea.js'
import{installQuickListCapture} from '../adapter/quick-list.js'
import{installItemDetailsCapture} from '../adapter/item-details.js'
import{installSquadSlotCapture} from '../adapter/squad-slot.js'
import{installSquadScreenCapture,installSquadActionsCapture,installClubPickCapture} from '../adapter/squad-screen.js'
import{installSbcScreenCapture} from '../adapter/sbc-screen.js'
import{installStorePacksCapture,installStoreCatalogCapture,installStoreTabCapture,openMyPacks,installPackOpenCapture,installPackAnimationCapture,goStorePacks,backPlan,BACK_CALLS} from '../adapter/store-packs.js'
import{installPlayerPicksCapture,installPlayerPickControls} from '../adapter/player-picks.js'
import{installItemEvents} from '../adapter/item-events.js'
import{applyItemEvent} from '../features/sbc-pool.js'
import{installUnassignedScreenCapture,createUnassignedPerform,createUnassignedNativeStep} from '../adapter/unassigned-screen.js'
import{createUnassignedBulk,BUSY_FRAMES} from '../adapter/unassigned-bulk.js'
import{createDoorConsent,doorConsentKey,isDoorRefusal,reviewAction,ALLOWED,UNKNOWN} from '../adapter/action-door.js'
import{extractItems} from '../automation/seller.js'
import{createUnassignedStrip} from '../features/unassigned-strip.js'
import{installGameRewardsCapture} from '../adapter/game-rewards.js'
import{createRewardFlow} from '../features/reward-flow.js'
import{installLiveMessageCapture} from '../adapter/live-message.js'
import{createPromoClose} from '../features/promo-close.js'
import{installHomeHubCapture,readHubRewards,findLevel,claimHubReward,grantHubItems,readRewardKinds,readRewardLoot,noteRewardLoot,loadObjectiveCategories,findGroup,claimGroupReward} from '../adapter/hub-rewards.js'
import{storeRailButton,unopenedPackCount,requestPackSplit,installObjectiveRewardWatch} from '../adapter/tab-rail.js'
import{createClaimRewards} from '../features/claim-rewards.js'
import{createHubButton} from '../features/hub-button.js'
import{createHomeGrid} from '../features/home-grid.js'
import{createHeadTop} from '../features/head-top.js'
import{PANEL_ID} from '../ui/panel.js'
import{createRailPacks} from '../features/rail-packs.js'
import{offMarket,meterCalls,isDayBudgetError,askDayBudget} from '../features/day-budget.js'
import{createListCursor} from '../features/list-cursor.js'
import{AXIS_X,AXIS_Y} from '../features/list-rows.js'
import{ensureNotFoundWatch} from '../features/notfound-watch.js'
export const SBC_SCREEN_SELECTOR='.ut-sbc-hub-view,.ut-sbc-challenges-view,.ut-sbc-challenge-details-view'
export function wirePage(deps){const{doc,win,t,isActive,clock,market,criteria,personas,marketSearchQuick=null,sellSidebar=null,cardLockMark=null,lockBadges=null,squadBar=null,squadPick=null,frozenMarks=null,cardGrid=null,dealPanel=null,clubBar=null,sbcStorage=null,transfersHub=null,marketBotBar=null,marketFilterMemory=null,headBar=null,sbcWindow=null,sbcTab=null,sbcSet=null,sbcWarm=null,ladderWarm=null,storeGrid=null,storeCatalog=null,pickPrices=null,packShow=null,submitHook=null,workArea=null,marketBudget=null,dayBudget=null,snipeKey=null,itemPool=null,clubMirror=null,clubItemById=null,railPacksMemory=null,relistPricing=null,onNotice=()=>{},onError=()=>{},preferredPersonaId=null,isBlocked=()=>false,onSelectedPlayer=()=>{},legacyItemSurfaces=true}=deps
const focusedPlayer=typeof deps.focusedPlayer==='function'?deps.focusedPlayer:null
const criteriaOfCard=typeof deps.criteriaOfCard==='function'?deps.criteriaOfCard:null
const measureMarket=typeof deps.measureMarket==='function'?deps.measureMarket:null
const askConfirm=typeof deps.askConfirm==='function'?deps.askConfirm:async()=>false
const goSection=typeof deps.goSection==='function'
?(name)=>{try{return deps.goSection(name)??{ok:false,reason:'failed'}}catch(err){onError(err)
return{ok:false,reason:'failed'}}}
:()=>({ok:false,reason:'unavailable'})
const poolPeek=typeof deps.poolPeek==='function'?deps.poolPeek:null
const frame=typeof deps.frame==='function'?deps.frame:(fn)=>{fn()}
const noteCard=typeof deps.noteCard==='function'?deps.noteCard:null
const learn=noteCard===null?()=>{}:(item,source)=>{try{noteCard(item,source??'capture')}catch(err){onError(err)}}
const learnAll=(items,source)=>{for(const item of Array.isArray(items)?items:[])learn(item,source)}
const badgePriceOf=typeof deps.badgePriceOf==='function'?deps.badgePriceOf:null
const isCardLocked=typeof deps.isCardLocked==='function'?deps.isCardLocked:null
const noteRecreatedLocks=typeof deps.noteRecreatedLocks==='function'?deps.noteRecreatedLocks:null
const expensiveFrom=typeof deps.expensiveFrom==='function'?deps.expensiveFrom:null
const setExpensiveFrom=typeof deps.setExpensiveFrom==='function'?deps.setExpensiveFrom:null
const unassignedView=typeof deps.unassignedView==='function'?deps.unassignedView:null
const setUnassignedView=typeof deps.setUnassignedView==='function'?deps.setUnassignedView:null
const cardView=typeof deps.cardView==='function'?deps.cardView:null
const setCardView=typeof deps.setCardView==='function'?deps.setCardView:null
const notice=(key,params)=>onNotice({key,params:params??{}})
const paintFrame=typeof win?.requestAnimationFrame==='function'
?(fn)=>{try{win.requestAnimationFrame(fn)}catch(err){onError(err)}}
:null
const rewardFlow=createRewardFlow({isActive,t,frame:paintFrame===null?undefined:paintFrame,now:()=>clock.now(),say:notice,onError})
const promoClose=createPromoClose({isActive,t,frame:paintFrame===null?undefined:paintFrame,now:()=>clock.now(),say:notice,onError})
const offMarketBudget=offMarket(dayBudget)
const claimRewards=createClaimRewards({isActive,t,say:notice,onError,
budget:offMarketBudget,
read:()=>readHubRewards(win),
review:(one)=>(one?.kind==='group'
?reviewAction({win,action:'claim-group',groupId:one?.id})
:reviewAction({win,action:'claim',levelId:one?.id,pass:one?.pass===true})),
claim:async(one)=>{if(one?.kind==='group'){const group=findGroup(win,one?.id)
if(group===null)throw new Error('hub-rewards: награда задач ушла')
const done=await claimGroupReward(win,group.category,group.id)
return{rewards:done?.rewards??[],hasUTRewards:false}}
const found=findLevel(win,one?.id,one?.pass===true)
if(found===null)throw new Error('hub-rewards: награда ушла')
return claimHubReward(win,found.campaign,found.level)},
load:()=>loadObjectiveCategories(win),
now:()=>clock.now(),
grant:()=>grantHubItems(win),
kinds:(rewards)=>readRewardKinds(win,rewards),
loot:(rewards)=>readRewardLoot(win,rewards),
note:(got,opts)=>noteRewardLoot(win,got,opts),
sleep:(ms)=>new Promise((resolve)=>{setTimeout(resolve,ms)}),
onProgress:(step)=>{try{hubButton.progress(step)}catch(err){onError(err)}}})
const hubButton=createHubButton({doc,t,flow:claimRewards,onError})
const HOME_LAYOUT_FEATURE='homeLayout'
const homeLayoutAllowed=()=>{try{return isActive(HOME_LAYOUT_FEATURE)===true}catch(err){onError(err)
return false}}
const homeGrid=createHomeGrid({doc,onError})
let homeShown=null
const headTop=createHeadTop({doc,panelHost:()=>doc.getElementById?.(PANEL_ID)??null,onError})
const railPacks=createRailPacks({doc,t,isActive,onError,
button:()=>storeRailButton(win),
live:()=>unopenedPackCount(win),
fetch:()=>requestPackSplit(win),
budget:offMarketBudget,
memory:railPacksMemory,
now:()=>clock.now()})
const marketOrNull=()=>{try{return market?.()??null}catch{return null}}
const criteriaOrNull=()=>{try{return criteria?.()??null}catch{return null}}
const runMinBin=async(card=null)=>{const adapter=marketOrNull()
if(!adapter) return{ok:false,reason:'no-market'}
const named=card??focusedPlayerOrNull()
const target=minBinTarget({card:named,criteria:criteriaOrNull(),criteriaOfCard})
if(!target) return{ok:false,reason:'no-criteria'}
const measured={measured:target.measured,name:target.name}
const prior=target.measured==='card'?priceBadgePeek(named?.definitionId):null
let result
try{result=await findMinBin({adapter,criteria:target.criteria,clock,budget:marketBudget,prior,note:(lots)=>learnAll(lots,'market')})}catch(err){onError(err)
return{ok:false,reason:'failed'}}
if(result.stoppedBy==='converged'||result.stoppedBy==='request-limit'){return{ok:true,price:result.price,reason:result.stoppedBy,...measured}}
if(result.stoppedBy==='no-listings') return{ok:true,price:null,reason:'no-listings',...measured}
return{ok:false,reason:result.stoppedBy}}
const cardOfBadge=(item)=>{
const type=searchTypeOf(item)
const record=selectedPlayerRecord(item)
if(Number.isSafeInteger(record?.definitionId))return type===null?record:{...record,type}
const id=Number(item?.definitionId??item?.defId)
if(!Number.isSafeInteger(id)||id<=0)return null
return type===null?{definitionId:id,name:''}:{definitionId:id,name:'',type}}
const measureFromBadge=(item)=>{const card=cardOfBadge(item)
if(card===null)return null
return runAction('findMinBin',card)}
const focusedPlayerOrNull=()=>{try{return focusedPlayer?.()??null}catch{return null}}
const listCursor=createListCursor({doc,win,onError})
const inSbcSection=()=>{const roots=doc?.querySelectorAll?.(SBC_SCREEN_SELECTOR)
return Array.from(roots??[]).some((root)=>{const box=root?.getBoundingClientRect?.()
return box?Number(box.height)>0:true})}
let unassignedScreen=null
let unassignedSeen=0
let unassignedHadCards=false
let unassignedBack=null
const screenOf=()=>unassignedScreen
const lockedOf=(id)=>{if(!isCardLocked)return false
try{return isCardLocked(id)===true}catch(err){onError(err)
return true}}
const KNIFE_ANSWER_FRAMES=3600
const CONFIRM_WAIT_FRAMES=90
let knifeTicket=null
let knifeLast=null
const knifeFrame=(mine)=>{const next=win?.requestAnimationFrame
if(typeof next!=='function'){knifeTicket=null
return false}
try{next.call(win,()=>knifeLook(mine))}catch(err){onError(err)
knifeTicket=null
return false}
return true}
const knifePress=(how,before)=>{let got=null
try{got=ownConfirmButton(doc,before)}catch(err){onError(err)
return 'failed'}
if(got.why!=='own')return got.why
if(!pressNode(got.button,win,onError))return 'not-pressed'
if(knifeLast!==null)knifeLast.pressed=how
return 'own'}
const knifeGiveUp=(mine,word)=>{if(mine!==knifeTicket)return
knifeTicket=null
if(knifeLast!==null)knifeLast.pressed=word
try{unassignedBulk.knifeUnpressed(word)}catch(err){onError(err)}}
const knifeLook=(mine)=>{if(mine!==knifeTicket)return
mine.frames+=1
if(mine.pressed!==true){const why=knifePress('frame',mine.before)
if(why==='own'){mine.pressed=true
mine.frames=0
knifeFrame(mine)
return}
if(why==='not-primary'||why==='blind')return knifeGiveUp(mine,'foreign')
if(why==='stale')mine.saw=true
if(mine.frames>=CONFIRM_WAIT_FRAMES)return knifeGiveUp(mine,mine.saw===true?'foreign':'none')
knifeFrame(mine)
return}
if(unassignedBulk.pending()===null){knifeTicket=null
if(knifeLast!==null)knifeLast.done='taken'
return}
if(mine.frames<KNIFE_ANSWER_FRAMES){knifeFrame(mine)
return}
knifeTicket=null
let open=false
try{open=confirmButton(doc)!==null}catch(err){onError(err)
open=false}
const key=open?'unassigned.knife':'unassigned.knifeOff'
if(knifeLast!==null)knifeLast.done=open?'waiting':'cancelled'
try{unassignedStrip.say(t(key,{count:mine.cards}))}catch(err){onError(err)}
notice(key,{count:mine.cards})}
const unassignedBulk=createUnassignedBulk({screen:screenOf,win,onError,budget:offMarketBudget,
beforeKnife:()=>{try{return visibleDialogs(doc)}catch(err){onError(err)
return null}},
onKnife:({cards,before})=>{knifeTicket={frames:0,cards:Number.isSafeInteger(cards)?cards:0,pressed:false,
before:Array.isArray(before)?before:null,saw:false}
knifeLast={cards:knifeTicket.cards,pressed:'none',done:null,at:clock.now()}
if(knifePress('now',knifeTicket.before)==='own'){knifeTicket.pressed=true
return knifeFrame(knifeTicket)}
return knifeFrame(knifeTicket)}})
const unassignedStrip=createUnassignedStrip({doc,t,onError,priceOf:badgePriceOf===null?undefined:(card)=>badgePriceOf(card),isLocked:lockedOf,expensiveFrom:expensiveFrom===null?undefined:()=>expensiveFrom(),setExpensiveFrom:setExpensiveFrom===null?undefined:(value)=>setExpensiveFrom(value),
view:unassignedView===null?undefined:()=>unassignedView(),setView:setUnassignedView===null?undefined:(patch)=>setUnassignedView(patch),isActive,
cardView:cardView===null?undefined:()=>cardView(),setCardView:setCardView===null?undefined:(next)=>setCardView(next),
frame:paintFrame===null?undefined:paintFrame,
perform:createUnassignedPerform({screen:screenOf,win,budget:offMarketBudget}),
onIdle:()=>{try{maybeGoBack()}catch(err){onError(err)}},
native:createUnassignedNativeStep({bulk:unassignedBulk}),sleep:(ms)=>clock.sleep(ms)})
const relistConsent=createDoorConsent({now:()=>clock.now()})
const bulkNote=(door,result)=>{if(result.ok===true){const key={club:'unassigned.bulk.club',storage:'unassigned.bulk.storage',quickSellItems:'unassigned.bulk.quickSellItems',quickSell:'unassigned.bulk.quickSell'}[door]
const params={cards:result.cards,coins:result.coins,stays:result.stays}
const main=t(key,params)
const tail=result.locked>0?` ${t('unassigned.bulk.locked',{count:result.locked})}`:''
notice(key,params)
return `${main}${tail}`}
const overridable={'busy-timeout':'unassigned.bulk.pending','locked-card':'unassigned.bulk.lockedCard',
'unreadable-locks':'unassigned.bulk.locksUnreadable'}[result.uncertain]
if(overridable!==undefined){const params={count:result.locked??0}
notice(overridable,params)
return t(overridable,params)}
if(result.verdict===UNKNOWN){notice('unassigned.bulk.unknown')
return t('unassigned.bulk.unknown')}
if(result.reason==='capacity'){const params={fits:result.fits??0,need:result.need??0}
notice('unassigned.bulk.capacity',params)
return t('unassigned.bulk.capacity',params)}
const key={empty:'unassigned.bulk.empty','nothing-to-do':'unassigned.bulk.nothing','no-screen':'unassigned.bulk.noScreen',gone:'unassigned.bulk.noScreen','no-storage':'unassigned.bulk.noStorage',busy:'unassigned.bulk.busy',predicate:'unassigned.bulk.nothing'}[result.reason]
??'unassigned.bulk.failed'
notice(key)
return t(key)}
const unassignedEmpty=()=>{const one=unassignedScreen
return one!==null&&one.box?.isConnected!==false
&&(one.cards?.length??0)===0&&(one.unreadable??0)===0}
const maybeGoBack=()=>{if(!unassignedHadCards)return
if(!unassignedEmpty())return
if(storeGrid?.state?.()?.bulk?.running)return
if(unassignedStrip.state().run?.running===true)return
if(backingToStore)return
backingToStore=true
unassignedHadCards=false
frame(()=>{void (async()=>{try{
const plan=backPlan(win)
const stop=await askDayBudget(offMarketBudget,plan.calls)
if(stop!==null){unassignedBack={ok:false,reason:stop}
return}
try{unassignedBack=goStorePacks(win)}catch(err){onError(err)
unassignedBack={ok:false,reason:'failed'}}
if(unassignedBack?.ok===true)notice('unassigned.bulk.backToStore')}
catch(err){onError(err)}
finally{backingToStore=false}})()})}
const pressSearch=()=>{const node=pressTarget(doc,HOTKEY_ACTIONS.marketSearch)
if(!node)return false
return pressNode(node,win,onError)}
const onMarketScreen=()=>layerVisible(doc,'marketAny')
const openBulkDoor=(door)=>{const result=unassignedBulk.open(door)
try{unassignedStrip.say(bulkNote(door,result))}catch(err){onError(err)}
if(result.ok===true&&result.reason==='confirm'){try{hotkeys.confirm.arm(unassignedScreen?.box??null)}catch(err){onError(err)}}
return result}
async function runAction(action,card=null){if(action==='findMinBin'){notice('bin.searching')
const result=await runMinBin(card)
onNotice({key:keyOfLabel(result),params:{coins:result.price??0,name:result.name??''}})
return result}
if(action==='listAtMin'){const result=await(sellSidebar?.priceAtMarketMin?.()??{ok:false,reason:'unavailable'})
onNotice(listAtMinNotice(result))
return result}
if(action==='freezeCard'){const result=frozenMarks?.toggleShown?.()??{ok:false,reason:'unavailable'}
if(!result.ok)notice(result.reason==='no-card'?'frozen.notice.noCard':'frozen.notice.failed')
return result}
if(action==='bulkToClub')return openBulkDoor('club')
if(action==='bulkToStorage')return openBulkDoor('storage')
if(action==='bulkQuickSellItems')return openBulkDoor('quickSellItems')
if(action==='bulkQuickSell')return openBulkDoor('quickSell')
if(action==='nextCard'||action==='prevCard'||action==='cardRight'||action==='cardLeft'){const across=action==='cardRight'||action==='cardLeft'
const result=listCursor.step(action==='nextCard'||action==='cardRight'?1:-1,across?AXIS_X:AXIS_Y)
if(result.ok)notice('hotkeys.cardPicked',{index:result.index,total:result.total})
else notice(result.reason==='edge'?'hotkeys.listEdge':'hotkeys.noList')
return result}
if(action==='rowEnter'){const result=listCursor.enter()
if(!result.ok)notice(result.reason==='by-hand'?'hotkeys.packByHand':'hotkeys.noList')
return result}
if(action==='openSbc'){if(inSbcSection()){notice('hotkeys.sbc.here')
return{ok:false,reason:'already-here'}}
const result=goSection('SBC')
if(!result.ok)notice('hotkeys.sbc.unavailable')
return result}
if(action==='relistAll'){const raw=marketOrNull()
if(!raw){notice('hotkeys.relistFailed')
return{ok:false,reason:'no-market'}}
const adapter=meterCalls(raw,offMarketBudget,['requestTransferItems','relist'],{stage:'relist-all'})
let budgetWord=null
const readRows=async()=>{try{return extractItems(await adapter.requestTransferItems())}catch(err){
if(isDayBudgetError(err)){budgetWord=err.reason
return null}
onError(err)
return null}}
const budgetStop=()=>{if(budgetWord===null)return null
notice(keyOfLabel({ok:false,reason:budgetWord}))
return{ok:false,reason:budgetWord,count:0}}
const rowIds=(rows)=>(Array.isArray(rows)?rows.map((row)=>row?.id).filter((id)=>id!==undefined&&id!==null):null)
let rows=await readRows()
const stoppedEarly=budgetStop()
if(stoppedEarly!==null)return stoppedEarly
const door=adapter.review({action:'relist',rows})
if(door.verdict===UNKNOWN){if(!relistConsent.ask(doorConsentKey({action:'relist',reason:door.reason,destination:'TRANSFER',ids:rowIds(rows),unreadable:door.unreadable}))){notice(door.reason==='unreadable-market'?'hotkeys.relistUnavailable':'hotkeys.relistUncertain')
return{ok:false,reason:'uncertain'}}}
else{relistConsent.forget()
if(door.verdict!==ALLOWED){notice(door.reason==='market-off'?'hotkeys.relistUnavailable':'hotkeys.relistNone')
return{ok:false,reason:door.reason==='market-off'?'market-off':'nothing-to-do',count:0}}}
const agreed=await askConfirm({titleKey:'hotkeys.action.relistAll',messageKey:'hotkeys.relistConfirm'})
if(agreed!==true)return{ok:false,reason:'cancelled'}
rows=await readRows()
const stoppedLate=budgetStop()
if(stoppedLate!==null)return stoppedLate
try{const data=await adapter.relist(rows)
if(!data
||typeof data!=='object'
||Array.isArray(data)
||!Array.isArray(data.auctionIds)){throw new Error('relist: EA вернула неизвестную форму результата')}
const count=data.auctionIds.length
if(count===0){notice('hotkeys.relistNone')
return{ok:true,reason:'none',count:0}}
notice('hotkeys.relisted',{count})
return{ok:true,reason:null,count}}catch(err){
if(isDoorRefusal(err)){notice(err.door?.reason==='market-off'?'hotkeys.relistUnavailable':'hotkeys.relistNone')
return{ok:false,reason:'nothing-to-do',count:0}}
if(isDayBudgetError(err)){notice(keyOfLabel({ok:false,reason:err.reason}))
return{ok:false,reason:err.reason,count:0}}
onError(err)
notice('hotkeys.relistFailed')
return{ok:false,reason:'failed'}}}
if(action==='repeatSearch'){const adapter=marketOrNull()
if(!adapter){notice('hotkeys.searchFailed')
return{ok:false,reason:'no-market'}}
const current=criteriaOrNull()
if(!current){notice('bin.noCriteria')
return{ok:false,reason:'no-criteria'}}
const refusal=marketBudget?.take?.()??null
if(refusal!==null){let wait=null
try{wait=marketBudget?.waitMs?.()??null}catch{wait=null}
notice(keyOfLabel({ok:false,reason:refusal,waitMs:wait}),{seconds:Math.max(1,Math.ceil(Number(wait??0)/1000))})
return{ok:false,reason:refusal}}
if(typeof adapter.clearMarketCache==='function'){try{adapter.clearMarketCache()}catch{
}}
try{const data=await adapter.searchTransferMarket(current,1)
notice('hotkeys.searchRepeated',{count:countListings(data)})
return{ok:true,reason:null}}catch(err){onError(err)
notice('hotkeys.searchFailed')
return{ok:false,reason:'failed'}}}
if(action==='snipeChain'){const result=await(snipeKey?.press?.({pressSearch,onScreen:onMarketScreen})??null)
if(result===null){notice('snipeKey.unavailable')
return{ok:false,reason:'unavailable'}}
onNotice(result.notice??{key:'snipeKey.unavailable',params:{}})
return result}
notice('hotkeys.notWired')
return{ok:false,reason:'not-wired'}}
function keyOfLabel(result){
return minBinLabel(result,(key)=>key)}
const hotkeys=installHotkeys({doc,win,t,isActive,isBlocked,onNotice,onError,goSection,run:(action)=>runAction(action),read:()=>deps.hotkeyState?.()??{},write:(next)=>deps.saveHotkeyState?.(next)})
const dropLiveCriteria=publishLiveCriteria({read:()=>readMarketFilterCriteria(win)?.criteria??null,
apply:(criteria)=>{const put=restoreLiveMarketCriteria(win,criteria)
if(put?.ok===true)marketFilterMemory?.noteWrite?.()
return put}})
let scheduled=false
let observer=null
const scheduleRefresh=()=>{if(scheduled)return
scheduled=true
Promise.resolve().then(()=>{scheduled=false
try{refresh()}catch(err){onError(err)}})}
const relabel=()=>{relabelPriceBadges()
const sell=sellSidebar?.relabel?.()===true
const locks=cardLockMark?.relabel?.()===true
lockBadges?.relabel?.()
squadBar?.refresh?.()
squadPick?.refresh?.()
frozenMarks?.relabel?.()
cardGrid?.relabel?.()
dealPanel?.relabel?.()
clubBar?.relabel?.()
sbcStorage?.relabel?.()
transfersHub?.relabel?.()
marketBotBar?.relabel?.()
headBar?.relabel?.()
hubButton?.relabel?.()
railPacks?.relabel?.()
const sbc=sbcWindow?.relabel?.()===true
sbcTab?.relabel?.()
sbcSet?.relabel?.()
const market=marketSearchQuick?.relabel?.()===true
storeGrid?.relabel?.()
storeCatalog?.relabel?.()
pickPrices?.relabel?.()
unassignedStrip.relabel()
refresh()
return{sell,locks,sbc,market}}
const refresh=()=>{ensureNativeCaptures();marketSearchQuick?.refresh?.();sellSidebar?.refresh?.();cardLockMark?.refresh?.();sbcWindow?.refresh?.();storeGrid?.refresh?.();storeCatalog?.refresh?.()
pickPrices?.refresh?.()
unassignedStrip.refresh()
hotkeys.refresh()
sbcTab?.refresh?.()
sbcSet?.refresh?.()
const badges=enhancePriceBadges({doc,t,isActive,itemOf:itemForEvidenceRow,priceOf:badgePriceOf,measure:measureFromBadge})
badges.pending?.catch?.(onError)
lockBadges?.refresh?.()
squadBar?.refresh?.()
squadPick?.refresh?.()
frozenMarks?.refresh?.()
headBar?.refresh?.()
headTop.refresh()
if(!homeLayoutAllowed())homeGrid.dispose()
else if(homeShown!==null&&homeGrid.state().attached!==true){try{homeGrid.apply(homeShown)}catch(err){onError(err)}}
cardGrid?.refresh?.()
dealPanel?.refresh?.()
clubBar?.refresh?.()
sbcStorage?.refresh?.()
transfersHub?.refresh?.()
marketBotBar?.refresh?.()
marketFilterMemory?.refresh?.()
hubButton?.refresh?.()
railPacks?.refresh?.()
const isActiveSurface=isActive
return{transferList:enhanceTransferList({doc,t,isActive:isActiveSurface,
relistPricing,
dayBudget:offMarketBudget,
measureMarket}),badges}}
let evidenceCapture={ok:false,reason:'unavailable',dispose(){}}
let quickListCapture={ok:false,reason:'unavailable',dispose(){}}
let detailsCapture={ok:false,reason:'unavailable',dispose(){}}
let squadSlotCapture={ok:false,reason:'unavailable',dispose(){}}
let squadScreenCapture={ok:false,reason:'unavailable',dispose(){}}
let squadActionsCapture={ok:false,reason:'unavailable',dispose(){}}
let clubPickCapture={ok:false,reason:'unavailable',dispose(){}}
let sbcScreenCapture={ok:false,reason:'unavailable',dispose(){}}
let sbcSetCapture={ok:false,reason:'unavailable',dispose(){}}
let sbcHubCapture={ok:false,reason:'unavailable',dispose(){}}
let sbcWarmCapture={ok:false,reason:'unavailable',dispose(){}}
let sbcLadderWarmCapture={ok:false,reason:'unavailable',dispose(){}}
let storePacksCapture={ok:false,reason:'unavailable',dispose(){}}
let storeCatalogCapture={ok:false,reason:'unavailable',dispose(){}}
let storeTabCapture={ok:false,reason:'unavailable',dispose(){}}
let storeJumpPending=false
let backingToStore=false
let packOpenCapture={ok:false,reason:'unavailable',dispose(){}}
let packBulkOpenCapture={ok:false,reason:'unavailable',dispose(){}}
let packAnimationCapture={ok:false,reason:'unavailable',dispose(){}}
let pickScreenCapture={ok:false,reason:'unavailable',dispose(){}}
let pickControlsCapture={ok:false,reason:'unavailable',dispose(){}}
let unassignedCapture={ok:false,reason:'unavailable',dispose(){}}
let itemEvents={ok:false,reason:'unavailable',missing:[],dispose(){}}
let rewardsCapture={ok:false,reason:'unavailable',state:()=>({ok:false,reason:'unavailable',marked:0,shown:0,foreign:0}),dispose(){}}
let promoCapture={ok:false,reason:'unavailable',state:()=>({ok:false,reason:'unavailable',shown:0,foreign:0}),dispose(){}}
let storageCapture={ok:false,reason:'unavailable',dispose(){}}
let homeHubCapture={ok:false,reason:'unavailable',state:()=>({ok:false,reason:'unavailable',shown:0}),dispose(){}}
let railPacksCapture={ok:false,reason:'unavailable',dispose(){}}
let railOpenCapture={ok:false,reason:'unavailable',dispose(){}}
let objectiveWatch={ok:false,reason:'unavailable',dispose(){}}
function ensureNativeCaptures(){
try{ensureNotFoundWatch(win,doc,{isActive})}catch(err){onError(err)}
if(!evidenceCapture.ok)evidenceCapture=installItemEvidenceCapture(win,(row,item)=>{learn(item)
scheduleRefresh()})
if(!quickListCapture.ok)quickListCapture=installQuickListCapture(win,(capture)=>{learn(capture?.item)
try{sellSidebar?.apply?.(capture)}catch(err){onError(err)}})
if(!detailsCapture.ok)detailsCapture=installItemDetailsCapture(win,(capture)=>{learn(capture?.item)
try{cardLockMark?.apply?.(capture)}catch(err){onError(err)}
try{frozenMarks?.apply?.(capture)}catch(err){onError(err)}
try{notePriceBadgeCard(capture?.root,capture?.item)}catch(err){onError(err)}
try{dealPanel?.apply?.(capture)}catch(err){onError(err)}})
if(!squadSlotCapture.ok)squadSlotCapture=installSquadSlotCapture(win,(root,item)=>{learn(item)
try{notePriceBadgeCard(root,item)}catch(err){onError(err)}
try{lockBadges?.note?.(root,item)}catch(err){onError(err)}
try{squadBar?.refresh?.()}catch(err){onError(err)}})
if(!squadScreenCapture.ok)squadScreenCapture=installSquadScreenCapture(win,(capture)=>{
try{squadBar?.apply?.(capture)}catch(err){onError(err)}})
if(!squadActionsCapture.ok)squadActionsCapture=installSquadActionsCapture(win,(capture)=>{
try{squadBar?.applyActions?.(capture)}catch(err){onError(err)}})
if(!clubPickCapture.ok)clubPickCapture=installClubPickCapture(win,(capture)=>{
try{squadPick?.apply?.(capture)}catch(err){onError(err)}})
if(!sbcScreenCapture.ok&&sbcScreenCapture.permanent!==true){sbcScreenCapture.dispose()
sbcScreenCapture=installSbcScreenCapture(win,(capture)=>{try{sbcWarm?.stop?.('challenge')}catch(err){onError(err)}
try{ladderWarm?.rush?.('challenge')}catch(err){onError(err)}
try{sbcWindow?.apply?.(capture)}catch(err){onError(err)}})}
if(!sbcSetCapture.ok&&sbcSetCapture.permanent!==true&&sbcSet!==null){sbcSetCapture.dispose()
sbcSetCapture=installSbcSetCapture(win,(capture)=>{try{sbcSet.apply(capture)}catch(err){onError(err)}
try{ladderWarm?.applySet?.(capture)}catch(err){onError(err)}})}
if(!sbcHubCapture.ok&&sbcTab!==null){sbcHubCapture=installSbcHubCapture(win,(capture)=>{try{sbcTab.apply(capture)}catch(err){onError(err)}})}
if(!sbcLadderWarmCapture.ok&&ladderWarm!==null){sbcLadderWarmCapture=installSbcHubCapture(win,()=>{try{ladderWarm.applyHub()}catch(err){onError(err)}})}
if(!sbcWarmCapture.ok&&sbcWarm!==null){sbcWarmCapture=installSbcHubCapture(win,(capture)=>{try{sbcWarm.apply(capture)}catch(err){onError(err)}})}
if(!storePacksCapture.ok&&storeGrid!==null){storePacksCapture=installStorePacksCapture(win,(capture)=>{try{storeGrid.apply(capture)}catch(err){onError(err)}})}
if(!storeCatalogCapture.ok&&storeCatalog!==null){storeCatalogCapture=installStoreCatalogCapture(win,(capture)=>{try{storeCatalog.apply(capture)}catch(err){onError(err)}})}
if(!railPacksCapture.ok&&railPacks!==null){railPacksCapture=installStorePacksCapture(win,(capture)=>{try{railPacks.apply(capture)}catch(err){onError(err)}})}
if(!homeHubCapture.ok&&hubButton!==null){homeHubCapture=installHomeHubCapture(win,(shown)=>{try{hubButton.apply(shown)}catch(err){onError(err)}
homeShown=shown
if(homeLayoutAllowed()){try{homeGrid.apply(shown)}catch(err){onError(err)}}
try{railPacks?.refresh?.()}catch(err){onError(err)}
void claimRewards.load().then((done)=>{if(done?.ok===true){try{hubButton.refresh()}catch(err){onError(err)}}}).catch(onError)
void railPacks?.load?.().catch?.(onError)})}
if(!objectiveWatch.ok&&hubButton!==null){objectiveWatch=installObjectiveRewardWatch(win,()=>{claimRewards.invalidate()
void claimRewards.load().then(()=>{try{hubButton.refresh()}catch(err){onError(err)}}).catch(onError)})}
if(!storeTabCapture.ok&&storeGrid!==null){storeTabCapture=installStoreTabCapture(win,({nav})=>{if(storeGrid.wantsMyPacks?.()!==true)return
if(storeJumpPending)return
storeJumpPending=true
const jump=async()=>{try{
const stop=await askDayBudget(offMarketBudget,BACK_CALLS)
if(stop!==null){storeGrid.noteJump?.({ok:false,reason:stop})
return}
try{storeGrid.noteJump?.(openMyPacks(win,nav))}catch(err){onError(err)}}
catch(err){onError(err)}
finally{storeJumpPending=false}}
if(typeof win?.requestAnimationFrame==='function')win.requestAnimationFrame(()=>{void jump()})
else setTimeout(()=>{void jump()},0)})}
if(!packOpenCapture.ok&&packShow!==null){packOpenCapture=installPackOpenCapture(win,(capture)=>{try{packShow.noteContents(capture)}catch(err){onError(err)}})}
if(!packBulkOpenCapture.ok&&storeGrid!==null){packBulkOpenCapture=installPackOpenCapture(win,(capture)=>{try{storeGrid.noteOpen?.(capture)}catch(err){onError(err)}})}
if(!railOpenCapture.ok&&railPacks!==null){railOpenCapture=installPackOpenCapture(win,(capture)=>{if(capture?.ok!==true||capture?.myPack!==true)return
try{railPacks.noteOpened(capture.packId)}catch(err){onError(err)}})}
if(!pickControlsCapture.ok&&pickPrices!==null){pickControlsCapture=installPlayerPickControls(win)}
if(!pickScreenCapture.ok&&pickPrices!==null){pickScreenCapture=installPlayerPicksCapture(win,(capture)=>{try{pickPrices.apply(capture)}catch(err){onError(err)}})}
if(!unassignedCapture.ok){unassignedCapture=installUnassignedScreenCapture(win,(capture)=>{unassignedScreen=capture
unassignedSeen+=1
try{unassignedBulk.settled()}catch(err){onError(err)}
try{unassignedStrip.apply(capture)}catch(err){onError(err)}
if(capture.cards.length>0||capture.unreadable>0)unassignedHadCards=true
else maybeGoBack()})}
if(!packAnimationCapture.ok&&packShow!==null){packAnimationCapture=installPackAnimationCapture(win,(context)=>{try{return packShow.decide(context)}catch(err){onError(err)
return null}})}
if(!rewardsCapture.ok)rewardsCapture=installGameRewardsCapture(win,(shown)=>{try{rewardFlow.appeared(shown)}catch(err){onError(err)}})
if(!promoCapture.ok)promoCapture=installLiveMessageCapture(win,(shown)=>{try{promoClose.appeared(shown)}catch(err){onError(err)}})
if(!storageCapture.ok)storageCapture=installStorageScreenCapture(win,()=>{try{sbcStorage?.refresh?.()}catch(err){onError(err)}})
try{submitHook?.install?.()}catch(err){onError(err)}
try{workArea?.install?.()}catch(err){onError(err)}
if(!itemEvents.ok&&itemPool!==null){const applyToPool=(event)=>{try{applyItemEvent(itemPool,event,clubItemById)}catch(err){onError(err)}}
itemEvents=installItemEvents(win,(event)=>{if(event?.name==='ITEM_MOVE'&&event?.to==='CLUB')frame(()=>applyToPool(event))
else applyToPool(event)
const applyToMirror=()=>{try{clubMirror?.applyEvent?.(event,clubItemById)}catch(err){onError(err)}}
if(event?.name==='ITEM_MOVE'&&event?.to==='CLUB')frame(applyToMirror)
else applyToMirror()
learnAll(event?.items,'event')
try{sbcWindow?.invalidate?.(event?.ids,event?.name)}catch(err){onError(err)}
if(event?.name==='ITEM_UNDO_DISCARD'&&noteRecreatedLocks!==null){try{noteRecreatedLocks(event?.ids)}catch(err){onError(err)}}
if(event?.name==='ITEM_DISCARD'||event?.name==='ITEM_CLEARSOLD'){try{forgetPurchases(event?.ids)}catch(err){onError(err)}}
try{sbcStorage?.left?.(event)}catch(err){onError(err)}})
try{itemPool.subscribed?.(itemEvents.ok,itemEvents.missing)}catch(err){onError(err)}
try{clubMirror?.subscribed?.(itemEvents.ok,itemEvents.missing)}catch(err){onError(err)}}
return{evidence:evidenceCapture.ok,quickList:quickListCapture.ok,details:detailsCapture.ok,squadSlot:squadSlotCapture.ok,squadScreen:squadScreenCapture.ok,squadActions:squadActionsCapture.ok,clubPick:clubPickCapture.ok,sbcScreen:sbcScreenCapture.ok,sbcHub:sbcHubCapture.ok,storageScreen:storageCapture.ok,storePacks:storePacksCapture.ok,storeCatalog:storeCatalogCapture.ok,storeTab:storeTabCapture.ok,packOpen:packOpenCapture.ok,packBulkOpen:packBulkOpenCapture.ok,packAnimation:packAnimationCapture.ok,pickScreen:pickScreenCapture.ok,pickControls:pickControlsCapture.ok,unassignedScreen:unassignedCapture.ok,gameRewards:rewardsCapture.ok,liveMessage:promoCapture.ok,submitGuard:submitHook?.state?.()?.ok===true,workArea:workArea?.state?.()?.installed===true,itemEvents:itemEvents.ok}}
const selectedPlayerCapture=installSelectedPlayerCapture({doc,win,itemForRow:itemForEvidenceRow,onSelect:onSelectedPlayer})
refresh()
const landingWatch=createLandingWatch({door:createLandingDoor(doc,win,{onError}),isActive})
const Observer=win?.MutationObserver
const observeRoot=doc?.body??doc?.documentElement??null
if(typeof Observer==='function'&&observeRoot){observer=new Observer(()=>{try{landingWatch.tick()}catch(err){onError(err)}
scheduleRefresh()})
observer.observe(observeRoot,{childList:true,subtree:true})}
const autologin=startAutologin({personas,clock,isActive,preferredId:preferredPersonaId,landing:landingWatch}).catch((err)=>{onError(err);
return{ok:false,reason:'failed',landing:landingWatch.report()}})
void autologin.then(()=>{landingWatch.disarm()},()=>{landingWatch.disarm()})
return{hotkeys,autologin,refresh,relabel,runAction,ensureNativeCaptures,
unassigned:()=>({strip:unassignedStrip.state(),bulk:unassignedBulk.state(),
seen:unassignedSeen,screen:unassignedScreen===null?null:{cards:unassignedScreen.cards.length,unreadable:unassignedScreen.unreadable,storage:unassignedScreen.storage,capacity:unassignedScreen.capacity,connected:unassignedScreen.box?.isConnected!==false},
back:{armed:unassignedHadCards,last:unassignedBack===null?null:{...unassignedBack}},
knife:knifeLast===null?null:{...knifeLast,watching:knifeTicket!==null},
capture:{ok:unassignedCapture.ok,reason:unassignedCapture.reason}}),
captures:()=>({evidence:evidenceCapture.ok,quickList:quickListCapture.ok,details:detailsCapture.ok,detailsMissing:[...(detailsCapture.missing??[])],sbcScreen:sbcScreenCapture.ok,sbcScreenMissing:[...(sbcScreenCapture.missing??[])],
sbcScreenRefused:[...(sbcScreenCapture.refused??[])],
sbcScreenWrapped:[...(sbcScreenCapture.wrapped??[])],sbcScreenPermanent:sbcScreenCapture.permanent===true,
sbcSet:sbcSetCapture.ok,sbcSetReason:sbcSetCapture.reason,sbcSetPermanent:sbcSetCapture.permanent===true,
sbcHub:sbcHubCapture.ok,sbcHubReason:sbcHubCapture.reason,sbcWarm:sbcWarmCapture.ok,sbcLadderWarm:sbcLadderWarmCapture.ok,
storePacks:storePacksCapture.ok,
storeTab:storeTabCapture.ok,
packOpen:packOpenCapture.ok,packAnimation:packAnimationCapture.ok,
pickScreen:pickScreenCapture.ok,pickControls:pickControlsCapture.ok,
unassignedScreen:unassignedCapture.ok,
gameRewards:rewardsCapture.ok,gameRewardsReason:rewardsCapture.reason??null,
liveMessage:promoCapture.ok,liveMessageReason:promoCapture.reason??null,
submitGuard:submitHook?.state?.()?.ok===true,
storageScreen:storageCapture.ok,storageScreenReason:storageCapture.reason??null,
workArea:workArea?.state?.()?.installed===true,
itemEvents:itemEvents.ok,itemEventsMissing:[...(itemEvents.missing??[])]}),
sbcTab:(opts)=>sbcTab?.state?.(opts)??null,
sbcSet:()=>sbcSet?.state?.()??null,
rewardFlow:()=>({...rewardFlow.state(),capture:rewardsCapture.state()}),
promoClose:()=>({...promoClose.state(),capture:promoCapture.state()}),
storage:()=>(sbcStorage===null?null:{...sbcStorage.state(),capture:{ok:storageCapture.ok,reason:storageCapture.reason??null}}),
hubRewards:()=>({...claimRewards.state(),view:claimRewards.view(),facts:claimRewards.facts(),
button:hubButton.state(),capture:homeHubCapture.state()}),
homeGrid:()=>homeGrid.state(),
headTop:()=>headTop.state(),
railPacks:()=>({...railPacks.state(),openWatch:railOpenCapture.reason}),dispose(){hotkeys.dispose()
evidenceCapture.dispose()
selectedPlayerCapture.dispose()
quickListCapture.dispose()
detailsCapture.dispose()
squadSlotCapture.dispose()
squadScreenCapture.dispose()
squadActionsCapture.dispose()
clubPickCapture.dispose()
sbcScreenCapture.dispose()
sbcHubCapture.dispose()
storePacksCapture.dispose()
storeCatalogCapture.dispose()
storeTabCapture.dispose()
packOpenCapture.dispose()
packBulkOpenCapture.dispose()
packAnimationCapture.dispose()
pickScreenCapture.dispose()
pickControlsCapture.dispose()
unassignedCapture.dispose()
rewardsCapture.dispose()
rewardFlow.dispose()
promoCapture.dispose()
promoClose.dispose()
unassignedStrip.dispose()
knifeTicket=null
unassignedBulk.dispose()
itemEvents.dispose()
sellSidebar?.dispose?.()
cardLockMark?.dispose?.()
lockBadges?.dispose?.()
squadBar?.dispose?.()
squadPick?.dispose?.()
frozenMarks?.dispose?.()
cardGrid?.dispose?.()
dealPanel?.dispose?.()
clubBar?.dispose?.()
storageCapture.dispose()
sbcStorage?.dispose?.()
transfersHub?.dispose?.()
marketBotBar?.dispose?.()
marketFilterMemory?.dispose?.()
dropLiveCriteria()
hubButton?.dispose?.()
homeGrid?.dispose?.()
headTop.dispose()
headBar?.dispose?.()
railPacks?.dispose?.()
homeHubCapture.dispose()
railPacksCapture.dispose()
railOpenCapture.dispose()
objectiveWatch.dispose()
sbcWindow?.dispose?.()
sbcTab?.dispose?.()
sbcSet?.dispose?.()
try{sbcSetCapture.dispose()}catch(err){onError(err)}
sbcWarm?.dispose?.()
sbcWarmCapture.dispose()
ladderWarm?.dispose?.()
sbcLadderWarmCapture.dispose()
storeGrid?.dispose?.()
storeCatalog?.dispose?.()
pickPrices?.dispose?.()
packShow?.dispose?.()
submitHook?.dispose?.()
marketSearchQuick?.dispose?.()
snipeKey?.dispose?.()
dropAllPriceBadges(doc)
observer?.disconnect?.()}}}
