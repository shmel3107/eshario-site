import { defaultToggles, sanitize as sanitizeFeatures } from '../settings/index.js';
import {
MAX_BYTES as MAX_FILTER_BYTES, MAX_SETS, sanitizeStored,
} from '../features/filter-store.js';
import { parseFilterSet } from '../features/filters.js';
import { sanitizeLimitInput } from '../features/automation-actions.js';
import { sanitizeOptionInput } from '../automation/options-input.js';
import { sanitizeSellerOptions } from '../features/seller-actions.js';
import { defaultUiState, sanitizeUiState } from '../features/ui-state.js';
import { sanitizePackLocks } from '../features/pack-locks.js';
export const SYNC_SCHEMA = 1;
export const SYNC_STATE_KEY = 'settings.sync';
export const MAX_SYNC_BYTES = 96 * 1024;
export const SYNC_NAMESPACES = Object.freeze([
'features', 'filters', 'buyerLimits', 'buyerOptions', 'sellerOptions',
'interface', 'packLocks',
]);
export const SYNC_STORAGE_KEYS = Object.freeze({
features: 'settings.toggles',
filters: 'filters.sets',
buyerLimits: 'automation.limits',
buyerOptions: 'automation.options',
sellerOptions: 'seller.options',
interface: 'ui.state',
packLocks: 'packs.locks',
});
export const EXCLUDED_STORAGE_KEYS = Object.freeze([
'account.session', 'license.key', 'automation.journal',
'automation.ledger', 'live.control', 'card.locks', 'rarity.groups',
'demand.memory', 'market.daybudget', 'market.buyrate',
'sbc.rate',
'club.mirror.head',
'card.frozen',
'purchase.log',
'cards.seed',
'preview.packs',
SYNC_STATE_KEY,
]);
const copy = (value) => JSON.parse(JSON.stringify(value));
const object = (value) => value && typeof value === 'object' && !Array.isArray(value);
function sanitizeFilters(raw) {
const out = [];
for (const line of sanitizeStored(raw)) {
if (!parseFilterSet(line).ok) continue;
if (out.length >= MAX_SETS) break;
const next = [...out, line];
if (JSON.stringify(next).length > MAX_FILTER_BYTES) break;
out.push(line);
}
return out;
}
function sanitizeInterface(raw) {
const value = sanitizeUiState(raw);
return { filters: [...value.filters], sbcPolicy: copy(value.sbcPolicy) };
}
export function defaultSyncNamespaces() {
return {
features: defaultToggles(),
filters: [],
buyerLimits: sanitizeLimitInput(null),
buyerOptions: sanitizeOptionInput(null),
sellerOptions: sanitizeSellerOptions(null),
interface: sanitizeInterface(defaultUiState()),
packLocks: [],
};
}
export function sanitizeSyncNamespaces(raw) {
const value = object(raw) ? raw : {};
return {
features: sanitizeFeatures(value.features),
filters: sanitizeFilters(value.filters),
buyerLimits: sanitizeLimitInput(value.buyerLimits),
buyerOptions: sanitizeOptionInput(value.buyerOptions),
sellerOptions: sanitizeSellerOptions(value.sellerOptions),
interface: sanitizeInterface(value.interface),
packLocks: sanitizePackLocks(value.packLocks),
};
}
export function syncBytes(namespaces) {
return new TextEncoder().encode(JSON.stringify(sanitizeSyncNamespaces(namespaces))).length;
}
export function parseRemoteSettings(raw) {
if (raw?.schema !== SYNC_SCHEMA) return { ok: false, reason: 'schema' };
if (typeof raw?.subject !== 'string' || raw.subject === '') {
return { ok: false, reason: 'subject' };
}
if (!Number.isSafeInteger(raw?.revision) || raw.revision < 0) {
return { ok: false, reason: 'revision' };
}
if (typeof raw?.initialized !== 'boolean') return { ok: false, reason: 'initialized' };
if (!raw.initialized) {
if (raw.namespaces !== null) return { ok: false, reason: 'namespaces' };
return { ok: true, value: {
schema: SYNC_SCHEMA, subject: raw.subject, revision: raw.revision,
initialized: false, namespaces: null,
} };
}
if (!object(raw.namespaces)) return { ok: false, reason: 'namespaces' };
const namespaces = sanitizeSyncNamespaces(raw.namespaces);
if (syncBytes(namespaces) > MAX_SYNC_BYTES) return { ok: false, reason: 'too-large' };
return { ok: true, value: {
schema: SYNC_SCHEMA, subject: raw.subject, revision: raw.revision,
initialized: true, namespaces,
} };
}
export function sanitizeSyncMetadata(raw) {
const parsed = parseRemoteSettings({ ...raw, ok: true });
return parsed.ok && parsed.value.initialized ? parsed.value : null;
}
export async function collectLocalSettings(area) {
if (!area || typeof area.get !== 'function') throw new Error('settings sync: storage required');
const keys = [...Object.values(SYNC_STORAGE_KEYS), SYNC_STATE_KEY];
const stored = await area.get(keys);
const raw = {
features: stored?.[SYNC_STORAGE_KEYS.features],
filters: stored?.[SYNC_STORAGE_KEYS.filters],
buyerLimits: stored?.[SYNC_STORAGE_KEYS.buyerLimits],
buyerOptions: stored?.[SYNC_STORAGE_KEYS.buyerOptions],
sellerOptions: stored?.[SYNC_STORAGE_KEYS.sellerOptions],
interface: stored?.[SYNC_STORAGE_KEYS.interface],
packLocks: stored?.[SYNC_STORAGE_KEYS.packLocks],
};
const present = [];
for (const namespace of SYNC_NAMESPACES) {
const key = SYNC_STORAGE_KEYS[namespace];
if (!Object.hasOwn(stored ?? {}, key)) continue;
if (namespace === 'interface') {
const ui = stored[key];
if (!object(ui) || (!Object.hasOwn(ui, 'filters') && !Object.hasOwn(ui, 'sbcPolicy'))) continue;
}
present.push(namespace);
}
return {
namespaces: sanitizeSyncNamespaces(raw),
present,
base: sanitizeSyncMetadata(stored?.[SYNC_STATE_KEY]),
};
}
export async function applyLocalSettings(area, namespaces, metadata) {
if (!area || typeof area.get !== 'function' || typeof area.set !== 'function') {
throw new Error('settings sync: storage required');
}
const clean = sanitizeSyncNamespaces(namespaces);
const parsed = parseRemoteSettings({ ...metadata, ok: true, namespaces: clean, initialized: true });
if (!parsed.ok) throw new Error(`settings sync: ${parsed.reason}`);
const current = await area.get(SYNC_STORAGE_KEYS.interface);
const deviceUi = sanitizeUiState(current?.[SYNC_STORAGE_KEYS.interface]);
const ui = {
...deviceUi,
filters: [...clean.interface.filters],
sbcPolicy: copy(clean.interface.sbcPolicy),
};
await area.set({
[SYNC_STORAGE_KEYS.features]: clean.features,
[SYNC_STORAGE_KEYS.filters]: clean.filters,
[SYNC_STORAGE_KEYS.buyerLimits]: clean.buyerLimits,
[SYNC_STORAGE_KEYS.buyerOptions]: clean.buyerOptions,
[SYNC_STORAGE_KEYS.sellerOptions]: clean.sellerOptions,
[SYNC_STORAGE_KEYS.interface]: ui,
[SYNC_STORAGE_KEYS.packLocks]: clean.packLocks,
[SYNC_STATE_KEY]: parsed.value,
});
}
export function sameSyncValue(a, b) {
return JSON.stringify(a) === JSON.stringify(b);
}
