import {
CHROME_SYNC_SUBJECT, createChromeSyncTransport,
} from './chrome-sync-transport.js';
import { CLOUD_STATUS_KEY, createCloudAutoPush } from './cloud-auto-push.js';
import { createSettingsSync, planSettingsSync } from './settings-client.js';
import { collectLocalSettings, parseRemoteSettings, sameSyncValue } from './settings-schema.js';
import { createBridgeArea, createBridgeCloud } from './bridge-storage.js';
import {
applyFileSettings, parseSettingsFile, serializeSettingsFile, settingsFileName,
} from './settings-file.js';
export const CLOUD_PHASES = Object.freeze([
'unknown', 'empty', 'pushed', 'waiting', 'first', 'conflict', 'ahead', 'full',
'error', 'taken', 'saved', 'loaded', 'bad-file',
]);
const CHOICE_PHASES = Object.freeze(['first', 'conflict']);
export function createCloudDesk(deps = {}) {
const request = deps.request;
if (typeof request !== 'function') throw new Error('cloud desk: нужен мост');
const doc = deps.doc;
const clock = deps.clock ?? { now: () => Date.now() };
const onChange = typeof deps.onChange === 'function' ? deps.onChange : () => {};
const onApplied = typeof deps.onApplied === 'function' ? deps.onApplied : () => {};
const onError = typeof deps.onError === 'function' ? deps.onError : () => {};
const area = createBridgeArea({ request });
const transport = createChromeSyncTransport({ sync: createBridgeCloud({ request }), clock });
const sync = createSettingsSync({ area, transport });
const auto = createCloudAutoPush({
area, transport, clock, ...(deps.timers ? { timers: deps.timers } : {}),
});
let view = { phase: 'unknown', revision: null, at: null, reason: null, busy: false };
let noticed = 0;
let takenAtOnce = 0;
const reasons = [];
const say = (phase, extra = {}) => {
view = { phase, revision: null, at: null, reason: null, busy: view.busy, ...extra };
onChange();
return view;
};
async function look() {
let snapshot;
try {
snapshot = await transport.read();
} catch (err) {
onError(`cloud: ${err?.message ?? err}`);
return say('error', { reason: 'network' });
}
if (snapshot?.ok !== true) {
return say(snapshot?.reason === 'cloud-full' ? 'full' : 'error',
{ reason: typeof snapshot?.reason === 'string' ? snapshot.reason : 'network' });
}
const parsed = parseRemoteSettings(snapshot);
if (!parsed.ok) return say('error', { reason: `invalid-${parsed.reason}` });
const remote = parsed.value;
if (!remote.initialized) return say('empty');
const at = Number.isSafeInteger(snapshot.updatedAt) ? snapshot.updatedAt : null;
const local = await collectLocalSettings(area);
if (local.base === null || local.base.subject !== CHROME_SYNC_SUBJECT) {
return say('first', { at, revision: remote.revision });
}
const plan = planSettingsSync({
base: local.base, local: local.namespaces, present: local.present, remote,
});
if (!plan.ok) {
return say(plan.reason === 'conflict' ? 'conflict' : 'error', { reason: plan.reason });
}
if (!sameSyncValue(plan.namespaces, local.namespaces)) {
return say('ahead', { at, revision: remote.revision });
}
if (!sameSyncValue(plan.namespaces, remote.namespaces)) {
return say('waiting', { revision: remote.revision, at });
}
return say('pushed', { revision: remote.revision, at });
}
let url = null;
let input = null;
let leaving = false;
function release() {
if (url === null) return;
URL.revokeObjectURL(url);
url = null;
}
function take(text, name) {
release();
url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
const link = doc.createElement('a');
link.href = url;
link.download = name;
doc.body.append(link);
link.click();
link.remove();
letGoOnLeave();
}
function letGoOnLeave() {
if (leaving) return;
leaving = true;
doc.defaultView?.addEventListener?.('pagehide', release);
}
function picker() {
if (input !== null) return input;
input = doc.createElement('input');
input.type = 'file';
input.accept = 'application/json,.json';
input.hidden = true;
input.addEventListener('change', () => { void picked(); });
doc.body.append(input);
return input;
}
async function picked() {
const file = input?.files?.[0] ?? null;
if (input) input.value = '';
if (file === null) return;
await guarded(async () => {
let parsed;
try {
parsed = parseSettingsFile(await file.text());
} catch {
parsed = { ok: false, reason: 'json' };
}
if (parsed.ok !== true) return say('bad-file', { reason: parsed.reason });
await applyFileSettings(area, parsed.namespaces);
await onApplied();
await look();
return say('loaded');
});
}
async function guarded(work) {
if (view.busy) return view;
view = { ...view, busy: true };
onChange();
try {
return await work();
} finally {
view = { ...view, busy: false };
onChange();
}
}
return {
state: () => ({ ...view, choose: CHOICE_PHASES.includes(view.phase) }),
refresh: () => guarded(look),
run: (resolution = null) => guarded(async () => {
let said;
try {
said = await sync.run(resolution === null ? {} : { resolution });
} catch (err) {
onError(`cloud: ${err?.message ?? err}`);
return say('error', { reason: 'network' });
}
if (said?.ok !== true) {
if (said?.reason === 'conflict') return say('conflict');
return say(said?.reason === 'cloud-full' ? 'full' : 'error',
{ reason: typeof said?.reason === 'string' ? said.reason : 'network' });
}
if (said.action !== 'uploaded' && said.action !== 'unchanged') await onApplied();
const taken = said.action === 'downloaded' || said.action === 'resolved-cloud';
await look();
return taken ? say('taken', { revision: said.revision }) : view;
}),
saveFile: () => guarded(async () => {
const local = await collectLocalSettings(area);
const name = settingsFileName(clock.now());
take(serializeSettingsFile({ namespaces: local.namespaces, exported: clock.now() }), name);
return say('saved');
}),
loadFile() {
picker().click();
return view;
},
notice: (changes) => {
noticed += 1;
const key = Object.keys(changes ?? {})[0] ?? null;
const one = key === null ? null : changes[key];
reasons.push({ key, changed: JSON.stringify(one?.oldValue ?? null) !== JSON.stringify(one?.newValue ?? null) });
if (reasons.length > 5) reasons.shift();
const took = auto.notice(changes, 'local');
if (took === true) takenAtOnce += 1;
return took;
},
diag: async () => {
let move = null;
try {
const stored = await area.get(CLOUD_STATUS_KEY);
move = stored?.[CLOUD_STATUS_KEY] ?? null;
} catch { move = null; }
return { noticed, takenAtOnce, ...auto.state(), reasons: [...reasons], move };
},
pushNow: () => auto.push(),
};
}
