import{en} from './dict.en.js'
import{ru} from './dict.ru.js'
import{accountEn,accountRu} from './dict.account.js'
import{clubTableEn,clubTableRu} from './dict.club-table.js'
import{outbidEn,outbidRu} from './dict.outbid.js'
import{listEn,listRu} from './dict.list.js'
import{sellEn,sellRu} from './dict.sell.js'
import{sbcWindowEn,sbcWindowRu,sbcGuardEn,sbcGuardRu} from './dict.sbc-window.js'
import{priceBadgeEn,priceBadgeRu} from './dict.price-badges.js'
import{hotkeysEn,hotkeysRu} from './dict.hotkeys.js'
import{storeGridEn,storeGridRu} from './dict.store-grid.js'
import{storeCatalogEn,storeCatalogRu} from './dict.store-catalog.js'
import{pickPricesEn,pickPricesRu} from './dict.pick-prices.js'
import{autoBuyEn,autoBuyRu} from './dict.auto-buy.js'
import{unassignedEn,unassignedRu} from './dict.unassigned.js'
import{sbcTabEn,sbcTabRu} from './dict.sbc-tab.js'
import{sbcSetEn,sbcSetRu} from './dict.sbc-set.js'
import{cardGridEn,cardGridRu} from './dict.card-grid.js'
import{clubBarEn,clubBarRu} from './dict.club-bar.js'
import{bootEn,bootRu} from './dict.boot.js'
import{rewardFlowEn,rewardFlowRu} from './dict.reward-flow.js'
import{hubRewardsEn,hubRewardsRu} from './dict.hub-rewards.js'
import{headBarEn,headBarRu} from './dict.head-bar.js'
import{dayXEn,dayXRu} from './dict.day-x.js'
import{transfersEn,transfersRu} from './dict.transfers.js'
import{snipeEn,snipeRu} from './dict.snipe.js'
import{settingsRegistryEn,settingsRegistryRu} from './dict.settings-registry.js'
import{panelEn,panelRu} from './dict.panel.js'
import{storageEn,storageRu} from './dict.storage.js'
import{promoCloseEn,promoCloseRu} from './dict.promo-close.js'
import{dropdownSearchEn,dropdownSearchRu} from './dict.dropdown-search.js'
import{sessionEn,sessionRu} from './dict.session.js'
import{homeGridEn,homeGridRu} from './dict.home-grid.js'
import{marketBotEn,marketBotRu} from './dict.market-bot.js'
import{marketRatingEn,marketRatingRu} from './dict.market-rating.js'
import{sbcStripEn,sbcStripRu} from './dict.sbc-strip.js'
import{squadEn,squadRu} from './dict.squad.js'
import{cloudEn,cloudRu} from './dict.cloud.js'
import{updateNoticeEn,updateNoticeRu} from './dict.update-notice.js'
export const DICTS=Object.freeze({en:Object.keys(en).length?Object.freeze({...en,...accountEn,...clubTableEn,...outbidEn,...listEn,...sellEn,...sbcWindowEn,...sbcGuardEn,...priceBadgeEn,...hotkeysEn,...storeGridEn,...storeCatalogEn,...pickPricesEn,...autoBuyEn,...unassignedEn,...sbcTabEn,...sbcSetEn,...cardGridEn,...clubBarEn,...bootEn,...rewardFlowEn,...hubRewardsEn,...headBarEn,...transfersEn,...snipeEn,...dayXEn,...settingsRegistryEn,...panelEn,...storageEn,...promoCloseEn,...dropdownSearchEn,...sessionEn,...homeGridEn,...marketBotEn,...marketRatingEn,...sbcStripEn,...squadEn,...cloudEn,...updateNoticeEn}):en,ru:Object.keys(ru).length?Object.freeze({...ru,...accountRu,...clubTableRu,...outbidRu,...listRu,...sellRu,...sbcWindowRu,...sbcGuardRu,...priceBadgeRu,...hotkeysRu,...storeGridRu,...storeCatalogRu,...pickPricesRu,...autoBuyRu,...unassignedRu,...sbcTabRu,...sbcSetRu,...cardGridRu,...clubBarRu,...bootRu,...rewardFlowRu,...hubRewardsRu,...headBarRu,...transfersRu,...snipeRu,...dayXRu,...settingsRegistryRu,...panelRu,...storageRu,...promoCloseRu,...dropdownSearchRu,...sessionRu,...homeGridRu,...marketBotRu,...marketRatingRu,...sbcStripRu,...squadRu,...cloudRu,...updateNoticeRu}):ru})
export{SUPPORTED_LOCALES,DEFAULT_LOCALE,RUSSIAN_TIME_ZONES,currentTimeZone,detectLocale,chooseLocale} from './detect.js'
import{SUPPORTED_LOCALES,DEFAULT_LOCALE} from './detect.js'
export function pluralKey(base,count,locale=DEFAULT_LOCALE){const lang=SUPPORTED_LOCALES.includes(locale)?locale:DEFAULT_LOCALE
const value=Number.isFinite(count)?count:0
let form='other'
try{form=new Intl.PluralRules(lang).select(value)}catch{form='other'}
return `${base}.${form}`}
export function createI18n(opts={}){const dicts=opts.dicts??DICTS
const locale=SUPPORTED_LOCALES.includes(opts.locale)?opts.locale:DEFAULT_LOCALE
const dict=dicts[locale]??dicts[DEFAULT_LOCALE]
const fallback=dicts[DEFAULT_LOCALE]
const missing=new Set()
function t(key,params){let template=dict[key]
if(template===undefined)template=fallback[key]
if(template===undefined){
missing.add(key)
return key}
if(!params)return template
return template.replace(/\{(\w+)\}/g,(whole,name)=>(Object.hasOwn(params,name)?String(params[name]):whole))}
const numberFormat=new Intl.NumberFormat(locale)
const percentFormat=new Intl.NumberFormat(locale,{style:'percent',maximumFractionDigits:1})
return{locale,t,
plural:(base,count,params)=>t(pluralKey(base,count,locale),params),
missingKeys:()=>[...missing],
formatNumber:(value)=>numberFormat.format(value),
formatCoins:(coins)=>numberFormat.format(Math.round(coins)),
formatPercent:(ratio)=>percentFormat.format(ratio)}}
