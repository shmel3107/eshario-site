export const promoCloseEn=Object.freeze({
'promoClose.closed':'EA announcement closed: {what}',
'promoClose.untitled':'no title',
'settings.feature.promoClose':'Close EA announcements automatically',
'settings.organ.features.promoClose.hint':'EA pop-up announcements are closed by their own Continue button. Confirmation windows are never touched.'})
export const promoCloseRu=Object.freeze({
'promoClose.closed':'Объявление EA закрыто: {what}',
'promoClose.untitled':'без заголовка',
'settings.feature.promoClose':'Сам закрывать объявления EA',
'settings.organ.features.promoClose.hint':'Всплывающие объявления EA закрываются их же кнопкой «Continue». Окна подтверждений не трогаются никогда.'})
