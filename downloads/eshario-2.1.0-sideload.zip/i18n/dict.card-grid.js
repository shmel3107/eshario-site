export const cardGridEn=Object.freeze({
'cardGrid.pinOn':'Pinned to the top. Click to release',
'cardGrid.pinOff':'Scrolls away. Click to pin',
'settings.feature.cardGrid':'Card grid',
'deal.good':'Good deals {count}',
'deal.bad':'Overpriced {count}',
'deal.market':'Market',
'deal.net':'After tax',
'deal.gain':'Profit',
'deal.noPrice':'no price'})
export const cardGridRu=Object.freeze({
'cardGrid.pinOn':'Приколота сверху. Нажми, чтобы отпустить',
'cardGrid.pinOff':'Уезжает со страницей. Нажми, чтобы приколоть',
'settings.feature.cardGrid':'Сетка карточек',
'deal.good':'Выгодных {count}',
'deal.bad':'Дорогих {count}',
'deal.market':'Рынок',
'deal.net':'Чистыми',
'deal.gain':'Выгода',
'deal.noPrice':'цены нет'})
