export const updateNoticeEn=Object.freeze({
'update.line':'Version {version} is available. Download'})
export const updateNoticeRu=Object.freeze({
'update.line':'Есть версия {version}. Скачать'})
