(function(){'use strict';
var CHANNEL='fut-companion';
var FROM_PAGE='fut-companion/page';
var FROM_CONTENT='fut-companion/content';
var KIND_EVENT='event';
var LOCKS_CHANGED='locks.changed';
var LOCKS_WRITE='locks.write';
var ACCOUNT_OPEN_FAILED='account.open.failed';
var script=document.createElement('script');
script.type='module';
script.src=chrome.runtime.getURL('page/page-entry.js');
script.dataset.futCompanion='page-entry';
script.addEventListener('load',function(){script.remove()});
(document.head||document.documentElement).appendChild(script);
var SETTINGS_KEY='settings.toggles';
var FILTERS_KEY='filters.sets';
var LIMITS_KEY='automation.limits';
var OPTIONS_KEY='automation.options';
var SELLER_KEY='seller.options';
var UI_KEY='ui.state';
var JOURNAL_KEY='automation.journal';
var LEDGER_KEY='automation.ledger';
var LICENSE_KEY='license.key';
var PACKS_KEY='packs.locks';
var LOCKS_KEY='card.locks';
var FROZEN_KEY='card.frozen';
var LIVE_CONTROL_KEY='live.control';
var CATALOG_PREFIX='catalog.v1.';
var CATALOG_SHARDS=16;
var GROUPS_KEY='rarity.groups';
var CARDBASE_KEY='cards.seed';
var PREVIEW_KEY='preview.packs';
var DEMAND_KEY='demand.memory';
var PURCHASES_KEY='purchase.log';
var DAY_BUDGET_KEY='market.daybudget';
var BUY_RATE_KEY='market.buyrate';
var SBC_RATE_KEY='sbc.rate';
var MIRROR_PREFIX='club.mirror.v1.';
var MIRROR_HEAD_KEY='club.mirror.head';
var MIRROR_SHARDS=8;
var SYNC_BASE_KEY='settings.sync';
var CLOUD_META_KEY='settings.cloud.meta';
var CLOUD_CHUNK_PREFIX='settings.cloud.';
var CLOUD_MAX_CHUNKS=512;
function readKey(key){return function(){return chrome.storage.local.get(key).then(function(stored){return(stored&&stored[key]!==undefined)?stored[key]:null})}}
function writeKey(key){return function(params){var payload={};
payload[key]=params;
return chrome.storage.local.set(payload).then(function(){return true})}}
function writeLocks(params){if(!params||typeof params!=='object'||Array.isArray(params))return Promise.resolve(false);
return chrome.runtime.sendMessage({method:LOCKS_WRITE,params:params})
.then(function(result){if(result&&result.ok===true)return true;
return Promise.reject('locks: '+((result&&result.reason)||'no-response'))},
function(err){return Promise.reject('locks: '+String((err&&err.message)||err))})}
function catalogKey(params){var shard=params&&params.shard;
if(typeof shard!=='number'||!isFinite(shard)||Math.floor(shard)!==shard) return null;
if(shard<0||shard>=CATALOG_SHARDS) return null;
return CATALOG_PREFIX+shard}
function readCatalog(params){var key=catalogKey(params);
if(key===null) return Promise.resolve(null);
return chrome.storage.local.get(key).then(function(stored){return(stored&&stored[key]!==undefined)?stored[key]:null})}
function writeCatalog(params){var key=catalogKey(params);
if(key===null) return Promise.resolve(false);
var payload={};
payload[key]=params.value;
return chrome.storage.local.set(payload).then(function(){return true})}
function mirrorKey(params){var shard=params&&params.shard;
if(typeof shard!=='number'||!isFinite(shard)||Math.floor(shard)!==shard) return null;
if(shard<0||shard>=MIRROR_SHARDS) return null;
return MIRROR_PREFIX+shard}
function readMirror(params){var key=mirrorKey(params);
if(key===null) return Promise.resolve(null);
return chrome.storage.local.get(key).then(function(stored){return(stored&&stored[key]!==undefined)?stored[key]:null})}
function writeMirror(params){var key=mirrorKey(params);
if(key===null) return Promise.resolve(false);
var payload={};
payload[key]=params.value;
return chrome.storage.local.set(payload).then(function(){return true})}
function cloudRead(){return chrome.storage.sync.get([CLOUD_META_KEY]).then(function(head){var meta=head&&head[CLOUD_META_KEY];
var count=meta&&typeof meta==='object'?meta.chunks:null;
if(typeof count!=='number'||!isFinite(count)||Math.floor(count)!==count||count<=0){return{meta:meta===undefined?null:meta,parts:[]}}
if(count>CLOUD_MAX_CHUNKS)count=CLOUD_MAX_CHUNKS;
var keys=[];
for(var at=0;at<count;at+=1)keys.push(CLOUD_CHUNK_PREFIX+at);
return chrome.storage.sync.get(keys).then(function(stored){var parts=[];
for(var index=0;index<count;index+=1){var one=stored?stored[CLOUD_CHUNK_PREFIX+index]:undefined;
parts.push(typeof one==='string'?one:null)}
return{meta:meta,parts:parts}})})}
function cloudWrite(params){var parts=params&&params.parts;
var meta=params&&params.meta;
if(!Array.isArray(parts)||parts.length>CLOUD_MAX_CHUNKS||!meta||typeof meta!=='object')return Promise.resolve({ok:false,reason:'bad-payload'});
var payload={};
payload[CLOUD_META_KEY]=meta;
for(var at=0;at<parts.length;at+=1){if(typeof parts[at]!=='string')return Promise.resolve({ok:false,reason:'bad-payload'});
payload[CLOUD_CHUNK_PREFIX+at]=parts[at]}
var drop=Number(params&&params.dropFrom);
return chrome.storage.sync.set(payload).then(function(){var stale=[];
if(isFinite(drop)&&drop>parts.length){var end=Math.min(drop,CLOUD_MAX_CHUNKS);
for(var index=parts.length;index<end;index+=1)stale.push(CLOUD_CHUNK_PREFIX+index)}
if(stale.length===0)return{ok:true,removed:[]};
return chrome.storage.sync.remove(stale).then(function(){return{ok:true,removed:stale}},
function(){return{ok:true,removed:[]}})},
function(err){return{ok:false,reason:String((err&&err.message)||err)}})}
function fetchPrice(params){return chrome.runtime.sendMessage({method:'price.fetch',url:params&&params.url})
.then(function(result){return result||{ok:false,reason:'no-response'}},function(err){return{ok:false,reason:String((err&&err.message)||err)}})}
function budgetAsk(method){return function(params){return chrome.runtime.sendMessage({method:method,params:params||null})
.then(function(result){return result&&typeof result==='object'&&result.ok!==undefined?result:{ok:false,granted:0,reason:'counter-unavailable',state:null}},
function(){return{ok:false,granted:0,reason:'counter-unavailable',state:null}})}}
function cardsBase(params){return chrome.runtime.sendMessage({method:'cards.base',params:params||null})
.then(function(result){return result||{ok:false,reason:'no-response',state:null}},
function(err){return{ok:false,reason:String((err&&err.message)||err),state:null}})}
function updateCheck(params){return chrome.runtime.sendMessage({method:'update.check',params:{force:!!(params&&params.force===true)}})
.then(function(result){return result||{ok:false,show:false,reason:'no-response'}},
function(err){return{ok:false,show:false,reason:String((err&&err.message)||err)}})}
function accountStatus(){return chrome.runtime.sendMessage({method:'account.status'})
.then(function(result){return result||{ok:false,reason:'no-response'}},function(){return{ok:false,reason:'network'}})}
function openAccount(){var sent;
try{sent=chrome.runtime.sendMessage({method:'account.open'})}catch(err){sent=Promise.reject(err)}
return Promise.resolve(sent).then(function(result){if(result&&result.ok===true)return{ok:true};
return accountDoorFailed(result&&typeof result.reason==='string'?result.reason:'no-response')},
function(){return accountDoorFailed('no-worker')})}
function accountDoorFailed(reason){var word=/^[a-z][a-z-]{0,39}$/.test(reason)?reason:'open-failed';
window.postMessage({channel:CHANNEL,from:FROM_CONTENT,kind:KIND_EVENT,name:ACCOUNT_OPEN_FAILED,payload:{reason:word}},window.location.origin);
return{ok:false,reason:word}}
var handlers={ping:function(){return 'pong'},version:function(){return chrome.runtime.getManifest().version},'price.fetch':fetchPrice,
'settings.read':readKey(SETTINGS_KEY),'settings.write':writeKey(SETTINGS_KEY),'filters.read':readKey(FILTERS_KEY),'filters.write':writeKey(FILTERS_KEY),'packs.read':readKey(PACKS_KEY),'packs.write':writeKey(PACKS_KEY),'locks.read':readKey(LOCKS_KEY),'locks.write':writeLocks,'frozen.read':readKey(FROZEN_KEY),'frozen.write':writeKey(FROZEN_KEY),'limits.read':readKey(LIMITS_KEY),'limits.write':writeKey(LIMITS_KEY),'options.read':readKey(OPTIONS_KEY),'options.write':writeKey(OPTIONS_KEY),'seller.read':readKey(SELLER_KEY),'seller.write':writeKey(SELLER_KEY),
'ui.read':readKey(UI_KEY),'ui.write':writeKey(UI_KEY),
'journal.read':readKey(JOURNAL_KEY),'journal.write':writeKey(JOURNAL_KEY),
'ledger.read':readKey(LEDGER_KEY),'ledger.write':writeKey(LEDGER_KEY),
'license.read':readKey(LICENSE_KEY),'license.write':writeKey(LICENSE_KEY),
'live-control.read':readKey(LIVE_CONTROL_KEY),'live-control.write':writeKey(LIVE_CONTROL_KEY),
'catalog.read':readCatalog,'catalog.write':writeCatalog,
'groups.read':readKey(GROUPS_KEY),'groups.write':writeKey(GROUPS_KEY),
'cards.base':cardsBase,
'cardbase.read':readKey(CARDBASE_KEY),'cardbase.write':writeKey(CARDBASE_KEY),
'preview.read':readKey(PREVIEW_KEY),'preview.write':writeKey(PREVIEW_KEY),
'demand.read':readKey(DEMAND_KEY),'demand.write':writeKey(DEMAND_KEY),
'purchases.read':readKey(PURCHASES_KEY),'purchases.write':writeKey(PURCHASES_KEY),
'daybudget.read':readKey(DAY_BUDGET_KEY),'daybudget.write':writeKey(DAY_BUDGET_KEY),
'buyrate.read':readKey(BUY_RATE_KEY),'buyrate.write':writeKey(BUY_RATE_KEY),
'sbcrate.read':readKey(SBC_RATE_KEY),'sbcrate.write':writeKey(SBC_RATE_KEY),
'mirror.read':readMirror,'mirror.write':writeMirror,
'mirror.head.read':readKey(MIRROR_HEAD_KEY),'mirror.head.write':writeKey(MIRROR_HEAD_KEY),
'sync.base.read':readKey(SYNC_BASE_KEY),'sync.base.write':writeKey(SYNC_BASE_KEY),
'cloud.read':cloudRead,'cloud.write':cloudWrite,
'account.status':accountStatus,'account.open':openAccount,
'update.check':updateCheck,
'budget.reserve':budgetAsk('budget.reserve'),'budget.spend':budgetAsk('budget.spend'),
'budget.release':budgetAsk('budget.release'),'budget.rest':budgetAsk('budget.rest'),
'budget.state':budgetAsk('budget.state')};
window.addEventListener('message',function(event){if(event.source!==window)return;
var msg=event.data;
if(!msg||msg.channel!==CHANNEL||msg.from!==FROM_PAGE)return;
if(msg.kind!=='request'||typeof msg.method!=='string') return;
var handler=handlers[msg.method];
if(!handler){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:false,error:'unknown method: '+msg.method});
return}
try{Promise.resolve(handler(msg.params)).then(function(value){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:true,value:value})},function(err){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:false,error:String((err&&err.message)||err)})})}catch(err){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:false,error:String((err&&err.message)||err)})}});
function reply(message){window.postMessage(message,window.location.origin)}
if(chrome.storage&&chrome.storage.onChanged&&typeof chrome.storage.onChanged.addListener==='function'){chrome.storage.onChanged.addListener(function(changes,area){if(area!=='local'||!changes||changes[LOCKS_KEY]===undefined)return;
window.postMessage({channel:CHANNEL,from:FROM_CONTENT,kind:KIND_EVENT,name:LOCKS_CHANGED,payload:null},window.location.origin)})}})()
