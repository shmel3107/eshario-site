import{el} from './dom.js'
import{renderSection,glyphOf} from './panel-section.js'
import{modalBox} from './window.js'
import{updateLine} from '../features/update-notice.js'
export const SETTINGS_STYLESHEET=new URL('./settings-window.css',import.meta.url).href
export const SETTINGS_LINK_ID='fut-companion-settings-window'
export const SETTINGS_MARK='futSettings'
export const SETTINGS_BOX_MARK='futSettingsBox'
export const SETTINGS_BOX_CLASS='fx-hk-capture-box fx-set-box'
export const SETTINGS_OVERLAY_CLASS='fx-hk-capture fx-set-back'
export function renderSettingsWindow(doc,model,hands,shape={}){const win=model.settings
const onClose=typeof shape.onClose==='function'?shape.onClose:()=>{}
const search=searchField(doc,model,shape)
const main=model.view==='search'
?searchScreen(doc,model,hands)
:(model.section===null?null:renderSection(doc,model.section,hands,shape.body??{}))
const cols=el(doc,'div',{class:'fx-set-cols'},
[railNode(doc,win,hands),
el(doc,'div',{class:'fx-set-main',dataset:{futSettingsMain:'1'}},[main].filter(Boolean))])
const host=modalBox(doc,{mark:SETTINGS_MARK,box:SETTINGS_BOX_CLASS,overlay:SETTINGS_OVERLAY_CLASS,
boxMark:SETTINGS_BOX_MARK,
title:win.title,closeLabel:win.closeLabel,tools:[updateLine(doc,{locale:win.locale?.now}),localeNode(doc,win,hands),search],
onBack:()=>onClose()},
[cols])
return host}
function railNode(doc,win,hands){const kids=[]
for(const row of win.rail.main)kids.push(railRow(doc,row,hands))
if(win.rail.pro.length>0){kids.push(el(doc,'div',{class:'fx-set-rail-group',dataset:{futSettingsRailGroup:'pro'},
text:win.rail.proLabel,attrs:{title:win.rail.proHint}}))
for(const row of win.rail.pro)kids.push(railRow(doc,row,hands))}
return el(doc,'nav',{class:'fx-set-rail',dataset:{futSettingsRail:'1'},
attrs:{'aria-label':win.rail.label}},kids)}
function railRow(doc,row,hands){const classes=['fx-set-rail-row']
if(row.on)classes.push('on')
if(row.locked)classes.push('locked')
const node=el(doc,'button',{class:classes.join(' '),attrs:{type:'button',title:row.hint},
dataset:{futSettingsRailItem:row.id},
on:{click:()=>hands.onOpen(row.id)}},
[el(doc,'span',{class:'fx-set-rail-glyph',text:glyphOf(row.icon)}),
el(doc,'span',{class:'fx-set-rail-name',text:row.title})])
if(row.on)node.setAttribute('aria-current','true')
return node}
function localeNode(doc,win,hands){const one=win.locale
if(!one||!Array.isArray(one.options)||one.options.length===0)return null
const onLocale=typeof hands?.onLocale==='function'?hands.onLocale:()=>{}
const kids=one.options.map((option)=>{const on=option.id===one.now
const node=el(doc,'button',{class:on?'fx-action on':'fx-action',text:option.short,
attrs:{type:'button',title:option.label,'aria-label':option.label},
dataset:{futSettingsLocale:option.id},
on:{click:()=>{if(on)return
onLocale(option.id)}}})
if(on)node.setAttribute('aria-pressed','true')
return node})
return el(doc,'div',{class:'fx-set-locale',dataset:{futSettingsLocaleBox:'1'},
attrs:{role:'group','aria-label':one.label}},kids)}
function searchField(doc,model,shape){const onSearch=typeof shape.onSearch==='function'?shape.onSearch:()=>{}
const input=el(doc,'input',{class:'fx-search fx-set-search',
attrs:{type:'search',placeholder:model.searchPlaceholder,'aria-label':model.searchPlaceholder,
title:model.searchClearLabel},
dataset:{futSettingsSearch:'1',panelSearch:'1'},
on:{input:(event)=>onSearch(String(event?.target?.value??''))}})
input.value=model.query??''
return input}
function searchScreen(doc,model,hands){const search=model.search
const kids=[el(doc,'div',{class:'search-count',dataset:{searchCount:'1'},text:search.title})]
if(search.rows.length===0)kids.push(el(doc,'div',{class:'empty',dataset:{searchEmpty:'1'},text:search.empty}))
for(const row of search.rows){const inside=[el(doc,'span',{class:'hit-name',text:row.label}),
el(doc,'span',{class:'hit-section',dataset:{hitWhere:row.organ},text:row.where??row.sectionTitle})]
if(row.openable===false){kids.push(el(doc,'div',{class:'hit hit-elsewhere',attrs:{title:row.hint},
dataset:{searchHit:`${row.section}.${row.organ}`,searchHitElsewhere:'1'}},inside))
continue}
kids.push(el(doc,'button',{class:'hit',attrs:{type:'button',title:row.hint},
dataset:{searchHit:`${row.section}.${row.organ}`},
on:{click:()=>{hands.onView('query','')
hands.onView('highlight',row.organ)
hands.onOpen(row.section)}}},inside))}
return el(doc,'div',{class:'search-screen',dataset:{panelSearchScreen:'1'}},kids)}
