import{SECTIONS,defaultOf,floorOf,inWindow} from '../settings/registry.js'
import{REGISTRY_SOURCES} from '../settings/registry-values.js'
import{AFTER_BUY,AFTER_BUY_KEY,afterBuyOf} from '../automation/options-input.js'
import{sanitizePackShowPolicy} from '../features/pack-show.js'
import{sanitizeExpensiveFrom} from '../features/unassigned-strip.js'
import{stopReasonKey} from '../features/automation-actions.js'
export const ORDERED_SECTIONS=Object.freeze([...SECTIONS].sort((a,b)=>a.order-b.order))
export const FIRST_SECTION=ORDERED_SECTIONS[0]?.id??null
const DEEDS=Object.freeze({'solver.locks':'solver.locks','solver.rereadClub':'solver.reread','snipe.filters':'buyer.filters','packs.beltDiscardAllowlist':null,'ledger.exportCsv':'ledger.csv','ledger.reset':'ledger.reset','journal.export':'journal.export','hotkeys.open':'hotkeys.open','market.taxCalculator':'market.tax','market.filterSets':'market.filters','club.analyze':'club.analyze','premium.apply':'premium.apply','premium.clear':'premium.clear','premium.account':'premium.account','diagnostics.check':'diagnostics.check','diagnostics.guide':'diagnostics.guide',
'cloud.sync':'cloud.sync','cloud.saveFile':'cloud.saveFile','cloud.loadFile':'cloud.loadFile','cloud.takeCloud':'cloud.takeCloud','cloud.takeLocal':'cloud.takeLocal'})
export function routeOf(sectionId,organ){const store=organ?.store
if((organ?.kind==='action'||organ?.kind==='link')&&typeof DEEDS[`${sectionId}.${organ?.id}`]==='string'){return{via:'deed',key:DEEDS[`${sectionId}.${organ.id}`]}}
if(typeof store==='string'){const cut=store.indexOf('.')
const bucket=store.slice(0,cut)
const key=store.slice(cut+1)
if(bucket==='toggles')return{via:'toggle',key}
if(bucket==='limits')return{via:'limit',key}
if(bucket==='options')return{via:'option',key}
if(bucket==='seller')return{via:'seller',key}
if(bucket==='license')return{via:'license',key}
if(bucket==='ui')return uiRoute(key)}
if(organ?.id==='dryRun')return{via:sectionId==='seller'?'sellerDryRun':'buyerDryRun',key:'dryRun'}
if(sectionId==='ledger'&&organ?.id==='scope')return{via:'view',key:'ledgerScope'}
const deed=DEEDS[`${sectionId}.${organ?.id}`]
return typeof deed==='string'?{via:'deed',key:deed}:null}
function uiRoute(key){
if(key==='packShow.ratingMin')return{via:'packShowRating',key:'ratingMin'}
if(key.startsWith('packShow.'))return{via:'packShow',key:key.slice('packShow.'.length)}
if(key.startsWith('solver.'))return{via:'solver',key:key.slice('solver.'.length)}
if(key==='relist.mode')return{via:'relist',key:'mode'}
if(key==='unassignedThreshold')return{via:'packThreshold',key:'expensiveFrom'}
if(key==='dayXOff')return{via:'dayX',key}
if(key==='onboarded')return{via:'onboarding',key}
if(key==='filters')return{via:'deed',key:'buyer.filters'}
return null}
export function valueOf(state,organ,sectionId=null){const store=organ?.store
if(typeof store!=='string'){if(organ?.id!=='dryRun')return null
const engine=sectionId==='seller'?state.seller:state.automation
return engine?engine.dryRun!==false:true}
const cut=store.indexOf('.')
const bucket=store.slice(0,cut)
const key=store.slice(cut+1)
if(bucket==='toggles')return typeof state.statusOf==='function'&&state.statusOf(key)==='active'
if(bucket==='limits')return text(state.automation?.limits?.[key])
if(bucket==='options')return key===AFTER_BUY_KEY
?afterBuyOf(state.automation?.options?.[key])
:raw(state.automation?.options?.[key])
if(bucket==='seller')return raw(state.seller?.options?.[key])
if(bucket==='license')return typeof state.licenseKey==='string'?state.licenseKey:''
if(bucket==='ui')return uiValue(state,key)
return null}
const text=(value)=>(typeof value==='string'?value:'')
const raw=(value)=>(typeof value==='boolean'?value:text(value))
function uiValue(state,key){if(key==='relist.mode')return typeof state.relist?.mode==='string'?state.relist.mode:''
if(key.startsWith('solver.'))return state.solver?.[key.slice('solver.'.length)]!==false
if(key==='packShow.ratingMin'){const min=sanitizePackShowPolicy(state.packs?.show).ratingMin
return min===null?'':String(min)}
if(key.startsWith('packShow.')){const show=sanitizePackShowPolicy(state.packs?.show)
return show[key.slice('packShow.'.length)]===true}
if(key==='unassignedThreshold')return String(sanitizeExpensiveFrom(state.packs?.unassignedThreshold))
if(key==='dayXOff')return state.dayXOff===true
if(key==='onboarded')return state.onboarded===true
if(key==='filters')return Array.isArray(state.chosenFilters)?state.chosenFilters.length:0
if(key==='snipeConsent')return state.automation?.consent?.ok===true
return null}
export const organDefault=(organ)=>defaultOf(organ,REGISTRY_SOURCES)
export const organFloor=(organ)=>floorOf(organ,REGISTRY_SOURCES)??null
export function isCustom(organ,value){if(organ.kind==='toggle'){const fallback=organDefault(organ)
return typeof fallback==='boolean'?value!==fallback:false}
if(organ.kind==='number'||organ.kind==='text')return typeof value==='string'&&value.trim()!==''
if(organ.kind==='choice'){const fallback=organDefault(organ)
return fallback===null||fallback===undefined?false:value!==fallback}
return false}
export function isBelowFloor(organ,value,floor=organFloor(organ)){if(!floor||typeof value!=='string'||value.trim()==='')return false
const number=Number(value.replace(',','.').replace(/\s/g,''))
return Number.isFinite(number)&&number<floor.value}
const labelKeyOf=(state,sectionId,organ)=>(sectionId==='diagnostics'&&organ.id==='guide'&&state.onboarded!==true
?'onboarding.done':organ.labelKey)
function readoutOf(state,sectionId,organ){if(sectionId!=='diagnostics')return null
const value=state.diagnostics??{}
if(organ.id==='version'){const ready=value.bridge==='ok'&&typeof value.version==='string'&&value.version!==''
return ready?value.version:state.t('onboarding.unknown')}
if(organ.id==='errors')return String(Number.isSafeInteger(value.errors)&&value.errors>=0?value.errors:0)
return null}
function choicesOf(t,sectionId,organ){if(organ.id===AFTER_BUY_KEY)return[{id:AFTER_BUY.UNASSIGNED,label:t('snipe.settings.afterBuyUnassigned')},{id:AFTER_BUY.TRANSFER_LIST,label:t('snipe.settings.afterBuyTransferList')},{id:AFTER_BUY.TRANSFER_LIST_NOW,label:t('snipe.settings.afterBuyTransferListNow')},{id:AFTER_BUY.CLUB,label:t('snipe.settings.afterBuyClub')}]
if(sectionId==='ledger'&&organ.id==='scope')return[{id:'session',label:t('ledger.session')},{id:'all',label:t('ledger.allTime')}]
if(organ.id==='relistMode')return[{id:'market',label:t('transfers.gear.mode.market')},
{id:'step',label:t('transfers.gear.mode.step')},{id:'percent',label:t('transfers.gear.mode.percent')}]
return[]}
export function organView(state,section,organ){const t=state.t
const readout=readoutOf(state,section.id,organ)
const value=readout!==null?readout
:organ.id==='scope'&&section.id==='ledger'
?(state.ledgerScope==='all'?'all':'session')
:valueOf(state,organ,section.id)
const fallback=organDefault(organ)
const floor=organFloor(organ)
const status=typeof state.statusOf==='function'?state.statusOf:()=>'unknown'
const own=typeof organ.store==='string'&&organ.store.startsWith('toggles.')
const gate=own?null:(organ.feature??section.feature??null)
const gateStatus=gate===null?'active':status(gate)
const locked=gateStatus!=='active'
return{id:organ.id,section:section.id,kind:organ.kind,level:organ.level,zone:organ.zone,
place:organ.place,tier:organ.tier,
hit:typeof state.highlight==='string'&&state.highlight===organ.id,
label:t(labelKeyOf(state,section.id,organ)),hint:organ.hintKey?t(organ.hintKey):null,
unit:organ.unit?t(organ.unit):null,
value,
defaultLabel:fallback===null||fallback===undefined||typeof fallback==='boolean'?null:t('panel.organ.default',{value:fallback}),
defaultValue:fallback===null||fallback===undefined||typeof fallback==='boolean'?null:String(fallback),
inline:inlineOf(state,section,organ),
custom:isCustom(organ,value)||inlineOf(state,section,organ)?.custom===true,
muted:mutedOf(state,section,organ),
choices:choicesOf(t,section.id,organ),
floor:floor===null?null:{value:floor.value,label:t('panel.floor.ours',{value:floor.value})},
belowFloor:isBelowFloor(organ,typeof value==='string'?value:'',floor),
danger:organ.danger===true,
locked,lockLabel:locked?t(gateStatus==='switched-off'?'settings.switchedOff':'license.premiumRequired'):null,
busy:busyOf(state,section.id)||idleOf(state,section.id,organ),
route:routeOf(section.id,organ)}}
function inlineOf(state,section,organ){if(typeof organ.inline!=='string')return null
const inner=section.organs.find((one)=>one.id===organ.inline&&one.shipped===true)??null
return inner===null?null:organView(state,section,inner)}
function mutedOf(state,section,organ){if(typeof organ.dimWhen!=='string')return false
const by=section.organs.find((one)=>one.id===organ.dimWhen)??null
return by!==null&&valueOf(state,by,section.id)===true}
const ENGINES=Object.freeze({snipe:'buyer',seller:'seller'})
const engineOf=(state,sectionId)=>(ENGINES[sectionId]==='seller'?state.seller
:ENGINES[sectionId]==='buyer'?state.automation:null)
function busyOf(state,sectionId){if(sectionId==='snipe')return state.automation?.running===true
if(sectionId==='seller')return state.seller?.running===true
if(sectionId==='packs')return state.packs?.busy===true
if(sectionId==='club')return state.club?.busy===true
return false}
const PREMIUM_SECTION='premium'
const CLOUD_SECTION='cloud'
const CLOUD_CHOICE=Object.freeze(['takeCloud','takeLocal'])
function idleOf(state,sectionId,organ){if(sectionId===CLOUD_SECTION){const cloud=state.cloud??null
if(cloud?.busy===true)return true
return CLOUD_CHOICE.includes(organ?.id)&&cloud?.choose!==true}
if(sectionId!==PREMIUM_SECTION)return false
const license=state.license??null
if(organ.id==='clear')return license?.mode==='account'||!(license?.unlocked===true||license?.hasKey===true)
if(organ.id==='key'||organ.id==='apply')return license?.mode==='account'
if(organ.id==='account')return false
return false}
export function organsView(state,section,level){return section.organs
.filter((organ)=>organ.shipped===true&&organ.level===level&&inWindow(organ)&&typeof organ.inlineIn!=='string')
.map((organ)=>organView(state,section,organ))}
export function splitFine(fine){return{fine:fine.filter((organ)=>organ.tier!=='pro'),
pro:fine.filter((organ)=>organ.tier==='pro')}}
export function resetPlan(section){const plan=[]
for(const organ of section.organs){if(organ.shipped!==true)continue
const route=routeOf(section.id,organ)
if(route===null||route.via==='deed'||route.via==='license')continue
if(organ.kind==='number'||organ.kind==='text'){plan.push({route,value:''})
continue}
const fallback=defaultOf(organ,REGISTRY_SOURCES)
if(organ.kind==='toggle'){if(typeof fallback==='boolean')plan.push({route,value:fallback})
continue}
if(organ.kind==='choice')plan.push({route,value:fallback===null||fallback===undefined?'':fallback})}
return plan}
export function engineWord(t,engine){if(engine?.running===true)return t('automation.running')
if(engine?.reason)return t('automation.stoppedAs',{reason:t(stopReasonKey(engine.reason))})
return t('automation.idle')}
function engineAction(state,t,sectionId,engine,gate){const name=ENGINES[sectionId]
if(name===undefined)return null
const running=engine?.running===true
const stopping=running&&state.stopping?.[name]===true
return{deed:`${name}.${running?'stop':'start'}`,running,stopping,
label:t(stopping?'automation.stopping':(running?'automation.stop':'automation.start')),
disabled:gate!=='active'}}
export function dockModel(state){const t=state.t
const live=[]
for(const id of Object.keys(ENGINES)){const engine=engineOf(state,id)
if(engine?.running!==true)continue
const section=ORDERED_SECTIONS.find((one)=>one.id===id)??null
live.push({id,stop:STOP_DEEDS[id],name:section===null?id:t(section.titleKey),count:runCount(state,id,engine)})}
const known=(id)=>typeof id==='string'&&ORDERED_SECTIONS.some((one)=>one.id===id)
return{openLabel:t('panel.settings.open'),openHint:t('panel.settings.openHint'),
section:known(state.lastSection)?state.lastSection:FIRST_SECTION,
stopLabel:t('panel.dock.stop'),
stopHint:live.length>1?t('panel.dock.stopBothHint'):t('panel.dock.stopHint'),
line:live.length===0?null
:(live.length===1?t('panel.dock.one',{name:live[0].name,count:live[0].count})
:t('panel.dock.many',{count:live.length})),
running:live.map((one)=>one.id),
stops:live.map((one)=>one.stop)}}
const STOP_DEEDS=Object.freeze({snipe:'buyer.stop',seller:'seller.stop'})
function runCount(state,id,engine){const t=state.t
const stats=engine?.stats??null
const num=(value)=>(Number.isFinite(Number(value))?Number(value):0)
if(id==='seller')return t('panel.dock.listed',{count:num(stats?.listings)})
return t('panel.dock.bought',{searches:num(stats?.searches),count:num(stats?.purchases)})}
export function leverOf(state){const t=state.t
const section=ORDERED_SECTIONS.find((one)=>one.id==='diagnostics')??null
const organ=section?.organs.find((one)=>one.id==='dayXOff')??null
if(section===null||organ===null||organ.shipped!==true)return null
return{...organView(state,section,organ),
title:t('dayX.title'),hintFull:t('dayX.hintFull'),
mounted:state.dayXMounted!==false,
onLabel:t('dayX.on'),reloadLabel:t('dayX.reload')}}
export function sectionModel(state,sectionId){const section=ORDERED_SECTIONS.find((one)=>one.id===sectionId)??null
if(section===null)return null
const t=state.t
const view=state.panelView??{}
const status=typeof state.statusOf==='function'?state.statusOf:()=>'unknown'
const gate=section.feature===null?'active':status(section.feature)
const engine=engineOf(state,section.id)
const hasEngine=Object.hasOwn(ENGINES,section.id)
const main=organsView(state,section,'main')
const split=splitFine(organsView(state,section,'fine'))
const fine=split.fine
const pro=split.pro
const zones=zonesView(state,section,fine)
return{id:section.id,title:t(section.titleKey),hint:t(section.hintKey),
icon:section.icon,tier:section.tier,
locked:gate!=='active',
lockLabel:gate==='active'?null:t(gate==='switched-off'?'settings.switchedOff':'license.premiumRequired'),
stateLabel:hasEngine?engineWord(t,engine):null,
stateCount:hasEngine&&engine?.running===true?runCount(state,section.id,engine):null,
stateRunning:hasEngine&&engine?.running===true,
action:engineAction(state,t,section.id,engine,gate),
mainLabel:t('panel.block.main'),
runLabel:t('panel.block.run'),
resetLabel:t('panel.organ.reset'),resetHint:t('panel.organ.resetHint'),
customLabel:t('panel.organ.custom'),customHint:t('panel.organ.customHint'),
riskLabel:t('panel.organ.risk'),riskHint:t('panel.organ.riskHint'),
floorWarning:t('panel.floor.warning'),floorConfirm:t('panel.floor.confirm'),
floorPending:t('panel.floor.pending'),
pro,
proLabel:t('panel.block.pro'),
main,fine,fineZones:zones}}
export function zonesView(state,section,fine){if(section.zones.length===0)return null
const t=state.t
const byZone=new Map(section.zones.map((zone)=>[zone.id,[]]))
for(const organ of fine){const list=byZone.get(organ.zone)
if(list!==undefined)list.push(organ)}
return section.zones.map((zone)=>{const organs=byZone.get(zone.id)??[]
return{id:zone.id,title:t(zone.titleKey),organs,
grid:zone.grid===true}})}
export function searchModel(state,query){const t=state.t
const needle=typeof query==='string'?query.trim().toLowerCase():''
if(needle==='')return null
const rows=[]
for(const section of ORDERED_SECTIONS){const sectionTitle=t(section.titleKey)
for(const organ of section.organs){if(organ.shipped!==true)continue
if(typeof organ.inlineIn==='string')continue
const label=t(organ.labelKey)
const hint=organ.hintKey?t(organ.hintKey):''
const inner=typeof organ.inline==='string'?section.organs.find((one)=>one.id===organ.inline&&one.shipped===true)??null:null
const also=inner?t(inner.labelKey):''
if(!`${label} ${hint} ${also}`.toLowerCase().includes(needle))continue
const openable=inWindow(organ)
rows.push({section:section.id,organ:organ.id,label,hint,sectionTitle,
place:organ.place,openable,where:sectionTitle})}}
return{query:needle,rows,title:t('panel.search.title',{count:rows.length}),
empty:rows.length===0?t('panel.search.empty'):null}}
export function settingsModel(state){const t=state.t
const view=state.panelView??{}
const status=typeof state.statusOf==='function'?state.statusOf:()=>'unknown'
const open=typeof view.section==='string'&&ORDERED_SECTIONS.some((one)=>one.id===view.section)
?view.section:null
const searching=typeof state.query==='string'&&state.query.trim()!==''
const row=(section)=>({id:section.id,title:t(section.titleKey),icon:section.icon,tier:section.tier,
hint:t(section.hintKey),
locked:section.feature!==null&&status(section.feature)!=='active',
on:searching===false&&section.id===open})
const rows=ORDERED_SECTIONS.map(row)
return{title:t('panel.settings.title'),closeLabel:t('panel.settings.close'),
openLabel:t('panel.settings.open'),openHint:t('panel.settings.openHint'),
locale:{label:t('panel.settings.locale'),
now:typeof state.locale==='string'?state.locale:'',
options:[{id:'ru',short:'RU',label:'Русский'},{id:'en',short:'EN',label:'English'}]},
rail:{main:rows.filter((one)=>one.tier==='all'),
pro:rows.filter((one)=>one.tier==='pro'),
proLabel:t('panel.home.advanced'),proHint:t('panel.home.advancedHint'),
label:t('panel.tabs')}}}
