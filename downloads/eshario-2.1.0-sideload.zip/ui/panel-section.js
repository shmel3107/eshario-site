import{el,clear} from './dom.js'
import{isBelowFloor} from './panel-model.js'
const GLYPHS=Object.freeze({snipe:'🎯',solver:'🧩',seller:'🏷️',packs:'🎁',ledger:'💰',journal:'📜',keys:'⌨️',market:'📈',club:'🏟️',features:'🧰',premium:'🔑',diagnostics:'🩺',cloud:'☁️'})
const glyph=(name)=>GLYPHS[name]??'•'
export const glyphOf=glyph
export function renderSection(doc,section,hands,body={}){const{onDeed=()=>{},onOrgan=()=>{},onReset=()=>{}}=hands
const children=[head(doc,section,onDeed,onReset)]
children.push(el(doc,'div',{class:'section-hint',dataset:{sectionHint:section.id},text:section.hint}))
if(section.locked)children.push(el(doc,'div',{class:'section-locked',dataset:{sectionLocked:section.id},text:section.lockLabel}))
for(const node of body.top??[])children.push(node)
for(const group of groupsOf(section))children.push(groupBlock(doc,section,group,hands,body))
if((body.run??[]).length>0)children.push(block(doc,'run',section.runLabel,body.run))
for(const node of body.bottom??[])children.push(node)
return el(doc,'div',{class:'section-screen',dataset:{panelSection:section.id}},children)}
function head(doc,section,onDeed,onReset){const right=[]
if(section.stateLabel){const chip=[el(doc,'span',{class:'state-word',text:section.stateLabel})]
if(section.stateCount)chip.push(el(doc,'span',{class:'state-count',dataset:{sectionStateCount:section.id},text:section.stateCount}))
right.push(el(doc,'span',{class:section.stateRunning?'section-state on':'section-state',dataset:{sectionState:section.id}},chip))}
if(section.action){const run=el(doc,'button',{class:section.action.running?'fx-action section-run on':'fx-action section-run',text:section.action.label,attrs:{type:'button'},dataset:{sectionAction:section.id},on:{click:()=>onDeed(section.action.deed)}})
run.disabled=section.action.disabled===true
right.push(run)}
right.push(el(doc,'button',{class:'fx-action section-reset',text:section.resetLabel,attrs:{type:'button',title:section.resetHint},dataset:{sectionReset:section.id},on:{click:()=>onReset(section.id)}}))
return el(doc,'div',{class:'section-head fx-bar',dataset:{sectionHead:section.id}},[el(doc,'span',{class:'section-glyph',text:glyph(section.icon)}),el(doc,'span',{class:'section-title',text:section.title}),...right])}
const block=(doc,key,label,children,extra='')=>el(doc,'div',{class:extra?`block ${extra}`:'block',dataset:{panelBlock:key}},[el(doc,'h3',{dataset:{groupTitle:key},text:label}),...children])
const MIN_GROUP=2
function groupsOf(section){const parts=[]
if(section.main.length>0)parts.push({id:'main',title:section.mainLabel,organs:section.main,grid:false,zone:null,bucket:false})
const zones=section.fineZones??null
if(zones===null){if(section.fine.length>0)parts.push({id:'fine',title:null,organs:section.fine,grid:false,zone:null,bucket:true})}
else for(const zone of zones){if(zone.organs.length===0)continue
parts.push({id:`zone-${zone.id}`,title:zone.title,organs:zone.organs,grid:zone.grid===true,zone:zone.id,bucket:false})}
if((section.pro?.length??0)>0)parts.push({id:'pro',title:section.proLabel,organs:section.pro,grid:false,zone:null,bucket:false})
const groups=[]
for(const part of parts){const own=part.bucket===false&&part.organs.length>=MIN_GROUP
if(own||groups.length===0)groups.push({id:part.id,title:own?part.title:null,parts:[part]})
else groups[groups.length-1].parts.push(part)}
if(groups.length===1)groups[0].title=null
return groups}
function groupBlock(doc,section,group,hands,body){const inside=[]
for(const part of group.parts){
for(const node of part.zone===null?[]:body.zones?.[part.zone]??[])inside.push(node)
const rows=organRows(doc,section,part.organs,hands,body)
inside.push(part.grid
?el(doc,'div',{class:'organ-grid',dataset:{organGrid:part.zone??part.id}},rows)
:el(doc,'div',{class:'organ-rows'},rows))}
const kids=group.title===null?inside:[el(doc,'h3',{dataset:{groupTitle:group.id},text:group.title}),...inside]
return el(doc,'div',{class:group.title===null?'block bare':'block',dataset:{panelBlock:group.id}},kids)}
function writeOrgan(organ,value,hands){const res=hands.onOrgan(organ,value)
if(res?.ok===false||res?.redraw===true)return res
hands.onRedraw?.({soon:true})
return res}
function organRows(doc,section,organs,hands,body){const out=[]
for(const organ of organs){if(body.replaces?.has(organ.id)!==true){
out.push(organRow(doc,section,organ,hands,body.heading?.has(organ.id)===true))}
for(const node of body.organs?.[organ.id]??[])out.push(node)}
return out}
function organRow(doc,section,organ,hands,heading=false){const control=controlOf(doc,section,organ,hands,heading)
const tail=[]
if(organ.custom)tail.push(el(doc,'span',{class:'chip own',text:section.customLabel,attrs:{title:section.customHint},dataset:{organChip:'custom'}}))
if(organ.danger||organ.belowFloor)tail.push(el(doc,'span',{class:'chip risk',text:section.riskLabel,attrs:{title:section.riskHint},dataset:{organChip:'risk'}}))
const lock=organ.locked?el(doc,'div',{class:'organ-lock',dataset:{organLock:organ.id},text:organ.lockLabel}):null
const classes=['organ']
if(organ.belowFloor)classes.push('below')
if(organ.hit)classes.push('hit')
if(organ.muted)classes.push('muted')
if(tail.length>0){const chips=el(doc,'div',{class:'organ-tail'},tail)
const set=control.row.querySelector('.organ-set')
if(set===null)control.row.appendChild(chips)
else control.row.insertBefore(chips,set)}
return el(doc,'div',{class:classes.join(' '),dataset:{organ:`${section.id}.${organ.id}`,organKind:organ.kind}},[control.row,lock,...control.extra].filter(Boolean))}
function controlOf(doc,section,organ,hands,heading){
if(heading)return{row:el(doc,'div',{class:'row heading'},[el(doc,'span',{class:'organ-name',text:organ.label})]),extra:[]}
if(organ.kind==='toggle')return toggleControl(doc,organ,hands)
if(organ.kind==='number'||organ.kind==='text')return fieldControl(doc,section,organ,hands)
if(organ.kind==='choice')return choiceControl(doc,organ,hands)
return deedControl(doc,organ,hands)}
function markOf(organ){const route=organ.route??null
if(route===null)return{}
if(route.via==='toggle')return{feature:route.key}
if(route.via==='limit')return{limit:route.key}
if(route.via==='option')return{option:route.key}
if(route.via==='seller')return{sellerField:route.key}
return{}}
const setCell=(doc,kids)=>el(doc,'span',{class:'organ-set'},kids.filter(Boolean))
function toggleControl(doc,organ,hands){const id=`fut-companion-organ-${organ.section}-${organ.id}`
const input=el(doc,'input',{attrs:{type:'checkbox',id},dataset:{organInput:organ.id,...markOf(organ)},on:{change:(event)=>hands.onOrgan(organ,Boolean(event?.target?.checked))}})
input.checked=organ.value===true
input.disabled=organ.locked||organ.busy
const name=organ.inline?inlineName(doc,organ,hands):el(doc,'label',{class:'organ-name',text:organ.label,attrs:{for:id,...(organ.hint?{title:organ.hint}:{})}})
return{row:el(doc,'div',{class:'row toggle'},[name,setCell(doc,[input])]),extra:[]}}
function inlineName(doc,organ,hands){const inner=organ.inline
const field=el(doc,'input',{class:'limit inline',attrs:{type:'text',inputmode:'numeric',...(inner.defaultValue!==null?{placeholder:inner.defaultValue}:{}),'aria-label':inner.label},
dataset:{organInput:inner.id},on:{change:(event)=>{writeOrgan(inner,String(event?.target?.value??''),hands)}}})
field.value=typeof inner.value==='string'?inner.value:''
field.disabled=inner.locked||inner.busy
return el(doc,'span',{class:'organ-name with-field'},[el(doc,'span',{text:organ.label}),field])}
function fieldControl(doc,section,organ,hands){const id=`fut-companion-organ-${organ.section}-${organ.id}`
const readonly=organ.route===null
const extra=[]
if(readonly){return{row:el(doc,'div',{class:'row readonly'},[el(doc,'span',{class:'organ-name',attrs:organ.hint?{title:organ.hint}:{},text:organ.label}),setCell(doc,[el(doc,'span',{class:'organ-value',dataset:{organValue:organ.id},text:String(organ.value??'')})])]),extra}}
const guard=el(doc,'div',{class:'floor',dataset:{organFloor:organ.id}})
const input=el(doc,'input',{class:organ.belowFloor?'limit below':'limit',attrs:{type:'text',id,...(organ.kind==='number'?{inputmode:'numeric'}:{}),...(organ.defaultLabel!==null?{placeholder:organ.defaultLabel}:{})},dataset:{organInput:organ.id,...markOf(organ)},on:{change:(event)=>{const typed=String(event?.target?.value??'')
if(organ.floor&&isBelowFloor(organ,typed,{value:organ.floor.value,danger:true})){askFloor(doc,guard,section,organ,typed,hands)
return}
clear(guard)
writeOrgan(organ,typed,hands)}}})
input.value=typeof organ.value==='string'?organ.value:''
input.disabled=organ.locked||organ.busy
if(organ.belowFloor)extra.push(el(doc,'div',{class:'floor-warning',dataset:{organFloorWarning:organ.id},text:section.floorWarning}))
extra.push(guard)
return{row:el(doc,'div',{class:'row limit'},[el(doc,'label',{class:'organ-name',text:organ.label,attrs:{for:id,...(organ.hint?{title:organ.hint}:{})}}),setCell(doc,[input,organ.unit?el(doc,'span',{class:'unit',text:organ.unit}):null,organ.floor?el(doc,'span',{class:'unit floor-ours',dataset:{organFloorOurs:organ.id},text:organ.floor.label}):null])]),extra}}
function askFloor(doc,guard,section,organ,typed,hands){const id=`fut-companion-floor-${organ.section}-${organ.id}`
const confirm=el(doc,'input',{attrs:{type:'checkbox',id},dataset:{organFloorConfirm:organ.id},on:{change:(event)=>{if(event?.target?.checked!==true)return
writeOrgan(organ,typed,hands)}}})
clear(guard)
guard.appendChild(el(doc,'div',{class:'floor-warning',dataset:{organFloorWarning:organ.id},text:section.floorWarning}))
guard.appendChild(el(doc,'div',{class:'floor-pending',dataset:{organFloorPending:organ.id},text:section.floorPending}))
guard.appendChild(el(doc,'div',{class:'row'},[confirm,el(doc,'label',{text:section.floorConfirm,attrs:{for:id}})]))}
function choiceControl(doc,organ,hands){const buttons=organ.choices.map((choice)=>{const node=el(doc,'button',{class:organ.value===choice.id?'fx-action on':'fx-action',text:choice.label,attrs:{type:'button'},dataset:{organChoice:`${organ.id}:${choice.id}`,...markOf(organ)},on:{click:()=>hands.onOrgan(organ,choice.id)}})
if(organ.value===choice.id)node.setAttribute('aria-pressed','true')
node.disabled=organ.locked||organ.busy
return node})
return{row:el(doc,'div',{class:'row choice'},[el(doc,'span',{class:'organ-name',attrs:organ.hint?{title:organ.hint}:{},text:organ.label}),setCell(doc,buttons)]),extra:[]}}
function deedControl(doc,organ,hands){const node=el(doc,'button',{class:organ.kind==='link'?'fx-action organ-link':'fx-action',text:organ.label,attrs:{type:'button',...(organ.hint?{title:organ.hint}:{})},dataset:{organAction:organ.id},on:{click:()=>hands.onOrgan(organ,null)}})
node.disabled=organ.locked||organ.busy||organ.route===null
return{row:el(doc,'div',{class:'row deed'},[node]),extra:[]}}
