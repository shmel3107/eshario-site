import{el,replaceChildren,ensureTheme,THEME_STYLESHEET} from './dom.js'
import{CONTROLS_STYLESHEET} from './controls.js'
import{WINDOW_STYLESHEET,onWindowRaised} from './window.js'
import{createDialogs} from './dialog.js'
import{dockModel,sectionModel,searchModel,settingsModel,resetPlan,leverOf,ORDERED_SECTIONS,FIRST_SECTION} from './panel-model.js'
import{renderLever} from './panel-home.js'
import{renderSettingsWindow,SETTINGS_STYLESHEET,SETTINGS_LINK_ID} from './settings-window.js'
import{stopReasonKey} from '../features/automation-actions.js'
import{ALLOW_UNASSIGNED_OVERFLOW,bidsEnabled} from '../automation/options-input.js'
import{SNIPE_FEATURE} from '../features/snipe-shared.js'
import{taxRows,listingRows,netLine,TAX_RATE_PERCENT} from '../features/tax-actions.js'
import{journalRows} from '../features/journal-actions.js'
import{totalRows,dealRows} from '../features/ledger-actions.js'
import{rejectLabelKey} from '../licensing/key.js'
import{allowedUnassignedDispositions} from '../features/unassigned-recovery.js'
import{CLUB_TABLE_FILTERS,viewClubItemTable} from '../features/club-table.js'
import{HOTKEY_ACTIONS,detectConflicts} from '../features/hotkeys.js'
import{sanitizePackShowPolicy} from '../features/pack-show.js'
export const PANEL_ID='fut-companion-panel'
export const PANEL_STYLESHEET=new URL('./panel.css',import.meta.url).href
export const PANEL_BUILD='CLOUD2-7'
const PANEL_ANCHOR_ATTR='futPanelAnchor'
const DOCK_ANCHOR_ATTR='futDockAnchor'
function pinToTopLayer(host){if(typeof host?.showPopover!=='function')return 'page'
try{host.setAttribute?.('popover','manual')
host.showPopover()
return 'top-layer'}catch{try{host.removeAttribute?.('popover')}catch{/* нечего снимать */}
return 'page'}}
function reliftDock(layer){if(layer?.isConnected!==true)return
if(typeof layer.showPopover!=='function')return
try{if(layer.hasAttribute?.('popover')!==true)return
layer.hidePopover()
layer.showPopover()}catch{/* коробку могли снять между вопросом и показом */}}
const lockedLabel=(t,status)=>(status==='active'
?null
:t(status==='switched-off'?'settings.switchedOff':'license.premiumRequired'))
function engineStatusLabel(t,engine){if(engine?.running)return t('automation.running')
if(engine?.reason){return t('automation.stoppedAs',{reason:t(stopReasonKey(engine.reason))})}
return t('automation.idle')}
function recoveryDispositionLabel(t,disposition){if(disposition==='club')return t('packs.recovery.club')
if(disposition==='transfer')return t('packs.recovery.transfer')
if(disposition==='storage')return t('packs.recovery.storage')
return t('packs.recovery.keep')}
export function panelModel(state){const{t,registry,statusOf,filters=[],filtersStatus='unknown',notice=null,automation=null,automationStatus='unknown'
}=state
const filtersLocked=filtersStatus!=='active'
const filterRows=filtersLocked?[]:filters.map((set)=>({id:set.id,label:set.name,actions:[{action:'apply',label:t('filters.apply')},{action:'rename',label:t('filters.rename')},{action:'remove',label:t('filters.remove')}]}))
const snipeStatus=typeof statusOf==='function'?statusOf(SNIPE_FEATURE):'unknown'
const open=typeof state.panelView?.section==='string'
&&ORDERED_SECTIONS.some((one)=>one.id===state.panelView.section)
?state.panelView.section:null
const search=searchModel(state,state.query)
const said=freshNotice(notice,state)
return{title:t('settings.title'),t,
licenseKey:typeof state.licenseKey==='string'?state.licenseKey:'',
view:search!==null?'search':(open===null?'closed':'section'),
dock:dockModel(state),
settings:settingsModel(state),
lever:leverOf(state),
section:open===null?null:sectionModel(state,open),
search,
query:typeof state.query==='string'?state.query:'',
searchPlaceholder:t('panel.search.placeholder'),
searchClearLabel:t('panel.search.clear'),
notice:said?t(said.key,said.params):null,noticeTone:said?noticeTone(said.key):null,
sections:[diagnosticsSection(t,state),hotkeysSection(t,state.hotkeys,state.hotkeysStatus??'unknown'),packsSection(t,state.packs),{id:'filters',title:t('filters.title'),kind:'filters',rows:filterRows,locked:filtersLocked,lockedLabel:lockedLabel(t,filtersStatus),emptyLabel:t('filters.empty'),saveLabel:t('filters.save'),transfer:[{action:'export',label:t('filters.export')},{action:'import',label:t('filters.import')}]},taxSection(t,state.tax??null,state.taxStatus??'unknown'),automationSection(state,t,automation,automationStatus),sellerSection(t,state.seller??null,state.sellerStatus??'unknown'),journalSection(t,state.journal??null,automationStatus,state.sellerStatus??'unknown'),ledgerSection(t,state.ledger??null,automationStatus,state.sellerStatus??'unknown',state.ledgerScope),licenseSection(t,state.license??null),clubSection(t,state.club??null,state.clubStatus??'unknown'),snipeSection(t,automation,snipeStatus),cloudSection(t,state.cloud??null,state.locale)]}}
const STOPPING_NOTICE='automation.stopping'
function freshNotice(notice,state){if(notice?.key!==STOPPING_NOTICE)return notice??null
const busy=state.automation?.running===true||state.seller?.running===true
return busy?notice:null}
function rotationLine(t,rotation){const seats=Array.isArray(rotation?.seats)?rotation.seats:null
if(seats===null)return t('panel.snipe.rotation.idle')
if(seats.length===0)return t('panel.snipe.rotation.empty')
const line=seats.map((seat)=>`${seat?.defId??t('panel.snipe.rotation.any')} — ${Number.isSafeInteger(seat?.searches)?seat.searches:0}`).join(' · ')
return t('panel.snipe.rotation',{line})}
function snipeSection(t,automation,status){const locked=status!=='active'
return{id:'snipe',title:t('snipe.settings.title'),kind:'snipe',locked,lockedLabel:lockedLabel(t,status),
rotation:rotationLine(t,automation?.rotation??null)}}
function diagnosticsSection(t,state){const value=state.diagnostics??{}
const ready=value.bridge==='ok'
&&typeof value.version==='string'&&value.version!==''
const errors=Number.isSafeInteger(value.errors)&&value.errors>=0
?value.errors:0
const version=ready?value.version:t('onboarding.unknown')
const guide=state.onboarded!==true
return{id:'diagnostics',title:t('onboarding.title'),kind:'diagnostics',ready,statusLabel:t(ready?'onboarding.ready':'onboarding.problem'),version,errors,guide,safetyLabel:guide?t('onboarding.safety'):null,premiumLabel:guide?t('onboarding.premium'):null}}
export function comboText(combo){if(typeof combo!=='string'||combo==='')return ''
return combo.split('+').map((part)=>(part.length<=1?part.toUpperCase():`${part[0].toUpperCase()}${part.slice(1)}`)).join(' + ')}
const problemKey=(reason)=>({'browser-reserved':'hotkeys.reserved',duplicate:'hotkeys.duplicate'}[reason]??null)
const NOTICE_OK=Object.freeze(new Set(['bin.searching','bin.result','hotkeys.cardPicked','hotkeys.relisted','hotkeys.searchRepeated','hotkeys.listAtMin.ready','packs.opened','packs.picks.confirmed','packs.recovery.moved','packs.recovery.discarded','sbc.solved','sbc.submitted','filters.applied','filters.saved','filters.removed','filters.renamed','filters.exported','filters.imported',
'rewardFlow.claimed',
'storage.returned'
]))
export function noticeTone(key){if(typeof key!=='string'||key==='')return 'ok'
if(/(?:error|failed)$/i.test(key))return 'bad'
return NOTICE_OK.has(key)?'ok':'warn'}
function hotkeysSection(t,bindings,status){const locked=status!=='active'
const map=bindings&&typeof bindings==='object'?bindings:{}
const problems=detectConflicts(map).problems
const bound=Object.values(map).filter((combo)=>typeof combo==='string'&&combo!=='').length
return{id:'hotkeys',title:t('hotkeys.title'),kind:'hotkeys',locked,lockedLabel:lockedLabel(t,status),hint:t('hotkeys.panelHint'),
summary:locked?null:t('hotkeys.panelSummary',{count:bound}),
problem:locked||problems.length===0?null:t(problemKey(problems[0].reason)??'hotkeys.duplicate',{combo:comboText(problems[0].combo)})}}
function packsSection(t,value={}){
const selected=new Set(Array.isArray(value?.picks?.selected)?value.picks.selected:[])
const recovery=value?.recovery??{}
const automation=value?.automation??{}
const show=sanitizePackShowPolicy(value?.show)
const discard=recovery.discardPreview
const picks=Array.isArray(value?.picks?.items)?value.picks.items.map((item)=>({...item,selected:selected.has(item.index),label:t('packs.picks.row',{number:item.index+1,id:item.definitionId,rating:item.rating,mode:t(item.tradable?'packs.tradeable':'packs.untradeable')})})):[]
const recoveryItems=Array.isArray(recovery.items)?recovery.items.map((item)=>({...item,label:t('packs.recovery.row',{id:item.id,mode:t(item.tradable?'packs.tradeable':'packs.untradeable'),kind:t(item.duplicate?'packs.recovery.duplicate':'packs.recovery.regular'),value:item.discardValue,plan:recoveryDispositionLabel(t,item.disposition)}),actions:allowedUnassignedDispositions(item).map((disposition)=>({disposition,label:recoveryDispositionLabel(t,disposition)}))})):[]
return{id:'packs',kind:'packs',title:t('packs.title'),picks,recoveryItems,
busy:value?.busy===true,picksBusy:value?.picks?.busy===true,picksRefreshLabel:t(value?.picks?.busy===true?'packs.picks.busy':'packs.picks.refresh'),picksEmptyLabel:t(value?.picks?.loaded===true?'packs.picks.empty':'packs.picks.idle'),picksSummaryLabel:t('packs.picks.summary',{selected:selected.size,count:value?.picks?.availablePicks??0,total:picks.length}),picksFull:selected.size>=(value?.picks?.availablePicks??0),picksReady:value?.picks?.review?.ok===true,picksReadyLabel:t('packs.picks.ready'),picksConfirmLabel:t('packs.picks.confirm'),recoveryBusy:recovery.busy===true,recoveryRefreshLabel:t(recovery.busy===true?'packs.recovery.busy':'packs.recovery.refresh'),recoveryLabel:t(recovery.loaded===true?'packs.recovery.summary':'packs.recovery.idle',{count:recovery.count??0,keep:recovery.keep??0,club:recovery.club??0,transfer:recovery.transfer??0,storage:recovery.storage??0}),recoveryResetLabel:t('packs.recovery.reset'),recoveryReviewLabel:t('packs.recovery.review'),recoveryReviewDisabled:recovery.busy===true||recovery.loaded!==true
||(recovery.club??0)+(recovery.transfer??0)+(recovery.storage??0)===0,recoveryReviewStatus:recovery.review
?t('packs.recovery.reviewed',{status:recovery.review.ok===true?'READY':recovery.review.reason??'BLOCKED'
}):'',recoveryDiscardLabel:discard?.ok===true?t('packs.recovery.discardPreview',{count:discard.count,value:discard.value,items:discard.items.map((x)=>`${x.id}/${x.definitionId}`).join(', ')}):null,recoveryDiscardApplyLabel:discard?.ok===true&&discard.count>0
?t('packs.recovery.discardApply'):null,recoveryApply:recovery.review?.ok===true
?['club','transfer','storage']
.filter((destination)=>(recovery[destination]??0)>0)
.map((destination)=>({destination,label:t('packs.recovery.apply',{destination:recoveryDispositionLabel(t,destination)})})):[],automationBusy:automation.busy===true,automationPreviewDisabled:automation.busy===true||value?.busy===true
||value?.picks?.busy===true||recovery.busy===true,automationPreviewLabel:t(automation.busy===true
?'packs.automation.busy':'packs.automation.preview'),automationStepKey:automation.review?.ok===true?automation.review.nextPack?.key:null,automationStepLabel:t('packs.automation.step'),automationOutcomeLabel:automation.outcome
?t(automation.outcome.ok===true
?({unassigned:'packs.automation.outcomeUnassigned','pending-pick':'packs.automation.outcomePick'}[automation.outcome.kind]
??'packs.automation.outcomeUnknown')
:'packs.automation.outcomeUnknown',{count:automation.outcome.count??0,reason:automation.outcome.reason??'unknown-state'
})
:null,automationActionLabel:automation.outcomeAction
&&['pending-pick','unassigned'].includes(automation.outcomeAction.kind)
?t(automation.outcomeAction.executed===true
?(automation.outcomeAction.action==='discard'
?(automation.outcomeAction.ok===true
?'packs.recovery.discarded':'packs.recovery.discardFailed')
:automation.outcomeAction.kind==='pending-pick'
?(automation.outcomeAction.ok===true
?'packs.automation.pickDone':'packs.automation.pickFailed')
:(automation.outcomeAction.ok===true
?'packs.automation.recoveryDone':'packs.automation.recoveryFailed'))
:(automation.outcomeAction.ok===true
?'packs.automation.actionAllowed':'packs.automation.actionBlocked'),{action:t({pick:'packs.automation.autoPick',recovery:'packs.automation.autoRecovery',discard:'packs.automation.autoDiscard'}[automation.outcomeAction.action]??'packs.automation.autoRecovery'),reason:automation.outcomeAction.reason??'unknown-state',count:automation.outcomeAction.rewards??automation.outcomeAction.count??0,value:automation.outcomeAction.value??0,destination:(automation.outcomeAction.destinations
??[automation.outcomeAction.destination]).map((destination)=>t({club:'packs.recovery.club',transfer:'packs.recovery.transfer',storage:'packs.recovery.storage'
}[destination]??'packs.recovery.keep')).join(' → ')}):null,automationContinuationLabel:automation.continuation
?t(automation.continuation.executed===true&&automation.continuation.ok===true
?'packs.opened':automation.continuation.ok===true
?'packs.automation.continuationReady':'packs.automation.continuationBlocked',{id:automation.continuation.nextPack?.id??'—',remaining:automation.continuation.sessionRemaining??0,reason:automation.continuation.reason??'unknown-state',count:automation.continuation.items?.length??0}):null,automationStatusLabel:automation.review
?t(automation.review.ok===true
?'packs.automation.ready':'packs.automation.blocked',{id:automation.review.nextPack?.id??'—',maxPacks:automation.review.maxPacks??'—',reason:automation.review.reason??'unknown-state'
})
:t('packs.automation.idle')}}
function taxSection(t,tax,status){const locked=status!=='active'
const price=typeof tax?.price==='string'?tax.price:''
const want=typeof tax?.want==='string'?tax.want:''
const label=(row)=>t(row.key,row.params)
return{id:'tax',title:t('tax.label'),kind:'tax',locked,lockedLabel:lockedLabel(t,status),rateLabel:t('tax.rate',{percent:TAX_RATE_PERCENT}),fields:[{key:'price',label:t('tax.price'),value:price},{key:'want',label:t('tax.wantNet'),value:want}],
rows:locked?[]:unique([...taxRows(price).rows,...listingRows(want).rows].map(label))}}
function unique(items){return items.filter((item,i)=>items.indexOf(item)===i)}
function netAfterTaxRow(t,listedValue,dryRun=false){const line=netLine(listedValue)
if(!line)return[]
return[{id:dryRun?'wouldNet':'netAfterTax',label:t(dryRun?'panel.dry.wouldNet':'seller.stat.netAfterTax'),value:line.params.coins}]}
function sellerStatRows(t,stats,dryRun){return[{id:dryRun?'wouldList':'listings',label:t(dryRun?'panel.dry.wouldList':'seller.stat.listings'),value:stats.listings},{id:dryRun?'wouldListValue':'listedValue',label:t(dryRun?'panel.dry.wouldListValue':'seller.stat.listedValue'),value:stats.listedValue},
...netAfterTaxRow(t,stats.listedValue,dryRun),{id:dryRun?'wouldQuickSell':'quickSells',label:t(dryRun?'panel.dry.wouldQuickSell':'seller.stat.quickSells'),value:stats.quickSells},{id:'relisted',label:t('seller.stat.relisted'),value:stats.relisted},{id:'cleared',label:t('seller.stat.cleared'),value:stats.cleared}]}
function automationSection(state,t,automation,status){const locked=status!=='active'
const running=Boolean(automation?.running)
const dryRun=automation?automation.dryRun!==false:true
const stats=automation?.stats??null
return{id:'automation',kind:'automation',locked,lockedLabel:lockedLabel(t,status),running,dryRun,statusLabel:engineStatusLabel(t,automation),
warning:dryRun?null:t('automation.realWarning'),actionLabel:running?t('automation.stop'):t('automation.start'),
overflowWarning:automation?.options?.[ALLOW_UNASSIGNED_OVERFLOW]===true
?t('automation.overflowWarning')
:null,
bidWarning:bidsEnabled(automation?.options??{})?t('automation.bidWarning'):null,rows:stats
?[{id:'searches',label:t('automation.stat.searches'),value:stats.searches},{id:dryRun?'wouldBuy':'purchases',label:t(dryRun?'automation.stat.wouldBuy':'automation.stat.purchases'),value:dryRun?stats.wouldBuy:stats.purchases},{id:'bids',label:t('automation.stat.bids'),value:stats.bids??0},{id:'outbid',label:t('automation.stat.outbid'),value:stats.outbid??0},{id:'actions',label:t('automation.stat.actions'),value:stats.actions},{id:'spent',label:t('automation.stat.spent'),value:stats.spent},{id:'coins',label:t('automation.stat.coins'),value:stats.coins},{id:'policySkipped',label:t('automation.stat.policySkipped'),value:Number.isSafeInteger(stats.policySkipped)?stats.policySkipped:0},{id:'listings',label:t('seller.stat.listings'),value:stats.listings??0},{id:'listedValue',label:t('seller.stat.listedValue'),value:stats.listedValue??0}]
:[]}}
function sellerSection(t,seller,status){const locked=status!=='active'
const running=Boolean(seller?.running)
const dryRun=seller?seller.dryRun!==false:true
const allowQuickSell=seller?.options?.allowQuickSell===true
const stats=seller?.stats??null
return{id:'seller',title:t('seller.title'),kind:'seller',locked,lockedLabel:lockedLabel(t,status),running,dryRun,allowQuickSell,statusLabel:engineStatusLabel(t,seller),warning:dryRun?null:t('seller.realWarning'),
quickSellWarning:allowQuickSell?t('seller.quickSellWarning'):null,actionLabel:running?t('automation.stop'):t('automation.start'),
dryNote:dryRun?t('panel.dry.note'):null,rows:stats?sellerStatRows(t,stats,dryRun):[]}}
function journalSection(t,journal,buyerStatus,sellerStatus){const locked=buyerStatus!=='active'&&sellerStatus!=='active'
const switchedOff=buyerStatus==='switched-off'||sellerStatus==='switched-off'
return{id:'journal',title:t('journal.title'),kind:'journal',locked,lockedLabel:locked
?t(switchedOff?'settings.switchedOff':'license.premiumRequired')
:null,emptyLabel:t('journal.empty'),
rows:locked?[]:journalRows(t,journal)}}
function ledgerSection(t,ledger,buyerStatus,sellerStatus,scope){const locked=buyerStatus!=='active'&&sellerStatus!=='active'
const switchedOff=buyerStatus==='switched-off'||sellerStatus==='switched-off'
const allTime=ledger?.allTime??null
const empty=!allTime
||(allTime.bought.count===0&&allTime.sold.count===0&&allTime.quick.count===0)
return{id:'ledger',title:t('ledger.title'),kind:'ledger',locked,lockedLabel:locked
?t(switchedOff?'settings.switchedOff':'license.premiumRequired')
:null,sessionLabel:t('ledger.session'),allTimeLabel:t('ledger.allTime'),
scope:scope==='all'?'all':'session',
taxNotice:t('tax.unverified'),estimatedNote:!locked&&allTime?.estimated?t('ledger.estimatedNote'):null,empty,sessionRows:locked||empty||scope==='all'?[]:totalRows(t,ledger?.session??null),allTimeRows:locked||empty||scope!=='all'?[]:totalRows(t,allTime),dealRows:locked||empty?[]:dealRows(t,allTime)}}
function licenseSection(t,license){
const unlocked=license?.unlocked===true
const reason=typeof license?.reason==='string'?license.reason:null
const left=Number.isFinite(license?.exp)&&Number.isFinite(license?.now)
?Math.max(1,Math.ceil((license.exp-license.now)/86_400_000))
:null
if(license?.mode==='account'){let statusLabel
if(unlocked)statusLabel=t('license.accountActive',{account:license?.account?.hint??'',days:left??'?'})
else if(reason==='signed-out'||reason==='unauthorized')statusLabel=t('license.accountRequired')
else if(reason==='inactive')statusLabel=t('license.accountInactive')
else statusLabel=t('license.accountUnavailable')
return{id:'license',title:t('license.title'),kind:'license',locked:false,unlocked,statusLabel,mode:'account',hint:t('license.accountHint')}}
let statusLabel
if(unlocked){
statusLabel=left===null?t('license.active'):t('license.activeUntil',{days:left})}else if(reason!==null){statusLabel=t('license.rejected',{reason:t(rejectLabelKey(reason))})}else{statusLabel=t('license.none')}
return{id:'license',title:t('license.title'),kind:'license',locked:false,unlocked,statusLabel,mode:license?.mode==='legacy'?'legacy':'plain',hint:license?.mode==='legacy'?t('license.legacyHint'):t('license.hint')}}
function clubSection(t,club,status){const locked=status!=='active';
const analysis=club?.analysis??null;
const summary=analysis?.summary??null;
const table=analysis?.table?clubTableModel(t,analysis.table,club?.tableFilters,club?.tablePage):null;
return{id:'club',title:t('club.title'),kind:'club',locked,lockedLabel:lockedLabel(t,status),busy:Boolean(club?.busy),statusLabel:club?.notice?t(club.notice.key,club.notice.params):t('club.idle'),summaryLabel:summary
?t('club.summary',{total:summary.total,sellable:summary.sellable,untradeable:summary.untradeable})
:null,valueLabel:club?.value?t(club.value.key,club.value.params):null,duplicatesLabel:analysis
?(analysis.duplicates.length===0
?t('club.noDuplicates')
:t('club.duplicates',{cards:analysis.duplicates.length,extra:analysis.duplicates.reduce((sum,d)=>sum+d.extra,0)}))
:null,candidatesLabel:analysis?t('club.candidates',{count:analysis.candidates.length}):null,
rows:(club?.rows??[]).map((row)=>({id:String(row.id),label:t('club.dupRow',{name:row.name,count:row.count,sellable:row.sellable}),priceLabel:marketPriceLabel(t,row.price)})),marketPriceLabel:t('club.marketPrice'),table}}
function clubTableModel(t,table,filters,page){const view=viewClubItemTable(table,filters,page)
const columns=view.columns.map((column)=>({key:column.key,label:t(column.labelKey)}))
const cells=(row)=>columns.map((column)=>({key:column.key,value:clubTableCell(t,row,column.key)}))
const sources=[...new Set(view.rows.flatMap((row)=>row.priceEvidence?.sources??[]).filter(Boolean))]
const from=[...new Set(view.rows.flatMap((row)=>row.priceEvidence?.from??[]).filter(Boolean))]
const sourceLabel=[...sources,...from.filter((value)=>!sources.includes(value))].map((value)=>clubPriceSource(t,value)).join(', ')||t('clubTable.source.none')
const observedAt=table?.pricing?.observedAt
return{columns,rows:view.rows.map((row)=>({id:row.id,cells:cells(row)})),totalRow:{id:'total',cells:columns.map((column)=>({key:column.key,value:clubTableTotalCell(t,view.totals,column.key)}))},filters:CLUB_TABLE_FILTERS.map((filter)=>({key:filter.key,label:t(filter.labelKey),value:typeof filters?.[filter.key]==='string'?filters[filter.key]:''})),page:view.page,pages:view.pages,total:view.total,previousLabel:t('clubTable.previous'),nextLabel:t('clubTable.next'),exportLabel:t('clubTable.export'),pageLabel:t('clubTable.page',{page:view.page,pages:view.pages,total:view.total}),evidenceLabel:t('clubTable.evidence',{source:sourceLabel,time:Number.isFinite(observedAt)?new Date(observedAt).toLocaleString():'—'})}}
function clubTableCell(t,row,key){if(key==='name')return row.name
if(key==='count')return String(row.count)
if(['discard','bought','price','profit'].includes(key))return clubMoney(t,row.money?.[key])
const field=row.fields?.[key]
if(!field||field.values.length===0)return t('clubTable.unknown')
return field.values.map((value)=>key==='tradeable'?t(value===true?'clubTable.yes':'clubTable.no'):String(value)).join(' / ')}
function clubTableTotalCell(t,totals,key){if(key==='name')return t('clubTable.total')
if(key==='count')return String(totals?.count??0)
if(['discard','bought','price','profit'].includes(key))return clubMoney(t,totals?.money?.[key])
return t('clubTable.unknown')}
function clubMoney(t,value){if(!value||value.state==='unknown')return t('clubTable.unknown')
return value.state==='partial'
?t('clubTable.moneyPartial',{coins:value.coins,known:value.known,total:value.total})
:t('clubTable.money',{coins:value.coins})}
function clubPriceSource(t,value){if(value==='external-cache'||value==='cache')return t('clubTable.source.cache')
if(value==='configured-fallback'||value==='configured external fallback'||value==='source')return t('clubTable.source.fallback')
return String(value)}
function marketPriceLabel(t,price){if(!price||typeof price.state!=='string')return null;
if(price.state==='busy')return t('club.marketPriceBusy');
if(price.state==='known')return t('club.marketPriceValue',{coins:price.coins});
if(price.state==='unknown')return t('club.marketPriceUnknown');
if(price.state==='throttled')return t('club.marketPriceThrottled',{seconds:price.seconds});
return t('club.marketPriceFailed',{reason:String(price.reason??'')})}
const DEEDS=Object.freeze({
'buyer.start':(h)=>{if(h.onAutomation('start')===true)closeSettings(h)},
'buyer.stop':(h)=>h.onAutomation('stop'),
'seller.start':(h)=>h.onSeller('start'),
'seller.stop':(h)=>h.onSeller('stop'),
'club.analyze':(h)=>h.onClub('analyze'),
'hotkeys.open':(h)=>h.onHotkey('window',null),
'journal.export':(h)=>h.onJournal('export'),
'ledger.csv':(h)=>h.onLedger('csv'),
'ledger.reset':(h)=>h.onLedger('reset'),
'premium.apply':(h,model)=>h.onLicense('apply',String(model.licenseKey??'')),
'premium.clear':(h)=>h.onLicense('clear',''),
'premium.account':(h)=>h.onLicense('account',''),
'diagnostics.check':(h)=>h.onDiagnostics(),
'cloud.sync':(h)=>h.onCloud('sync'),
'cloud.saveFile':(h)=>h.onCloud('save-file'),
'cloud.loadFile':(h)=>h.onCloud('load-file'),
'cloud.takeCloud':(h)=>h.onCloud('take-cloud'),
'cloud.takeLocal':(h)=>h.onCloud('take-local'),
'diagnostics.guide':(h,model)=>h.onOnboarding(bodyOf(model,'diagnostics')?.guide===true),
'solver.locks':(h)=>h.onPanelView({section:'club'}),
'solver.reread':(h)=>h.onSolverReread(),
})
const bodyOf=(model,id)=>(model.sections??[]).find((one)=>one.id===id)??null
function closeSettings(h){h.onPanelView({section:null})
h.onView('query','')}
function wire(model,handlers){const h={onRedraw:()=>{},onToggle:()=>{},onLimit:()=>{},onOption:()=>{},onSellerOption:()=>{},onDryRun:()=>{},onSeller:()=>{},onAutomation:()=>{},onPacks:()=>{},onLocale:()=>{},onRelist:()=>{},onDayX:()=>{},onOnboarding:()=>{},onSolver:()=>{},onDiagnostics:()=>{},onClub:()=>{},onHotkey:()=>{},onJournal:()=>{},onLedger:()=>{},onLicense:()=>{},onSolverReread:()=>{},onCloud:()=>{},onPanelView:()=>{},onView:()=>{},...handlers}
const deed=(name)=>{const hand=DEEDS[name]
if(typeof hand==='function')hand(h,model)}
const onOrgan=(organ,value)=>{const route=organ?.route??null
if(route===null)return undefined
const via=route.via
const key=route.key
if(via==='toggle')return h.onToggle(key,value===true)
if(via==='limit')return h.onLimit(key,String(value??''))
if(via==='option')return h.onOption(key,value)
if(via==='seller')return h.onSellerOption(key,value)
if(via==='buyerDryRun')return h.onDryRun(value===true)
if(via==='sellerDryRun')return h.onSeller('dryRun',value===true)
if(via==='packShow')return h.onPacks('show-policy',{field:key,value:value===true})
if(via==='packShowRating')return h.onPacks('show-rating',{value:String(value??'')})
if(via==='packThreshold')return h.onPacks('unassigned-threshold',{field:key,value:String(value??'')})
if(via==='locale')return h.onLocale(value)
if(via==='relist')return h.onRelist(key,value)
if(via==='dayX')return h.onDayX(value===true)
if(via==='solver')return h.onSolver(key,value===true)
if(via==='onboarding')return h.onOnboarding(value===true)
if(via==='license')return h.onView('licenseKey',String(value??''))
if(via==='view')return h.onView(key,value)
if(via==='deed')return deed(key)
return undefined}
return{...h,onDeed:deed,onOrgan,
onOpen:(id)=>h.onPanelView({section:id}),
onHome:()=>h.onPanelView({section:null}),
onCloseSettings:()=>closeSettings(h),
onStopAll:()=>{for(const name of model.dock?.stops??[])deed(name)},
onReset:(id)=>{const section=ORDERED_SECTIONS.find((one)=>one.id===id)??null
if(section===null)return
for(const step of resetPlan(section))onOrgan({route:step.route},step.value)
h.onRedraw()}}}
export function renderPanel(model,doc,handlers={},show={}){const hands=wire(model,handlers)
const settings=model.view==='closed'?null:renderSettingsWindow(doc,model,hands,{
body:model.section===null?{}:bodyFor(doc,model,model.section.id,hands),
onClose:()=>hands.onCloseSettings(),
onSearch:(value)=>hands.onView('query',value)})
return el(doc,'div',{class:'shell',dataset:{futCompanion:'shell',futPanelBuild:PANEL_BUILD}},[show.dock===false?null:dockNode(doc,model,hands,show),settings].filter(Boolean))}
export function renderDock(model,doc,handlers={},show={}){return dockNode(doc,model,wire(model,handlers),show)}
function dockNode(doc,model,hands,show){const run=model.dock.line!==null
const said=model.notice&&show.dockNotice!==false
?el(doc,'div',{class:'dock-notice',dataset:{dockNotice:'1',noticeTone:model.noticeTone??'ok'},text:model.notice}):null
const kids=[el(doc,'button',{class:'dock-toggle',text:model.title,
attrs:{type:'button',title:model.dock.openHint,'aria-label':model.dock.openHint},
dataset:{dockToggle:'1'},
on:{click:()=>hands.onOpen(model.dock.section)}})]
if(run){kids.push(el(doc,'span',{class:'dock-run',dataset:{dockRun:model.dock.running.join(' ')},text:model.dock.line}))
kids.push(el(doc,'button',{class:'fx-action dock-stop',text:model.dock.stopLabel,
attrs:{type:'button',title:model.dock.stopHint},
dataset:{dockStop:String(model.dock.running.length)},
on:{click:()=>hands.onStopAll()}}))}
return el(doc,'div',{class:run?'dock running':'dock',dataset:{futCompanionDock:'1'}},
[said,el(doc,'div',{class:'dock-row'},kids)].filter(Boolean))}
function textFieldRow(doc,prefix,field,dataKey,onChange,disabled=false,numeric=true,labelClass='name'
){const id=`fut-companion-${prefix}-${field.key}`;
const input=el(doc,'input',{class:'limit',attrs:{type:'text',...(numeric?{inputmode:'numeric'}:{}),...(typeof field.hint==='string'&&field.hint!==''?{placeholder:field.hint}:{}),id},dataset:{[dataKey]:field.key},on:{change:(event)=>onChange(field.key,String(event?.target?.value??''))}});
input.value=field.value;
input.disabled=disabled;
return el(doc,'div',{class:'row limit'},[el(doc,'label',{class:labelClass,text:field.label,attrs:{for:id}}),input,field.unit?el(doc,'span',{class:'unit',text:field.unit}):null].filter(Boolean))}
const PREMIUM_SECTION='premium'
function bodyFor(doc,model,id,hands){const body={organs:{},zones:{},run:[],top:[],bottom:[],heading:new Set(),replaces:new Set()}
if(id==='snipe')return snipeBody(doc,model,hands,body)
if(id==='seller')return sellerBody(doc,model,hands,body)
if(id==='ledger')return ledgerBody(doc,model,body)
if(id==='journal')return journalBody(doc,model,body)
if(id==='hotkeys')return hotkeysBody(doc,model,body)
if(id==='cloud')return cloudBody(doc,model,body)
if(id==='market')return marketBody(doc,model,hands,body)
if(id==='club')return clubBody(doc,model,hands,body)
if(id===PREMIUM_SECTION)return premiumBody(doc,model,body)
if(id==='diagnostics')return diagnosticsBody(doc,model,hands,body)
return body}
const info=(doc,text,dataset,className='hint small')=>el(doc,'div',{class:className,dataset,text})
const lockLine=(doc,id,section)=>(section?.locked===true
?el(doc,'div',{class:'section-locked',dataset:{sectionLocked:id},text:section.lockedLabel??''})
:null)
function actionButton(doc,text,dataset,onClick,className='fx-action',attrs={type:'button'}){return el(doc,'button',{class:className,text,attrs,dataset,on:{click:onClick}})}
const statRow=(doc,row,key)=>el(doc,'div',{class:'row stat',dataset:{[key]:row.id}},[el(doc,'span',{class:'name',text:row.label}),el(doc,'span',{text:String(row.value)})])
function snipeBody(doc,model,hands,body){const snipe=bodyOf(model,'snipe')
const engine=bodyOf(model,'automation')
if(snipe===null||engine===null||engine.locked)return body
if(engine.warning)body.top.push(info(doc,engine.warning,{automationWarning:'1'},'warning'))
if(engine.bidWarning)body.bottom.push(info(doc,engine.bidWarning,{bidWarning:'1'},'warning'))
if(engine.overflowWarning)body.bottom.push(info(doc,engine.overflowWarning,{overflowWarning:'1'},'warning'))
if(engine.rows.length===0)return body
body.run=[info(doc,snipe.rotation,{snipe:'rotation'})]
body.run.push(...statsOf(doc,engine))
return body}
const statsOf=(doc,section)=>(section?.rows??[]).map((row)=>statRow(doc,row,'stat'))
function sellerBody(doc,model,hands,body){const section=bodyOf(model,'seller')
if(section===null||section.locked)return body
if(section.warning)body.top.push(info(doc,section.warning,{sellerWarning:'1'},'warning'))
if(section.quickSellWarning)body.organs.allowQuickSell=[info(doc,section.quickSellWarning,{quickSellWarning:'1'},'warning')]
const run=(section.rows??[]).map((row)=>statRow(doc,row,'sellerStat'))
if(section.dryNote&&run.length>0)run.unshift(info(doc,section.dryNote,{sellerDry:'1'},'dry-note'))
body.run=run
return body}
function ledgerBody(doc,model,body){const section=bodyOf(model,'ledger')
const lock=lockLine(doc,'ledger',section)
if(lock)body.top.push(lock)
if(section===null||section.locked)return body
if(section.empty)return body
const rows=[]
const group=(label,list,scope)=>{if(list.length===0)return
rows.push(info(doc,label,{ledgerGroup:scope},'hint'))
for(const row of list)rows.push(info(doc,row.label,{ledgerRow:`${scope}.${row.id}`}))}
group(section.sessionLabel,section.sessionRows,'session')
group(section.allTimeLabel,section.allTimeRows,'all')
for(const row of section.dealRows)rows.push(info(doc,row.label,{ledgerDeal:row.id}))
if(section.estimatedNote)rows.push(info(doc,section.estimatedNote,{ledgerEstimated:'1'}))
rows.push(info(doc,section.taxNotice,{ledgerTax:'1'}))
body.run=rows
return body}
function journalBody(doc,model,body){const section=bodyOf(model,'journal')
body.heading.add('recent')
const lock=lockLine(doc,'journal',section)
if(lock)body.top.push(lock)
if(section===null||section.locked)return body
body.organs.recent=section.rows.length===0
?[el(doc,'div',{class:'empty',text:section.emptyLabel})]
:section.rows.map((row)=>info(doc,row.label,{journalRow:row.id}))
return body}
const CLOUD_LINES=Object.freeze({unknown:'cloud.line.unknown',empty:'cloud.line.empty',
pushed:'cloud.line.pushed',waiting:'cloud.line.waiting',first:'cloud.line.first',conflict:'cloud.line.conflict',
ahead:'cloud.line.ahead',full:'cloud.line.full',error:'cloud.line.error',
taken:'cloud.line.taken',saved:'cloud.line.saved',loaded:'cloud.line.loaded','bad-file':'cloud.line.badFile'})
const CLOUD_WARNINGS=Object.freeze(['conflict','full','error','bad-file'])
function cloudWhen(at,locale){if(!Number.isSafeInteger(at))return '—'
try{return new Date(at).toLocaleString(typeof locale==='string'&&locale!==''?locale:undefined)}
catch{return new Date(at).toISOString()}}
function cloudSection(t,cloud,locale){const view=cloud??{}
const phase=typeof view.phase==='string'&&Object.hasOwn(CLOUD_LINES,view.phase)?view.phase:'unknown'
return{id:'cloud',phase,
warn:CLOUD_WARNINGS.includes(phase),
line:t(CLOUD_LINES[phase],{revision:String(view.revision??''),
when:cloudWhen(view.at,locale),reason:String(view.reason??'')})}}
function cloudBody(doc,model,body){const section=bodyOf(model,'cloud')
if(section===null)return body
body.top.push(info(doc,section.line,{cloudLine:section.phase},section.warn?'warning':'hint small'))
return body}
function hotkeysBody(doc,model,body){const section=bodyOf(model,'hotkeys')
if(section===null||section.locked)return body
body.top.push(info(doc,section.hint,{hotkeysHint:'1'}))
if(section.summary)body.top.push(info(doc,section.summary,{hotkeysSummary:'1'}))
if(section.problem)body.top.push(info(doc,section.problem,{hotkeyProblem:'1'},'warning'))
return body}
function marketBody(doc,model,hands,body){
body.heading.add('taxCalculator')
body.heading.add('filterSets')
const tax=bodyOf(model,'tax')
if(tax!==null&&!tax.locked){const rows=[info(doc,tax.rateLabel,{taxRate:'1'})]
for(const field of tax.fields)rows.push(textFieldRow(doc,'tax',field,'tax',(key,value)=>hands.onTax?.(key,value)))
for(const[i,row]of tax.rows.entries())rows.push(info(doc,row,{taxRow:String(i)},'hint'))
body.organs.taxCalculator=rows}
const sets=bodyOf(model,'filters')
if(sets!==null&&!sets.locked){const rows=[]
if(sets.rows.length===0){rows.push(el(doc,'div',{class:'empty',text:sets.emptyLabel}))}else{for(const row of sets.rows){rows.push(el(doc,'div',{class:'row filter'},[el(doc,'span',{class:'name',text:row.label}),...row.actions.map((action)=>actionButton(doc,action.label,{filter:row.id,action:action.action},()=>hands.onFilter?.(action.action,row.id)))]))}}
rows.push(actionButton(doc,sets.saveLabel,{filterSave:'1'},()=>hands.onSaveFilter?.()))
rows.push(el(doc,'div',{class:'row transfer'},sets.transfer.map((item)=>actionButton(doc,item.label,{filterTransfer:item.action},()=>hands.onFilter?.(item.action,null)))))
body.organs.filterSets=rows}
return body}
function clubBody(doc,model,hands,body){const section=bodyOf(model,'club')
if(section===null||section.locked)return body
const onClub=(action,value)=>hands.onClub?.(action,value)
const rows=[info(doc,section.statusLabel,{clubStatus:'1'},'status')]
const line=(text,key)=>{if(text)rows.push(info(doc,text,{club:key},'hint'))}
line(section.summaryLabel,'summary')
line(section.valueLabel,'value')
line(section.duplicatesLabel,'duplicates')
line(section.candidatesLabel,'candidates')
for(const row of section.rows){rows.push(el(doc,'div',{class:'row filter',dataset:{clubDup:row.id}},[el(doc,'span',{class:'name',text:row.label}),actionButton(doc,section.marketPriceLabel,{clubPrice:row.id},()=>onClub('price',row.id),'fx-action',{type:'button',title:section.marketPriceLabel})]))
if(row.priceLabel)rows.push(info(doc,row.priceLabel,{clubDupPrice:row.id}))}
if(section.table){rows.push(el(doc,'h4',{class:'sub',text:section.table.evidenceLabel}))
rows.push(actionButton(doc,section.table.exportLabel,{clubTableExport:'csv'},()=>onClub('table-export')))
for(const filter of section.table.filters){const input=el(doc,'input',{class:'limit',attrs:{type:'text',id:`fut-club-table-${filter.key}`},dataset:{clubTableFilter:filter.key},on:{change:(event)=>onClub('table-filter',{key:filter.key,value:String(event?.target?.value??'')})}})
input.value=filter.value
rows.push(el(doc,'div',{class:'row limit club-table-filter'},[el(doc,'label',{class:'name',text:filter.label,attrs:{for:`fut-club-table-${filter.key}`}}),input]))}
const head=el(doc,'tr',{},section.table.columns.map((column)=>el(doc,'th',{text:column.label,dataset:{clubTableColumn:column.key}})))
const bodyRows=[section.table.totalRow,...section.table.rows].map((row)=>el(doc,'tr',{dataset:{clubTableRow:row.id}},row.cells.map((cell)=>el(doc,'td',{text:cell.value,dataset:{clubTableCell:cell.key}}))))
rows.push(el(doc,'div',{class:'club-table-wrap'},[el(doc,'table',{class:'club-table'},[el(doc,'thead',{},[head]),el(doc,'tbody',{},bodyRows)])]))
const previous=actionButton(doc,section.table.previousLabel,{clubTablePage:'previous'},()=>onClub('table-page','previous'),'fx-action',{type:'button',...(section.table.page<=1?{disabled:'disabled'}:{})})
const next=actionButton(doc,section.table.nextLabel,{clubTablePage:'next'},()=>onClub('table-page','next'),'fx-action',{type:'button',...(section.table.page>=section.table.pages?{disabled:'disabled'}:{})})
rows.push(el(doc,'div',{class:'row club-table-pages'},[previous,info(doc,section.table.pageLabel,{clubTablePageLabel:'1'}),next]))}
body.organs.analyze=rows
return body}
function premiumBody(doc,model,body){const section=bodyOf(model,'license')
if(section===null)return body
body.top.push(info(doc,section.statusLabel,{licenseStatus:section.unlocked===true?'unlocked':'locked'},'status'))
body.bottom.push(info(doc,section.hint,{licenseHint:'1'}))
return body}
function diagnosticsBody(doc,model,hands,body){const section=bodyOf(model,'diagnostics')
const lever=renderLever(doc,model.lever,hands.onOrgan)
if(lever){body.replaces.add('dayXOff')
body.organs.dayXOff=[lever]}
if(section===null)return body
body.top.push(info(doc,section.statusLabel,{diagnostics:'status'},'status'))
if(section.guide){body.top.push(info(doc,section.safetyLabel,{diagnostics:'safety'},'warning'))
body.top.push(info(doc,section.premiumLabel,{diagnostics:'premium'}))}
return body}
export function mountPanel(opts){const{doc,getState,handlers={}}=opts;
const existing=doc.getElementById?.(PANEL_ID);
if(existing)existing.remove();
ensureTheme(doc);
const host=el(doc,'div',{attrs:{id:PANEL_ID}});
const shadow=host.attachShadow({mode:'open'});
shadow.appendChild(el(doc,'link',{attrs:{rel:'stylesheet',href:THEME_STYLESHEET}}));
shadow.appendChild(el(doc,'link',{attrs:{rel:'stylesheet',href:CONTROLS_STYLESHEET}}));
shadow.appendChild(el(doc,'link',{attrs:{rel:'stylesheet',href:WINDOW_STYLESHEET}}));
shadow.appendChild(el(doc,'link',{attrs:{rel:'stylesheet',href:PANEL_STYLESHEET}}));
shadow.appendChild(el(doc,'link',{attrs:{id:SETTINGS_LINK_ID,rel:'stylesheet',href:SETTINGS_STYLESHEET}}));
const slot=el(doc,'div');
shadow.appendChild(slot);
const dialogSlot=el(doc,'div',{dataset:{futDialogs:'1'}});
shadow.appendChild(dialogSlot);
const dockLayer=el(doc,'div',{class:'shell dock-layer',dataset:{futDockLayer:'1'}});
shadow.appendChild(dockLayer);
const translate=opts.t??((key,params)=>getState().t(key,params));
const dialogs=createDialogs({doc,root:dialogSlot,t:translate});
const view={query:'',licenseKey:'',ledgerScope:'session',highlight:null,stopping:{}}
const markStop=(engine,action)=>{if(action!=='stop'&&action!=='start')return
view.stopping={...view.stopping,[engine]:action==='stop'}}
const FIELD_MARKS='[data-panel-search],[data-organ-input]'
const fieldAddress=(node)=>{if(node?.dataset?.panelSearch!==undefined)return'[data-panel-search]'
const organ=node?.dataset?.organInput
return typeof organ==='string'&&organ!==''?`[data-organ-input="${organ}"]`:null}
const focusedField=()=>{try{if(doc.activeElement===null||doc.activeElement===undefined)return null
for(const node of slot.querySelectorAll?.(FIELD_MARKS)??[]){if(node.getRootNode?.()?.activeElement!==node)continue
const where=fieldAddress(node)
if(where===null)continue
return{where,at:node.selectionStart??null}}
return null}catch{return null}}
const focusBack=(was)=>{if(was===null)return false
try{const node=slot.querySelector?.(was.where)??null
if(node===null)return false
node.focus()
if(was.at!==null&&typeof node.setSelectionRange==='function')node.setSelectionRange(was.at,was.at)
return true}catch{return false}}
const SCROLLERS=Object.freeze(['.fx-set-main'])
const scrolledTo=()=>{const out={}
for(const where of SCROLLERS){try{out[where]=slot.querySelector?.(where)?.scrollTop??0}catch{out[where]=0}}
return out}
const scrollBackTo=(was)=>{let done=false
for(const where of SCROLLERS){const said=was?.[where]??0
if(!(said>0))continue
try{const room=slot.querySelector?.(where)??null
if(room===null)continue
room.scrollTop=said
done=true}catch{/* ящик мог исчезнуть вместе с окном — это не поломка */}}
return done}
const onView=(key,value)=>{if(!Object.hasOwn(view,key))return undefined
view[key]=value
api.update()
return undefined}
const win=doc.defaultView??globalThis
let pending=null
const updateSoon=()=>{if(pending!==null)return
pending=win.setTimeout(()=>{pending=null
api.update()},0)}
const dropPending=()=>{if(pending===null)return
win.clearTimeout(pending)
pending=null}
const DOCK_NOTICE_LIFE_MS=6000
const now=typeof opts.now==='function'?opts.now:()=>Date.now()
let dockStamp=null
let dockLit=0
const api={host,dialogs,
update(){const was=scrolledTo();
const caret=focusedField();
const state={...getState(),...view};
const model=panelModel(state);
const stamp=model.notice===null||model.notice===undefined?null:(state.notice??null);
if(stamp!==dockStamp){dockStamp=stamp;
dockLit=now()}
const dockNotice=stamp!==null&&(now()-dockLit)<DOCK_NOTICE_LIFE_MS;
const wired={...handlers,onView,
onRedraw:(opts)=>{if(opts?.soon===true)return updateSoon()
return api.update()},
onAutomation:(...args)=>{markStop('buyer',args[0])
return handlers.onAutomation?.(...args)},
onSeller:(...args)=>{markStop('seller',args[0])
return handlers.onSeller?.(...args)},
onLicense:(action,value)=>{if(action==='apply'||action==='clear')view.licenseKey=''
return handlers.onLicense?.(action,value)}};
replaceChildren(slot,renderPanel(model,doc,wired,{dockNotice,dock:false}));
replaceChildren(dockLayer,renderDock(model,doc,wired,{dockNotice}));
scrollBackTo(was);
focusBack(caret);
return api},remove(){dropPending()
onWindowRaised(null);
dialogs.close();
host.remove()},
scrollTop:scrolledTo,
view:()=>({...view}),
pending:()=>pending!==null};
(doc.body??doc.documentElement).appendChild(host);
host.dataset[PANEL_ANCHOR_ATTR]=pinToTopLayer(host);
dockLayer.dataset[DOCK_ANCHOR_ATTR]=pinToTopLayer(dockLayer);
onWindowRaised(()=>reliftDock(dockLayer));
return api.update()}
