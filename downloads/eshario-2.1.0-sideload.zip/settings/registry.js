import{FEATURES} from '../licensing/features.js'
export const STORE_BUCKETS=Object.freeze({toggles:'settings.toggles',limits:'automation.limits',options:'automation.options',seller:'seller.options',ui:'ui.state',license:'license.key'})
export const LEVELS=Object.freeze(['main','fine'])
export const ZONES=Object.freeze(['rhythm','stop','destination','screen','places','prices'])
export const PLACES=Object.freeze(['window'])
export const inWindow=(organ)=>organ?.place==='window'
export const onScreen=(organ)=>organ?.place!=='window'
export function organsAt(sectionId,place,sections=SECTIONS){const found=sections.find((one)=>one.id===sectionId)
if(!found)return[]
const wants=place==='screen'?onScreen:inWindow
return found.organs.filter((item)=>item.shipped===true&&wants(item))}
export const KINDS=Object.freeze(['toggle','number','choice','action','link','text'])
export const TIERS=Object.freeze(['all','pro'])
export const MAIN_LIMIT=3
export const SHELL_KEYS=Object.freeze(['ui.collapsed','ui.position','ui.legacyOpen'])
export const CHROME_KEYS=Object.freeze(['ui.locale'])
export const DATA_KEYS=Object.freeze(['automation.ledger','automation.journal'])
export const MOVED_KEYS=Object.freeze({'filters.sets':'экран рынка, фича advancedFilters',
'limits.maxPurchases':'полоса бота на родном экране поиска, ряд «Этот запуск»',
'options.ratingSearchNow':'шапка окна «Дешевейшие по рейтингу» на родном экране поиска'})
const NO_STATUS=null
const organ=(value)=>Object.freeze({kind:'toggle',level:'fine',zone:null,place:'window',tier:'all',hintKey:null,default:null,defaultFrom:null,unit:null,store:null,floor:null,feature:null,danger:false,shipped:true,...value})
const section=(value)=>Object.freeze({tier:'all',icon:'',feature:null,status:NO_STATUS,...value,zones:Object.freeze((value.zones??[]).map((one)=>Object.freeze({...one}))),organs:Object.freeze((value.organs??[]).map(organ))})
const featureLabel=(id)=>`settings.feature.${id}`
const featureDefault=(id)=>`FEATURE_DEFAULTS.${id}`
const featureToggle=(id,extra={})=>({id:extra.id??id,kind:'toggle',labelKey:featureLabel(id),defaultFrom:featureDefault(id),store:`toggles.${id}`,feature:id,...extra})
export const SECTIONS=Object.freeze([
section({id:'snipe',order:1,tier:'all',icon:'snipe',feature:'autoBuyer',status:'automation',
titleKey:'settings.section.snipe.title',hintKey:'settings.section.snipe.hint',
zones:[{id:'rhythm',titleKey:'settings.zone.snipe.rhythm'},
{id:'stop',titleKey:'settings.zone.snipe.stop'},
{id:'destination',titleKey:'settings.zone.snipe.destination'},
{id:'screen',titleKey:'settings.zone.snipe.screen'}],
organs:[
featureToggle('autoBuyer',{id:'buys',level:'main'}),
{id:'confirmEachRun',kind:'toggle',level:'main',labelKey:'settings.organ.snipe.confirmEachRun.label',defaultFrom:'CONFIRM_EACH_RUN_DEFAULT',store:'options.confirmEachRun'},
{id:'afterBuy',kind:'choice',level:'main',labelKey:'snipe.settings.afterBuy',defaultFrom:'AFTER_BUY_DEFAULT',store:'options.afterBuy'},
{id:'dryRun',kind:'toggle',level:'main',place:'window',shipped:false,labelKey:'automation.dryRun',hintKey:'settings.organ.snipe.dryRun.hint',default:true},
{id:'spendCap',kind:'number',place:'window',tier:'pro',labelKey:'automation.limit.maxSpend',hintKey:'settings.organ.snipe.spendCap.hint',store:'limits.maxSpend'},
{id:'maxPrice',kind:'number',place:'window',tier:'pro',labelKey:'automation.option.maxPrice',hintKey:'settings.organ.snipe.maxPrice.hint',store:'options.maxPrice'},
{id:'resaleMinProfit',kind:'number',place:'window',tier:'pro',labelKey:'automation.option.resaleMinProfit',hintKey:'settings.organ.snipe.resaleMinProfit.hint',store:'options.resaleMinProfit'},
{id:'maxBid',kind:'number',place:'window',tier:'pro',labelKey:'automation.option.maxBid',hintKey:'settings.organ.snipe.maxBid.hint',store:'options.maxBid'},
{id:'matchGuard',kind:'number',place:'window',tier:'pro',labelKey:'settings.organ.snipe.matchGuard.label',hintKey:'settings.organ.snipe.matchGuard.hint',defaultFrom:'MATCH_GUARD_DEFAULT',store:'options.matchGuard'},
{id:'snipeKeyThreshold',kind:'number',place:'window',tier:'pro',labelKey:'settings.organ.snipe.snipeKeyThreshold.label',hintKey:'settings.organ.snipe.snipeKeyThreshold.hint',defaultFrom:'SNIPE_KEY_THRESHOLD_DEFAULT',store:'options.snipeKeyThreshold'},
{id:'resaleMarginPercent',kind:'number',place:'window',tier:'pro',labelKey:'automation.option.resaleMargin',hintKey:'settings.organ.snipe.resaleMarginPercent.hint',unit:'seller.field.percent',store:'options.resaleMarginPercent'},
{id:'searchDelaySec',kind:'number',zone:'rhythm',labelKey:'automation.option.searchDelay',hintKey:'settings.organ.snipe.searchDelaySec.hint',defaultFrom:'DEFAULT_SEARCH_DELAY_MS',unit:'automation.option.seconds',store:'options.searchDelaySec',
floor:{from:'SAFE_PAUSE_FLOOR_MS',danger:true}},
{id:'jitterSec',kind:'number',zone:'rhythm',labelKey:'automation.option.jitter',hintKey:'settings.organ.snipe.jitterSec.hint',defaultFrom:'DEFAULT_JITTER_MS',unit:'automation.option.seconds',store:'options.jitterSec'},
{id:'buyDelaySec',kind:'number',zone:'rhythm',labelKey:'automation.option.buyDelay',hintKey:'settings.organ.snipe.buyDelaySec.hint',unit:'automation.option.seconds',store:'options.buyDelaySec'},
{id:'breakWorkMin',kind:'number',zone:'rhythm',labelKey:'automation.option.breakWork',defaultFrom:'WORK_MS',unit:'automation.limit.minutes',store:'options.breakWorkMin'},
{id:'breakRestMin',kind:'number',zone:'rhythm',labelKey:'automation.option.breakRest',defaultFrom:'BREAK_MS',unit:'automation.limit.minutes',store:'options.breakRestMin'},
{id:'maxPerSearch',kind:'number',zone:'rhythm',labelKey:'snipe.settings.maxPerSearch',hintKey:'settings.organ.snipe.maxPerSearch.hint',defaultFrom:'MAX_PER_SEARCH_DEFAULT',store:'options.maxPerSearch'},
{id:'maxActions',kind:'number',zone:'stop',labelKey:'automation.limit.maxActions',hintKey:'settings.organ.snipe.maxActions.hint',defaultFrom:'SAFE_LIMIT_DEFAULTS.maxActions',store:'limits.maxActions'},
{id:'maxSearches',kind:'number',zone:'stop',place:'window',labelKey:'automation.limit.maxSearches',hintKey:'settings.organ.snipe.maxSearches.hint',store:'limits.maxSearches'},
{id:'maxDurationMs',kind:'number',zone:'stop',labelKey:'automation.limit.maxDuration',hintKey:'settings.organ.snipe.maxDurationMs.hint',defaultFrom:'SAFE_LIMIT_DEFAULTS.maxDurationMs',unit:'automation.limit.minutes',store:'limits.maxDurationMs'},
{id:'minCoins',kind:'number',zone:'stop',labelKey:'automation.limit.minCoins',hintKey:'settings.organ.snipe.minCoins.hint',store:'limits.minCoins'},
{id:'maxLossCoins',kind:'number',zone:'stop',shipped:false,labelKey:'automation.limit.maxLossCoins',hintKey:'settings.organ.snipe.maxLossCoins.hint',store:'limits.maxLossCoins'},
{id:'allowUnassignedOverflow',kind:'toggle',zone:'destination',labelKey:'automation.option.allowUnassignedOverflow',hintKey:'settings.organ.snipe.allowUnassignedOverflow.hint',default:false,store:'options.allowUnassignedOverflow',danger:true},
featureToggle('autoSnipe',{id:'enabled',zone:'screen',labelKey:'settings.organ.snipe.enabled.label',hintKey:'settings.organ.snipe.enabled.hint'}),
featureToggle('notifications',{id:'buySound',zone:'screen'}),
{id:'consent',kind:'text',zone:'screen',shipped:false,labelKey:'settings.organ.snipe.consent.label',hintKey:'settings.organ.snipe.consent.hint',store:'ui.snipeConsent'}]}),
section({id:'solver',order:2,tier:'all',icon:'solver',feature:'sbcSolver',status:'sbc',titleKey:'settings.section.solver.title',hintKey:'settings.section.solver.hint',organs:[
{id:'keepActiveSquad',kind:'toggle',labelKey:'settings.organ.solver.keepActiveSquad.label',hintKey:'settings.organ.solver.keepActiveSquad.hint',defaultFrom:'SOLVER_DEFAULTS.keepActiveSquad',store:'ui.solver.keepActiveSquad'},
{id:'adviseBuy',kind:'toggle',labelKey:'settings.organ.solver.adviseBuy.label',hintKey:'settings.organ.solver.adviseBuy.hint',defaultFrom:'SOLVER_DEFAULTS.adviseBuy',store:'ui.solver.adviseBuy'},
{id:'adviceCoins',kind:'number',labelKey:'settings.organ.solver.adviceCoins.label',hintKey:'settings.organ.solver.adviceCoins.hint',default:1000,shipped:false},
{id:'advicePercent',kind:'number',labelKey:'settings.organ.solver.advicePercent.label',hintKey:'settings.organ.solver.advicePercent.hint',default:15,unit:'seller.field.percent',shipped:false},
{id:'locks',kind:'link',labelKey:'settings.organ.solver.locks.label',hintKey:'settings.organ.solver.locks.hint'},
{id:'rereadClub',kind:'action',tier:'pro',labelKey:'sbcWindow.clubReread',hintKey:'settings.organ.solver.rereadClub.hint'},
featureToggle('sbcSolver',{id:'enabled',level:'main'}),
featureToggle('sbcAutoBuy',{id:'autoBuy',level:'main',hintKey:'settings.organ.solver.autoBuy.hint'})]}),
section({id:'seller',order:3,tier:'all',icon:'seller',feature:'autoSeller',status:'seller',titleKey:'settings.section.seller.title',hintKey:'settings.section.seller.hint',organs:[
{id:'marginPercent',kind:'number',level:'main',labelKey:'seller.field.margin',unit:'seller.field.percent',store:'seller.marginPercent'},
{id:'minProfit',kind:'number',level:'main',labelKey:'seller.field.minProfit',hintKey:'settings.organ.seller.minProfit.hint',store:'seller.minProfit'},
{id:'dryRun',kind:'toggle',level:'main',labelKey:'seller.dryRun',hintKey:'settings.organ.seller.dryRun.hint',default:true},
featureToggle('autoSeller',{id:'enabled'}),
{id:'allowQuickSell',kind:'toggle',labelKey:'seller.allowQuickSell',hintKey:'settings.organ.seller.allowQuickSell.hint',default:false,store:'seller.allowQuickSell',danger:true},
{id:'quickSellBelow',kind:'number',labelKey:'seller.field.quickSellBelow',store:'seller.quickSellBelow'},
{id:'maxActions',kind:'number',labelKey:'seller.field.maxActions',store:'seller.maxActions'},
{id:'maxDurationMs',kind:'number',labelKey:'automation.limit.maxDuration',unit:'automation.limit.minutes',store:'seller.maxDurationMs'}]}),
section({id:'packs',order:4,tier:'all',icon:'packs',feature:'packGrid',status:'packShow',titleKey:'settings.section.packs.title',hintKey:'settings.section.packs.hint',organs:[
{id:'showAlways',kind:'toggle',level:'main',labelKey:'packs.show.always',defaultFrom:'PACK_SHOW_DEFAULTS.always',store:'ui.packShow.always'},
{id:'showSpecial',kind:'toggle',level:'main',labelKey:'packs.show.special',defaultFrom:'PACK_SHOW_DEFAULTS.special',store:'ui.packShow.special',dimWhen:'showAlways'},
{id:'showRating',kind:'toggle',level:'main',labelKey:'packs.show.rating',defaultFrom:'PACK_SHOW_DEFAULTS.rating',store:'ui.packShow.rating',inline:'showRatingMin',dimWhen:'showAlways'},
{id:'showRatingMin',kind:'number',labelKey:'packs.show.ratingMin',defaultFrom:'SHOW_RATING_DEFAULT',store:'ui.packShow.ratingMin',inlineIn:'showRating'},
featureToggle('packGrid',{id:'grid'}),
featureToggle('packPeek',{id:'peek'}),
featureToggle('pickByPrice',{id:'pickByPrice'}),
{id:'beltMaxPacks',kind:'number',labelKey:'packs.automation.maxPacks',hintKey:'settings.organ.packs.belt.hint',shipped:false},
{id:'beltMaxMinutes',kind:'number',labelKey:'packs.automation.maxMinutes',hintKey:'settings.organ.packs.belt.hint',unit:'automation.limit.minutes',shipped:false},
{id:'beltRecoveryOrder',kind:'text',labelKey:'packs.automation.recoveryOrder',hintKey:'settings.organ.packs.belt.hint',shipped:false},
{id:'beltDiscardAllowlist',kind:'text',labelKey:'packs.automation.discardAllowlist',hintKey:'settings.organ.packs.belt.hint',shipped:false},
{id:'beltAutoPick',kind:'toggle',labelKey:'packs.automation.autoPick',hintKey:'settings.organ.packs.belt.hint',default:false,shipped:false},
{id:'beltAutoRecovery',kind:'toggle',labelKey:'packs.automation.autoRecovery',hintKey:'settings.organ.packs.belt.hint',default:false,shipped:false},
{id:'beltAutoDiscard',kind:'toggle',labelKey:'packs.automation.autoDiscard',hintKey:'settings.organ.packs.belt.hint',default:false,shipped:false,danger:true},
{id:'beltAutoContinue',kind:'toggle',labelKey:'packs.automation.autoContinue',hintKey:'settings.organ.packs.belt.hint',default:false,shipped:false}]}),
section({id:'ledger',order:5,tier:'all',icon:'ledger',status:'ledger',titleKey:'settings.section.ledger.title',hintKey:'settings.section.ledger.hint',organs:[
{id:'scope',kind:'choice',level:'main',labelKey:'settings.organ.ledger.scope.label',default:'session'},
{id:'exportCsv',kind:'action',level:'main',labelKey:'ledger.csv'},
{id:'reset',kind:'action',labelKey:'ledger.reset',hintKey:'settings.organ.ledger.reset.hint',danger:true}]}),
section({id:'journal',order:6,tier:'all',icon:'journal',status:'journal',titleKey:'settings.section.journal.title',hintKey:'settings.section.journal.hint',organs:[
{id:'recent',kind:'text',level:'main',labelKey:'settings.organ.journal.recent.label'},
{id:'export',kind:'action',level:'main',labelKey:'journal.export'},
{id:'byEngine',kind:'choice',labelKey:'settings.organ.journal.byEngine.label',hintKey:'settings.organ.journal.byEngine.hint',shipped:false}]}),
section({id:'hotkeys',order:7,tier:'all',icon:'keys',feature:'hotkeyNav',status:'hotkeys',titleKey:'settings.section.hotkeys.title',hintKey:'settings.section.hotkeys.hint',organs:[
featureToggle('hotkeys',{id:'enabled',level:'main',labelKey:'settings.organ.hotkeys.enabled.label'}),
{id:'open',kind:'action',level:'main',labelKey:'hotkeys.open',feature:'hotkeys'},
featureToggle('hotkeyNav',{id:'nav',level:'main',hintKey:'settings.organ.hotkeys.nav.hint'})]}),
section({id:'cloud',order:8,tier:'all',icon:'cloud',status:'cloud',titleKey:'settings.section.cloud.title',hintKey:'settings.section.cloud.hint',organs:[
{id:'sync',kind:'action',level:'main',labelKey:'settings.organ.cloud.sync.label'},
{id:'saveFile',kind:'action',level:'main',labelKey:'settings.organ.cloud.saveFile.label'},
{id:'loadFile',kind:'action',level:'main',labelKey:'settings.organ.cloud.loadFile.label',hintKey:'settings.organ.cloud.loadFile.hint'},
{id:'takeCloud',kind:'action',labelKey:'settings.organ.cloud.takeCloud.label',hintKey:'settings.organ.cloud.takeCloud.hint'},
{id:'takeLocal',kind:'action',labelKey:'settings.organ.cloud.takeLocal.label',hintKey:'settings.organ.cloud.takeLocal.hint'}]}),
section({id:'market',order:9,tier:'pro',icon:'market',titleKey:'settings.section.market.title',hintKey:'settings.section.market.hint',
zones:[{id:'places',titleKey:'settings.zone.market.places',grid:true},
{id:'prices',titleKey:'settings.zone.market.prices'}],
organs:[
featureToggle('advancedFilters',{id:'quickSearch',level:'main',hintKey:'settings.organ.market.quickSearch.hint'}),
{id:'taxCalculator',kind:'action',level:'main',labelKey:'tax.label',feature:'eaTax'},
{id:'filterSets',kind:'action',level:'main',labelKey:'settings.organ.market.filterSets.label',feature:'advancedFilters'},
featureToggle('priceBadges',{id:'priceBadges',zone:'places'}),
featureToggle('cardGrid',{id:'cardGrid',zone:'places'}),
featureToggle('enhancedTransferList',{id:'enhancedTransferList',zone:'places',labelKey:'settings.organ.market.place.transferList'}),
featureToggle('enhancedUnassignedList',{id:'enhancedUnassignedList',zone:'places',labelKey:'settings.organ.market.place.unassigned'}),
featureToggle('unassignedTools',{id:'unassignedTools',zone:'places'}),
featureToggle('enhancedObjectivesList',{id:'enhancedObjectivesList',zone:'places',labelKey:'settings.organ.market.place.objectives'}),
featureToggle('enhancedClubList',{id:'enhancedClubList',zone:'places',labelKey:'settings.organ.market.place.club'}),
featureToggle('squadScreen',{id:'squadScreen',zone:'places',labelKey:'settings.organ.market.place.squad'}),
featureToggle('dropdownSearch',{id:'dropdownSearch',zone:'places',hintKey:'settings.organ.features.dropdownSearch.hint'}),
featureToggle('eaTax',{id:'eaTax',zone:'prices'}),
featureToggle('priceSources',{id:'priceSources',zone:'prices',hintKey:'settings.organ.market.priceSources.hint'}),
featureToggle('minBinSearch',{id:'minBinSearch',zone:'prices'}),
{id:'relistMode',kind:'choice',zone:'prices',labelKey:'settings.organ.market.relistMode.label',default:'market',store:'ui.relist.mode',shipped:true},
]}),
section({id:'club',order:10,tier:'pro',icon:'club',feature:'clubAnalysis',status:'club',titleKey:'settings.section.club.title',hintKey:'settings.section.club.hint',organs:[
{id:'analyze',kind:'action',level:'main',labelKey:'club.analyze',hintKey:'settings.organ.club.analyze.hint'},
featureToggle('clubAnalysis',{id:'enabled'}),
featureToggle('clubBar',{id:'bar'})]}),
section({id:'features',order:11,tier:'pro',icon:'features',status:'settings',titleKey:'settings.section.features.title',hintKey:'settings.section.features.hint',organs:[
featureToggle('autologin',{id:'autologin',level:'main'}),
featureToggle('headBar',{id:'headBar',level:'main',hintKey:'settings.organ.features.headBar.hint'}),
featureToggle('hubRewards',{id:'hubRewards',hintKey:'settings.organ.features.hubRewards.hint'}),
featureToggle('homeLayout',{id:'homeLayout'}),
featureToggle('promoClose',{id:'promoClose',hintKey:'settings.organ.features.promoClose.hint'})]}),
section({id:'premium',order:12,tier:'pro',icon:'premium',status:'license',titleKey:'settings.section.premium.title',hintKey:'settings.section.premium.hint',organs:[
{id:'key',kind:'text',level:'main',labelKey:'license.key',hintKey:'settings.organ.premium.key.hint',store:'license.key'},
{id:'apply',kind:'action',level:'main',labelKey:'license.apply'},
{id:'account',kind:'link',level:'main',labelKey:'license.accountOpen'},
{id:'clear',kind:'action',labelKey:'license.clear',danger:true}]}),
section({id:'diagnostics',order:13,tier:'pro',icon:'diagnostics',titleKey:'settings.section.diagnostics.title',hintKey:'settings.section.diagnostics.hint',organs:[
{id:'dayXOff',kind:'toggle',level:'main',labelKey:'dayX.label',hintKey:'settings.organ.diagnostics.dayXOff.hint',default:false,store:'ui.dayXOff',danger:true},
{id:'errors',kind:'text',level:'main',labelKey:'settings.organ.diagnostics.errors.label'},
{id:'check',kind:'action',level:'main',labelKey:'onboarding.check'},
{id:'version',kind:'text',labelKey:'settings.organ.diagnostics.version.label'},
{id:'guide',kind:'action',labelKey:'onboarding.show',default:false,store:'ui.onboarded'}]})])
export function allOrgans(sections=SECTIONS){const out=[]
for(const one of sections)for(const item of one.organs)out.push({section:one.id,organ:item})
return out}
export function shippedOrgans(sections=SECTIONS){return allOrgans(sections).filter((row)=>row.organ.shipped===true)}
export function organsOf(sectionId,level=null,sections=SECTIONS){const found=sections.find((one)=>one.id===sectionId)
if(!found)return[]
return found.organs.filter((item)=>item.shipped===true&&(level===null||item.level===level))}
export function findOrgan(sectionId,organId,sections=SECTIONS){return sections.find((one)=>one.id===sectionId)?.organs.find((item)=>item.id===organId)??null}
export function storePaths(sections=SECTIONS){return allOrgans(sections).map((row)=>row.organ.store).filter((path)=>typeof path==='string')}
export function defaultOf(organ,sources={}){if(organ?.defaultFrom===null||organ?.defaultFrom===undefined)return organ?.default??null
const raw=readPath(sources.constants??{},organ.defaultFrom)
if(raw===undefined)return undefined
if(typeof raw!=='number')return raw
const scale=typeof sources.scaleOf==='function'&&typeof organ.store==='string'?sources.scaleOf(organ.store):1
return Number.isFinite(scale)&&scale>0?raw/scale:raw}
export function floorOf(organ,sources={}){const floor=organ?.floor
if(!floor)return null
if(typeof floor.value==='number')return{value:floor.value,danger:floor.danger===true}
const raw=readPath(sources.constants??{},floor.from)
if(typeof raw!=='number')return undefined
const scale=typeof sources.scaleOf==='function'&&typeof organ.store==='string'?sources.scaleOf(organ.store):1
return{value:Number.isFinite(scale)&&scale>0?raw/scale:raw,danger:floor.danger===true}}
function readPath(map,path){if(typeof path!=='string'||path==='')return undefined
let value=map
for(const part of path.split('.')){if(value===null||typeof value!=='object'||!Object.hasOwn(value,part))return undefined
value=value[part]}
return value}
export function togglesInRegistry(sections=SECTIONS){return allOrgans(sections)
.filter((row)=>typeof row.organ.store==='string'&&row.organ.store.startsWith('toggles.'))
.map((row)=>row.organ.store.slice('toggles.'.length))
.sort()}
export const COVERS_ALL_FEATURES=togglesInRegistry().length===Object.keys(FEATURES).length
