import{el,ensureStylesheet,ensureTheme} from '../ui/dom.js'
import{PANEL_DOOR_SELECTOR} from './head-bar.js'
export const TOPLESS_MARK='data-fut-topless'
export const TOPLESS_KEY='futTopless'
export const EA_HEADER='div.fc-header-view'
export const KNOWN_CHILDREN=Object.freeze(['fc','eaSports'])
export const NAVCENTER_MARK='data-fut-navcenter'
export const NAVCENTER_KEY='futNavcenter'
export const EA_RAIL='.ut-tab-bar-view.game-navigation .ut-tab-bar'
export const EA_SETTINGS_ITEM='.ut-tab-bar-item.icon-settings'
export const EA_LANDSCAPE='landscape'
const TOPLESS_STYLESHEET=new URL('../ui/head-top.css',import.meta.url).href
const TOPLESS_LINK_ID='fut-companion-head-top'
const TOPLESS_SHEET_MARK='futToplessSheet'
const childrenOf=(node)=>{const kids=node?.children
if(kids===null||kids===undefined)return []
return Array.prototype.slice.call(kids)}
export function ensureHeadTopStyles(doc){ensureTheme(doc)
return ensureStylesheet(doc,TOPLESS_STYLESHEET,TOPLESS_LINK_ID)}
export function createHeadTop(deps={}){const doc=deps.doc
if(!doc||typeof doc.createElement!=='function'){throw new Error('head-top: нужен документ')}
const panelHost=typeof deps.panelHost==='function'?deps.panelHost:()=>null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const counts={passes:0,marks:0,drops:0,noStrip:0,notOurs:0,noButton:0,sheets:0}
let lastReason=null
let marked=false
const nav={marks:0,drops:0,noRail:0,notLandscape:0,noSettings:0,noButton:0}
let navReason=null
let navMarked=false
const stripOf=()=>doc.querySelector(EA_HEADER)
function ourStrip(strip){if(strip===null||strip===undefined)return false
const seen=new Set()
for(const kid of childrenOf(strip)){if(String(kid.tagName??'').toLowerCase()!=='a')return false
const known=KNOWN_CHILDREN.find((name)=>kid.classList?.contains?.(name)===true)
if(known===undefined||seen.has(known))return false
seen.add(known)}
return seen.size===KNOWN_CHILDREN.length}
const buttonOf=()=>doc.querySelector(PANEL_DOOR_SELECTOR)
const railOf=()=>doc.querySelector(EA_RAIL)
const landscapeOf=()=>doc.body?.classList?.contains?.(EA_LANDSCAPE)===true
const settingsOf=(rail)=>rail?.querySelector?.(EA_SETTINGS_ITEM)??null
function sheetIn(host){if(host===null||host===undefined)return false
const shadow=host.shadowRoot
if(!shadow||typeof shadow.querySelector!=='function')return false
if(shadow.querySelector(`[data-fut-topless-sheet="1"]`)!==null)return true
const link=el(doc,'link',{attrs:{rel:'stylesheet',href:TOPLESS_STYLESHEET},
dataset:{[TOPLESS_SHEET_MARK]:'1'}})
shadow.appendChild(link)
counts.sheets+=1
return true}
function dropSheet(host){if(host===null||host===undefined)return
const link=host.shadowRoot?.querySelector?.(`[data-fut-topless-sheet="1"]`)??null
if(link!==null)link.remove()}
function mark(node,on,key=TOPLESS_KEY){if(node===null||node===undefined||node.dataset===undefined)return false
const has=node.dataset[key]==='1'
if(on===has)return false
if(on)node.dataset[key]='1'
else delete node.dataset[key]
return true}
function navDrop(){let changed=false
try{changed=mark(doc.body,false,NAVCENTER_KEY)}catch(err){onError(err)}
if(changed)nav.drops+=1
navMarked=false}
function navPass(){const rail=railOf()
if(rail===null){nav.noRail+=1
navReason='no-rail'
navDrop()
return{ok:false,reason:navReason}}
if(!landscapeOf()){nav.notLandscape+=1
navReason='not-landscape'
navDrop()
return{ok:false,reason:navReason}}
if(settingsOf(rail)===null){nav.noSettings+=1
navReason='no-settings'
navDrop()
return{ok:false,reason:navReason}}
if(buttonOf()===null){nav.noButton+=1
navReason='no-button'
navDrop()
return{ok:false,reason:navReason}}
if(mark(doc.body,true,NAVCENTER_KEY))nav.marks+=1
navMarked=true
navReason=null
return{ok:true,reason:null}}
function drop(){let changed=false
try{changed=mark(doc.body,false)||changed
const host=panelHost()
changed=mark(host,false)||changed
dropSheet(host)}catch(err){onError(err)}
if(changed)counts.drops+=1
marked=false
return changed}
function toplessPass(){const strip=stripOf()
if(strip===null){counts.noStrip+=1
lastReason='no-strip'
drop()
return{ok:false,reason:lastReason}}
if(!ourStrip(strip)){counts.notOurs+=1
lastReason='not-our-strip'
drop()
return{ok:false,reason:lastReason}}
if(buttonOf()===null){counts.noButton+=1
lastReason='no-button'
drop()
return{ok:false,reason:lastReason}}
let changed=mark(doc.body,true)
const host=panelHost()
changed=mark(host,true)||changed
sheetIn(host)
if(changed)counts.marks+=1
marked=true
lastReason=null
return{ok:true,reason:null}}
return{
refresh(){let полоса={ok:false,reason:'failed'}
try{counts.passes+=1
ensureHeadTopStyles(doc)
полоса=toplessPass()}catch(err){onError(err)
lastReason='failed'
полоса={ok:false,reason:lastReason}}
let центр={ok:false,reason:'failed'}
try{центр=navPass()}catch(err){onError(err)
navReason='failed'
центр={ok:false,reason:navReason}}
return{...полоса,nav:центр}},
state(){const strip=stripOf()
const kids=childrenOf(strip).map((node)=>`${String(node.tagName??'').toLowerCase()}.${String(node.className??'').trim()}`)
const rail=railOf()
const items=childrenOf(rail).length
const settings=settingsOf(rail)!==null
return{marked,reason:lastReason,counts:{...counts},
strip:strip!==null,ours:ourStrip(strip),children:kids,
button:buttonOf()!==null,
nav:{marked:navMarked,reason:navReason,counts:{...nav},
rail:rail!==null,landscape:landscapeOf(),items,settings},
line:`верх EA: ${marked?'скрыт':'на месте'}`
+`, причина ${lastReason??'нет'}`
+`, детей полосы ${kids.length}${kids.length===0?'':` (${kids.join(', ')})`}`
+`, дверь панели в кластере ${buttonOf()===null?'нет':'есть'}`
+`, проходов ${counts.passes}, меток ${counts.marks}, снятий ${counts.drops}`
+`; меню слева: ${navMarked?'по центру':'как у EA'}`
+`, причина ${navReason??'нет'}`
+`, пунктов ${items}, Settings ${settings?'есть':'нет'}`
+`, меток ${nav.marks}, снятий ${nav.drops}`}},
dispose(){drop()
lastReason='disposed'
navDrop()
navReason='disposed'}}}
