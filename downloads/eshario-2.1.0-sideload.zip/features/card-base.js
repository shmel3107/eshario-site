import{UNKNOWN,POS_NONE,POS_PRIMARY,POS_FULL} from './card-catalog.js'
import{seasonFits} from '../adapter/season.js'
export const CARD_BASE_SCHEMA=1
export const CARD_BASE_FIELDS=Object.freeze(['eaId','overall','position','altPositions',
'nationEaId','leagueEaId','clubEaId','rarityEaId','raritySquadId','basePlayerEaId','uniqueClubEaId'])
export function parseCardBase(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw))return null
if(raw.v!==CARD_BASE_SCHEMA)return null
const game=season(raw.game)
if(game===null)return null
const fields=Array.isArray(raw.fields)?raw.fields:null
if(fields===null)return null
const index={}
for(let at=0;at<fields.length;at+=1){const name=fields[at]
if(typeof name==='string'&&CARD_BASE_FIELDS.includes(name)&&index[name]===undefined)index[name]=at}
if(index.eaId===undefined)return null
const rows=Array.isArray(raw.cards)?raw.cards:null
if(rows===null)return null
return{schema:CARD_BASE_SCHEMA,game,
builtAt:builtAtOf(raw.built_at),
complete:raw.complete===true,
indexed:Number.isSafeInteger(raw.indexed)?raw.indexed:null,
misses:Number.isSafeInteger(raw.misses)?raw.misses:null,
source:raw.source&&typeof raw.source==='object'&&!Array.isArray(raw.source)?raw.source:null,
index,rows,count:rows.length,rarities:parseRarities(raw.dicts),groups:parseGroups(raw.rarityGroups)}}
function builtAtOf(value){if(Number.isSafeInteger(value)&&value>0)return new Date(value).toISOString()
return typeof value==='string'&&value!==''?value:null}
export function baseDefinitions(base,from=0,to=Number.MAX_SAFE_INTEGER){const out=[]
if(!base||!Array.isArray(base.rows))return out
const end=Math.min(to,base.rows.length)
for(let at=Math.max(0,from);at<end;at+=1){const definition=baseDefinition(base.index,base.rows[at])
if(definition!==null)out.push(definition)}
return out}
export function baseDefinition(index,row){if(!Array.isArray(row)||!index)return null
const definitionId=positive(row[index.eaId])
if(definitionId===null)return null
const positions=[]
const primary=positionCode(pick(index,row,'position'))
if(primary!==null)positions.push(primary)
let hasAlt=false
const alt=pick(index,row,'altPositions')
if(Array.isArray(alt)){hasAlt=true
for(const value of alt){const code=positionCode(value)
if(code!==null&&!positions.includes(code))positions.push(code)}}
let positionMode=POS_NONE
if(positions.length>0)positionMode=hasAlt?POS_FULL:POS_PRIMARY
return{definitionId,
rating:ratingOf(pick(index,row,'overall'))??0,
rareflag:count(pick(index,row,'rarityEaId')),
leagueId:positive(pick(index,row,'leagueEaId'))??UNKNOWN,
nationId:positive(pick(index,row,'nationEaId'))??UNKNOWN,
teamId:teamOf(index,row),
positions,positionMode}}
function teamOf(index,row){const own=positive(pick(index,row,'uniqueClubEaId'))
if(own!==null)return own
return positive(pick(index,row,'clubEaId'))??UNKNOWN}
export function parseRarities(dicts){const out=[]
const table=dicts&&typeof dicts==='object'&&!Array.isArray(dicts)?dicts.rarities:null
if(!table||typeof table!=='object'||!Array.isArray(table.rows))return out
const fields=Array.isArray(table.fields)?table.fields:[]
const at=(name)=>fields.indexOf(name)
const idAt=at('eaId')
if(idAt<0)return out
const nameAt=at('name')
const specialAt=at('isSpecial')
const seen=new Set()
for(const row of table.rows){if(!Array.isArray(row))continue
const eaId=count(row[idAt])
if(eaId===UNKNOWN||seen.has(eaId))continue
seen.add(eaId)
const name=nameAt<0?null:row[nameAt]
const special=specialAt<0?null:row[specialAt]
out.push({eaId,name:typeof name==='string'&&name!==''?name:null,
special:special===1||special===true?true:(special===0||special===false?false:null)})}
return out}
export function parseGroups(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw))return null
const out={}
let any=false
for(const key of Object.keys(raw)){const rarity=Number(key)
if(!Number.isSafeInteger(rarity)||rarity<0)continue
const list=raw[key]
if(!Array.isArray(list))continue
const clean=[]
for(const value of list){if(Number.isSafeInteger(value)&&value>0&&!clean.includes(value))clean.push(value)}
if(clean.length===0)continue
out[rarity]=clean.sort((a,b)=>a-b)
any=true}
return any?out:null}
export function createCardBaseFeed(deps={}){const ask=typeof deps.ask==='function'?deps.ask:null
const seed=typeof deps.seed==='function'?deps.seed:null
if(ask===null||seed===null)throw new Error('card-base: нужны ask и seed')
const storage=deps.storage??null
const groups=typeof deps.groups==='function'?deps.groups:null
const seasonNow=typeof deps.season==='function'?deps.season:()=>null
const gameNow=typeof deps.game==='function'?deps.game:()=>null
const now=typeof deps.now==='function'?deps.now:()=>0
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let seeded=null
let loaded=false
let asking=null
const stats={asks:0,bodies:0,notModified:0,refused:0,seedMs:null,parseMs:null,askMs:null,
askedAt:null,status:null,reason:null,why:null,worker:null}
const remember=(value)=>{seeded=value
if(storage===null)return
try{const result=storage.write?.(value)
if(result&&typeof result.catch==='function')result.catch(onError)}catch(err){onError(err)}}
const runRefresh=async(why)=>{const game=gameNow()
if(!Number.isSafeInteger(game))return{ok:false,reason:'no-season'}
stats.asks+=1
stats.why=typeof why==='string'?why:null
stats.askedAt=now()
const etag=seeded!==null&&seeded.game===game?seeded.etag:null
const soon=seeded!==null&&seeded.game===game&&seeded.complete===false
let answer=null
const startedAsk=now()
try{answer=await ask({game,etag,soon})}catch(err){onError(err)
answer=null}
stats.askMs=now()-startedAsk
if(!answer||typeof answer!=='object'){stats.status=null
stats.reason='no-answer'
return{ok:false,reason:'no-answer'}}
stats.status=Number.isSafeInteger(answer.status)?answer.status:null
stats.worker=answer.state&&typeof answer.state==='object'?answer.state:null
if(answer.ok!==true){stats.reason=typeof answer.reason==='string'?answer.reason:'refused'
return{ok:false,reason:stats.reason}}
if(answer.status===304||typeof answer.body!=='string'||answer.body===''){stats.notModified+=1
stats.reason=null
return{ok:true,reason:'not-modified',seeded:0}}
const startedParse=now()
let parsed=null
try{parsed=parseCardBase(JSON.parse(answer.body))}catch(err){onError(err)
parsed=null}
stats.parseMs=now()-startedParse
if(parsed===null){stats.refused+=1
stats.reason='bad-shape'
return{ok:false,reason:'bad-shape'}}
const season=seasonNow()
if(parsed.game!==game||!seasonFits(parsed.game,season)){stats.refused+=1
stats.reason='other-season'
return{ok:false,reason:'other-season'}}
const startedSeed=now()
let result=null
try{result=await seed(parsed)}catch(err){onError(err)
result=null}
stats.seedMs=now()-startedSeed
if(result===null){stats.refused+=1
stats.reason='seed-failed'
return{ok:false,reason:'seed-failed'}}
if(groups!==null){try{groups(parsed.groups)}catch(err){onError(err)}}
stats.bodies+=1
stats.reason=null
remember({game:parsed.game,etag:typeof answer.etag==='string'?answer.etag:null,at:now(),
cards:parsed.count,builtAt:parsed.builtAt,complete:parsed.complete,indexed:parsed.indexed,misses:parsed.misses})
return{ok:true,reason:null,complete:parsed.complete,
seeded:Number.isSafeInteger(result.cards)?result.cards:0,cards:parsed.count}}
return{
async load(){loaded=true
if(storage===null)return null
try{const raw=await storage.read?.()
if(!raw||typeof raw!=='object'||Array.isArray(raw))return null
const game=Number.isSafeInteger(raw.game)?raw.game:null
const etag=typeof raw.etag==='string'&&raw.etag!==''?raw.etag:null
if(game===null||etag===null)return null
seeded={game,etag,at:Number.isSafeInteger(raw.at)?raw.at:null,
cards:Number.isSafeInteger(raw.cards)?raw.cards:null,
builtAt:typeof raw.builtAt==='string'?raw.builtAt:null,
complete:raw.complete===true,
indexed:Number.isSafeInteger(raw.indexed)?raw.indexed:null,
misses:Number.isSafeInteger(raw.misses)?raw.misses:null}
return seeded}catch(err){onError(err)
return null}},
refresh(why='start'){if(asking!==null)return asking
asking=runRefresh(why).then((out)=>{asking=null
return out},(err)=>{asking=null
throw err})
return asking},
state(){return{loaded,
seeded:seeded===null?null:{...seeded},
asks:stats.asks,bodies:stats.bodies,notModified:stats.notModified,refused:stats.refused,
askedAt:stats.askedAt,why:stats.why,status:stats.status,reason:stats.reason,
ms:{ask:stats.askMs,parse:stats.parseMs,seed:stats.seedMs},
worker:stats.worker===null?null:{...stats.worker}}}}}
function pick(index,row,name){const at=index[name]
return at===undefined?undefined:row[at]}
function season(value){return Number.isSafeInteger(value)&&value>=20&&value<=99?value:null}
function positionCode(value){return Number.isSafeInteger(value)&&value>=0&&value<=27?value:null}
function ratingOf(value){return Number.isSafeInteger(value)&&value>=1&&value<=99?value:null}
function count(value){return Number.isSafeInteger(value)&&value>=0?value:UNKNOWN}
function positive(value){return Number.isSafeInteger(value)&&value>0?value:null}
