import{MIN_PRICE,AUCTION_MAX_BID,floorToValidPrice,nextPrice,prevPrice} from './price-grid.js'
import{setPriceBadgeCoins} from './price-badges.js'
import{classifyStatus} from '../adapter/error-codes.js'
export const DEFAULT_CEILING=100_000
export const MIN_BIN_FEATURE='minBinSearch'
export const MARKET_PAGE=20
export const DEFAULT_MAX_REQUESTS=5
export const PAUSE_MIN_MS=600
export const PAUSE_MAX_MS=1200
const PRIOR_HEADROOM=1.2
export const BUDGET_LIMIT=30
const BUDGET_WINDOW_MS=60_000
export const REST_MS=300_000
export function createMarketBudget(options={}){const{clock}=options
if(!clock||typeof clock.now!=='function'){throw new Error('min-bin: бюджету рынка нужны часы (правило 6 NIGHT_BRIEF)')}
if(options.owner){const owner=options.owner
return{waitMs:()=>owner.waitMs(),
take:()=>owner.take('minute'),
warm:(count=1)=>(typeof owner.warm==='function'?owner.warm('minute',count):Promise.resolve(null)),
settle:()=>(typeof owner.settle==='function'?owner.settle('minute'):Promise.resolve(null)),
rest:(ms)=>owner.rest(ms),
stats:()=>{const state=owner.state()
return{spent:state?.minute?.used??0,limit:state?.minute?.cap??BUDGET_LIMIT,
restingUntil:state?.restingUntil??0}}}}
const limit=positive(options.limit)??BUDGET_LIMIT
const windowMs=positive(options.windowMs)??BUDGET_WINDOW_MS
const restMs=positive(options.restMs)??REST_MS
const stamps=[]
let restingUntil=0
const prune=(now)=>{while(stamps.length>0&&now-stamps[0]>=windowMs)stamps.shift()}
return{
waitMs(){const now=clock.now()
prune(now)
if(now<restingUntil)return restingUntil-now
if(stamps.length<limit)return 0
return windowMs-(now-stamps[0])},
take(){const now=clock.now()
prune(now)
if(now<restingUntil)return 'rest'
if(stamps.length>=limit)return 'budget'
stamps.push(now)
return null},
rest(ms){const until=clock.now()+(positive(ms)??restMs)
if(until>restingUntil)restingUntil=until
return restingUntil},
stats(){prune(clock.now())
return{spent:stamps.length,limit,restingUntil}}}}
export const CARD_COOLDOWN_MS=20_000
export const EMPTY_TRIES=3
const seenCards=new Map()
export const CARD_THROTTLE_MS=30*60_000
const throttledCards=new Map()
let lastThrottle=null
export function forgetRecentBins(){seenCards.clear()
throttledCards.clear()
lastThrottle=null}
export function cardThrottleLeft(criteria,clock,windowMs){const live=Number.isFinite(windowMs)?windowMs:CARD_THROTTLE_MS
if(!(live>0))return 0
const card=singleDefinitionOf(criteria)
if(card===null)return 0
const seen=throttledCards.get(card)
if(!seen)return 0
const now=safeNow(clock)
if(!Number.isFinite(now))return 0
const left=seen.until-now
if(left<=0||now<seen.until-live){throttledCards.delete(card)
return 0}
return left}
export function cardThrottleEvidence(card){const seen=throttledCards.get(card)
return seen?{...seen.evidence,until:seen.until}:null}
function throttleEvidenceOf(err,at){const body=err?.response
const error=body&&typeof body==='object'&&!Array.isArray(body)?body.error:null
const code=error&&typeof error==='object'&&typeof error.code==='number'?error.code:null
const reason=error&&typeof error==='object'&&typeof error.reason==='string'
?error.reason
:(body&&typeof body==='object'&&typeof body.reason==='string'?body.reason:null)
return{status:Number.isFinite(err?.status)?err.status:null,
httpStatus:Number.isFinite(err?.httpStatus)?err.httpStatus:null,
code,reason,at:Number.isFinite(at)?at:null}}
export function cardCooldownLeft(criteria,clock,windowMs){const live=Number.isFinite(windowMs)?windowMs:CARD_COOLDOWN_MS
if(!(live>0))return 0
const card=singleDefinitionOf(criteria)
if(card===null)return 0
const seen=seenCards.get(card)
if(!seen)return 0
if(seen.empty>0&&seen.empty<EMPTY_TRIES)return 0
const now=safeNow(clock)
if(!Number.isFinite(now))return 0
const left=seen.at+live-now
if(left<=0||now<seen.at){seenCards.delete(card)
return 0}
return left}
export function singleDefinitionOf(criteria){const raw=criteria?.defId
const list=Array.isArray(raw)?raw:(raw===undefined||raw===null?[]:[raw])
if(list.length!==1)return null
const id=Number(list[0])
return Number.isSafeInteger(id)&&id>0?id:null}
function safeNow(clock){try{const now=clock?.now?.()
return Number.isFinite(now)?now:Number.NaN}catch{return Number.NaN}}
function recallRecent(criteria,clock,windowMs){const live=Number.isFinite(windowMs)?windowMs:RECENT_MS
if(!(live>0))return null
const card=singleDefinitionOf(criteria)
if(card===null)return null
const seen=recent.get(card)
if(!seen)return null
const now=safeNow(clock)
if(!Number.isFinite(now))return null
if(now-seen.at>=live||now<seen.at){recent.delete(card)
return null}
return seen.price}
function publish(definitionId,coins){try{setPriceBadgeCoins(definitionId,coins)}catch{/* ценник — показ, а не замер */}}
export async function findMinBin(options){const{adapter,criteria={},clock,budget=null,maxRequests=DEFAULT_MAX_REQUESTS,ceiling=DEFAULT_CEILING}=options
if(!adapter||typeof adapter.searchTransferMarket!=='function'){throw new Error('min-bin: нужен адаптер с searchTransferMarket')}
if(!clock||typeof clock.sleep!=='function'){throw new Error('min-bin: нужны часы с sleep (правило 6 NIGHT_BRIEF)')}
const rng=typeof options.rng==='function'?options.rng:Math.random
const note=typeof options.note==='function'?options.note:null
const pauseMin=nonNegative(options.pauseMinMs)??PAUSE_MIN_MS
const pauseMax=Math.max(pauseMin,nonNegative(options.pauseMaxMs)??PAUSE_MAX_MS)
const pageSize=positive(criteria.count)??MARKET_PAGE
const top=floorToValidPrice(ceiling)
const marketTop=floorToValidPrice(AUCTION_MAX_BID)
const state={requests:0,low:null,high:null,error:null}
const budgetLeft=()=>{try{const stats=budget?.stats?.()
if(!stats||!Number.isFinite(stats.limit)||!Number.isFinite(stats.spent))return null
return Math.max(0,stats.limit-stats.spent)}catch{return null}}
const finish=(stoppedBy,price,waitMs=null)=>{
const card=singleDefinitionOf(criteria)
if(card!==null&&typeof price==='number')publish(card,price)
if(card!==null&&stoppedBy!=='card-cooldown'&&stoppedBy!=='card-throttled'){const at=safeNow(clock)
if(Number.isFinite(at)){const before=seenCards.get(card)
const empty=typeof price==='number'&&price>0?0:((before?.empty??0)+1)
seenCards.set(card,{at,empty})}}
return{price:price??null,requests:state.requests,stoppedBy,low:state.low,high:state.high,error:state.error,waitMs,left:budgetLeft(),
throttle:stoppedBy==='card-throttled'&&card!==null?cardThrottleEvidence(card):null}}
const noteThrottle=(err)=>{const card=singleDefinitionOf(criteria)
const at=safeNow(clock)
const live=Number.isFinite(options.throttleMs)?options.throttleMs:CARD_THROTTLE_MS
const previous=lastThrottle!==null&&Number.isFinite(at)&&at-lastThrottle.at<live
?lastThrottle.card
:null
const market=card===null||(previous!==null&&previous!==card)
if(card!==null&&Number.isFinite(at)&&live>0){throttledCards.set(card,{until:at+live,evidence:throttleEvidenceOf(err,at)})
lastThrottle={card,at}}
if(market)budget?.rest?.()
return market}
const pauseMs=()=>{const roll=Number(rng())
const fraction=Number.isFinite(roll)?Math.min(1,Math.max(0,roll)):0
return pauseMin+Math.round(fraction*(pauseMax-pauseMin))}
const page=async(maxBuy)=>{if(state.requests>0)await clock.sleep(pauseMs())
if(typeof adapter.clearMarketCache==='function')adapter.clearMarketCache()
state.requests+=1
const data=await adapter.searchTransferMarket({...criteria,count:pageSize,maxBuy},1)
const lots=listingsOf(data)
if(note!==null){try{note(lots)}catch{/* докорм словарей замеру не указ */}}
const prices=lotPrices(lots)
return{count:lots.length,min:prices.length>0?snapUp(Math.min(...prices)):null}}
const quarantined=cardThrottleLeft(criteria,clock,options.throttleMs)
if(quarantined>0)return finish('card-throttled',null,quarantined)
const waiting=cardCooldownLeft(criteria,clock,options.recentMs)
if(waiting>0)return finish('card-cooldown',null,waiting)
if(typeof budget?.warm==='function'){let asked=null
try{asked=await budget.warm(1)}catch{asked=null}
if(asked!==null){let wait=null
try{wait=budget?.waitMs?.()??null}catch{wait=null}
return finish(asked,null,wait)}}
try{
const start=positive(options.prior)
let maxBuy=start===null?top:Math.min(marketTop,snapUp(start*PRIOR_HEADROOM))
let best=null
while(state.requests<maxRequests){const refusal=budget?.take?.()
if(refusal){let wait=null
try{wait=budget?.waitMs?.()??null}catch{wait=null}
return finish(refusal,best,wait)}
if(typeof budget?.settle==='function'){let answered=null
try{answered=await budget.settle()}catch{answered=null}
if(typeof answered==='string'){let wait=null
try{wait=budget?.waitMs?.()??null}catch{wait=null}
return finish(answered,best,wait)}}
if(typeof options.cancelled==='function'){let stop=false
try{stop=options.cancelled()===true}catch{stop=false}
if(stop)return finish('cancelled',best)}
const{count,min}=await page(maxBuy)
if(count===0){state.low=maxBuy
if(best!==null)return finish('converged',best)
if(maxBuy>=marketTop)return finish('no-listings',null)
maxBuy=start===null?marketTop:Math.min(marketTop,snapUp(maxBuy*2))
continue}
if(min===null)return finish('unreadable',null)
best=min
state.high=min
if(count<pageSize)return finish('converged',min)
const next=prevPrice(min)
if(next<MIN_PRICE)return finish('converged',min)
maxBuy=next}
return finish('request-limit',best)}catch(err){state.error=err
const kind=classifyStatus(err?.status)
if(kind==='captcha'){budget?.rest?.()
return finish('captcha',null)}
if(kind==='throttled'){if(noteThrottle(err))return finish('throttled',null)
return finish('card-throttled',null,cardThrottleLeft(criteria,clock,options.throttleMs))}
if(kind==='fatal'||kind==='out-of-coins') return finish('fatal',null)
return finish('error',null)}}
export function listingsOf(data){if(!data
||typeof data!=='object'
||Array.isArray(data)
||!Array.isArray(data.items)){throw new Error('рынок: EA вернула неизвестную форму страницы')}
return data.items}
export function countListings(data){return listingsOf(data).length}
const REFUSAL_WORDS=Object.freeze({budget:'bin.budget','day-budget':'bin.dayBudget','search-hour':'bin.searchHour','counter-unavailable':'bin.counterUnavailable',rest:'bin.resting',throttled:'bin.resting',captcha:'bin.captcha','card-cooldown':'bin.cardCooldown','card-throttled':'bin.cardThrottled'})
export function minBinLabel(result,t){if(!result||result.ok!==true){if(result?.reason==='no-criteria') return t('bin.noCriteria')
const word=REFUSAL_WORDS[result?.reason]
if(word!==undefined)return t(word,{seconds:Math.max(1,Math.ceil(Number(result?.waitMs??0)/1000))})
return t('bin.error')}
if(result.price===null||result.price===undefined) return t('bin.notFound')
const low=Number.isFinite(result.left)&&result.left<=BUDGET_HINT_AT
if(result.measured==='card')return t(low?'hotkeys.minBin.cardLow':'hotkeys.minBin.card',{coins:result.price,name:result.name??''})
if(result.measured==='filter')return t(low?'hotkeys.minBin.filterLow':'hotkeys.minBin.filter',{coins:result.price})
return t('bin.result',{coins:result.price})}
export const BUDGET_HINT_AT=3
export function minBinTarget(input){const{card=null,criteria=null,criteriaOfCard}=input??{}
const id=card?.definitionId
if(typeof criteriaOfCard==='function'&&(Number.isSafeInteger(id)||(typeof id==='string'&&id!==''))){const name=typeof card?.name==='string'?card.name.trim().replace(/\s+/g,' '):''
return{criteria:criteriaOfCard(id,typeof card?.type==='string'?card.type:null),measured:'card',name}}
if(criteria&&typeof criteria==='object')return{criteria,measured:'filter',name:''}
return null}
export function lotPrices(lots){const prices=[]
for(const lot of Array.isArray(lots)?lots:[]){let value=null
try{value=lot?.getAuctionData?.()?.buyNowPrice}catch{value=null}
if(Number.isSafeInteger(value)&&value>0)prices.push(value)}
return prices}
function snapUp(value){const floor=floorToValidPrice(value)
return floor>=value?floor:nextPrice(floor)}
function positive(value){const num=Number(value)
return Number.isFinite(num)&&num>0?num:null}
function nonNegative(value){const num=Number(value)
return Number.isFinite(num)&&num>=0?num:null}
