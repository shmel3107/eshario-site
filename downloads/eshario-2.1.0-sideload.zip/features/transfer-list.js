import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoLink} from '../ui/controls.js'
import{modalBox,modalButtons} from '../ui/window.js'
import{netAfterTax} from './tax.js'
import{smartListPrice,nudgeListPrice,atListPrice,DEFAULT_DURATION} from './list-actions.js'
import{nextPrice,floorToValidPrice} from './price-grid.js'
import{priceBadgePeek} from './price-badges.js'
import{boughtOf} from './purchase-log.js'
import{cardFrozenNow,cardFrozenKey,frozenReasonOf} from './card-frozen.js'
import{itemForEvidenceRow} from './item-evidence.js'
import{createAdapter,localizeNumber,pileValueOf} from '../adapter/ea.js'
import{installClearSoldGuard} from '../adapter/clear-sold.js'
import{itemFact,isRelistableAuction,soldFact,pileRoom,createDoorConsent,doorConsentKey,
isDoorRefusal,reviewAction,ALLOWED} from '../adapter/action-door.js'
import{meterCalls,isDayBudgetError,DAY_BUDGET_REFUSAL,COUNTER_UNAVAILABLE,stopOnEaLimit} from './day-budget.js'
import{PAUSE_MIN_MS,PAUSE_MAX_MS} from './min-bin.js'
import{listPauseMs} from '../core/pace-jitter.js'
export const TRANSFER_BUILD='TRPERF1-1'
export const TRANSFER_LIST_FEATURE='enhancedTransferList'
export const TRANSFER_LIST_SELECTOR='.ut-transfer-list-view'
export const TRANSFER_ROW_SELECTOR='.listFUTItem'
export const TRANSFER_NAME_SELECTOR='.name'
export const UNASSIGNED_LIST_FEATURE='enhancedUnassignedList'
export const UNASSIGNED_LIST_SELECTOR='.ut-unassigned-view'
export const OBJECTIVES_LIST_FEATURE='enhancedObjectivesList'
export const OBJECTIVES_LIST_SELECTOR='.ut-objectives-hub'
export const OBJECTIVES_ROW_SELECTOR='.ut-objective-group-view'
export const OBJECTIVES_GROUP_TITLE_SELECTOR='.ut-objective-group-view--title'
export const OBJECTIVES_TASK_TITLE_SELECTOR='.ut-objective-task-view--title'
export const CLUB_LIST_FEATURE='enhancedClubList'
export const CLUB_LIST_SELECTOR='.ut-club-search-results-view'
export const CLUB_ROW_SELECTOR=TRANSFER_ROW_SELECTOR
export const CLUB_NAME_SELECTOR=TRANSFER_NAME_SELECTOR
const BUILD_MARK='futTransferBuild'
const TOOLS='fut-companion-list-tools'
const LISTS=[[TRANSFER_LIST_FEATURE,TRANSFER_LIST_SELECTOR,'Transfer'],[OBJECTIVES_LIST_FEATURE,OBJECTIVES_LIST_SELECTOR,'Objectives',OBJECTIVES_ROW_SELECTOR,`${OBJECTIVES_GROUP_TITLE_SELECTOR},${OBJECTIVES_TASK_TITLE_SELECTOR}`,'itemList.filterTasks'
],[CLUB_LIST_FEATURE,CLUB_LIST_SELECTOR,'Club']]
const labelKeyOf=(list)=>(typeof list?.[5]==='string'?list[5]:'itemList.filter')
const displays=new WeakMap()
const normalize=(value)=>String(value??'').trim().replace(/\s+/g,' ').toLowerCase()
function rowsOf(root,list){return root.querySelectorAll(list[3]??TRANSFER_ROW_SELECTOR)}
function restore(row){if(!displays.has(row))return
row.style.display=displays.get(row)
displays.delete(row)}
function applyFilter(root,query,list){const needle=normalize(query)
const rows=rowsOf(root,list)
const names=list[4]??TRANSFER_NAME_SELECTOR
for(const row of rows){const name=normalize(Array.from(row.querySelectorAll(names))
.map((node)=>node.textContent).join(' '))
const show=needle===''||name===''||name.includes(needle)
if(show)restore(row)
else if(!displays.has(row)){displays.set(row,row.style.display||'')
row.style.display='none'
}}}
function createTools(doc,root,t,list){const key=list[2]
ensureControls(doc)
const label=t(labelKeyOf(list))
const input=el(doc,'input',{class:'fx-search',attrs:{type:'search',placeholder:label,'aria-label':label},dataset:{[`fut${key}Filter`]:'1'},on:{input:()=>applyFilter(root,input.value,list)}})
const stop=(event)=>event?.stopPropagation?.()
const tools=el(doc,'div',{class:TOOLS,dataset:{[`fut${key}Tools`]:'1'},
on:{mousedown:stop,touchstart:stop,click:stop}},[logoLink(doc),input])
root.appendChild(tools)
return tools}
const TOOLS_HOME='display:flex;align-items:center;gap:6px;padding:6px'
const TOOLS_GUEST='display:flex;align-items:center;gap:6px;flex:0 1 auto;min-width:0'
const MARK_LINK_CLASS='fx-mark-link'
function headOf(root){try{return root?.querySelector?.(`${CARD_BAR_SELECTOR},${GUEST_HEAD_SELECTOR}`)??null}catch{return null}}
function placeTools(doc,root,tools){const head=headOf(root)
const mark=tools.querySelector?.(`.${MARK_LINK_CLASS}`)??null
if(head===null){if(tools.parentNode!==root)root.appendChild(tools)
if(tools.getAttribute?.('style')!==TOOLS_HOME)tools.setAttribute?.('style',TOOLS_HOME)
if(mark===null)tools.insertBefore(logoLink(doc),tools.firstChild??null)
return false}
const anchor=head.querySelector?.(`.${MONEY_CELL_CLASS}`)??head.querySelector?.(VIEW_TOGGLE_SELECTOR)??head.querySelector?.(PIN_SELECTOR)??null
const kids=Array.from(head.children??[])
const at=anchor===null?kids.length:kids.indexOf(anchor)
const settled=tools.parentNode===head&&kids.indexOf(tools)===at-1
if(!settled)head.insertBefore(tools,anchor)
if(tools.getAttribute?.('style')!==TOOLS_GUEST)tools.setAttribute?.('style',TOOLS_GUEST)
if(mark!==null)mark.remove?.()
return true}
export function enhanceTransferList({doc,t,isActive,win,sleep,relistPricing:port=null,dayBudget=null,measureMarket=null}){const money=enhanceTransferMoney({doc,t,isActive,win,sleep,relistPricing:port,dayBudget,measureMarket})
for(const list of LISTS){const roots=doc?.querySelectorAll?.(list[1])??[]
const active=isActive(list[0])
for(const root of roots){
if(root.dataset?.futSquadPick!==undefined){root.querySelector(`.${TOOLS}`)?.remove()
for(const row of rowsOf(root,list))restore(row);
continue}
let tools=root.querySelector(`.${TOOLS}`)
if(!active){tools?.remove()
for(const row of rowsOf(root,list))restore(row);
continue}
tools??=createTools(doc,root,t,list)
placeTools(doc,root,tools)
const input=tools.querySelector('input')
if(!input)continue
const label=t(labelKeyOf(list))
if(input.getAttribute?.('placeholder')!==label){input.setAttribute?.('placeholder',label)
input.setAttribute?.('aria-label',label)}
applyFilter(root,input.value,list)}}
return money}
const MONEY_STYLESHEET=new URL('../ui/transfer-money.css',import.meta.url).href
const MONEY_LINK_ID='fut-companion-transfer-money'
export const MONEY_MARK='futTransferMoney'
export const MONEY_SELECTOR='[data-fut-transfer-money]'
const SECTION_SELECTOR='.ut-sectioned-item-list-view'
const HEADER_SELECTOR='.ut-section-header-view'
const AUCTION_SELECTOR='.auction'
const STATE_SELECTOR='.auction-state'
const CARD_BAR_SELECTOR='[data-fut-card-bar]'
const GUEST_HEAD_SELECTOR='[data-fut-card-head]'
const VIEW_TOGGLE_SELECTOR='[data-fut-card-view-toggle]'
const PIN_SELECTOR='[data-fut-card-pin]'
const BAR_CLASS='fx-money'
const MONEY_CELL_CLASS='fx-money-cell'
const DESK_CLASS='fx-desk'
const NAME_SELECTOR='.entityContainer > .name'
const NAME_CLASS='fx-desk-name'
const DESK_CHIPS_CLASS='fx-desk-chips'
const MONEY_BOX_CLASS='fx-desk-money'
const DESK_SHAPE='futDeskShape'
const HEAD_CLASS='fx-transfer-head'
const TRIP_CLASS='fx-transfer-trip'
const CHIPS_CLASS='fx-transfer-chips'
const BTN_CLASS='fx-transfer-btn'
const TITLE_SELECTOR='h2.title'
export const BATCH_CAP=100
export const EA_REFUSALS_TO_STOP=2
export const EA_REFUSALS_TOTAL_STOP=3
export const RELIST_MARKET='market'
export const RELIST_STEP='step'
export const RELIST_PERCENT='percent'
export const RELIST_MODES=Object.freeze([RELIST_MARKET,RELIST_STEP,RELIST_PERCENT])
export const RELIST_MODE_DEFAULT=RELIST_MARKET
export const RELIST_DOWN='down'
export const RELIST_UP='up'
export const RELIST_DIRS=Object.freeze([RELIST_DOWN,RELIST_UP])
export const RELIST_DIR_DEFAULT=RELIST_DOWN
export const RELIST_PERCENT_DEFAULT=5
export const RELIST_PERCENT_MIN=1
export const RELIST_PERCENT_MAX=99
export const relistHasDirection=(mode)=>mode===RELIST_STEP||mode===RELIST_PERCENT
export function sanitizeRelistPricing(stored){const mode=RELIST_MODES.includes(stored?.mode)?stored.mode:RELIST_MODE_DEFAULT
const direction=RELIST_DIRS.includes(stored?.direction)?stored.direction:RELIST_DIR_DEFAULT
const raw=Number(stored?.percent)
const percent=Number.isFinite(raw)&&raw>=RELIST_PERCENT_MIN&&raw<=RELIST_PERCENT_MAX
?Math.round(raw):RELIST_PERCENT_DEFAULT
return Object.freeze({mode,direction,percent})}
export function relistPriceOf(pricing,market,limits){const view=sanitizeRelistPricing(pricing)
const reference=Number(market)
if(!Number.isFinite(reference)||reference<=0)return null
const up=view.direction===RELIST_UP
const price=view.mode===RELIST_PERCENT
?nudgeListPrice({buyNow:reference,factor:(up?100+view.percent:100-view.percent)/100,limits})
:(view.mode===RELIST_STEP
?(up?atListPrice({reference:nextPrice(floorToValidPrice(reference)),limits})
:smartListPrice({reference,limits}))
:atListPrice({reference,limits}))
return price.ok===true?price:null}
let relistPricing=sanitizeRelistPricing(null)
export function relistPricingNow(){return relistPricing}
let relistPort=null
function useRelistPort(port){if(!port||typeof port.read!=='function')return false
if(relistPort===port)return false
relistPort=port
let stored=null
try{stored=port.read()}catch{stored=null}
const next=sanitizeRelistPricing(stored)
if(samePricing(next,relistPricing))return false
relistPricing=next
batchConsent.forget()
armedKind=null
return true}
const samePricing=(one,two)=>one.mode===two.mode&&one.direction===two.direction&&one.percent===two.percent
export function setRelistPricing(patch){const next=sanitizeRelistPricing({...relistPricing,...(patch??{})})
if(pricingKey(next)===pricingKey(relistPricing))return relistPricing
relistPricing=next
if(relistPort&&typeof relistPort.write==='function'){try{relistPort.write({...next})}catch{/* не сохранилось — выбор всё равно действует */}}
batchConsent.forget()
armedKind=null
return relistPricing}
const pricingKey=(view)=>{if(view.mode===RELIST_PERCENT)return view.mode+'-'+view.direction+'-'+view.percent
if(view.mode===RELIST_STEP)return view.mode+'-'+view.direction
return view.mode}
const RELIST_MODE_KEYS=Object.freeze({market:'transfers.gear.mode.market',
step:'transfers.gear.mode.step',percent:'transfers.gear.mode.percent'})
const RELIST_DIR_KEYS=Object.freeze({down:'transfers.gear.dir.down',up:'transfers.gear.dir.up'})
const RELIST_SAY_KEYS=Object.freeze({market:'transfers.gear.say.market',
'step-down':'transfers.gear.say.stepDown','step-up':'transfers.gear.say.stepUp',
'percent-down':'transfers.gear.say.percentDown','percent-up':'transfers.gear.say.percentUp'})
const sayKeyOf=(view)=>(relistHasDirection(view.mode)
?RELIST_SAY_KEYS[view.mode+'-'+view.direction]:RELIST_SAY_KEYS[view.mode])
const CARD_UNIT_KEYS=Object.freeze({one:'transfers.unit.card1',
few:'transfers.unit.card2',many:'transfers.unit.card5'})
export function cardsUnitKey(count){const whole=Math.abs(Math.trunc(Number(count)||0))
const tail=whole%10
const teen=whole%100
if(tail===1&&teen!==11)return CARD_UNIT_KEYS.one
if(tail>=2&&tail<=4&&(teen<12||teen>14))return CARD_UNIT_KEYS.few
return CARD_UNIT_KEYS.many}
export const GEAR_WINDOW_MARK='futRelistGear'
export const GEAR_WINDOW_SELECTOR='[data-fut-relist-gear]'
const GEAR_CLASS='fx-transfer-gear'
const GEAR_GLYPH='⚙';
let gearHost=null
let gearOwner=null
let gearFeed=null
let gearWord=null
function closeGear(){gearHost?.remove?.()
gearHost=null
gearOwner=null
gearFeed=null
gearWord=null}
function sayGear(text){if(gearWord===null)return false
setText(gearWord,String(text))
return true}
function feedGear(section,chip,hand){if(gearFeed===null||gearOwner!==section)return false
gearFeed(chip,typeof hand==='function'?hand:null)
return true}
function openGear(doc,t,after,section=null){closeGear()
const modes=RELIST_MODES.map((mode)=>el(doc,'button',{class:'fx-action',attrs:{type:'button'},
dataset:{futRelistMode:mode},on:{click:()=>{setRelistPricing({mode})
paint(null)}}}))
const dirs=RELIST_DIRS.map((direction)=>el(doc,'button',{class:'fx-action',attrs:{type:'button'},
dataset:{futRelistDir:direction},on:{click:()=>{setRelistPricing({direction})
paint(null)}}}))
const field=el(doc,'input',{class:'fx-gear-percent',
attrs:{type:'text',inputmode:'numeric',maxlength:'2','aria-label':t('transfers.gear.percent')},
dataset:{futRelistPercent:'1'},
on:{input:()=>{const raw=Number(String(field.value??'').trim())
const ok=Number.isFinite(raw)&&raw>=RELIST_PERCENT_MIN&&raw<=RELIST_PERCENT_MAX
if(ok)setRelistPricing({percent:raw})
paint(ok?null:'bad')}}})
const say=el(doc,'div',{class:'fx-gear-say'})
const askKey=el(doc,'span',{class:'fx-gear-key'})
let askView=null
let askHand=null
const askBtn=el(doc,'button',{class:'fx-action',attrs:{type:'button'},
dataset:{futGearMeasure:'1'},
on:{click:()=>{if(typeof askHand!=='function')return
try{askHand()}
catch{/* заход сам говорит словом */}}}})
const askRow=el(doc,'div',{class:'fx-gear-row',dataset:{futGearAskRow:'1'}},[askKey,askBtn])
const askSay=el(doc,'div',{class:'fx-gear-word'})
const paintAsk=()=>{const chip=askView
setClass(askRow,chip===null||chip===undefined?'fx-gear-row fx-hidden':'fx-gear-row')
if(chip===null||chip===undefined)return
setText(askKey,chip.id==='measuring'?t(chip.key,chip.params):t('transfers.gear.unpriced',chip.params))
const armed=Boolean(chip.action)&&typeof askHand==='function'
setClass(askBtn,armed?'fx-action':'fx-action fx-hidden')
if(armed)setText(askBtn,t(chip.action==='stop'?'transfers.gear.stop':'transfers.gear.measure'))}
const dirRow=el(doc,'div',{class:'fx-gear-row',dataset:{futRelistDirRow:'1'}},
[el(doc,'span',{class:'fx-gear-key',text:t('transfers.gear.direction')}),
el(doc,'span',{class:'fx-gear-pick'},dirs)])
const percentRow=el(doc,'div',{class:'fx-gear-row',dataset:{futRelistPercentRow:'1'}},
[el(doc,'span',{class:'fx-gear-key',text:t('transfers.gear.percent')}),field,
el(doc,'span',{class:'fx-gear-range',
text:t('transfers.gear.percentRange',{min:RELIST_PERCENT_MIN,max:RELIST_PERCENT_MAX})})])
const paint=(bad)=>{const view=relistPricingNow()
for(const node of modes){const mode=node.dataset?.futRelistMode
setClass(node,view.mode===mode?'fx-action on':'fx-action')
setText(node,t(RELIST_MODE_KEYS[mode]))
if(node.setAttribute)node.setAttribute('aria-pressed',view.mode===mode?'true':'false')}
for(const node of dirs){const direction=node.dataset?.futRelistDir
setClass(node,view.direction===direction?'fx-action on':'fx-action')
setText(node,t(RELIST_DIR_KEYS[direction]))
if(node.setAttribute)node.setAttribute('aria-pressed',view.direction===direction?'true':'false')}
setClass(dirRow,relistHasDirection(view.mode)?'fx-gear-row':'fx-gear-row fx-hidden')
setClass(percentRow,view.mode===RELIST_PERCENT?'fx-gear-row':'fx-gear-row fx-hidden')
setClass(field,bad==='bad'?'fx-gear-percent fx-bad':'fx-gear-percent')
if(bad!=='bad'&&String(field.value??'')!==String(view.percent))field.value=String(view.percent)
setText(say,t('transfers.gear.now',{rule:t(sayKeyOf(view),{percent:view.percent})}))
paintAsk()
after?.()}
gearHost=modalBox(doc,{mark:GEAR_WINDOW_MARK,box:'fx-hk-capture-box fx-gear-box',
title:t('transfers.gear.title'),closeLabel:t('common.close'),
onBack:()=>{closeGear()
after?.()}},
[el(doc,'div',{class:'fx-gear-modes'},modes),dirRow,percentRow,say,
el(doc,'div',{class:'fx-gear-hint',text:t('transfers.gear.hint')}),askRow,askSay,
modalButtons(doc,[{text:t('common.close'),mark:'futRelistGearDone',on:()=>{closeGear()
after?.()}}])])
;(doc.body??doc.documentElement)?.appendChild?.(gearHost)
gearOwner=section
gearWord=askSay
gearFeed=(next,hand)=>{askView=next??null
askHand=hand
paintAsk()}
paint(null)
return gearHost}
export function sectionOfLot(item){const auction=auctionOfLot(item)
if(auction===null)return null
if(soldFact(auction)===true)return 'SOLD'
if(isRelistableAuction(auction)===true)return 'UNSOLD'
if(itemFact(auction,'isValid')===false)return 'AVAILABLE'
if(itemFact(auction,'isActiveTrade')===true)return 'ACTIVE'
return null}
function auctionOfLot(item){if(!item||typeof item.getAuctionData!=='function')return null
try{const data=item.getAuctionData()
return data&&typeof data==='object'?data:null}catch{return null}}
const wholeCoins=(value)=>{const number=Number(value)
return Number.isFinite(number)&&number>0?Math.round(number):0}
export function verdictOfLot(section,ask,market,costKnown=true){if(section==='SOLD')return costKnown===true?'profit':'net'
if(section!=='UNSOLD'&&section!=='AVAILABLE'&&section!=='ACTIVE')return null
if(market===null)return section==='UNSOLD'?'none':null
if(section==='AVAILABLE')return 'market'
if(market<ask)return 'cut'
return section==='ACTIVE'?'market':'dead'}
export function lotMoney(item,market,bought=0){const section=sectionOfLot(item)
if(section===null)return null
const auction=auctionOfLot(item)
const start=wholeCoins(auction?.startingBid)
const buy=wholeCoins(auction?.buyNowPrice)
const bid=wholeCoins(auction?.currentBid)
const ask=buy>0?buy:start
const soldFor=bid>0?bid:start
const paid=wholeCoins(bought)
const price=Number.isFinite(market)&&market>0?Math.round(market):null
const net=section==='SOLD'?netAfterTax(soldFor):0
const take=section==='SOLD'?net:(section==='ACTIVE'&&ask>0?netAfterTax(ask):0)
const costKnown=paid>0
const profit=costKnown===false?null
:(section==='SOLD'?net-paid:(section==='ACTIVE'&&ask>0?netAfterTax(ask)-paid:null))
return Object.freeze({section,start,buy,ask,soldFor,bought:paid,net,take,profit,market:price,
verdict:verdictOfLot(section,ask,price,costKnown)})}
const emptyBox=()=>({count:0,valued:0,market:0,net:0,take:0,quick:0,profit:0,costly:0,listed:0,cut:0,dead:0,none:0,relist:0,noPrice:0,club:0,list:0,frozen:0})
export function summarizeLots(lots){const out={SOLD:emptyBox(),UNSOLD:emptyBox(),AVAILABLE:emptyBox(),ACTIVE:emptyBox()}
for(const one of Array.isArray(lots)?lots:[]){const money=one?.money
const box=money===null||money===undefined?null:out[money.section]
if(!box)continue
box.count+=1
if(money.market!==null)box.market+=money.market
const valued=money.section==='SOLD'||money.section==='ACTIVE'||money.market!==null
if(valued){box.valued+=1
box.quick+=Math.max(0,Math.round(Number(one?.quick)||0))}
if(money.section==='SOLD')box.take+=money.net
else if(money.section==='ACTIVE')box.take+=money.take
else if(money.market!==null)box.take+=netAfterTax(money.market)
if(money.section==='SOLD'){box.net+=money.net
if(money.profit!==null){box.profit+=money.profit
box.costly+=1}}
if(money.section==='ACTIVE'){box.listed+=money.ask
if(money.profit!==null){box.profit+=money.profit
box.costly+=1}}
if(money.verdict==='cut')box.cut+=1
if(money.verdict==='dead')box.dead+=1
if(money.verdict==='none')box.none+=1
if(one.frozen===true)box.frozen+=1
if(money.section==='UNSOLD'){if(one.frozen===true){/* заморожена — своё число выше */}
else if(one.priced===true)box.relist+=1
else box.noPrice+=1}
if(money.section==='AVAILABLE'){if(one.frozen===true){/* заморожена — своё число выше */}
else if(one.priced===true&&one.tradeable===true)box.list+=1
else box.noPrice+=1}
if(one.frozen!==true&&one.movable===true&&(money.section==='AVAILABLE'||money.verdict==='dead'))box.club+=1}
return out}
export function coinsText(win,value){const number=Math.round(Number(value)||0)
const said=localizeNumber(win,number)
if(said!==null)return said
const sign=number<0?'−':''
return sign+String(Math.abs(number)).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
function signedText(win,value){const number=Math.round(Number(value)||0)
if(number>0)return`+${coinsText(win,number)}`
return coinsText(win,number)}
const batchConsent=createDoorConsent()
function forgetBatch(){batchConsent.forget()
armedKind=null}
let batchRun=null
export function stopBatchNow(){if(batchRun===null)return false
batchRun.stop=true
return true}
let armedKind=null
function adapterOf(win){if(!win)return null
try{return createAdapter(win)}catch{return null}}
const setText=(node,text)=>{if(!node)return false
if(node.textContent===text)return false
node.textContent=text
return true}
const setClass=(node,text)=>{if(!node)return false
if(node.className===text)return false
node.className=text
return true}
export function chipsOfLot(money,quick=0){const out=[]
if(money===null||money===undefined)return out
const verdict=money.verdict
if(money.section==='UNSOLD'||money.section==='ACTIVE'){
if(verdict==='cut'||verdict==='dead'||verdict==='none'||verdict==='market')out.push(verdict)}
else if(money.section==='AVAILABLE'&&money.market===null)out.push('none')
if(quicksellBetter(money,quick))out.unshift('quicksell')
return out}
export function quicksellBetter(money,quick){const value=Math.round(Number(quick)||0)
if(value<=0)return false
if(money?.section!=='UNSOLD'&&money?.section!=='AVAILABLE')return false
if(money.market===null||money.market===undefined)return false
return value>=netAfterTax(money.market)}
export function deskLines(money,price){const out=[]
if(money===null||money===undefined||money.section===null)return out
const put=(id,value,tone,lead,sign)=>{out.push({id,value,tone,lead:lead===true,sign:sign===true})}
const take=(lead)=>{if(money.profit!==null){put('profit',money.profit,money.profit<0?'fx-minus':'fx-plus',lead,true)
return}
if(money.take>0)put('net',money.take,'fx-mine',lead,false)}
if(money.section==='SOLD'){if(money.start>0)put('start',money.start,'fx-plain',false)
if(money.buy>0)put('buy',money.buy,'fx-plain',false)
take(true)
return out}
if(money.section==='ACTIVE'){put('bid',money.soldFor,'fx-plain',false)
if(money.buy>0)put('buy',money.buy,'fx-plain',false)
if(money.bought>0)put('bought',money.bought,'fx-plain',false)
take(true)
return out}
if(money.section==='UNSOLD'){put('start',money.start,'fx-plain',false)
if(money.buy>0)put('buy',money.buy,'fx-plain',true)
if(money.bought>0)put('bought',money.bought,'fx-plain',false)
if(price)put('relist',[price.startingBid,price.buyNow],'fx-plus',false)
return out}
if(money.bought>0)put('bought',money.bought,'fx-plain',true)
return out}
function deskText(line,win){const value=line.value
if(Array.isArray(value))return`${coinsText(win,value[0])} / ${coinsText(win,value[1])}`
if(value===null)return '–'
if(line.sign===true)return signedText(win,value)
return coinsText(win,value)}
export function lotName(row){let node=null
try{node=row?.querySelector?.(NAME_SELECTOR)??null}catch{node=null}
if(!node)return ''
return String(node.textContent??'').trim().replace(/[\s\u00a0]+/g,' ')}
function ourDesk(auction){for(const one of Array.from(auction?.children??[])){if(String(one.className??'').split(/\s+/).includes(DESK_CLASS))return one}
return null}
function paintDesk(doc,one,t,win){const auction=one?.row?.querySelector?.(AUCTION_SELECTOR)??null
if(!auction)return false
const desk=ourDesk(auction)
const money=one.money
if(money===null||money===undefined||money.section===null){if(desk){desk.remove?.()
return true}
return false}
let node=desk
if(!node){node=el(doc,'div',{class:DESK_CLASS})
const state=auction.querySelector?.(STATE_SELECTOR)??null
if(state)auction.insertBefore(node,state)
else auction.appendChild(node)}
setClass(node,`${DESK_CLASS} fx-${String(money.section).toLowerCase()}`)
const chips=chipsOfLot(money,one.quick)
const lines=deskLines(money,one.price)
const name=lotName(one.row)
const shape=`${name===''?'-':'who'}|${chips.length===0?'-':chips.join('+')}|${lines.map((line)=>line.id).join(',')}`
if(node.dataset&&node.dataset[DESK_SHAPE]!==shape){for(const old of Array.from(node.children??[]))old.remove?.()
if(name!==''||chips.length>0){const head=el(doc,'div',{class:NAME_CLASS})
if(name!=='')head.appendChild(el(doc,'span',{class:'fx-desk-who'}))
if(chips.length>0){const bar=el(doc,'div',{class:DESK_CHIPS_CLASS})
for(let made=0;made<chips.length;made+=1)bar.appendChild(el(doc,'span',{class:'fx-desk-chip'}))
head.appendChild(bar)}
node.appendChild(head)}
if(lines.length>0){const box=el(doc,'div',{class:MONEY_BOX_CLASS})
for(const line of lines)box.appendChild(el(doc,'div',{class:'fx-desk-row'},
[el(doc,'span',{class:'fx-desk-key'}),el(doc,'span',{class:'fx-desk-val'})]))
node.appendChild(box)}
node.dataset[DESK_SHAPE]=shape}
const kids=Array.from(node.children??[])
let at=0
if(name!==''||chips.length>0){const head=kids[at]
at+=1
if(name!=='')setText(head?.querySelector?.('.fx-desk-who'),name)
const badges=Array.from(head?.querySelector?.('.'+DESK_CHIPS_CLASS)?.children??[])
for(let put=0;put<chips.length;put+=1){const badge=badges[put]
if(!badge)continue
setClass(badge,`fx-desk-chip ${CHIP_TONES[chips[put]]}`)
setText(badge,t(CHIP_KEYS[chips[put]]))}}
const boxes=Array.from(kids[at]?.children??[])
for(let put=0;put<lines.length;put+=1){const line=lines[put]
const box=boxes[put]
if(!box)continue
setClass(box,`fx-desk-row${line.lead?' fx-lead':''}`)
setText(box.children?.[0],t(ROW_KEYS[line.id]))
const value=box.children?.[1]
setClass(value,`fx-desk-val ${line.tone}`)
setText(value,deskText(line,win))}
return true}
const unreadWord=(t,unread)=>(unread>0
?' '+t('transfers.sum.unread',{unread,unit:t(cardsUnitKey(unread))}):'')
export function sectionView(section,box,t,win,unread=0){const cards=t('transfers.sum.cards',
{count:box.count,unit:t(cardsUnitKey(box.count))})
const words=cards+unreadWord(t,unread)
if(section==='SOLD')return{words,chips:[],cells:[
{key:'transfers.cell.net',text:coinsText(win,box.net),tone:'fx-coins'},
profitCell(box,win)]}
if(section==='ACTIVE')return{words,chips:chipsOfSection(box),cells:[
{key:'transfers.cell.listed',text:coinsText(win,box.listed),tone:''},
{key:'transfers.cell.net',text:coinsText(win,box.take),tone:'fx-coins'},
{key:'transfers.cell.quick',text:coinsText(win,box.quick),tone:'fx-quiet'}]}
return{words,chips:chipsOfSection(box),cells:[
{key:'transfers.cell.market',text:coinsText(win,box.market),tone:''},
{key:'transfers.cell.net',text:coinsText(win,box.take),tone:'fx-coins'},
{key:'transfers.cell.quick',text:coinsText(win,box.quick),tone:'fx-quiet'}]}}
export function chipsOfSection(box){const out=[]
if(box.cut>0)out.push({id:'cut',key:'transfers.chip.cut',params:{count:box.cut},tone:'fx-cut'})
if(box.dead>0)out.push({id:'dead',key:'transfers.chip.dead',params:{count:box.dead},tone:'fx-dead'})
if(box.frozen>0)out.push({id:'frozen',key:'transfers.chip.frozen',params:{count:box.frozen},tone:'fx-ice'})
return out}
export function askChip(box,ask){if(ask?.busy===true){return{id:'measuring',key:'transfers.chip.measuring',
params:{done:Math.max(0,Math.trunc(Number(ask.done)||0)),total:Math.max(0,Math.trunc(Number(ask.total)||0))},
tone:'fx-ask',action:'stop'}}
const unpriced=Math.max(0,box.count-box.valued)
if(unpriced===0)return null
if(ask?.can===true)return{id:'measure',key:'transfers.chip.noPrice',params:{count:unpriced},tone:'fx-ask',action:'measure'}
return{id:'noPrice',key:'transfers.chip.noPrice',params:{count:unpriced},tone:'fx-none',action:null}}
export function jobsOf(rows,kind){const out=[]
for(const one of Array.isArray(rows)?rows:[]){if(out.length>=BATCH_CAP)break
const money=one?.money
if(money===null||money===undefined)continue
if(one.frozen===true)continue
if(kind==='relist'){if(money.section!=='UNSOLD'||!one.price)continue
out.push({item:one.item,row:one.row,id:one.id,price:one.price})
continue}
if(kind==='list'){if(money.section!=='AVAILABLE'||!one.price||one.tradeable!==true)continue
out.push({item:one.item,row:one.row,id:one.id,price:one.price})
continue}
if(one.movable!==true)continue
if(money.section==='AVAILABLE'||money.verdict==='dead')out.push({item:one.item,row:one.row,id:one.id,price:null})}
return out}
const DOOR_WHY_KEYS=Object.freeze({predicate:'transfers.why.notTradeable',
'already-selling':'transfers.why.selling','market-off':'transfers.why.marketOff',
capacity:'transfers.why.noRoom','locked-card':'transfers.why.locked',
'unreadable-predicate':'transfers.why.unreadable','unreadable-item':'transfers.why.unreadable',
'unreadable-origin':'transfers.why.unreadable','unreadable-market':'transfers.why.unreadable',
'unreadable-capacity':'transfers.why.unreadable','unreadable-rows':'transfers.why.unreadable',
'unreadable-locks':'transfers.why.unreadable',empty:'transfers.why.unreadable',
'frozen-card':'transfers.why.frozen','frozen-unreadable':'transfers.why.frozenUnreadable'})
export function refusalWords(reasons,t){const out=[]
for(const one of Array.isArray(reasons)?reasons:[]){
if(String(one).startsWith('ea:')){const code=String(one).slice(3)
const word=code==='?'?t('transfers.why.ea'):t('transfers.why.eaCode',{status:code})
if(!out.includes(word))out.push(word)
continue}
const said=typeof DOOR_WHY_KEYS[one]==='string'
?t(DOOR_WHY_KEYS[one]):t('transfers.why.door',{reason:String(one)})
if(!out.includes(said))out.push(said)}
return out.join(', ')}
function recheckSkipped(kind,skippedJobs,deps){if(skippedJobs.length===0)return 0
let changed=0
for(const one of skippedJobs){let verdict=null
try{verdict=reviewAction(kind==='club'
?{action:'move',win:deps.win,items:[one.item],destination:'CLUB'}
:{action:'list',win:deps.win,items:[one.item],fresh:kind==='list',rows:kind==='list'?deps.listRows:null})}
catch{verdict=null}
if(verdict?.verdict===ALLOWED&&one.reason!=='locked-card')changed+=1}
return changed}
function meteredItems(adapter,day){if(!day||typeof day.take!=='function'||typeof day.warm!=='function'){
return{ok:false,reason:COUNTER_UNAVAILABLE}}
return{ok:true,item:meterCalls(adapter.item,day,['list','move'],{stage:BUDGET_STAGE})}}
const BUDGET_STAGE='transfers'
const BUDGET_WHY_KEYS=Object.freeze({[DAY_BUDGET_REFUSAL]:'transfers.why.dayBudget',
[COUNTER_UNAVAILABLE]:'transfers.why.noCounter'})
const budgetWord=(reason,t,door)=>{const said=t(BUDGET_WHY_KEYS[reason]??'transfers.why.dayBudget')
return typeof door==='string'&&door!==''?said+' '+t('transfers.why.door.at',{door}):said}
export async function runBatch(kind,jobs,deps){const{win,t,say,sleep}=deps
const note=typeof deps.note==='string'?deps.note:''
const adapter=adapterOf(win)
const club=pileValueOf(win,'CLUB')
if(adapter===null||(kind==='club'&&club===null)){say(t('transfers.run.stopped',{done:1,total:jobs.length,why:t('transfers.why.gone')}))
return{ok:false,reason:'no-adapter',done:0,skipped:0,refusals:[]}}
const metered=meteredItems(adapter,deps.dayBudget??null)
if(metered.ok!==true){say(t('transfers.run.stopped',{done:0,total:jobs.length,
why:budgetWord(metered.reason,t,null)}))
return{ok:false,reason:'day-budget',done:0,skipped:0,refusals:[metered.reason]}}
const item=metered.item
const listRows=kind==='list'&&typeof deps.listRows==='function'?deps.listRows():null
let done=0
let skipped=0
let byHand=false
let eaRow=0
let eaTotal=0
const refusals=[]
const skippedJobs=[]
batchRun={stop:false}
try{for(const job of jobs){say(t('transfers.run.busy',{done:done+skipped+1,total:jobs.length}))
let asked=false
const chill=frozenReasonOf(job.id)
if(chill!==null){skipped+=1
const word=chill==='unreadable'?'frozen-unreadable':'frozen-card'
refusals.push(word)}
else{try{if(kind==='relist')await item.list(job.item,job.price.startingBid,job.price.buyNow,DEFAULT_DURATION,{fresh:false,rows:null})
else if(kind==='list')await item.list(job.item,job.price.startingBid,job.price.buyNow,DEFAULT_DURATION,{fresh:true,rows:listRows})
else await item.move([job.item],club)
asked=true
eaRow=0
done+=1}
catch(err){
if(isDayBudgetError(err)){say(t('transfers.run.stopped',{done:done+skipped+1,total:jobs.length,
why:budgetWord(String(err?.reason??DAY_BUDGET_REFUSAL),t,err?.door??null)})+note)
return{ok:false,reason:'day-budget',done,skipped,refusals}}
if(isDoorRefusal(err)){
if(err?.door?.reason==='capacity'&&kind==='list'){const room=err.door
say(t('transfers.run.noRoom',
{count:done,fits:room.fits??0,used:room.used??'?',size:room.size??'?'})+note)
return{ok:false,reason:'capacity',done,skipped,refusals}}
skipped+=1
const why=String(err?.door?.reason??'?')
refusals.push(why)
skippedJobs.push({item:job.item,reason:why})}
else{
const status=Number(err?.status)
const who=lotName(job.row)
try{deps.detail?.(eaAnswerText(err))}catch{/* прибор не имеет права ронять пачку */}
asked=true
eaRow+=1
eaTotal+=1
refusals.push('ea:'+(Number.isFinite(status)?status:'?'))
const rhythm=stopOnEaLimit(deps.dayBudget??null,err)!==null
if(rhythm||eaRow>=EA_REFUSALS_TO_STOP||eaTotal>=EA_REFUSALS_TOTAL_STOP){
say(t(who===''?'transfers.run.stopped':'transfers.run.stoppedAt',
{done:done+skipped+1,total:jobs.length,who,
why:rhythm?t('transfers.why.eaRhythm',{status})
:(Number.isFinite(status)?t('transfers.why.eaCode',{status}):t('transfers.why.ea'))})+note)
return{ok:false,reason:rhythm?'ea-rhythm':'ea',done,skipped:skipped+1,refusals}}
skipped+=1}}}
if(batchRun?.stop===true){byHand=true
break}
if(done+skipped<jobs.length){if(asked)await sleep(listPauseMs(deps.random))
else await nextFrame(win)}}
if(byHand){const why=refusalWords(refusals,t)
say(t(STOP_KEYS[kind]??STOP_KEYS.club,{count:done,total:jobs.length})
+(skipped>0?' '+t('transfers.stop.skipped',{skipped,why}):'')+note)
return{ok:true,reason:'stopped',stopped:true,done,skipped,refusals}}
const words=refusalWords(refusals,t)
const changed=recheckSkipped(kind,skippedJobs,{win,listRows})
const tail=changed>0?' '+t('transfers.why.transient',{changed,skipped}):''
say((skipped>0
?t(doneKeyOf(kind,true),{count:done,skipped,why:words})
:t(doneKeyOf(kind,false),{count:done,skipped}))+tail+note)
return{ok:true,reason:null,done,skipped,refusals,changed}}
finally{batchRun=null}}
export function clearSoldPlan(doc){for(const root of Array.from(doc?.querySelectorAll?.(TRANSFER_LIST_SELECTOR)??[])){
for(const box of Array.from(root.querySelectorAll?.(SECTION_SELECTOR)??[])){const rows=readRows(box)
if(rows.length===0||rows[0].money.section!=='SOLD')continue
const drop=[]
let kept=0
for(const one of rows){if(one.frozen===true){kept+=1
continue}
if(one.item)drop.push(one.item)}
return{drop,kept,header:box.querySelector?.(HEADER_SELECTOR)??null}}}
return null}
export async function runClearSold(deps){const{win,t,say,sleep,drop,kept}=deps
const done0={ok:false,done:0,kept,total:Array.isArray(drop)?drop.length:0}
const finish=()=>{try{deps.unlock?.()}catch{/* вид уехал */}
try{deps.refresh?.()}catch{/* список уехал */}}
const adapter=adapterOf(win)
if(adapter===null){say(t('transfers.clear.stopped',{done:0,total:done0.total,why:t('transfers.why.gone')}))
finish()
return{...done0,reason:'no-adapter'}}
if(done0.total===0){say(t('transfers.clear.kept',{kept}))
finish()
return{...done0,ok:true,reason:'nothing'}}
const day=deps.dayBudget??null
if(!day||typeof day.take!=='function'||typeof day.warm!=='function'){
say(t('transfers.clear.stopped',{done:0,total:done0.total,why:budgetWord(COUNTER_UNAVAILABLE,t,null)}))
finish()
return{...done0,reason:COUNTER_UNAVAILABLE}}
const item=meterCalls(adapter.item,day,['clear'],{stage:BUDGET_STAGE})
try{deps.lock?.()}catch{/* вид уехал */}
let done=0
let left=kept
let late=0
try{for(const one of drop){
const chill=frozenReasonOf(cardFrozenKey(one))
if(chill!==null){left+=1
late+=1
continue}
say(t('transfers.clear.busy',{done:done+late+1,total:done0.total}))
try{await item.clear([one],one)
done+=1}
catch(err){const status=Number(err?.status)
const why=isDayBudgetError(err)
?budgetWord(String(err?.reason??DAY_BUDGET_REFUSAL),t,err?.door??null)
:(isDoorRefusal(err)
?refusalWords([String(err?.door?.reason??'?')],t)
:(Number.isFinite(status)?t('transfers.why.eaCode',{status}):t('transfers.why.ea')))
say(t('transfers.clear.stopped',{done:done+late+1,total:done0.total,why}))
return{...done0,done,kept:left,reason:'stopped'}}
if(done+late<done0.total)await sleep(listPauseMs(deps.random))}
say(left>0?t('transfers.clear.doneKept',{count:done,kept:left}):t('transfers.clear.done',{count:done}))
return{ok:true,done,kept:left,total:done0.total,reason:null}}
finally{finish()}}
function armClearSold(deps){const view=deps.win
if(!view)return{ok:false,reason:'no-win'}
const hand={shouldGuard:()=>{if(deps.isActive?.(TRANSFER_LIST_FEATURE)!==true)return false
const sold=clearSoldPlan(deps.doc)
return sold!==null&&sold.kept>0},
run:(hands)=>{const sold=clearSoldPlan(deps.doc)
if(sold===null){hands.unlock()
hands.refresh()
return null}
return runClearSold({win:view,t:deps.t,sleep:deps.sleep,dayBudget:deps.dayBudget,
drop:sold.drop,kept:sold.kept,
say:(text)=>sayInto(sold.header,text),
lock:hands.lock,unlock:hands.unlock,refresh:hands.refresh}).catch(()=>null)}}
const out=installClearSoldGuard(view,hand)
return{ok:out.ok,reason:out.reason}}
export const ASK_CAP=20
let askRun=null
export function askRunNow(){return askRun===null?null:{section:askRun.section,done:askRun.done,total:askRun.total}}
const ASK_STOP=Object.freeze(['off','no-market','bad-key','budget','rest','captcha','fatal','throttled',
DAY_BUDGET_REFUSAL,COUNTER_UNAVAILABLE])
const ASK_WHY_KEYS=Object.freeze({throttled:'transfers.ask.why.wait',rest:'transfers.ask.why.wait',
captcha:'transfers.ask.why.captcha',off:'transfers.ask.why.off','no-market':'transfers.ask.why.noMarket',
budget:'transfers.why.dayBudget',[DAY_BUDGET_REFUSAL]:'transfers.why.dayBudget',
[COUNTER_UNAVAILABLE]:'transfers.why.noCounter'})
function askViewOf(section,door){if(askRun!==null&&askRun.section===section){
return{can:true,busy:true,done:askRun.done,total:askRun.total}}
if(askRun!==null)return{can:false,busy:false}
return{can:door===true,busy:false}}
export async function runAsk(section,deps){if(askRun!==null&&askRun.section===section){askRun.stop=true
return{ok:false,reason:'stopping'}}
if(askRun!==null)return{ok:false,reason:'busy'}
const door=typeof deps?.door==='function'?deps.door:null
if(door===null)return{ok:false,reason:'no-door'}
const targets=[]
for(const one of deps.rows()){if(targets.length>=ASK_CAP)break
if(one?.money?.market===null&&one.item)targets.push(one)}
if(targets.length===0){deps.say(deps.t('transfers.ask.nothing'))
return{ok:false,reason:'nothing'}}
askRun={section,done:0,total:targets.length,stop:false}
deps.repaint()
let measured=0
let stopped=null
try{for(const one of targets){if(askRun.stop){stopped='stopped'
break}
let answer=null
try{answer=await door(one.item)}catch(err){answer={ok:false,reason:String(err?.message??err)}}
askRun.done+=1
const why=String(answer?.reason??'')
if(answer?.ok===true&&Number.isFinite(answer.price)&&answer.price>0)measured+=1
if(answer?.ok!==true&&ASK_STOP.includes(why)){stopped=why
break}
deps.repaint()
if(askRun.stop||one===targets[targets.length-1])continue
await askGap(deps)}}
finally{const run=askRun
askRun=null
deps.repaint()
if(stopped!==null&&stopped!=='stopped'){deps.say(deps.t('transfers.ask.stopped',
{done:run?.done??0,total:run?.total??0,why:deps.t(ASK_WHY_KEYS[stopped]??'transfers.why.ea')}))}
else{const left=Math.max(0,(run?.total??0)-measured)
deps.say(deps.t('transfers.ask.done',{count:measured,left}))}}
return{ok:stopped===null||stopped==='stopped',reason:stopped,done:measured}}
function askGap(deps){const win=deps.win
const span=PAUSE_MAX_MS-PAUSE_MIN_MS
const ms=PAUSE_MIN_MS+Math.floor(Math.random()*(span+1))
const sleep=typeof deps.sleep==='function'?deps.sleep:sleeperOf(win)
return Promise.resolve(sleep(ms)).then(()=>nextFrame(win))}
export const FRAME_BACKUP_MS=16
function nextFrame(win){return new Promise((done)=>{let fired=false
const go=()=>{if(fired)return
fired=true
done()}
const raf=typeof win?.requestAnimationFrame==='function'?win.requestAnimationFrame:null
const timer=typeof win?.setTimeout==='function'?win.setTimeout:null
if(raf){try{raf.call(win,go)}catch{/* кадра не будет — остаётся таймер */}}
if(timer){try{timer.call(win,go,FRAME_BACKUP_MS)}catch{go()}}
if(!raf&&!timer)go()})}
const RUN_DONE_KEYS=Object.freeze({relist:'transfers.run.relisted',
list:'transfers.run.listed',club:'transfers.run.moved'})
const RUN_SOME_KEYS=Object.freeze({relist:'transfers.run.relistedSome',
list:'transfers.run.listedSome',club:'transfers.run.movedSome'})
const doneKeyOf=(kind,some)=>(some?RUN_SOME_KEYS:RUN_DONE_KEYS)[kind]??RUN_DONE_KEYS.club
const STOP_KEYS=Object.freeze({relist:'transfers.stop.relist',
list:'transfers.stop.list',club:'transfers.stop.club'})
export const RUN_WINDOW_MARK='futBatchRun'
export const RUN_WINDOW_SELECTOR='[data-fut-batch-run]'
let runHost=null
let runWord=null
let runDetail=null
let runQuestion=null
let runDetailText=''
let runRow=null
function closeRunWindow(){if(runHost===null)return
runHost.remove?.()
runHost=null
runWord=null
runDetail=null
runDetailText=''
runQuestion=null
runRow=null}
export function eaAnswerText(err){const out=[]
const http=Number(err?.httpStatus)
if(Number.isFinite(http))out.push('HTTP '+http)
const put=(where,lead)=>{if(!where||typeof where!=='object')return
for(const key of Object.keys(where)){if(key==='success'||key==='status')continue
const value=where[key]
const kind=typeof value
if(kind!=='string'&&kind!=='number'&&kind!=='boolean')continue
const said=String(value)
if(said==='')continue
out.push((lead===''?'':lead+'.')+key+'='+said)}}
put(err?.response,'')
put(err?.response?.error,'error')
const said=out.join(' · ')
return said.length>260?said.slice(0,257)+'…':said}
function sayRun(text){if(runWord===null)return false
setText(runWord,String(text))
return true}
function sayRunDetail(text){if(runDetail===null)return false
const said=String(text??'')
if(said==='')return false
if(runDetailText!==''&&runDetailText.includes(said))return true
runDetailText=runDetailText===''?said:runDetailText+' ;; '+said
if(runDetailText.length>520)runDetailText=runDetailText.slice(0,517)+'…'
setText(runDetail,runDetailText)
return true}
function openRunWindow(doc,t,spec){closeRunWindow()
const word=el(doc,'div',{class:'fx-run-word'})
const detail=el(doc,'div',{class:'fx-run-detail'})
const stop=()=>{closeRunWindow()
spec.onClose?.()}
const row=modalButtons(doc,[
{text:spec.yes,mark:'futBatchRunYes',kind:'primary',on:()=>{spec.onYes?.()}}])
runQuestion=askBlock(doc,t,spec)
runHost=modalBox(doc,{mark:RUN_WINDOW_MARK,
box:'fx-hk-capture-box fx-run-box',
title:spec.title,closeLabel:t('common.close'),onBack:stop},[runQuestion,word,detail,row].filter(Boolean))
runWord=word
runDetail=detail
runRow=row
;(doc.body??doc.documentElement)?.appendChild?.(runHost)
return runHost}
function askBlock(doc,t,spec){const kind=String(spec.kind??'')
if(kind==='')return null
const count=Math.max(0,Math.trunc(Number(spec.count)||0))
const rows=[el(doc,'div',{class:'fx-run-ask'},
[el(doc,'span',{text:t(ASK_HEAD_KEYS[kind]??ASK_HEAD_KEYS.club)+' '}),
el(doc,'b',{class:'fx-run-num',text:t('transfers.sum.cards',{count,unit:spec.unit??''})})])]
if(typeof spec.rule==='string'&&spec.rule!=='')rows.push(el(doc,'div',{class:'fx-run-rule',
text:t('transfers.ask.rule',{rule:spec.rule})}))
const parts=spec.parts??null
if(parts!==null){const chips=[chipNode(doc,t('transfers.chip.section',{count:parts.total}))]
if(parts.frozen>0)chips.push(chipNode(doc,t('transfers.chip.frozenPlain',{count:parts.frozen})))
if(parts.noPrice>0)chips.push(chipNode(doc,t('transfers.chip.noPrice',{count:parts.noPrice})))
rows.push(el(doc,'div',{class:'fx-run-chips'},chips))}
const note=typeof spec.note==='string'?spec.note.trim():''
if(note!=='')rows.push(el(doc,'div',{class:'fx-run-note',text:note}))
return el(doc,'div',{class:'fx-run-ask-box'},rows)}
function chipNode(doc,text){return el(doc,'span',{class:'fx-desk-chip fx-none',text})}
function runWindowWorking(doc,t){
runQuestion?.remove?.()
runQuestion=null
setRunRow(doc,[
{text:t('transfers.stop.button'),mark:'futBatchRunStop',on:()=>{if(!stopBatchNow())return
sayRun(t('transfers.stop.now'))
closeOnlyRow(doc,t)}},
{text:t('common.close'),mark:'futBatchRunDone',on:()=>{closeRunWindow()}}])}
function setRunRow(doc,buttons){if(runHost===null||runRow===null)return false
const next=modalButtons(doc,buttons)
runRow.replaceWith?.(next)
runRow=next
return true}
function closeOnlyRow(doc,t){return setRunRow(doc,[{text:t('common.close'),
mark:'futBatchRunDone',on:()=>{closeRunWindow()}}])}
function settleRunWindow(out,after,doc,t){const done=out?.done
if(!done||typeof done.then!=='function')return false
const note=typeof out.note==='string'?out.note:''
const rest=()=>{closeOnlyRow(doc,t)}
done.then((answer)=>{if(answer?.ok!==true||answer?.stopped===true
||Math.max(0,Math.trunc(Number(answer.skipped)||0))!==0||note!==''){rest()
return}
closeRunWindow()
after?.()},()=>{rest()})
return true}
function pressBatch(kind,deps){if(batchRun!==null)return{ok:false,reason:'busy'}
const view=typeof deps.read==='function'?deps.read():{rows:deps.rows?.()??[],seen:0,unread:0}
const jobs=jobsOf(view.rows,kind)
const note=promiseNote(kind,deps.promised,jobs.length,view,deps.t)
if(jobs.length===0){armedKind=null
if(note!=='')deps.say(note.trim())
return{ok:false,reason:'empty',note}}
const key=doorConsentKey({action:kind==='club'?'move':'list',
reason:kind==='club'?'batch':'batch-'+kind+'-'+pricingKey(relistPricing),
destination:kind==='club'?'CLUB':'TRANSFER',ids:jobs.map((job)=>job.id)})
if(!batchConsent.ask(key)){armedKind=kind
const question=deps.t(ASK_KEYS[kind]??ASK_KEYS.club,
{count:jobs.length,unit:deps.t(cardsUnitKey(jobs.length)),
rule:deps.t(sayKeyOf(relistPricing),{percent:relistPricing.percent})})+note
+sectionNote(kind,view,deps.t)
if(typeof deps.confirm==='function')deps.confirm({text:question,count:jobs.length,
kind,unit:deps.t(cardsUnitKey(jobs.length)),
rule:kind==='club'?null:deps.t(sayKeyOf(relistPricing),{percent:relistPricing.percent}),
parts:sectionParts(kind,view),note})
else deps.say(question)
return{ok:false,reason:'consent',count:jobs.length,note}}
armedKind=null
const done=runBatch(kind,jobs,{...deps,note})
done.catch?.(()=>{})
return{ok:true,reason:null,count:jobs.length,done,note}}
export function sectionParts(kind,view){const rows=Array.isArray(view?.rows)?view.rows:[]
const box=summarizeLots(rows)[SECTION_OF_KIND[kind]??'UNSOLD']
const whole=(value)=>Math.max(0,Math.trunc(Number(value)||0))
const total=whole(box?.count)
const promised=whole(box?.[BULK_FIELD_OF_KIND[kind]??'relist'])
const frozen=whole(box?.frozen)
const noPrice=whole(box?.noPrice)
if(frozen+noPrice+promised!==total)return null
if(frozen+noPrice===0)return null
return{total,promised,frozen,noPrice}}
export function sectionNote(kind,view,t){const parts=sectionParts(kind,view)
if(parts===null)return ''
const why=[]
if(parts.frozen>0)why.push(t('transfers.chip.frozen',{count:parts.frozen}))
if(parts.noPrice>0)why.push(t('transfers.chip.noPrice',{count:parts.noPrice}))
return ' '+t('transfers.batch.section',{total:parts.total,taken:parts.promised,why:why.join(', ')})}
export function promiseNote(kind,promised,taken,view,t){const said=Number(promised)
if(!Number.isSafeInteger(said)||said===taken)return ''
const rows=Array.isArray(view?.rows)?view.rows:[]
const unread=Math.max(0,Number(view?.unread)||0)
const box=summarizeLots(rows)[SECTION_OF_KIND[kind]??'UNSOLD']
const why=said<taken?t('transfers.promise.late')
:(taken>=BATCH_CAP?t('transfers.promise.cap',{cap:BATCH_CAP,left:Math.max(0,said-taken)})
:(unread>0?t('transfers.promise.unread',{unread,unit:t(cardsUnitKey(unread))})
:(kind!=='club'&&box.noPrice>0?t('transfers.promise.noPrice',{noPrice:box.noPrice,unit:t(cardsUnitKey(box.noPrice))})
:t('transfers.promise.gone'))))
return ' '+t('transfers.promise.said',{promised:said,taken,why})}
const SECTION_OF_KIND=Object.freeze({relist:'UNSOLD',list:'AVAILABLE',club:'AVAILABLE'})
const BULK_FIELD_OF_KIND=Object.freeze({relist:'relist',list:'list',club:'club'})
const ASK_KEYS=Object.freeze({relist:'transfers.btn.relistAllAsk',
list:'transfers.btn.listAllAsk',club:'transfers.btn.clubAsk'})
const ASK_HEAD_KEYS=Object.freeze({relist:'transfers.ask.relist',
list:'transfers.ask.list',club:'transfers.ask.club'})
const BULK_YES_KEYS=Object.freeze({relist:'transfers.btn.relistAll',
list:'transfers.btn.listAll',club:'transfers.btn.club'})
function paintHead(doc,header,section,summary,t,win,deps,unread=0){if(!header)return false
const bulkKind=section==='AVAILABLE'?'list':'relist'
const mine=ourStrip(header)
if(section===null){if(mine){returnTitle(header)
mine.remove?.()}
return false}
const strip=mine??el(doc,'div',{class:HEAD_CLASS},[logoLink(doc),
el(doc,'span',{class:'fx-transfer-sum'}),
el(doc,'span',{class:CHIPS_CLASS}),
el(doc,'span',{class:'fx-transfer-say'}),
el(doc,'span',{class:TRIP_CLASS})])
placeStrip(header,strip)
placeTitle(header,strip)
placeButtons(doc,header,strip,deps,bulkKind)
const view=sectionView(section,summary,t,win,unread)
const ask=askChip(summary,deps?.ask??null)
setText(strip.querySelector?.('.fx-transfer-sum')??null,view.words)
paintChips(doc,strip.querySelector?.(`.${CHIPS_CLASS}`)??null,view.chips,t)
paintTrip(doc,strip.querySelector?.(`.${TRIP_CLASS}`)??null,view.cells,t)
const batches=section==='UNSOLD'||section==='AVAILABLE'
const buttons=Array.from(header.querySelectorAll?.('.fx-transfer-btn')??[])
const count=bulkKind==='list'?summary.list:summary.relist
const bulk=paintButton(buttons[0],batches&&count>0,
t(bulkKind==='list'?'transfers.btn.listAll':'transfers.btn.relistAll',{count}),
armedKind===bulkKind,BTN_CLASS)
promise(buttons[0],count)
paintGear(buttons[1],bulk||ask!==null,t)
feedGear(section,ask,deps?.onAsk??null)
paintButton(buttons[2],batches&&summary.club>0,t('transfers.btn.club',{count:summary.club}),armedKind==='club',BTN_CLASS)
promise(buttons[2],summary.club)
return true}
function paintChips(doc,box,chips,t){if(!box)return false
const list=Array.isArray(chips)?chips:[]
const shape=list.map((one)=>one.id).join(',')
if(box.dataset&&box.dataset.futChips!==shape){for(const old of Array.from(box.children??[]))old.remove?.()
for(let made=0;made<list.length;made+=1)box.appendChild(el(doc,'span',{class:'fx-desk-chip'}))
box.dataset.futChips=shape}
const nodes=Array.from(box.children??[])
list.forEach((one,at)=>{const node=nodes[at]
if(!node)return
setClass(node,`fx-desk-chip ${one.tone}`)
setText(node,t(one.key,one.params))})
return true}
function paintTrip(doc,box,cells,t){if(!box)return false
const list=Array.isArray(cells)?cells:[]
let nodes=Array.from(box.children??[])
if(nodes.length!==list.length){for(const one of nodes)one.remove?.()
nodes=list.map(()=>{const cell=el(doc,'span',{class:MONEY_CELL_CLASS},
[el(doc,'span',{class:'fx-money-key'}),el(doc,'span',{class:'fx-money-value'})])
box.appendChild(cell)
return cell})}
list.forEach((one,at)=>{const cell=nodes[at]
if(!cell)return
setText(cell.children?.[0],t(one.key))
setClass(cell.children?.[1],`fx-money-value ${one.tone}${one.tone==='fx-coins'?' currency-coins':''}`)
paintValue(doc,cell.children?.[1],one.text,one.chip??null,t)})
return true}
function paintGear(node,shown,t){if(!node)return false
setClass(node,shown?BTN_CLASS+' '+GEAR_CLASS:BTN_CLASS+' '+GEAR_CLASS+' fx-hidden')
if(!shown)return false
setText(node,GEAR_GLYPH)
const title=t('transfers.gear.open')
if(node.getAttribute?.('title')!==title){node.setAttribute?.('title',title)
node.setAttribute?.('aria-label',title)}
return true}
function placeTitle(header,strip){let title=null
try{title=header?.querySelector?.(TITLE_SELECTOR)??null}catch{title=null}
if(!title)return false
const kids=Array.from(strip.children??[])
if(kids.indexOf(title)===1)return false
const mark=kids[0]??null
if(mark)strip.insertBefore(title,mark.nextSibling??null)
else strip.insertBefore(title,strip.firstChild??null)
return true}
function returnTitle(header){let title=null
try{title=header?.querySelector?.(TITLE_SELECTOR)??null}catch{title=null}
if(!title)return false
if(title.parentNode===header&&header.firstChild===title)return false
header.insertBefore(title,header.firstChild??null)
return true}
function placeButtons(doc,header,strip,deps,bulkKind){let ours=Array.from(header.querySelectorAll?.(`.${BTN_CLASS}`)??[])
if(ours.length!==3||ours[0]?.dataset?.futBulkKind!==bulkKind){for(const one of ours)one.remove?.()
const bulkBtn=el(doc,'button',{class:BTN_CLASS,attrs:{type:'button'},dataset:{futBulkKind:bulkKind}})
const clubBtn=el(doc,'button',{class:BTN_CLASS,attrs:{type:'button'}})
bulkBtn.addEventListener?.('click',()=>deps.press(bulkKind,promisedOf(bulkBtn)))
clubBtn.addEventListener?.('click',()=>deps.press('club',promisedOf(clubBtn)))
ours=[bulkBtn,el(doc,'button',{class:BTN_CLASS+' '+GEAR_CLASS,attrs:{type:'button'},on:{click:()=>deps.gear?.()}}),clubBtn]}
const kids=Array.from(header.children??[])
const anchor=kids.find((one)=>one!==strip&&!ours.includes(one)
&&String(one.tagName??'').toLowerCase()==='button')??null
const at=anchor?kids.indexOf(anchor):kids.length
const want=at-ours.length
const settled=want>=0&&ours.every((one,step)=>kids[want+step]===one)
if(settled)return false
for(const one of ours){if(anchor)header.insertBefore(one,anchor)
else header.appendChild(one)}
return true}
function ourStrip(header){for(const one of Array.from(header?.children??[])){if(String(one.className??'').includes(HEAD_CLASS))return one}
return null}
function placeStrip(header,strip){if(strip.parentNode===header&&header.firstChild===strip)return false
header.insertBefore(strip,header.firstChild??null)
return true}
function promise(node,count){if(!node?.dataset)return false
const said=String(Number.isFinite(count)?Math.trunc(count):0)
if(node.dataset.futBulkCount===said)return false
node.dataset.futBulkCount=said
return true}
function promisedOf(node){const value=Number(node?.dataset?.futBulkCount)
return Number.isSafeInteger(value)&&value>=0?value:null}
function paintButton(node,shown,text,armed,base){if(!node)return false
setClass(node,`${base}${shown?'':' fx-hidden'}${shown&&armed?' fx-armed':''}`)
if(shown)setText(node,text)
return shown}
const BAR_CELLS=Object.freeze([
Object.freeze({id:'slots',key:'transfers.money.slots',hint:'transfers.money.slotsHint'}),
Object.freeze({id:'soldNet',key:'transfers.money.soldNet',hint:'transfers.money.soldNetHint'})])
export const ROW_KEYS=Object.freeze({start:'transfers.row.start',buy:'transfers.row.buy',
bid:'transfers.row.bid',relist:'transfers.row.relist',
bought:'transfers.row.bought',net:'transfers.verdict.net',
profit:'transfers.verdict.profit'})
const CHIP_KEYS=Object.freeze({cut:'transfers.verdict.cut',dead:'transfers.verdict.dead',
none:'transfers.verdict.none',market:'transfers.chip.market',
quicksell:'transfers.chip.quicksellBetter'})
const CHIP_TONES=Object.freeze({cut:'fx-cut',dead:'fx-dead',none:'fx-none',market:'fx-ok',
quicksell:'fx-ask'})
const askHands=new WeakMap()
function ourBar(root){for(const one of Array.from(root?.children??[])){if(String(one.className??'').includes(BAR_CLASS))return one}
return null}
function ownBar(doc,root){const bar=ourBar(root)??el(doc,'div',{class:BAR_CLASS},[logoLink(doc)])
if(bar.parentNode!==root||root.firstChild!==bar){if(root.firstChild)root.insertBefore(bar,root.firstChild)
else root.appendChild(bar)}
return bar}
function placeCells(doc,bar,shared){let cells=Array.from(bar.querySelectorAll?.(`.${MONEY_CELL_CLASS}`)??[])
const anchor=shared?(bar.querySelector?.(VIEW_TOGGLE_SELECTOR)??bar.querySelector?.(PIN_SELECTOR)??null):null
const put=(list)=>{for(const one of list){if(anchor)bar.insertBefore(one,anchor)
else bar.appendChild(one)}}
if(cells.length!==BAR_CELLS.length){for(const one of cells)one.remove?.()
cells=BAR_CELLS.map((one)=>el(doc,'div',{class:one.wide===true?'fx-money-cell fx-money-wide':'fx-money-cell'},
[el(doc,'span',{class:'fx-money-key'}),el(doc,'span',{class:'fx-money-value'})]))
put(cells)
return cells}
const kids=Array.from(bar.children??[])
const at=anchor?kids.indexOf(anchor):kids.length
const want=at-cells.length
const settled=want>=0&&cells.every((one,step)=>kids[want+step]===one)
if(!settled)put(cells)
return cells}
function paintBar(doc,root,view,t,win){const shared=root.querySelector?.(CARD_BAR_SELECTOR)??null
const bar=shared??ownBar(doc,root)
if(shared){const own=ourBar(root)
if(own)own.remove?.()}
placeCells(doc,bar,shared!==null)
const cells=Array.from(bar.querySelectorAll?.('.fx-money-cell')??[])
cells.forEach((cell,at)=>{const one=BAR_CELLS[at]
if(one===undefined)return
const said=view[one.id]
setText(cell.children?.[0],t(one.key))
const hint=t(one.hint)
if(cell.setAttribute&&cell.getAttribute?.('title')!==hint)cell.setAttribute('title',hint)
setClass(cell.children?.[1],`fx-money-value ${said.tone}${said.tone==='fx-coins'?' currency-coins':''}`)
paintValue(doc,cell.children?.[1],said.text,said.chip??null,t)})
return bar}
function paintValue(doc,value,text,chip,t,onAsk=null){if(!value)return false
let num=value.querySelector?.('.fx-money-num')??null
if(!num){value.textContent=''
num=el(doc,'span',{class:'fx-money-num'})
value.appendChild(num)}
setText(num,text)
let badge=value.querySelector?.('.fx-desk-chip')??null
if(chip===null||chip===undefined){if(badge){badge.remove?.()
return true}
return false}
if(!badge){badge=el(doc,'span',{class:'fx-desk-chip'},[],)
const fire=(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
const run=askHands.get(event?.currentTarget??badge)
if(typeof run==='function'){try{run()}catch{/* рука сама говорит словом */}}}
badge.addEventListener?.('click',fire)
badge.addEventListener?.('keydown',(event)=>{const key=String(event?.key??'')
if(key==='Enter'||key===' '||key==='Spacebar')fire(event)})
value.appendChild(badge)}
if(chip.action&&typeof onAsk==='function')askHands.set(badge,onAsk)
else askHands.delete(badge)
setClass(badge,`fx-desk-chip ${chip.tone}`)
setText(badge,t(chip.key,chip.params))
const role=chip.action?'button':null
if(badge.dataset&&badge.dataset.futAsk!==(chip.action??''))badge.dataset.futAsk=chip.action??''
if(badge.setAttribute){if(role&&badge.getAttribute('role')!==role){badge.setAttribute('role',role)
badge.setAttribute('tabindex','0')}
if(!role&&badge.getAttribute('role')==='button'){badge.removeAttribute?.('role')
badge.removeAttribute?.('tabindex')}}
return true}
export function barView(boxes,room,win,t=(key)=>key,opts=null){const active=boxes.ACTIVE
const sold=boxes.SOLD
const unsold=boxes.UNSOLD
const available=boxes.AVAILABLE
const free=room===null?null:Math.max(0,room.size-room.used)
const market=unsold.market+available.market+active.listed
const net=unsold.take+available.take+active.take
const quick=unsold.quick+available.quick+active.quick
const valued=unsold.valued+available.valued+active.valued
const inHand=unsold.count+available.count+active.count
const breakdown=opts?.slotsBreakdown!==false
return{slots:{text:breakdown
?t('transfers.money.slotsValue',
{used:room===null?'—':room.used,size:room===null?'—':room.size,
sold:sold.count,active:active.count,unsold:unsold.count,available:available.count})
:t('transfers.money.slotsShort',
{used:room===null?'—':room.used,size:room===null?'—':room.size}),
tone:free!==null&&free<=10?'fx-tight':'fx-mine'},
market:{text:coinsText(win,market),tone:'',
chip:askChip({count:inHand,valued},null)},
net:{text:coinsText(win,net),tone:'fx-coins'},
quick:{text:coinsText(win,quick),tone:'fx-quiet'},
soldNet:{text:coinsText(win,sold.net),tone:'fx-coins'}}}
function profitCell(box,win){const key='transfers.cell.profit'
if(box.costly===0)return{key,text:'–',tone:'fx-none'}
const text=signedText(win,box.profit)
const tone=box.profit<0?'fx-minus':'fx-plus'
return{key,text:box.costly<box.count?text+' · '+box.costly+'/'+box.count:text,tone}}
function priceFor(item,market){let limits=null
try{limits=item?.getPriceLimits?.()??null}catch{limits=null}
return relistPriceOf(relistPricing,market,limits)}
export function readSection(box){const rows=readRows(box)
let seen=rows.length
try{seen=box?.querySelectorAll?.(TRANSFER_ROW_SELECTOR)?.length??rows.length}catch{seen=rows.length}
return{rows,seen,unread:Math.max(0,seen-rows.length)}}
function readRows(box){const out=[]
for(const row of Array.from(box?.querySelectorAll?.(TRANSFER_ROW_SELECTOR)??[])){const item=itemForEvidenceRow(row)
if(!item)continue
const money=lotMoney(item,priceBadgePeek(item?.definitionId??item?.defId),boughtOf(item))
if(money===null)continue
const price=money.market!==null&&(money.section==='UNSOLD'||money.section==='AVAILABLE')?priceFor(item,money.market):null
out.push({row,item,id:item?.id??null,money,price,priced:price!==null,
quick:wholeCoins(item?.discardValue),
movable:itemFact(item,'isMovable')===true,
tradeable:itemFact(item,'isTradeable')===true,
frozen:frozenOf(item)})}
return out}
function frozenOf(item){try{return cardFrozenNow(cardFrozenKey(item))===true}catch{return false}}
function sayInto(header,text){setText(header?.querySelector?.('.fx-transfer-say')??null,text)}
export function paintTransferMoney(deps,root){const{doc,t,win,sleep,dayBudget=null,measureMarket=null}=deps
if(root.dataset&&root.dataset[MONEY_MARK]!=='1')root.dataset[MONEY_MARK]='1'
if(root.dataset&&root.dataset[BUILD_MARK]!==TRANSFER_BUILD)root.dataset[BUILD_MARK]=TRANSFER_BUILD
const repaint=()=>{try{paintTransferMoney(deps,root)}catch{}}
const all=[]
for(const box of Array.from(root.querySelectorAll?.(SECTION_SELECTOR)??[])){const view=readSection(box)
const rows=view.rows
const unread=view.unread
all.push(...rows)
const section=rows.length===0?null:rows[0].money.section
const summary=summarizeLots(rows)[section??'SOLD']
for(const one of rows)paintDesk(doc,one,t,win)
const header=box.querySelector?.(HEADER_SELECTOR)??null
paintHead(doc,header,section,summary,t,win,
{press:(kind,promised)=>{
const hand=()=>pressBatch(kind,{win,t,sleep,dayBudget,promised,read:()=>readSection(box),
listRows:()=>all.map((one)=>one.item),
say:(text)=>{if(!sayRun(text))sayInto(header,text)},
detail:(text)=>{sayRunDetail(text)},
confirm:(spec)=>{openRunWindow(doc,t,{
title:t('transfers.run.windowTitle'),
...spec,
text:spec.text,
yes:t(BULK_YES_KEYS[kind]??BULK_YES_KEYS.club,{count:spec.count}),
onYes:()=>{runWindowWorking(doc,t)
const out=hand()
repaint()
settleRunWindow(out,repaint,doc,t)},
onClose:()=>{forgetBatch()
repaint()}})}})
const out=hand()
repaint()
return out},
gear:()=>openGear(doc,t,repaint,section),
rows:()=>readSection(box).rows,
ask:askViewOf(section,typeof measureMarket==='function'),
onAsk:()=>{runAsk(section,{door:measureMarket,rows:()=>readSection(box).rows,win,t,sleep,
say:(text)=>{if(!sayGear(text))sayInto(header,text)},repaint}).catch(()=>{/* заход сам говорит словом */})}},unread)}
paintBar(doc,root,barView(summarizeLots(all),roomOf(win),win,t,{slotsBreakdown:false}),t,win)
return all.length}
function roomOf(win){try{return pileRoom(win,'TRANSFER')}catch{return null}}
export function clearTransferMoney(doc){let gone=0
closeGear()
closeRunWindow()
for(const one of Array.from(doc?.querySelectorAll?.(GEAR_WINDOW_SELECTOR)??[])){one.remove?.()
gone+=1}
for(const one of Array.from(doc?.querySelectorAll?.(RUN_WINDOW_SELECTOR)??[])){one.remove?.()
gone+=1}
for(const root of Array.from(doc?.querySelectorAll?.(MONEY_SELECTOR)??[])){const bar=ourBar(root)
if(bar){bar.remove?.()
gone+=1}
for(const cell of Array.from(root.querySelectorAll?.('.fx-money-cell')??[])){cell.remove?.()
gone+=1}
for(const desk of Array.from(root.querySelectorAll?.(`.${DESK_CLASS}`)??[])){desk.remove?.()
gone+=1}
for(const strip of Array.from(root.querySelectorAll?.(`.${HEAD_CLASS}`)??[])){
const header=strip.parentNode
if(header)returnTitle(header)
strip.remove?.()
gone+=1}
for(const btn of Array.from(root.querySelectorAll?.(`.${BTN_CLASS}`)??[])){btn.remove?.()
gone+=1}
if(root.dataset&&root.dataset[MONEY_MARK]!==undefined)delete root.dataset[MONEY_MARK]
if(root.dataset&&root.dataset[BUILD_MARK]!==undefined)delete root.dataset[BUILD_MARK]}
return gone}
function sleeperOf(win){return(ms)=>new Promise((done)=>{const later=typeof win?.setTimeout==='function'?win.setTimeout.bind(win)
:(typeof setTimeout==='function'?setTimeout:null)
if(later)later(done,ms)
else done()})}
let lastMoneyDeps=null
let repainting=false
export function repaintTransferMoney(){if(lastMoneyDeps===null||repainting)return false
repainting=true
try{enhanceTransferMoney(lastMoneyDeps)}
finally{repainting=false}
return true}
export function enhanceTransferMoney(deps){const{doc,t,isActive,win,sleep,relistPricing:port=null,dayBudget=null,measureMarket=null}=deps??{}
if(!doc)return{ok:false,reason:'no-doc',roots:0}
lastMoneyDeps=deps
useRelistPort(port)
armClearSold({doc,win:win??doc.defaultView??null,t,isActive,
sleep:typeof sleep==='function'?sleep:sleeperOf(win??doc.defaultView??null),dayBudget})
const roots=Array.from(doc.querySelectorAll?.(TRANSFER_LIST_SELECTOR)??[])
if(isActive(TRANSFER_LIST_FEATURE)!==true){const gone=clearTransferMoney(doc)
return{ok:true,reason:'off',roots:0,cleared:gone}}
ensureStylesheet(doc,MONEY_STYLESHEET,MONEY_LINK_ID)
if(roots.length===0)return{ok:true,reason:'no-screen',roots:0}
ensureTheme(doc)
ensureControls(doc)
const view=win??doc.defaultView??null
const wait=typeof sleep==='function'?sleep:sleeperOf(view)
let lots=0
for(const root of roots)lots+=paintTransferMoney({doc,t,win:view,sleep:wait,dayBudget,measureMarket},root)
return{ok:true,reason:null,roots:roots.length,lots}}
