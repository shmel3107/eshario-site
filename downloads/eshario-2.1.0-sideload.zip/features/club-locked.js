import{el,ensureStylesheet} from '../ui/dom.js'
import{modalBox,modalHead,ensureWindow} from '../ui/window.js'
import{STORAGE_LOADED,STORAGE_PENDING} from '../core/storage-provider.js'
import{cardLocksNow} from './card-locks.js'
import{cardLabel} from './club-actions.js'
import{createItemCell} from '../adapter/item-cell.js'
import{createPageGrid,PAGE_SIZE} from './card-views.js'
import{ensureSidebarStyles} from '../ui/dom.js'
const LOCKED_STYLESHEET=new URL('../ui/club-locked.css',import.meta.url).href
const LOCKED_LINK_ID='fut-companion-club-locked'
export const LOCKED_WINDOW_SELECTOR='[data-fut-lock-window]'
export const LOCKED_PAGE_SIZE=20
export const LOCKED_PAGE_MIN=10
export const LOCKED_PAGE_MAX=30
const PLAN_CHECKS=6
const FRAME_WAIT_MS=250
const LOCK_HEAD_PX=32
const LOCK_WARN_PX=56
export function lockedPageSize(room,row){const space=Number(room)
const one=Number(row)
if(!Number.isFinite(space)||!Number.isFinite(one)||space<=0||one<=0)return LOCKED_PAGE_SIZE
return Math.min(LOCKED_PAGE_MAX,Math.max(LOCKED_PAGE_MIN,Math.floor(space/one)))}
export function sanitizePageSize(value){const size=Math.trunc(Number(value))
return Number.isSafeInteger(size)&&size>=LOCKED_PAGE_MIN&&size<=LOCKED_PAGE_MAX?size:LOCKED_PAGE_SIZE}
export function lockFurniture(category,head,warn){const one=Number(head)>0?Number(head):LOCK_HEAD_PX
const two=Number(warn)>0?Number(warn):LOCK_WARN_PX
return(category===LOCK_ALL?2:1)*one+(category===LOCK_IN_CLUB?0:1)*two}
export const LOCK_ALL='all'
export const LOCKED_BUILD='W21B-2'
export const LOCK_IN_CLUB='club'
export const LOCK_GONE='gone'
export const LOCK_CATEGORIES=Object.freeze([LOCK_ALL,LOCK_IN_CLUB,LOCK_GONE])
export function sanitizeLockCategory(value){return LOCK_CATEGORIES.includes(value)?value:LOCK_ALL}
export const SORT_ADDED='added'
export const SORT_RATING_UP='ratingUp'
export const SORT_RATING_DOWN='ratingDown'
export const LOCK_SORTS=Object.freeze([SORT_RATING_DOWN,SORT_RATING_UP,SORT_ADDED])
export const SORT_DEFAULT=SORT_RATING_DOWN
export function sanitizeLockSort(value){return LOCK_SORTS.includes(value)?value:SORT_DEFAULT}
export function sortLockRows(rows,sort){const list=Array.isArray(rows)?rows.slice():[]
const order=sanitizeLockSort(sort)
if(order===SORT_ADDED)return list
const rank=(one)=>{const value=Number(one?.rating)
return Number.isSafeInteger(value)&&value>0?value:null}
const at=new Map(list.map((one,index)=>[one,index]))
list.sort((left,right)=>{const a=rank(left)
const b=rank(right)
if(a===null&&b===null)return at.get(left)-at.get(right)
if(a===null)return 1
if(b===null)return -1
if(a!==b)return order===SORT_RATING_UP?a-b:b-a
return at.get(left)-at.get(right)})
return list}
export function openingCategory(counts){const club=Number(counts?.club)
const gone=Number(counts?.gone)
return club>0||!(gone>0)?LOCK_IN_CLUB:LOCK_ALL}
function ratingOf(source){const value=Number(source?.rating)
return Number.isSafeInteger(value)&&value>0?value:null}
export function lockRowOutcome(id,row,item,recreated=false){const seenByMemory=item!==null&&item!==undefined
const seenByMirror=row!==null&&row!==undefined
const label=seenByMemory?cardLabel(item,String(id)):String(id)
const source=seenByMemory?(seenByMirror?'both':'memory'):(seenByMirror?'mirror':'none')
return{id,inClub:seenByMemory||seenByMirror,
recreated:recreated===true,
rating:(seenByMemory?ratingOf(item):null)??(seenByMirror?ratingOf(row):null),
name:label===String(id)?null:label,source}}
const CONFIRM_STEPS=Object.freeze([0,1,2])
const SOURCE_HINTS=Object.freeze({both:'clubLocked.from.both',memory:'clubLocked.from.memory',
mirror:'clubLocked.from.mirror',none:'clubLocked.from.none'})
export function lockBlockOf(status){if(status===STORAGE_LOADED)return null
return status===STORAGE_PENDING?'loading':'unavailable'}
export function lockedWindowModel(facts,state={}){const blocked=lockBlockOf(facts?.status)
const all=blocked!==null||!Array.isArray(facts?.rows)?[]:facts.rows.filter((one)=>one&&typeof one==='object')
const club=all.filter((one)=>one.inClub===true)
const gone=all.filter((one)=>one.inClub!==true)
const category=sanitizeLockCategory(state?.category)
const list=sortLockRows(category===LOCK_IN_CLUB?club:(category===LOCK_GONE?gone:[...club,...gone]),state?.sort)
const size=sanitizePageSize(state?.size)
const pages=Math.max(1,Math.ceil(list.length/size))
const asked=Math.trunc(Number(state?.page))
const page=Math.min(Math.max(1,Number.isSafeInteger(asked)&&asked>0?asked:1),pages)
const from=(page-1)*size
const rows=list.slice(from,from+size)
return{blocked,ready:blocked===null,category,sort:sanitizeLockSort(state?.sort),page,pages,rows,size,
counts:{all:all.length,club:club.length,gone:gone.length},
first:rows.length===0?0:from+1,last:from+rows.length,total:list.length,
empty:all.length===0,
emptyHere:all.length>0&&list.length===0,
mass:{club:(category===LOCK_ALL||category===LOCK_IN_CLUB)&&club.length>0,
gone:(category===LOCK_ALL||category===LOCK_GONE)&&gone.length>0},
asking:state?.asking===LOCK_IN_CLUB||state?.asking===LOCK_GONE?state.asking:null,
confirming:CONFIRM_STEPS.includes(state?.confirming)?state.confirming:0,
refused:state?.refused===true,
changed:state?.changed===true}}
export function createLockedWindow(deps={}){const{doc}=deps
const win=doc?.defaultView??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const num=typeof deps.formatNumber==='function'?deps.formatNumber:(value)=>String(value)
const readFacts=typeof deps.facts==='function'?deps.facts:()=>({rows:[],status:''})
const setLock=typeof deps.setLock==='function'?deps.setLock:null
const itemById=typeof deps.itemById==='function'?deps.itemById:null
const readStoredSort=typeof deps.sort==='function'?deps.sort:null
const writeSort=typeof deps.setSort==='function'?deps.setSort:null
const readSort=()=>{if(readStoredSort===null)return SORT_DEFAULT
try{return sanitizeLockSort(readStoredSort())}catch(err){onError(err)
return SORT_DEFAULT}}
let host=null
let shown=null
const category=LOCK_IN_CLUB
let sort=SORT_DEFAULT
let page=1
let picked=false
let asking=null
let confirming=0
let consent=null
let changed=false
let refused=false
let size=LOCKED_PAGE_SIZE
let fits={measured:false,size:LOCKED_PAGE_SIZE,limit:0,chrome:0,room:0,row:0,
head:LOCK_HEAD_PX,warn:LOCK_WARN_PX}
const pages=itemById===null?null:createPageGrid({doc,onError})
let cells=[]
let tiles=0
let broken=0
let faceless=0
let gridOff=null
let checks=0
let opens=0
let paints=0
let unlocks=0
let refusals=0
let measures=0
let resizes=0
function pxOf(value){const found=/^(-?[\d.]+)px$/.exec(String(value??'').trim())
return found===null?0:Number(found[1])}
function styleOf(node){try{return win?.getComputedStyle?.(node)??null}catch(err){onError(err)
return null}}
function blockOf(node){if(!node)return 0
const height=Number(node.offsetHeight)||0
if(height<=0)return 0
const style=styleOf(node)
return height+pxOf(style?.marginTop)+pxOf(style?.marginBottom)}
function measure(){if(host===null)return null
const box=host.querySelector?.('.fx-lock-box')??null
const list=box?.querySelector?.('.fx-lock-rows')??null
const row=list?.querySelector?.('.fx-lock-row')??null
if(!box||!list||!row)return null
const style=styleOf(box)
const boxHeight=Number(box.offsetHeight)||0
const rowHeight=Number(row.offsetHeight)||0
const limit=pxOf(style?.maxHeight)+(String(style?.boxSizing??'')==='border-box'?0
:pxOf(style?.paddingTop)+pxOf(style?.paddingBottom)
+pxOf(style?.borderTopWidth)+pxOf(style?.borderBottomWidth))
if(limit<=0||rowHeight<=0||boxHeight<=0)return null
const head=blockOf(list.querySelector?.('.fx-lock-head'))||fits.head
const warn=blockOf(list.querySelector?.('.fx-lock-warn'))||fits.warn
const chrome=Math.max(0,boxHeight-(Number(list.offsetHeight)||0))
const room=limit-chrome-lockFurniture(category,head,warn)
measures+=1
fits={measured:true,size:lockedPageSize(room,rowHeight),limit:Math.round(limit),
chrome:Math.round(chrome),room:Math.round(room),row:Math.round(rowHeight),
head:Math.round(head),warn:Math.round(warn)}
return fits.size}
const facts=()=>{try{const value=readFacts()
return{rows:Array.isArray(value?.rows)?value.rows:[],status:String(value?.status??'')}}catch(err){onError(err)
return{rows:[],status:''}}}
function unlock(id){if(setLock===null)return false
let done=false
try{done=setLock(id,false)===true}catch(err){onError(err)
done=false}
if(done){unlocks+=1
refused=false}else{refusals+=1
refused=true}
paint()
return done}
function nameOf(row){return row.name===null||row.name===undefined
?t('clubLocked.noName',{id:String(row.id)}):row.name}
function lockRow(row){const gone=row.inClub!==true
const node=el(doc,'div',{class:gone?'fx-lock-row fx-lock-gone':'fx-lock-row',
attrs:{title:t(SOURCE_HINTS[row.source]??'clubLocked.from.none')},
dataset:{futLockRow:String(row.id),futLockSource:String(row.source)}},[
el(doc,'span',{class:'fx-lock-rating',text:row.rating===null?'–':num(row.rating)}),
el(doc,'span',{class:'fx-lock-name',text:nameOf(row)})])
if(row.recreated===true)node.appendChild(el(doc,'span',{class:'fx-lock-tag',
attrs:{title:t('clubLocked.recreatedHint')},
dataset:{futLockRecreated:String(row.id)},text:t('clubLocked.recreated')}))
if(setLock!==null){node.appendChild(el(doc,'button',{class:'fx-action fx-lock-off',
attrs:{type:'button',title:t(gone?'clubLocked.dropHint':'clubLocked.unlockHint')},
dataset:gone?{futLockDrop:String(row.id)}:{futLockOff:String(row.id)},
text:t(gone?'clubLocked.drop':'clubLocked.unlock'),
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
unlock(row.id)}}}))}
return node}
function dropCells(){if(cells.length===0)return 0
const had=cells.length
for(const one of cells){try{one.dispose()}catch(err){onError(err)}}
cells=[]
return had}
function markCards(box,on){if(!box?.dataset)return false
if(on){if(box.dataset.futLockCards==='1')return false
box.dataset.futLockCards='1'
return true}
if(box.dataset.futLockCards===undefined)return false
delete box.dataset.futLockCards
return true}
function tileLock(row){const label=t('clubLocked.unlockHint')
return el(doc,'button',{class:'fut-card-lock fx-lock-tile-off',
attrs:{type:'button',title:label,'aria-label':label},
dataset:{futLockOff:String(row.id),futCardLockOn:'1'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
unlock(row.id)}}})}
function lockTile(row){if(itemById===null)return null
let item=null
try{item=itemById(row.id)??null}catch(err){onError(err)
item=null}
if(item===null||item===undefined){faceless+=1
return null}
const made=createItemCell(win,item)
if(made===null){faceless+=1
return null}
cells.push(made)
tiles+=1
if(!made.painted)broken+=1
const node=made.root
try{node.className=`${String(node.className??'').trim()} fx-lock-tile`.trim()}catch(err){onError(err)}
if(node.dataset){node.dataset.futLockRow=String(row.id)
node.dataset.futLockSource=String(row.source)}
try{node.setAttribute?.('title',t(SOURCE_HINTS[row.source]??'clubLocked.from.none'))}catch(err){onError(err)}
if(row.recreated===true)node.appendChild(el(doc,'span',{class:'fx-lock-tag',
attrs:{title:t('clubLocked.recreatedHint')},
dataset:{futLockRecreated:String(row.id)},text:t('clubLocked.recreated')}))
if(setLock!==null)node.appendChild(tileLock(row))
return node}
function planFault(){if(pages===null||host===null)return null
let laid=null
try{laid=pages.state().plan}catch(err){onError(err)
return null}
if(laid===null||Number(laid.statsWidth)>0)return null
let block=null
try{block=host.querySelector?.('.fx-lock-tile .player-stats-data-component')??null}catch{block=null}
if(block===null)return null
let display=null
try{display=win?.getComputedStyle?.(block)?.display??null}catch{display=null}
if(display==='none')return null
return{why:'stats-zero',statsWidth:Number(laid.statsWidth)||0,face:Number(laid.face)||0}}
function checkPlan(){if(pages===null||host===null||gridOff!==null)return false
checks+=1
let ready=false
try{ready=Boolean(pages.state().plan)}catch(err){onError(err)}
if(!ready){if(checks>=PLAN_CHECKS)return false
laterFrame(checkPlan)
return false}
pinNativeFace()
const fault=planFault()
if(fault===null)return false
gridOff=fault
shown=null
settle()
return true}
function pinNativeFace(){if(pages===null||host===null)return false
let base=null
try{base=pages.state().base}catch(err){onError(err)
return false}
const native=Number(base?.faceNative)
const ratio=Number(base?.ratio)
if(!(native>0)||!(ratio>0))return false
const grid=host.querySelector?.('.fx-lock-grid')??null
if(grid===null)return false
try{grid.style?.setProperty?.('--fut-lock-face',`${Math.round(native)}px`)
grid.style?.setProperty?.('--fut-lock-face-h',`${Math.round(native*ratio)}px`)}catch(err){onError(err)
return false}
let rows=0
let tile=0
try{rows=Number(pages.state().plan?.rows)||0
tile=Number(grid.querySelector?.('li.listFUTItem')?.getBoundingClientRect?.().height)||0}catch(err){onError(err)}
const gapY=Number(base?.gapY)||0
if(rows>0&&tile>0){try{grid.style?.setProperty?.('--fut-lock-grid-h',
`${Math.ceil(rows*tile+(rows-1)*gapY)}px`)}catch(err){onError(err)}}
return true}
function laterFrame(run){let done=false
const once=()=>{if(done)return
done=true
try{run()}catch(err){onError(err)}}
try{if(typeof win?.requestAnimationFrame==='function')win.requestAnimationFrame(once)}catch(err){onError(err)}
try{win?.setTimeout?.(once,FRAME_WAIT_MS)}catch(err){onError(err)}}
function mountGrid(list){if(pages===null||!list)return false
ensureSidebarStyles(doc)
pages.ensure()
pages.apply([list])
checks=0
laterFrame(checkPlan)
return true}
const SORT_WORDS=Object.freeze({[SORT_ADDED]:'clubLocked.sortAdded',
[SORT_RATING_DOWN]:'clubLocked.sortRatingDown',[SORT_RATING_UP]:'clubLocked.sortRatingUp'})
function sortField(model){const select=el(doc,'select',{class:'fx-lock-cat',
dataset:{futLockSort:'1'},attrs:{'aria-label':t('clubLocked.sort')}})
for(const value of LOCK_SORTS){const option=el(doc,'option',{attrs:{value},text:t(SORT_WORDS[value])})
if(value===model.sort)option.selected=true
select.appendChild(option)}
select.addEventListener('change',()=>{sort=sanitizeLockSort(String(select.value??''))
if(writeSort!==null){try{writeSort(sort)}catch(err){onError(err)}}
page=1
paint()})
return el(doc,'label',{class:'fx-lock-cat-box'},[
el(doc,'span',{class:'fx-lock-cat-label',text:t('clubLocked.sort')}),select])}
function pager(model){if(model.total===0)return null
const step=(next)=>{page=Math.min(Math.max(1,next),model.pages)
paint()}
const ARROW=Object.freeze({prev:'‹',next:'›'})
const button=(key,label,to,enabled)=>el(doc,'button',{class:'fx-action fx-action-square fx-lock-page',
attrs:enabled?{type:'button',title:label,'aria-label':label}
:{type:'button',disabled:'disabled',title:label,'aria-label':label},
dataset:{futLockPage:key},text:ARROW[key],
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
if(enabled)step(to)}}})
return el(doc,'div',{class:'fx-lock-pager'},[
button('prev',t('clubLocked.prev'),model.page-1,model.page>1),
el(doc,'span',{class:'fx-lock-count',
text:t('clubLocked.page',{first:num(model.first),last:num(model.last),total:num(model.total)})}),
button('next',t('clubLocked.next'),model.page+1,model.page<model.pages)])}
const MASS=Object.freeze({
[LOCK_IN_CLUB]:{calm:'clubLocked.unlockAll',ask:'clubLocked.unlockAllSure',
final:'clubLocked.unlockAllFinal',warn:'clubLocked.unlockAllWarn'},
[LOCK_GONE]:{calm:'clubLocked.dropAll',ask:'clubLocked.dropAllSure',
final:'clubLocked.dropAllFinal',warn:'clubLocked.dropAllWarn'}})
function massVisible(model,group){return group===LOCK_IN_CLUB?model.mass.club===true:model.mass.gone===true}
function groupIds(seen,group){const wanted=group===LOCK_IN_CLUB
const out=[]
for(const one of Array.isArray(seen?.rows)?seen.rows:[]){if(!one||(one.inClub===true)!==wanted)continue
const id=Number(one.id)
if(Number.isSafeInteger(id)&&!out.includes(id))out.push(id)}
return out}
function groupPrint(ids){return [...ids].sort((a,b)=>a-b).join(',')}
function livePrint(){const ids=cardLocksNow()
return ids===null?null:groupPrint(ids)}
function consentHolds(seen){if(consent===null)return true
if(livePrint()!==consent.live)return false
return groupPrint(groupIds(seen,consent.group))===consent.print}
function dropConsent(){asking=null
confirming=0
consent=null
changed=true}
function massButton(model,group){const count=group===LOCK_IN_CLUB?model.counts.club:model.counts.gone
if(setLock===null||count===0||!model.ready||!massVisible(model,group))return null
const step=asking===group?confirming:0
const words=MASS[group]
const key=step===0?words.calm:(step===1?words.ask:words.final)
return el(doc,'button',{class:step===0?'fx-action fx-lock-all':'fx-action fx-lock-all fx-lock-asking',
attrs:{type:'button'},
dataset:{futLockAll:group,futLockStep:step===0?'calm':(step===1?'ask':'final')},
text:t(key,{count:num(count)}),
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
const seen=facts()
if(asking!==group){asking=group
confirming=1
changed=false
consent={group,ids:groupIds(seen,group),print:groupPrint(groupIds(seen,group)),live:livePrint()}
paint()
return}
if(!consentHolds(seen)){dropConsent()
paint()
return}
if(confirming<2){confirming+=1
paint()
return}
const doomed=consent===null?[]:consent.ids
asking=null
confirming=0
consent=null
for(const id of doomed){try{if(setLock(id,false)===true)unlocks+=1
else refusals+=1}catch(err){onError(err)
refusals+=1}}
paint()}}})}
function cancelButton(){if(asking===null)return null
return el(doc,'button',{class:'fx-action fx-lock-cancel',attrs:{type:'button'},
dataset:{futLockCancel:'1'},text:t('clubLocked.cancel'),
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
asking=null
confirming=0
consent=null
changed=false
paint()}}})}
function groupHead(key,count){return el(doc,'div',{class:'fx-lock-head',text:t(key,{count:num(count)})})}
function paint(){if(host===null)return false
const seen=facts()
const cardsMode=pages!==null&&gridOff===null&&category!==LOCK_GONE
&&seen.rows.some((one)=>one&&one.inClub===true)
const fresh=cardsMode?null:measure()
if(fresh!==null)size=fresh
const room=cardsMode?PAGE_SIZE:size
if(asking!==null&&!consentHolds(seen))dropConsent()
let model=lockedWindowModel(seen,{category,sort,page,size:room,asking,confirming,refused,changed})
picked=true
page=model.page
if(asking!==null&&massVisible(model,asking)!==true){asking=null
confirming=0
consent=null
model=lockedWindowModel(seen,{category,sort,page,size:room,asking,confirming,refused,changed})}
const key=JSON.stringify([model.rows.map((one)=>`${one.id}:${one.rating}:${one.name}:${one.source}`),
model.counts,model.category,model.page,model.pages,model.total,model.mass,
cardsMode,
model.blocked,model.asking,model.confirming,model.refused,model.changed,t('clubLocked.title')])
if(shown===key)return false
shown=key
paints+=1
const box=host.querySelector?.('.fx-lock-box')??null
if(!box)return false
dropCells()
while(box.firstChild)box.removeChild(box.firstChild)
markCards(box,pages!==null&&model.counts.club>0)
box.appendChild(modalHead(doc,{title:t('clubLocked.title'),closeLabel:t('common.close'),
tools:[model.ready&&model.total>0?sortField(model):null].filter(Boolean),onClose:close}))
box.appendChild(el(doc,'div',{class:'fx-lock-hint',text:t('clubLocked.hint')}))
if(model.blocked!==null)box.appendChild(el(doc,'div',{class:'fx-lock-blocked',
text:t(model.blocked==='loading'?'clubLocked.loading':'clubLocked.unreadable')}))
else if(model.empty)box.appendChild(el(doc,'div',{class:'fx-lock-empty',text:t('clubLocked.empty')}))
else if(model.emptyHere)box.appendChild(el(doc,'div',{class:'fx-lock-empty',text:t('clubLocked.catEmpty')}))
if(model.ready&&model.total>0){
const rows=el(doc,cardsMode?'ul':'div',{class:cardsMode?'fx-lock-rows fx-lock-grid':'fx-lock-rows'})
const put=(node)=>{if(node===null)return
rows.appendChild(cardsMode?el(doc,'li',{class:'fx-lock-span'},[node]):node)}
const lead=[]
let group=null
let first=true
for(const row of model.rows){const now=row.inClub===true?LOCK_IN_CLUB:LOCK_GONE
if(now!==group){group=now
const head=groupHead(now===LOCK_IN_CLUB?'clubLocked.inClub':'clubLocked.gone',
now===LOCK_IN_CLUB?model.counts.club:model.counts.gone)
const warn=now===LOCK_GONE?el(doc,'div',{class:'fx-lock-warn',text:t('clubLocked.goneHint')}):null
if(cardsMode&&first){lead.push(head)
if(warn!==null)lead.push(warn)}
else{put(head)
put(warn)}}
first=false
const tile=cardsMode&&row.inClub===true?lockTile(row):null
if(tile!==null)rows.appendChild(tile)
else put(lockRow(row))}
for(const one of lead)box.appendChild(one)
box.appendChild(rows)
if(cardsMode)mountGrid(rows)}
if(model.refused)box.appendChild(el(doc,'div',{class:'fx-lock-failed',text:t('clubLocked.failed')}))
if(model.changed)box.appendChild(el(doc,'div',{class:'fx-lock-failed',dataset:{futLockChanged:'1'},text:t('clubLocked.changed')}))
if(model.confirming===2&&model.asking!==null)box.appendChild(el(doc,'div',{class:'fx-lock-final',
text:t(MASS[model.asking].warn,
{count:num(model.asking===LOCK_IN_CLUB?model.counts.club:model.counts.gone)})}))
box.appendChild(el(doc,'div',{class:'fx-lock-buttons'},[
massButton(model,LOCK_IN_CLUB),massButton(model,LOCK_GONE),cancelButton(),
model.ready&&model.total>0?pager(model):null].filter(Boolean)))
return true}
function settle(){if(!paint())return false
paint()
return true}
function onResize(){if(host===null)return
resizes+=1
const grid=host?.querySelector?.('.fx-lock-grid')??null
if(pages!==null&&grid!==null){try{
grid.style?.removeProperty?.('--fut-lock-grid-h')
pages.remeasure([grid])
checks=0
laterFrame(checkPlan)}catch(err){onError(err)}}
settle()}
function close(){let gone=0
dropCells()
if(pages!==null){try{const mine=host?.querySelector?.('.fx-lock-grid')??null
if(mine!==null)pages.unmark(mine)
pages.forget()}catch(err){onError(err)}}
for(const one of Array.from(doc?.querySelectorAll?.(LOCKED_WINDOW_SELECTOR)??[])){one.remove?.()
gone+=1}
try{win?.removeEventListener?.('resize',onResize)}catch(err){onError(err)}
host=null
shown=null
asking=null
confirming=0
consent=null
changed=false
refused=false
gridOff=null
checks=0
return gone}
return{
open(){if(!doc)return false
if(host!==null){settle()
return true}
ensureWindow(doc)
ensureStylesheet(doc,LOCKED_STYLESHEET,LOCKED_LINK_ID)
host=modalBox(doc,{mark:'futLockWindow',overlay:'fx-lock',box:'fx-lock-box',
title:t('clubLocked.title'),closeLabel:t('common.close'),onBack:close},[])
;(doc.body??doc.documentElement)?.appendChild?.(host)
opens+=1
shown=null
sort=readSort()
page=1
picked=false
try{win?.addEventListener?.('resize',onResize)}catch(err){onError(err)}
settle()
return true},
refresh(){return host===null?false:settle()},
relabel(){if(host===null)return false
shown=null
return settle()},
isOpen:()=>host!==null,
close,
state(){const value=facts()
const model=lockedWindowModel(value,{category,sort,page,size,asking,confirming,refused,changed})
return{open:host!==null,status:value.status,blocked:model.blocked,ready:model.ready,
locked:model.counts.club,orphans:model.counts.gone,locks:model.counts.all,
category:model.category,sort:model.sort,page:model.page,pages:model.pages,shownRows:model.rows.length,
picked,
size:model.size,fits,
cards:{can:itemById!==null&&pages!==null,tiles,broken,faceless,live:cells.length,off:gridOff,
plan:(()=>{if(pages===null)return null
try{return pages.state().plan}catch(err){onError(err)
return null}})()},
build:LOCKED_BUILD,
mass:model.mass,asking,confirming,refused,changed,consent:consent===null?null:{group:consent.group,cards:consent.ids.length},canUnlock:setLock!==null,
work:{opens,paints,unlocks,refused:refusals,measures,resizes}}},
dispose(){try{close()}catch(err){onError(err)}}}}
