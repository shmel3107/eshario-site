import{el,ensureStylesheet} from '../ui/dom.js'
import{modalBox,modalButtons,ensureWindow} from '../ui/window.js'
import{HOTKEYS_STYLESHEET,HOTKEYS_LINK_ID,badgeText,targetOf,layerVisible,labelOfNode} from './hotkey-bind.js'
import{LAYERS,layerOf,dangerKindsOf,DANGER_KIND_KEYS,GROUPS,groupOf,FUSED_ROWS} from './hotkeys.js'
const HOTKEYS_FEATURE='hotkeys'
const BADGE_SELECTOR='[data-fut-hotkey-badge]'
const PLACED_SELECTOR='[data-fut-hotkey-placed]'
const GROUP_LABELS=Object.freeze({nav:'hotkeys.group.nav',card:'hotkeys.group.card',unassigned:'hotkeys.group.unassigned',market:'hotkeys.group.market',sbc:'hotkeys.group.sbc',mine:'hotkeys.group.mine'})
const ROW_ORDER=Object.freeze({nav:['prevCard','nextCard','cardLeft','cardRight','pagePrev','pageNext','rowEnter','goBack','goBackEsc','openSbc','showKeys'],card:['findMinBin','lockCard','freezeCard','listForTransfer','sendToTransfer','sendToClub','sendToStorage','discardItem','listAtMin'],unassigned:['sortPack','bulkToClub','bulkToStorage','bulkQuickSell','bulkQuickSellItems','stopPackBulk'],market:['marketSearch','minBuyDown','minBuyUp','maxBuyDown','maxBuyUp','minBidDown','minBidUp','maxBidDown','maxBidUp','buyNow','placeBid','snipeChain','relistAll','repeatSearch'],sbc:['showOnPitch','submitChallenge'],mine:[]})
const rowRank=(group,action)=>{const list=ROW_ORDER[group]
if(!Array.isArray(list))return Number.MAX_SAFE_INTEGER
const at=list.indexOf(action)
return at===-1?Number.MAX_SAFE_INTEGER:at}
const LAYER_LABELS=Object.freeze({global:'hotkeys.layer.global',market:'hotkeys.layer.market',marketAny:'hotkeys.layer.marketAny',transferList:'hotkeys.layer.transferList',targets:'hotkeys.layer.targets',unassigned:'hotkeys.layer.unassigned',club:'hotkeys.layer.club',sbc:'hotkeys.layer.sbc',challenge:'hotkeys.layer.challenge',store:'hotkeys.layer.store'})
export function createHotkeyBadges(deps){const{doc,t,isActive=()=>true,bindings,registry,enabled=()=>true,onError=()=>{}}=deps
let overlay=null
const styles=()=>{ensureWindow(doc)
ensureStylesheet(doc,HOTKEYS_STYLESHEET,HOTKEYS_LINK_ID)}
const dropAll=()=>{for(const node of Array.from(doc?.querySelectorAll?.(PLACED_SELECTOR)??[]))node.remove?.()}
function refresh(){if(!isActive('hotkeys')||enabled()!==true){dropAll()
return{badges:0,off:true}}
styles()
const map=bindings()
const table=registry()
const seen=new Set()
let placed=0
for(const[action,combo]of Object.entries(map)){if(combo==='')continue
const meta=table[action]
if(!meta||meta.reserved)continue
if(!layerVisible(doc,layerOf(meta)))continue
let node=null
try{node=targetOf(doc,meta)}catch(err){onError(err)
node=null}
if(!node||seen.has(node))continue
seen.add(node)
try{if(place(node,combo,meta,action))placed+=1}catch(err){onError(err)}}
for(const badge of Array.from(doc?.querySelectorAll?.(PLACED_SELECTOR)??[])){if(!seen.has(badge.parentElement)&&!seen.has(badge.__futHost))badge.remove?.()}
return{badges:placed,off:false}}
function place(node,combo,meta,action=''){const text=badgeText(combo)
if(text==='')return false
const existing=node.querySelector?.(PLACED_SELECTOR)??null
const tone=meta.danger===true?'danger':'normal'
const target=labelOfNode(node)
if(existing){if(existing.textContent!==text)existing.textContent=text
if(existing.dataset.futHotkeyBadge!==tone)existing.dataset.futHotkeyBadge=tone
if(existing.dataset.futHotkeyAction!==action)existing.dataset.futHotkeyAction=action
if(existing.dataset.futHotkeyTarget!==target)existing.dataset.futHotkeyTarget=target
existing.__futHost=node
return true}
const badge=el(doc,'span',{class:'fx-hk-badge',text,dataset:{futHotkeyBadge:tone,futHotkeyPlaced:'1',futHotkeyAction:action,futHotkeyTarget:target},attrs:{'aria-hidden':'true'}})
badge.__futHost=node
node.setAttribute?.('data-fut-hotkey-host','1')
node.appendChild?.(badge)
return true}
function toggleHelp(){if(overlay){hideHelp()
return false}
if(!isActive('hotkeys'))return false
styles()
const map=bindings()
const table=registry()
const here=Object.keys(LAYERS).filter((id)=>id!=='global'&&layerVisible(doc,id))
const rows=Object.entries(map).filter(([action,combo])=>{const meta=table[action]
if(combo===''||!meta||meta.reserved)return false
const layer=layerOf(meta)
return layer==='global'||here.includes(layer)}).map(([action,combo])=>{const meta=table[action]
return{combo:badgeText(combo),label:meta.label??(meta.labelKey?t(meta.labelKey):action),danger:meta.danger===true}})
const list=rows.length===0
?[el(doc,'div',{class:'fx-hk-help-empty',text:t('hotkeys.help.empty')})]
:rows.map((row)=>el(doc,'div',{class:'fx-hk-help-row'},[el(doc,'span',{class:'fx-hk-badge',text:row.combo,dataset:{futHotkeyBadge:row.danger?'danger':'normal'}}),el(doc,'span',{class:'fx-hk-help-label',text:row.label})]))
overlay=modalBox(doc,{mark:'futHotkeyHelp',lift:true,overlay:'fx-hk-help',box:'fx-hk-help-box',onBack:hideHelp,closeLabel:t('common.close'),title:t('hotkeys.help.title',{screen:here.length===0?t('hotkeys.help.anywhere'):t(LAYER_LABELS[here[0]])})},[...list,el(doc,'div',{class:'fx-hk-help-hint',text:t('hotkeys.help.hint')})])
;(doc.body??doc.documentElement)?.appendChild?.(overlay)
return true}
function hideHelp(){overlay?.remove?.()
overlay=null}
return{refresh,toggleHelp,hideHelp,
helpOpen:()=>overlay!==null,dispose(){hideHelp()
dropAll()}}}
export const WINDOW_ROW_CAP=200
export function createHotkeyWindow(deps){const{doc,t,bindings,registry,badgesOn,onBadges,onRebind,onReset,isActive=()=>true,onError=()=>{}}=deps
let host=null
let shown=''
const close=()=>{host?.remove?.()
host=null
shown=''}
function collect(){const map=bindings()
const table=registry()
const groups=new Map()
let hidden=0
let taken=0
for(const[action,meta]of Object.entries(table)){if(map[action]===undefined)continue
const group=groupOf(meta)
if(group===null)continue
if(typeof meta.reserved==='string')continue
if(meta.retired===true)continue
if(taken>=WINDOW_ROW_CAP){hidden+=1
continue}
taken+=1
const row={action,combo:map[action]??'',label:meta.label??(meta.labelKey?t(meta.labelKey):action),danger:meta.danger===true,reserved:typeof meta.reserved==='string'?meta.reserved:'',
handOnly:typeof meta.handOnly==='string'?meta.handOnly:''}
row.rank=rowRank(group,action)
const list=groups.get(group)
if(list)list.push(row)
else groups.set(group,[row])}
for(const list of groups.values())list.sort((a,b)=>a.rank-b.rank)
for(const pair of FUSED_ROWS){for(const list of groups.values()){const head=list.findIndex((row)=>row.action===pair[0])
const tail=list.findIndex((row)=>row.action===pair[1])
if(head===-1||tail===-1)continue
list[head]={...list[head],twin:list[tail]}
list.splice(tail,1)}}
return{groups,hidden,badges:badgesOn()===true}}
function signatureOf(model){const parts=[model.badges?'1':'0',String(model.hidden)]
for(const group of GROUPS){const rows=model.groups.get(group)
if(!rows)continue
parts.push(group)
for(const row of rows)parts.push(`${row.action}${row.combo}${row.label}${row.danger?'1':'0'}${row.reserved}${row.handOnly}`)}
return parts.join('')}
function rowNode(row){
if(row.reserved!==''){return el(doc,'div',{class:'fx-hk-window-row'},[el(doc,'span',{class:'fx-hk-window-unbound',text:'–'}),el(doc,'span',{class:'fx-hk-help-label fx-hk-window-reserved',text:`${row.label} · ${t('hotkeys.reserved.hint',{why:t(row.reserved)})}`})])}
const keyNode=(one)=>{const hit=()=>{try{onRebind(one.action)}catch(err){onError(err)}}
return one.combo===''
?el(doc,'span',{class:'fx-hk-window-unbound',text:t('hotkeys.unbound'),dataset:{futHotkeyRow:one.action},on:{click:hit}})
:el(doc,'span',{class:'fx-hk-badge',text:badgeText(one.combo),dataset:{futHotkeyBadge:one.danger?'danger':'normal',futHotkeyRow:one.action},on:{click:hit}})}
const key=el(doc,'span',{class:'fx-hk-window-key'},row.twin
?[keyNode(row),el(doc,'span',{class:'fx-hk-window-cut'}),keyNode(row.twin)]
:[keyNode(row)])
const hint=null
return el(doc,'div',{class:'fx-hk-window-row'},[key,el(doc,'span',{class:'fx-hk-help-label',text:row.label}),hint].filter(Boolean))}
function scrollBox(node){if(!node)return null
try{if(node.classList?.contains?.('fx-hk-help-box'))return node
return node.querySelector?.('.fx-hk-help-box')??null}catch{return null}}
function open(){if(isActive(HOTKEYS_FEATURE)!==true){close()
return null}
const model=collect()
const sign=signatureOf(model)
if(host&&host.isConnected!==false&&sign===shown)return host
const keepTop=scrollBox(host)?.scrollTop??0
close()
ensureWindow(doc)
ensureStylesheet(doc,HOTKEYS_STYLESHEET,HOTKEYS_LINK_ID)
const blocks=[]
for(const group of GROUPS){const rows=model.groups.get(group)
if(!rows||rows.length===0)continue
blocks.push(el(doc,'div',{class:'fx-hk-window-layer',text:t(GROUP_LABELS[group])}))
for(const row of rows)blocks.push(rowNode(row))}
if(model.hidden>0)blocks.push(el(doc,'div',{class:'fx-hk-help-hint',text:t('hotkeys.window.hidden',{count:model.hidden})}))
const toggle=el(doc,'input',{attrs:{type:'checkbox',id:'fut-hotkey-badges'},dataset:{futHotkeyBadgesToggle:'1'},on:{change:(event)=>{try{onBadges(Boolean(event?.target?.checked))}catch(err){onError(err)}}}})
toggle.checked=model.badges
host=modalBox(doc,{mark:'futHotkeyWindow',lift:true,overlay:'fx-hk-help',box:'fx-hk-help-box fx-hk-window-box',onBack:()=>close(),closeLabel:t('common.close'),title:t('hotkeys.title')},[el(doc,'div',{class:'fx-hk-help-hint',text:t('hotkeys.window.hint')}),...blocks,el(doc,'div',{class:'fx-hk-window-toggle'},[toggle,el(doc,'label',{text:t('hotkeys.window.badges'),attrs:{for:'fut-hotkey-badges'}})]),modalButtons(doc,[{text:t('hotkeys.reset'),mark:'futHotkeyReset',on:()=>{try{onReset()}catch(err){onError(err)}
close()}},{text:t('common.close'),mark:'futHotkeyClose',on:close}])])
;(doc.body??doc.documentElement)?.appendChild?.(host)
if(keepTop>0){const box=scrollBox(host)
if(box)box.scrollTop=keepTop}
shown=sign
return host}
return{open,close,
refresh(){if(host)open()},isOpen:()=>host!==null,
signature:()=>shown,dispose:close}}
export function createDangerNote(deps){const{doc,t,seen,onSeen,onError=()=>{}}=deps
let host=null
const close=()=>{host?.remove?.()
host=null}
const note=(keys)=>{const already=seen()
const known=Array.isArray(already)?already:[]
const fresh=(Array.isArray(keys)?keys:[]).filter((one)=>typeof one?.action==='string'&&!known.includes(one.action))
if(fresh.length===0)return 0
close()
ensureWindow(doc)
ensureStylesheet(doc,HOTKEYS_STYLESHEET,HOTKEYS_LINK_ID)
const rows=fresh.map((one)=>el(doc,'div',{class:'fx-hk-help-row'},[el(doc,'span',{class:'fx-hk-badge',text:badgeText(one.combo??''),dataset:{futHotkeyBadge:'danger'}}),el(doc,'span',{class:'fx-hk-help-label',text:one.label})]))
const kinds=dangerKindsOf(fresh.map((one)=>one.action))
const lines=kinds.map((kind)=>el(doc,'div',{class:'fx-hk-capture-hint',dataset:{futHotkeyDangerKind:kind},text:t(DANGER_KIND_KEYS[kind])}))
host=modalBox(doc,{mark:'futHotkeyDanger',lift:true,value:fresh.map((one)=>one.action).join(','),box:'fx-hk-capture-box danger',title:t('hotkeys.danger.title'),closeLabel:t('common.close'),onBack:close},[...rows,el(doc,'div',{class:'fx-hk-capture-hint',text:t('hotkeys.danger.body')}),...lines,el(doc,'div',{class:'fx-hk-capture-hint',text:t('hotkeys.danger.tail')}),modalButtons(doc,[{text:t('hotkeys.danger.ok'),mark:'futHotkeyDangerYes',on:close}])])
;(doc.body??doc.documentElement)?.appendChild?.(host)
for(const one of fresh){try{onSeen(one.action)}catch(err){onError(err)}}
return fresh.length}
return{note,close,isOpen:()=>host!==null}}
