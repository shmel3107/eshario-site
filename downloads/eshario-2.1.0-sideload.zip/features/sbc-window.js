import{el,clear,ensureSbcWindowStyles,ensureSidebarStyles,logoLink} from '../ui/dom.js'
import{ensureControls} from '../ui/controls.js'
import{keyOfEvent} from './hotkeys.js'
import{isTypingTarget,realTarget} from './hotkey-binding.js'
import{SBC_FEATURE,requirementLabelKey,requirementNameKey,guardBlockerKey,solvePhases,cheaperVerdict,rescueVerdict,phaseReason,conceptsMissingFor,twiceInPlan,mismatchInPlan,planSlotsFor,ALT_PICKS,MAX_SOLVE_EVALUATIONS,CHEAPEN_MIN_COINS,CHEAPEN_MIN_SHARE} from './sbc-actions.js'
import{verifiedPriceOf,AGE_KNOWN} from './price-badges.js'
import{CARD_SILENCE,OVER_REFERENCE} from './live-price-probe.js'
import{SKIP_FAILURES,HOUR_CAP_REFUSAL,RECEIPT_UNRESOLVED,buyCeilingOf,buyTargetOf} from '../automation/auto-buy.js'
import{stopReasonKey} from '../automation/stop-reasons.js'
import{REQUIREMENT_KEY} from '../automation/sbc-requirements.js'
import{FINISH_MS,FINISH_SIGNAL,FINISH_CALL_MS} from '../automation/sbc-finish.js'
import{cardTag} from './club-actions.js'
import{formatStamp} from './sell-sidebar.js'
import{challengeContentOf,challengeAnchorOf,observeChallengeSubmitted,observeSquadChanges,squadFieldSignature,squadFieldSlotPairs,frozenKeyOf,HOOK_ENTER} from '../adapter/sbc-screen.js'
import{createStaticPlayers,DATABASE_ID_MASK} from '../adapter/static-players.js'
import{createFrozenStore,solutionIds,FROZEN_KEEP} from './sbc-frozen.js'
import{SUBMIT_DOORS,SUBMIT_TAB_SELECTOR} from '../adapter/sbc-submit.js'
const WINDOW_SELECTOR='[data-fut-sbc-window]'
const SLOT_SELECTOR='.ut-squad-slot-view[index]'
const RECREATED_WALL='sbc.recreatedLock'
export const FOLD_BUYS='buys'
export const FOLD_LINEUP='lineup'
const SAVE_REFUSALS=new Set(['sbcWindow.saveExhausted','sbcWindow.saveRefused','sbcWindow.saveFailed'])
export const NATIVE_ENTRY_MS=600
export const ENTRY_WATCH_MS=600
const LONG_GAP_MS=32
export const REBUILD_PATIENCE_MS=18000
export const REBUILD_TRIES=Math.ceil(REBUILD_PATIENCE_MS/NATIVE_ENTRY_MS)
const CHEAPEN_TIME_MS=15000
const CHEAPEN_WAIT_FRAMES=120
const CHEAPEN_CEILING_X=5
export const RESCUE_CEILING_X=3
export const RESCUE_CEILING_RUNGS=3
export const RESCUE_CEILING_MAX=900_000
export const RESCUE_TOP_MS=8000
export const RESCUE_FINISH_WEIGHT=300_000
const WHY_RESCUE='rescue'
const WHY_STALLED='rescue-unfinished'
const WHY_OFFERED='offered'
export const MODE_CLUB='club'
export const MODE_MARKET='club+market'
export function resultModel(input={}){const{t,result}=input
const empty={rating:null,chemistry:null,burn:null,price:null,failed:[]}
if(!result)return empty
const failed=(result.failed??[]).map((row)=>({id:String(row?.key),label:requirementLabel(t,row)}))
const verdict=result.verdict
if(!verdict)return{...empty,failed}
const live=input.live??null
const unknown=t('sbcWindow.unknown')
const show=(value)=>(typeof value==='number'&&Number.isFinite(value)?String(value):unknown)
const number=(value)=>(typeof value==='number'&&Number.isFinite(value)?value:null)
const exact=number(verdict.ratingExact)
const offlineRating=number(verdict.rating)
const liveRating=number(live?.rating)
const drift=liveRating!==null&&offlineRating!==null&&offlineRating!==liveRating
?t('sbcWindow.ratingDrift',{offline:offlineRating,live:liveRating}):null
const rating={text:t('sbcWindow.rating',{value:exact===null?unknown:exact.toFixed(2)}),met:(live?live.ratingMet:verdict.ratingMet)===true,drift}
const liveChemistry=number(live?.chemistry)
const chemistry=liveChemistry===null
?{text:t('sbcWindow.chemistryOffline',{value:show(verdict.chemistry)}),met:false}
:number(verdict.chemistry)===null
?{text:t('sbcWindow.chemistryLive',{value:show(liveChemistry)}),met:live.chemistryMet===true}
:{text:t('sbcWindow.chemistry',{offline:show(verdict.chemistry),live:show(liveChemistry)}),met:live.chemistryMet===true}
chemistry.note=liveChemistry===null&&(result.buys??[]).some((buy)=>buy?.posEstimate===true||buy?.posBlind===true)
?t('sbcWindow.chemistryPosEstimate'):null
return{rating,chemistry,burn:burnRow(t,result.burn),price:priceRow(t,result.price),failed}}
function burnRow(t,burn){if(typeof burn?.cost!=='number'||!Number.isFinite(burn.cost))return null
const unknown=typeof burn.unknown==='number'&&burn.unknown>0?burn.unknown:0
const counted=typeof burn.priced==='number'?burn.priced>0||unknown===0:burn.cost>0||unknown===0
const mine=typeof burn.mine==='number'&&burn.mine>0?burn.mine:0
return{text:counted?t('sbcWindow.burn',{value:burn.cost}):t('sbcWindow.burnUnknown'),
unpriced:unknown,mine}}
function priceRow(t,price){if(typeof price?.total!=='number'||!Number.isFinite(price.total))return null
const unknown=typeof price.unknown==='number'&&price.unknown>0?price.unknown:0
const counted=typeof price.priced==='number'?price.priced>0:price.total>0||unknown===0
return{text:counted?t('sbcWindow.price',{value:price.total}):t('sbcWindow.priceUnknown'),unpriced:unknown>0?t('sbcWindow.priceUnpriced',{unknown}):null}}
export function costModel(input={}){const result=input?.result??null
if(!result||result.ok!==true)return null
const price=result.price
if(!price||typeof price.total!=='number'||!Number.isFinite(price.total))return null
const unpriced=Number.isFinite(price.unknown)&&price.unknown>0?price.unknown:0
const counted=Number.isFinite(price.priced)?price.priced>0:price.total>0||unpriced===0
if(!counted)return null
let tradable=0
let untradable=0
for(const row of Array.isArray(result.lineup)?result.lineup:[]){if(row?.buy===true)continue
const value=Number.isFinite(row?.price)&&row.price>0?row.price:0
if(row?.untradeable===true)untradable+=value
else tradable+=value}
const spend=Number.isFinite(result.spend)&&result.spend>0?result.spend:0
const buys=Array.isArray(result.buys)?result.buys.length:0
const mine=Array.isArray(result.mine)?result.mine.length
:(Number.isFinite(result.burn?.mine)&&result.burn.mine>0?result.burn.mine:0)
return{total:price.total,tradable,untradable,real:tradable+spend,spend,buys,unpriced,mine}}
export const SCARCITY_SPARE=8
export function scarcityTight(scarcity){const candidates=scarcity?.candidates
const need=scarcity?.need
if(!Number.isFinite(candidates)||!Number.isFinite(need))return false
return candidates-need<=SCARCITY_SPARE}
export const UNTRADEABLE_FROM=83
function whyFacts(result){if(result?.ok!==true)return null
const scarcity=result.scarcity
if(scarcity?.noCounted===true)return{kind:'none',name:null,candidates:null,need:null,buy:false,fromClub:null,tight:false}
const candidates=scarcity?.candidates
const need=scarcity?.need
if(!Number.isFinite(candidates)||!Number.isFinite(need)||need<=0)return null
const buy=(Array.isArray(result.lineup)?result.lineup:[]).some((row)=>row?.buy===true)
const fromClub=scarcity?.fromClub
if(buy&&!Number.isFinite(fromClub))return null
return{kind:'scarcity',name:scarcity.name,candidates,need,buy,fromClub:buy?fromClub:null,tight:scarcityTight(scarcity)}}
export function whyModel(input={}){const{t,result}=input
const facts=whyFacts(result)
if(facts===null)return null
const tight=facts.tight
const parts=[]
if(facts.kind==='none')parts.push(t('sbcWindow.whyAny'))
else{const name=t(requirementNameKey(facts.name))
parts.push(facts.buy
?t('sbcWindow.whyBuy',{name,club:facts.fromClub,need:facts.need})
:t('sbcWindow.why',{name,have:facts.candidates,need:facts.need}))}
if(tight)parts.push(t('sbcWindow.whyTight'))
const burned=(Array.isArray(result.lineup)?result.lineup:[])
.filter((row)=>row?.buy!==true&&Number.isFinite(row?.rating)&&row.rating>=UNTRADEABLE_FROM)
if(burned.length>0&&burned.every((row)=>row?.untradeable===true))parts.push(t('sbcWindow.whyUntradeable'))
return{text:parts.join(' · '),tight}}
export function footballerIdOf(id){if(!Number.isSafeInteger(id)||id<=0)return null
const base=id%(DATABASE_ID_MASK+1)
return base>0?base:null}
export function buyRowName(input,row){const t=input?.t
const rating=Number.isFinite(row?.rating)?row.rating:t('sbcWindow.unknown')
const nameOf=typeof input?.nameOf==='function'?input.nameOf:null
const id=footballerIdOf(row?.definitionId)
const card=nameOf===null||id===null?null:nameOf(id)
if(typeof card==='string'&&card!=='')return t('sbcWindow.buyRowNamed',{name:card,rating})
const affiliation=typeof row?.affiliation?.name==='string'&&row.affiliation.name!==''?row.affiliation.name:null
return affiliation===null?t('sbcWindow.buyRow',{rating}):t('sbcWindow.buyRowNamed',{name:affiliation,rating})}
export function lineupModel(input={}){const{t}=input
const isLocked=typeof input.isLocked==='function'?input.isLocked:()=>false
return(Array.isArray(input.rows)?input.rows:[]).map((row)=>{const parked=row?.parked===true
if(row?.buy===true){const priced=Number.isFinite(row?.price)&&row.price>0
const estimate=priced&&row?.estimate===true
const rating=Number.isFinite(row?.rating)?row.rating:t('sbcWindow.unknown')
const affiliation=typeof row?.affiliation?.name==='string'&&row.affiliation.name!==''?row.affiliation.name:null
return{id:String(row?.id??''),lock:null,affiliation,
name:buyRowName(input,row),
lockedLabel:t('sbcWindow.markLocked'),mineLabel:t('sbcWindow.markMine'),
price:priced?(estimate?t('sbcWindow.buyEstimate',{value:row.price}):String(row.price)):t('sbcWindow.unknown'),
marks:[t('sbcWindow.markBuy')],locked:false,mine:false,parked:false,buy:true,estimate,
known:buyDoorKnown(row),
posEstimate:row?.posEstimate===true}}
const marks=[]
if(row?.duplicate===true)marks.push(t('sbcWindow.markDuplicate'))
if(row?.untradeable===true)marks.push(t('sbcWindow.markUntradeable'))
return{id:String(row?.id??''),lock:Number.isSafeInteger(row?.lock)?row.lock:null,name:String(row?.name??row?.id??''),
lockedLabel:t('sbcWindow.markLocked'),mineLabel:t('sbcWindow.markMine'),
price:Number.isFinite(row?.price)&&row.price>0?String(row.price):t('sbcWindow.unknown'),
marks,locked:isLocked(row?.lock)===true,
mine:row?.mine===true&&!parked,parked,buy:false}})}
export function offerModel(input={}){const{t,offer}=input
if(!offer||offer.answer===null||offer.answer===undefined)return null
if(offer.taken===true)return{taken:true,text:null,action:t('sbcWindow.offerBack')}
const saved=Number.isFinite(offer.savings)?Math.round(offer.savings):0
const spend=Number.isFinite(offer.spend)?Math.round(offer.spend):0
if(saved<=0||spend<=0)return null
return{taken:false,text:t('sbcWindow.offerCheaper',{saved,spend}),action:t('sbcWindow.offerShow')}}
export function spendModel(input={}){const{t,result}=input
if(!result||result.market!==true)return null
const solved=result.ok===true
const buys=Array.isArray(result.buys)?result.buys:[]
if(buys.length===0)return solved?{text:t('sbcWindow.spendNone'),count:0,ok:true}:null
const spend=Number.isFinite(result.spend)&&result.spend>0?result.spend:0
return{text:t(solved?'sbcWindow.spend':'sbcWindow.spendFailed',{value:spend,count:buys.length}),count:buys.length,ok:solved}}
export function buyDoorKnown(row){return Number.isSafeInteger(row?.definitionId)&&row.definitionId>0}
export function buyListModel(input={}){const{t,result}=input
if(!result||result.market!==true)return[]
return(Array.isArray(result.buys)?result.buys:[]).map((buy)=>{const priced=Number.isFinite(buy?.price)&&buy.price>0
const estimate=priced&&buy?.live!==true
const rating=Number.isFinite(buy?.rating)?buy.rating:t('sbcWindow.unknown')
const affiliation=typeof buy?.affiliation?.name==='string'&&buy.affiliation.name!==''?buy.affiliation.name:null
return{id:String(buy?.id??''),
name:buyRowName(input,buy),
affiliation,
price:priced?(estimate?t('sbcWindow.buyEstimate',{value:buy.price}):String(buy.price)):t('sbcWindow.unknown'),
known:buyDoorKnown(buy),
estimate,
posEstimate:buy?.posEstimate===true}})}
export const AUTO_BUY_FEATURE='sbcAutoBuy'
export const WINDOW_BUILD='W21B-2'
export const WARN_SPEND_COINS=150_000
export const SHAKEDOWN=false
export const SHAKEDOWN_DIVISOR=10
export function warnSpendCoins(){return SHAKEDOWN?Math.round(WARN_SPEND_COINS/SHAKEDOWN_DIVISOR):WARN_SPEND_COINS}
export function autoBuyTargets(result,opts={}){if(!result||result.market!==true)return[]
const verifiedOf=typeof opts.verifiedOf==='function'?opts.verifiedOf:verifiedPriceOf
const done=opts.done instanceof Set?opts.done:null
const out=[]
for(const buy of Array.isArray(result.buys)?result.buys:[]){if(!Number.isSafeInteger(buy?.definitionId)||buy.definitionId<=0)return[]
if(done!==null&&done.has(String(buy?.id??'')))continue
out.push({id:buy.definitionId,row:String(buy?.id??''),
want:referenceOfBuy(buy,verifiedOf),
rating:Number.isFinite(buy?.rating)?buy.rating:null,
affiliation:buy?.affiliation??null,
alts:(Array.isArray(buy?.alts)?buy.alts:[]).filter((one)=>Number.isSafeInteger(one?.id)&&one.id>0)})}
return out}
export function batchPrices(targets){let estimate=0
let worst=0
const blind=[]
for(const one of Array.isArray(targets)?targets:[]){const live=Number.isFinite(one?.price)&&one.price>0?one.price:null
const cap=buyCeilingOf(buyTargetOf({...one,price:live}))
if(!Number.isFinite(cap)||cap<=0){blind.push(one)
continue}
const known=live??(Number.isFinite(one?.want)&&one.want>0?one.want:cap)
estimate+=Math.min(known,cap)
worst+=cap}
return{estimate,worst,blind}}
export const EXCLUDE_PICKS=3
const STUCK=new Set([...CARD_SILENCE,OVER_REFERENCE])
export function overPercentOf(row){if(row?.reason!==OVER_REFERENCE)return null
const price=Number(row?.price)
const want=Number(row?.want)
if(!Number.isFinite(price)||!Number.isFinite(want)||want<=0)return null
return Math.round((price/want-1)*100)}
export function stuckWithoutAlts(targets,verdict){const rows=new Map()
for(const row of Array.isArray(verdict?.rows)?verdict.rows:[])rows.set(row?.id,row)
const out=[]
for(const one of Array.isArray(targets)?targets:[]){const row=rows.get(one?.id)
if(row?.live===true||!STUCK.has(row?.reason))continue
if((Array.isArray(one?.alts)?one.alts:[]).length>0)continue
if(!Number.isSafeInteger(one?.id)||one.id<=0)continue
out.push({id:one.id,rating:Number.isFinite(one?.rating)?one.rating:null,
affiliation:one?.affiliation??null,
over:overPercentOf(row)})}
return out}
export function substituteStuck(targets,verdict){const rows=new Map()
for(const row of Array.isArray(verdict?.rows)?verdict.rows:[])rows.set(row?.id,row)
let changed=false
const out=(Array.isArray(targets)?targets:[]).map((one)=>{const row=rows.get(one?.id)
if(row?.live===true||!STUCK.has(row?.reason))return one
const alts=Array.isArray(one?.alts)?one.alts:[]
if(alts.length===0)return one
const[next,...rest]=alts
changed=true
return{...one,id:next.id,want:Number.isFinite(next.price)&&next.price>0?next.price:null,alts:rest,
price:null,age:null,origin:null,stampedAt:null,
swapped:(Number.isFinite(one?.swapped)?one.swapped:0)+1,
swapRoot:Number.isSafeInteger(one?.swapRoot)&&one.swapRoot>0?one.swapRoot:(Number.isSafeInteger(one?.id)&&one.id>0?one.id:null),
swapFrom:{id:one?.id??null,rating:Number.isFinite(one?.rating)?one.rating:null,
affiliation:one?.affiliation??null},
swapOver:overPercentOf(row)}})
return changed?out:null}
export const VERIFIED_TTL_MS=30_000
export function referenceOfBuy(buy,verifiedOf){if(Number.isFinite(buy?.price)&&buy.price>0)return buy.price
let seen=null
try{seen=typeof verifiedOf==='function'?verifiedOf(buy?.definitionId):null}catch{seen=null}
if(!seen||!Number.isFinite(seen.coins)||seen.coins<=0)return null
if(seen.age!==undefined&&seen.age!==AGE_KNOWN)return null
return Number.isFinite(seen.ageMs)&&seen.ageMs<=VERIFIED_TTL_MS?seen.coins:null}
export function swappedNote(input={}){const{t}=input
const face=typeof input.face==='function'?input.face:null
let count=0
let over=null
for(const one of Array.isArray(input.targets)?input.targets:[]){if(!Number.isFinite(one?.swapped)||one.swapped<=0)continue
count+=1
if(over===null&&Number.isFinite(one?.swapOver)&&one.swapFrom)over=one}
if(count===0)return null
if(over===null||face===null)return t('sbcBuy.swapped',{count})
const said=t('sbcBuy.swappedOver',{out:face(over.swapFrom),in:face(over),percent:over.swapOver})
return count===1?said:`${said} ${t('sbcBuy.overMore',{count:count-1})}`}
const MARKET_STOP_WORDS=Object.freeze({budget:'sbcBuy.marketBusy',rest:'sbcBuy.marketBusy',
throttled:'sbcBuy.marketBusy','unknown-refusals':'sbcBuy.marketBusy',
'day-budget':'sbcBuy.marketDay','counter-unavailable':'sbcBuy.marketBusy',
'search-hour':'sbcBuy.marketHour',
captcha:'sbcBuy.marketBroken',fatal:'sbcBuy.marketBroken'})
function marketBusyWordOf(verdict){let word=null
for(const row of Array.isArray(verdict?.rows)?verdict.rows:[]){if(row?.live===true)continue
const reason=row?.reason
if(typeof reason!=='string'||reason===''||reason===OVER_REFERENCE)continue
if(CARD_SILENCE.has(reason))continue
const said=MARKET_STOP_WORDS[reason]??'sbcBuy.marketBusy'
if(said!=='sbcBuy.marketBusy')return said
word=said}
return word}
function marketWord(t,key,verdict){if(key!=='sbcBuy.marketBusy')return t(key)
const rows=Array.isArray(verdict?.rows)?verdict.rows:[]
const cards=Number.isFinite(verdict?.cards)&&verdict.cards>0?verdict.cards:rows.length
if(cards<=0)return t(key)
const done=rows.filter((one)=>Number.isFinite(one?.price)&&one.price>0).length
const waitMs=Number(verdict?.waitMs)
return Number.isFinite(waitMs)&&waitMs>0
?t('sbcBuy.marketBusyWait',{done,cards,seconds:Math.max(1,Math.ceil(waitMs/1000))})
:t('sbcBuy.marketBusyCount',{done,cards})}
export function autoBuyPriceNote(input={}){const{t}=input
const stopped=typeof input.verdict?.stoppedBy==='string'?input.verdict.stoppedBy:null
if(stopped!==null&&Object.hasOwn(MARKET_STOP_WORDS,stopped))return marketWord(t,MARKET_STOP_WORDS[stopped],input.verdict)
const busy=marketBusyWordOf(input.verdict)
if(busy!==null)return marketWord(t,busy,input.verdict)
const over=Array.isArray(input.verdict?.over)?input.verdict.over:[]
if(over.length===0)return t('sbcBuy.needsPrice')
const first=over[0]
const key=input.fresh===true?'sbcBuy.overFresh':'sbcBuy.overReference'
const said=t(key,{name:first?.name??t('sbcWindow.unknown'),
coins:first?.price??0,want:first?.want??0})
return over.length===1?said:`${said} ${t('sbcBuy.overMore',{count:over.length-1})}`}
const SKIP_REASON_KEYS=Object.freeze({gone:'sbcBuy.skip.gone','no-lot':'sbcBuy.skip.noLot',transient:'sbcBuy.skip.transient',unknown:'sbcBuy.skip.unknown','card-throttled':'sbcBuy.skip.cardThrottled'})
const AUTO_BUY_BAD_STATE='bad-state'
export function autoBuyStopLine(input={}){const{t}=input
const reason=typeof input.reason==='string'&&input.reason!==''?input.reason:null
if(reason===null)return null
if(reason===HOUR_CAP_REFUSAL){const stamp=formatStamp(input.detail?.until)
return stamp===null?t('sbcBuy.hourCapSoon'):t('sbcBuy.hourCap',{time:stamp.time})}
if(reason===RECEIPT_UNRESOLVED)return t('sbcBuy.receiptUnresolved',{name:input.detail?.name??t('sbcWindow.unknown')})
if(reason===AUTO_BUY_BAD_STATE&&input.detail?.stage==='concepts'){const why=input.detail?.why
const said=why==='no-source'
?t('sbcBuy.conceptNoSolve')
:why==='no-squad'
?t('sbcBuy.conceptNoPitch')
:why==='twice'
?t('sbcBuy.conceptTwice',{name:input.detail?.name??t('sbcWindow.unknown')})
:why==='mismatch'
?t('sbcBuy.conceptMismatch',{name:input.detail?.name??t('sbcWindow.unknown')})
:t('sbcBuy.needsConcept',{name:input.detail?.name??t('sbcWindow.unknown')})
const more=Number.isSafeInteger(input.detail?.count)?input.detail.count-1:0
return more>0?`${said} ${t('sbcBuy.overMore',{count:more})}`:said}
return t(stopReasonKey(reason))}
export function autoBuySkips(input={}){const{t}=input
const out=[]
for(const row of Array.isArray(input.rows)?input.rows:[]){if(row?.status!=='skipped')continue
const kind=SKIP_FAILURES.includes(row?.reason)?row.reason:'unknown'
out.push(t('sbcBuy.skipped',{name:row?.name??t('sbcWindow.unknown'),
reason:t(SKIP_REASON_KEYS[kind]??SKIP_REASON_KEYS.unknown)}))}
return out}
export function chemistryRefused(live){return live!==null&&live!==undefined&&live.chemistryMet===false}
export function autoBuyModel(input={}){const{t,result}=input
if(input.available!==true)return null
if(!result||result.market!==true)return null
const buys=Array.isArray(result.buys)?result.buys:[]
if(buys.length===0)return null
if(input.active!==true)return null
if(input.entitled!==true){return{label:t('sbcBuy.button'),disabled:true,armed:false,locked:true,
hint:t('license.premiumRequired'),phase:'locked'}}
const state=input.state??null
const phase=typeof state?.phase==='string'?state.phase:'idle'
const targets=autoBuyTargets(result,input.done instanceof Set?{done:input.done}:{})
if(phase==='checking'){return{label:t('sbcBuy.checking'),disabled:true,armed:false,locked:false,hint:null,phase}}
if(phase==='running'){return{label:t('sbcBuy.stop'),disabled:false,armed:false,locked:false,
hint:t('sbcBuy.running',{done:state?.done??0,cards:state?.cards??targets.length,coins:state?.spent??0}),phase}}
if(input.busy===true){return{label:t('sbcBuy.stopBusy'),disabled:false,armed:false,locked:false,
hint:t('sbcBuy.runningOther'),phase:'busy'}}
if(phase==='counting'){return{label:t('sbcBuy.button'),disabled:false,armed:false,locked:false,
hint:typeof state?.note==='string'?state.note:null,phase}}
if(phase==='armed'){const early=input.ready!==true||chemistryRefused(input.live)
const coins=state?.total??0
const limit=Number.isFinite(state?.worst)&&state.worst>coins?state.worst:null
const one=typeof state?.only==='string'&&state.only!==''
?(Array.isArray(state?.targets)?state.targets:[]).find((row)=>String(row?.row??'')===state.only)??null
:null
const name=typeof one?.name==='string'&&one.name!==''?one.name:null
const label=name===null
?(limit===null?t('sbcBuy.armed',{coins}):t('sbcBuy.armedFork',{coins,limit}))
:(limit===null?t('sbcBuy.armedOne',{name,coins}):t('sbcBuy.armedOneFork',{name,coins,limit}))
return{label,
disabled:early,armed:!early,locked:false,
hint:chemistryRefused(input.live)?t('sbcBuy.chemistryFailed')
:(early?t('sbcBuy.needsPitch'):(state?.note??null)),phase}}
let hint=null
if(targets.length===0)hint=t('sbcBuy.noTargets')
else if(chemistryRefused(input.live))hint=t('sbcBuy.chemistryFailed')
else if(input.ready!==true)hint=t('sbcBuy.needsPitch')
const disabled=hint!==null
return{label:t('sbcBuy.button'),disabled,armed:false,locked:false,
hint:hint??(typeof state?.note==='string'?state.note:null),phase:'idle'}}
export function rowForSlot(prepared,targets,slot){if(!Number.isInteger(slot)||slot<0)return null
if(prepared===null||prepared===undefined)return null
const plan=planSlotsFor(prepared,Array.isArray(targets)?targets:[])
const slots=plan?.slots instanceof Map?plan.slots:null
if(slots===null)return null
for(const[row,at]of slots){if(at===slot)return String(row)}
return null}
const CHEAPEN_BELOW='below-threshold'
const CHEAPEN_NONE='no-savings'
export function searchCapModel(input={}){const{t,result}=input
if(!result||result.ok!==true||result.search?.exhausted!==true)return null
if(input.background===true)return null
const phase=input.phase??null
const coins=Number.isFinite(phase?.savings)?Math.round(phase.savings):0
if(phase?.why===CHEAPEN_BELOW&&coins>0)return{text:t('sbcWindow.searchCheaperKnown',{coins})}
if(phase?.why===CHEAPEN_NONE&&phase?.done===true)return null
return{text:t(result.search?.solverBudget?.timeStopped===true?'sbcWindow.searchCapClock':'sbcWindow.searchExhausted')}}
export function readyModel(input={}){const{t,result}=input
if(input.busy===true)return null
if(!result||result.ok!==true||result.prepared===null||result.prepared===undefined)return null
return{text:t('sbcWindow.ready')}}
const RARITY_KEYS=new Set([REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_RARITY_GROUP])
const IDENTITY_KEYS=new Set([REQUIREMENT_KEY.LEAGUE_ID,REQUIREMENT_KEY.NATION_ID,REQUIREMENT_KEY.CLUB_ID])
const CHEMISTRY_GAP_KEYS=new Set([REQUIREMENT_KEY.CHEMISTRY_POINTS,REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS])
const OWNERSHIP_KEYS=new Set([REQUIREMENT_KEY.FIRST_OWNER_PLAYERS_COUNT,REQUIREMENT_KEY.PLAYER_TRADABILITY])
const GAP_TEXT={rarity:'sbcWindow.marketNoRarity',identity:'sbcWindow.marketNoIdentity',chemistry:'sbcWindow.marketNoChemistry',
ownership:'sbcWindow.marketNoOwnership'}
export function marketGapModel(input={}){const{t,result}=input
if(!result||result.market!==true)return null
const blind=Array.isArray(result.marketBlind)?result.marketBlind:[]
const buys=Array.isArray(result.buys)?result.buys.length:0
if(result.ok===true&&buys>0)return null
const failed=Array.isArray(result.failed)?result.failed:[]
const failedIdentity=failed.some((row)=>IDENTITY_KEYS.has(row?.key))
const failedRarity=failed.some((row)=>RARITY_KEYS.has(row?.key))
const failedChemistry=failed.some((row)=>CHEMISTRY_GAP_KEYS.has(row?.key))
const failedOwnership=failed.some((row)=>OWNERSHIP_KEYS.has(row?.key))
const order=failedOwnership?['ownership','chemistry','identity','rarity']
:failedChemistry?['chemistry','identity','rarity','ownership']
:failedIdentity&&!failedRarity?['identity','rarity','chemistry','ownership']:['rarity','identity','chemistry','ownership']
for(const kind of order){if(!blind.includes(kind))continue
return{text:t(GAP_TEXT[kind])}}
return result.ok!==true&&failedRarity?{text:t('sbcWindow.marketNoRarity')}:null}
function cacheModel(input={}){const{t,cache}=input
const coins=typeof input.coins==='function'?input.coins:(value)=>String(value)
const hunger=cache?.hunger
let warn=null
if(hunger&&typeof hunger==='object'&&hunger.ok===false){const reason=typeof hunger.reason==='string'?hunger.reason:''
const total=Number.isFinite(hunger.expected)?hunger.expected:0
const got=Number.isFinite(hunger.got)?hunger.got:0
if(reason==='day-limit')warn=t('sbcWindow.clubDayLimit')
else if(total>0&&got<total)warn=t('sbcWindow.clubShort',{count:got,total})
else warn=t('sbcWindow.clubUnread')}
const club=Number.isFinite(cache?.sources?.club)&&cache.sources.club>0?cache.sources.club:null
const storage=Number.isFinite(input.storage)&&input.storage>=0?input.storage
:(Number.isFinite(cache?.sources?.storage)&&cache.sources.storage>=0?cache.sources.storage:null)
const text=club===null?t('sbcWindow.cacheEmpty')
:storage===null?t('sbcWindow.clubRowPlain',{club:coins(club)})
:t('sbcWindow.clubRow',{club:coins(club),storage:coins(storage)})
return{text,action:t('sbcWindow.rebuild'),warn}}
const CHEMISTRY_MISMATCH=/^chemistry-estimate-mismatch:(-?\d+)!=(-?\d+)$/
export function guardModel(input={}){const{t,guard}=input
if(!guard)return{lines:[],again:null}
const names=input.names instanceof Map?input.names:new Map
const named=(ids)=>(Array.isArray(ids)?ids:[]).map((id)=>names.get(String(id))??String(id)).join(', ')
const blockers=Array.isArray(guard.blockers)?guard.blockers:[]
const lines=blockers.map((blocker)=>{const key=guardBlockerKey(blocker?.code)
return key?t(key,{names:named(blocker?.ids),reason:String(blocker?.reason??''),count:(Array.isArray(blocker?.reqs)?blocker.reqs.length:0)+(Number(blocker?.skipped)||0)}):t('sbcGuard.other',{code:String(blocker?.code)})})
for(const warning of guard.warnings??[]){const drift=CHEMISTRY_MISMATCH.exec(String(warning))
lines.push(drift?t('sbcGuard.mismatch',{offline:drift[1],live:drift[2]}):t('sbcGuard.other',{code:String(warning)}))}
const passable=blockers.length>0&&blockers.every((blocker)=>blocker?.confirmable===true)
if(!passable)return{lines,again:null}
const ids=[...new Set(blockers.flatMap((blocker)=>(blocker?.ids??[]).map(String)))]
return{lines,again:ids.length>0?t('sbcGuard.again',{names:named(ids)}):t('sbcGuard.againPlain')}}
export function guardBadgeModel(input={}){const{t,hook}=input
if(!hook)return null
const faults=(Number(hook.faults)||0)+(Number(hook.errors)||0)
const missing=hook.missing?.length??0
if(missing>=SUBMIT_DOORS.length)return{text:t('sbcWindow.guardNone'),ok:false,level:'none'}
if(hook.ok!==true||faults>0)return{text:t('sbcWindow.guardOff'),ok:false,level:'off'}
if(missing>0)return{text:t('sbcWindow.guardPartial'),ok:false,level:'off'}
return null}
function requirementLabel(t,row){const name=t(requirementLabelKey(row?.key))
const have=row?.have
return have===null||have===undefined?name:`${name}: ${have}/${row?.need??row?.value}`}
export function createSbcWindow(deps={}){const{doc,t}=deps
const win=deps.win??doc?.defaultView??globalThis
const now=typeof deps.now==='function'?deps.now:()=>Date.now()
const staticPlayers=createStaticPlayers(win)
const staticNameOf=(id)=>{try{return staticPlayers.nameOf(id)}catch{return null}}
const phases=deps.phases&&typeof deps.phases.begin==='function'?deps.phases:solvePhases
const prewarm=typeof deps.prewarm==='function'?deps.prewarm:null
const wantsCheapen=typeof deps.wantsCheapen==='function'?deps.wantsCheapen:()=>true
const onEnterChallenge=typeof deps.onEnterChallenge==='function'?deps.onEnterChallenge:null
const onSolution=typeof deps.onSolution==='function'?deps.onSolution:()=>{}
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const statusOf=typeof deps.statusOf==='function'?deps.statusOf:()=>'unknown'
const cacheState=typeof deps.cacheState==='function'?deps.cacheState:null
const coins=typeof deps.coins==='function'?deps.coins:(value)=>String(value)
const storageOf=typeof deps.storageCount==='function'?deps.storageCount:null
const storageCount=()=>{if(storageOf===null)return null
try{const value=storageOf()
return Number.isFinite(value)&&value>=0?value:null}catch{return null}}
const frozen=deps.frozen&&typeof deps.frozen.get==='function'&&typeof deps.frozen.put==='function'&&typeof deps.frozen.dropAll==='function'
?deps.frozen:createFrozenStore()
const warmStats=typeof deps.warm==='function'?deps.warm:null
const lockGeneration=typeof deps.lockGeneration==='function'?deps.lockGeneration:null
const refreshCache=typeof deps.refreshCache==='function'?deps.refreshCache:null
const tradeAccess=typeof deps.tradeAccess==='function'?deps.tradeAccess:null
const onSubmitted=typeof deps.onSubmitted==='function'?deps.onSubmitted:null
const solve=typeof deps.solve==='function'?deps.solve:null
const showOnPitch=typeof deps.show==='function'?deps.show:null
const submitHook=deps.submitHook&&typeof deps.submitHook.attach==='function'?deps.submitHook:null
const isLocked=typeof deps.isLocked==='function'?deps.isLocked:null
const setLock=typeof deps.setLock==='function'?deps.setLock:null
const deadLocks=typeof deps.deadLocks==='function'?deps.deadLocks:null
const searchBuy=typeof deps.searchBuy==='function'?deps.searchBuy:null
const autoBuy=deps.autoBuy&&typeof deps.autoBuy.confirmPrices==='function'&&typeof deps.autoBuy.run==='function'
?deps.autoBuy:null
const askConfirm=typeof deps.askConfirm==='function'?deps.askConfirm:null
const eaNotice=typeof deps.eaNotice==='function'?deps.eaNotice:null
const livePairs=typeof deps.livePairs==='function'?deps.livePairs:null
const adopt=typeof deps.adopt==='function'?deps.adopt:null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let last=null
let scheduled=false
let lastResult={ok:false,reason:'not-run'}
let lastShow={ok:false,reason:'not-run',detail:null,notice:null,saved:null,sent:null,passport:null,saveReason:null}
const closedFolds=new Set()
let shownFolds=new Set()
let lastBuySearch={ok:false,reason:'not-run',detail:null,maxBuy:null,applied:null}
let priceToken=0
let autoBuyState={phase:'idle',total:0,worst:0,cards:0,done:0,spent:0,note:null,targets:[],skips:[],stop:null,said:null,why:null,door:null,at:null,detail:null,count:null,only:null}
let pickedSlot=null
try{doc?.addEventListener?.('keydown',(event)=>{try{
if(disposed===true)return
if(event?.repeat===true)return
if(keyOfEvent(event)!=='4')return
if(event.ctrlKey||event.altKey||event.metaKey||event.shiftKey)return
if(isTypingTarget(realTarget(event)))return
keySeen+=1
if(current.key===null||current.key===undefined)return noteKey('no-key')
if(!doc?.querySelector?.(SUBMIT_TAB_SELECTOR))return noteKey('no-screen')
if(autoBuy===null)return noteKey('no-door')
if(statusOf(AUTO_BUY_FEATURE)==='not-entitled'||isActive(AUTO_BUY_FEATURE)!==true)return noteKey('not-entitled')
if(current.result?.market!==true||(current.result?.buys??[]).length===0)return noteKey('no-buys')
noteKey('passed')
event.preventDefault?.()
event.stopPropagation?.()
keyPresses+=1
pressAutoBuy({one:true,spendNow:true,needsPick:true,byKey:true})}catch(err){onError(err)}},true)}catch(err){onError(err)}
try{doc?.addEventListener?.('click',(event)=>{try{if(disposed===true)return
const at=event?.target?.closest?.(SLOT_SELECTOR)
if(!at){
if(event?.target?.closest?.(WINDOW_SELECTOR))return
pickedSlot=null
return}
const index=Number(at.getAttribute('index'))
pickedSlot=Number.isInteger(index)&&index>=0?index:null}catch(err){onError(err)}},true)}catch(err){onError(err)}
let buyingNow=false
const batchLive=()=>{if(buyingNow===true)return true
if(autoBuy===null||typeof autoBuy.busy!=='function')return false
try{return autoBuy.busy()===true}catch(err){onError(err)
return false}}
let queuedByBuy=false
const resetAutoBuy=(note=null)=>{priceToken+=1
autoBuyState={phase:'idle',total:0,worst:0,cards:0,done:0,spent:0,note,targets:[],skips:[],stop:null,said:null,why:null,door:null,at:null,detail:null,count:null,only:null}}
let painted=null
const blank=()=>({key:null,busy:false,progress:null,said:null,result:null,warn:null,live:null,showing:false,shown:false,stale:false,guard:null,submitted:false,locked:[],lockFail:null,answered:false,redo:false,redoFailed:false,cheaper:null,adopted:false,offer:null})
let current=blank()
const sayOf=(notice,why)=>(notice&&typeof notice.key==='string'
?{key:notice.key,params:notice.params??null,why}:null)
function shieldNotice(result){if(result?.notice?.params?.reason!=='not-enough-players')return null
const shield=result?.pool?.shield
if(!shield||shield.enough!==true)return null
const locked=Number.isFinite(shield.locked)?shield.locked:0
const active=Number.isFinite(shield.active)?shield.active:0
if(locked+active<=0)return null
const params={free:shield.free,club:shield.eligible,need:shield.need,locked,active}
if(locked>0&&active>0)return{key:'sbcWindow.shieldBoth',params}
if(locked>0)return{key:'sbcWindow.shieldLocked',params}
return{key:'sbcWindow.shieldActive',params}}
function flashKind(){if(reading===true)return'reading'
if(current.busy===true)return current.redo===true?'redo':'solving'
if(current.showing===true)return'showing'
if(background===true&&current.busy!==true)return'cheapening'
return null}
const mode=MODE_CLUB
function accessNow(){if(tradeAccess===null)return{known:false,allowed:false,consoleOnly:false}
try{const value=tradeAccess()
return{known:value?.known===true,allowed:value?.allowed===true,consoleOnly:value?.consoleOnly===true}}catch(err){onError(err)
return{known:false,allowed:false,consoleOnly:false}}}
const activeMode=()=>MODE_CLUB
let reading=false
let request=0
let cancels=0
const seen={entries:0,updates:0,solves:0,preempted:0,cancelled:0}
const locks={clicks:0,writes:0,solves:0,last:null}
let retries=0
let chainId=0
let chainRedo=0
let chainCheapen=0
let background=false
let cheapenTicket=null
let cheapenHybrid=false
let cheapenRescue=false
let cheapenStalled=false
let cheapenChain=null
let cheapenDoor=null
let hybridOutcome=null
const sayOutcome=(value)=>{hybridOutcome=value
const seek=current?.result?.search
if(seek&&typeof seek==='object')seek.phase={...value,last:cheapenLast===null?null:{...cheapenLast}}}
const hybridSeen={open:0,'feature-off':0,submitted:0,'access-unknown':0,'console-only':0,'market-closed':0,'frozen-hit':0,
'cheapen-off':0,
'no-search':0,'redo-pending':0}
let cheapenPercent=null
let cheapenMark=null
let cheapenAt=0
let cheapenLast=null
const cheapenSeen={started:0,adopted:0,rejected:0,rescued:0,offered:0}
let adoptFailed=0
let offerTaken=0
let offerBack=0
let offerRefused=0
let offerRestored=0
const offers=new Map()
let cheapenCancelBy=null
let cheapenCeiling=null
let cheapenBase=null
let cheapenRungs=0
let cheapenLadder=null
let cheapenRebuilds=0
let disposed=false
const REDO_TIME_MS=15000
let watch={dispose(){},ok:false,reason:'not-run',state:()=>null}
const placed=new Map()
const memoStats={hits:0,misses:0,key:null,stored:null}
let squadWatch={dispose(){},ok:false,reason:'not-run'}
let watched=null
let signed=''
let hand=0
let pendingShow=false
const pitch={changes:0,clears:0,solves:0}
const DOOR_LOG_MAX=64
const doors={by:Object.create(null),log:[]}
let openDoor=null
const doorRow=(name)=>{const key=String(name??'unknown')
const had=doors.by[key]
if(had)return had
const row={calls:0,solves:0,buyCalls:0,buySolves:0,memo:0,refused:null,ms:null,last:null}
doors.by[key]=row
return row}
const knock=(name,why=null)=>{const key=String(name??'unknown')
const row=doorRow(key)
row.calls+=1
const buying=buyingNow===true
if(buying)row.buyCalls+=1
row.last={at:now(),buying,why:why===null?null:String(why)}
const line={door:key,at:row.last.at,buying,why:row.last.why,
shown:current.shown===true,showing:current.showing===true,busy:current.busy===true,
ours:(placed.get(current.key)??new Set).size,lineup:(current.result?.lineup??[]).length,solved:false}
if(doors.log.length>=DOOR_LOG_MAX)doors.log.shift()
doors.log.push(line)
return false}
const doorSolved=(name)=>{const key=String(name??'unknown')
const row=doorRow(key)
row.solves+=1
const buying=buyingNow===true
if(buying)row.buySolves+=1
openDoor={door:key,at:now(),memo:false}
for(let i=doors.log.length-1;i>=0;i-=1){if(doors.log[i].door===key){doors.log[i].solved=true
break}}}
const doorRefused=(name,why)=>{const row=doorRow(name)
row.refused=String(why)
return false}
const doorDone=()=>{if(openDoor===null)return
const row=doorRow(openDoor.door)
row.ms=Math.max(0,now()-openDoor.at)
if(openDoor.memo===true)row.memo+=1
openDoor=null}
let lockedSeen=''
let excludedIds=[]
const boughtSwaps=new Map()
let lockGenSeen=lockGenerationNow()
let lockGenKnown=lockGenSeen!==null
let solveLocks=null
let writing=false
if(submitHook)submitHook.observe((verdict)=>{current={...current,guard:verdict??null}
redraw()})
if(typeof submitHook?.observeDoors==='function')submitHook.observeDoors(()=>redraw())
const record=(result)=>{lastResult=result
return result}
const keyOf=frozenKeyOf
function apply(capture){if(!doc||!capture?.root)return record({ok:false,reason:'no-capture'})
const key=keyOf(capture.challenge)
const known=last?.challenge??null
const knownSquad=watched
last={root:capture.root,challenge:capture.challenge,set:capture.set,controller:capture.controller??null,key,hook:capture.hook??null}
if(key===null)return record({ok:false,reason:'no-challenge'})
const entry=capture.hook===HOOK_ENTER||key!==current.key
if(entry)knock('entry',capture.hook===HOOK_ENTER?'hook-enter':'new-key')
else knock('update',capture.hook??null)
const held=entry&&buyingNow===true&&capture.hook===HOOK_ENTER&&key===current.key
if(held)doorRefused('entry','buying')
if(entry)seen.entries+=1
else seen.updates+=1
if(entry&&!held){request+=1
lockedSeen=''
pendingShow=false
cheapenRebuilds=0
cheapenLadder=null
current={...blank(),key}
resetAutoBuy()
excludedIds=[]
pickedSlot=null
if(onEnterChallenge!==null){try{onEnterChallenge()}catch(err){onError(err)}}}
if(capture.challenge!==known)listen(capture.challenge)
listenSquad(capture.challenge)
if(background===true&&(capture.challenge!==known||watched!==knownSquad))cancel()
if(submitHook){if(isActive(SBC_FEATURE))submitHook.attach(capture)
else submitHook.detach()}
schedule()
if(entry&&!held)autosolve()
return record({ok:true,reason:'pending',entry,held})}
function listen(challenge){watch.dispose()
if(!onSubmitted){watch={dispose(){},ok:false,reason:'no-listener',state:()=>null}
return}
const subscription=observeChallengeSubmitted(challenge,(ids)=>{try{onSubmitted(ids)}catch(err){onError(err)}
frozen.drop(current.key,'submitted')
placed.delete(current.key)
boughtSwaps.delete(current.key)
current={...blank(),key:current.key,submitted:true,said:sayOf({key:'sbc.submitted',params:{}},'submitted')}
redraw()})
watch={dispose:subscription.dispose,ok:subscription.ok===true,reason:subscription.reason??null,state:typeof subscription.state==='function'?subscription.state:()=>null}}
function listenSquad(challenge){const squad=challenge?.squad??null
if(squad===watched&&squadWatch.ok)return
squadWatch.dispose()
watched=squad
signed=squadFieldSignature(squad).signature
if(!squad){squadWatch={dispose(){},ok:false,reason:'no-squad'}
return}
const subscription=observeSquadChanges(squad,()=>{try{onFieldChanged()}catch(err){onError(err)}})
squadWatch={dispose:subscription.dispose,ok:subscription.ok===true,reason:subscription.reason??null}}
function onFieldChanged(){if(!watched)return
if(current.showing===true||buyingNow){const held=squadFieldSignature(watched)
if(held.signature!==signed)knock('field',current.showing===true?'showing':'buying')
signed=held.signature
return}
const now=squadFieldSignature(watched)
if(now.signature===signed)return
signed=now.signature
pitch.changes+=1
knock('field')
if(now.count===0){pitch.clears+=1
placed.delete(current.key)
current={...current,shown:false,stale:false,live:null,guard:null}}
redraw()
rebuild(()=>{pitch.solves+=1},{door:'field'})}
function rebuild(onSolved=()=>{},opts={}){const ticket=++hand
cancel()
let left=REBUILD_TRIES
const tick=()=>{if(ticket!==hand||!isActive(SBC_FEATURE))return
if(run({preempt:true,force:opts.force===true,door:opts.door})){onSolved()
return}
if(working()&&left>0){left-=1
defer(tick)}}
defer(tick)}
function cancel(){
if(current.busy!==true&&background!==true)return false
request+=1
cancels+=1
seen.cancelled+=1
return true}
function schedule(){if(scheduled)return
scheduled=true
Promise.resolve().then(()=>{scheduled=false
try{settle()}catch(err){onError(err)}})}
function settle(){if(!last)return record({ok:false,reason:'no-capture'})
const content=challengeContentOf(last.root)
if(!content)return record({ok:false,reason:'detached'})
if(last.key===null){drop(content)
return record({ok:false,reason:'no-challenge'})}
ensureControls(doc)
ensureSbcWindowStyles(doc)
ensureSidebarStyles(doc)
const host=mount(content)
if(!host)return record({ok:false,reason:'no-window'})
const drawn=paint(host)
return record({ok:true,reason:null,key:last.key,busy:current.busy,drawn})}
function paint(host){const now=signature()
if(painted&&painted.host===host&&painted.signature===now)return false
render(host)
painted={host,signature:now}
return true}
function signature(){const verdict=current.result?.verdict??null
const live=current.live??null
const burn=current.result?.burn??null
const price=current.result?.price??null
const cache=cacheSnapshot()
const hook=hookState()
return JSON.stringify([last?.key??null,isActive(SBC_FEATURE),statusOf(SBC_FEATURE),t('sbcWindow.title'),
mode,current.result?.market===true,current.result?.spend??null,(current.result?.buys??[]).length,
(()=>{const one=accessNow()
return[one.known,one.allowed,one.consoleOnly]})(),
[...closedFolds].sort().join(','),lastBuySearch.ok,lastBuySearch.reason,
autoBuyState.phase,autoBuyState.total,autoBuyState.done,autoBuyState.spent,autoBuyState.note,autoBuyState.skips,autoBuyState.stop,autoBuyState.said,
autoBuyState.only,
autoBuyState.count?.done??null,autoBuyState.count?.cards??null,
isActive(AUTO_BUY_FEATURE),statusOf(AUTO_BUY_FEATURE),current.busy,current.progress,current.submitted,reading,current.showing,current.shown,current.stale,current.lockFail,
current.redo,current.redoFailed,current.answered,
background,cheapenPercent,current.cheaper?.key??null,current.cheaper?.params?.coins??null,
current.cheaper?.params?.out??null,current.cheaper?.params?.in??null,
offerAlive(),current.offer?.taken===true,current.offer?.savings??null,current.offer?.spend??null,
pendingShow,hook?[hook.ok,hook.missing?.length??0,(hook.faults??0)+(hook.errors??0)]:null,cache?[cache.size,cache.readAt]:null,
storageCount(),current.said?.key??null,current.said?.params??null,current.said?.why??null,current.warn?.key??null,verdict?[verdict.ratingExact,verdict.rating,verdict.ratingMet,verdict.chemistry]:null,live?[live.rating,live.chemistry,live.ratingMet,live.chemistryMet]:null,burn?[burn.cost,burn.unknown,burn.priced,burn.mine]:null,price?[price.total,price.unknown,price.priced]:null,(current.result?.failed??[]).map((row)=>[row?.key,row?.have,row?.need,row?.value]),
lines().map((row)=>[row.id,row.price,row.duplicate,row.untradeable,row.mine,lockedNow(row.lock),row.parked]),
(current.guard?.blockers??[]).map((row)=>[row?.code,row?.confirmable,row?.ids]),current.guard?.warnings??null,
deadLockRows().map((row)=>[row.id,row.name])])}
function lines(){const rows=[...(current.result?.lineup??[])]
const standing=new Set(rows.map((row)=>String(row?.id??'')))
for(const row of current.locked){if(!standing.has(String(row?.id??''))&&lockedNow(row?.lock))rows.push({...row,parked:true})}
return rows}
function openBuy(id){if(searchBuy===null)return false
const prepared=current.result?.prepared
if(!prepared){lastBuySearch={ok:false,reason:'no-verdict',detail:null}
redraw()
return false}
let result=null
try{result=searchBuy(prepared,id)}catch(err){onError(err)
result={ok:false,reason:'failed',detail:String(err?.message??err)}}
lastBuySearch={ok:result?.ok===true,reason:result?.reason??null,detail:result?.detail??null,
maxBuy:result?.maxBuy??null,applied:result?.applied??null}
redraw()
return lastBuySearch.ok===true}
function buySearchNotice(){if(lastBuySearch.ok===true)return null
const reason=lastBuySearch.reason
if(reason===null||reason==='not-run')return null
return reason==='not-on-pitch'
?t('sbcWindow.buyNeedsPitch')
:t('sbcWindow.buySearchFailed',{reason})}
function lockKey(){return(current.result?.lineup??[]).filter((row)=>lockedNow(row?.lock)).map((row)=>String(row?.id??'')).join(',')}
function syncLocks(){if(writing)return false
if(lockChangedOutside()){forgetByLock('lock-changed')
if(background===true)cancel()}
if(current.busy===true){const now=lockGenerationNow()
if(now===null||now===solveLocks)return false
solveLocks=now
rebuild(()=>{locks.solves+=1},{force:true})
return true}
const lineup=current.result?.lineup
if(!Array.isArray(lineup))return false
const key=lockKey()
if(key===lockedSeen)return false
lockedSeen=key
if(key==='')return false
const rows=(current.result?.lineup??[]).filter((row)=>lockedNow(row?.lock))
const known=new Set((current.locked??[]).map((row)=>row?.lock))
const add=rows.filter((row)=>!known.has(row?.lock)).map((row)=>({...row,parked:true}))
if(add.length>0)current={...current,locked:[...(current.locked??[]),...add]}
rebuild(()=>{locks.solves+=1},{force:true})
return true}
function forgetByLock(why){lockGenSeen=lockGenerationNow()
lockGenKnown=true
return frozen.dropAll(why)>0}
function lockChangedOutside(){if(!lockGeneration)return false
const now=lockGenerationNow()
if(now===null)return false
if(!lockGenKnown){lockGenKnown=true
lockGenSeen=now
return false}
return now!==lockGenSeen}
function lockedNow(lock){if(!isLocked||!Number.isSafeInteger(lock))return false
try{return isLocked(lock)===true}catch(err){onError(err)
return false}}
function mount(content){const existing=content.querySelector?.(WINDOW_SELECTOR)??null
if(existing)return existing
const node=el(doc,'section',{class:'fut-sbc-window',dataset:{futSbcWindow:'1'}})
const anchor=challengeAnchorOf(content)
if(anchor)content.insertBefore(node,anchor)
else content.appendChild(node)
return node}
function render(host){clear(host)
host.appendChild(el(doc,'div',{class:'fut-sbc-head'},[logoLink(doc),el(doc,'span',{class:'fut-sbc-title',text:t('sbcWindow.title')})]))
const status=statusOf(SBC_FEATURE)
if(!isActive(SBC_FEATURE)){host.appendChild(el(doc,'div',{class:'fut-sbc-locked',text:t(status==='switched-off'?'settings.switchedOff':'license.premiumRequired')}))
return}
const solving=current.busy===true
const retrying=retryReady()
if(((showOnPitch&&(current.result?.ok===true||solving))||retrying)&&!current.shown&&!current.submitted){const queued=pendingShow===true
const blocked=current.showing===true||reading===true
host.appendChild(el(doc,'button',{class:queued?'fut-sbc-show is-queued':'fut-sbc-show',
text:retrying?t('sbcWindow.retry'):queued?t('sbcWindow.showQueued'):t('sbcWindow.show'),
attrs:blocked?{type:'button',disabled:'disabled'}:{type:'button'},
dataset:{futSbcShow:'1',...(retrying?{futSbcRetry:'1'}:{}),...(queued?{futSbcShowQueued:'1'}:{})},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{press()}catch(err){onError(err)}}}}))}
const ready=readyModel({t,result:current.result,busy:current.busy===true})
const badge=guardBadgeModel({t,hook:hookState()})
if(ready||badge){const state=el(doc,'div',{class:'fut-sbc-state'})
if(ready)state.appendChild(el(doc,'span',{class:'fut-sbc-ready',dataset:{futSbcReady:'1'},text:ready.text}))
if(badge)state.appendChild(el(doc,'span',{class:`fut-sbc-badge${badge.level==='on'?'':badge.level==='none'?' is-off is-none':' is-off'}`,dataset:{futSbcGuardBadge:badge.level}},
[badge.ok?el(doc,'span',{class:'fut-sbc-badge-dot'}):null,el(doc,'span',{text:badge.text})]))
host.appendChild(state)}
const flash=flashKind()
if(flash!==null)host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcStatus:'1',futSbcSay:'flash'},
text:flash==='reading'?t('sbcWindow.cacheRefreshing')
:flash==='showing'?t('sbcWindow.showing')
:flash==='redo'?(Number.isFinite(current.progress)?t('sbcWindow.redoing',{percent:current.progress}):t('sbcWindow.redo'))
:flash==='cheapening'?cheapenSay()
:Number.isFinite(current.progress)?t('sbcWindow.solving',{percent:current.progress}):t('sbcWindow.busy')}))
const dead=deadLockRows()
const solvedSay=current.said?.key==='sbc.solved'
if(current.said&&!solvedSay&&!(dead.length>0&&current.said.key===RECREATED_WALL)){const warn=SAVE_REFUSALS.has(current.said.key)
host.appendChild(el(doc,'div',{class:warn?'fut-sbc-status fut-sbc-stale':'fut-sbc-status',
dataset:{futSbcStatus:'1',futSbcSay:current.said.why,...(warn?{futSbcSaveWarn:'1'}:{})},text:t(current.said.key,current.said.params)}))}
if(current.redoFailed===true)host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcStatus:'1',futSbcRedoFailed:'1'},text:t('sbcWindow.redoFailed')}))
if(current.cheaper)host.appendChild(el(doc,'div',{class:'fut-sbc-status fut-sbc-stale',
dataset:{futSbcStatus:'1',futSbcCheaper:current.cheaper.key==='sbcWindow.cheaperReshow'?'reshow'
:current.cheaper.key==='sbcWindow.rescueFound'?'rescue'
:current.cheaper.key==='sbcWindow.rescueUnfinished'?'stalled':'found'},
text:t(current.cheaper.key,current.cheaper.params)}))
if(current.warn)host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcWarn:'1'},text:t(current.warn.key,current.warn.params)}))
const model=resultModel({t,result:current.result,live:current.live})
for(const note of[[model.rating?.drift,'futSbcDrift']]){
if(!note[0])continue
host.appendChild(el(doc,'div',{class:'fut-sbc-status fut-sbc-drift',dataset:{[note[1]]:'1'},text:note[0]}))}
const gap=marketGapModel({t,result:current.result})
if(gap)host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcMarketGap:'1'},text:gap.text}))
const capped=current.adopted===true||offerAlive()?null:searchCapModel({t,result:current.result,background,
phase:cheapenLast!==null&&cheapenLast.chain===chainId?cheapenLast:null})
if(capped)host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcExhausted:'1'},text:capped.text}))
for(const row of model.failed){host.appendChild(el(doc,'div',{class:'fut-sbc-failed',dataset:{futSbcFailed:row.id},text:row.label}))}
if(current.stale&&!current.shown&&!current.submitted){host.appendChild(el(doc,'div',{class:'fut-sbc-stale',dataset:{futSbcStale:'1'},text:t('sbcWindow.stale')}))}
if(current.lockFail)host.appendChild(el(doc,'div',{class:'fut-sbc-stale',dataset:{futSbcLockFail:'1'},text:t('sbcWindow.lockFailed',{why:current.lockFail})}))
if(dead.length>0)host.appendChild(deadLockBlock(dead))
const guarded=guardModel({t,guard:current.guard,names:current.guard?.names instanceof Map?current.guard.names:selectionNames()})
if(guarded.lines.length>0){const block=el(doc,'div',{class:'fut-sbc-guard',dataset:{futSbcGuard:'1'}})
for(const line of guarded.lines)block.appendChild(el(doc,'div',{class:'fut-sbc-guard-line',text:line}))
if(guarded.again)block.appendChild(el(doc,'div',{class:'fut-sbc-guard-again',dataset:{futSbcGuardAgain:'1'},text:guarded.again}))
host.appendChild(block)}
const offerRow=offerModel({t,offer:offerAlive()?current.offer:null})
if(offerRow){const taken=offerRow.taken===true
const parts=[]
if(offerRow.text!==null)parts.push(el(doc,'span',{class:'fut-sbc-offer-text',text:offerRow.text}))
parts.push(el(doc,'button',{class:'fut-sbc-offer-act',text:offerRow.action,
attrs:working()?{type:'button',disabled:'disabled'}:{type:'button'},
dataset:taken?{futSbcOfferBack:'1'}:{futSbcOfferShow:'1'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{if(taken)pressOfferBack()
else pressOffer()}catch(err){onError(err)}}}}))
host.appendChild(el(doc,'div',{class:'fut-sbc-offer',dataset:{futSbcOffer:taken?'taken':'open'}},parts))}
const why=whyModel({t,result:current.result})
const source=lines()
const lineRows=lineupModel({t,rows:source,isLocked:lockedNow,nameOf:staticNameOf})
const folds=[]
if(why?.tight===true){host.appendChild(el(doc,'div',{class:'fut-sbc-why is-tight',
dataset:{futSbcWhy:'tight'},text:why.text}))}
if(lineRows.length>0){folds.push({id:FOLD_LINEUP,title:t('sbcWindow.foldLineup',{count:lineRows.length}),
fill:(box)=>{
const ok=current.result?.ok===true&&current.result?.prepared!==null&&current.result?.prepared!==undefined
const list=el(doc,'div',{class:'fut-sbc-list',dataset:{futSbcList:'1'}})
lineRows.forEach((row,index)=>{
const opens=row.buy===true&&row.known===true&&ok
const door=opens?{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{openBuy(row.id)}catch(err){onError(err)}},
keydown:(event)=>{const key=event?.key
if(key!=='Enter'&&key!==' '&&key!=='Spacebar')return
event?.preventDefault?.()
event?.stopPropagation?.()
try{openBuy(row.id)}catch(err){onError(err)}}}:{}
const classes=row.parked?'fut-sbc-line is-parked':(opens?'fut-sbc-line fut-sbc-buy':'fut-sbc-line')
const mark={futSbcLine:row.id}
if(row.buy===true)mark.futSbcBuy=row.id
list.appendChild(el(doc,'div',{class:classes,dataset:mark,
attrs:opens?{role:'button',tabindex:'0',title:t('sbcWindow.buySearch')}:{},on:door},[
el(doc,'span',{class:'fut-sbc-line-head'},[el(doc,'span',{class:'fut-sbc-line-name',text:row.name}),
row.mine?el(doc,'span',{class:'fut-sbc-mark is-mine',dataset:{futSbcMine:'1'},text:row.mineLabel}):null,
row.locked?el(doc,'span',{class:'fut-sbc-mark is-locked',dataset:{futSbcLocked:'1'},text:row.lockedLabel}):null]),
...row.marks.map((mark)=>el(doc,'span',{class:'fut-sbc-mark',text:mark})),
el(doc,'span',{class:'fut-sbc-line-price',text:row.price,
attrs:row.estimate===true?{title:t('sbcWindow.buyEstimateHint')}:{}}),
lockButton(row,source[index])]))})
box.appendChild(list)
if(!ok&&lineRows.some((row)=>row.buy===true))box.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcBuysReference:'1'},text:t('sbcWindow.buysReference')}))
const failed=buySearchNotice()
if(failed)box.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcBuyFailed:'1'},text:failed}))}})}
paintFolds(host,folds)
const pitched=current.result?.ok===true&&current.result?.prepared!==null&&current.result?.prepared!==undefined&&current.shown===true
const buyAll=autoBuyModel({t,result:current.result,state:autoBuyState,done:closedTargets(current.key),
live:current.live??null,
entitled:statusOf(AUTO_BUY_FEATURE)!=='not-entitled',active:isActive(AUTO_BUY_FEATURE),
ready:pitched,available:autoBuy!==null,busy:batchLive()})
if(buyAll){
const row=el(doc,'div',{class:'fut-sbc-buyrow',dataset:{futSbcBuyRow:'1'}})
row.appendChild(el(doc,'button',{
class:buyAll.armed?'fut-sbc-buyall is-armed':'fut-sbc-buyall',
text:buyAll.label,
attrs:buyAll.disabled?{type:'button',disabled:'disabled'}:{type:'button'},
dataset:{futSbcBuyAll:buyAll.phase},
on:buyAll.disabled?{}:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{pressAutoBuy()}catch(err){onError(err)}}}}))
host.appendChild(row)
if(buyAll.hint)host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcBuyAllHint:'1'},text:buyAll.hint}))
if(autoBuyState.count){host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcBuyCount:'1'},
text:t('sbcBuy.counting',{done:autoBuyState.count.done,cards:autoBuyState.count.cards})}))}
if(typeof autoBuyState.stop==='string'&&autoBuyState.stop!==''){host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcBuyStop:'1'},text:autoBuyState.stop}))}
if(typeof autoBuyState.said==='string'&&autoBuyState.said!==''){host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcBuySwap:'1'},text:autoBuyState.said}))}
for(const line of Array.isArray(autoBuyState.skips)?autoBuyState.skips:[]){host.appendChild(el(doc,'div',{class:'fut-sbc-status',dataset:{futSbcBuySkip:'1'},text:line}))}}
const cache=cacheSnapshot()
if(cache){const row=cacheModel({t,coins,cache,storage:storageCount()})
const parts=[row.text===null?null:el(doc,'span',{class:'fut-sbc-cache-text',text:row.text}),el(doc,'button',{class:'fut-sbc-cache-refresh',text:row.action,attrs:working()?{type:'button',disabled:'disabled'}:{type:'button'},dataset:{futSbcRebuild:'1'},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{pressRebuild()}catch(err){onError(err)}}}})]
if(row.warn!==null)parts.push(el(doc,'span',{class:'fut-sbc-cache-warn',text:row.warn,dataset:{futSbcCacheWarn:'1'}}))
host.appendChild(el(doc,'div',{class:'fut-sbc-cache',dataset:{futSbcCache:'1'}},parts))}
}
function paintFolds(host,folds){shownFolds=new Set()
if(folds.length===0){try{host.classList?.remove?.('has-fold')}catch{/* узел чужой */}
return}
const open=folds.filter((one)=>!closedFolds.has(one.id))
const shown=open.length>0?open:[folds[0]]
for(const one of shown)shownFolds.add(one.id)
try{host.classList?.add?.('has-fold')}catch{/* узел чужой */}
const lastOpen=shown[shown.length-1].id
for(const one of folds){const isOpen=shownFolds.has(one.id)
const box=el(doc,'div',{class:isOpen?(one.id===lastOpen?'fut-sbc-fold is-open is-last':'fut-sbc-fold is-open'):'fut-sbc-fold',dataset:{futSbcFold:one.id,futSbcFoldOpen:isOpen?'1':'0'}})
box.appendChild(el(doc,'div',{class:'fut-sbc-fold-head',
attrs:{role:'button',tabindex:'0','aria-expanded':isOpen?'true':'false',
title:t(isOpen?'sbcWindow.buysHide':'sbcWindow.buysShow')},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{toggleFold(one.id)}catch(err){onError(err)}},
keydown:(event)=>{const key=event?.key
if(key!=='Enter'&&key!==' '&&key!=='Spacebar')return
event?.preventDefault?.()
event?.stopPropagation?.()
try{toggleFold(one.id)}catch(err){onError(err)}}}},
[el(doc,'span',{class:'fut-sbc-fold-title',text:one.title}),
el(doc,'span',{class:'fut-sbc-fold-sign',text:isOpen?'▾':'▸'})]))
if(isOpen){const body=el(doc,'div',{class:'fut-sbc-fold-body',dataset:{futSbcFoldBody:one.id}})
one.fill(body)
box.appendChild(body)}
host.appendChild(box)}}
function toggleFold(id){if(shownFolds.has(id)){
if(shownFolds.size<=1)return false
closedFolds.add(id)}
else closedFolds.delete(id)
redraw()
return true}
function deadLockRows(){if(deadLocks===null)return[]
let rows
try{rows=deadLocks()}catch(err){onError(err)
return[]}
const out=[]
for(const row of Array.isArray(rows)?rows:[]){const id=row?.id
if(id===null||id===undefined||id==='')continue
out.push({id,name:typeof row?.name==='string'&&row.name.trim()!==''?row.name.trim():null})}
return out}
const deadLockFace=(row)=>row.name??String(row.id)
function deadLockBlock(rows){const block=el(doc,'div',{class:'fut-sbc-guard',dataset:{futSbcDeadLocks:String(rows.length)}})
block.appendChild(el(doc,'div',{class:'fut-sbc-guard-line',text:t(RECREATED_WALL,{cards:rows.map(deadLockFace).join(', ')})}))
for(const row of rows){const droppable=setLock!==null&&Number.isSafeInteger(row.id)&&row.id>0
if(!droppable)continue
const title=t('clubLocked.dropHint')
const attrs=working()?{type:'button',title,disabled:'disabled'}:{type:'button',title}
block.appendChild(el(doc,'div',{class:'fut-sbc-dead',dataset:{futSbcDead:String(row.id)}},[
rows.length>1?el(doc,'span',{class:'fut-sbc-dead-name',text:deadLockFace(row)}):null,
el(doc,'button',{class:'fx-action fut-sbc-dead-drop',text:t('clubLocked.drop'),attrs,
dataset:{futSbcLockDrop:String(row.id)},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{toggleLock(row.id,null,false)}catch(err){onError(err)}}}})]))}
return block}
function lockButton(row,source){if(!setLock||!isLocked||row.lock===null)return null
const title=t(row.locked?'sell.lock.on':'sell.lock.off')
const attrs={type:'button',title,'aria-label':title}
return el(doc,'button',{class:'fut-card-lock fut-sbc-lock',attrs:working()?{...attrs,disabled:'disabled'}:attrs,
dataset:{futSbcLock:String(row.lock),futCardLockOn:row.locked?'1':'0'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{toggleLock(row.lock,source)}catch(err){onError(err)}}}})}
function toggleLock(lock,source=null,want=null){if(!Number.isSafeInteger(lock))return false
locks.clicks+=1
if(working()||!setLock){const why=working()?'busy':'no-storage'
locks.last={id:lock,on:null,wrote:false,solved:false,why}
fail(why)
return false}
const on=want===null?!lockedNow(lock):want===true
const raw=source??(current.result?.lineup??[]).find((row)=>row?.lock===lock)??null
writing=true
let wrote=false
try{wrote=setLock(lock,on,on?raw?.name:undefined)===true}finally{writing=false}
if(wrote)locks.writes+=1
if(!wrote){locks.last={id:lock,on,wrote:false,solved:false,why:'write-refused'}
fail('write-refused')
return false}
current={...current,lockFail:null}
forgetByLock(on?'locked':'unlocked')
if(on&&raw&&!(current.locked??[]).some((row)=>row?.lock===lock))current={...current,locked:[...(current.locked??[]),{...raw,parked:true}]}
lockedSeen=lockKey()
redraw()
knock('lock')
const solved=run({force:true,door:'lock'})
if(solved)locks.solves+=1
else rebuild(()=>{locks.solves+=1
locks.last={...locks.last,solved:true,why:'solved-later'}},{force:true,door:'lock'})
locks.last={id:lock,on,wrote:true,solved,why:solved?null:'solve-refused'}
return true}
function fail(why){current={...current,lockFail:String(why)}
redraw()}
function working(){return current.busy===true||reading===true||current.showing===true}
function hookState(){if(!submitHook)return null
try{const state=submitHook.state()
return state&&typeof state==='object'?state:null}catch{return null}}
function warmState(){if(warmStats===null)return null
try{const state=warmStats()
return state&&typeof state==='object'?state:null}catch(err){onError(err)
return null}}
function cacheSnapshot(){if(!cacheState)return null
try{const state=cacheState()
return state&&typeof state==='object'?state:null}catch{return null}}
function pressRebuild(){if(working())return false
const hunger=cacheSnapshot()?.hunger
if(hunger&&typeof hunger==='object'&&hunger.ok===false&&hunger.reason!=='day-limit'
&&reread()===true)return true
knock('rebuild')
cheapenRebuilds+=1
current={...current,guard:null}
redraw()
return run({force:true,door:'rebuild'})!==false}
function reread(){if(working()||!refreshCache)return false
knock('reread')
cancel()
reading=true
current={...current,guard:null}
redraw()
Promise.resolve()
.then(()=>refreshCache())
.then(()=>{reading=false
redraw()
run({force:true,door:'reread'})})
.catch((err)=>{reading=false
onError(err)
redraw()})
return true}
function selectionNames(){const map=new Map
for(const item of current.result?.prepared?.selection??[]){const id=String(item?.id??'')
if(id!=='')map.set(id,cardTag(item,id))}
return map}
function run(opts={}){const door=String(opts.door??'unknown')
if(!solve||!last?.challenge)return doorRefused(door,'no-challenge')
if(reading===true||current.showing===true)return doorRefused(door,reading===true?'reading':'showing')
if(current.busy===true){if(opts.preempt!==true)return doorRefused(door,'busy')
if(opts.redo!==true)seen.preempted+=1}
const ticket=++request
const world=cancels
const key=current.key
seen.solves+=1
doorSolved(door)
if(opts.redo===true)phases.pass()
else if(!phases.isChain(opts.entryChain))phases.begin('run')
phases.at('prep')
if(opts.redo!==true){chainId+=1
chainRedo=0
chainCheapen=0
pendingShow=false}
const force=opts.force===true
solveLocks=lockGenerationNow()
if(lockChangedOutside())forgetByLock('lock-changed')
lockGenSeen=solveLocks
lockGenKnown=true
const mark=inputMark()
const calm=calmMark()
const squad=squadNow()
let hit=force||key===null?null:frozen.get(key,mark,squad)
let asked=mark
if(hit===null&&!force&&key!==null&&calm!==mark){hit=frozen.get(key,calm,squad)
if(hit!==null)asked=calm}
if(openDoor!==null)openDoor.memo=hit?true:false
memoStats.key=asked
phases.note('memo',hit?true:false)
if(!force&&key!==null){if(hit)memoStats.hits+=1
else memoStats.misses+=1}
current={...current,busy:true,progress:null,said:null,result:null,warn:null,live:null,shown:false,stale:current.shown===true||current.stale===true,guard:null,submitted:false,answered:false,redo:opts.redo===true,redoFailed:false,cheaper:null,adopted:false,offer:null}
resetAutoBuy()
redraw()
let noticed=null
const report=(warn)=>{noticed=warn&&typeof warn.key==='string'?{key:warn.key,params:warn.params??null}:null
if(ticket!==request||key!==current.key)return
current={...current,warn:noticed}
redraw()}
const pace=typeof win?.requestAnimationFrame==='function'?{pause:()=>frame(ticket),progress:(percent)=>{if(ticket!==request||key!==current.key)return
current={...current,progress:Number.isFinite(percent)?percent:null}
redraw()}}:null
const budgetOpts=opts.redo===true||excludedIds.length>0
?{...(opts.redo===true?{timeBudgetMs:REDO_TIME_MS}:{}),...(excludedIds.length===0?{}:{exclude:[...excludedIds]})}
:undefined
const answer=hit?Promise.resolve(hit.result):Promise.resolve().then(()=>solve(last.challenge,last.set,report,new Set(placed.get(key)??[]),pace,activeMode(),budgetOpts))
answer.then((result)=>{
const unfinished=result?.search?.unfinished===true
if(!hit&&key!==null&&result?.search&&!unfinished&&world===cancels)frozen.put(key,{result,warn:noticed,ids:solutionIds(result),mark:answerMark(result),squad,from:'live'})
if(ticket!==request||key!==current.key)return
phases.at('draw')
doorDone()
const ok=result?.ok===true
if(!hit)memoStats.stored=answerMark(result)
if(unfinished&&chainRedo===0){chainRedo=1
knock('redo')
if(run({force:true,redo:true,preempt:true,door:'redo'}))return
chainRedo=0}
current={...current,busy:false,progress:null,said:sayOf(shieldNotice(result)??result?.notice,'solve'),result:ok||Array.isArray(result?.failed)?result:null,
warn:hit?hit.warn??null:current.warn,
answered:true,redo:false,
redoFailed:unfinished===true&&opts.redo===true}
redraw()
if(excludeSaid!==null&&excludeSaid.key===key){const said=excludeSaid
excludeSaid=null
sayExcluded(said,result)}
if(ok)flushPendingShow()
else pendingShow=false
phases.stop()
if(armCheapen(result,Boolean(hit))!==true){restoreOffer(key,result)
startPriceQueue()}})
.catch((err)=>{if(ticket!==request)return
phases.at('draw')
doorDone()
phases.note('failed',true)
current={...current,busy:false,progress:null,answered:true}
pendingShow=false
onError(err)
redraw()
phases.stop()})
return true}
function lockGenerationNow(){if(!lockGeneration)return null
try{return String(lockGeneration())}catch(err){onError(err)
return null}}
function inputMark(){return markWith(liveTerm())}
function calmMark(){return markWith([])}
function markWith(live){return JSON.stringify([mineSlotPairs(),current.submitted===true,activeMode(),...excludeTerm(),...live])}
function usedLive(result){for(const buy of Array.isArray(result?.buys)?result.buys:[]){if(buy?.live===true)return true}
return false}
function answerMark(result){return usedLive(result)?inputMark():calmMark()}
function liveTerm(){if(livePairs===null)return[]
let pairs=null
try{pairs=livePairs()}catch(err){onError(err)
return[]}
return Array.isArray(pairs)&&pairs.length>0?[pairs]:[]}
function excludeTerm(){return excludedIds.length===0?[]:[[...excludedIds].sort((a,b)=>a-b)]}
function squadNow(){return last?.challenge?.squad??watched??null}
function mineSlotPairs(){const own=placed.get(current.key)??null
const pairs=[]
for(const[slot,id]of squadFieldSlotPairs(watched)){if(!own||!own.has(id))pairs.push([slot,id])}
return pairs.sort((a,b)=>a[0]-b[0])}
function flushPendingShow(){if(!pendingShow)return false
pendingShow=false
try{return show()}catch(err){onError(err)
return false}}
function frame(ticket){return new Promise((resolve,reject)=>{if(ticket!==request){reject(new Error('stale-solve'))
return}
win.requestAnimationFrame(()=>{if(ticket===request)resolve()
else reject(new Error('stale-solve'))})})}
const wakesCheapen=(result)=>result?.ok===true&&result?.search?.exhausted===true
function hybridDoor(){
if(wantsCheapen()!==true)return'cheapen-off'
if(!isActive(SBC_FEATURE))return'feature-off'
if(current.submitted===true)return'submitted'
const one=accessNow()
if(one.known!==true)return'access-unknown'
if(one.consoleOnly===true)return'console-only'
if(one.allowed!==true)return'market-closed'
return null}
const noPhase=(detail)=>{sayOutcome({chain:chainId,state:'not-run',detail})}
function cheapenSay(){const percent=Number.isFinite(cheapenPercent)?cheapenPercent:0
return cheapenRescue===true?t('sbcWindow.rescuing',{percent}):t('sbcWindow.cheapening',{percent})}
const cheapenTicketOf=()=>({chain:chainId,world:cancels,key:current.key,entity:last?.challenge??null,request})
const cheapenAlive=(one)=>one!==null&&one!==undefined&&disposed!==true
&&one.chain===chainId&&one.world===cancels&&one.key===current.key
&&one.entity===(last?.challenge??null)&&one.request===request
const cheapenDeath=()=>(disposed===true?'gone':'canceled')
function nextFrame(fn){const frame=win?.requestAnimationFrame
if(typeof frame!=='function')return false
frame.call(win,fn)
return true}
function phaseDone(answer){const search=answer?.search
if(search===null||search===undefined)return null
return search.exhausted!==true&&search.solverBudget?.timeStopped!==true}
function finishCheapen(why,verdict=null,answer=null){if(background!==true)return false
background=false
cheapenTicket=null
cheapenPercent=null
cheapenMark=null
const askedCeiling=cheapenCeiling
const askedFrom=cheapenBase
const askedRungs=cheapenRungs
cheapenCeiling=null
cheapenBase=null
cheapenRungs=0
const named=why==='canceled'&&cheapenCancelBy!==null?`canceled/${cheapenCancelBy}`:String(why)
cheapenCancelBy=null
cheapenLast={why:named,
chain:cheapenChain,
base:askedFrom,ceiling:askedCeiling,
rungs:askedRungs,
done:phaseDone(answer),
savings:Number.isFinite(verdict?.savings)?verdict.savings:null,
share:Number.isFinite(verdict?.share)?Math.round(verdict.share*1000)/10:null,
before:Number.isFinite(verdict?.before)?verdict.before:null,
after:Number.isFinite(verdict?.after)?verdict.after:null,
ms:Math.max(0,Math.round(now()-cheapenAt)),at:now()}
const saved=why===WHY_RESCUE||why===WHY_STALLED
const offered=why===WHY_OFFERED
if(why==='adopted'||saved||offered){cheapenSeen.adopted+=1
if(saved)cheapenSeen.rescued+=1
if(offered)cheapenSeen.offered+=1}
else cheapenSeen.rejected+=1
sayOutcome({chain:cheapenChain,state:named,detail:null})
redraw()
if(named!=='canceled/autobuy')startPriceQueue()
return true}
function armCheapen(result,hit){if(solve===null||background===true)return false
if(wantsCheapen()!==true){hybridSeen['cheapen-off']+=1
noPhase('cheapen-off')
return false}
if(typeof win?.requestAnimationFrame!=='function'){noPhase('no-frames')
return false}
if(hit===true){hybridSeen['frozen-hit']+=1
noPhase('frozen-hit')
return false}
if(chainCheapen!==0)return false
const reason=phaseReason(result,chainRedo!==0)
if(reason.kind===null){hybridSeen[reason.why]+=1
noPhase(reason.why)
return false}
const rescue=reason.kind!=='cheapen'
const stalled=reason.kind==='rescue-unfinished'
const shut=hybridDoor()
if(shut===null)hybridSeen.open+=1
else hybridSeen[shut]=(hybridSeen[shut]??0)+1
if(shut!==null&&!wakesCheapen(result)){noPhase(shut)
return false}
if(current.key===null||!last?.challenge){noPhase('no-challenge')
return false}
if(current.submitted===true){noPhase('submitted')
return false}
chainCheapen=1
cheapenSeen.started+=1
knock('cheapen')
cheapenHybrid=shut===null
cheapenRescue=rescue&&shut===null
cheapenStalled=stalled&&shut===null
cheapenChain=chainId
cheapenDoor=shut
sayOutcome({chain:chainId,state:'started',detail:null})
background=true
cheapenTicket=cheapenTicketOf()
cheapenMark=inputMark()
cheapenAt=now()
cheapenPercent=null
let left=CHEAPEN_WAIT_FRAMES
const wait=()=>{const one=cheapenTicket
if(!cheapenAlive(one)){finishCheapen(cheapenDeath())
return}
if(current.submitted===true){finishCheapen('canceled')
return}
if(working()){if(left<=0){finishCheapen('busy')
return}
left-=1
if(!nextFrame(step))finishCheapen('busy')
return}
startCheapen(one)}
const step=()=>{try{wait()}catch(err){onError(err)
finishCheapen('throw')}}
if(!nextFrame(step))finishCheapen('busy')
return true}
function startCheapen(one){
const baseline=cheapenRescue===true?null:(current.result?.prepared?.selection??null)
if(cheapenRescue!==true&&(!Array.isArray(baseline)||baseline.length===0)){finishCheapen('unknown-cost')
return}
if(cheapenHybrid===true){const shut=hybridDoor()
if(shut!==null){cheapenDoor=shut
finishCheapen(shut)
return}}
const shownCeiling=current.result?.search?.solverBudget?.ceiling
const first=Number.isFinite(shownCeiling)&&shownCeiling>0
?Math.max(shownCeiling*CHEAPEN_CEILING_X,MAX_SOLVE_EVALUATIONS):null
cheapenBase=Number.isFinite(shownCeiling)&&shownCeiling>0?shownCeiling:null
cheapenCeiling=first
cheapenRungs=0
let bestRung=null
let bestPrice=null
let bestCeiling=null
let climbStalled=false
let bestN=null
const rungLog=[]
cheapenLadder=null
let edgeAsked=false
let rungEdge=false
let rungMs=null
let finishAsked=false
let rungFinish=false
let finishTold=null
let finishWon=false
let finishSeedRows=null
const reachedEdge=(ceiling)=>Number.isFinite(ceiling)&&ceiling>=RESCUE_CEILING_MAX
const edgeLeft=()=>cheapenRescue===true&&!edgeAsked&&!reachedEdge(cheapenCeiling)
&&!rungLog.some((r)=>reachedEdge(r.asked)||reachedEdge(r.got))
const finishLeft=()=>cheapenRescue===true&&!finishAsked&&!edgeAsked
let doneWeight=0
let shownPercent=null
const weightOf=(ceiling)=>(Number.isFinite(ceiling)&&ceiling>0?ceiling:MAX_SOLVE_EVALUATIONS)
const pace={pause:()=>frame(one.request),progress:(percent)=>{if(!cheapenAlive(one))return
const ahead=(finishLeft()?RESCUE_FINISH_WEIGHT:0)+(edgeLeft()?RESCUE_CEILING_MAX:0)
if(!Number.isFinite(percent)||(doneWeight===0&&ahead===0))cheapenPercent=Number.isFinite(percent)?percent:null
else{const here=weightOf(cheapenCeiling)
const whole=Math.floor((doneWeight+Math.min(100,Math.max(0,percent))/100*here)/(doneWeight+here+ahead)*100)
shownPercent=Math.max(shownPercent??0,Math.min(100,whole))
cheapenPercent=shownPercent}
redraw()}}
const ask=(ceiling,edge=false)=>{cheapenRungs+=1
cheapenCeiling=ceiling
rungEdge=edge===true
rungFinish=false
const rest=cheapenRungs===1?CHEAPEN_TIME_MS:Math.max(1,Math.round(CHEAPEN_TIME_MS-(now()-cheapenAt)))
const left=rungEdge?Math.min(RESCUE_TOP_MS,rest):rest
rungMs=left
return solve(last.challenge,last.set,()=>{},new Set(placed.get(one.key)??[]),pace,
cheapenHybrid===true?MODE_MARKET:activeMode(),
{timeBudgetMs:left,quiet:true,...(baseline===null?{}:{baseline}),...(ceiling===null?{}:{evaluationCeiling:ceiling}),
...(cheapenHybrid===true&&baseline!==null?{heir:heirOf(baseline)}:{})})}
const askFinish=()=>{finishAsked=true
cheapenRungs+=1
cheapenCeiling=RESCUE_FINISH_WEIGHT
rungEdge=false
rungFinish=true
const rest=Math.max(1,Math.round(CHEAPEN_TIME_MS-(now()-cheapenAt)))
const left=Math.min(FINISH_CALL_MS,rest)
rungMs=left
const seed=(bestRung?.prepared?.selection??[]).filter((row)=>row?.id!==undefined&&row?.id!==null)
finishSeedRows=seed.map((row)=>(row?.virtual===true?{...row}:{id:row.id}))
return solve(last.challenge,last.set,()=>{},new Set(placed.get(one.key)??[]),pace,
cheapenHybrid===true?MODE_MARKET:activeMode(),
{timeBudgetMs:left,quiet:true,evaluationCeiling:RESCUE_FINISH_WEIGHT,finish:{seed}})}
const grown=(answer)=>{if(cheapenRescue!==true)return null
if(answer?.ok===true&&climbStalled===true)return null
if(cheapenRungs>=RESCUE_CEILING_RUNGS)return null
if(!cheapenAlive(one)||current.submitted===true)return null
const seek=answer?.search
if(seek?.exhausted!==true||seek?.solverBudget?.timeStopped===true)return null
if(now()-cheapenAt>=CHEAPEN_TIME_MS)return null
const spent=seek?.solverBudget?.ceiling
if(!Number.isFinite(spent)||spent<=0)return null
const next=Math.min(spent*RESCUE_CEILING_X,RESCUE_CEILING_MAX)
return next>spent?next:null}
redraw()
const priceOf=(answer)=>{const said=rescueVerdict(answer)
return said.ok===true&&Number.isFinite(said.after)?said.after:null}
let rungThrew=false
const thrown=(err)=>{if(!cheapenAlive(one))throw err
onError(err)
rungThrew=true
return climb(null)}
const climb=(answer)=>{const price=priceOf(answer)
const asked=answer?.search
rungLog.push({n:cheapenRungs,asked:Number.isFinite(cheapenCeiling)?cheapenCeiling:null,
got:Number.isFinite(asked?.solverBudget?.ceiling)?asked.solverBudget.ceiling:null,
ok:answer?.ok===true,exhausted:asked?.exhausted===true,
timeStopped:asked?.solverBudget?.timeStopped===true,
evaluations:Number.isFinite(asked?.evaluations)?asked.evaluations:null,price,
ms:Number.isFinite(rungMs)?rungMs:null,...(rungEdge?{edge:true}:{}),
...(rungFinish?{finish:answer?.search?.finish??null,seed:finishSeedRows}:{}),...(rungThrew?{thrown:true}:{})})
rungThrew=false
if(rungFinish)finishTold=answer?.search?.finish??null
if(rungFinish&&price!==null&&(bestPrice===null||price<bestPrice))finishWon=true
doneWeight+=weightOf(cheapenCeiling)
if(price!==null){if(bestPrice===null){bestPrice=price
bestRung=answer
bestN=cheapenRungs
bestCeiling=cheapenCeiling}
else{const saved=bestPrice-price
if(!rungEdge&&!rungFinish)climbStalled=!(saved>=CHEAPEN_MIN_COINS&&bestPrice>0&&saved/bestPrice>=CHEAPEN_MIN_SHARE)
if(price<bestPrice){bestPrice=price
bestRung=answer
bestN=cheapenRungs
bestCeiling=cheapenCeiling}}}
const more=edgeAsked||finishAsked?null:grown(answer)
if(more!==null)return ask(more).then(climb,thrown)
const phaseCut=()=>rungLog.some((r)=>r.timeStopped===true&&r.finish===undefined)
if(finishLeft()&&cheapenAlive(one)&&current.submitted!==true&&!phaseCut()&&now()-cheapenAt<CHEAPEN_TIME_MS)return askFinish().then(climb,thrown)
const edgeWanted=!finishWon&&(finishTold===null||finishTold.needEdge!==false)
if(edgeWanted&&edgeLeft()&&cheapenAlive(one)&&current.submitted!==true
&&!phaseCut()&&now()-cheapenAt<CHEAPEN_TIME_MS){edgeAsked=true
return ask(RESCUE_CEILING_MAX,true).then(climb,thrown)}
if(bestRung!==null&&Number.isFinite(bestCeiling))cheapenCeiling=bestCeiling
cheapenLadder={branch:cheapenRescue===true?'rescue':'cheapen',
rungs:rungLog.map((one)=>({...one})),
winnerRung:bestN,winnerCeiling:Number.isFinite(bestCeiling)?bestCeiling:null,
stalled:climbStalled,door:cheapenDoor,
...(cheapenRescue===true?{edgeMs:RESCUE_TOP_MS}:{}),
...(cheapenRescue===true?{finishMs:FINISH_MS,finishSignal:FINISH_SIGNAL,finishSkippedEdge:finishWon||finishTold?.needEdge===false,finishWon}:{})}
return bestRung===null?answer:bestRung}
Promise.resolve()
.then(()=>ask(first))
.then(climb)
.then((answer)=>{cheapenPercent=null
settleCheapen(answer,one)})
.catch((err)=>{cheapenPercent=null
if(!cheapenAlive(one)){finishCheapen(cheapenDeath())
return}
onError(err)
finishCheapen('failed')})}
function settleCheapen(answer,one){let waiting=CHEAPEN_WAIT_FRAMES
const accept=()=>{if(!cheapenAlive(one)){finishCheapen(cheapenDeath())
return}
if(current.submitted===true){finishCheapen('canceled')
return}
if(current.showing===true){if(waiting<=0){finishCheapen('busy')
return}
waiting-=1
if(!nextFrame(commit))finishCheapen('busy')
return}
if(buyingNow||autoBuyState.phase==='running'){finishCheapen('autobuy-running')
return}
if(inputMark()!==cheapenMark){finishCheapen('canceled')
return}
const verdict=cheapenRescue===true?rescueVerdict(answer):cheaperVerdict(answer)
if(verdict.ok!==true){finishCheapen(verdict.why,verdict,answer)
return}
const buys=Array.isArray(answer?.buys)?answer.buys.length:0
if(cheapenRescue!==true&&buys>0){const pocket={ticket:one,mark:cheapenMark,answer,verdict,
savings:Number.isFinite(verdict.savings)?verdict.savings:0,
spend:Number.isFinite(answer?.spend)&&answer.spend>0?answer.spend:0,
ladder:cheapenLadder,
count:buys,taken:false,club:null}
current={...current,offer:pocket}
keepOffer(one.key,pocket,current.result)
redraw()
finishCheapen(WHY_OFFERED,verdict,answer)
return}
if(takePhaseAnswer(answer,verdict,{key:one.key,rescued:cheapenRescue===true,stalled:cheapenStalled===true,ladder:cheapenLadder})!==true){finishCheapen('frozen-refused',verdict,answer)
return}
finishCheapen(cheapenRescue===true?(cheapenStalled===true?WHY_STALLED:WHY_RESCUE):'adopted',verdict,answer)}
const commit=()=>{try{accept()}catch(err){onError(err)
finishCheapen('throw')}}
commit()}
function takePhaseAnswer(answer,verdict,at){
const stored=frozen.put(at.key,{result:answer,warn:current.warn??null,ids:solutionIds(answer),
mark:answerMark(answer),squad:squadNow(),from:'cheapen'})
if(stored!==true)return false
if(adopt!==null){try{if(adopt(traceOf(answer,at),answer)!==true)adoptFailed+=1}catch(err){adoptFailed+=1
onError(err)}}
const wasShown=current.shown===true
const rescued=at.rescued===true
const stalled=rescued&&at.stalled===true
const coins=Math.round(rescued?verdict.after:verdict.savings)
current={...current,result:answer,shown:false,stale:wasShown||current.stale===true,adopted:true,
...(rescued?{said:null,redoFailed:false}:{}),
cheaper:rescued
?{key:stalled?'sbcWindow.rescueUnfinished':'sbcWindow.rescueFound',params:{coins}}
:wasShown
?{key:'sbcWindow.cheaperReshow',params:{coins}}
:{key:'sbcWindow.cheaperFound',params:{coins,out:cheapenFaceName(verdict.out),in:cheapenFaceName(verdict.in)}}}
if(autoBuyState.phase==='checking'||autoBuyState.phase==='counting')autoBuyTicket+=1
resetAutoBuy()
redraw()
return true}
function traceOf(answer,at){const trace=answer?.trace
if(!trace||typeof trace!=='object')return null
trace.ladder=at?.ladder??null
trace.rebuilds=cheapenRebuilds
trace.buy=()=>buyDumpRow(answer)
return trace}
function buyDumpRow(answer){const blank={stale:true,phase:null,estimate:null,worst:null,cards:null,targets:[],live:[]}
if(current.result!==answer)return blank
const state=autoBuyState
const targets=Array.isArray(state?.targets)?state.targets:[]
return{stale:false,phase:typeof state?.phase==='string'?state.phase:null,
estimate:Number.isFinite(state?.total)?state.total:null,
worst:Number.isFinite(state?.worst)?state.worst:null,
cards:Number.isFinite(state?.cards)?state.cards:null,
targets:targets.map((one)=>{let cap=null
try{cap=buyCeilingOf(buyTargetOf({...one}))}catch{cap=null}
return{definitionId:one?.id??null,want:Number.isFinite(one?.want)?one.want:null,
cap:Number.isFinite(cap)&&cap>0?cap:null,name:typeof one?.name==='string'?one.name:null}}),
live:targets.filter((one)=>Number.isFinite(one?.price)&&one.price>0).map((one)=>({definitionId:one?.id??null,
coins:one.price,
atMs:Number.isFinite(one?.stampedAt)?one.stampedAt:null}))}}
function keepOffer(key,pocket,base){if(key===null||key===undefined||base===null||base===undefined)return false
if(!offers.has(key)&&offers.size>=FROZEN_KEEP){const oldest=offers.keys().next().value
if(oldest!==undefined)offers.delete(oldest)}
offers.set(key,{base,mark:pocket.mark,answer:pocket.answer,verdict:pocket.verdict,
savings:pocket.savings,spend:pocket.spend,count:pocket.count})
return true}
function restoreOffer(key,result){const kept=key===null||key===undefined?null:offers.get(key)
if(!kept||kept.base!==result)return false
if(kept.mark!==inputMark())return false
current={...current,offer:{ticket:cheapenTicketOf(),mark:kept.mark,answer:kept.answer,verdict:kept.verdict,
savings:kept.savings,spend:kept.spend,count:kept.count,taken:false,club:null}}
offerRestored+=1
redraw()
return true}
const offerAlive=()=>{const pocket=current.offer
return pocket!==null&&pocket!==undefined&&cheapenAlive(pocket.ticket)}
function offerBlocker(pocket){if(!offerAlive())return 'gone'
if(current.submitted===true)return 'submitted'
if(working())return 'busy'
if(buyingNow||autoBuyState.phase==='running')return 'autobuy'
if(inputMark()!==pocket.mark)return 'changed'
return null}
function refuseOffer(why){offerRefused+=1
current={...current,said:sayOf({key:'sbcWindow.offerFailed',params:{why}},'offer')}
redraw()
return false}
function pressOffer(){const pocket=current.offer
if(pocket===null||pocket===undefined||pocket.taken===true)return false
const blocked=offerBlocker(pocket)
if(blocked!==null)return refuseOffer(blocked)
const club={result:current.result,shown:current.shown===true,stale:current.stale===true,
adopted:current.adopted===true,cheaper:current.cheaper,
record:{result:current.result,warn:current.warn??null,ids:solutionIds(current.result),
mark:answerMark(current.result),squad:squadNow(),from:'live'}}
const before=pocket
current={...current,offer:{...pocket,taken:true,club}}
if(takePhaseAnswer(pocket.answer,pocket.verdict,{key:pocket.ticket.key,rescued:false,stalled:false,ladder:pocket.ladder??null})!==true){current={...current,offer:before}
return refuseOffer('storage')}
offerTaken+=1
startPriceQueue()
press()
return true}
function pressOfferBack(){const pocket=current.offer
if(pocket===null||pocket===undefined||pocket.taken!==true)return false
const club=pocket.club
if(!club)return false
if(current.submitted===true)return refuseOffer('submitted')
if(working())return refuseOffer('busy')
if(buyingNow||autoBuyState.phase==='running')return refuseOffer('autobuy')
frozen.drop(pocket.ticket.key,'offer-back')
frozen.put(pocket.ticket.key,club.record)
if(autoBuyState.phase==='checking'||autoBuyState.phase==='counting')autoBuyTicket+=1
resetAutoBuy()
const pitchMoved=current.shown===true
current={...current,result:club.result,
shown:pitchMoved?false:club.shown,
stale:pitchMoved?true:club.stale,
adopted:club.adopted,cheaper:club.cheaper,
offer:{...pocket,taken:false,club:null}}
offerBack+=1
redraw()
press()
return true}
function heirOf(rows){if(!Array.isArray(rows)||rows.length===0)return null
const hand=new Set((current.result?.prepared?.mine??[]).map(String))
const free=rows.filter((one)=>!hand.has(String(one?.id??'')))
return free.length>0?free:null}
function cheapenFaceName(one){if(!one)return t('sbcWindow.unknown')
if(one.buy===true)return buyRowName({t,nameOf:staticNameOf},one)
return typeof one.name==='string'&&one.name!==''?one.name:t('sbcWindow.unknown')}
function autosolve(){if(!solve||!isActive(SBC_FEATURE))return false
const key=current.key
const chain=phases.begin('enter')
watchEntryFrames()
warmUp(chain,key)
defer(()=>{
if(key!==current.key){phases.drop(chain)
return}
try{if(run({entryChain:chain,door:'entry'})!==true)phases.drop(chain)}catch(err){phases.drop(chain)
onError(err)}})
return true}
let warmRequest=0
let entryFrames=null
function warmUp(chain,key){if(prewarm===null||!last?.challenge)return false
const frameFn=win?.requestAnimationFrame
if(typeof frameFn!=='function')return false
const ticket=++warmRequest
const stale=()=>ticket!==warmRequest||key!==current.key||!phases.isChain(chain)
const started=now()
const pause=()=>new Promise((resolve,reject)=>{if(stale()){reject(new Error('stale-warm'))
return}
frameFn.call(win,()=>{if(stale())reject(new Error('stale-warm'))
else resolve()})})
Promise.resolve().then(()=>prewarm(last.challenge,{pause}))
.then(()=>{if(stale())return
phases.note('warm',Math.round(now()-started))})
.catch((err)=>{if(String(err?.message??err)==='stale-warm')return
onError(err)})
return true}
function watchEntryFrames(){const frame=win?.requestAnimationFrame
if(typeof frame!=='function'){entryFrames={seen:false,frames:0,worst:null,long:null,window:ENTRY_WATCH_MS,left:false}
return}
const key=current.key
const started=now()
let previous=started
const seen={seen:true,frames:0,worst:0,long:0,window:ENTRY_WATCH_MS,left:false}
entryFrames=seen
const tick=()=>{if(key!==current.key){seen.left=true
return}
const at=now()
const gap=at-previous
previous=at
seen.frames+=1
if(gap>seen.worst)seen.worst=Math.round(gap)
if(gap>=LONG_GAP_MS)seen.long+=1
if(at-started>=ENTRY_WATCH_MS)return
frame.call(win,tick)}
frame.call(win,tick)}
function defer(fn){const timer=win?.setTimeout
if(typeof timer!=='function'){fn()
return}
const frame=win?.requestAnimationFrame
if(typeof frame!=='function'){timer.call(win,fn,0)
return}
const started=now()
const step=()=>{if(now()-started>=NATIVE_ENTRY_MS){timer.call(win,fn,0)
return}
frame.call(win,step)}
frame.call(win,step)}
function keySay(byKey,text,kind){if(byKey===true)sayEa(text,kind)
return text}
function sayEa(text,kind){if(eaNotice===null||typeof text!=='string'||text===''){saidSkipped+=1
return false}
let ok=false
try{ok=eaNotice(text,kind)===true}catch(err){onError(err)
ok=false}
if(ok)saidOk+=1
else saidSkipped+=1
return ok}
let saidOk=0
let saidSkipped=0
let keyPresses=0
let keySeen=0
let lastKey=null
const askDoc=(selector)=>{try{return doc?.querySelectorAll?.(selector)?.length??0}catch{return-1}}
const screenMarks=()=>({
dock:askDoc('.ut-squad-slot-dock-view'),
tabs:askDoc('.ut-squad-tab-button-control'),
sbc:askDoc('.SBCSquadPanel'),
content:askDoc('.challenge-content'),
submit:askDoc(SUBMIT_TAB_SELECTOR),
root:last?.root?.isConnected===true})
const noteKey=(gate)=>{lastKey={gate,
slots:askDoc(SLOT_SELECTOR),
key:current.key!==null&&current.key!==undefined,picked:Number.isInteger(pickedSlot)?pickedSlot:null,
buys:(current.result?.buys??[]).length,marks:screenMarks()}
return false}
function pressAutoBuy(opts={}){const single=opts.one===true
const spendNow=opts.spendNow===true&&single
const needsPick=opts.needsPick===true&&single
const byKey=opts.byKey===true
if(autoBuy===null)return false
if(background===true){cheapenCancelBy='autobuy'
cancel()}
if(autoBuyState.phase==='running'){try{autoBuy.cancel?.()}catch(err){onError(err)}
return true}
if(batchLive()){try{autoBuy.cancel?.()}catch(err){onError(err)}
return true}
if(autoBuyState.phase==='checking')return false
if(autoBuyState.phase==='counting'){const left=autoBuyState.count?.etaMs??null
autoBuyState={...autoBuyState,note:keySay(byKey,Number.isFinite(left)&&left>0
?t('sbcBuy.countingWait',{seconds:Math.max(1,Math.ceil(left/1000))})
:t('sbcBuy.countingSoon'),'NEUTRAL')}
redraw()
return true}
if(autoBuyState.phase==='armed'){
if(needsPick){const aimed=aimedRow()
if(aimed!==null&&aimed===autoBuyState.only)return runAutoBuy({byKey})
return armAutoBuy({one:true,spendNow,needsPick,byKey})}
if(single&&autoBuyState.only===null)return armAutoBuy({one:true,spendNow,byKey})
return runAutoBuy({byKey})}
return armAutoBuy({one:single,spendNow,needsPick,byKey})}
function aimedRow(){if(!Number.isInteger(pickedSlot))return null
return rowOfPickedSlot(autoBuyTargets(current.result,{done:closedTargets(current.key)}))}
let autoBuyTicket=0
let excludeSaid=null
const buyIdsOf=(result)=>new Set((Array.isArray(result?.buys)?result.buys:[])
.map((one)=>one?.definitionId).filter((id)=>Number.isSafeInteger(id)&&id>0))
const buyFaceOf=(row)=>(row===null||row===undefined
?t('sbcWindow.unknown')
:buyRowName({t,nameOf:staticNameOf},row))
const targetFace=(row)=>buyFaceOf(row===null||row===undefined?null:{definitionId:Number.isSafeInteger(row?.definitionId)?row.definitionId:(row?.id??null),
rating:Number.isFinite(row?.rating)?row.rating:null,affiliation:row?.affiliation??null})
function sayExcluded(said,result){const fresh=[]
for(const one of Array.isArray(result?.buys)?result.buys:[]){const id=one?.definitionId
if(!Number.isSafeInteger(id)||id<=0||said.ids.has(id))continue
fresh.push(buyFaceOf({definitionId:one?.definitionId??null,
rating:Number.isFinite(one?.rating)?one.rating:null,affiliation:one?.affiliation??null}))}
const out=said.out.join(', ')
const over=Number.isFinite(said.over)?said.over:null
autoBuyState={...autoBuyState,said:fresh.length===0
?(over===null?t('sbcBuy.excludedNone',{out}):t('sbcBuy.excludedOverNone',{out,percent:over}))
:(over===null?t('sbcBuy.excludedFor',{out,in:fresh.join(', ')}):t('sbcBuy.excludedOverFor',{out,in:fresh.join(', '),percent:over}))}
redraw()}
function excludeStuckCards(dropped){if(!Array.isArray(dropped)||dropped.length===0)return false
const fresh=dropped.filter((one)=>!excludedIds.includes(one.id))
if(fresh.length===0)return false
if(excludedIds.length+fresh.length>EXCLUDE_PICKS)return false
const before=excludedIds
excludedIds=[...excludedIds,...fresh.map((one)=>one.id)]
const over=Number.isFinite(fresh[0]?.over)?fresh[0].over:null
const said={key:current.key,out:fresh.map((one)=>buyFaceOf({definitionId:one.id,rating:one.rating,affiliation:one.affiliation??null})),ids:buyIdsOf(current.result),over}
autoBuyTicket+=1
resetAutoBuy(over===null?t('sbcBuy.excluding',{name:said.out[0]}):t('sbcBuy.excludingOver',{name:said.out[0],percent:over}))
redraw()
knock('exclude')
if(!run({force:true,preempt:true,door:'exclude'})){excludedIds=before
return false}
excludeSaid=said
return true}
const autoBuyPlan=(rows)=>rows.map((one)=>({id:one.id,want:one.want,row:one.row,
name:buyRowName({t,nameOf:staticNameOf},{definitionId:one.id,rating:one.rating,affiliation:one.affiliation})}))
const livePriceOf=(verdict,id)=>{const row=(verdict?.rows??[]).find((one)=>one?.id===id)
return Number.isFinite(row?.price)&&row.price>0?row.price:null}
const liveStampOf=(verdict,id)=>{const row=(verdict?.rows??[]).find((one)=>one?.id===id)
return{age:Number.isFinite(row?.age)?row.age:null,origin:row?.origin??null,
stampedAt:Number.isFinite(row?.age)?now():null}}
const agedTargets=(targets)=>targets.map((one)=>(Number.isFinite(one?.age)&&Number.isFinite(one?.stampedAt)
?{...one,age:one.age+Math.max(0,now()-one.stampedAt)}
:one))
function startPriceQueue(){if(autoBuy===null)return false
if(batchLive()){queuedByBuy=true
return false}
if(autoBuyState.phase!=='idle')return false
if(current.busy===true)return false
if(statusOf(AUTO_BUY_FEATURE)==='not-entitled')return false
if(isActive(AUTO_BUY_FEATURE)!==true)return false
return armAutoBuy({background:true})}
async function walkStuck(plan,verdict,ask,stale){let targets=plan
let out=verdict
for(let round=0;round<ALT_PICKS&&out?.ok!==true;round+=1){if(stale())return{targets,verdict:out}
const next=substituteStuck(targets,out)
if(next===null)break
targets=next
out=await ask(targets)}
return{targets,verdict:out}}
async function armWith(input){const{verdict,targets,background,stale}=input
const byKey=input.byKey===true&&background!==true
const named=(one)=>({...one,name:targetFace(one)})
const priced=(verdict?targets.map((one)=>({...one,price:livePriceOf(verdict,one.id)??one.price??null,...liveStampOf(verdict,one.id)})):targets).map(named)
const sums=batchPrices(priced)
const total=sums.worst
if(background&&total>warnSpendCoins()){autoBuyState={...autoBuyState,phase:'idle',count:null,queued:false,
note:t('sbcBuy.countedBig',{coins:total})}
redraw()
return false}
if(total>warnSpendCoins()){if(askConfirm===null){resetAutoBuy(keySay(byKey,t('sbcBuy.needsPrice'),'NEGATIVE'))
redraw()
return false}
autoBuyState={...autoBuyState,phase:'checking',count:null,queued:background===true}
redraw()
const agreed=await askConfirm({titleKey:'sbcBuy.bigTitle',messageKey:'sbcBuy.bigMessage',
messageParams:{coins:total,limit:warnSpendCoins()},danger:true})
if(stale())return false
if(agreed!==true){resetAutoBuy(null)
redraw()
return false}}
const swapped=swappedNote({t,targets:priced,face:targetFace})
const said=swapped===null?null:(input.spendNow===true?keySay(byKey,`${swapped} ${t('sbcBuy.swapConfirm')}`,'NEUTRAL'):swapped)
autoBuyState={phase:'armed',total:sums.estimate,worst:sums.worst,cards:priced.length,done:0,spent:0,count:null,said:autoBuyState.said??null,queued:background===true,
only:typeof input.only==='string'&&input.only!==''?input.only:null,
note:said??input.note??null,
targets:priced}
redraw()
if(input.spendNow===true&&swapped===null&&background!==true&&!stale())runAutoBuy({byKey})
return true}
function rowOfPickedSlot(targets){if(!Number.isInteger(pickedSlot))return null
try{return rowForSlot(current.result?.prepared??null,targets,pickedSlot)}catch(err){onError(err)
return null}}
function conceptsGap(targets){if(current.shown!==true)return null
const named=(Array.isArray(targets)?targets:[]).map((one)=>({...one,name:targetFace(one)}))
const prepared=current.result?.prepared??null
const mismatch=mismatchInPlan(prepared,named)
const twice=mismatch.length>0?mismatch:twiceInPlan(prepared,named)
const missing=twice.length>0?twice:conceptsMissingFor(prepared,named)
if(missing.length===0)return null
const one=missing[0]
return autoBuyStopLine({t,reason:AUTO_BUY_BAD_STATE,
detail:{stage:'concepts',why:one.why,name:one.name??null,id:one.id??null,count:missing.length}})}
function armAutoBuy(opts={}){const background=opts.background===true
const single=opts.one===true
const spendNow=opts.spendNow===true&&single
const needsPick=opts.needsPick===true&&single
const byKey=opts.byKey===true
if(chemistryRefused(current.live)){autoBuyState={...autoBuyState,phase:'idle',count:null,queued:false,note:keySay(byKey,t('sbcBuy.chemistryFailed'),'NEGATIVE')}
redraw()
return false}
const all=autoBuyTargets(current.result,{done:closedTargets(current.key)})
const showed=single&&Number.isInteger(pickedSlot)
if(needsPick&&!showed){autoBuyState={...autoBuyState,phase:'idle',count:null,queued:false,note:keySay(byKey,t('sbcBuy.pickFirst'),'NEGATIVE')}
redraw()
return false}
const picked=showed?rowOfPickedSlot(all):null
if(showed&&picked===null){autoBuyState={...autoBuyState,phase:'idle',count:null,queued:false,note:keySay(byKey,t('sbcBuy.pickNothing'),'NEGATIVE')}
redraw()
return false}
const first=single?(picked===null?all.slice(0,1):all.filter((one)=>String(one?.row??'')===picked)):all
if(first.length===0){if(background)return false
autoBuyState={...autoBuyState,phase:'idle',note:keySay(byKey,t('sbcBuy.noTargets'),'NEGATIVE')}
redraw()
return false}
const gap=conceptsGap(first)
if(gap!==null){autoBuyState={...autoBuyState,phase:'idle',count:null,queued:false,note:keySay(byKey,gap,'NEGATIVE')}
redraw()
return false}
const ticket=++autoBuyTicket
const key=current.key
const token=priceToken
const stale=()=>ticket!==autoBuyTicket||key!==current.key||token!==priceToken
const only=single?String(first[0]?.row??''):null
const blind=batchPrices(first).blind
if(blind.length===0){armWith({targets:first,background,stale,only,spendNow,byKey}).catch((err)=>{onError(err)
if(stale())return
resetAutoBuy(t('sbcBuy.needsPrice'))
redraw()})
return true}
const timer=win?.setTimeout
const startedAt=now()
const pace=background&&typeof timer==='function'?{
sleep:(ms)=>new Promise((done)=>{timer.call(win,done,Math.max(0,Number(ms)||0))}),
cancelled:()=>stale(),
onStep:({done,total})=>{if(stale())return
const spent=Math.max(0,now()-startedAt)
const left=done>0&&total>done?Math.round((spent/done)*(total-done)):null
autoBuyState={...autoBuyState,count:{done,cards:total,etaMs:left}}
redraw()}}:null
autoBuyState={phase:background?'counting':'checking',total:0,cards:blind.length,done:0,spent:0,note:null,targets:first,
queued:background,said:autoBuyState.said??null,
count:background?{done:0,cards:blind.length,etaMs:null}:null}
redraw()
let asking=blind
const ask=(list)=>autoBuy.confirmPrices(autoBuyPlan(list),pace===null?{}:{pace})
Promise.resolve()
.then(async()=>{const walked=await walkStuck(asking,await ask(asking),ask,stale)
asking=walked.targets
return walked.verdict})
.then(async(verdict)=>{if(stale())return
if(verdict?.ok!==true){
if(excludeStuckCards(stuckWithoutAlts(asking,verdict)))return
resetAutoBuy(keySay(byKey,autoBuyPriceNote({t,verdict,fresh:verdict?.asked===0}),'NEGATIVE'))
autoBuyState={...autoBuyState,queued:background}
redraw()
return}
const named=new Map(asking.map((one)=>[String(one?.row??''),one]))
const targets=first.map((one)=>named.get(String(one?.row??''))??one)
await armWith({verdict,targets,background,stale,only,spendNow,byKey})})
.catch((err)=>{onError(err)
if(stale())return
resetAutoBuy(t('sbcBuy.needsPrice'))
redraw()})
return true}
function runAutoBuy(opts={}){
const byKey=opts.byKey===true
let targets=Array.isArray(autoBuyState.targets)?autoBuyState.targets:[]
if(chemistryRefused(current.live)){resetAutoBuy(keySay(byKey,t('sbcBuy.chemistryFailed'),'NEGATIVE'))
redraw()
return false}
const closed=closedTargets(current.key)
if(closed!==null)targets=targets.filter((one)=>!closed.has(String(one?.row??'')))
if(targets.length===0){resetAutoBuy(keySay(byKey,t('sbcBuy.noTargets'),'NEGATIVE'))
redraw()
return false}
const sums=batchPrices(targets)
if(sums.blind.length>0)return armAutoBuy({byKey})
let ticket=++autoBuyTicket
const key=current.key
const stale=()=>ticket!==autoBuyTicket||key!==current.key
autoBuyState={phase:'running',total:sums.estimate,worst:sums.worst,cards:targets.length,done:0,spent:0,count:null,
note:null,targets}
redraw()
Promise.resolve()
.then(async()=>{
buyingNow=true
let out=null
try{out=await autoBuy.run(agedTargets(targets),(progress)=>{if(stale())return
autoBuyState={...autoBuyState,done:progress?.done??autoBuyState.done,spent:progress?.spent??autoBuyState.spent}
redraw()},current.result?.prepared??null)}finally{buyingNow=false}
adoptBought(key,out?.rows)
pickedSlot=null
forget()
if(stale())return
const bought=Number.isFinite(out?.bought)?out.bought:0
const planned=Number.isFinite(out?.planned)?out.planned:targets.length
const spent=Number.isFinite(out?.spent)?out.spent:0
const waitMs=Number.isFinite(out?.detail?.waitMs)&&out.detail.waitMs>0?out.detail.waitMs:null
autoBuyState={phase:'idle',total:0,worst:sums.worst,cards:planned,done:bought,spent,targets:[],only:null,
skips:autoBuySkips({t,rows:out?.rows}),
stop:autoBuyStopLine({t,reason:out?.reason??null,detail:out?.detail??null}),
why:out?.reason??null,door:out?.detail?.door??null,at:out?.detail?.stage??null,
detail:out?.detail??null,
note:bought===planned&&out?.reason===null
?t('sbcBuy.done',{cards:bought,coins:spent})
:waitMs!==null
?t('sbcBuy.partialWait',{done:bought,cards:planned,coins:spent,seconds:Math.max(1,Math.ceil(waitMs/1000))})
:t('sbcBuy.partial',{done:bought,cards:planned,coins:spent})}
if(byKey){const win=(Array.isArray(out?.rows)?out.rows:[]).find((row)=>row?.status==='placed'||row?.status==='bought')
if(bought===planned&&out?.reason===null&&win){sayEa(t('sbcBuy.boughtNotice',{
name:typeof win.name==='string'&&win.name!==''?win.name:buyFaceOf(null),
coins:Number.isFinite(win.paid)?win.paid:spent}),'POSITIVE')}
else sayEa(autoBuyState.note,'NEGATIVE')}
redraw()
if(out?.reason!==null&&out?.reason!==undefined)return
const done=closedTargets(key)
const left=targets.filter((one)=>done===null||!done.has(String(one?.row??'')))
if(left.length===0)return
await recheckLeft({targets:left,stale,bought,planned,
bump:()=>{ticket=++autoBuyTicket}})})
.catch((err)=>{onError(err)
if(stale())return
resetAutoBuy(t('sbcBuy.needsPrice'))
redraw()})
.finally(()=>{flushQueuedPrice()})
return true}
function flushQueuedPrice(){if(queuedByBuy!==true)return false
queuedByBuy=false
return startPriceQueue()}
async function recheckLeft(input){const{stale,bought,planned,bump}=input
let rest=input.targets
const ask=(list)=>autoBuy.confirmPrices(autoBuyPlan(list),{})
const walked=await walkStuck(rest,await ask(rest),ask,stale)
rest=walked.targets
if(stale())return false
const verdict=walked.verdict
if(verdict?.ok!==true){
if(excludeStuckCards(stuckWithoutAlts(rest,verdict)))return false
autoBuyState={...autoBuyState,note:autoBuyPriceNote({t,verdict,fresh:verdict?.asked===0})}
redraw()
return false}
bump()
return armWith({verdict,targets:rest,background:false,stale,
note:t('sbcBuy.recheckedRest',{done:bought,cards:planned})})}
function retryReady(){return Boolean(solve)&&current.busy!==true&&current.answered===true
&&current.result?.ok!==true&&current.shown!==true&&current.submitted!==true}
function retry(){retries+=1
knock('retry')
if(!run({force:true,door:'retry'}))rebuild(()=>{},{force:true,door:'retry'})
return true}
function press(){if(retryReady())return retry()
if(!showOnPitch||current.shown||current.submitted)return false
if(current.busy===true){pendingShow=true
redraw()
return true}
return show()}
function show(){if(working()||!showOnPitch||current.shown||current.submitted)return false
const prepared=current.result?.prepared
if(!prepared)return false
const ticket=request
const key=current.key
current={...current,showing:true,guard:null}
redraw()
Promise.resolve()
.then(()=>showOnPitch(prepared))
.then((result)=>{if(ticket!==request||key!==current.key)return
if(result?.ok===true)placed.set(key,carryBought(key,ownIds(prepared,current.result?.mine,result?.placed)))
forget()
lastShow={ok:result?.ok===true,reason:result?.reason??null,detail:result?.detail??null,notice:result?.notice?.key??null,
saved:result?.saved??null,sent:result?.sent??null,passport:result?.passport??null,saveReason:result?.saveReason??null}
current={...current,showing:false,said:sayOf(result?.notice,'show'),shown:result?.ok===true,stale:result?.ok===true?false:current.stale,live:result?.ok===true?(result.live??null):null,
...(result?.ok===true?{cheaper:null}:{})}
redraw()})
.catch((err)=>{if(ticket!==request)return
forget()
current={...current,showing:false}
onError(err)
redraw()})
return true}
function forget(){if(watched)signed=squadFieldSignature(watched).signature}
function ownIds(prepared,mine,onPitch){const own=new Set((Array.isArray(mine)?mine:[]).map(String))
const ids=new Set()
const list=Array.isArray(onPitch)&&onPitch.length>0?onPitch:(prepared?.selection??[]).map((item)=>item?.id)
for(const value of list){const id=String(value??'')
if(id!==''&&!own.has(id))ids.add(id)}
return ids}
function adoptBought(key,rows){const own=placed.get(key)??null
let swapped=0
for(const row of Array.isArray(rows)?rows:[]){if(row?.status!=='placed')continue
const bought=String(row?.placedId??'')
if(bought===''||bought==='0')continue
const concept=String(row?.id??'')
if(own!==null){if(concept!=='')own.delete(concept)
own.add(bought)}
const step=String(row?.row??'')
if(step!==''){const mine=boughtSwaps.get(key)??new Map
mine.set(step,bought)
boughtSwaps.set(key,mine)}
swapped+=1}
return swapped}
function closedTargets(key){const mine=boughtSwaps.get(key)??null
if(mine===null||mine.size===0)return null
const own=placed.get(key)??null
if(own===null)return null
const done=new Set()
for(const[step,bought]of mine){if(own.has(bought))done.add(step)}
return done.size===0?null:done}
function carryBought(key,ids){const mine=boughtSwaps.get(key)??null
if(mine===null)return ids
for(const bought of mine.values())ids.add(bought)
return ids}
let toldAnswer=null
function redraw(){if(!last)return false
const content=challengeContentOf(last.root)
const host=content?.querySelector?.(WINDOW_SELECTOR)??null
if(!host)return false
try{paint(host)}catch(err){onError(err)}
if(current.result!==toldAnswer){toldAnswer=current.result
try{onSolution()}catch(err){onError(err)}}
return true}
function refresh(){
syncLocks()
if(!last)return false
return settle().ok===true}
function relabel(){return redraw()}
function drop(content){content?.querySelector?.(WINDOW_SELECTOR)?.remove?.()
painted=null}
function dropAll(){for(const node of doc?.querySelectorAll?.(WINDOW_SELECTOR)??[])node.remove?.()
painted=null}
return{apply,refresh,relabel,
storageChanged(){return redraw()},
reread,
sessionEpoch:{
stop(){if(disposed===true)return false
let acted=false
cheapenCancelBy='session-epoch'
if(cancel()===true)acted=true
else cheapenCancelBy=null
if(batchLive()){try{autoBuy?.cancel?.()}catch(err){onError(err)}
acted=true}
if(queuedByBuy===true){queuedByBuy=false
acted=true}
const armed=autoBuyState.phase!=='idle'||(autoBuyState.targets??[]).length>0
autoBuyTicket+=1
resetAutoBuy()
if(armed){redraw()
acted=true}
return acted},
forget(){if(disposed===true)return false
const had=current.key!==null&&current.key!==undefined
||current.result!==null&&current.result!==undefined
||current.offer!==null&&current.offer!==undefined
||offers.size>0||Number.isInteger(pickedSlot)||excludedIds.length>0||pendingShow===true
offers.clear()
pickedSlot=null
pendingShow=false
excludedIds=[]
current=blank()
if(had)redraw()
return had}},
invalidate(ids,why='items-gone'){
priceToken+=1
if(background===true&&Array.isArray(ids)&&ids.length>0)cancel()
knock('items:'+String(why??'items-gone'),(Array.isArray(ids)?ids.length:0)+' id')
const dropped=frozen.invalidate(ids,why)
if(dropped.length===0)return false
if(last?.challenge&&current.key!==null&&dropped.includes(String(current.key)))rebuild(()=>{},{force:true,door:'items:'+String(why??'items-gone')})
return true},
state:()=>({active:isActive(SBC_FEATURE),phases:phases.state(),
doors:{by:Object.fromEntries(Object.entries(doors.by).map(([name,row])=>[name,{...row,last:row.last===null?null:{...row.last}}])),
log:doors.log.map((one)=>({...one}))},
entry:entryFrames===null?null:{...entryFrames},
prewarm:prewarm!==null,
freshOnEntry:onEnterChallenge!==null,
mode,
access:accessNow(),activeMode:activeMode(),show:{...lastShow},concepts:(current.result?.prepared?.concepts?.size)??0,market:current.result?.market===true,buys:(current.result?.buys??[]).length,
livePriced:(current.result?.buys??[]).filter((one)=>one?.live===true).length,spend:current.result?.spend??null,
build:WINDOW_BUILD,
autoBuy:{phase:autoBuyState?.phase??'idle',total:autoBuyState?.total??0,cards:autoBuyState?.cards??0,
worst:autoBuyState?.worst??0,
dump:buyDumpRow(current.result),
done:autoBuyState?.done??0,spent:autoBuyState?.spent??0,note:autoBuyState?.note??null,
warnCoins:warnSpendCoins(),
bought:[...(closedTargets(current.key)??[])],
said:autoBuyState?.said??null,excluded:[...excludedIds],
count:autoBuyState?.count?{done:autoBuyState.count.done,cards:autoBuyState.count.cards,
etaMs:Number.isFinite(autoBuyState.count.etaMs)?autoBuyState.count.etaMs:null}:null,
queued:autoBuyState?.queued===true,
only:autoBuyState?.only??null,
picked:Number.isInteger(pickedSlot)?pickedSlot:null,
pickedRow:(()=>{try{return rowOfPickedSlot(autoBuyTargets(current.result,{done:closedTargets(current.key)}))}catch{return 'бросила'}})(),
stop:autoBuyState?.stop??null,why:autoBuyState?.why??null,
detail:autoBuyState?.detail??null,
door:autoBuyState?.door??null,at:autoBuyState?.at??null,
targets:(Array.isArray(autoBuyState?.targets)?autoBuyState.targets:[]).map((one)=>({id:one?.id??null,
want:one?.want??null,price:one?.price??null,
limit:buyCeilingOf(buyTargetOf(one)),
age:Number.isFinite(one?.age)?one.age:null,origin:one?.origin??null,
swapped:Number.isFinite(one?.swapped)?one.swapped:0,
alts:(Array.isArray(one?.alts)?one.alts:[]).length}))},
folds:{closed:[...closedFolds].sort(),shown:[...shownFolds]},buySearch:{...lastBuySearch},
buyRows:(current.result?.buys??[]).map((row)=>[row?.rating??null,row?.price??null,row?.definitionId??null,
row?.affiliation?.name??null,
buyRowName({t,nameOf:staticNameOf},row)]),
ready:readyModel({t,result:current.result,busy:current.busy===true})!==null,
lineupBuys:(current.result?.lineup??[]).filter((row)=>row?.buy===true).length,
lineupNamed:(current.result?.lineup??[]).filter((row)=>row?.buy===true&&typeof row?.affiliation?.name==='string').length,
shop:current.result?.shop??null,
counterweight:current.result?.counterweight??null,
memo:{...memoStats},
frozen:{...frozen.state(),warm:warmState(),pendingShow},lineup:(current.result?.lineup??[]).length,locked:(current.locked??[]).map((row)=>row?.lock??null),locks:{...locks},stale:current.stale===true,pitch:{...pitch,ok:squadWatch.ok,reason:squadWatch.reason,mine:(current.result?.mine??[]).length,ours:(placed.get(current.key)??new Set).size},lastResult,challenge:last?.key??null,busy:current.busy,reading,showing:current.showing,shown:current.shown,submitted:current.submitted,
answered:current.answered===true,retry:retryReady(),retries,
chain:{id:chainId,redo:chainRedo,cheapen:chainCheapen},chainPhase:current.redo===true?'redo':current.busy===true?'foreground':background===true?'cheapen':null,
cheapen:{...cheapenSeen,offerTaken,offerBack,offerRefused,offerRestored,offersKept:offers.size,
offer:current.offer===null||current.offer===undefined?null:{savings:current.offer.savings,spend:current.offer.spend,
count:current.offer.count,taken:current.offer.taken===true,alive:offerAlive(),club:current.offer.club!==null&&current.offer.club!==undefined},
background,percent:cheapenPercent,base:cheapenBase,ceiling:cheapenCeiling,adoptFailed,port:adopt!==null,last:cheapenLast===null?null:{...cheapenLast},
rebuilds:cheapenRebuilds,ladder:cheapenLadder===null?null:{...cheapenLadder,rungs:(cheapenLadder.rungs??[]).map((one)=>({...one}))},
hybrid:{door:hybridDoor(),live:cheapenHybrid,chain:cheapenChain,rescue:cheapenRescue,stalled:cheapenStalled,was:cheapenDoor,reasons:{...hybridSeen},outcome:hybridOutcome===null?null:{...hybridOutcome},adopted:current.adopted===true}},
screen:{...seen,hook:last?.hook??null},cache:cacheSnapshot(),watch:{ok:watch.ok,reason:watch.reason,...(watch.state()??{})},submit:hookState(),guard:(current.guard?.blockers??[]).map((row)=>({code:row?.code,confirmable:row?.confirmable===true,ids:row?.ids??[]})),warnings:current.guard?.warnings??[],notice:current.said?.key??null,warn:current.warn?.key??null,solved:current.result?.ok===true,
deadLocks:deadLockRows().map((row)=>({id:row.id,named:row.name!==null,droppable:setLock!==null&&Number.isSafeInteger(row.id)&&row.id>0})),
eaNotice:{said:saidOk,skipped:saidSkipped,port:eaNotice!==null,presses:keyPresses,
seen:keySeen,last:lastKey===null?null:{...lastKey}},
say:`${flashKind()??'-'}/${current.said?`${current.said.key}@${current.said.why}`:'-'}`,
why:(()=>{const one=whyFacts(current.result)
return one===null?null
:one.kind==='none'?'no-counted:calm'
:`${one.name}:${one.candidates}/${one.need}:${one.tight?'tight':'calm'}${one.buy?`:club${one.fromClub}`:''}`})(),verdict:current.result?.verdict??null,live:current.live,burn:current.result?.burn??null,price:current.result?.price??null,search:current.result?.search??null,pool:current.result?.pool??null,mounted:doc?.querySelectorAll?.(WINDOW_SELECTOR)?.length??0}),
dispose(){
disposed=true
cancel()
dropAll()
pendingShow=false
watch.dispose()
watch={dispose(){},ok:false,reason:'disposed',state:()=>null}
squadWatch.dispose()
squadWatch={dispose(){},ok:false,reason:'disposed'}
watched=null
placed.clear()
boughtSwaps.clear()
frozen.clear()
submitHook?.detach?.()
last=null}}}
