import{isCriticalStop} from '../automation/stop-reasons.js'
export const SOUND_FEATURE='notifications'
export const VOLUME=0.07
export const RAMP_SECONDS=0.012
export const TONES=Object.freeze({bought:Object.freeze([{hz:880,ms:90},{hz:1318,ms:150}]),outbid:Object.freeze([{hz:523,ms:100},{hz:349,ms:190}]),alert:Object.freeze([{hz:233,ms:200},{hz:0,ms:70},{hz:233,ms:200},{hz:0,ms:70},{hz:233,ms:320}]),done:Object.freeze([{hz:587,ms:120},{hz:440,ms:200}])})
export function toneFor(event,payload){if(event==='bought') return 'bought'
if(event==='outbid')return 'outbid'
if(event==='stopped'){
return isCriticalStop(payload?.reason)?'alert':'done'
}
return null}
function browserAudio(){const Ctor=globalThis.AudioContext
return typeof Ctor==='function'?new Ctor():null}
export function createSounds(deps={}){
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const audio=typeof deps.audio==='function'?deps.audio:browserAudio
let ctx=null
let broken=false
function context(){if(broken)return null
if(ctx)return ctx
let made
try{made=audio()}catch{broken=true
return null}
if(!made||typeof made.createOscillator!=='function'||typeof made.createGain!=='function'){broken=true
return null}
ctx=made
return ctx}
function wake(target){if(target.state!=='suspended'||typeof target.resume!=='function') return
try{const result=target.resume()
if(result&&typeof result.catch==='function') result.catch(()=>{})}catch{
}}
function play(name){const steps=TONES[name]
if(!steps) return 'unknown'
if(!isActive(SOUND_FEATURE)) return 'off'
const target=context()
if(!target) return 'silent'
try{wake(target)
let at=Number(target.currentTime)||0
for(const step of steps){const seconds=step.ms / 1000;
if(step.hz>0)note(target,step.hz,at,seconds)
at+=seconds}
return 'played'
}catch{
broken=true
ctx=null
return 'silent'
}}
return{play,
record(event,payload){const tone=toneFor(event,payload)
return tone===null?null:play(tone)}}}
function note(ctx,hz,at,seconds){const osc=ctx.createOscillator()
const gain=ctx.createGain()
osc.type='sine'
osc.frequency.setValueAtTime(hz,at)
const peak=Math.max(RAMP_SECONDS,seconds / 2);
gain.gain.setValueAtTime(0,at);
gain.gain.linearRampToValueAtTime(VOLUME,at+Math.min(RAMP_SECONDS,peak));
gain.gain.setValueAtTime(VOLUME,at+Math.max(0,seconds-RAMP_SECONDS));
gain.gain.linearRampToValueAtTime(0,at+seconds);
osc.connect(gain);
gain.connect(ctx.destination);
osc.start(at);
osc.stop(at+seconds)}
