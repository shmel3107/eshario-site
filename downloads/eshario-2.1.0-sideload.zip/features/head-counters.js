export const HOUR_MS=3_600_000
export const SEARCH_HOUR_CAP=1_000
export const SEARCH_HOUR_REFUSAL='search-hour'
export const SBC_HOUR_CAP=89
export const SBC_DAY_CAP=300
export function dayKeyOf(now){const date=new Date(Number.isFinite(now)?now:0)
const pad=(value)=>String(value).padStart(2,'0')
return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`}
export function readStamps(stored,now,windowMs){const list=Array.isArray(stored)
?stored
:(stored&&typeof stored==='object'&&Array.isArray(stored.stamps)?stored.stamps:[])
const out=[]
for(const value of list){if(!Number.isFinite(value)||value>now)continue
if(now-value>=windowMs)continue
out.push(value)}
return out.sort((a,b)=>a-b)}
export function readDayCount(stored){if(!stored||typeof stored!=='object'||Array.isArray(stored))return{day:null,used:0}
const day=typeof stored.day==='string'&&stored.day!==''?stored.day:null
const used=Number.isSafeInteger(stored.used)&&stored.used>=0?stored.used:0
return day===null?{day:null,used:0}:{day,used}}
export function readFixedWindow(stored,now,windowMs){const empty={start:null,used:0,wall:null}
if(!Number.isFinite(now)||!Number.isSafeInteger(windowMs)||windowMs<=0)return empty
const box=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:null
if(box!==null&&Number.isFinite(box.start)){const start=box.start
if(start>now||now-start>=windowMs)return empty
const used=Number.isSafeInteger(box.used)&&box.used>0?box.used:0
if(used===0)return empty
const wall=Number.isFinite(box.wall)&&box.wall>=start&&box.wall<=now?box.wall:null
return{start,used,wall}}
const stamps=readStamps(stored,now,windowMs)
if(stamps.length===0)return empty
return{start:stamps[0],used:stamps.length,wall:null}}
function readWindowLog(stored,keep){const list=Array.isArray(stored)?stored:[]
const out=[]
for(const one of list){if(!one||typeof one!=='object'||Array.isArray(one))continue
if(!Number.isFinite(one.opened))continue
if(!Number.isSafeInteger(one.used)||one.used<0)continue
out.push({opened:one.opened,
wall:Number.isFinite(one.wall)&&one.wall>=one.opened?one.wall:null,
used:one.used})}
out.sort((a,b)=>a.opened-b.opened)
const room=Number.isSafeInteger(keep)&&keep>0?keep:1
return out.slice(-room)}
export function untilText(untilAt,now){if(!Number.isFinite(untilAt)||!Number.isFinite(now))return null
const left=Math.max(0,Math.ceil((untilAt-now)/1000))
const pad=(value)=>String(value).padStart(2,'0')
return `${pad(Math.floor(left/60))}:${pad(left%60)}`}
export function createRateWindow(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('head-counters: окну нужны часы (правило 6 NIGHT_BRIEF)')}
const cap=Number.isSafeInteger(deps.cap)&&deps.cap>0?deps.cap:1
const windowMs=Number.isSafeInteger(deps.windowMs)&&deps.windowMs>0?deps.windowMs:HOUR_MS
const storage=deps.storage??null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let stamps=[]
let pending=null
const prune=(now)=>{stamps=stamps.filter((at)=>at<=now&&now-at<windowMs)}
const save=()=>{if(storage===null||typeof storage.write!=='function')return false
try{const done=storage.write({stamps:[...stamps]})
if(done&&typeof done.catch==='function')done.catch(onError)
return true}catch(err){onError(err)
return false}}
return{cap,windowMs,
load(){if(pending!==null)return pending
pending=(async()=>{if(storage!==null&&typeof storage.read==='function'){try{stamps=readStamps(await storage.read(),clock.now(),windowMs)}catch(err){onError(err)
stamps=[]}}
return{used:stamps.length,left:Math.max(0,cap-stamps.length)}})()
return pending},
left(){prune(clock.now())
return Math.max(0,cap-stamps.length)},
nextAt(){const now=clock.now()
prune(now)
return stamps.length>=cap?stamps[0]+windowMs:null},
take(at){const now=clock.now()
prune(now)
const when=Number.isFinite(at)&&at<=now?at:now
stamps.push(when)
stamps.sort((a,b)=>a-b)
save()
return stamps.length},
dump(){prune(clock.now())
return{stamps:[...stamps]}},
restore(stored){stamps=readStamps(stored,clock.now(),windowMs)
return stamps.length},
state(){const now=clock.now()
prune(now)
const until=stamps.length>=cap?stamps[0]+windowMs:null
return{cap,windowMs,used:stamps.length,left:Math.max(0,cap-stamps.length),
over:Math.max(0,stamps.length-cap),full:stamps.length>=cap,until,
untilText:until===null?null:untilText(until,now)}}}}
export const WINDOW_LOG_KEEP=6
export function createFixedWindow(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('head-counters: окну нужны часы (правило 6 NIGHT_BRIEF)')}
const cap=Number.isSafeInteger(deps.cap)&&deps.cap>0?deps.cap:1
const windowMs=Number.isSafeInteger(deps.windowMs)&&deps.windowMs>0?deps.windowMs:HOUR_MS
const keep=Number.isSafeInteger(deps.keep)&&deps.keep>0?deps.keep:WINDOW_LOG_KEEP
const storage=deps.storage??null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let start=null
let used=0
let wall=null
let log=[]
let pending=null
const roll=(now)=>{if(start===null)return false
if(!Number.isFinite(now)||now-start<windowMs)return false
log.push({opened:start,wall,used})
while(log.length>keep)log.shift()
start=null
used=0
wall=null
return true}
const snapshot=()=>({start,used,wall,log:log.map((one)=>({...one}))})
const restoreFrom=(stored)=>{const box=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:null
const parsed=readFixedWindow(stored,clock.now(),windowMs)
start=parsed.start
used=parsed.used
wall=parsed.wall
log=readWindowLog(box?.log,keep)}
const save=()=>{if(storage===null||typeof storage.write!=='function')return false
try{const done=storage.write(snapshot())
if(done&&typeof done.catch==='function')done.catch(onError)
return true}catch(err){onError(err)
return false}}
return{cap,windowMs,keep,
load(){if(pending!==null)return pending
pending=(async()=>{if(storage!==null&&typeof storage.read==='function'){try{restoreFrom(await storage.read())}catch(err){onError(err)
start=null
used=0
wall=null
log=[]}}
return{used,left:Math.max(0,cap-used)}})()
return pending},
left(){roll(clock.now())
return Math.max(0,cap-used)},
nextAt(){roll(clock.now())
return start!==null&&used>=cap?start+windowMs:null},
take(at){const now=clock.now()
roll(now)
const when=Number.isFinite(at)&&at<=now?at:now
if(start===null){start=when
used=0
wall=null}
used+=1
if(used>=cap&&wall===null)wall=when
save()
return used},
dump(){roll(clock.now())
return snapshot()},
restore(stored){restoreFrom(stored)
return used},
windows(){roll(clock.now())
const out=log.map((one)=>({...one,live:false}))
if(start!==null)out.push({opened:start,wall,used,live:true})
return out},
state(){const now=clock.now()
roll(now)
const until=start!==null&&used>=cap?start+windowMs:null
return{cap,windowMs,used,left:Math.max(0,cap-used),
over:Math.max(0,used-cap),full:used>=cap,start,wall,until,
untilText:until===null?null:untilText(until,now)}}}}
export function createDayCount(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('head-counters: суткам нужны часы (правило 6 NIGHT_BRIEF)')}
const cap=Number.isSafeInteger(deps.cap)&&deps.cap>0?deps.cap:1
let day=dayKeyOf(clock.now())
let used=0
const rollover=()=>{const today=dayKeyOf(clock.now())
if(today===day)return false
day=today
used=0
return true}
return{cap,
left(){rollover()
return Math.max(0,cap-used)},
take(count=1){rollover()
const want=Number.isSafeInteger(count)&&count>0?count:1
used+=want
return used},
dump(){rollover()
return{day,used}},
restore(stored){const parsed=readDayCount(stored)
day=dayKeyOf(clock.now())
used=parsed.day===day?parsed.used:0
return used},
state(){rollover()
return{day,cap,used,left:Math.max(0,cap-used),over:Math.max(0,used-cap),full:used>=cap}}}}
export function createSbcSubmits(deps={}){const clock=deps.clock
const storage=deps.storage??null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const hour=createFixedWindow({clock,cap:SBC_HOUR_CAP,windowMs:HOUR_MS,onError})
const day=createDayCount({clock,cap:SBC_DAY_CAP})
let pending=null
const save=()=>{if(storage===null||typeof storage.write!=='function')return false
try{const done=storage.write({hour:hour.dump(),day:day.dump()})
if(done&&typeof done.catch==='function')done.catch(onError)
return true}catch(err){onError(err)
return false}}
return{hourCap:SBC_HOUR_CAP,dayCap:SBC_DAY_CAP,
load(){if(pending!==null)return pending
pending=(async()=>{if(storage!==null&&typeof storage.read==='function'){let stored=null
try{stored=await storage.read()}catch(err){onError(err)
stored=null}
if(stored&&typeof stored==='object'){hour.restore(stored.hour)
day.restore(stored.day)}}
return{hour:hour.state().used,day:day.state().used}})()
return pending},
left(){return Math.min(hour.left(),day.left())},
nextAt(){return hour.nextAt()},
take(){hour.take()
day.take(1)
save()
return{hour:hour.state().used,day:day.state().used}},
windows(){return hour.windows()},
state(){const h=hour.state()
const d=day.state()
const rows=hour.windows()
return{hour:h,day:d,left:Math.min(h.left,d.left),windows:rows,
line:`СБЧ: ${h.used}/${h.cap} за час, ${d.used}/${d.cap} за сутки (${d.day})`
+(h.until===null?'':`, час отпустит через ${h.untilText}`)
+`; ${windowsLine(rows)}`}}}}
export function windowsLine(rows){const list=Array.isArray(rows)?rows:[]
if(list.length===0)return'окон сдач ещё не было'
const clock12=(at)=>{const date=new Date(at)
const pad=(value)=>String(value).padStart(2,'0')
return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`}
const mins=(ms)=>`${Math.round(ms/60_000)} мин`
const out=[]
for(let at=0;at<list.length;at+=1){const one=list[at]
const next=list[at+1] ?? null
const parts=[`окно ${one.live===true?'живое ':''}с ${clock12(one.opened)}: сдач ${one.used}`]
if(Number.isFinite(one.wall))parts.push(`упор ${clock12(one.wall)} (через ${mins(one.wall-one.opened)} после первой)`)
if(next!==null)parts.push(`следующая сдача ${clock12(next.opened)} (через ${mins(next.opened-one.opened)} после первой этого окна)`)
out.push(parts.join(', '))}
return out.join(' | ')}
export function createDayProfit(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('head-counters: прибыли дня нужны часы (правило 6 NIGHT_BRIEF)')}
const profitOf=typeof deps.profitOf==='function'?deps.profitOf:()=>0
const empty=()=>({bought:{count:0,coins:0},sold:{count:0,net:0,estimated:0},quick:{count:0,coins:0}})
let day=dayKeyOf(clock.now())
let book=empty()
const rollover=()=>{const today=dayKeyOf(clock.now())
if(today===day)return false
day=today
book=empty()
return true}
return{
bought(coins){rollover()
book.bought.count+=1
book.bought.coins+=coins
return book},
sold(coins,net,estimated){rollover()
book.sold.count+=1
book.sold.net+=net
if(estimated===true)book.sold.estimated+=1
return book},
quick(coins){rollover()
book.quick.count+=1
book.quick.coins+=coins
return book},
dump(){rollover()
return{day,bought:{...book.bought},sold:{...book.sold},quick:{...book.quick}}},
restore(stored){const today=dayKeyOf(clock.now())
day=today
book=empty()
if(!stored||typeof stored!=='object'||Array.isArray(stored))return false
if(stored.day!==today)return false
const parsed=sanitizeDayBook(stored)
if(parsed===null)return false
book=parsed
return true},
state(){rollover()
const profit=profitOf(book)
return{day,bought:{...book.bought},sold:{...book.sold},quick:{...book.quick},profit,
estimated:book.sold.estimated>0,
line:`прибыль за ${day}: ${profit} монет (продано ${book.sold.count+book.quick.count}, куплено ${book.bought.count})`
+(book.sold.estimated>0?`, оценок ${book.sold.estimated}`:'')}}}}
const isMoney=(value)=>typeof value==='number'&&Number.isFinite(value)&&value>=0
const isCount=(value)=>Number.isSafeInteger(value)&&value>=0
export function sanitizeDayBook(stored){const{bought,sold,quick}=stored??{}
if(!isCount(bought?.count)||!isMoney(bought?.coins))return null
if(!isCount(sold?.count)||!isMoney(sold?.net)||!isCount(sold?.estimated))return null
if(!isCount(quick?.count)||!isMoney(quick?.coins))return null
return{bought:{count:bought.count,coins:bought.coins},
sold:{count:sold.count,net:sold.net,estimated:sold.estimated},
quick:{count:quick.count,coins:quick.coins}}}
export function headCountersLine(parts={}){const rows=[]
const search=parts.search??null
if(search)rows.push(`поиски: ${search.used}/${search.cap} за час, осталось ${search.left}`
+(search.until===null||search.until===undefined?'':`, отпустит через ${search.untilText}`))
else rows.push('поиски: нет счётчика')
rows.push(parts.sbc?.line??'СБЧ: нет счётчика')
rows.push(parts.profit?.line??'прибыль дня: нет счётчика')
return rows.join('\n')}
