import{nextPrice,prevPrice,floorToValidPrice,isValidPrice,AUCTION_MAX_BID,MIN_PRICE} from './price-grid.js'
export const MIN_STARTING_BID=150
export const MIN_BUY_NOW=200
export const LIST_DURATIONS=Object.freeze([3600,10800,21600,43200,86400,259200])
export const DEFAULT_DURATION=3600
export const LIST_FEATURE='autoSeller'
export function readPriceLimits(limits){if(!limits||typeof limits!=='object')return null
const minimum=Number(limits.minimum)
const maximum=Number(limits.maximum)
if(!Number.isSafeInteger(minimum)||!Number.isSafeInteger(maximum))return null
if(minimum<1||maximum<minimum)return null
return{minimum,maximum}}
export function smartListPrice(input={}){const raw=Number(input.reference)
if(!Number.isFinite(raw)||raw<=0)return{ok:false,reason:'no-reference'}
const band=readPriceLimits(input.limits)
const banded=band!==null
const bounds=listingBounds(input.limits)
const want=prevPrice(floorToValidPrice(Math.min(raw,bounds.buyMax)))
const price=pricePair(want,bounds)
if(price.ok!==true)return price
return{ok:true,startingBid:price.startingBid,buyNow:price.buyNow,reference:Math.round(raw),banded}}
function ceilToValidPrice(price){const value=Number(price)
const floored=floorToValidPrice(Number.isFinite(value)?value:MIN_PRICE)
return floored>=value?floored:nextPrice(floored)}
export function listingBounds(limits){const band=readPriceLimits(limits)
if(!band)return{bidMin:MIN_STARTING_BID,bidMax:floorToValidPrice(prevPrice(AUCTION_MAX_BID)),buyMin:MIN_BUY_NOW,buyMax:AUCTION_MAX_BID,banded:false}
const buyMax=floorToValidPrice(Math.min(band.maximum,AUCTION_MAX_BID))
return{bidMin:ceilToValidPrice(Math.max(band.minimum,MIN_STARTING_BID)),
bidMax:Math.max(floorToValidPrice(prevPrice(buyMax)),MIN_STARTING_BID),
buyMin:ceilToValidPrice(Math.max(nextPrice(band.minimum),MIN_BUY_NOW)),buyMax,banded:true}}
export function nudgeListPrice(input={}){const current=Number(input.buyNow)
const factor=Number(input.factor)
if(!Number.isFinite(current)||current<=0)return{ok:false,reason:'no-reference'}
if(!Number.isFinite(factor)||factor<=0)return{ok:false,reason:'no-reference'}
const bounds=listingBounds(input.limits)
let buyNow=floorToValidPrice(current*factor)
if(buyNow===floorToValidPrice(current)){buyNow=factor>1?nextPrice(current):prevPrice(current)}
return pricePair(buyNow,bounds)}
function pricePair(want,bounds){let buyNow=want
if(buyNow>bounds.buyMax)buyNow=floorToValidPrice(bounds.buyMax)
if(buyNow<bounds.buyMin)buyNow=bounds.buyMin
let startingBid=prevPrice(buyNow)
if(startingBid<bounds.bidMin)startingBid=bounds.bidMin
if(startingBid>bounds.bidMax)startingBid=bounds.bidMax
if(!(buyNow>startingBid)){const lifted=nextPrice(startingBid)
if(lifted>bounds.buyMax)return{ok:false,reason:'band-too-narrow'}
buyNow=lifted}
if(!isValidPrice(startingBid)||!isValidPrice(buyNow))return{ok:false,reason:'below-minimum'}
if(buyNow>bounds.buyMax||startingBid<MIN_STARTING_BID||buyNow<MIN_BUY_NOW)return{ok:false,reason:'band-too-narrow'}
return{ok:true,startingBid,buyNow}}
export function atListPrice(input={}){const raw=Number(input.reference)
if(!Number.isFinite(raw)||raw<=0)return{ok:false,reason:'no-reference'}
return pricePair(floorToValidPrice(raw),listingBounds(input.limits))}
export function normalizeDuration(value){const seconds=Number(value)
return LIST_DURATIONS.includes(seconds)?seconds:DEFAULT_DURATION}
