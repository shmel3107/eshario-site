import{jitterFor} from '../automation/breaks.js'
import{STOP_REASON_KEYS} from '../automation/stop-reasons.js'
import{netAfterTax} from './tax.js'
import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoLink} from '../ui/controls.js'
import{createCardViews,cardViewButton,sanitizeCardView,CARD_VIEW_DEFAULT,
markScrollGutter,clearScrollGutter,SCROLL_MARK} from './card-views.js'
import{priceBadgePeek} from './price-badges.js'
import{sanitizeUnassignedRules,rulesForStore,defaultUnassignedRules,adoptDefaults,planByRules,planCounts,
DESTINATIONS,DUPE_ABOVE_DESTS,DUPE_BELOW_DESTS,DUPE_NONE_DESTS,
TIER_BRONZE,TIER_SILVER,TIER_GOLD,
DUPE_PRICE_DEFAULT} from './unassigned-brain.js'
const STRIP_STYLESHEET=new URL('../ui/unassigned-strip.css',import.meta.url).href
const STRIP_LINK_ID='fut-companion-unassigned-strip'
const STRIP_BUILD='UNKEEP1D'
const STRIP_SELECTOR='[data-fut-unassigned-strip]'
const GRID_STYLESHEET=new URL('../ui/unassigned-grid.css',import.meta.url).href
const GRID_LINK_ID='fut-companion-unassigned-grid'
export const UNASSIGNED_GRID_FEATURE='enhancedUnassignedList'
export const UNASSIGNED_TOOLS_FEATURE='unassignedTools'
const GRID_LIST_SELECTOR='ul.itemList'
const GRID_MARK='futUnassignedGrid'
const GRID_SELECTOR='[data-fut-unassigned-grid]'
const COMPACT_MARK='futUnassignedCompact'
const WIDE_MARK='futUnassignedWide'
const WIDE_SELECTOR='[data-fut-unassigned-wide]'
const AIR_MARK='futUnassignedAir'
const AIR_SELECTOR='[data-fut-unassigned-air]'
const WIDE_HOSTS=Object.freeze(['.ut-navigation-container-view','.ut-navigation-container-view--content',
'.ut-split-view','.ut-content'])
const WIDE_STOP='.ut-root-view'
const GRID_VAR='--fut-un-cols'
const AUTO_MARK='futUnassignedAuto'
const UNASSIGNED_ROOT_SELECTOR='.ut-unassigned-view'
export const EXPENSIVE_FROM_DEFAULT=1000
export const EXPENSIVE_FROM_MAX=10_000_000
export const STEP_CARDS=20
export const STEP_PAUSE_MIN_MS=900
export const STEP_PAUSE_MAX_MS=2_100
export const SCENARIOS=Object.freeze(['dupes-storage','expensive-club','expensive-quicksell'])
export const ARMED_SCENARIOS=Object.freeze(['expensive-quicksell'])
export function planPrint(plan){if(plan?.ok!==true)return null
const steps=(Array.isArray(plan.steps)?plan.steps:[])
.map((step)=>`${step.kind}:${(Array.isArray(step.ids)?step.ids:[]).join('.')}`).join('|')
return `${plan.scenario}#${plan.cards}#${plan.coins}#${steps}`}
const int=(value)=>(Number.isSafeInteger(value)?value:null)
const coins=(value)=>{const n=int(value)
return n!==null&&n>=0?n:0}
export function sanitizeExpensiveFrom(stored){const value=typeof stored==='string'&&/^\d{1,9}$/.test(stored.trim())
?Number(stored.trim()):stored
if(!Number.isSafeInteger(value)||value<0||value>EXPENSIVE_FROM_MAX)return EXPENSIVE_FROM_DEFAULT
return value}
export function canList(card){return card?.tradable===true
&&(card?.movable===true||card?.tradeableDuplicate===true)}
export function groupUnassigned(cards,opts={}){const list=Array.isArray(cards)?cards.filter((card)=>card&&typeof card==='object'&&int(card.id)!==null):[]
const from=sanitizeExpensiveFrom(opts.expensiveFrom)
const priceOf=typeof opts.priceOf==='function'?opts.priceOf:()=>null
const isLocked=typeof opts.isLocked==='function'?opts.isLocked:()=>false
const storageOn=opts.storage===true
const out={expensive:[],listable:[],movable:[],storable:[],discardable:[],locked:[],all:list,expensiveFrom:from,value:0,priced:0}
for(const card of list){
let locked=false
try{locked=isLocked(card.id)===true}catch{locked=true}
if(locked){out.locked.push(card)
continue}
let price=null
try{const value=priceOf(card)
price=Number.isSafeInteger(value)&&value>=0?value:null}catch{price=null}
if(price!==null){out.value+=price
out.priced+=1}
if(canList(card))out.listable.push(card)
if(canList(card)&&price!==null&&price>=from){out.expensive.push(card)
continue}
if(storageOn&&card.untradeableDuplicate===true&&card.storable===true)out.storable.push(card)
if(card.movable===true)out.movable.push(card)
if(card.discardable===true&&card.duplicateLoan!==true)out.discardable.push(card)}
return out}
export function priceAsOnBadge(priceOf,onError=()=>{}){const readPrice=typeof priceOf==='function'?priceOf:()=>null
return (card)=>{let shown=null
try{shown=priceBadgePeek(card?.definitionId??card?.defId)}catch(err){onError(err)
shown=null}
if(Number.isSafeInteger(shown)&&shown>0)return shown
return readPrice(card)}}
export function stripSummary(groups,capacity={}){const value=coins(groups?.value)
const all=Array.isArray(groups?.all)?groups.all.length:0
const priced=int(groups?.priced)??0
const pile=(name)=>{const raw=capacity?.[name]
const used=int(raw?.used)
const size=int(raw?.size)
return used!==null&&size!==null&&used>=0&&size>=0&&used<=size?{used,size,free:size-used,loaded:raw?.loaded===false?false:true}:null}
return{cards:all,
value,
priced,
net:netAfterTax(value),
unpriced:Math.max(0,all-(Array.isArray(groups?.locked)?groups.locked.length:0)-priced),
quicksell:(Array.isArray(groups?.all)?groups.all:[]).reduce((sum,card)=>{
const shut=Array.isArray(groups?.locked)&&groups.locked.includes(card)
return shut?sum:sum+coins(card?.discardValue)},0),
locked:Array.isArray(groups?.locked)?groups.locked.length:0,
transfer:pile('transfer'),
storage:pile('storage')}}
function fit(count,pile){if(!pile)return{take:count,left:0}
const take=Math.max(0,Math.min(count,pile.free))
return{take,left:count-take}}
function byRating(cards,take){if(take>=cards.length)return cards.slice(0,take)
const order=cards.map((card,at)=>({at,rating:Number.isSafeInteger(card?.rating)&&card.rating>=0?card.rating:null}))
order.sort((a,b)=>{if(a.rating===b.rating)return a.at-b.at
if(a.rating===null)return 1
if(b.rating===null)return -1
return b.rating-a.rating})
return order.slice(0,take).map((one)=>one.at).sort((a,b)=>a-b).map((at)=>cards[at])}
export function planUnassigned(groups,scenario,capacity={}){const bad=(reason)=>({ok:false,reason,scenario,steps:[],cards:0,coins:0,left:{},locked:0,stays:0})
if(!SCENARIOS.includes(scenario))return bad('unknown-scenario')
if(!groups||typeof groups!=='object')return bad('no-cards')
const summary=stripSummary(groups,capacity)
const steps=[]
const left={}
const taken=new Set()
let value=0
const push=(kind,cards,pile,rank)=>{
const free=(Array.isArray(cards)?cards:[]).filter((card)=>!taken.has(card.id))
if(free.length===0)return
const{take,left:over}=fit(free.length,pile??null)
if(over>0)left[kind]=over
if(take===0)return
const slice=rank===undefined?free.slice(0,take):rank(free,take)
for(const card of slice)taken.add(card.id)
steps.push({kind,ids:slice.map((card)=>card.id),cards:take})
if(kind==='discard')value+=slice.reduce((sum,card)=>sum+coins(card.discardValue),0)}
if(scenario==='dupes-storage'){push('storage',groups.storable,summary.storage,byRating)
push('club',groups.movable,null)}
else{push('transfer',groups.expensive,summary.transfer)
if(scenario==='expensive-club')push('club',groups.movable,null)
else push('discard',groups.discardable,null)}
const cards=steps.reduce((sum,step)=>sum+step.cards,0)
const stays=(Array.isArray(groups.all)?groups.all.length:0)-summary.locked-cards
if(cards===0)return{...bad('nothing-to-do'),locked:summary.locked,left,stays}
return{ok:true,reason:null,scenario,steps,cards,coins:value,left,locked:summary.locked,stays:Math.max(0,stays)}}
export function chunkPlan(plan){const out=[]
for(const step of Array.isArray(plan?.steps)?plan.steps:[]){const ids=Array.isArray(step?.ids)?step.ids:[]
const size=CHUNK_CARDS[step.kind]??STEP_CARDS
for(let at=0;at<ids.length;at+=size){const slice=ids.slice(at,at+size)
const chunk={kind:step.kind,ids:slice,cards:slice.length}
if(step.expect&&typeof step.expect==='object'){chunk.expect={}
for(const id of slice){if(Object.hasOwn(step.expect,id))chunk.expect[id]=step.expect[id]}}
out.push(chunk)}}
return out}
const CHUNK_CARDS=Object.freeze({redeem:1})
export function pauseForStep(step){const middle=(STEP_PAUSE_MIN_MS+STEP_PAUSE_MAX_MS)/2
const spread=(STEP_PAUSE_MAX_MS-STEP_PAUSE_MIN_MS)/2
return Math.min(STEP_PAUSE_MAX_MS,Math.max(STEP_PAUSE_MIN_MS,Math.round(middle+jitterFor(step,spread))))}
export function createUnassignedRun(deps={}){const perform=typeof deps.perform==='function'?deps.perform:null
const native=typeof deps.native==='function'?deps.native:null
const sleep=typeof deps.sleep==='function'?deps.sleep:(ms)=>new Promise((done)=>setTimeout(done,ms))
const onTick=typeof deps.onTick==='function'?deps.onTick:()=>{}
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let running=false
let stopping=false
let done=0
let total=0
let scenario=null
let outcome=null
let doors={native:0,chunked:0,why:{}}
const snapshot=()=>({running,stopping,done,total,scenario,outcome:outcome?{...outcome}:null,
doors:{native:doors.native,chunked:doors.chunked,why:{...doors.why}}})
const tick=()=>{try{onTick(snapshot())}catch(err){onError(err)}}
return{state:snapshot,
forget(){if(running)return false
outcome=null
return true},
stop(){if(!running)return false
stopping=true
tick()
return true},
async run(plan){if(running)return{ok:false,reason:'busy'}
if(!perform)return{ok:false,reason:'guard-unavailable'}
if(plan?.ok!==true)return{ok:false,reason:plan?.reason??'no-plan'}
const steps=Array.isArray(plan.steps)?plan.steps.filter((step)=>Array.isArray(step?.ids)&&step.ids.length>0):[]
if(steps.length===0)return{ok:false,reason:'nothing-to-do'}
running=true
stopping=false
done=0
total=plan.cards
scenario=plan.scenario
outcome=null
doors={native:0,chunked:0,why:{}}
tick()
let act=0
let moved=0
let failed=null
let knife=0
const count=(result,cards)=>{const said=int(result?.count)
return said!==null&&said>=0&&said<=cards?said:cards}
try{
for(const step of steps){if(stopping){failed='stopped'
break}
if(act>0){await sleep(pauseForStep(act))
if(stopping){failed='stopped'
break}}
let whole=null
if(native!==null){try{whole=await native(step.kind,step.ids)}catch(err){onError(err)
whole={ok:false,reason:'uncertain'}}}
if(whole?.ok===true){act+=1
doors.native+=1
if(whole.reason==='confirm'){knife=int(whole.cards)??step.cards
break}
moved+=count(whole,step.cards)
done=moved
tick()
continue}
if(whole!==null&&whole.reason!=='not-native'){failed=whole.reason??'unknown-state'
act+=1
break}
doors.chunked+=1
const why=typeof whole?.why==='string'&&whole.why!==''?whole.why:'no-door'
doors.why[why]=(doors.why[why]??0)+1
const chunks=chunkPlan({steps:[step]})
for(let at=0;at<chunks.length;at+=1){if(stopping){failed='stopped'
break}
if(at>0){await sleep(pauseForStep(act))
if(stopping){failed='stopped'
break}}
const chunk=chunks[at]
let result
try{result=await perform(chunk.kind,chunk.ids,chunk.expect)}catch(err){onError(err)
result={ok:false,reason:'uncertain'}}
act+=1
if(result?.ok!==true){failed=result?.reason??'unknown-state'
break}
moved+=count(result,chunk.cards)
done=moved
tick()}
if(failed!==null)break}}
finally{running=false
stopping=false
outcome={ok:failed===null,reason:knife>0&&failed===null?'knife':failed,moved,total,knife}
tick()}
return{ok:failed===null,reason:failed,moved,total,knife}}}}
export function planLine(t,plan){const step=(kind)=>plan?.steps?.find((item)=>item.kind===kind)??null
const list=step('transfer')
const store=step('storage')
const club=step('club')
const cut=step('discard')
const coins=plan?.coins??0
if(store&&club)return t('unassigned.plan.storageClub',{store:store.cards,club:club.cards})
if(list&&club)return t('unassigned.plan.transferClub',{list:list.cards,club:club.cards})
if(list&&cut)return t('unassigned.plan.transferQuick',{list:list.cards,discard:cut.cards,coins})
if(store)return t('unassigned.plan.storage',{store:store.cards})
if(list)return t('unassigned.plan.transfer',{list:list.cards})
if(cut)return t('unassigned.plan.quick',{discard:cut.cards,coins})
return t('unassigned.plan.club',{club:club?.cards??0})}
export function planTitle(t,plan){const has=(kind)=>Boolean(plan?.steps?.some((item)=>item.kind===kind))
const list=has('transfer')
const store=has('storage')
const club=has('club')
const cut=has('discard')
if(store&&club)return t('unassigned.title.storageClub')
if(list&&club)return t('unassigned.title.transferClub')
if(list&&cut)return t('unassigned.title.transferQuick')
if(store)return t('unassigned.title.storage')
if(list)return t('unassigned.title.transfer')
if(cut)return t('unassigned.title.quick')
return t('unassigned.title.club')}
export function primaryPlan(plans){const list=Array.isArray(plans)?plans.filter((plan)=>plan?.ok===true):[]
if(list.length===0)return null
const safe=list.filter((plan)=>!ARMED_SCENARIOS.includes(plan.scenario))
const pool=safe.length>0?safe:list
const money=pool.find((plan)=>plan.steps?.some((step)=>step.kind==='transfer'&&step.cards>0))
return money??pool[0]}
export function createUnassignedStrip(deps={}){const{doc,t}=deps
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const priceOf=priceAsOnBadge(deps.priceOf,onError)
const isLocked=typeof deps.isLocked==='function'?deps.isLocked:()=>false
const readFrom=typeof deps.expensiveFrom==='function'?deps.expensiveFrom:()=>EXPENSIVE_FROM_DEFAULT
const readView=typeof deps.view==='function'?deps.view:()=>({})
const writeView=typeof deps.setView==='function'?deps.setView:null
const readCardView=typeof deps.cardView==='function'?deps.cardView:null
const writeCardView=typeof deps.setCardView==='function'?deps.setCardView:null
const cardViewNow=()=>{if(!readCardView)return CARD_VIEW_DEFAULT
try{return sanitizeCardView(readCardView())}catch(err){onError(err)
return CARD_VIEW_DEFAULT}}
const views=createCardViews({doc,frame:deps.frame,onError})
const readPinned=()=>{if(!writeView)return false
try{return readView()?.pinned!==false}catch(err){onError(err)
return false}}
const gridAllowed=()=>{if(typeof deps.isActive!=='function')return false
try{return deps.isActive(UNASSIGNED_GRID_FEATURE)===true}catch(err){onError(err)
return false}}
const toolsAllowed=()=>{if(typeof deps.isActive!=='function')return false
try{return deps.isActive(UNASSIGNED_TOOLS_FEATURE)===true}catch(err){onError(err)
return false}}
const readRules=()=>{if(!writeView)return defaultUnassignedRules()
try{return sanitizeUnassignedRules(readView()?.rules)}catch(err){onError(err)
return defaultUnassignedRules()}}
const writeRules=(next)=>{if(!writeView)return false
try{writeView({rules:rulesForStore(next)})}catch(err){onError(err)
return false}
try{paint()}catch(err){onError(err)}
return true}
const catalogNow=()=>{const box=last?.catalog
return{styles:Array.isArray(box?.styles)?box.styles:[],
nations:Array.isArray(box?.nations)?box.nations:[],
leagues:Array.isArray(box?.leagues)?box.leagues:[]}}
const folds={styles:false,nations:false,leagues:false,
stylesAll:false,nationsAll:false,leaguesAll:false}
let last=null
let scheduled=false
let lastResult={ok:false,reason:'not-run'}
let armed=null
let resetAsk=false
let lastCounts=null
let settles=0
let renders=0
let adoptions=0
let painted=null
let told=null
let gear=false
let ran=false
const run=createUnassignedRun({perform:deps.perform,native:deps.native,sleep:deps.sleep,onError,
onTick(state){try{paint()}catch(err){onError(err)}
if(state?.running===true){ran=true
return}
if(!ran)return
ran=false
try{deps.onIdle?.()}catch(err){onError(err)}}})
const record=(result)=>{lastResult=result
return result}
function apply(capture){if(!doc||!capture?.box)return record({ok:false,reason:'no-capture'})
last=capture
adoptOnce()
schedule()
return record({ok:true,reason:'pending'})}
function adoptOnce(){if(!writeView)return false
const rules=readRules()
if(rules.adopted===true)return false
const got=adoptDefaults(rules,catalogNow())
if(!got.changed)return false
try{writeView({rules:got.rules})}catch(err){onError(err)
return false}
return true}
const FRAME_BACKUP_MS=16
function frameFor(){const given=typeof deps.passFrame==='function'?deps.passFrame:null
if(given)return given
const view=doc?.defaultView??null
if(typeof view?.requestAnimationFrame!=='function')return null
return (fn)=>{let raced=false
const once=()=>{if(raced)return
raced=true
fn()}
try{view.requestAnimationFrame(once)}catch(err){onError(err)
once()
return}
try{view.setTimeout?.(once,FRAME_BACKUP_MS)}catch{/* кадра хватит */}}}
function schedule(now=false){const frame=frameFor()
if(frame===null&&now===true){scheduled=false
try{settle()}catch(err){onError(err)}
return false}
if(scheduled)return true
scheduled=true
if(frame)frame(pass)
else Promise.resolve().then(pass)
return true}
function pass(){scheduled=false
try{settle()}catch(err){onError(err)}}
function drop(){armed=null
run.stop()
run.forget()
told=null
last=null
painted=null
try{clearGrid()}catch(err){onError(err)}
return record({ok:false,reason:'gone'})}
function liveBox(){const box=last?.box??null
if(!box)return null
if(box.isConnected!==false)return box
let fresh=null
try{fresh=doc?.querySelector?.(UNASSIGNED_ROOT_SELECTOR)??null}catch(err){onError(err)
fresh=null}
if(!fresh||fresh===box||fresh.isConnected===false)return null
adoptions+=1
last={...last,box:fresh}
painted=null
return fresh}
function hasSomethingToSay(){const state=run.state()
return state.running===true||state.outcome!==null||told!==null}
function settle(){settles+=1
if(!last)return record({ok:false,reason:'no-capture'})
const box=liveBox()
if(!box)return drop()
if(!toolsAllowed()){remove(box)
try{markGrid(box)}catch(err){onError(err)}
return record({ok:false,reason:'locked'})}
if((!Array.isArray(last.cards)||last.cards.length===0)&&!hasSomethingToSay()){remove(box)
try{markGrid(box)}catch(err){onError(err)}
return record({ok:false,reason:'empty'})}
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,STRIP_STYLESHEET,STRIP_LINK_ID)
paint()
return record({ok:true,reason:null,cards:last.cards?.length??0})}
function markGrid(box){const lists=listsOf(box)
if(!gridAllowed()){for(const list of lists)unmarkList(list)
clearWide()
return 0}
ensureStylesheet(doc,GRID_STYLESHEET,GRID_LINK_ID)
views.ensure()
markWide(box)
let marked=0
for(const list of lists){if(!list?.dataset)continue
if(list.dataset[GRID_MARK]!=='1')list.dataset[GRID_MARK]='1'
if(list.dataset[COMPACT_MARK]!==undefined)delete list.dataset[COMPACT_MARK]
if(list.dataset[AUTO_MARK]!==undefined)delete list.dataset[AUTO_MARK]
try{if(list.style?.getPropertyValue?.(GRID_VAR))list.style?.removeProperty?.(GRID_VAR)}catch{/* нечего снимать */}
marked+=1}
views.apply(lists,cardViewNow())
return marked}
function listsOf(box){try{return Array.from(box?.querySelectorAll?.(GRID_LIST_SELECTOR)??[])}catch(err){onError(err)
return[]}}
function wideHostsOf(box){const found=[]
let node=box?.parentNode??null
for(let depth=0;node&&depth<10;depth+=1){let stop=false
try{stop=node.matches?.(WIDE_STOP)===true}catch{stop=false}
if(stop)break
let hit=false
try{hit=WIDE_HOSTS.some((selector)=>node.matches?.(selector)===true)}catch{hit=false}
if(hit)found.unshift(node)
node=node.parentNode??null}
return found}
let gutterHost=null
let gutterFor=null
function markWide(box){const hosts=wideHostsOf(box)
if(hosts.length===0)return 0
for(const host of hosts){if(!host?.dataset)continue
if(host.dataset[WIDE_MARK]!=='1')host.dataset[WIDE_MARK]='1'
if(host.dataset[AIR_MARK]!=='0')host.dataset[AIR_MARK]='0'}
if(box?.dataset&&box.dataset[AIR_MARK]!=='1')box.dataset[AIR_MARK]='1'
if(gutterFor!==box||gutterHost===null||gutterHost.isConnected===false){gutterHost=markScrollGutter(box,doc?.defaultView??null)
gutterFor=box}
else if(gutterHost.dataset&&gutterHost.dataset[SCROLL_MARK]!=='1')gutterHost.dataset[SCROLL_MARK]='1'
return hosts.length}
function clearWide(){let gone=0
if(clearScrollGutter(gutterHost)){gutterHost=null
gone+=1}
gutterFor=null
const seen=new Set()
for(const selector of[WIDE_SELECTOR,AIR_SELECTOR]){for(const node of Array.from(doc?.querySelectorAll?.(selector)??[])){if(seen.has(node))continue
seen.add(node)
if(node.dataset&&node.dataset[WIDE_MARK]!==undefined)delete node.dataset[WIDE_MARK]
if(node.dataset&&node.dataset[AIR_MARK]!==undefined)delete node.dataset[AIR_MARK]
gone+=1}}
return gone}
function unmarkList(list){if(!list)return false
let touched=false
for(const mark of[GRID_MARK,COMPACT_MARK,AUTO_MARK]){if(list.dataset&&list.dataset[mark]!==undefined){delete list.dataset[mark]
touched=true}}
try{if(list.style?.getPropertyValue?.(GRID_VAR))touched=true
list.style?.removeProperty?.(GRID_VAR)}catch{/* нечего снимать */}
if(views.unmark(list))touched=true
return touched}
function clearGrid(){let gone=0
for(const list of Array.from(doc?.querySelectorAll?.(GRID_SELECTOR)??[])){if(unmarkList(list))gone+=1}
gone+=views.clear()
gone+=clearWide()
return gone}
function gridState(){const box=last?.box??null
const lists=box?listsOf(box):[]
const first=lists[0]??null
const view=doc?.defaultView??null
let style=null
try{style=view?.getComputedStyle?.(first)??null}catch{style=null}
let row=null
try{row=first?.querySelector?.('li.listFUTItem')??null}catch{row=null}
return{feature:UNASSIGNED_GRID_FEATURE,allowed:gridAllowed(),
view:views.state(),
tile:tileNow(row),
lists:lists.length,marked:lists.filter((one)=>one?.dataset?.[GRID_MARK]==='1').length,
window:view?.innerWidth??null,
boxWidth:box?.clientWidth??null,listWidth:first?.clientWidth??null,rowWidth:row?.clientWidth??null,
rows:first?.children?.length??null,
columns:typeof style?.gridTemplateColumns==='string'?style.gridTemplateColumns:null,
chain:(box?wideChain(box):[]),
styles:Boolean(doc?.getElementById?.(GRID_LINK_ID))}}
function tileNow(tile){if(!tile)return null
const view=doc?.defaultView??null
let style=null
try{style=view?.getComputedStyle?.(tile)??null}catch{style=null}
const pad=(value)=>{const number=Number.parseFloat(value??'')
return Number.isFinite(number)?number:0}
const width=tile.clientWidth??null
const content=width===null?null:Math.max(0,width-pad(style?.paddingLeft)-pad(style?.paddingRight))
let face=null
try{face=tile.querySelector?.('.entityContainer > :first-child')?.clientWidth??null}catch{face=null}
const pair=(node)=>{if(!node)return null
const want=node.scrollWidth
const got=node.clientWidth
return{want,got,cut:want>got+1}}
let stats=null
let name=null
try{stats=pair(tile.querySelector?.('.player-stats-data-component ul')??null)}catch{stats=null}
try{name=pair(tile.querySelector?.('.entityContainer > .name')??null)}catch{name=null}
return{width,content,face,stats,name}}
function wideChain(box){const view=doc?.defaultView??null
const out=[]
let node=box
for(let depth=0;node&&depth<10;depth+=1){let style=null
try{style=view?.getComputedStyle?.(node)??null}catch{style=null}
out.push({tag:node.tagName,class:typeof node.className==='string'?node.className:'',
width:node.clientWidth??null,
maxWidth:style?.maxWidth??null,marginLeft:style?.marginLeft??null,marginRight:style?.marginRight??null,
paddingLeft:style?.paddingLeft??null,display:style?.display??null,
overflowY:style?.overflowY??null,
bar:Math.max(0,(node.offsetWidth??0)-(node.clientWidth??0)),
scrolls:(node.scrollHeight??0)>(node.clientHeight??0)+1,
gutter:node.dataset?.[SCROLL_MARK]==='1',
wide:node.dataset?.[WIDE_MARK]==='1',air:node.dataset?.[AIR_MARK]==='1'})
let stop=false
try{stop=node.matches?.(WIDE_STOP)===true}catch{stop=false}
if(stop)break
node=node.parentNode??null}
return out}
function mount(box){const existing=box.querySelector?.(STRIP_SELECTOR)??null
if(existing&&existing.parentNode===box&&box.firstChild===existing)return existing
const node=existing??el(doc,'section',{class:'fx-bar fx-unassigned-strip',dataset:{futUnassignedStrip:'1'}})
painted=null
box.insertBefore(node,box.firstChild)
return node}
function remove(box){const existing=box?.querySelector?.(STRIP_SELECTOR)??null
if(existing?.parentNode)existing.parentNode.removeChild(existing)
painted=null
return Boolean(existing)}
function model(){const from=sanitizeExpensiveFrom(readFrom())
const groups=groupUnassigned(last?.cards,{expensiveFrom:from,priceOf,isLocked,storage:last?.storage===true})
const capacity=last?.capacity??{}
const summary=stripSummary(groups,capacity)
const rules=readRules()
const brain=planByRules(last?.cards,rules,{price:priceOf,storage:last?.storage===true,
locked:isLocked,capacity})
return{from,groups,summary,short:storageShort(groups,summary),rules,brain,
catalog:catalogNow(),
view:cardViewNow(),grid:gridAllowed(),pinned:readPinned()}}
function scenarioPlans(){if(!last)return[]
const parts=model()
const dupes=parts.groups.storable.length>0
const sellable=parts.groups.listable.length>0
const offered=SCENARIOS.filter((scenario)=>(scenario==='dupes-storage'?dupes:sellable||!dupes))
const seen=new Set()
const plans=[]
for(const scenario of offered){const plan=planUnassigned(parts.groups,scenario,last?.capacity??{})
if(plan.ok!==true)continue
const shape=plan.steps.map((step)=>`${step.kind}:${step.ids.join('.')}`).join('|')
if(seen.has(shape))continue
seen.add(shape)
plans.push(plan)}
return plans}
function signature(parts,state,note){const summary=parts.summary
return JSON.stringify([summary.cards,summary.value,summary.net,summary.locked,summary.unpriced,
summary.priced,
summary.transfer,summary.storage,parts.view,parts.grid,parts.pinned,parts.short,armed,resetAsk,told,gear,
state.running,state.stopping,state.done,state.total,state.outcome,
JSON.stringify(parts.rules),planPrint(parts.brain),parts.brain.reason,
parts.summary.quicksell,
JSON.stringify(folds),JSON.stringify(Object.fromEntries(
Object.entries(parts.catalog).map(([name,list])=>[name,list.length]))),
note?.text??null,note?.left??null,note?.tip??null])}
function paint(){const box=liveBox()
if(!box)return false
try{markGrid(box)}catch(err){onError(err)}
if(!toolsAllowed()){remove(box)
return false}
const node=mount(box)
const parts=model()
const state=run.state()
const pinned=parts.pinned===true&&!gear?'1':'0'
if(node.dataset&&node.dataset.futUnassignedPinned!==pinned)node.dataset.futUnassignedPinned=pinned
const note=noteFor(state,parts.short,parts.brain)
const key=signature(parts,state,note)
if(painted===key&&node.firstChild)return true
painted=key
renders+=1
while(node.firstChild)node.removeChild(node.firstChild)
const summary=parts.summary
const head=el(doc,'div',{class:'fx-strip-head'},[logoLink(doc)])
if(state.running)head.appendChild(progressButton(state))
else head.appendChild(sortButton(parts,summary))
head.appendChild(gearButton())
if(summary.value>0)head.appendChild(el(doc,'span',{class:'fx-strip-money',
dataset:{futUnassignedMoney:String(summary.value)},
attrs:{title:moneyTipText(summary)},
text:t('unassigned.market',{coins:summary.value})}))
if(summary.quicksell>0)head.appendChild(el(doc,'span',{class:'fx-strip-qsell',
dataset:{futUnassignedQuicksell:String(summary.quicksell)},
attrs:{title:summary.value>0?t('unassigned.qsellTip'):t('unassigned.qsellTip')+' '+moneyTipText(summary)},
text:t('unassigned.qsell',{coins:summary.quicksell})}))
head.appendChild(el(doc,'span',{class:'fx-strip-air'}))
if(summary.transfer||summary.storage)head.appendChild(el(doc,'span',{class:'fx-strip-counts',
dataset:{futUnassignedPiles:'1'}},
[el(doc,'span',{class:'fx-strip-pile',attrs:{title:t(summary.transfer?.loaded===false?'unassigned.pilesColdTip':'unassigned.pilesTransferTip')},
text:t('unassigned.pilesTransfer',{list:summary.transfer?.loaded===false?'?':(summary.transfer?.used??'?'),listMax:summary.transfer?.size??'?'})}),
el(doc,'span',{text:' · '}),
el(doc,'span',{class:'fx-strip-pile',attrs:{title:t(summary.storage?.loaded===false?'unassigned.pilesColdTip':'unassigned.pilesStorageTip')},
text:t('unassigned.pilesStorage',{store:summary.storage?.loaded===false?'?':(summary.storage?.used??'?'),storeMax:summary.storage?.size??'?'})})]))
const corner=el(doc,'div',{class:'fx-strip-corner'})
const toggle=viewField(parts)
if(toggle)corner.appendChild(toggle)
const pin=pinButton(parts)
if(pin)corner.appendChild(pin)
if(corner.firstChild)head.appendChild(corner)
node.appendChild(head)
if(parts.rules.warned!==true)node.appendChild(warnBox(parts.rules))
if(gear)node.appendChild(gearBox(parts))
if(note?.text)node.appendChild(el(doc,'div',{class:'fx-strip-note',dataset:{futUnassignedNote:'1'},text:note.text}))
if(note?.left){const line=el(doc,'div',{class:'fx-strip-note fx-strip-note-left',
dataset:{futUnassignedLeft:'1'},text:note.left})
if(note.tip){line.className+=' fx-strip-hint'
line.setAttribute('title',note.tip)}
node.appendChild(line)}
return true}
function sortButton(parts,summary){const plan=parts.brain
const ready=plan?.ok===true
const button=el(doc,'button',{class:ready?'fx-strip-go':'fx-strip-go fx-strip-go-off',
dataset:{futUnassignedScenario:'rules',futUnassignedGo:'1'},attrs:{type:'button'}},
[el(doc,'span',{class:'t',text:t('unassigned.go')}),
el(doc,'span',{class:'d',text:ready
?t('unassigned.goCount',{cards:plan.cards})
:t('unassigned.goCards',{cards:summary.cards})})])
if(!ready)button.disabled=true
button.addEventListener('click',()=>{try{pressPlan(plan)}catch(err){onError(err)}})
return button}
function pressPlan(plan){
const fresh=replan(plan?.scenario)
if(!ARMED_SCENARIOS.includes(plan?.scenario)){armed=null
start(fresh)
return false}
const print=planPrint(fresh)
if(print===null||armed!==print){armed=print
paint()
return true}
armed=null
start(fresh)
return false}
function gearButton(){const button=el(doc,'button',{class:'fx-action fx-action-square fx-strip-gear',
dataset:{futUnassignedGear:gear?'1':'0'},
attrs:{type:'button','aria-pressed':gear?'true':'false',title:t(gear?'unassigned.gearOn':'unassigned.gearOff')},
text:'⚙'})
button.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
gear=!gear
if(!gear){armed=null
resetAsk=false}
else toTop()
try{paint()}catch(err){onError(err)}})
return button}
function toTop(){const host=gutterHost??last?.box??null
if(!host)return false
try{host.scrollTop=0
return true}catch(err){onError(err)
return false}}
function gearBox(parts){const box=el(doc,'div',{class:'fx-strip-more-box',
dataset:{futUnassignedMore:'1'}})
box.appendChild(calmRow(parts.rules))
box.appendChild(ruleSets(parts))
box.appendChild(redeemRow(parts.rules))
box.appendChild(resetRow(parts.rules))
return box}
function calmRow(rules){const price=dupePrice(rules)
const knife=rules?.dupe?.below==='quicksell'
return el(doc,'div',{class:'fx-strip-calm',dataset:{futUnassignedCalm:knife?'knife':'safe'}},
[el(doc,'span',{text:t(knife?'unassigned.rules.calm':'unassigned.rules.calmSafe',{price})+' · '}),
el(doc,'span',{class:'fx-strip-why fx-strip-hint',dataset:{futUnassignedWhy:'1'},
attrs:{title:t('unassigned.rules.calmTip',{price})},text:t('unassigned.rules.calmWhy')})])}
function dupePrice(rules){const value=Number(rules?.dupe?.price)
return Number.isFinite(value)&&value>0?value:DUPE_PRICE_DEFAULT}
function moneyTipText(summary){const parts=[t('unassigned.moneyTip',{priced:summary.priced,cards:summary.cards})]
if(summary.unpriced>0)parts.push(t('unassigned.moneyTipUnpriced',{count:summary.unpriced}))
if(summary.locked>0)parts.push(t('unassigned.moneyTipLocked',{count:summary.locked}))
if(summary.value>0)parts.push(t('unassigned.moneyTipNet',{net:summary.net}))
return parts.join(' ')}
const DEST_LABEL=Object.freeze({transfer:'unassigned.dest.transfer',
club:'unassigned.dest.club',quicksell:'unassigned.dest.quicksell',
storage:'unassigned.dest.storage',keep:'unassigned.dest.keep'})
function warnBox(rules){const price=dupePrice(rules)
const box=el(doc,'div',{class:'fx-strip-warn',dataset:{futUnassignedWarn:'1'}},
[el(doc,'span',{class:'fx-strip-warn-text'},[el(doc,'b',{text:t('unassigned.warn.title')}),
el(doc,'span',{text:' '}),el(doc,'span',{text:t('unassigned.warn.body',{price})})])])
const ok=el(doc,'button',{class:'fx-action fx-strip-warn-ok',attrs:{type:'button'},text:t('unassigned.warn.ok')})
ok.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{writeRules({...rules,warned:true})}catch(err){onError(err)}})
box.appendChild(ok)
return box}
function ruleSets(parts){const rules=parts.rules
const sets=el(doc,'div',{class:'fx-strip-sets'})
const sell=setBox('fx-strip-set-trad',t('unassigned.rules.sellable'),t('unassigned.rules.sellableCap'))
sell.appendChild(ruleRow({key:'expensive',label:t('unassigned.rules.expensive'),
tip:t('unassigned.rules.priceTip'),
fields:[numField('rating',rules.expensive.rating,t('unassigned.rules.ratingFrom'),null,(value)=>{
writeRules({...rules,expensive:{...rules.expensive,rating:value}})}),
orWord(),
numField('price',rules.expensive.price,t('unassigned.rules.priceFrom'),null,(value)=>{
writeRules({...rules,expensive:{...rules.expensive,price:value}})}),
orWord(),
checkField('special',t('unassigned.rules.special'),rules.expensive.special===true,(on)=>{
writeRules({...rules,expensive:{...rules.expensive,special:on}})},t('unassigned.rules.specialTip'))],
dest:destPick('expensive',rules)}))
sell.appendChild(ruleRow({key:'players',label:t('unassigned.rules.players'),dest:destPick('players',rules)}))
sell.appendChild(dupeSellRow(rules))
sell.appendChild(ruleRow({key:'styles',label:t('unassigned.rules.styles'),
tip:t('unassigned.rules.stylesTip'),
hint:pickedHint(parts.catalog.styles,rules.styles),
fold:foldButton('styles',t('unassigned.rules.stylesFold')),
body:folds.styles?kindsPanel('styles',parts.catalog.styles,rules.styles,(next)=>{
writeRules({...rules,styles:next})}):null,
dest:destPick('styles',rules)}))
sell.appendChild(ruleRow({key:'coaches',label:t('unassigned.rules.coaches'),
tip:t('unassigned.rules.coachesTip'),
hint:pickedHint(parts.catalog.nations,rules.nations),
fold:foldButton('nations',t('unassigned.rules.coachesFold')),
body:folds.nations?kindsPanel('nations',parts.catalog.nations,rules.nations,(next)=>{
writeRules({...rules,nations:next})}):null,
dest:destPick('coaches',rules)}))
sell.appendChild(ruleRow({key:'leagues',label:t('unassigned.rules.leagues'),
tip:t('unassigned.rules.leaguesTip'),
hint:pickedHint(parts.catalog.leagues,rules.leagues),
fold:foldButton('leagues',t('unassigned.rules.leaguesFold')),
body:folds.leagues?kindsPanel('leagues',parts.catalog.leagues,rules.leagues,(next)=>{
writeRules({...rules,leagues:next})}):null,
dest:destPick('leagues',rules)}))
sell.appendChild(ruleRow({key:'items',label:t('unassigned.rules.items'),
tip:t('unassigned.rules.itemsTip'),
hint:t('unassigned.rules.itemsHint'),dest:destPick('items',rules)}))
sets.appendChild(sell)
const keep=setBox('fx-strip-set-untrad',t('unassigned.rules.unsellable'),t('unassigned.rules.unsellableCap'))
keep.appendChild(ruleRow({key:'new',label:t('unassigned.rules.new'),
tip:t('unassigned.rules.newHint')+' '+t('unassigned.rules.newWhy'),
fixed:t('unassigned.rules.newDest')}))
const goldOn=rules.quality.gold===true
const dupeFields=[checkField('bronze',t('unassigned.rules.bronze'),rules.quality.bronze===true,(on)=>{
writeRules({...rules,quality:{...rules.quality,bronze:on}})}),
checkField('silver',t('unassigned.rules.silver'),rules.quality.silver===true,(on)=>{
writeRules({...rules,quality:{...rules.quality,silver:on}})}),
checkField('gold',t('unassigned.rules.gold'),goldOn,(on)=>{
writeRules({...rules,quality:{...rules.quality,gold:on}})},t('unassigned.rules.goldTip'))]
if(goldOn)dupeFields.push(numField('gold-below',rules.quality.goldBelow,t('unassigned.rules.goldBelow'),
t('unassigned.rules.goldBelowTip'),(value)=>{
writeRules({...rules,quality:{...rules.quality,goldBelow:value}})}))
keep.appendChild(ruleRow({key:'dupe',label:t('unassigned.rules.dupe'),
tip:t('unassigned.rules.dupeHint'),
fields:dupeFields}))
keep.appendChild(ruleRow({key:'loan',label:t('unassigned.rules.loan'),
tip:t('unassigned.rules.loanHint')+' '+t('unassigned.rules.loanWhy'),
fields:[numField('loan-rating',rules.loan.rating,t('unassigned.rules.ratingFrom'),null,(value)=>{
writeRules({...rules,loan:{...rules.loan,rating:value}})}),
orWord(),
checkField('loan-special',t('unassigned.rules.special'),rules.loan.special===true,(on)=>{
writeRules({...rules,loan:{...rules.loan,special:on}})},t('unassigned.rules.specialTip'))],
dest:destPick('loan-keep',rules,['club','quicksell'],rules.loan.keep,(next)=>{
writeRules({...rules,loan:{...rules.loan,keep:next}})}),
rest:{label:t('unassigned.rules.loanRest'),
pick:destPick('loan-rest',rules,['club','quicksell'],rules.loan.rest,(next)=>{
writeRules({...rules,loan:{...rules.loan,rest:next}})})}}))
sets.appendChild(keep)
return sets}
function dupeSellRow(rules){return ruleRow({key:'dupe-sell',label:t('unassigned.rules.dupeSell'),
tip:t('unassigned.rules.dupeSellTip'),
fields:[numField('dupe-price',rules.dupe.price,t('unassigned.rules.dupeAbove'),null,(value)=>{
writeRules({...rules,dupe:{...rules.dupe,price:value}})}),
destPick('dupe-above',rules,DUPE_ABOVE_DESTS,rules.dupe.above,(next)=>{
writeRules({...rules,dupe:{...rules.dupe,above:next}})})],
rest:[{label:t('unassigned.rules.dupeBelow'),
pick:destPick('dupe-below',rules,DUPE_BELOW_DESTS,rules.dupe.below,(next)=>{
writeRules({...rules,dupe:{...rules.dupe,below:next}})})},
{label:t('unassigned.rules.dupeNone'),
pick:warnKnife(destPick('dupe-none',rules,DUPE_NONE_DESTS,rules.dupe.none,(next)=>{
writeRules({...rules,dupe:{...rules.dupe,none:next}})}),rules.dupe.none==='quicksell')}]})}
function warnKnife(pick,on){if(!on)return pick
pick.dataset.futUnassignedKnifeWarn='1'
pick.className+=' fx-strip-pick-warn fx-strip-hint'
pick.setAttribute('title',t('unassigned.rules.dupeNoneWarn'))
return pick}
function setBox(tone,title,tip){return el(doc,'div',{class:'fx-strip-set '+tone},
[el(doc,'div',{class:'fx-strip-set-head fx-strip-hint',attrs:{title:tip},text:title})])}
function ruleRow(spec){const row=el(doc,'div',{class:'fx-strip-rule',dataset:{futUnassignedRule:spec.key}})
const name=el(doc,'span',{class:spec.tip?'fx-strip-rule-name fx-strip-hint':'fx-strip-rule-name',
text:spec.label})
if(spec.tip)name.setAttribute('title',spec.tip)
const cond=el(doc,'div',{class:'fx-strip-cond'},[name])
if(spec.hint||spec.fold){const line=el(doc,'div',{class:'fx-strip-subline'})
if(spec.hint)line.appendChild(el(doc,'span',{class:'fx-strip-rule-hint',text:spec.hint}))
if(spec.fold)line.appendChild(spec.fold)
cond.appendChild(line)}
row.appendChild(cond)
if(Array.isArray(spec.fields)&&spec.fields.length>0){row.appendChild(el(doc,'div',{class:'fx-strip-fields'},spec.fields))}
if(spec.body)row.appendChild(spec.body)
if(spec.fixed)row.appendChild(el(doc,'div',{class:'fx-strip-fixed',text:spec.fixed}))
if(spec.dest)row.appendChild(spec.dest)
for(const tail of[].concat(spec.rest??[]))row.appendChild(el(doc,'div',{class:'fx-strip-rest'},
[el(doc,'span',{class:'fx-strip-rule-hint',text:tail.label}),tail.pick]))
if(spec.foot)row.appendChild(el(doc,'div',{class:'fx-strip-foot',text:spec.foot}))
return row}
function orWord(){return el(doc,'span',{class:'fx-strip-or',text:t('unassigned.rules.or')})}
function destPick(key,rules,allowed=DESTINATIONS,value=null,onPick=null){const now=value??rules.dest[key]
const select=el(doc,'select',{class:'fx-strip-pick',dataset:{futUnassignedDest:key},
attrs:{'aria-label':t('unassigned.rules.destLabel'),title:t('unassigned.rules.destTip')}})
for(const dest of allowed){const option=el(doc,'option',{attrs:{value:dest},text:t(DEST_LABEL[dest])})
if(now===dest)option.selected=true
select.appendChild(option)}
select.disabled=!writeView
select.addEventListener('change',()=>{const next=String(select.value??'')
if(!allowed.includes(next))return
Promise.resolve().then(()=>{try{if(onPick)onPick(next)
else writeRules({...rules,dest:{...rules.dest,[key]:next}})}catch(err){onError(err)}})})
return select}
function numField(key,value,label,tip,onSet){const input=el(doc,'input',{class:'fx-strip-num',
dataset:{futUnassignedNum:key},
attrs:{type:'text',inputmode:'numeric',autocomplete:'off',maxlength:'9','aria-label':label}})
input.value=String(value)
input.disabled=!writeView
input.addEventListener('input',()=>{const raw=String(input.value??'')
const digits=raw.replace(/\D+/g,'')
if(digits!==raw)input.value=digits})
input.addEventListener('change',()=>{const digits=String(input.value??'').trim()
const next=/^\d{1,9}$/.test(digits)?Number(digits):null
if(next===null)return
Promise.resolve().then(()=>{try{onSet(next)}catch(err){onError(err)}})})
const box=el(doc,'label',{class:'fx-strip-field'},[el(doc,'span',{class:'fx-strip-field-label',text:label}),input])
if(tip)box.setAttribute('title',tip)
return box}
function checkField(key,label,on,onToggle,tip=null){const button=el(doc,'button',{class:on?'fx-strip-check fx-strip-check-on':'fx-strip-check',
dataset:{futUnassignedCheck:key},
attrs:{type:'button','aria-pressed':on?'true':'false'}},
[el(doc,'span',{class:'fx-strip-box',text:on?'✓':''}),el(doc,'span',{text:label})])
if(tip){button.className+=' fx-strip-hint'
button.setAttribute('title',tip)}
button.disabled=!writeView
button.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{onToggle(!on)}catch(err){onError(err)}})
return button}
function foldButton(key,label){const open=folds[key]===true
const button=el(doc,'button',{class:'fx-strip-fold',dataset:{futUnassignedFold:key},
attrs:{type:'button','aria-expanded':open?'true':'false'},
text:open?label+' ▴':label+' ▾'})
button.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
folds[key]=!open
try{paint()}catch(err){onError(err)}})
return button}
function pickedHint(catalog,picked){const list=Array.isArray(picked)?picked:[]
if(list.length===0)return t('unassigned.rules.none')
const names=[]
for(const one of Array.isArray(catalog)?catalog:[]){if(list.includes(one?.id)&&names.length<3)names.push(one.name)}
if(names.length===0)return t('unassigned.rules.picked',{count:list.length})
const tail=list.length>names.length?' …':''
return names.join(' · ')+tail}
const KINDS_SHOWN=12
function kindsPanel(key,catalog,picked,onSet){const list=Array.isArray(catalog)?catalog:[]
const box=el(doc,'div',{class:'fx-strip-kinds',dataset:{futUnassignedKinds:key}})
if(list.length===0){box.appendChild(el(doc,'div',{class:'fx-strip-foot',text:t('unassigned.rules.kindsEmpty')}))
return box}
const all=folds[key==='styles'?'stylesAll':'nationsAll']===true
const shown=all?list:list.slice(0,KINDS_SHOWN)
const row=el(doc,'div',{class:'fx-strip-kinds-row'})
const now=Array.isArray(picked)?picked:[]
for(const one of shown){const on=now.includes(one.id)
row.appendChild(checkField(key+'-'+String(one.id),one.name,on,(next)=>{
onSet(next?[...now,one.id]:now.filter((id)=>id!==one.id))}))}
box.appendChild(row)
if(list.length>KINDS_SHOWN)box.appendChild(foldButton(key==='styles'?'stylesAll':'nationsAll',
all?t('unassigned.rules.less'):t('unassigned.rules.more',{count:list.length})))
return box}
function resetRow(rules){const row=el(doc,'div',{class:'fx-strip-reset',dataset:{futUnassignedReset:'1'}})
if(resetAsk!==true){const button=el(doc,'button',{class:'fx-action',dataset:{futUnassignedResetGo:'1'},
attrs:{type:'button'},text:t('unassigned.rules.reset')})
button.disabled=!writeView
button.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
resetAsk=true
try{paint()}catch(err){onError(err)}})
row.appendChild(button)
return row}
const ask=el(doc,'div',{class:'fx-strip-warn fx-strip-reset-ask',dataset:{futUnassignedResetAsk:'1'}},
[el(doc,'span',{class:'fx-strip-warn-text'},[el(doc,'b',{text:t('unassigned.rules.resetAskTitle')}),
el(doc,'span',{text:' '}),el(doc,'span',{text:t('unassigned.rules.resetAsk')})])])
const yes=el(doc,'button',{class:'fx-action fx-strip-warn-ok',dataset:{futUnassignedResetYes:'1'},
attrs:{type:'button'},text:t('unassigned.rules.resetYes')})
yes.disabled=!writeView
yes.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
resetAsk=false
try{const fresh={...defaultUnassignedRules(),warned:rules.warned===true}
writeRules(adoptDefaults(fresh,catalogNow()).rules)}catch(err){onError(err)}})
const no=el(doc,'button',{class:'fx-action fx-strip-reset-no',dataset:{futUnassignedResetNo:'1'},
attrs:{type:'button'},text:t('unassigned.rules.resetNo')})
no.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
resetAsk=false
try{paint()}catch(err){onError(err)}})
ask.appendChild(yes)
ask.appendChild(no)
row.appendChild(ask)
return row}
function redeemRow(rules){const name=el(doc,'span',{class:'fx-strip-rule-name fx-strip-hint',
attrs:{title:t('unassigned.rules.redeemHint')},text:t('unassigned.rules.redeem')})
return el(doc,'div',{class:'fx-strip-redeem',dataset:{futUnassignedRedeem:'1'}},
[el(doc,'div',{class:'fx-strip-cond'},[name]),
checkField('redeem',t('unassigned.rules.redeemOn'),rules.redeem===true,(on)=>{
writeRules({...rules,redeem:on})})])}
function viewField(parts){if(!writeCardView||parts.grid!==true)return null
return cardViewButton(doc,{view:parts.view,t,onError,
onPick:(next)=>{try{writeCardView(next)}catch(err){onError(err)}
try{paint()}catch(err){onError(err)}}})}
function pinButton(parts){if(!writeView)return null
const on=parts.pinned===true
const button=el(doc,'button',{class:'fx-action fx-action-square fx-strip-pin',
dataset:{futUnassignedPin:on?'1':'0'},
attrs:{type:'button','aria-pressed':on?'true':'false',title:t(on?'unassigned.pinOn':'unassigned.pinOff')},
text:'📌'})
button.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{writeView({pinned:!on})}catch(err){onError(err)}
try{paint()}catch(err){onError(err)}})
return button}
function progressButton(state){const button=el(doc,'button',{class:'fx-action fx-strip-btn fx-strip-btn-running',
dataset:{futUnassignedStop:'1'},attrs:{type:'button'},
text:t(state.stopping?'unassigned.stopping':'unassigned.progress',{done:state.done,total:state.total})})
button.addEventListener('click',()=>{try{run.stop()}catch(err){onError(err)}})
return button}
function storageShort(groups,summary){const room=summary?.storage
if(!room)return null
const dupes=Array.isArray(groups?.storable)?groups.storable.length:0
const over=dupes-Math.max(0,room.free)
return over>0?t('unassigned.storageShort',{left:over,room:Math.max(0,room.free)}):null}
function brainStop(plan){if(plan?.ok===true||plan?.reason==='nothing-to-do')return null
const stop=plan?.stop??null
if(plan?.reason==='no-room-transfer')return t('unassigned.stop.transfer',{need:stop?.need??0,free:stop?.free??0})
if(plan?.reason==='no-room-storage')return t('unassigned.stop.storage',{need:stop?.need??0,free:stop?.free??0})
if(plan?.reason==='unknown-kind')return t('unassigned.stop.unknown',{id:stop?.id??0,kind:stop?.type??'?'})
return null}
const KEEP_WHY_LABEL=Object.freeze({
'dupe-unpriced':'unassigned.why.unpriced',
'dupe-unpriced-no-room':'unassigned.why.noRoom',
'dupe-no-bar':'unassigned.why.noBar',
'dupe-kept':'unassigned.why.dupeKept',
'swap-no-id':'unassigned.why.swapNoId',
'dupe-storage-full':'unassigned.why.storageFull',
'storage-no-room':'unassigned.why.storageRoom',
'dupe-cheap-kept':'unassigned.why.cheapKept',
'locked':'unassigned.why.locked',
'pick':'unassigned.why.pick',
'redeem-off':'unassigned.why.redeemOff'})
const LEFT_SHOWN=3
const SORT_STOP_LABEL=Object.freeze({'guard-unavailable':'unassigned.stop.guard',
busy:'unassigned.stop.busy','no-match':'unassigned.stop.changed',
'blind-items':'unassigned.stop.blind','no-room':'unassigned.stop.noRoom',
gone:'unassigned.stop.gone',stale:'unassigned.stop.stale',
failed:'unassigned.stop.failed','no-storage':'unassigned.stop.noStorage'})
function reasonWord(word){const said=typeof word==='string'&&word!==''?word:'unknown-state'
const key=SORT_STOP_LABEL[said]??(Object.hasOwn(STOP_REASON_KEYS,said)?STOP_REASON_KEYS[said]:null)
return typeof key==='string'?t(key):said}
function leftWord(brain){const keepers=planCounts(brain).keepers
if(keepers.length===0)return null
const wordOf=(why)=>{const key=KEEP_WHY_LABEL[why]
return key?t(key):String(why??'')}
const say=(one)=>{const name=(()=>{try{return last?.nameOf?.(one.id)??null}catch(err){onError(err)
return null}})()
const who=typeof name==='string'&&name!==''?name:`#${one.id}`
const word=wordOf(one.why)
return word===''?who:`${who} — ${word}`}
const all=keepers.map(say)
if(keepers.length===1)return{text:t('unassigned.stayed',{count:1,list:all[0]}),tip:null}
const groups=[]
for(const one of keepers){const found=groups.find((group)=>group.why===one.why)
if(found)found.count+=1
else groups.push({why:one.why,count:1})}
const shown=groups.slice(0,LEFT_SHOWN)
.map((group)=>(groups.length===1?wordOf(group.why):`${wordOf(group.why)} (${group.count})`))
if(groups.length>shown.length)shown.push(t('unassigned.stayedMore',{count:groups.length-shown.length}))
return{text:t('unassigned.stayed',{count:keepers.length,list:shown.join(' · ')}),
tip:all.join(' · ')}}
function noteFor(state,tail,brain){
let left=null
const main=(()=>{if(told!==null)return told
const outcome=state.outcome
if(outcome){if(outcome.reason==='stopped')return t('unassigned.stopped',{moved:outcome.moved,total:outcome.total})
if(outcome.reason==='knife')return t('unassigned.knife',{count:outcome.knife??0})
if(outcome.ok!==true)return t('unassigned.failed',{moved:outcome.moved,reason:reasonWord(outcome.reason)})
left=leftWord(brain)
return t('unassigned.done',{moved:outcome.moved})}
const stop=brainStop(brain)
if(stop!==null)return stop
if(brain?.keep>0)return t('unassigned.stays',{count:brain.keep})
return null})()
const said=left===null?tail:null
const text=!said?main:(main===null?said:`${main} · ${said}`)
if(text===null&&left===null)return null
return{text,left:left?.text??null,tip:left?.tip??null}}
function replan(scenario){const parts=model()
return scenario==='rules'?parts.brain:planUnassigned(parts.groups,scenario,last?.capacity??{})}
function start(plan){told=null
if(plan?.ok!==true){paint()
return false}
if(plan.scenario==='rules')lastCounts={at:Date.now(),...planCounts(plan)}
run.run(plan).catch((err)=>onError(err))
paint()
return true}
return{apply,
refresh(){if(!last)return false
const заказан=schedule(true)
return заказан?true:lastResult.ok===true},
say(text){const next=typeof text==='string'&&text!==''?text:null
if(told===next)return false
told=next
if(!last)return false
try{paint()}catch(err){onError(err)}
return true},
relabel(){if(!last)return false
painted=null
return settle().ok===true},
detach(){if(last?.box)remove(last.box)
return drop().reason==='gone'},
stop:()=>run.stop(),
state:()=>({result:{...lastResult},work:{settles,renders,adoptions},armed,told,gear,run:run.state(),
build:STRIP_BUILD,
tools:{feature:UNASSIGNED_TOOLS_FEATURE,allowed:toolsAllowed()},
cards:last?.cards?.length??0,
threshold:sanitizeExpensiveFrom(readFrom()),
rules:readRules(),
brain:last?planCounts(model().brain):null,
ran:lastCounts?{...lastCounts}:null,
catalog:Object.fromEntries(Object.entries(catalogNow()).map(([name,list])=>[name,list.length])),
scenarios:scenarioPlans().map((plan)=>({scenario:plan.scenario,cards:plan.cards,coins:plan.coins,left:plan.left,stays:plan.stays})),
styles:Boolean(doc?.getElementById?.(STRIP_LINK_ID)),
grid:gridState(),
mounted:Boolean(last?.box?.querySelector?.(STRIP_SELECTOR))}),
dispose(){run.stop()
try{clearGrid()}catch(err){onError(err)}
last=null
armed=null
resetAsk=false
told=null
gear=false
painted=null}}}
const FLOW_HOSTS=Object.freeze([UNASSIGNED_ROOT_SELECTOR,'[data-fut-store-grid]'])
const FLOW_STYLESHEET=new URL('../ui/pack-flow.css',import.meta.url).href
const FLOW_LINK_ID='fut-companion-pack-flow'
const FLOW_SELECTOR='[data-fut-pack-flow]'
export function packFlowText(t,status,why){if(!status||typeof status!=='object')return null
const opened=Number.isSafeInteger(status.opened)?status.opened:0
const total=Number.isSafeInteger(status.total)?status.total:0
const running=status.running===true
const action=running?'stop':(status.reason==='stopped'||status.parked===true?'resume':null)
const end=running||action==='resume'?null
:(status.reason==='done'||status.reason==='gone'?'ok':'warn')
let main=''
if(!running)main=t('packFlow.done',{opened,total,why:typeof why==='function'?why(status.reason??null):''})
else if(status.hold){const left=Number.isSafeInteger(status.poured)&&status.poured>0?status.poured:null
main=left===null?t('packFlow.waitAny'):t('packFlow.wait',{left})}
else main=t('packFlow.busy',{opened,total})
let drop=''
if(status.drop){const name=typeof status.drop.name==='string'&&status.drop.name!==''?status.drop.name:t('packFlow.dropAnon')
const rating=status.drop.rating
const mark=Number.isSafeInteger(rating)?String(rating):t('packFlow.dropSpecial')
drop=t('packFlow.drop',{name,mark})}
return{main,drop,running,action,end}}
export function createPackFlowLine(deps={}){const{doc,t}=deps
const status=typeof deps.status==='function'?deps.status:()=>null
const why=typeof deps.why==='function'?deps.why:()=>''
const onToggle=typeof deps.onToggle==='function'?deps.onToggle:null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let mounted=0
let lastText=null
const root=()=>{for(const selector of FLOW_HOSTS){let found=null
try{found=doc?.querySelector?.(selector)??null}catch(err){onError(err)
found=null}
if(found)return found}
return null}
function remove(){let gone=0
for(const node of Array.from(doc?.querySelectorAll?.(FLOW_SELECTOR)??[])){node.remove?.()
gone+=1}
if(gone>0)lastText=null
return gone}
function place(host,node){const strip=host.querySelector?.(STRIP_SELECTOR)??null
const anchor=strip&&strip.parentNode===host?strip.nextSibling:host.firstChild
if(node.parentNode===host&&(anchor===node||(anchor===null&&host.lastChild===node)))return false
host.insertBefore(node,anchor)
return true}
function mount(host){const existing=host.querySelector?.(FLOW_SELECTOR)??null
if(existing&&existing.parentNode===host){if(!place(host,existing))return existing
lastText=null
return existing}
const node=existing??el(doc,'section',{class:'fx-bar fx-pack-flow',dataset:{futPackFlow:'1'}},[
logoLink(doc),
el(doc,'span',{class:'fx-pack-flow-main',dataset:{futPackFlowMain:'1'}}),
el(doc,'span',{class:'fx-pack-flow-drop',dataset:{futPackFlowDrop:'1'}}),
onToggle?el(doc,'button',{class:'fx-action fx-pack-flow-stop',attrs:{type:'button'},dataset:{futBulkStop:'1'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{onToggle()}catch(err){onError(err)}}}},[el(doc,'span',{class:'fx-pack-flow-stop-text',dataset:{futPackFlowStopText:'1'}})]):null,
])
place(host,node)
mounted+=1
lastText=null
return node}
function refresh(){const host=root()
if(!host){remove()
return false}
const parts=packFlowText(t,status(),why)
if(!parts){remove()
return false}
const node=mount(host)
const key=`${parts.main} ${parts.drop} ${parts.running?'1':'0'} ${parts.action??'-'} ${parts.end??'-'}`
if(lastText===key)return true
lastText=key
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,FLOW_STYLESHEET,FLOW_LINK_ID)
const main=node.querySelector?.('[data-fut-pack-flow-main]')
if(main&&main.textContent!==parts.main)main.textContent=parts.main
const drop=node.querySelector?.('[data-fut-pack-flow-drop]')
if(drop){if(drop.textContent!==parts.drop)drop.textContent=parts.drop
if(drop.dataset&&drop.dataset.futPackFlowHas!==(parts.drop===''?'0':'1'))drop.dataset.futPackFlowHas=parts.drop===''?'0':'1'}
const stop=node.querySelector?.('[data-fut-bulk-stop]')
if(stop){const label=stop.querySelector?.('[data-fut-pack-flow-stop-text]')
const text=t(parts.action==='resume'?'packFlow.resume':'packFlow.stop')
if(label&&label.textContent!==text)label.textContent=text
const on=parts.action===null?'0':'1'
if(stop.dataset&&stop.dataset.futPackFlowOn!==on)stop.dataset.futPackFlowOn=on}
if(node.dataset&&node.dataset.futPackFlowRunning!==(parts.running?'1':'0'))node.dataset.futPackFlowRunning=parts.running?'1':'0'
const done=parts.end??'0'
if(node.dataset&&node.dataset.futPackFlowDone!==done)node.dataset.futPackFlowDone=done
return true}
return{refresh,
relabel(){lastText=null
return refresh()},
state:()=>({mounts:mounted,screen:Boolean(root()),
shown:Boolean(doc?.querySelector?.(FLOW_SELECTOR)),
styles:Boolean(doc?.getElementById?.(FLOW_LINK_ID)),
text:packFlowText(t,status(),why)}),
dispose(){remove()}}}
