import{el,ensureTheme,ensureStylesheet,logoLink,logoMark} from '../ui/dom.js'
import{ensureControls} from '../ui/controls.js'
import{SEARCH_BUTTON_BOX,NATIVE_BUTTON_CLASS} from '../adapter/market-screen.js'
import{AFTER_BUY_KEY,afterBuyOf,parseOptions} from '../automation/options-input.js'
import{buyCeilingOf} from '../automation/sniper.js'
import{stopReasonKey} from '../automation/stop-reasons.js'
import{FILTER_CHANGED,COLUMN_SELECTOR} from './market-bot-column.js'
import{modalBox,modalButtons} from '../ui/window.js'
import{SNIPE_FEATURE,searchScreenRoot,targetFromCriteria,
TARGET_NO_CAP,controlModel,clockWords,digitsOf,AFTER_BUY_CHOICES,
stopLadder,consentLabelKey,consentTextDiffers,CONSENT_TEXT_MISMATCH,
DISCLAIMER_TEXT_KEY,narrowWords,cardIdOf} from './snipe-shared.js'
import{createMarketBotColumn} from './market-bot-column.js'
import{createRatingSearch} from './market-rating-search.js'
const MARKET_BOT_STYLESHEET=new URL('../ui/market-bot.css',import.meta.url).href
const MARKET_BOT_LINK_ID='fut-companion-market-bot'
export const MARKET_BOX_MARK='futMarketBox'
export const MARKET_BOX_SELECTOR='[data-fut-market-box]'
export const MARKET_BAR_MARK='futMarketBot'
export const MARKET_BAR_SELECTOR='[data-fut-market-bot]'
export const MARKET_BTN_MARK='futMarketBotBtn'
export const MARKET_BTN_SELECTOR='[data-fut-market-bot-btn]'
export const MARKET_RUN_MARK='futMarketBotRun'
export const MARKET_FIELD_MARK='futMarketBotField'
const MARKET_GATE_MARK='futMarketBotGate'
export const MARKET_GATE_SELECTOR='[data-fut-market-bot-gate]'
const MARKET_GATE_OK_MARK='futMarketBotGateOk'
const MARKET_GATE_NO_MARK='futMarketBotGateNo'
export const MARKET_BOT_BUILD='SNGATES-1'
export const BAR_FIELDS=Object.freeze([
{id:'buy',field:'maxPurchases',kind:'limit',labelKey:'marketBot.buy'},
{id:'searches',field:'maxSearches',kind:'limit',labelKey:'marketBot.searches'},
{id:'where',field:AFTER_BUY_KEY,kind:'choice',labelKey:'marketBot.where'}].map(Object.freeze))
export function afterBuyLabelKey(value){const name=String(value??'')
return `snipe.settings.afterBuy${name.charAt(0).toUpperCase()}${name.slice(1)}`}
export function barPrint(model,notice='',yielding=false){if(!model||typeof model!=='object')return 'нет'
const promise=model.promise===null||model.promise===undefined
?'—'
:`${model.promise.key}:${model.promise.value}:${model.promise.buys??'—'}`
const state=model.running
?`run:${clockWords(model.elapsedMs)}:${model.searches}:${model.seen??'—'}`
:'idle'
return [state,yielding?'yield':'free',model.canStart?'can':'no',
`left=${model.searchesLeft??'—'}/${model.searchesCap??'—'}`,
promise,notice].join('|')}
export function runCaps(limits){let ladder=[]
try{ladder=stopLadder(limits)}catch{ladder=[]}
const found=new Map()
for(const one of Array.isArray(ladder)?ladder:[]){if(!found.has(one?.key))found.set(one?.key,one?.value)}
const said=(key)=>{const value=found.get(key)
return Number.isFinite(value)?value:null}
return{buy:said('maxPurchases'),spend:said('maxSpend'),searches:said('maxSearches')}}
export function budgetShare(left,cap){if(!Number.isSafeInteger(left)||!Number.isSafeInteger(cap)||cap<=0)return null
const used=Math.min(Math.max(cap-left,0),cap)
return used/cap}
export function createMarketBotBar(deps={}){const{doc}=deps
const t=typeof deps.t==='function'?deps.t:(key)=>key
const num=typeof deps.formatNumber==='function'?deps.formatNumber:(value)=>String(value)
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const win=deps.win??null
const hunt=deps.hunt??null
const readCriteria=typeof deps.criteria==='function'?deps.criteria:()=>null
const readBudget=typeof deps.budget==='function'?deps.budget:()=>null
const readUnassigned=typeof deps.unassigned==='function'?deps.unassigned:null
const playerOf=typeof deps.playerOf==='function'?deps.playerOf:null
const column=createMarketBotColumn({doc,win,t,formatNumber:num,clock:deps.clock,
isActive:deps.isActive,hunt,criteria:deps.criteria,filters:deps.filters,applySet:deps.applySet,
saveSet:deps.saveSet,loot:deps.loot,
priceOf:deps.priceOf,
runMemory:deps.runMemory,setRunMemory:deps.setRunMemory,
aim:()=>aimForLog(),
stopWords:()=>(handStop===null?'':handStop.words),
onError})
const rating=createRatingSearch({doc,t,formatNumber:num,isActive:deps.isActive,
book:deps.book,playerOf:deps.playerOf,pick:deps.pickRatingCard,
searchNow:()=>statusNow()?.options?.ratingSearchNow!==false,
setSearchNow:(value)=>{if(hunt===null||typeof hunt.setOption!=='function'){return{ok:false,notice:null}}
try{return hunt.setOption('ratingSearchNow',value===true)}catch(err){onError(err)
return{ok:false,notice:null}}},onError})
const allowed=()=>{if(typeof deps.isActive!=='function')return true
try{return deps.isActive(SNIPE_FEATURE)===true}catch(err){onError(err)
return false}}
let notice=''
let printed=null
let liveArmed=false
let runFilter=null
let runWords=''
let handStop=null
let gateHost=null
let gateNotice=''
let gateSkip=false
let passes=0,mounts=0,buttons=0,starts=0,stops=0,edits=0,paints=0,ticks=0,homeless=0
let arms=0,disarms=0,gates=0
const TICK_MS=500
let timer=null
const stopTick=()=>{if(timer===null)return
try{win?.clearInterval?.(timer)}catch{
}
timer=null}
const startTick=()=>{if(timer!==null||typeof win?.setInterval!=='function')return
timer=win.setInterval(()=>{ticks+=1
try{watchFilter()}catch(err){onError(err)}
try{paint()}catch(err){onError(err)}},TICK_MS)}
let bar=null,parts=null,button=null
const statusNow=()=>{if(hunt===null||typeof hunt.status!=='function')return null
try{return hunt.status()}catch(err){onError(err)
return null}}
const budgetNow=()=>{try{return readBudget()}catch(err){onError(err)
return null}}
const unassignedNow=()=>{if(readUnassigned===null)return null
try{return readUnassigned()}catch(err){onError(err)
return null}}
function screenCriteria(){let said=null
try{said=readCriteria()}catch(err){onError(err)
return null}
if(said===null||said===undefined)return null
return said?.criteria??null}
function runOptions(){try{return parseOptions(statusNow()?.options??{}).options}catch(err){onError(err)
return{}}}
function priceCapNow(){const criteria=screenCriteria()
if(criteria===null)return null
let said=null
try{said=buyCeilingOf(criteria,runOptions().maxPrice)}catch(err){onError(err)
return null}
return Number.isFinite(said?.cap)?said.cap:null}
function targetNow(){const criteria=screenCriteria()
if(criteria===null)return null
return targetFromCriteria(criteria)}
function modelNow(){const target=targetNow()
return controlModel(statusNow(),target,budgetNow(),unassignedNow())}
function engineSet(kind,key,value){if(hunt===null){notice=t('snipe.noEngine')
return false}
const hand=kind==='limit'?hunt.setLimit:hunt.setOption
if(typeof hand!=='function'){notice=t('snipe.noEngine')
return false}
let result=null
try{result=hand.call(hunt,key,value)}catch(err){onError(err)
notice=t('snipe.noEngine')
return false}
if(result?.ok!==true){notice=result?.notice?.key?t(result.notice.key,result.notice.params??{}):t('snipe.startRefused')
return false}
notice=''
edits+=1
return true}
const consentNow=()=>{const raw=statusNow()?.consent
const said=raw&&typeof raw==='object'?raw:{ok:false,reason:'no-port',fingerprint:null}
if(!consentTextDiffers(said,t(DISCLAIMER_TEXT_KEY)))return said
return{ok:false,reason:CONSENT_TEXT_MISMATCH,fingerprint:said.fingerprint}}
function capsWords(){const caps=runCaps(statusNow()?.limits)
const said=(value)=>(value===null?t('marketBot.liveCapNone'):num(value))
return t('marketBot.liveCaps',{buy:said(caps.buy),spend:said(caps.spend),searches:said(caps.searches)})}
function aimWords(){const criteria=screenCriteria()
if(criteria===null)return null
let narrow=''
let card=null
try{narrow=narrowWords(criteria,t)
card=cardIdOf(criteria)}catch(err){onError(err)
narrow=''
card=null}
const parts=[]
if(card!==null){const said=playerCard(card)
if(said===null)parts.push(t('marketBot.liveAimCard'))
else{parts.push(said.name)
if(said.rating!==null)parts.push(t('marketBot.liveAimRating',{rating:num(said.rating)}))}}
if(narrow!=='')parts.push(narrow)
const cap=priceCapNow()
return{what:parts.length===0?t('marketBot.liveAimAny'):parts.join(' · '),
price:cap===null?t('marketBot.liveCapNone'):num(cap)}}
function playerCard(definitionId){if(playerOf===null)return null
const id=Number(definitionId)
if(!Number.isSafeInteger(id)||id<=0)return null
let said=null
try{said=playerOf(id)}catch(err){onError(err)
return null}
const name=typeof said?.name==='string'?said.name.trim():''
if(name==='')return null
const rating=Number(said?.rating)
return{name,rating:Number.isSafeInteger(rating)&&rating>0?rating:null}}
function aimLine(){const said=aimWords()
return said===null?'':t('marketBot.liveAim',{what:said.what,price:said.price})}
function aimForLog(){const said=aimWords()
if(said===null)return null
const caps=runCaps(statusNow()?.limits)
const capSaid=(value)=>(value===null?t('marketBot.liveCapNone'):num(value))
return{what:said.what,price:said.price,buy:capSaid(caps.buy),spend:capSaid(caps.spend)}}
const confirmEachRun=()=>statusNow()?.options?.confirmEachRun!==false
function skipBox(){const node=el(doc,'input',{attrs:{type:'checkbox'},dataset:{futMarketBotGateSkip:'1'},
on:{change:(event)=>{gateSkip=event?.target?.checked===true}}})
node.checked=gateSkip
return node}
function buildGate(){ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,MARKET_BOT_STYLESHEET,MARKET_BOT_LINK_ID)
const said=consentNow()
const needsSign=said.ok!==true
const buttons=modalButtons(doc,[{text:t('marketBot.liveCancel'),mark:MARKET_GATE_NO_MARK,
on:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
closeGate()
paint()}},
{text:t('marketBot.liveOk'),mark:MARKET_GATE_OK_MARK,kind:'danger',
on:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
confirmStart()}}])
return modalBox(doc,{mark:MARKET_GATE_MARK,box:'fx-hk-capture-box fx-mbot-gate-box',
title:t('marketBot.liveTitle'),closeLabel:t('common.close'),onBack:()=>{closeGate()
paint()}},
[el(doc,'p',{class:'fx-mbot-gate-warn',dataset:{futMarketBotGateWarn:'1'},text:t('marketBot.liveWarn')}),
el(doc,'p',{class:'fx-mbot-gate-aim',dataset:{futMarketBotGateAim:'1'},text:aimLine()}),
el(doc,'p',{class:'fx-mbot-gate-caps',dataset:{futMarketBotGateCaps:'1'},text:capsWords()}),
el(doc,'p',{class:'fx-mbot-gate-note',text:t('marketBot.liveOnce')}),
el(doc,'label',{class:'fx-mbot-gate-skip'},
[skipBox(),el(doc,'span',{text:t('marketBot.liveSkipAsk')})]),
needsSign?el(doc,'p',{class:'fx-mbot-gate-text',dataset:{futMarketBotGateText:'1'},text:t(DISCLAIMER_TEXT_KEY)}):null,
needsSign?el(doc,'div',{class:'fx-mbot-gate-state',dataset:{futMarketBotGateState:String(said.reason??'not-given')},
text:t('snipe.settings.consent',{state:t(consentLabelKey(said))})}):null,
gateNotice===''?null:el(doc,'div',{class:'fx-mbot-notice',dataset:{futMarketBotGateNotice:'1'},text:gateNotice}),
said.reason===CONSENT_TEXT_MISMATCH
?el(doc,'div',{class:'fx-mbot-notice',dataset:{futMarketBotGateMismatch:'1'},text:t('snipe.disclaimerMismatchWhy')})
:buttons].filter(Boolean))}
function repaintGate(){if(gateHost===null)return false
const rebuilt=buildGate()
const home=gateHost.parentNode??null
if(home!==null&&home!==undefined){home.insertBefore(rebuilt,gateHost)
gateHost.remove?.()}
else gateHost.remove?.()
gateHost=rebuilt
return true}
function openGate(){if(!doc)return false
if(gateHost!==null)return true
gateNotice=''
gateSkip=false
gateHost=buildGate()
doc.body?.appendChild?.(gateHost)
gates+=1
return true}
function closeGate(){if(gateHost===null)return false
try{gateHost.remove?.()}catch(err){onError(err)}
gateHost=null
gateNotice=''
gateSkip=false
return true}
function refuse(words){gateNotice=words
if(!repaintGate())notice=words
return false}
function armLive(){
if(consentNow().reason===CONSENT_TEXT_MISMATCH){refuse(t('snipe.disclaimerMismatchWhy'))
return false}
if(statusNow()?.running===true){refuse(t('marketBot.liveBusy'))
return false}
if(hunt===null||typeof hunt.setDryRun!=='function'){refuse(t('snipe.noEngine'))
return false}
if(consentNow().ok!==true){let signed=null
if(typeof hunt.acceptDisclaimer==='function'){try{signed=hunt.acceptDisclaimer()}catch(err){onError(err)
signed=null}}
if(signed?.ok!==true||consentNow().ok!==true){refuse(t('snipe.disclaimerNoPortWhy'))
return false}}
let result=null
try{result=hunt.setDryRun(false)}catch(err){onError(err)
result=null}
if(result?.ok!==true||statusNow()?.dryRun!==false){refuse(result?.notice?.key
?t(result.notice.key,result.notice.params??{})
:t('marketBot.liveRefused'))
return false}
liveArmed=true
arms+=1
notice=''
closeGate()
paint()
return true}
function confirmStart(){
if(gateSkip&&confirmEachRun()&&hunt!==null&&typeof hunt.setOption==='function'){try{hunt.setOption('confirmEachRun',false)}catch(err){onError(err)}}
if(!armLive())return false
const done=start()
paint()
return done}
function disarmLive(){liveArmed=false
if(hunt===null||typeof hunt.setDryRun!=='function')return false
if(statusNow()?.dryRun!==false)return false
let result=null
try{result=hunt.setDryRun(true)}catch(err){onError(err)
return false}
if(result?.ok!==true)return false
disarms+=1
return true}
function forgetLive(){if(statusNow()?.running===true)return false
return disarmLive()}
function capsMissing(){const caps=runCaps(statusNow()?.limits)
return caps.buy===null&&caps.spend===null}
function doorToCap(){const node=parts?.inputs?.get('buy')??null
if(node===null)return false
try{node.focus?.()}catch(err){onError(err)}
return true}
function askStart(){if(statusNow()?.running===true){notice=t('marketBot.liveBusy')
return false}
const target=targetNow()
if(target===null){notice=t('snipe.needFilter')
return false}
if(target.ok!==true){notice=target.reason===TARGET_NO_CAP?t('snipe.needCap'):t('snipe.needTarget')
return false}
if(capsMissing()){notice=t('marketBot.needCap')
doorToCap()
return false}
notice=''
if(!confirmEachRun())return confirmStart()
return openGate()}
function start(){if(hunt===null||typeof hunt.start!=='function'){notice=t('snipe.noEngine')
return false}
if(!liveArmed){notice=t('marketBot.needConfirm')
return false}
const target=targetNow()
if(target===null){notice=t('snipe.needFilter')
return false}
if(target.ok!==true){notice=target.reason===TARGET_NO_CAP?t('snipe.needCap'):t('snipe.needTarget')
return false}
if(capsMissing()){notice=t('marketBot.needCap')
doorToCap()
return false}
if(statusNow()?.dryRun!==false){notice=t('marketBot.liveRefused')
return false}
let result=null
try{result=hunt.start({filters:[{...target.criteria}]})}catch(err){onError(err)
notice=t('snipe.startRefused')
return false}
if(result?.ok!==true){notice=result?.notice?.key?t(result.notice.key,result.notice.params??{}):t('snipe.startRefused')
return false}
notice=''
starts+=1
runFilter={...target.criteria}
runWords=aimWords()?.what??''
handStop=null
touched=false
return true}
let handOn=false
let touched=false
const HAND_EVENTS=Object.freeze(['pointerdown','click','keyup','input','change'])
function listenHand(){if(handOn||typeof doc?.addEventListener!=='function')return false
for(const name of HAND_EVENTS)doc.addEventListener(name,onHandEdit,true)
handOn=true
return true}
function forgetHand(){if(!handOn||typeof doc?.removeEventListener!=='function')return false
for(const name of HAND_EVENTS)doc.removeEventListener(name,onHandEdit,true)
handOn=false
return true}
function sameCriteria(a,b){if(a===null||b===null)return a===b
const keys=new Set([...Object.keys(a),...Object.keys(b)])
for(const key of keys){const one=a[key]
const two=b[key]
if(Array.isArray(one)||Array.isArray(two)){if(!Array.isArray(one)||!Array.isArray(two)||one.length!==two.length)return false
for(let i=0;i<one.length;i+=1)if(one[i]!==two[i])return false
continue}
if(one!==two)return false}
return true}
function onHandEdit(event){if(event?.isTrusted!==true)return false
touched=true
return true}
function watchFilter(){if(!touched)return false
if(runFilter===null)return false
if(statusNow()?.running!==true)return false
const live=screenCriteria()
if(live===null)return false
if(sameCriteria(live,runFilter)){
touched=false
return false}
touched=false
handStop={reason:FILTER_CHANGED,words:runWords}
const done=stop()
notice=t(stopReasonKey(FILTER_CHANGED),{words:handStop.words})
paint()
return done}
function stop(){if(hunt===null||typeof hunt.stop!=='function'){notice=t('snipe.noEngine')
return false}
let result=null
try{result=hunt.stop()}catch(err){onError(err)
notice=t('snipe.startRefused')
return false}
if(result?.ok!==true){notice=result?.notice?.key?t(result.notice.key,result.notice.params??{}):t('snipe.startRefused')
return false}
notice=''
stops+=1
return true}
function press(){const running=statusNow()?.running===true
const done=running?stop():askStart()
paint()
return done}
function buildBar(){const fields=[]
const inputs=new Map()
for(const one of BAR_FIELDS){const label=el(doc,'label',{class:'fx-mbot-field',
dataset:{[MARKET_FIELD_MARK]:one.id}},[el(doc,'span',{text:t(one.labelKey)})])
let control
if(one.kind==='choice'){control=el(doc,'select',{on:{change:(event)=>{
engineSet('option',one.field,afterBuyOf(event?.target?.value))
paint()
column.refresh(searchScreenRoot(doc))}}},
AFTER_BUY_CHOICES.map((value)=>el(doc,'option',{attrs:{value},
text:t(afterBuyLabelKey(value))})))}
else{control=el(doc,'input',{attrs:{type:'text',inputmode:'numeric'},
on:{input:(event)=>{const said=String(event?.target?.value??'')
const clean=said===''?'':String(digitsOf(said))
if(clean!==said&&event?.target)event.target.value=clean
engineSet('limit',one.field,clean)}}})}
label.appendChild(control)
inputs.set(one.id,control)
fields.push(label)}
const gaugeFill=el(doc,'span')
const budgetLine=el(doc,'span')
const budgetBox=el(doc,'div',{class:'fx-mbot-budget',attrs:{title:t('snipe.barHint')}},
[budgetLine,el(doc,'div',{class:'fx-mbot-gauge'},[gaugeFill])])
const head=el(doc,'div',{class:'fx-mbot-head'},
[logoLink(doc),el(doc,'span',{class:'fx-mbot-title',text:t('marketBot.title')}),budgetBox])
const state=el(doc,'div',{class:'fx-mbot-state'})
const noticeNode=el(doc,'div',{class:'fx-mbot-notice'})
const foot=el(doc,'div',{class:'fx-mbot-foot'},[state,noticeNode])
const box=el(doc,'section',{class:'fx-mbot',dataset:{[MARKET_BAR_MARK]:'1',futMarketBotBuild:MARKET_BOT_BUILD},
attrs:{title:t('marketBot.hint')}},
[head,el(doc,'div',{class:'fx-mbot-fields'},fields),foot])
return{box,parts:{inputs,budgetLine,gaugeFill,state,notice:noticeNode,
title:head.querySelector('.fx-mbot-title')}}}
function mountButton(root){let box=null
try{box=root?.querySelector?.(SEARCH_BUTTON_BOX)??null}catch(err){onError(err)
return null}
if(!box)return null
const existing=box.querySelector?.(MARKET_BTN_SELECTOR)??null
if(existing!==null)return existing
const node=el(doc,'button',{class:`${NATIVE_BUTTON_CLASS} fx-mbot-btn`,
attrs:{type:'button'},dataset:{[MARKET_BTN_MARK]:'1'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{press()}catch(err){onError(err)}}}},
[logoMark(doc),el(doc,'span',{class:'fx-mbot-btn-text'})])
let anchor=null
for(const kid of Array.from(box.children??[])){let ours=false
try{ours=kid?.matches?.(MARKET_BTN_SELECTOR)===true}catch{ours=false}
if(!ours){anchor=kid
break}}
box.insertBefore(node,anchor)
buttons+=1
return node}
function barHost(root){let column=null
try{column=root?.querySelector?.(COLUMN_SELECTOR)??null}catch(err){onError(err)
column=null}
if(column===null)homeless+=1
return column}
function mountBar(root){const host=barHost(root)
if(host===null)return null
let existing=null
for(const kid of Array.from(host.children??[])){let ours=false
try{ours=kid?.matches?.(MARKET_BAR_SELECTOR)===true}catch{ours=false}
if(ours){existing=kid
break}}
try{for(const stray of Array.from(root?.querySelectorAll?.(MARKET_BAR_SELECTOR)??[])){
if(stray!==existing)stray.remove()}}catch(err){onError(err)}
if(existing!==null&&existing===bar)return bar
if(existing!==null){try{existing.remove()}catch{
}}
const built=buildBar()
bar=built.box
parts=built.parts
printed=null
host.appendChild(bar)
mounts+=1
return bar}
function budgetWords(model){if(model.searchesLeft===null||model.searchesCap===null)return t('snipe.barLineUnknown')
return t('snipe.barLine',{used:num(model.searchesCap-model.searchesLeft),cap:num(model.searchesCap)})}
function paint(){if(bar===null||parts===null)return false
const model=modelNow()
if(liveArmed&&model.dry===true)liveArmed=false
const yielding=statusNow()?.session?.yielding===true
if(model.running)startTick()
else stopTick()
const mark=barPrint(model,notice,yielding)
if(mark===printed)return false
printed=mark
paints+=1
const running=t('snipe.running',{time:clockWords(model.elapsedMs),searches:num(model.searches),lots:num(model.seen??0)})
parts.state.textContent=model.running
?(yielding?`${running} · ${t('marketBot.yield')}`:running)
:''
parts.state.hidden=!model.running
parts.notice.textContent=notice
parts.notice.hidden=notice===''
parts.budgetLine.textContent=budgetWords(model)
const share=budgetShare(model.searchesLeft,model.searchesCap)
parts.gaugeFill.style.width=share===null?'0%':`${Math.round(share*100)}%`
const status=statusNow()
for(const one of BAR_FIELDS){const node=parts.inputs.get(one.id)
if(!node)continue
if(doc?.activeElement===node)continue
if(one.kind==='choice'){const said=afterBuyOf(status?.options?.[one.field])
if(node.value!==said)node.value=said
continue}
const said=String(status?.limits?.[one.field]??'')
if(node.value!==said)node.value=said
node.setAttribute('placeholder',t('snipe.runNoLimit'))}
if(button!==null){const text=model.running?t('marketBot.stop'):t('marketBot.start')
const label=button.querySelector?.('.fx-mbot-btn-text')??null
if(label&&label.textContent!==text)label.textContent=text
const hint=model.running?t('marketBot.stopHint'):t('marketBot.startHint')
if(button.getAttribute('title')!==hint)button.setAttribute('title',hint)
const run=model.running?'1':'0'
if(button.dataset[MARKET_RUN_MARK]!==run)button.dataset[MARKET_RUN_MARK]=run}
return true}
function clearAll(){let gone=0
for(const node of Array.from(doc?.querySelectorAll?.(MARKET_BAR_SELECTOR)??[])){try{node.remove()
gone+=1}catch{
}}
for(const node of Array.from(doc?.querySelectorAll?.(MARKET_BTN_SELECTOR)??[])){try{node.remove()
gone+=1}catch{
}}
for(const node of Array.from(doc?.querySelectorAll?.(MARKET_BOX_SELECTOR)??[])){try{delete node.dataset[MARKET_BOX_MARK]
gone+=1}catch{
}}
closeGate()
stopTick()
gone+=column.clearAll()
gone+=rating.clearAll()
bar=null
parts=null
button=null
printed=null
forgetHand()
forgetLive()
return gone}
let inPass=false
function refresh(){if(inPass)return false
inPass=true
try{return pass()}finally{inPass=false}}
function pass(){if(!doc)return false
passes+=1
if(!allowed()){clearAll()
return false}
column.hear()
const root=searchScreenRoot(doc)
if(root===null){
if(bar!==null||button!==null)clearAll()
else if(liveArmed)forgetLive()
return false}
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,MARKET_BOT_STYLESHEET,MARKET_BOT_LINK_ID)
listenHand()
if(root.dataset&&root.dataset[MARKET_BOX_MARK]!=='1')root.dataset[MARKET_BOX_MARK]='1'
button=mountButton(root)
column.refresh(root)
mountBar(root)
paint()
rating.refresh(root)
return true}
function relabel(){if(bar===null||parts===null)return refresh()
parts.title.textContent=t('marketBot.title')
bar.setAttribute('title',t('marketBot.hint'))
for(const one of BAR_FIELDS){const node=parts.inputs.get(one.id)
const label=node?.parentElement??null
if(label?.firstChild)label.firstChild.textContent=t(one.labelKey)
if(one.kind!=='choice')continue
for(const option of Array.from(node?.children??[])){const value=String(option.getAttribute?.('value')??option.value??'')
option.textContent=t(afterBuyLabelKey(value))}}
printed=null
paint()
column.relabel()
rating.relabel()
return true}
return{refresh,relabel,
forget(event=null){return column.forget(event)},
state(){const root=searchScreenRoot(doc)
const model=bar===null?null:modelNow()
return{build:MARKET_BOT_BUILD,
screen:root!==null,
marked:root?.dataset?.[MARKET_BOX_MARK]==='1',
bar:doc?.querySelectorAll?.(MARKET_BAR_SELECTOR)?.length??0,
button:doc?.querySelectorAll?.(MARKET_BTN_SELECTOR)?.length??0,
fields:Array.from(bar?.querySelectorAll?.('[data-fut-market-bot-field]')??[])
.map((one)=>one.dataset.futMarketBotField).join(' · '),
running:model?.running??null,
dry:model?.dry??null,
armed:liveArmed,
capsMissing:capsMissing(),
priceCap:priceCapNow(),
priceCapMissing:priceCapNow()===null,
gate:doc?.querySelectorAll?.(MARKET_GATE_SELECTOR)?.length??0,
gateNotice,
consent:consentNow().ok===true,
consentWhy:consentNow().reason??null,
caps:capsWords(),
aim:aimLine(),
confirm:confirmEachRun(),
gateSkip,
runFilter:runWords,
handStop:handStop===null?null:handStop.reason,
handStopWords:handStop===null?'':handStop.words,
handTouched:touched,
canStart:model?.canStart??null,
budget:model===null?'':budgetWords(model),
notice,
print:printed,
column:column.state(),
rating:rating.state(),
work:{passes,mounts,buttons,starts,stops,edits,paints,ticks,arms,disarms,gates,homeless}}},
press,start,stop,
standStop(words){handStop=typeof words==='string'&&words!==''
?{reason:FILTER_CHANGED,words}
:null
return{ok:true,words:handStop===null?'':handStop.words}},
askStart,confirmStart,armLive,disarmLive,openGate,closeGate,
col:column,
rat:rating,
dispose(){clearAll()
column.dispose()
rating.dispose()}}}
