import{buyNowPriceOf,bidReceiptOf,bidOutcome,pileOrNull} from '../automation/sniper.js'
import{createStopConditions} from '../automation/stop-conditions.js'
import{stopReasonKey} from '../automation/stop-reasons.js'
import{AFTER_BUY_PILE,afterBuyOf} from '../automation/options-input.js'
import{moveReceiptMatches} from '../automation/item-receipts.js'
import{isDoorRefusal,isLotRefusal,ALLOWED} from '../adapter/action-door.js'
import{classifyStatus} from '../adapter/error-codes.js'
import{askBudgetRound} from './day-budget.js'
import{targetFromCriteria,TARGET_NO_CAP,SNIPE_FEATURE} from './snipe-shared.js'
import{lootNameOf} from './hunt-loot.js'
export{SNIPE_FEATURE}
export const THRESHOLD_DEFAULT=5
export const THRESHOLD_MIN=1
export const THRESHOLD_MAX=10
export const CHAIN_CALLS=3
export function thresholdOf(value){
if(typeof value==='string'&&value.trim()==='')return THRESHOLD_DEFAULT
const raw=typeof value==='string'?Number(value.trim()):value
if(!Number.isFinite(raw))return THRESHOLD_DEFAULT
const whole=Math.round(raw)
if(whole<THRESHOLD_MIN)return THRESHOLD_MIN
if(whole>THRESHOLD_MAX)return THRESHOLD_MAX
return whole}
export function lastLotOf(lots){return Array.isArray(lots)&&lots.length>0?lots[lots.length-1]:null}
export const CHAIN_EMPTY='empty'
export const CHAIN_TOO_MANY='too-many'
export const CHAIN_BUY='buy'
export function chainVerdict(count,threshold){if(!Number.isFinite(count)||count<=0)return CHAIN_EMPTY
return count>threshold?CHAIN_TOO_MANY:CHAIN_BUY}
export const NOTICE=Object.freeze({busy:'snipeKey.busy',
noCriteria:'snipeKey.noCriteria',noCap:'snipeKey.noCap',noMarket:'snipeKey.noMarket',
empty:'snipeKey.empty',tooMany:'snipeKey.tooMany',
searchFailed:'snipeKey.searchFailed',noPrice:'snipeKey.noPrice',overCap:'snipeKey.overCap',noPage:'snipeKey.noPage',noButton:'snipeKey.noButton',
bought:'snipeKey.bought',boughtUnassigned:'snipeKey.boughtUnassigned',boughtNotMoved:'snipeKey.boughtNotMoved',
gone:'snipeKey.gone',refused:'snipeKey.refused',unsure:'snipeKey.unsure',unavailable:'snipeKey.unavailable'})
const lotGone=(review)=>isLotRefusal(review)
export function createSnipeKey(deps={}){const market=typeof deps.market==='function'?deps.market:null
const clock=deps.clock
if(!clock||typeof clock.now!=='function')throw new Error('snipe-key: нужны часы (правило 6 NIGHT_BRIEF)')
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const journal=deps.journal??null
const note=(event,payload)=>{try{journal?.record?.(event,payload)}catch(err){onError(err)}}
const ask=(port)=>{if(typeof port!=='function')return undefined
try{return port()}catch(err){onError(err)
return undefined}}
const thresholdNow=()=>thresholdOf(ask(deps.threshold))
const afterBuyNow=()=>afterBuyOf(ask(deps.afterBuy))
const maxPriceNow=()=>{const said=Number(ask(deps.maxPrice))
return Number.isSafeInteger(said)&&said>0?said:null}
let busy=false
let disposed=false
let presses=0
let bought=0
const said=(ok,reason,key,params={})=>({ok,reason,notice:{key,params}})
const moneyStop=(price)=>{if(typeof deps.coinBalance!=='function')return null
let coins=null
try{coins=deps.coinBalance()}catch(err){onError(err)
coins=null}
const stop=createStopConditions({minCoins:0},{clock})
const verdict=stop.shouldStopBeforePurchase({coins,spent:0,earned:0,loss:0},price)
return verdict.stop===true?verdict.reason:null}
const ratePort=()=>{const said=typeof deps.buyRate==='function'?deps.buyRate():deps.buyRate
return said&&typeof said.take==='function'?said:null}
const hourRoom=async()=>{const rate=ratePort()
if(rate===null)return null
if(typeof rate.warm==='function'){let asked=null
try{asked=await rate.warm()}catch(err){onError(err)
return 'bad-state'}
if(typeof asked==='string'&&asked!=='')return asked}
if(typeof rate.refusal!=='function')return null
try{const word=rate.refusal()
return typeof word==='string'&&word!==''?word:null}catch(err){onError(err)
return 'bad-state'}}
const hourStop=async()=>{const rate=ratePort()
if(rate===null)return null
let refusal=null
try{refusal=await rate.take()}catch(err){onError(err)
return 'bad-state'}
if(typeof refusal==='string'&&refusal!=='')return refusal
if(typeof rate.settle!=='function')return null
let said=null
try{said=await rate.settle()}catch(err){onError(err)
said='bad-state'}
if(typeof said!=='string'||said==='')return null
await hourRelease()
return said}
const hourRelease=async()=>{const rate=ratePort()
if(rate===null||typeof rate.release!=='function')return
try{await rate.release()}catch(err){onError(err)}}
const searchStop=async()=>{const budget=deps.marketBudget
if(!budget||typeof budget.take!=='function')return null
const doors={warm:(count)=>(typeof budget.warm==='function'?budget.warm(count):null),
take:()=>budget.take(),
settle:()=>(typeof budget.settle==='function'?budget.settle({market:true}):null)}
let said=null
try{said=await askBudgetRound(doors,1)}catch(err){onError(err)
return 'bad-state'}
return said===null?null:said.reason}
const dayPort=()=>{const said=typeof deps.dayBudget==='function'?deps.dayBudget():deps.dayBudget
return said&&typeof said.take==='function'?said:null}
const callDoors=(day)=>({warm:(count)=>(typeof day.warm==='function'?day.warm(count,{market:false}):null),
take:(count)=>day.take(count,{market:false}),
settle:()=>(typeof day.settle==='function'?day.settle({market:false}):null)})
const spendCall=async(count=1)=>{const day=dayPort()
if(day===null)return null
let said=null
try{said=await askBudgetRound(callDoors(day),count)}catch(err){onError(err)
return 'bad-state'}
return said===null?null:said.reason}
const warmCalls=async(count)=>{const day=dayPort()
if(day===null||typeof day.warm!=='function')return null
let said=null
try{said=await day.warm(count,{market:false})}catch(err){onError(err)
return 'bad-state'}
return typeof said==='string'&&said!==''?said:null}
const dayRoom=()=>{const day=dayPort()
if(day===null||typeof day.left!=='function')return null
try{const left=day.left()
return Number.isSafeInteger(left)?left:0}catch(err){onError(err)
return 0}}
const failureOf=(err)=>{const status=typeof err?.status==='number'?err.status:null
return classifyStatus(status)}
async function press(opts={}){if(busy)return said(false,'busy',NOTICE.busy)
if(disposed)return said(false,'unavailable',NOTICE.unavailable)
const pressSearch=typeof opts?.pressSearch==='function'?opts.pressSearch
:(typeof deps.pressSearch==='function'?deps.pressSearch:null)
const onScreen=typeof opts?.onScreen==='function'?opts.onScreen
:(typeof deps.onScreen==='function'?deps.onScreen:null)
const stillHere=()=>{if(disposed)return false
if(onScreen===null)return true
try{return onScreen()===true}catch(err){onError(err)
return false}}
const live=market===null?null:(()=>{try{return market()}catch(err){onError(err)
return null}})()
if(!live||typeof live.bid!=='function'){return said(false,'unavailable',NOTICE.unavailable)}
busy=true
presses+=1
let slotTaken=false
let watch=null
try{
if(typeof live.review==='function'){let door=null
try{door=live.review({action:'market'})}catch(err){onError(err)
door=null}
if(door===null||door.verdict!==ALLOWED){note('stopped',{reason:'market-off'})
return said(false,'market-off',NOTICE.noMarket)}}
const room=dayRoom()
if(room!==null&&room<CHAIN_CALLS){note('stopped',{reason:'day-budget'})
return said(false,'day-budget',stopReasonKey('day-budget'))}
const warmed=await warmCalls(CHAIN_CALLS-1)
if(warmed!==null){note('stopped',{reason:warmed})
return said(false,warmed,stopReasonKey(warmed))}
const budgetRefusal=await searchStop()
if(budgetRefusal!==null){note('stopped',{reason:budgetRefusal})
return said(false,budgetRefusal,stopReasonKey(budgetRefusal))}
const hour=await hourRoom()
if(hour!==null){note('stopped',{reason:hour})
return said(false,hour,stopReasonKey(hour))}
const perPage=typeof live.pageSize==='function'?(()=>{try{return live.pageSize()}catch(err){onError(err)
return null}})():null
if(!Number.isSafeInteger(perPage)||perPage<=0){note('stopped',{reason:'no-page'})
return said(false,'no-page',NOTICE.noPage)}
let answer=null
let searchStatus=null
const caught=new Promise((resolve)=>{watch=live.catchSearch?.({onItems:(list,asked)=>resolve({items:list,criteria:asked??null}),
onMiss:(status)=>{searchStatus=status
resolve(null)},onError})??null
if(watch===null)resolve(undefined)})
const pressed=pressSearch===null?false:(()=>{try{return pressSearch()===true}catch(err){onError(err)
return false}})()
if(!pressed){note('stopped',{reason:'no-search-button'})
return said(false,'no-search-button',NOTICE.noButton)}
note('search',{})
answer=await caught
if(answer===undefined){note('stopped',{reason:'unavailable'})
return said(false,'unavailable',NOTICE.unavailable)}
if(answer===null){
const kind=searchStatus===null?'no-answer':classifyStatus(searchStatus)
note('failure',{stage:'search',category:kind})
return kind==='captcha'||kind==='fatal'
?said(false,kind,stopReasonKey(kind))
:said(false,'search-failed',NOTICE.searchFailed)}
if(!stillHere()){note('stopped',{reason:'left-screen'})
return said(false,'left-screen',NOTICE.noButton)}
const target=targetFromCriteria(answer.criteria)
if(!target.ok){note('stopped',{reason:target.reason===TARGET_NO_CAP?'no-cap':'no-criteria'})
return said(false,target.reason===TARGET_NO_CAP?'no-cap':'no-criteria',
target.reason===TARGET_NO_CAP?NOTICE.noCap:NOTICE.noCriteria)}
const items=Array.isArray(answer.items)?answer.items:[]
const lots=items.slice(0,perPage)
const threshold=thresholdNow()
note('found',{total:items.length,affordable:lots.length})
const verdict=chainVerdict(lots.length,threshold)
if(verdict===CHAIN_EMPTY)return said(true,'empty',NOTICE.empty)
if(verdict===CHAIN_TOO_MANY)return said(true,'too-many',NOTICE.tooMany,{count:lots.length,limit:threshold})
const lot=lastLotOf(lots)
const price=buyNowPriceOf(lot)
if(!Number.isSafeInteger(price)||price<=0)return said(false,'no-price',NOTICE.noPrice)
const ceiling=Math.min(target.cap,maxPriceNow()??Infinity)
if(price>ceiling)return said(true,'over-cap',NOTICE.overCap,{coins:price,limit:ceiling})
const money=moneyStop(price)
if(money!==null){note('stopped',{reason:money})
return said(false,money,stopReasonKey(money))}
const [hourSlot,bidBudget]=await Promise.all([hourStop(),spendCall(1)])
if(hourSlot===null)slotTaken=true
if(hourSlot!==null){note('stopped',{reason:hourSlot})
return said(false,hourSlot,stopReasonKey(hourSlot))}
if(bidBudget!==null){note('stopped',{reason:bidBudget})
return said(false,bidBudget,stopReasonKey(bidBudget))}
if(!stillHere()){note('stopped',{reason:'left-screen'})
return said(false,'left-screen',NOTICE.noButton)}
const name=lootNameOf(lot)
let receipt=null
try{const paid=await live.bid(lot,price,'buy')
receipt=bidReceiptOf(paid)}
catch(err){if(isDoorRefusal(err)){const review=err.door
note('failure',{stage:'buy',category:review?.reason??'door'})
return lotGone(review)
?said(true,'gone',NOTICE.gone)
:said(false,review?.reason??'door',NOTICE.refused,{reason:String(review?.reason??'')})}
const kind=failureOf(err)
onError(err)
note('failure',{stage:'buy',category:kind})
if(kind==='gone')return said(true,'gone',NOTICE.gone)
return kind==='captcha'||kind==='fatal'||kind==='out-of-coins'
?said(false,kind,stopReasonKey(kind))
:said(false,'refused',NOTICE.refused,{reason:kind})}
const outcome=bidOutcome({receipt})
if(outcome!=='bought'){note('failure',{stage:'buy',category:'unsure'})
return said(false,'unsure',NOTICE.unsure,{name})}
bought+=1
slotTaken=false
note('bought',{item:lot,price})
const pile=pileOrNull(AFTER_BUY_PILE[afterBuyNow()])
if(pile===null||typeof live.move!=='function'){
return said(true,'bought',NOTICE.boughtUnassigned,{name,coins:price})}
const moveBudget=await spendCall(1)
if(moveBudget!==null){note('stopped',{reason:moveBudget})
return said(true,'bought',NOTICE.boughtUnassigned,{name,coins:price})}
if(!stillHere()){note('stopped',{reason:'left-screen'})
return said(true,'bought',NOTICE.boughtUnassigned,{name,coins:price})}
try{const shipped=await live.move([lot],pile)
const landed=moveReceiptMatches(shipped,[lot])
note('moved',{item:lot,pile})
return said(true,'bought',landed===true?NOTICE.bought:NOTICE.boughtNotMoved,{name,coins:price})}
catch(err){if(!isDoorRefusal(err))onError(err)
note('failure',{stage:'move',category:isDoorRefusal(err)?(err.door?.reason??'door'):failureOf(err)})
return said(true,'bought',NOTICE.boughtNotMoved,{name,coins:price})}}
finally{
try{watch?.dispose?.()}catch(err){onError(err)}
if(slotTaken)await hourRelease()
busy=false}}
return{press,
dispose(){disposed=true},
running:()=>busy,
state:()=>({presses,bought,threshold:thresholdNow(),afterBuy:afterBuyNow()})}}
