import{el,ensureStylesheet,ensureTheme,logoMark} from '../ui/dom.js'
import{createPlatformSign,PLATFORM_SIGN_HOST} from '../adapter/head-bar.js'
import{BUDGET_LIMIT} from './min-bin.js'
import{untilText,SBC_HOUR_CAP,SBC_DAY_CAP,SEARCH_HOUR_CAP} from './head-counters.js'
import{DAY_REQUEST_CAP} from './day-budget.js'
import{placeUpdateLine} from './update-notice.js'
import{openAccountDoor,watchAccountDoor} from './account-door.js'
export const HEAD_BAR_FEATURE='headBar'
export const HEAD_BAR_BUILD='ACCOPEN-1'
export const SEARCH_HOUR_OURS=Math.min(BUDGET_LIMIT*60,SEARCH_HOUR_CAP)
export const NAV_BAR='.ut-navigation-bar-view'
export const NAV_CURRENCY='.view-navbar-currency'
export const NAV_CLUBINFO='.view-navbar-clubinfo'
const HEAD_STYLESHEET=new URL('../ui/head-bar.css',import.meta.url).href
const HEAD_LINK_ID='fut-companion-head-bar'
const BAR_MARK='futHead'
const LIMITS_MARK='futHeadLimits'
const CLUSTER_MARK='futHeadCluster'
const EYE_MARK='futHeadEye'
const CHIP_MARK='futHeadChip'
export const SIGN_IN_MARK='futHeadSignIn'
export const GUEST_MARK='futHeadGuest'
const DIV_MARK='futHeadDiv'
const PLAT_MARK='futHeadPlat'
export const PANEL_DOOR_MARK='futHeadPanel'
export const PANEL_DOOR_SELECTOR='[data-fut-head-panel="1"]'
const COLUMN_MARK='futHeadColumn'
const EYE_GLYPH='👁'
export const BAN_TICK_MS=1_000
export function defaultHeadView(){return{division:true,club:true}}
export function sanitizeHeadView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const out=defaultHeadView()
if(typeof raw.division==='boolean')out.division=raw.division
if(typeof raw.club==='boolean')out.club=raw.club
return out}
function share(used,cap){if(!Number.isFinite(used)||!Number.isFinite(cap)||cap<=0)return 0
return Math.max(0,Math.min(100,Math.round((used/cap)*100)))}
export function searchScale(hour,day=null){const used=hour?.used
if(!Number.isSafeInteger(used)||used<0)return null
const hourShare=share(used,SEARCH_HOUR_OURS)
const hourHot=used>=Math.floor(SEARCH_HOUR_OURS*0.9)
const dayUsed=day?.used
const dayCap=day?.cap
const hasDay=Number.isSafeInteger(dayUsed)&&dayUsed>=0&&Number.isSafeInteger(dayCap)&&dayCap>0
const dayShare=hasDay?share(dayUsed,dayCap):0
return{used,cap:SEARCH_HOUR_OURS,share:hourShare,hot:hourHot||(hasDay&&dayUsed>=dayCap),
hourUsed:used,hourCap:SEARCH_HOUR_OURS,hourShare,hourHot,
hasDay,
dayUsed:hasDay?dayUsed:null,dayCap:hasDay?dayCap:null,dayShare,
dayHot:hasDay&&dayUsed>=Math.floor(dayCap*0.9)}}
export function sbcScale(rate,now=null){const hour=rate?.hour
const day=rate?.day
if(!Number.isSafeInteger(hour?.used)||!Number.isSafeInteger(day?.used))return null
const hourShare=share(hour.used,hour.cap)
const dayShare=share(day.used,day.cap)
const until=Number.isFinite(hour.until)?hour.until:null
return{hourUsed:hour.used,hourCap:hour.cap,dayUsed:day.used,dayCap:day.cap,
hourShare,dayShare,
share:Math.max(hourShare,dayShare),
hot:hour.used>=hour.cap||day.used>=day.cap,
hourHot:hour.used>=hour.cap,
dayHot:day.used>=day.cap,
until,
untilText:until===null?null:(Number.isFinite(now)?untilText(until,now):hour.untilText??null)}}
export function banFit(sbc){const text=sbc?.untilText
const ban=typeof text==='string'&&text!==''?text:null
return{ban,running:ban!==null}}
export function divisionScale(answer){const number=answer?.divisionNumber
if(!Number.isSafeInteger(number)||number<=0)return null
const count=(value)=>(Number.isSafeInteger(value)&&value>=0?value:null)
const won=count(answer?.wins)
const drew=count(answer?.draws)
const lost=count(answer?.losses)
return{number,record:won===null||drew===null||lost===null?null:`${won}-${drew}-${lost}`}}
export function divisionSilence(view,division){if(view?.division!==true)return'eye'
return division===null?'no-number':'ok'}
export function chipScale(license){const unlocked=license?.unlocked===true
const signIn=!unlocked&&license?.authenticated!==true
const exp=unlocked&&Number.isFinite(license?.exp)?license.exp:null
if(exp===null)return{unlocked,until:null,signIn}
const date=new Date(exp)
const pad=(value)=>String(value).padStart(2,'0')
return{unlocked,until:`${pad(date.getDate())}.${pad(date.getMonth()+1)}.${date.getFullYear()}`,signIn}}
export function createHeadBar(deps={}){const doc=deps.doc
if(!doc||typeof doc.createElement!=='function'){throw new Error('head-bar: нужен документ')}
const win=deps.win??doc.defaultView??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const searchHour=typeof deps.searchHour==='function'?deps.searchHour:()=>null
const searchDay=typeof deps.searchDay==='function'?deps.searchDay:()=>null
const sbcRate=typeof deps.sbcRate==='function'?deps.sbcRate:()=>null
const rivals=deps.rivals??null
const platformSign=typeof deps.platform==='function'?deps.platform:createPlatformSign(win)
const license=typeof deps.license==='function'?deps.license:()=>null
const onOpenPanel=typeof deps.onOpenPanel==='function'?deps.onOpenPanel:null
const readView=typeof deps.view==='function'?deps.view:()=>defaultHeadView()
const writeView=typeof deps.setView==='function'?deps.setView:()=>({ok:false,reason:'no-store'})
const now=typeof deps.now==='function'?deps.now:null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const counts={passes:0,bars:0,painted:0,asked:0,record:0,cold:0,ticks:0,toggles:0,windows:0,panels:0,accounts:0}
try{watchAccountDoor(win)}catch(err){onError(err)}
let lastReason=null
let ticking=false
let asked=false
let recordAsked=false
const view=()=>{try{return sanitizeHeadView(readView())}catch(err){onError(err)
return defaultHeadView()}}
const bars=()=>{try{return[...doc.querySelectorAll(NAV_BAR)]}catch{return[]}}
const write=(node,text)=>{if(node&&node.textContent!==text)node.textContent=text}
const mark=(node,name,value)=>{if(node&&node.dataset[name]!==value)node.dataset[name]=value}
const attr=(node,name,value)=>{if(node&&node.getAttribute(name)!==value)node.setAttribute(name,value)}
const fraction=(node,count,total,hot,share=null)=>{if(node===null)return
write(node.querySelector('.fx-hd-n'),count)
write(node.querySelector('.fx-hd-d'),total)
mark(node,'futHeadHot',hot===true?'1':'0')
mark(node,'futHeadScale',share===null?'0':'1')
bar(node.querySelector('.fx-hd-bar b'),share===null?0:share)}
const bar=(node,percent)=>{const value=`${percent}%`
if(node&&node.style.width!==value)node.style.width=value}
function eye(kind,on){return el(doc,'button',{class:'fx-hd-eye',text:EYE_GLYPH,
attrs:{type:'button',title:t(on?`headBar.hide.${kind}`:`headBar.show.${kind}`),
'aria-label':t(on?`headBar.hide.${kind}`:`headBar.show.${kind}`),'aria-pressed':on?'false':'true'},
dataset:{[EYE_MARK]:kind,futHeadEyeOn:on?'1':'0'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
toggle(kind)}}})}
function limitChip(key,values,ban=false){return el(doc,'div',{class:'fx-hd-chip fx-hd-chip-limit',
dataset:{futHeadLimit:key}},[
el(doc,'span',{class:'fx-hd-k',dataset:{futHeadCapOf:key}}),
...values.map((name)=>el(doc,'span',{class:'fx-hd-v',dataset:{futHeadValOf:`${key}-${name}`}},[
el(doc,'b',{class:'fx-hd-n'}),
el(doc,'span',{class:'fx-hd-d'}),
el(doc,'i',{class:'fx-hd-bar'},[el(doc,'b',{})])])),
ban?el(doc,'span',{class:'fx-hd-ban',dataset:{futHeadBanOf:key}},[
el(doc,'span',{class:'fx-hd-ban-k'}),
el(doc,'b',{class:'fx-hd-ban-t'})]):null])}
function clubEyeIn(club,on){const found=club.querySelector(`[data-fut-head-eye="club"]`)
if(found!==null)return found
const node=eye('club',on)
club.appendChild(node)
return node}
function limitsIn(root,club){const found=root.querySelector(`[data-fut-head-limits="1"]`)
if(found!==null)return found
const node=el(doc,'div',{class:'fx-hd-limits',dataset:{[LIMITS_MARK]:'1'}},
[limitChip('search',['hour','day']),limitChip('sbc',['hour','day'],true)])
root.insertBefore(node,club)
return node}
function clusterIn(root,club){const found=root.querySelector(`[data-fut-head-cluster="1"]`)
if(found!==null)return found
const node=el(doc,'div',{class:'fx-hd-cluster',dataset:{[CLUSTER_MARK]:'1'}},[
el(doc,'div',{class:'fx-hd-chip fx-hd-chip-div',dataset:{[DIV_MARK]:'0'}},[
el(doc,'span',{class:'fx-hd-plat',dataset:{[PLAT_MARK]:'0'}}),
el(doc,'span',{class:'fx-hd-k',dataset:{futHeadDivCap:'1'}}),
el(doc,'span',{class:'fx-hd-v',dataset:{futHeadDivNum:'1'}}),
el(doc,'span',{class:'fx-hd-v fx-hd-div-rec',dataset:{futHeadRec:'0'}}),
eye('division',true)]),
el(doc,'button',{class:'fx-hd-chip fx-hd-chip-plan',attrs:{type:'button'},
dataset:{[CHIP_MARK]:'1'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
if(event?.target?.dataset?.[SIGN_IN_MARK]==='1')openAccount()
else openPanel()}}},[
logoMark(doc,'fx-hd-logo'),
el(doc,'span',{class:'fx-hd-chip-plan-text'},[
el(doc,'b',{class:'fx-hd-v fx-hd-chip-plan-name'}),
el(doc,'span',{class:'fx-hd-k fx-hd-chip-until'})])])])
if(club.nextSibling===null)root.appendChild(node)
else root.insertBefore(node,club.nextSibling)
return node}
function drop(){for(const root of bars()){try{for(const node of root.querySelectorAll(
`[data-fut-head-limits="1"],[data-fut-head-cluster="1"],[data-fut-head-eye="club"]`))node.remove()
for(const key of['futHead','futHeadClub','futHeadDivision','futHeadBan'])delete root.dataset[key]
const currency=root.querySelector(NAV_CURRENCY)
if(currency!==null)delete currency.dataset[COLUMN_MARK]}catch(err){onError(err)}}}
function toggle(kind){try{const current=view()
const next=kind==='division'?{division:current.division!==true}:{club:current.club!==true}
const res=writeView(next)
if(res?.ok!==true)onError(new Error(`head-bar: вид не записан (${res?.reason??'нет ответа'})`))
counts.toggles+=1
if(kind==='division'&&next.division===true)askDivision()
refresh()
return res}catch(err){onError(err)
return{ok:false,reason:'failed'}}}
function askDivision(){if(rivals===null||typeof rivals.askDivision!=='function')return
if(view().division!==true)return
if(asked)return
if(rivals.available?.()!==true)return
asked=true
counts.asked+=1
try{const done=rivals.askDivision()
if(done&&typeof done.then==='function')done.then((res)=>{
if(res&&res.reason==='settings-cold'){asked=false
counts.cold+=1
return}
refresh()},onError)}catch(err){onError(err)}}
function askRecord(){if(rivals===null||typeof rivals.askRecord!=='function')return
if(view().division!==true)return
if(recordAsked)return
const known=rivals.peek?.()??null
if(known?.ok!==true)return
if(rivals.hasRecord?.()===true)return
if(rivals.recordAvailable?.()!==true)return
recordAsked=true
counts.record+=1
try{const done=rivals.askRecord()
if(done&&typeof done.then==='function')done.then(()=>{refresh()},onError)}catch(err){onError(err)}}
function tick(){if(ticking)return
const later=typeof win?.setTimeout==='function'?win.setTimeout.bind(win):null
if(later===null)return
ticking=true
later(()=>{ticking=false
counts.ticks+=1
try{refresh()}catch(err){onError(err)}},BAN_TICK_MS)}
function model(){const stamp=now===null?null:now()
return{view:view(),
search:searchScale(searchHour(),searchDay()),
sbc:sbcScale(sbcRate(),stamp),
division:divisionScale(rivals?.peek?.()??null),
platform:readPlatform(),
chip:chipScale(license())}}
function readPlatform(){try{const found=platformSign()
if(found===null||found===undefined)return null
const kind=typeof found.kind==='string'?found.kind:null
const sign=typeof found.sign==='string'&&found.sign!==''?found.sign:null
return kind===null||sign===null?null:{kind,sign}}catch(err){onError(err)
return null}}
function paintBar(root,data){const club=root.querySelector(NAV_CLUBINFO)
if(club===null)return false
mark(root,BAR_MARK,'1')
mark(root,'futHeadClub',data.view.club?'1':'0')
mark(root,'futHeadDivision',data.view.division?'1':'0')
const currency=root.querySelector(NAV_CURRENCY)
if(currency!==null)mark(currency,COLUMN_MARK,'1')
const limits=limitsIn(root,club)
const chipOf=(key)=>limits.querySelector(`[data-fut-head-limit="${key}"]`)
const valOf=(node,name)=>node.querySelector(`[data-fut-head-val-of="${name}"]`)
const fit=banFit(data.sbc)
const search=chipOf('search')
write(search.querySelector(`[data-fut-head-cap-of="search"]`),t('headBar.searches'))
if(data.search===null){fraction(valOf(search,'search-hour'),'–','',false)
fraction(valOf(search,'search-day'),'','',false)
mark(search,'futHeadHot','0')}
else{fraction(valOf(search,'search-hour'),String(data.search.hourUsed),`/${data.search.hourCap}`,data.search.hourHot,data.search.hourShare)
fraction(valOf(search,'search-day'),data.search.hasDay?String(data.search.dayUsed):'',
data.search.hasDay?`/${data.search.dayCap}`:'',data.search.dayHot,
data.search.hasDay?data.search.dayShare:null)
mark(search,'futHeadHot',data.search.hot?'1':'0')}
attr(search,'title',t('headBar.searchesHint',{hour:SEARCH_HOUR_OURS,day:data.search?.dayCap??DAY_REQUEST_CAP}))
const sbc=chipOf('sbc')
write(sbc.querySelector(`[data-fut-head-cap-of="sbc"]`),t('headBar.submits'))
mark(sbc,'futHeadBanning',fit.running?'1':'0')
mark(root,'futHeadBan',fit.running?'1':'0')
const banOf=(text)=>{const node=sbc.querySelector('.fx-hd-ban')
if(node===null)return
write(node.querySelector('.fx-hd-ban-k'),text===null?'':`${t('headBar.banWord')} `)
write(node.querySelector('.fx-hd-ban-t'),text===null?'':text)
attr(node,'title',text===null?'':t('headBar.banUntil',{time:text}))}
if(data.sbc===null){fraction(valOf(sbc,'sbc-hour'),'–','',false)
fraction(valOf(sbc,'sbc-day'),'','',false)
banOf(null)
mark(sbc,'futHeadHot','0')}
else{fraction(valOf(sbc,'sbc-hour'),String(data.sbc.hourUsed),`/${data.sbc.hourCap}`,data.sbc.hourHot,data.sbc.hourShare)
fraction(valOf(sbc,'sbc-day'),String(data.sbc.dayUsed),`/${data.sbc.dayCap}`,data.sbc.dayHot,data.sbc.dayShare)
mark(sbc,'futHeadHot',data.sbc.hot?'1':'0')
banOf(fit.ban)}
attr(sbc,'title',t('headBar.submitsHint',{hour:data.sbc?.hourCap??SBC_HOUR_CAP,day:data.sbc?.dayCap??SBC_DAY_CAP}))
clubEyeIn(club,data.view.club===true)
const cluster=clusterIn(root,club)
for(const node of root.querySelectorAll(`[data-fut-head-eye]`)){const kind=node.dataset[EYE_MARK]
const on=kind==='division'?data.view.division===true:data.view.club===true
mark(node,'futHeadEyeOn',on?'1':'0')
const label=t(on?`headBar.hide.${kind}`:`headBar.show.${kind}`)
attr(node,'title',label)
attr(node,'aria-label',label)
attr(node,'aria-pressed',on?'false':'true')}
const divChip=cluster.querySelector('.fx-hd-chip-div')
mark(divChip,DIV_MARK,data.division===null?'0':'1')
const plat=divChip.querySelector('.fx-hd-plat')
const sign=data.platform
mark(plat,PLAT_MARK,sign===null?'0':sign.sign)
const platClass=sign===null?'fx-hd-plat':`fx-hd-plat ${PLATFORM_SIGN_HOST} ${sign.sign}`
if(plat!==null&&plat.className!==platClass)plat.className=platClass
attr(plat,'title',sign===null?''
:sign.kind==='PSN'?t('headBar.platform.PSN')
:sign.kind==='XBL'?t('headBar.platform.XBL')
:sign.kind==='PC'?t('headBar.platform.PC'):'')
write(divChip.querySelector('.fx-hd-k'),t('headBar.division'))
write(divChip.querySelector(`[data-fut-head-div-num="1"]`),
data.division===null?'':String(data.division.number))
const divRec=divChip.querySelector('.fx-hd-div-rec')
const record=data.division?.record??null
mark(divRec,'futHeadRec',record===null?'0':'1')
write(divRec,record===null?'':record)
attr(divChip,'title',t('headBar.divisionHint'))
const chip=cluster.querySelector(`[data-fut-head-chip="1"]`)
write(chip.querySelector('.fx-hd-chip-plan-name'),t(data.chip.unlocked?'headBar.premium':'headBar.free'))
const untilNode=chip.querySelector('.fx-hd-chip-until')
write(untilNode,data.chip.until!==null
?t('headBar.until',{date:data.chip.until})
:data.chip.unlocked?t('headBar.noExpiry')
:data.chip.signIn?t('headBar.signIn'):'')
const signInWord=data.chip.until===null&&!data.chip.unlocked&&data.chip.signIn
mark(untilNode,SIGN_IN_MARK,signInWord?'1':'0')
mark(chip,GUEST_MARK,signInWord?'1':'0')
if(signInWord)attr(untilNode,'title',t('headBar.signInHint'))
else if(untilNode.getAttribute('title')!==null)untilNode.removeAttribute('title')
mark(chip,'futHeadPlan',data.chip.unlocked?'premium':'free')
if(onOpenPanel===null)delete chip.dataset[PANEL_DOOR_MARK]
else mark(chip,PANEL_DOOR_MARK,'1')
attr(chip,'title',t(data.chip.unlocked?'headBar.chipHintPremium':'headBar.chipHintFree'))
try{placeUpdateLine(cluster,{doc,win,t})}catch(err){onError(err)}
return true}
function currencyShape(){try{const win2=win
if(win2===null||typeof win2.getComputedStyle!=='function')return null
for(const root of bars()){const box=root.querySelector(NAV_CURRENCY)
if(box===null)continue
const rect=typeof box.getBoundingClientRect==='function'?box.getBoundingClientRect():null
if(rect===null||rect.height<=0)continue
const style=win2.getComputedStyle(box)
const kids=[...box.children].filter((node)=>{const kid=node.getBoundingClientRect?.()??null
return kid!==null&&kid.height>0})
return{direction:style.flexDirection,marked:box.dataset[COLUMN_MARK]==='1',
width:Math.round(rect.width),height:Math.round(rect.height),
rows:kids.length,
order:kids.map((node)=>({top:Math.round(node.getBoundingClientRect().top),
text:(node.textContent??'').trim()}))
.sort((a,b)=>a.top-b.top).map((row)=>row.text)}}
return null}catch{return null}}
function currencyWord(shape){if(shape===null)return '—'
return `${shape.direction}, строк ${shape.rows}: ${shape.order.join(' | ')}`}
function openAccount(){counts.accounts+=1
openAccountDoor(win).catch(onError)
return{ok:true,reason:null}}
function openPanel(){if(onOpenPanel===null)return{ok:false,reason:'no-door'}
try{counts.panels+=1
onOpenPanel()
return{ok:true,reason:null}}catch(err){onError(err)
return{ok:false,reason:'failed'}}}
function refresh(){try{if(isActive(HEAD_BAR_FEATURE)!==true){drop()
lastReason='locked'
return{ok:false,reason:'locked',bars:0}}
ensureTheme(doc)
ensureStylesheet(doc,HEAD_STYLESHEET,HEAD_LINK_ID)
const data=model()
counts.passes+=1
let painted=0
const list=bars()
for(const root of list){try{if(paintBar(root,data))painted+=1}catch(err){onError(err)}}
counts.bars=list.length
counts.painted=painted
lastReason=painted===0?'no-bars':null
askDivision()
askRecord()
if(data.sbc?.until!==null&&data.sbc?.until!==undefined)tick()
return{ok:painted>0,reason:lastReason,bars:painted}}catch(err){onError(err)
lastReason='failed'
return{ok:false,reason:'failed',bars:0}}}
return{refresh,drop,toggle,openPanel,openAccount,askDivision,askRecord,
relabel(){refresh()},
state(){let data=null
try{data=model()}catch(err){onError(err)
data=null}
const silence=data===null?'—':divisionSilence(data.view,data.division)
const shape=currencyShape()
const width=(()=>{try{const value=win?.innerWidth
return Number.isFinite(value)?value:null}catch{return null}})()
return{feature:HEAD_BAR_FEATURE,build:HEAD_BAR_BUILD,reason:lastReason,counts:{...counts},
bars:bars().length,ticking,
searchCap:SEARCH_HOUR_OURS,view:view(),silence,width,
model:data===null?null:{search:data.search,sbc:data.sbc,division:data.division,
platform:data.platform,chip:data.chip},
currency:shape,
rivals:rivals?.state?.()??null,
line:data===null?`шапка ${HEAD_BAR_BUILD}: моделей нет`
:`шапка ${HEAD_BAR_BUILD}: полос ${bars().length}, поиски ${data.search===null?'—':`${data.search.used}/${data.search.cap}`}`
+`, СБЧ ${data.sbc===null?'—':`${data.sbc.hourUsed}/${data.sbc.hourCap} за час, ${data.sbc.dayUsed}/${data.sbc.dayCap} за сутки`}`
+`${data.sbc?.untilText?`, час отпустит через ${data.sbc.untilText}`:''}`
+`, дивизион ${data.division===null?'—':data.division.number}`
+`, В-Н-П ${data.division?.record??'—'}`
+`, платформа ${data.platform===null?'—':`${data.platform.kind} (${data.platform.sign})`}`
+`, валюты ${currencyWord(shape)}`
+`, стата ${silence} на окне ${width===null?'—':width}`
+`, ходили за ним ${counts.asked} раз, за В-Н-П ${counts.record}`
+`, запросов В-Н-П ${rivals?.state?.()?.record?.sends??'—'}`
+`, тариф ${data.chip.unlocked?'premium':'free'}`
+`, дверь панели ${onOpenPanel===null?'нет':'есть'}`
+`, «войти» ${data.chip.signIn?'есть':'нет'}, нажат ${counts.accounts} раз`}},
dispose(){drop()}}}
