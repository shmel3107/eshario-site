import{installSquadSelectionCapture,installSquadSlotCapture} from '../adapter/squad-slot.js'
const ROW_SELECTOR='.listFUTItem'
const CARD_SELECTOR='.ut-item-view'
const NAME_SELECTOR='.name'
const SQUAD_SLOT_SELECTOR='.ut-squad-slot-view'
export function selectedPlayerName(item){if(!item||typeof item!=='object')return''
try{if(typeof item.isPlayer==='function'&&item.isPlayer()!==true)return''}catch{return''}
let data=null
try{data=item.getStaticData?.()??null}catch{}
for(const value of[data?.name,item.displayName,item.name,item.commonName]){const clean=cleanName(value)
if(clean)return clean}
return''}
export function selectedPlayerRecord(item){const name=selectedPlayerName(item)
if(!name)return null
const selected={name}
let definitionId
try{definitionId=Number(item?.definitionId)}catch{}
if(Number.isSafeInteger(definitionId)&&definitionId>0)selected.definitionId=definitionId
return selected}
export function selectedPlayerFromTarget(target,options={}){if(!target||typeof target.closest!=='function')return null
const squadSlot=target.closest(SQUAD_SLOT_SELECTOR)
if(squadSlot){let item=null
try{item=options.itemForSquadSlot?.(squadSlot)??null}catch{}
return selectedPlayerRecord(item)}
const row=target.closest(ROW_SELECTOR)
if(row){let item=null
try{item=options.itemForRow?.(row)??null}catch{}
if(item)return selectedPlayerRecord(item)}
const card=target.closest(CARD_SELECTOR)??row?.querySelector?.(CARD_SELECTOR)??null
const name=cleanName(card?.querySelector?.(NAME_SELECTOR)?.textContent)
return name?{name}:null}
export function installSelectedPlayerCapture(options={}){const{doc,win,itemForRow,onSelect=()=>{}}=options
const onSelectItem=typeof options.onSelectItem==='function'?options.onSelectItem:()=>{}
if(!doc||typeof doc.addEventListener!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let lastSelection=''
const squadSlots=new WeakMap()
let squadCapture=null
let controllerCapture=null
const deliver=(selected,item=null)=>{if(!selected)return
const key=JSON.stringify(selected)
if(key===lastSelection)return
lastSelection=key
try{onSelectItem(item)}catch{}
try{onSelect(Object.freeze(selected))}catch{}}
const emit=(item)=>deliver(selectedPlayerRecord(item),item)
const ensureNativeCaptures=()=>{if(!squadCapture?.ok)squadCapture=installSquadSlotCapture(win,(slot,item)=>{if(item&&typeof item==='object')squadSlots.set(slot,item)
else squadSlots.delete(slot)})
if(!controllerCapture?.ok)controllerCapture=installSquadSelectionCapture(win,emit)}
ensureNativeCaptures()
const listener=(event)=>{const path=event?.composedPath?.()
const target=Array.isArray(path)&&path.length>0?path[0]:event?.target
ensureNativeCaptures()
let native=null
const remember=(item)=>{native=item??null;return item}
const selected=selectedPlayerFromTarget(target,{itemForRow:(row)=>remember(itemForRow?.(row)??null),itemForSquadSlot:(slot)=>remember(squadSlots.get(slot)??null)})
deliver(selected,native)}
doc.addEventListener('pointerdown',listener,true)
return{ok:true,reason:null,dispose(){doc.removeEventListener?.('pointerdown',listener,true)
squadCapture?.dispose()
controllerCapture?.dispose()}}}
function cleanName(value){return typeof value==='string'?value.trim().replace(/\s+/g,' '):''}
