import{createRateWindow,dayKeyOf,SEARCH_HOUR_CAP,HOUR_MS,untilText} from './head-counters.js'
import{classifyStatus} from '../adapter/error-codes.js'
export{dayKeyOf}
export const DAY_REQUEST_CAP=2_000
export const DAY_BUDGET_REFUSAL='day-budget'
export const COUNTER_UNAVAILABLE='counter-unavailable'
export const BUDGET_DOOR_WARM='warm'
export const BUDGET_DOOR_TAKE='take'
export const BUDGET_DOOR_SETTLE='settle'
export const BUDGET_DOORS=Object.freeze([BUDGET_DOOR_WARM,BUDGET_DOOR_TAKE,BUDGET_DOOR_SETTLE])
export async function askBudgetRound(doors,count=1){const warmed=await doors.warm(count)
if(typeof warmed==='string')return{reason:warmed,door:BUDGET_DOOR_WARM}
const slot=doors.take(count)
if(typeof slot==='string')return{reason:slot,door:BUDGET_DOOR_TAKE}
const settled=await doors.settle()
if(typeof settled==='string')return{reason:settled,door:BUDGET_DOOR_SETTLE}
return null}
export async function readBudgetRound(doors,count=1){const first=await askBudgetRound(doors,count)
if(first===null||first.reason!==COUNTER_UNAVAILABLE)return first
return askBudgetRound(doors,count)}
export function dayBudgetError(stage,reason=DAY_BUDGET_REFUSAL,door=null){const err=new Error(reason)
err.dayBudget=true
err.reason=reason
err.stage=stage
err.door=typeof door==='string'&&BUDGET_DOORS.includes(door)?door:null
return err}
export const THROTTLED='throttled'
export function restMarketAfterThrottle(budget){if(!budget||typeof budget.rest!=='function')return false
try{budget.rest()
return true}catch{return false}}
export function eaStatusOf(err){if(err===null||typeof err!=='object')return null
const raw=err.response?.error?.code??err.response?.status??err.error?.code??err.status
return Number.isInteger(raw)?raw:null}
export function eaLimitOf(err){const kind=classifyStatus(eaStatusOf(err))
return kind==='captcha'||kind===THROTTLED?kind:null}
export function stopOnEaLimit(budget,err){const limit=eaLimitOf(err)
if(limit===null)return null
restMarketAfterThrottle(budget)
return limit}
export const EA_LIMIT='ea-limit'
export const REQUEST_STOP_WORDS=Object.freeze([EA_LIMIT,DAY_BUDGET_REFUSAL,COUNTER_UNAVAILABLE,
'search-hour','hour-cap','rest','budget',THROTTLED,'captcha'])
export function stopsRequest(reason){return typeof reason==='string'&&REQUEST_STOP_WORDS.includes(reason)}
export function isDayBudgetError(err){return err!==null&&typeof err==='object'&&err.dayBudget===true}
export function meterCalls(target,day,names,opts={}){if(target===null||typeof target!=='object')return target
if(!day||typeof day.take!=='function')return target
const market=opts.market===true
const out={...target}
for(const name of names){const call=target[name]
if(typeof call!=='function')continue
out[name]=async(...args)=>{const stop=await askDayBudgetRound(day,1,{market})
if(stop!==null)throw dayBudgetError(opts.stage??name,stop.reason,stop.door)
return call(...args)}}
return out}
export async function askDayBudgetRound(day,count=1,opts={}){if(!day||typeof day.take!=='function')return null
const market=opts.market===true
const want=Number.isSafeInteger(count)&&count>0?count:1
const doors={warm:(n)=>(typeof day.warm==='function'?day.warm(n,{market}):null),
take:(n)=>day.take(n,{market}),
settle:()=>(typeof day.settle==='function'?day.settle({market}):null)}
try{const first=await askBudgetRound(doors,want)
if(first===null)return null
if(first.reason!==COUNTER_UNAVAILABLE||first.door===BUDGET_DOOR_SETTLE)return first
return await askBudgetRound(doors,want)}
catch{
return{reason:COUNTER_UNAVAILABLE,door:null}}}
export async function askDayBudget(day,count=1,opts={}){const stop=await askDayBudgetRound(day,count,opts)
return stop===null?null:stop.reason}
const NEWLINE=String.fromCharCode(10)
export function readDayBudget(stored){if(!stored||typeof stored!=='object'||Array.isArray(stored))return{day:null,used:0,hour:null}
const day=typeof stored.day==='string'&&stored.day!==''?stored.day:null
const used=Number.isSafeInteger(stored.used)&&stored.used>=0?stored.used:0
const hour=stored.hour??null
return day===null?{day:null,used:0,hour}:{day,used,hour}}
export const BUDGET_RESERVE='budget.reserve'
export const BUDGET_SPEND='budget.spend'
export const BUDGET_RELEASE='budget.release'
export const BUDGET_REST='budget.rest'
export const BUDGET_STATE='budget.state'
export const TICKET_DEPTH=1
export const PLEDGE_TTL_MS=60_000
export const MIRROR_REFRESH_MS=1_000
export const BUDGET_KINDS=Object.freeze(['minute','market','other','bid'])
const countOf=(value)=>(Number.isSafeInteger(value)&&value>0?value:1)
export function createBudgetOwner(deps={}){const request=typeof deps.request==='function'?deps.request:null
if(request===null){throw new Error('budget-owner: нужен порт к фоновому воркеру')}
const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('budget-owner: нужны часы (правило 6 NIGHT_BRIEF)')}
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const depth=Number.isSafeInteger(deps.depth)&&deps.depth>0?deps.depth:TICKET_DEPTH
const credit={minute:[],market:[],other:[],bid:[]}
const inflight={minute:new Set(),market:new Set(),other:new Set(),bid:new Set()}
let generation=null
const asking={minute:false,market:false,other:false,bid:false}
const said={minute:null,market:null,other:null,bid:null}
let mirror=null
let mirrorAt=-Infinity
let refreshing=false
let localRestUntil=0
let pending=null
let refused=0
const alive=(kind)=>{const now=clock.now()
const rows=credit[kind]
let live=0
for(let i=rows.length-1;i>=0;i-=1){if(rows[i].until<=now)rows.splice(i,1)
else live+=rows[i].left}
return live}
const claim=(kind,want)=>{const rows=credit[kind]
const out=[]
let need=want
while(need>0&&rows.length>0){const row=rows[0]
const step=Math.min(row.left,need)
row.left-=step
need-=step
out.push({id:row.id,count:step})
if(row.left<=0)rows.shift()}
return out}
const grant=(kind,result)=>{const count=Number.isSafeInteger(result?.granted)?result.granted:0
if(count<=0)return
const lease=result?.lease
const until=Number.isSafeInteger(lease?.expiresAt)?lease.expiresAt:clock.now()+PLEDGE_TTL_MS
credit[kind].push({id:typeof lease?.id==='string'?lease.id:null,left:count,until})}
const forget=(kind,tell)=>{const rows=credit[kind]
credit[kind]=[]
if(tell!==true)return
for(const row of rows){if(row.id===null)continue
void post(BUDGET_RELEASE,{kind,count:row.left,lease:row.id})}}
const restUntil=()=>Math.max(localRestUntil,
Number.isSafeInteger(mirror?.restingUntil)?mirror.restingUntil:0)
const resting=()=>clock.now()<restUntil()
const applyState=(state)=>{if(!state||typeof state!=='object')return
const born=typeof state.generation==='string'?state.generation:null
if(born!==null&&generation!==null&&born!==generation){for(const kind of BUDGET_KINDS)forget(kind,false)}
if(born!==null)generation=born
mirror=state
mirrorAt=clock.now()
if(resting())forget('minute',true)
for(const kind of BUDGET_KINDS){if(said[kind]===null&&!(kind==='minute'&&resting())&&alive(kind)<depth)ask(kind,depth)}}
const post=(method,params)=>{let answer
try{answer=request(method,params)}catch(err){onError(err)
return Promise.resolve(null)}
return Promise.resolve(answer).then((result)=>{if(result&&typeof result==='object')applyState(result.state)
return result&&typeof result==='object'?result:null},(err)=>{onError(err)
return null})}
const ask=(kind,want)=>{if(asking[kind])return
const need=Math.max(depth,want)-alive(kind)
if(need<=0)return
asking[kind]=true
void post(BUDGET_RESERVE,{kind,count:need}).then((result)=>{asking[kind]=false
if(result&&result.ok===true){grant(kind,result)
said[kind]=null
return}
said[kind]=typeof result?.reason==='string'?result.reason:COUNTER_UNAVAILABLE})}
const redeem=(kind,part)=>{const done=(async()=>{const first=await post(BUDGET_SPEND,{kind,count:part.count,lease:part.id})
noteSpend(kind,first)
if(recorded(first))return null
let result=first
if(first===null){forget(kind,false)
const fresh=await post(BUDGET_RESERVE,{kind,count:part.count})
if(fresh!==null&&fresh.ok===true){grant(kind,fresh)
result=null
for(const one of claim(kind,part.count)){result=await post(BUDGET_SPEND,{kind,count:one.count,lease:one.id})
if(!recorded(result))break}
if(recorded(result)){said[kind]=null
ask(kind,depth)
return null}}}
forget(kind,false)
const word=typeof result?.reason==='string'?result.reason:COUNTER_UNAVAILABLE
said[kind]=word
ask(kind,depth)
return word})()
const rows=inflight[kind]
rows.add(done)
void done.then(()=>rows.delete(done),()=>rows.delete(done))
return done}
const knownRefusal=(kind)=>said[kind]??COUNTER_UNAVAILABLE
const recorded=(answer)=>answer!==null&&typeof answer==='object'&&answer.ok===true
let spent=null
const noteSpend=(kind,result)=>{spent={kind,at:clock.now(),
silent:result===null,
ok:result===null?null:result.ok===true,
lease:typeof result?.lease==='string'?result.lease:null,
reason:typeof result?.reason==='string'?result.reason:null}}
const spendLine=()=>{if(spent===null)return 'выкупов ещё не было'
if(spent.silent)return `последний выкуп (${spent.kind}): ответа не было вовсе`
return `последний выкуп (${spent.kind}): ok=${spent.ok}, имя=${spent.lease??'—'}, причина=${spent.reason??'—'}`}
return{depth,
load(){if(pending!==null)return pending
pending=(async()=>{const result=await post(BUDGET_STATE,null)
if(!result||result.ok!==true){pending=null
throw new Error(`budget-owner: ${result?.reason??'нет ответа'}`)}
for(const kind of BUDGET_KINDS)ask(kind,depth)
return result.state})()
return pending},
take(kind,count=1){const want=countOf(count)
if(kind==='minute'&&resting()){refused+=1
return 'rest'}
if(alive(kind)>=want){
for(const part of claim(kind,want))redeem(kind,part)
ask(kind,depth)
return null}
ask(kind,want)
refused+=1
return knownRefusal(kind)},
async warm(kind,count=1){const want=countOf(count)
if(kind==='minute'&&resting())return 'rest'
const have=alive(kind)
if(have>=want)return null
const need=want-have
let result=null
try{result=await post(BUDGET_RESERVE,{kind,count:need})}catch(err){onError(err)
result=null}
if(result&&result.ok===true){grant(kind,result)
said[kind]=null
if(alive(kind)>=want)return null
refused+=1
return knownRefusal(kind)}
said[kind]=typeof result?.reason==='string'?result.reason:COUNTER_UNAVAILABLE
refused+=1
return knownRefusal(kind)},
refusal(kind,count=1){const want=countOf(count)
if(kind==='minute'&&resting())return 'rest'
return alive(kind)>=want?null:knownRefusal(kind)},
async settle(kind){const rows=inflight[kind]
if(!rows||rows.size===0)return null
const words=await Promise.all([...rows])
for(const word of words){if(typeof word==='string')return word}
return null},
release(kind,count=1){ask(kind,Math.max(depth,countOf(count)))
return true},
rest(ms){const asked=Number.isSafeInteger(ms)&&ms>0?ms:null
const now=clock.now()
const guess=now+(asked??0)
if(guess>localRestUntil)localRestUntil=guess
forget('minute',true)
void post(BUDGET_REST,asked===null?null:{ms:asked})
return restUntil()},
state(){const now=clock.now()
if(!refreshing&&now-mirrorAt>=MIRROR_REFRESH_MS){refreshing=true
void post(BUDGET_STATE,null).then(()=>{refreshing=false},()=>{refreshing=false})}
return mirror},
waitMs(){const now=clock.now()
const until=restUntil()
if(now<until)return until-now
if(alive('minute')>0)return 0
const window=mirror?.minute
if(!window||!Number.isSafeInteger(window.oldest))return 0
return window.used>=window.cap?Math.max(0,window.oldest+window.windowMs-now):0},
tickets:()=>{const out={}
for(const kind of BUDGET_KINDS)out[kind]=alive(kind)
return out},
refusedCount:()=>refused,
lastSpend:()=>(spent===null?null:{...spent}),
spendLine}}
export function createDayBudget(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('day-budget: нужны часы (правило 6 NIGHT_BRIEF)')}
const cap=Number.isSafeInteger(deps.cap)&&deps.cap>0?deps.cap:DAY_REQUEST_CAP
const storage=deps.storage??null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
if(deps.owner)return createOwnedDayBudget(deps.owner,clock,cap)
let day=dayKeyOf(clock.now())
let used=0
let ready=storage===null
let broken=false
let usedMarket=0
let usedOther=0
let refused=0
let pending=null
const hour=createRateWindow({clock,cap:SEARCH_HOUR_CAP,windowMs:HOUR_MS,onError})
const unavailable=()=>(broken||!ready?COUNTER_UNAVAILABLE:null)
const save=()=>{if(storage===null)return false
try{const done=storage.write({day,used,hour:hour.dump()})
if(done&&typeof done.catch==='function')done.catch((err)=>{broken=true
onError(err)})
return true}catch(err){broken=true
onError(err)
return false}}
const rollover=()=>{const today=dayKeyOf(clock.now())
if(today===day)return false
day=today
used=0
usedMarket=0
usedOther=0
save()
return true}
return{cap,
load(){if(pending!==null)return pending
pending=(async()=>{if(storage!==null){let stored=null
try{stored=await storage.read()
broken=false
ready=true}catch(err){onError(err)
broken=true
pending=null
throw err}
const parsed=readDayBudget(stored)
const today=dayKeyOf(clock.now())
if(parsed.day===today)used=Math.min(cap,parsed.used)
day=today
hour.restore(parsed.hour)}
return{day,used,hour:hour.state().used}})()
return pending},
left(){if(unavailable()!==null)return 0
rollover()
return Math.max(0,cap-used)},
refusal(count=1){const blocked=unavailable()
if(blocked!==null)return blocked
rollover()
const want=Number.isSafeInteger(count)&&count>0?count:1
return used+want>cap?DAY_BUDGET_REFUSAL:null},
warm(count=1){const blocked=unavailable()
if(blocked!==null)return Promise.resolve(blocked)
rollover()
const size=Number.isSafeInteger(count)&&count>0?count:1
return Promise.resolve(used+size>cap?DAY_BUDGET_REFUSAL:null)},
take(count=1,opts={}){const blocked=unavailable()
if(blocked!==null)return blocked
rollover()
const want=Number.isSafeInteger(count)&&count>0?count:1
if(used+want>cap){refused+=1
return DAY_BUDGET_REFUSAL}
used+=want
const market=opts?.market!==false
if(market)usedMarket+=want
else usedOther+=want
if(market){for(let i=0;i<want;i+=1)hour.take()}
save()
return null},
state(){rollover()
const window=hour.state()
return{day,cap,used,left:Math.max(0,cap-used),refused,hour:window,
available:unavailable()===null,
split:{market:usedMarket,other:usedOther},
line:searchLine(window)+NEWLINE+dayLine(day,used,cap,usedMarket,usedOther)}}}}
function searchLine(window){return `поиски рынка: ${window.used}/${window.cap} за час`+(window.until===null?'':`, час отпустит через ${window.untilText}`)}
function dayLine(day,used,cap,market,other){return `все обращения к EA: ${used}/${cap} за сутки (${day})`+(market+other>0?` — из них за эту страницу рыночных ${market}, прочих ${other}`:'')}
export function offMarket(day){if(!day||typeof day.take!=='function')return day
const off={...day,take:(count=1)=>day.take(count,{market:false})}
if(typeof day.warm==='function')off.warm=(count=1)=>day.warm(count,{market:false})
if(typeof day.settle==='function')off.settle=()=>day.settle({market:false})
if(typeof day.refusal==='function')off.refusal=(count=1)=>day.refusal(count,{market:false})
return off}
export function createHuntBudget(market,day){return{
search:()=>(market&&typeof market.take==='function'?market.take():null),
call:(count=1)=>(day&&typeof day.take==='function'?day.take(count,{market:false}):null),
warm:(count=1)=>(day&&typeof day.warm==='function'
?day.warm(count,{market:false})
:Promise.resolve(null)),
settle:(opts={})=>(day&&typeof day.settle==='function'
?day.settle(opts)
:Promise.resolve(null)),
waitMs:()=>(market&&typeof market.waitMs==='function'?Number(market.waitMs())||0:0),
searchesLeft:()=>searchesLeftOf(day&&typeof day.state==='function'?day.state():null),
rest:(ms)=>(market&&typeof market.rest==='function'?market.rest(ms):0)}}
export function searchesLeftOf(state){return state?.available===false
?null
:(Number.isSafeInteger(state?.left)?state.left:null)}
export function withDayBudget(budget,day){if(!day)return budget
return{...budget,
waitMs:()=>budget.waitMs(),
rest:(ms)=>budget.rest(ms),
async warm(count=1){const pre=typeof day.warm==='function'?await day.warm(count):null
if(pre!==null)return pre
return typeof budget.warm==='function'?await budget.warm(count):null},
take(){const pre=typeof day.refusal==='function'?day.refusal(1):(day.left()<=0?DAY_BUDGET_REFUSAL:null)
if(pre!==null)return pre
const refusal=budget.take()
if(refusal!==null)return refusal
return day.take(1)},
async settle(opts={}){const minute=typeof budget.settle==='function'?await budget.settle(opts):null
if(typeof minute==='string')return minute
return typeof day.settle==='function'?await day.settle(opts):null},
stats:()=>({...budget.stats(),day:day.state()})}}
export function windowStateOf(window,now){const cap=Number.isSafeInteger(window?.cap)?window.cap:0
const used=Number.isSafeInteger(window?.used)?window.used:0
const windowMs=Number.isSafeInteger(window?.windowMs)?window.windowMs:HOUR_MS
const until=used>=cap&&cap>0&&Number.isSafeInteger(window?.oldest)?window.oldest+windowMs:null
return{cap,windowMs,used,left:Math.max(0,cap-used),over:Math.max(0,used-cap),full:cap>0&&used>=cap,
until,untilText:until===null?null:untilText(until,now)}}
function createOwnedDayBudget(owner,clock,cap){let usedMarket=0
let usedOther=0
let refused=0
const want=(count)=>(Number.isSafeInteger(count)&&count>0?count:1)
const kindOf=(opts)=>(opts?.market!==false?'market':'other')
return{cap,owner,
load(){return owner.load().then((state)=>({day:state?.day??null,used:state?.used??0,
hour:state?.hour?.used??0}))},
left(){const state=owner.state()
return state===null||state===undefined?0:Math.max(0,cap-state.used)},
refusal(count=1,opts={}){return owner.refusal(kindOf(opts),want(count))},
rest(ms){return typeof owner.rest==='function'?owner.rest(ms):0},
release(count=1,opts={}){return typeof owner.release==='function'
?owner.release(kindOf(opts),want(count)):false},
warm(count=1,opts={}){return typeof owner.warm==='function'
?owner.warm(kindOf(opts),want(count))
:Promise.resolve(null)},
settle(opts={}){return typeof owner.settle==='function'
?owner.settle(kindOf(opts))
:Promise.resolve(null)},
take(count=1,opts={}){const kind=kindOf(opts)
const size=want(count)
const word=owner.take(kind,size)
if(word!==null){refused+=1
return word}
if(kind==='market')usedMarket+=size
else usedOther+=size
return null},
state(){const now=clock.now()
const snapshot=owner.state()
const available=snapshot!==null&&snapshot!==undefined
const hour=windowStateOf(snapshot?.hour,now)
const used=available?snapshot.used:0
const day=available?snapshot.day:null
return{build:'W22D',day,cap,used,left:available?Math.max(0,cap-used):0,refused,hour,available,
split:{market:usedMarket,other:usedOther},
line:available
?searchLine(hour)+NEWLINE+dayLine(day,used,cap,usedMarket,usedOther)+NEWLINE+bidLine(snapshot.buy)
+NEWLINE+(typeof owner.spendLine==='function'?owner.spendLine():'')
:'счётчики защиты ещё не прочитаны: сколько потрачено, неизвестно'}}}
function bidLine(window){const used=Number.isSafeInteger(window?.used)?window.used:0
const cap=Number.isSafeInteger(window?.cap)?window.cap:0
return `ставки: ${used}/${cap} за час`}}
