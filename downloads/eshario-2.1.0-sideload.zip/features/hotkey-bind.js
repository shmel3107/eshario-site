import{el} from '../ui/dom.js'
import{modalBox,modalButtons,WINDOW_BUTTON_CLASS} from '../ui/window.js'
import{ensureControls} from '../ui/controls.js'
import{templateChipAt} from './market-bot-column.js'
import{LAYERS,comboFromEvent,canonicalCombo,detectConflicts,layerOf,layersClash,groupOfLayer} from './hotkeys.js'
import{cardLockedNow} from './card-locks.js'
import{rowDeedLabels} from '../adapter/item-actions.js'
export const PRESS_GESTURE=Object.freeze([['pointerdown','PointerEvent'],['mousedown','MouseEvent'],['mouseup','MouseEvent'],['click','MouseEvent']])
function visible(node){const box=node?.getBoundingClientRect?.()
return box?Number(box.height)>0:true}
export function screenVisible(doc,selector){if(typeof selector!=='string'||selector==='')return false
let roots
try{roots=doc?.querySelectorAll?.(selector)}catch{return false}
return Array.from(roots??[]).some(visible)}
export function layerVisible(doc,layer){if(layer==='global')return true
return screenVisible(doc,LAYERS[layer])}
export function pressNode(node,win,onError=()=>{}){if(!node?.dispatchEvent)return false
for(const[type,ctor]of PRESS_GESTURE){const Ctor=win?.[ctor]??win?.MouseEvent
if(typeof Ctor!=='function')continue
try{node.dispatchEvent(new Ctor(type,{bubbles:true,cancelable:true,composed:true}))}catch(err){onError(err)}}
return true}
export function pressTarget(doc,meta){if(typeof meta?.press!=='string'||meta.press==='')return null
if(typeof meta.deed==='string')return rowButtonByDeed(doc,meta.deed)
const layer=layerOf(meta)
if(layer==='global'||meta.pressScope==='document'){const all=matchesIn(doc?.body??doc,meta.press)
const seen=all.find(visible)
if(seen)return seen
return meta.requireVisible===true?null:(all[0]??null)}
let roots
try{roots=doc?.querySelectorAll?.(LAYERS[layer])}catch{return null}
for(const root of Array.from(roots??[])){const box=root?.getBoundingClientRect?.()
if(box&&!(Number(box.height)>0))continue
let found=null
try{found=root?.querySelector?.(meta.press)??null}catch{found=null}
if(found&&meta.requireVisible===true&&!visible(found))continue
if(found)return found}
return null}
function rowButtonText(node){for(const kid of Array.from(node?.children??[])){let own=false
try{own=kid?.classList?.contains?.('btn-text')===true}catch{own=false}
if(own)return String(kid.textContent??'').trim()}
return''}
function rowButtons(doc){const out=[]
let panels=[]
try{panels=Array.from(doc?.querySelectorAll?.('.DetailPanel')??[])}catch{panels=[]}
for(const panel of panels){if(!visible(panel))continue
for(const group of Array.from(panel.children??[])){let row=false
try{row=group?.classList?.contains?.('ut-button-group')===true}catch{row=false}
if(!row)continue
for(const button of Array.from(group.children??[])){if(String(button?.tagName??'').toUpperCase()==='BUTTON'&&visible(button))out.push(button)}}}
return out}
export function rowButtonByDeed(doc,deed){const labels=rowDeedLabels(doc?.defaultView??null,deed)
if(labels.length===0)return null
return rowButtons(doc).find((button)=>labels.includes(rowButtonText(button)))??null}
function sameRowButton(label,node){if(typeof label!=='string'||label==='')return false
if(labelOfNode(node)===label)return true
const text=rowButtonText(node)
if(text==='')return false
return label===text.slice(0,40)||label.startsWith(`${text} `)}
const CARD_LOCK_SELECTOR='[data-fut-card-lock]'
const LOCK_LOOKUP_DEPTH=5
export function lockedCardAt(node){let at=node
for(let depth=0;at&&depth<LOCK_LOOKUP_DEPTH;depth+=1,at=at.parentElement){const doc=at.ownerDocument
if(at===doc?.body||at===doc?.documentElement)break
let mark=null
try{mark=at.querySelector?.(CARD_LOCK_SELECTOR)??null}catch{mark=null}
if(mark)return lockedByStore(mark)??mark.dataset?.futCardLockOn==='1'}
return false}
function lockedByStore(mark){const value=Number(mark?.dataset?.futCardLockId)
if(!Number.isSafeInteger(value)||value<=0)return null
try{return cardLockedNow(value)}catch{
return true}}
export function isTypingTarget(node){if(!node||typeof node!=='object') return false
const tag=String(node.tagName??'').toUpperCase()
if(tag==='INPUT'||tag==='TEXTAREA'||tag==='SELECT') return true
if(node.isContentEditable===true)return true
return String(node.contentEditable??'')==='true'
}
export function realTarget(event){const path=event?.composedPath?.()
if(Array.isArray(path)&&path.length>0)return path[0]
return event?.target??null}
const EA_DIALOG='.ea-dialog-view'
const EA_DIALOG_ROW='.ut-st-button-group'
export const CONFIRM_FRAMES=90
const hasClass=(node,name)=>String(node?.className??'').trim().split(/\s+/).includes(name)
export function confirmButton(doc){for(const dialog of Array.from(doc?.querySelectorAll?.(EA_DIALOG)??[])){if(!visible(dialog))continue
let row=null
try{row=dialog.querySelector?.(EA_DIALOG_ROW)??null}catch{row=null}
if(!row)continue
let buttons=[]
try{buttons=Array.from(row.querySelectorAll?.('button')??[])}catch{buttons=[]}
const first=buttons[0]
if(!first||!hasClass(first,'primary'))continue
return first}
return null}
export function visibleDialogs(doc){const out=[]
for(const dialog of Array.from(doc?.querySelectorAll?.(EA_DIALOG)??[])){if(visible(dialog))out.push(dialog)}
return out}
export function ownConfirmButton(doc,before){if(!Array.isArray(before))return{button:null,why:'blind'}
const open=visibleDialogs(doc)
if(open.length===0)return{button:null,why:'none'}
const top=open[open.length-1]
if(before.includes(top))return{button:null,why:'stale'}
let row=null
try{row=top.querySelector?.(EA_DIALOG_ROW)??null}catch{row=null}
let buttons=[]
if(row){try{buttons=Array.from(row.querySelectorAll?.('button')??[])}catch{buttons=[]}}
const first=buttons[0]
if(!first||!hasClass(first,'primary'))return{button:null,why:'not-primary'}
return{button:first,why:'own'}}
export function createConfirmWatcher(deps){const{doc,win=null,onError=()=>{},onDone=()=>{}}=deps
let ticket=null
const finish=(result)=>{ticket=null
try{onDone(result)}catch(err){onError(err)}}
function look(mine){if(mine!==ticket)return
mine.frames+=1
let ok=null
try{ok=confirmButton(doc)}catch(err){onError(err)
finish({ok:false,reason:'failed'})
return}
if(ok){finish({ok:true,frames:mine.frames,pressed:pressNode(ok,win,onError)})
return}
if(mine.anchor?.isConnected===false){finish({ok:false,reason:'gone',frames:mine.frames})
return}
if(mine.frames>=CONFIRM_FRAMES){finish({ok:false,reason:'no-dialog',frames:mine.frames})
return}
next(mine)}
function next(mine){const frame=win?.requestAnimationFrame
if(typeof frame!=='function'){finish({ok:false,reason:'no-frames',frames:mine.frames})
return}
try{frame.call(win,()=>look(mine))}catch(err){onError(err)
finish({ok:false,reason:'failed'})}}
return{
arm(anchor){ticket={anchor:anchor??null,frames:0}
next(ticket)},
disarm(){ticket=null},
waiting:()=>ticket!==null}}
export const HOTKEYS_STYLESHEET=new URL('../ui/hotkeys.css',import.meta.url).href
export const HOTKEYS_LINK_ID='fut-companion-hotkeys'
export const UNSTABLE_CLASSES=Object.freeze(new Set(['active','disabled','enabled','hover','selected','isDragging','isDroppable','droppable','draggable','sortable','filled','empty','open','opened','closed','visible','hidden','loading','won','lost','expired','outbid','has-auction-data','is-selected','highlighted','focus','focused','pressed','on','off']))
export const CLICKABLE_SELECTOR='button,a[href],[role="button"],.btn-standard,.btn-flat,.btn-group,.pagination,.ut-navigation-button-control,.increment-value,.decrement-value,.tile'
const RIGHT_BUTTON=2
const HOTKEYS_FEATURE='hotkeys'
const SWALLOW_TYPES=Object.freeze(['pointerdown','mousedown','pointerup','mouseup','auxclick','click'])
const SHORT_KEYS=Object.freeze({arrowup:'↑',arrowdown:'↓',arrowleft:'←',arrowright:'→',backspace:'⌫',space:'␣',escape:'Esc',enter:'⏎',delete:'Del',pageup:'PgUp',pagedown:'PgDn'})
export function badgeParts(combo){if(typeof combo!=='string'||combo==='')return[]
return combo.split('+').map((part)=>SHORT_KEYS[part]??(part.length<=1?part.toUpperCase():`${part[0].toUpperCase()}${part.slice(1)}`))}
export const COMBO_JOIN=' + '
export function badgeText(combo){return badgeParts(combo).join(COMBO_JOIN)}
export function anchorBox(target,box,view,gap=8){const margin=6
const width=Math.max(0,Number(box?.width)||0)
const height=Math.max(0,Number(box?.height)||0)
const room=Math.max(0,Number(view?.width)||0)
const tall=Math.max(0,Number(view?.height)||0)
const right=Number(target?.right)||0
const left=Number(target?.left)||0
const fitsRight=right+gap+width<=room-margin
const side=fitsRight?'right':'left'
let x=fitsRight?right+gap:left-gap-width
if(x<margin)x=Math.min(margin,Math.max(0,room-width-margin))
if(x+width>room-margin)x=Math.max(margin,room-width-margin)
let y=Number(target?.top)||0
if(y+height>tall-margin)y=tall-height-margin
if(y<margin)y=margin
return{left:Math.round(x),top:Math.round(y),side}}
const LAYER_MARK='|'
const PARENT_MARK='>'
const INDEX_MARK='#'
function stableTokens(node){const raw=node?.classList
const list=raw&&typeof raw.length==='number'?Array.from(raw):String(node?.className??'').trim().split(/\s+/)
return list.filter((token)=>token!==''&&!UNSTABLE_CLASSES.has(token)&&!token.startsWith('fut-')).sort()}
function nodeSelector(node){const tokens=stableTokens(node)
if(tokens.length>0)return `.${tokens.join('.')}`
const tag=String(node?.tagName??'').toLowerCase()
return tag===''?'':tag}
export function layerOfNode(node){for(const[id,selector]of Object.entries(LAYERS)){if(id==='global'||selector==='')continue
let hit=null
try{hit=node?.closest?.(selector)??null}catch{hit=null}
if(hit)return id}
return 'global'}
export function elementKey(node,doc){if(!node||typeof node.tagName!=='string')return null
const own=nodeSelector(node)
if(own==='')return null
const parent=node.parentElement
const selector=parent?`${nodeSelector(parent)} ${PARENT_MARK} ${own}`.replace(/\s+/g,''):own
const layer=layerOfNode(node)
const root=layerRoot(node,doc,layer)
const index=Math.max(0,matchesIn(root,selector).indexOf(node))
return `${layer}${LAYER_MARK}${selector}${INDEX_MARK}${index}`}
function layerRoot(node,doc,layer){if(layer==='global')return doc?.body??doc?.documentElement??doc??null
try{return node?.closest?.(LAYERS[layer])??doc?.body??null}catch{return doc?.body??null}}
function matchesIn(root,selector){if(!root||selector==='')return []
try{return Array.from(root.querySelectorAll?.(selector)??[])}catch{return[]}}
export function parseElementKey(key){if(typeof key!=='string')return null
const cut=key.indexOf(LAYER_MARK)
if(cut<=0)return null
const layer=key.slice(0,cut)
if(!Object.hasOwn(LAYERS,layer))return null
const rest=key.slice(cut+1)
const hash=rest.lastIndexOf(INDEX_MARK)
if(hash<=0)return null
const index=Number(rest.slice(hash+1))
if(!Number.isSafeInteger(index)||index<0)return null
const selector=rest.slice(0,hash)
return selector===''?null:{layer,selector,index}}
export function findByKey(doc,key){const parsed=parseElementKey(key)
if(!parsed)return null
const{layer,selector,index}=parsed
if(layer==='global'){const found=matchesIn(doc?.body??doc,selector)[index]??null
return found&&visible(found)?found:null}
let roots
try{roots=doc?.querySelectorAll?.(LAYERS[layer])}catch{return null}
for(const root of Array.from(roots??[])){const box=root?.getBoundingClientRect?.()
if(box&&!(Number(box.height)>0))continue
const found=matchesIn(root,selector)[index]
if(found&&visible(found))return found}
return null}
export function targetOf(doc,meta){if(!meta)return null
if(typeof meta.boundKey==='string'&&meta.boundKey!=='')return boundTarget(doc,meta)
return pressTarget(doc,meta)}
const ROW_BUTTON_KEY='.ut-button-group>button'
function boundTarget(doc,meta){const found=findByKey(doc,meta.boundKey)
const parsed=parseElementKey(meta.boundKey)
if(parsed?.selector!==ROW_BUTTON_KEY)return found
if(found&&sameRowButton(meta.label,found))return found
let roots=[]
try{roots=parsed.layer==='global'?[doc?.body??doc]:Array.from(doc?.querySelectorAll?.(LAYERS[parsed.layer])??[])}catch{roots=[]}
for(const root of roots){if(!root||!visible(root))continue
const same=matchesIn(root,ROW_BUTTON_KEY).find((button)=>visible(button)&&sameRowButton(meta.label,button))
if(same)return same}
return null}
export const ROAD_HERE='here'
export const PANEL_SCREENS=Object.freeze([
{root:'.ut-market-search-filters-view',screen:'market',labelKey:'hotkeys.layer.market',section:'AUCTION'},
{root:'.ut-transfer-list-view',screen:'transferList',labelKey:'hotkeys.layer.transferList',section:'TRADE_PILE'},
{root:'.ut-watch-list-view',screen:'targets',labelKey:'hotkeys.layer.targets',section:'WATCH_LIST'},
{root:'.ut-unassigned-view',screen:'unassigned',labelKey:'hotkeys.layer.unassigned',section:'UNASSIGNED'},
{root:'.ut-store-hub-view',screen:'store',labelKey:'hotkeys.layer.store',section:'STORE'},
{root:'.ut-sbc-hub-view',screen:'sbc',labelKey:'hotkeys.layer.sbc',section:'SBC'},
{root:'.ut-objectives-hub',screen:'objectives',labelKey:'hotkeys.screen.objectives',section:'OBJECTIVES'},
{root:'.ut-squad-overview',screen:'activeSquad',labelKey:'hotkeys.screen.activeSquad',section:'ACTIVE_SQUAD'},
{root:'.ut-club-hub-view',screen:'club',labelKey:'hotkeys.layer.club',section:null},
{root:'.TransfersHub',screen:'transfersHub',labelKey:'hotkeys.screen.transfersHub',section:null},
{root:'.ut-squads-hub-view',screen:'squadsHub',labelKey:'hotkeys.screen.squadsHub',section:null},
{root:'.ut-club-search-results-view',screen:'clubResults',labelKey:'hotkeys.screen.clubResults',section:null},
{root:'.ut-sbc-challenges-view',screen:'sbcChallenges',labelKey:'hotkeys.screen.sbcChallenges',section:null},
{root:'.ut-sbc-challenge-details-view',screen:'challenge',labelKey:'hotkeys.layer.challenge',section:null},
{root:'.SBCSquadPanel',screen:'challenge',labelKey:'hotkeys.layer.challenge',section:null},
])
export const HUB_GRID='.grid.layout-hub'
export const HOME_HUB_TILE='.home-hub-transfer-tile'
function has(node,selector){try{return node?.querySelector?.(selector)!=null}catch{return false}}
function upTo(node,selector){try{return node?.closest?.(selector)??null}catch{return null}}
export function roadOfNode(node,doc=null){void doc
for(const entry of PANEL_SCREENS){if(upTo(node,entry.root))return{screen:entry.screen,labelKey:entry.labelKey,section:entry.section}}
const grid=upTo(node,HUB_GRID)
if(grid){if(has(grid,HOME_HUB_TILE))return{screen:'home',labelKey:'hotkeys.screen.home',section:'HOME'}
return{screen:'hub',labelKey:'hotkeys.screen.hub',section:null}}
return{screen:'',labelKey:'hotkeys.layer.global',section:ROAD_HERE}}
export function roadScreenVisible(doc,section){if(typeof section!=='string'||section===''||section===ROAD_HERE)return false
if(section==='HOME'){let grids
try{grids=doc?.querySelectorAll?.(HUB_GRID)}catch{return false}
return Array.from(grids??[]).some((grid)=>has(grid,HOME_HUB_TILE)&&visible(grid))}
return PANEL_SCREENS.some((entry)=>entry.section===section&&screenVisible(doc,entry.root))}
export function roadOfKey(key){const parsed=parseElementKey(key)
if(!parsed)return null
if(parsed.layer==='global')return ROAD_HERE
const entry=PANEL_SCREENS.find((one)=>one.screen===parsed.layer)
return entry?entry.section:ROAD_HERE}
export function elementEntry(key,label,danger=false,road=undefined){const parsed=parseElementKey(key)
const known=road===null||(typeof road==='string'&&road!=='')
return{labelKey:'',label,feature:'hotkeys',defaultCombo:'',layer:parsed?.layer??'global',group:groupOfLayer(parsed?.layer??'global'),boundKey:key,danger:danger===true,road:known?road:roadOfKey(key),roadGuessed:!known}}
export function labelOfNode(node){const kids=node?.children
const mine=(one)=>one?.dataset?.futHotkeyPlaced==='1'
const parts=kids?Array.from(kids).filter((one)=>!mine(one)).map((one)=>String(one?.textContent??'').trim()).filter((one)=>one!==''):[]
const bare=node?.childNodes?Array.from(node.childNodes).filter((one)=>!mine(one)).map((one)=>String(one?.textContent??'')).join(''):String(node?.textContent??'')
const whole=parts.length>0?parts.join(' '):bare
const text=whole.trim().replace(/\s+/g,' ')
if(text!=='')return text.slice(0,40)
const aria=node?.getAttribute?.('aria-label')??node?.getAttribute?.('title')??''
return String(aria).trim().slice(0,40)}
export const DANGER_ZONES=Object.freeze(['.bidOptions','.sbc-button-container','.ut-button-group','.tradeOptions','.fx-strip-go'])
export function looksDangerous(node){return DANGER_ZONES.some((zone)=>{try{return node?.closest?.(zone)!==null&&node?.closest?.(zone)!==undefined}catch{return false}})}
let templateSource=null
const TPL_MENU_MARK='futTplMenu'
export const TPL_MENU_SELECTOR='[data-fut-tpl-menu]'
const TPL_ROW_MARK='futTplRow'
const TPL_FIELD_MARK='futTplField'
const TPL_APPLY_MARK='futTplApply'
const TPL_CANCEL_MARK='futTplCancel'
export function publishTemplateMenu(provider){templateSource=provider??null
return()=>{if(templateSource===provider)templateSource=null}}
export function templateAt(node){if(templateSource===null)return null
const id=templateChipAt(node)
if(id===null)return null
let list=null
try{list=templateSource.sets?.()}catch{return null}
if(!Array.isArray(list))return null
const set=list.find((one)=>String(one?.id??'')===id)
if(!set)return null
return{id,name:String(set.name??'')}}
function templateDoor(name){const door=templateSource?.[name]
return typeof door==='function'?door:null}
export function createBindCapture(deps){const{doc,t,bindings,registry,onBind,onAssign,onUnbind,isActive=()=>true,onError=()=>{},onNotice=()=>{},win=null}=deps
const view=()=>{const w=win??doc?.defaultView??null
return{width:Number(w?.innerWidth)||Number(doc?.documentElement?.clientWidth)||0,height:Number(w?.innerHeight)||Number(doc?.documentElement?.clientHeight)||0}}
let host=null
let pending=null
const close=()=>{host?.remove?.()
host=null
pending=null}
const licensed=()=>{try{return isActive(HOTKEYS_FEATURE)===true}catch(err){onError(err)
return false}}
const guard=()=>{const ok=licensed()
if(!ok&&(pending!==null||host!==null))close()
return ok}
const aimed=(event)=>{const path=event?.composedPath?.()
const first=Array.isArray(path)&&path.length>0?path[0]:event?.target
try{return first?.closest?.(CLICKABLE_SELECTOR)??null}catch{return null}}
const OURS_SELECTOR=`[data-fut-hotkey-capture],[data-fut-logo],[data-fut-head-chip],[data-panel-tile-box],${TPL_MENU_SELECTOR}`
const ours=(node)=>{try{return node?.closest?.(OURS_SELECTOR)!==null}catch{return false}}
function onContextMenu(event){if(!guard())return
const node=aimed(event)
if(!node||ours(node))return
event.preventDefault?.()
event.stopPropagation?.()
try{open(node)}catch(err){onError(err)}}
function holderOf(node,key,table){for(const[action,meta]of Object.entries(table)){if(meta?.boundKey===key&&typeof key==='string')return{action,mode:'element'}}
for(const[action,meta]of Object.entries(table)){if(typeof meta?.press!=='string'||meta.press==='')continue
let target=null
try{target=pressTarget(doc,meta)}catch{target=null}
if(target&&target===node)return{action,mode:'action'}}
return null}
function open(node){if(!guard())return
close()
const template=templateAt(node)
if(template!==null){showMenu(node,template)
return}
openBind(node)}
function openBind(node){if(!guard())return
close()
const table=registry()
const key=elementKey(node,doc)
const holder=holderOf(node,key,table)
if(!key&&!holder)return
const mode=holder?.mode==='action'?'action':'element'
const meta=holder?table[holder.action]:null
const road=mode==='element'?roadOfNode(node,doc):null
if(mode==='element'&&road.section===null){onNotice({key:'hotkeys.bind.noRoad',params:{screen:t(road.labelKey)}})
return}
show({key,node,mode,action:holder?.action??null,road:road?road.section:undefined,
label:mode==='action'?(meta?.label??(meta?.labelKey?t(meta.labelKey):holder.action)):(labelOfNode(node)),
danger:mode==='action'?meta?.danger===true:looksDangerous(node)})}
function openAction(action,anchor=null){if(!guard())return
close()
const meta=registry()[action]
if(!meta||meta.reserved)return
show({key:null,node:anchor,mode:'action',action,
label:meta.label??(meta.labelKey?t(meta.labelKey):action),danger:meta.danger===true})}
function menuRow(key,mark,run){return el(doc,'button',
{class:`${WINDOW_BUTTON_CLASS} fx-hk-menu-row`,text:t(key),
attrs:{type:'button'},dataset:{[TPL_ROW_MARK]:mark},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{run()}catch(err){onError(err)}}}})}
function showTemplate(stage,node,template,title,children){close()
pending={mode:stage,node,template}
ensureControls(doc)
host=modalBox(doc,{mark:TPL_MENU_MARK,value:stage,title,onBack:close},children)
;(doc.body??doc.documentElement)?.appendChild?.(host)
placeNear(node)
return host}
function tell(said){const notice=said?.notice
if(notice&&typeof notice.key==='string')onNotice(notice)
return said?.ok===true}
function showMenu(node,template){const rows=el(doc,'div',{class:'fx-hk-menu'},
[menuRow('hotkeys.tpl.bind','bind',()=>openBind(node)),
menuRow('hotkeys.tpl.rename','rename',()=>showRename(node,template)),
menuRow('hotkeys.tpl.remove','remove',()=>showRemove(node,template))])
return showTemplate('menu',node,template,t('hotkeys.tpl.title',{name:template.name}),[rows])}
function showRename(node,template){const field=el(doc,'input',
{class:'fx-hk-capture-field',
attrs:{type:'text',spellcheck:'false',value:template.name,'aria-label':t('hotkeys.tpl.rename')},
dataset:{[TPL_FIELD_MARK]:'1'},
on:{keydown:(event)=>{event?.stopPropagation?.()
if(event?.key==='Escape'){event.preventDefault?.()
close()
return}
if(event?.key==='Enter'){event.preventDefault?.()
doRename(template,field.value)}}}})
const buttons=modalButtons(doc,[{text:t('hotkeys.tpl.renameOk'),mark:TPL_APPLY_MARK,value:'rename',kind:'primary',on:()=>doRename(template,field.value)},
{text:t('common.cancel'),mark:TPL_CANCEL_MARK,on:close}])
showTemplate('rename',node,template,t('hotkeys.tpl.renameTitle'),
[el(doc,'div',{class:'fx-hk-capture-hint',text:t('hotkeys.tpl.renameHint')}),field,buttons])
field.focus?.()
field.select?.()
return host}
function showRemove(node,template){const buttons=modalButtons(doc,[{text:t('common.cancel'),mark:TPL_CANCEL_MARK,on:close},
{text:t('hotkeys.tpl.removeOk'),mark:TPL_APPLY_MARK,value:'remove',kind:'danger',on:()=>doRemove(template)}])
return showTemplate('remove',node,template,t('hotkeys.tpl.removeTitle'),
[el(doc,'div',{class:'fx-hk-capture-what',text:t('hotkeys.tpl.removeAsk',{name:template.name})}),
el(doc,'div',{class:'fx-hk-capture-hint',text:t('hotkeys.tpl.removeWarn')}),buttons])}
function doRename(template,text){const door=templateDoor('rename')
close()
if(door===null){onNotice({key:'hotkeys.tpl.noDoor',params:{}})
return false}
let said=null
try{said=door(template.id,String(text??''))}catch(err){onError(err)
onNotice({key:'hotkeys.tpl.noDoor',params:{}})
return false}
return tell(said)}
function doRemove(template){const door=templateDoor('remove')
close()
if(door===null){onNotice({key:'hotkeys.tpl.noDoor',params:{}})
return false}
let said=null
try{said=door(template.id)}catch(err){onError(err)
onNotice({key:'hotkeys.tpl.noDoor',params:{}})
return false}
return tell(said)}
function show(target){pending={...target}
ensureControls(doc)
const what=el(doc,'div',{class:'fx-hk-capture-what',text:pending.label||t('hotkeys.bind.unnamed')})
const hint=el(doc,'div',{class:'fx-hk-capture-hint',text:t(pending.danger?'hotkeys.bind.dangerHint':'hotkeys.bind.hint')})
const field=el(doc,'input',{class:'fx-hk-capture-field',attrs:{type:'text',readonly:'readonly',spellcheck:'false'},dataset:{futHotkeyField:'1'},on:{keydown:(keyEvent)=>{keyEvent?.preventDefault?.()
keyEvent?.stopPropagation?.()
try{record(keyEvent,field,status,slot)}catch(err){onError(err)}}}})
const status=el(doc,'div',{class:'fx-hk-capture-status',dataset:{futHotkeyStatus:'1'},text:''})
const slot=el(doc,'div',{class:'fx-hk-capture-slot'})
const buttons=modalButtons(doc,[pending.action?{text:t('hotkeys.bind.clear'),mark:'futHotkeyClear',on:()=>{const action=pending?.action
close()
if(action)onUnbind(action)}}:null,{text:t('common.cancel'),mark:'futHotkeyCancel',on:close}])
host=modalBox(doc,{mark:'futHotkeyCapture',lift:true,title:t('hotkeys.bind.title'),box:pending.danger?'fx-hk-capture-box danger':'fx-hk-capture-box',onBack:close},[what,field,status,slot,hint,buttons])
;(doc.body??doc.documentElement)?.appendChild?.(host)
placeNear(pending.node)
field.focus?.()}
function placeNear(node){const rect=node?.getBoundingClientRect?.()
if(!rect||!host)return
const box=host.querySelector?.('.fx-hk-capture-box')
if(!box)return
const size=box.getBoundingClientRect?.()??{width:0,height:0}
const room=view()
if(!(room.width>0&&room.height>0))return
const at=anchorBox(rect,size,room)
host.dataset.futHotkeyAnchored='1'
host.style.position='fixed'
host.style.inset='0'
host.style.zIndex='2147483000'
box.style.position='fixed'
box.style.width='224px'
box.style.maxWidth='90vw'
box.style.left=`${at.left}px`
box.style.top=`${at.top}px`
box.dataset.futHotkeySide=at.side}
function record(event,field,status,slot){if(!pending)return
if(event?.key==='Escape'){close()
return}
const combo=comboFromEvent(event)
if(combo===''){status.textContent=t('hotkeys.bind.modifierOnly')
return}
field.value=combo
const problem=whyNot(combo,pending)
if(problem){status.textContent=problem.text
offerOverride(slot,problem.override,canonicalCombo(combo))
return}
commit(combo,null)}
function commit(combo,drop){const target=pending
if(!target)return
close()
if(target.mode==='action')onAssign(target.action,combo,drop)
else onBind(target.key,elementEntry(target.key,target.label,target.danger,target.road),combo,drop)}
function offerOverride(slot,override,combo){if(!slot)return
for(const old of[...(slot.children??[])])old.remove?.()
if(!override||combo==='')return
slot.appendChild?.(modalButtons(doc,[{text:t('hotkeys.bind.override'),mark:'futHotkeyOverride',on:()=>{if(!pending)return
const name=override.name
try{commit(combo,override.action)
onNotice({key:'hotkeys.bind.overridden',params:{combo:badgeText(combo),name}})}catch(err){onError(err)}}}]))}
function whyNot(combo,target){const canon=canonicalCombo(combo)
if(canon==='')return{text:t('hotkeys.bind.unreadable')}
const self=target.mode==='action'?target.action:target.key
const table=target.mode==='action'
?registry()
:{...registry(),[target.key]:elementEntry(target.key,target.label,target.danger)}
const map={...bindings()}
delete map[self]
map[self]=canon
const problems=detectConflicts(map,table).problems.filter((one)=>one.action===self)
const first=problems.find((one)=>one.reason!=='duplicate'||liveHere(table[one.conflictsWith]))
if(!first)return null
if(first.reason==='browser-reserved')return{text:t('hotkeys.reserved',{combo:canon})}
if(first.reason==='duplicate'){const busy=table[first.conflictsWith]
const name=busy?.label??(busy?.labelKey?t(busy.labelKey):first.conflictsWith)
return{text:t('hotkeys.bind.taken',{name}),override:{action:first.conflictsWith,name}}}
return{text:t('hotkeys.bind.unreadable')}}
function liveHere(meta){const layer=layerOf(meta)
return layer==='global'||layerVisible(doc,layer)}
const swallow=(event)=>{if(event?.button!==RIGHT_BUTTON)return
if(!isActive(HOTKEYS_FEATURE))return
const node=aimed(event)
if(!node||ours(node))return
event.preventDefault?.()
event.stopPropagation?.()}
const listener=(event)=>{onContextMenu(event)}
doc?.addEventListener?.('contextmenu',listener,true)
for(const type of SWALLOW_TYPES)doc?.addEventListener?.(type,swallow,true)
return{
open,
openAction,close,
refresh(){guard()},
state:()=>(pending?{...pending,node:undefined}:null),dispose(){close()
doc?.removeEventListener?.('contextmenu',listener,true)
for(const type of SWALLOW_TYPES)doc?.removeEventListener?.(type,swallow,true)}}}
