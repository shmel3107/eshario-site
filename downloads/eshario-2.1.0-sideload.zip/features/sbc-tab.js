import{el,clear,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoLink} from '../ui/controls.js'
import{parseRequirements,needOf,COMPARE,REQUIREMENT_KEY} from '../automation/sbc-requirements.js'
import{demandClasses,classCoversCard,classPrice} from '../automation/card-value.js'
import{LADDER_MIN_RATING} from './price-ladder.js'
import{setFactsOf,categoryFactsOf,challengesWithMemory,challengeMemorySize,forgetChallenges,installSetDtoCapture,submittedOf,submittedMemorySize,forgetSubmitted,tileHostOf,tilePartOf,toolbarSlotOf,TILE_ROOT_SELECTOR,TILE_REWARD_SELECTOR,TILE_EXPIRY_SELECTOR} from '../adapter/sbc-hub.js'
import{SBC_COLUMNS_MIN,SBC_COLUMNS_MAX,SBC_COLUMNS_DEFAULT,SBC_PINNED_DEFAULT,SBC_SORTS} from './ui-state.js'
export const SBC_TAB_FEATURE='sbcSolver'
export const TOOLBAR_SELECTOR='[data-fut-sbc-tab]'
export const STRIP_SELECTOR='[data-fut-sbc-strip]'
export const TILE_MARK='futSbcSet'
export const GRID_MARK='futSbcGrid'
export const GRID_SELECTOR='[data-fut-sbc-grid]'
export const COMPACT_MARK='futSbcCompact'
export const COMPACT_SELECTOR='[data-fut-sbc-compact]'
export const COMPACT_FROM=6
export const REWARD_MARK='futSbcReward'
export const REWARD_SELECTOR='[data-fut-sbc-reward]'
export const WHEN_MARK='futSbcWhen'
export const WHEN_SELECTOR='[data-fut-sbc-when]'
export const SOON_SECONDS=24*60*60
const TOOLBAR_STYLESHEET=new URL('../ui/sbc-tab.css',import.meta.url).href
const TOOLBAR_LINK_ID='fut-companion-sbc-tab'
export const SORTS=SBC_SORTS
const SORT_KEYS=Object.freeze({ea:'sbcTab.sort.ea',soonest:'sbcTab.sort.soonest',liked:'sbcTab.sort.liked'})
export const SQUAD_SIZE=11
export const TILE_STALE_MS=10*60*1000
const BLIND_KEYS=Object.freeze(new Set([REQUIREMENT_KEY.CHEMISTRY_POINTS,REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS,REQUIREMENT_KEY.PLAYER_COUNT,REQUIREMENT_KEY.PLAYER_COUNT_COMBINED]))
const isNum=(value)=>typeof value==='number'&&Number.isFinite(value)
export const VOTES_BAD=40
export const VOTES_GOOD=70
export function voteMood(percent){if(!isNum(percent))return null
if(percent<VOTES_BAD)return 'down'
return percent<VOTES_GOOD?'mid':'up'}
const stamp=(value)=>(value===null||value===undefined?'-':Object.values(value).map((one)=>(one===null||one===undefined?'':String(one))).join('/'))
const isColumns=(value)=>Number.isSafeInteger(value)&&value>=SBC_COLUMNS_MIN&&value<=SBC_COLUMNS_MAX
export function squadSizeOf(parsed,eaSize=null){if(Number.isSafeInteger(eaSize)&&eaSize>0&&eaSize<=SQUAD_SIZE)return eaSize
for(const req of Array.isArray(parsed)?parsed:[]){if(req?.key!==REQUIREMENT_KEY.PLAYER_COUNT)continue
const need=needOf(req)
if(Number.isSafeInteger(need)&&need>0&&need<=SQUAD_SIZE)return need}
return SQUAD_SIZE}
export function slotPrice(cls,prices){if(!cls||typeof cls!=='object')return null
return classPrice(cls,prices)}
export function provenFloor(prices){const ladder=prices?.ladder
if(!Array.isArray(ladder))return null
let lowest=null
let best=null
for(const step of ladder){const rating=Number(step?.rating)
if(!Number.isFinite(rating)||!isNum(step?.price))continue
if(lowest===null||rating<lowest)lowest=rating
if(best===null||step.price<best)best=step.price}
if(lowest===null||lowest>LADDER_MIN_RATING)return null
return best}
export function ladderFresh(prices,now){if(!isNum(now))return true
const builtAt=prices?.builtAt
return isNum(builtAt)&&now-builtAt<=TILE_STALE_MS}
export function priceClub(club,prices){const out=[]
for(const card of Array.isArray(club)?club:[]){const rating=Number(card?.rating)
const coins=isNum(rating)?slotPrice({minRating:rating},prices):null
out.push({card,coins:isNum(coins)?coins:null})}
out.sort((a,b)=>{if(a.coins===null)return b.coins===null?0:1
if(b.coins===null)return-1
return a.coins-b.coins})
return out}
export function estimateChallenge(requirements,priced,prices,used=new Set(),eaSize=null){const fail=(reason)=>({ok:false,reason,clubCoins:0,buyCoins:0,buy:0,size:0})
const{requirements:parsed,skipped}=parseRequirements(requirements)
if(skipped>0||parsed.length===0)return fail('unsupported')
const size=squadSizeOf(parsed,eaSize)
const list=Array.isArray(priced)?priced:[]
const demands=[]
for(const one of parsed){if(BLIND_KEYS.has(one?.key))continue
if(one?.key===REQUIREMENT_KEY.TEAM_RATING){if(!Number.isFinite(Number(one?.value)))return fail('unsupported')
demands.push({cls:{minRating:Number(one.value)},need:size,matches:[]})
continue}
if(one?.compare!==COMPARE.GREATER)continue
const[cls]=demandClasses([one])
const need=Number(cls?.slots)
if(!cls||!Number.isSafeInteger(need)||need<=0)return fail('unsupported')
demands.push({cls,need:Math.min(need,size),matches:[]})}
for(let index=0;index<list.length;index+=1){if(used.has(index))continue
for(const demand of demands){
if(demand.matches.length>=size)continue
let covers=false
try{covers=classCoversCard(list[index].card,demand.cls,prices)===true}catch{covers=false}
if(covers)demand.matches.push(index)}}
demands.sort((a,b)=>a.matches.length-b.matches.length)
for(const demand of demands)demand.price=slotPrice(demand.cls,prices)
let room=size
for(const demand of[...demands].sort((a,b)=>{if(a.price===null)return b.price===null?0:-1
if(b.price===null)return 1
return b.price-a.price})){demand.slots=Math.min(demand.need,room)
room-=demand.slots}
let clubCoins=0
let buyCoins=0
let buy=0
let taken=0
for(const demand of demands){const price=demand.price
let need=demand.slots
for(const index of demand.matches){if(need<=0)break
if(used.has(index))continue
const coins=list[index].coins
if(coins===null)break
used.add(index)
clubCoins+=coins
need-=1
taken+=1}
if(need>0){
if(price===null)return fail('no-price')
buy+=need
buyCoins+=price*need
taken+=need}}
const floor=provenFloor(prices)
if(taken<size){let need=size-taken
for(let index=0;index<list.length&&need>0;index+=1){if(used.has(index))continue
const coins=list[index].coins
if(coins===null)break
used.add(index)
clubCoins+=coins
need-=1
taken+=1}
if(need>0){if(floor===null)return fail('no-price')
buy+=need
buyCoins+=floor*need
taken+=need}}
return{ok:true,reason:null,clubCoins,buyCoins,buy,size}}
export function estimateSet(challenges,priced,prices,facts={},now=null){const empty=(kind,reason=null)=>({kind,reason,clubCoins:null,buyCoins:null,buy:0})
if(facts?.complete===true)return empty('done')
if(!Array.isArray(priced))return empty('no-club')
if(!Array.isArray(prices?.ladder)||prices.ladder.length===0)return empty('solver','no-prices')
if(!ladderFresh(prices,now))return empty('solver','stale-prices')
if(!Array.isArray(challenges))return empty('visit')
if(challenges.length===0)return empty('done')
const used=new Set()
let clubCoins=0
let buyCoins=0
let buy=0
for(const challenge of challenges){const one=estimateChallenge(challenge?.requirements,priced,prices,used,challenge?.squadSize??null)
if(!one.ok)return empty('solver',one.reason)
clubCoins+=one.clubCoins
buyCoins+=one.buyCoins
buy+=one.buy}
return{kind:buy>0?'buy':'ok',reason:null,clubCoins,buyCoins,buy}}
export function explainSet(challenges,priced,prices,now=null){const empty=(reason)=>({ok:false,reason,classes:[],clubCoins:0,buyCoins:0,buy:0,line:`разбора нет: ${reason}`})
if(!Array.isArray(challenges))return empty('в набор не заходили')
if(challenges.length===0)return empty('в наборе не осталось несданных испытаний')
if(!Array.isArray(priced))return empty('клуб не прочитан')
if(!Array.isArray(prices?.ladder)||prices.ladder.length===0)return empty('лестница цен не собрана')
const used=new Set()
const byClass=new Map()
let clubCoins=0
let buyCoins=0
let buy=0
for(const challenge of challenges){const before=new Set(used)
const one=estimateChallenge(challenge?.requirements,priced,prices,used,challenge?.squadSize??null)
if(!one.ok)return empty(`испытание не считается (${one.reason})`)
clubCoins+=one.clubCoins
buyCoins+=one.buyCoins
buy+=one.buy
const{requirements:parsed,skipped}=parseRequirements(challenge?.requirements)
if(skipped>0)continue
const size=squadSizeOf(parsed,challenge?.squadSize??null)
const taken=used.size-before.size
const names=[]
for(const req of parsed){if(BLIND_KEYS.has(req?.key))continue
if(req?.key===REQUIREMENT_KEY.TEAM_RATING){names.push({key:`рейтинг≥${req?.value}`,cls:{minRating:Number(req?.value)},slots:size})
continue}
if(req?.compare!==COMPARE.GREATER)continue
const[cls]=demandClasses([req])
if(!cls)continue
names.push({key:`${req?.name??req?.key}:${JSON.stringify(cls).slice(0,40)}`,cls,slots:Math.min(Number(cls.slots)||0,size)})}
for(const part of names){const held=byClass.get(part.key)??{key:part.key,slots:0,price:slotPrice(part.cls,prices),challenges:0}
held.slots+=part.slots
held.challenges+=1
byClass.set(part.key,held)}
const held=byClass.get('ИТОГО ПО ИСПЫТАНИЯМ')??{key:'ИТОГО ПО ИСПЫТАНИЯМ',slots:0,price:null,challenges:0,fromClub:0,bought:0}
held.slots+=size
held.challenges+=1
held.fromClub=(held.fromClub??0)+taken
held.bought=(held.bought??0)+one.buy
byClass.set('ИТОГО ПО ИСПЫТАНИЯМ',held)}
const classes=[...byClass.values()].sort((a,b)=>(b.price??0)*b.slots-(a.price??0)*a.slots)
const line=classes.map((one)=>`${one.key} × ${one.slots} ${one.fromClub===undefined?'просят':'слотов'}${one.price===null?' (цены класса НЕТ)':` по ${one.price}`}${one.fromClub===undefined?'':` · из клуба ${one.fromClub}, куплено ${one.bought}`}`).join(' | ')
const floor=provenFloor(prices)
const age=isNum(now)&&isNum(prices?.builtAt)?Math.round((now-prices.builtAt)/1000):null
const ladder=`лестница: ступеней ${prices.ladder.length}, дно ${floor===null?'НЕ ДОКАЗАНО':floor}, снимку ${age===null?'?':age} с${isNum(now)&&!ladderFresh(prices,now)?' — ПРОТУХ, плитка молчит':''}`
return{ok:true,reason:null,classes,clubCoins,buyCoins,buy,line:`${line} || ${ladder}`}}
export function rewardOf(facts,priceOf=null){const award=Array.isArray(facts?.awards)?facts.awards[0]:null
const plain=(kind,extra={})=>({kind,coins:null,count:null,pending:null,...extra})
if(!award)return plain('none')
if(award.isPack===true)return plain('pack')
if(award.isCoin===true){const coins=isNum(award.value)&&award.value>0?award.value:(isNum(award.count)?award.count:null)
return plain('coins',{coins})}
if(award.isEventToken===true)return plain('token',{count:tokenCount(award)})
if(award.isXP===true)return plain('xp',{count:isNum(award.value)?award.value:null})
if(!award.item)return plain('none')
let answer=null
try{answer=typeof priceOf==='function'?priceOf(award.item):null}catch{answer=null}
if(isNum(answer))return plain('card',{coins:answer})
const pending=answer&&typeof answer.then==='function'?answer:null
return plain('card',{pending})}
function tokenCount(award){if(isNum(award?.value)&&award.value>0)return award.value
return isNum(award?.count)?award.count:null}
export function rewardTint(facts){const award=Array.isArray(facts?.awards)?facts.awards[0]:null
if(!award)return null
return award.sale==='yes'||award.sale==='no'||award.sale==='coins'?award.sale:null}
export function sellsForCoins(facts){const tint=rewardTint(facts)
return tint==='yes'||tint==='coins'}
export function submittedLabel(facts,submitted){if(!submitted)return null
const count=submitted.allTime
return isNum(count)&&count>0?count:null}
export function submittedWhy(facts,submitted){if(!submitted)return 'ответа службы не видели'
if(!isNum(submitted.allTime))return 'поля нет в ответе'
return submitted.allTime>0?'показано':'ни разу не сдавал'}
export function deadlineOf(facts){const ends=isNum(facts?.endsIn)&&facts.endsIn>0?facts.endsIn:null
const refresh=isNum(facts?.refreshIn)&&facts.refreshIn>0?facts.refreshIn:null
if(ends===null&&refresh===null)return null
if(refresh===null)return{seconds:ends,kind:'ends'}
if(ends===null)return{seconds:refresh,kind:'refresh'}
return refresh<ends?{seconds:refresh,kind:'refresh'}:{seconds:ends,kind:'ends'}}
export function expiresSoon(facts){const ends=facts?.endsIn
if(!isNum(ends)||ends<=0)return false
return ends<SOON_SECONDS}
export function matchesSearch(name,query){const needle=typeof query==='string'?query.trim().toLowerCase():''
if(needle==='')return true
return String(name??'').toLowerCase().includes(needle)}
export function visibleRows(rows,filters={}){const out=[]
const hasAward=(facts)=>Array.isArray(facts?.awards)&&facts.awards.length>0
for(const row of Array.isArray(rows)?rows:[]){if(row?.hidden===true&&filters.showHidden!==true)continue
if(!matchesSearch(row?.facts?.name,filters.query))continue
if(filters.hideDone===true&&row?.facts?.complete===true)continue
if(filters.hideUntradeable===true&&hasAward(row?.facts)&&!sellsForCoins(row?.facts))continue
out.push(row)}
return out}
export function tileOrder(rows,sort,showHidden=false){const list=[...(Array.isArray(rows)?rows:[])]
if(sort==='liked'){list.sort((a,b)=>{const left=a.cost?.percent
const right=b.cost?.percent
if(!isNum(left)&&!isNum(right))return a.index-b.index
if(!isNum(left))return 1
if(!isNum(right))return-1
return left===right?a.index-b.index:right-left})}
else if(sort==='soonest'){list.sort((a,b)=>{const leftEnds=expiresSoon(a.facts)
const rightEnds=expiresSoon(b.facts)
if(leftEnds!==rightEnds)return leftEnds?-1:1
if(leftEnds&&rightEnds){const left=a.facts.endsIn
const right=b.facts.endsIn
return left===right?a.index-b.index:left-right}
const left=deadlineOf(a.facts)
const right=deadlineOf(b.facts)
if(left===null&&right===null)return a.index-b.index
if(left===null)return 1
if(right===null)return-1
return left.seconds===right.seconds?a.index-b.index:left.seconds-right.seconds})}
else list.sort((a,b)=>a.index-b.index)
if(showHidden!==true)return list
return[...list.filter((row)=>row.hidden===true),...list.filter((row)=>row.hidden!==true)]}
export function buyShown(estimate,cost){const coins=estimate?.buyCoins
if(!isNum(coins))return null
const whole=cost?.coins
return isNum(whole)&&whole<coins?whole:coins}
export function buyCapped(estimate,cost){const coins=estimate?.buyCoins
const whole=cost?.coins
return isNum(coins)&&isNum(whole)&&whole<coins}
export function verdictLabel(estimate,t,format=(value)=>String(value),cost=null){const kind=estimate?.kind
if(kind==='ok')return t('sbcTab.verdict.ok')
if(kind==='buy')return t('sbcTab.verdict.buy',{coins:format(buyShown(estimate,cost)??0)})
if(kind==='visit')return null
if(kind==='done')return t('sbcTab.verdict.done')
return null}
export function createSbcTab(deps={}){const{doc,t}=deps
const win=deps.win??doc?.defaultView??null
const frame=typeof deps.frame==='function'?deps.frame:(fn)=>{fn()}
const soon=typeof deps.soon==='function'?deps.soon:(fn)=>{const raf=win?.requestAnimationFrame
if(typeof raf!=='function')return frame(fn)
try{raf.call(win,()=>fn())}catch{frame(fn)}}
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>true
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const poolOf=typeof deps.poolOf==='function'?deps.poolOf:null
const pricesOf=typeof deps.pricesOf==='function'?deps.pricesOf:null
const now=typeof deps.now==='function'?deps.now:()=>Date.now()
const rewardPriceOf=typeof deps.rewardPriceOf==='function'?deps.rewardPriceOf:null
const readHidden=typeof deps.hiddenSets==='function'?deps.hiddenSets:null
const writeHidden=typeof deps.setHidden==='function'?deps.setHidden:null
const readView=typeof deps.sbcView==='function'?deps.sbcView:null
const writeView=typeof deps.setSbcView==='function'?deps.setSbcView:null
const formatCoins=typeof deps.formatCoins==='function'?deps.formatCoins:(coins)=>String(Math.round(coins))
const futgg=deps.sbcPrices??null
let dtoCapture={ok:false,reason:'unavailable',dispose(){}}
const ensureSetDtoCapture=()=>{if(dtoCapture.ok)return dtoCapture
try{dtoCapture=installSetDtoCapture(win)}catch(err){onError(err)}
return dtoCapture}
ensureSetDtoCapture()
const filters={query:'',sort:'ea',columns:SBC_COLUMNS_DEFAULT,pinned:SBC_PINNED_DEFAULT,hideDone:true,hideUntradeable:false,showHidden:false}
if(readView!==null){try{const saved=readView()
if(SORTS.includes(saved?.sort))filters.sort=saved.sort
if(isColumns(saved?.columns))filters.columns=saved.columns
if(typeof saved?.pinned==='boolean')filters.pinned=saved.pinned}catch(err){onError(err)}}
const rememberView=(patch)=>{if(writeView===null)return
try{writeView(patch)}catch(err){onError(err)}}
let last=null
let rows=[]
const measured=new WeakMap()
const queue=new Set()
let draining=false
let epoch=0
let mark=''
const armed=new Set()
const stats={captures:0,frames:0,measured:0,drawn:0,skipped:0,orders:0}
const wakes={capture:0,visible:0,priceArrived:0,costArrived:0}
const SCROLL_HUMAN=Object.freeze(['wheel','keydown','touchmove'])
const SCROLL_GRAB=Object.freeze(['pointerdown','mousedown'])
const SCROLL_RELEASE=Object.freeze(['pointerup','mouseup','pointercancel'])
const CATEGORY_BAR_SELECTOR='.ea-filter-bar-view'
const CATEGORY_KEYS=Object.freeze(['Enter',' ','Spacebar'])
const CATEGORY_PRESS_MS=1000
const PARK_MS=10*60*1000
const CLAMP_MIN_PX=600
const CLAMP_PART=0.4
const ASSIGN_MS=100
const HUMAN_MS=250
const GRAB_MS=15*1000
const CLAMP_ROW_MAX=2
const CLAMP_CALM_MS=1500
let scroller=null
let point=0
let humanAt=0
let pending=null
let parked=null
let wantTop=false
let categoryAt=0
let categorySpent=0
let seenIds=''
let seenCategory=null
let capturedAt=0
let settle=null
let assignAt=0
let grabbed=false
let grabAt=0
let clampWant=null
let clampRow=0
let clampAt=0
const scrolls={found:false,node:null,how:null,drops:0,restored:0,fromPark:0,resets:0,otherList:0,human:0,kept:0,noScroller:0,parks:0,settled:0,lag:null,last:null,
byHand:0,handless:0,
clampDrops:0,clampRestored:0,clampLate:0,clampGave:0,
clampWhy:{assign:0,human:0,war:0,gone:0,fix:0},clampLast:null,
why:{first:0,category:0,relist:0,same:0,unknown:0},lastList:null}
let observer=null
const Observer=win?.IntersectionObserver
if(typeof Observer==='function'){try{observer=new Observer((entries)=>{for(const entry of entries){if(entry?.isIntersecting===false)continue
enqueue(entry?.target,'visible')}
drain()})}catch{observer=null}}
const connected=(node)=>{try{return node?.isConnected!==false}catch{return false}}
const activeSafe=()=>{try{return isActive(SBC_TAB_FEATURE)===true}catch{return false}}
const nameOf=(node)=>{if(!node)return null
try{const cls=String(node.className??'').trim().split(/\s+/).filter(Boolean).slice(0,2).join('.')
return String(node.tagName??'?').toLowerCase()+(cls===''?'':`.${cls}`)}catch{return '?'}}
const nowMs=()=>{try{const value=win?.performance?.now?.()
return isNum(value)?value:Date.now()}catch{return Date.now()}}
const topOf=(node)=>{try{const value=Number(node?.scrollTop)
return Number.isFinite(value)?value:null}catch{return null}}
const sizeOf=(node,name)=>{try{const value=Number(node?.[name])
return Number.isFinite(value)?Math.round(value):null}catch{return null}}
const maxTop=(node)=>{const sh=sizeOf(node,'scrollHeight')
const ch=sizeOf(node,'clientHeight')
return sh===null||ch===null?null:Math.max(0,sh-ch)}
function putTop(node,value){assignAt=nowMs()
try{node.scrollTop=value
return true}catch(err){onError(err)
return false}}
function findScroller(){for(const start of[toolbarOf(),last?.box??null,last?.root??null]){const found=scrollerAbove(start)
if(found!==null)return found}
const page=doc?.scrollingElement??doc?.documentElement??null
if(page!==null&&overflowOf(page)>1){const how=canScroll(page)
if(how!==null){scrolls.how=how
return page}}
return null}
function scrollerAbove(start){let node=start
let guard=0
while(node&&guard<14){guard+=1
if(overflowOf(node)>1){const how=canScroll(node)
if(how!==null){scrolls.how=how
return node}}
node=node.parentNode??null}
return null}
const overflowOf=(node)=>{try{const over=Number(node.scrollHeight)-Number(node.clientHeight)
return Number.isFinite(over)?over:0}catch{return 0}}
const canScroll=(node)=>{if(scrollsItself(node))return 'style'
return acceptsScroll(node)?'assign':null}
const scrollsItself=(node)=>{let style=null
try{style=win?.getComputedStyle?.(node)??null}catch{style=null}
if(style===null)return true
const flow=String(style.overflowY??style.overflow??'')
return flow==='auto'||flow==='scroll'||flow==='overlay'}
function acceptsScroll(node){const before=topOf(node)
if(before===null)return false
const want=before>0?before-1:1
if(!putTop(node,want))return false
const got=topOf(node)
putTop(node,before)
return got!==null&&got!==before}
const onScroll=()=>{const at=topOf(scroller)
if(at===null)return
if(trapped!==null&&at<point-1)noteTrap('event',point,at,null)
const from=point
point=at
if(from-at>=CLAMP_MIN_PX)noteClamp(from,at)}
const onHuman=(event)=>{humanAt=nowMs()
clampRow=0
noteCategoryPress(event)}
const onGrab=(event)=>{grabbed=true
grabAt=nowMs()
humanAt=grabAt
clampRow=0
noteCategoryPress(event)}
function pressedCategory(node){if(!node||last===null)return false
let bar=null
try{bar=typeof node.closest==='function'?node.closest(CATEGORY_BAR_SELECTOR):null}catch{bar=null}
if(!bar)return false
let up=bar
let guard=0
while(up&&guard<14){if(up===last.root)return true
try{up=up.parentNode??null}catch{return false}
guard+=1}
return false}
function noteCategoryPress(event){let type=null
let node=null
try{type=String(event?.type??'')}catch{type=''}
try{node=event?.target??null}catch{node=null}
if(type==='keydown'){let key=null
try{key=String(event?.key??'')}catch{key=null}
if(key===null||!CATEGORY_KEYS.includes(key))return}
else if(type!=='pointerdown'&&type!=='mousedown')return
if(!pressedCategory(node))return
categoryAt=nowMs()}
function tookCategoryPress(){if(categoryAt===0||categoryAt<=categorySpent)return false
if(nowMs()-categoryAt>CATEGORY_PRESS_MS)return false
categorySpent=categoryAt
return true}
const onRelease=()=>{grabbed=false
humanAt=nowMs()}
const held=()=>grabbed&&nowMs()-grabAt<=GRAB_MS
function noteClamp(from,at){const box=scroller
const ch=sizeOf(box,'clientHeight')
const sh=sizeOf(box,'scrollHeight')
if(ch!==null&&from-at<Math.round(ch*CLAMP_PART))return
scrolls.clampDrops+=1
const now=nowMs()
const why=assignAt>0&&now-assignAt<=ASSIGN_MS?'assign'
:held()||(humanAt>0&&now-humanAt<=HUMAN_MS)?'human'
:clampRow>=CLAMP_ROW_MAX?'war'
:sh!==null&&ch!==null&&from>Math.max(0,sh-ch)+1?'gone'
:'fix'
scrolls.clampWhy[why]+=1
scrolls.clampLast={why,from:Math.round(from),to:Math.round(at),sh,ch,back:null,lagMs:null,
sinceAssignMs:assignAt===0?null:Math.round(now-assignAt)}
if(why!=='fix')return
const had=clampWant!==null
clampWant={point:had?Math.max(clampWant.point,from):from,at:now}
if(!had)soon(()=>{try{clampFix()}catch(err){onError(err)}})}
function clampFix(){const want=clampWant
clampWant=null
if(want===null)return false
if(held()||humanAt>want.at){scrolls.clampLate+=1
return false}
if(assignAt>want.at){scrolls.clampLate+=1
return false}
const box=scroller
if(box===null||!connected(box))return false
const at=topOf(box)
if(at===null||at>=want.point)return false
const ceiling=maxTop(box)
if(ceiling!==null&&want.point>ceiling+1){scrolls.clampGave+=1
clampRow=0
return false}
putTop(box,want.point)
const after=topOf(box)
if(after===null||after<=at)return false
scrolls.clampRestored+=1
const now=nowMs()
clampRow=clampAt>0&&now-clampAt<=CLAMP_CALM_MS?clampRow+1:1
clampAt=now
point=after
scrolls.clampLast={...scrolls.clampLast,back:Math.round(after),lagMs:Math.round(now-want.at)}
return true}
function eachHuman(fn){fn(SCROLL_HUMAN,onHuman)
fn(SCROLL_GRAB,onGrab)
fn(SCROLL_RELEASE,onRelease)}
function watchScroll(){if(scroller!==null&&connected(scroller))return scroller
releaseScroll()
const found=findScroller()
if(found===null)return null
scroller=found
try{found.addEventListener('scroll',onScroll,{passive:true})}catch{try{found.addEventListener('scroll',onScroll)}catch{/* без слушателя точку помнить нечем */}}
eachHuman((types,handler)=>{for(const type of types){try{doc.addEventListener(type,handler,{capture:true,passive:true})}catch{try{doc.addEventListener(type,handler,true)}catch{/* без этого возврат просто осторожнее */}}}})
scrolls.found=true
scrolls.node=nameOf(found)
point=topOf(found)??0
return found}
function releaseScroll(){const node=scroller
releaseTrap()
scroller=null
scrolls.found=false
grabbed=false
clampWant=null
clampRow=0
clampAt=0
assignAt=0
categoryAt=0
categorySpent=0
if(node===null)return
try{node.removeEventListener('scroll',onScroll,{passive:true})}catch{/* снимаем вторым способом */}
try{node.removeEventListener('scroll',onScroll)}catch{/* уже снят */}
eachHuman((types,handler)=>{for(const type of types){try{doc.removeEventListener(type,handler,{capture:true})}catch{/* снимаем вторым способом */}
try{doc.removeEventListener(type,handler,true)}catch{/* уже снят */}}})}
function parkPoint(){const key=listKey()
parked=point>0&&key!==''?{point,key,at:nowMs()}:null
if(parked!==null)scrolls.parks+=1}
const listKey=()=>(seenCategory??seenIds)
function noteList(cat,ids,changed,relist,tiles,byHand){const why=cat.key===null?'unknown'
:seenCategory===null?'first'
:changed?'category'
:relist?'relist'
:'same'
scrolls.why[why]+=1
if(why==='category')scrolls[byHand?'byHand':'handless']+=1
scrolls.lastList={why,name:cat.name,key:cat.key,was:seenCategory,tiles,
ids:seenIds===''?'first':ids===seenIds?'same':'changed',
byHand:why==='category'?byHand===true:null}}
function restoreScroll(){const want=pending
pending=null
const toTop=wantTop
wantTop=false
if(want!==null&&want.relist===true)scrolls.otherList+=1
if(toTop)return resetScroll()
if(want===null)return false
if(want.same!==true)return false
if(humanAt>want.at){scrolls.human+=1
return false}
const box=watchScroll()
if(box===null){scrolls.noScroller+=1
return false}
const at=topOf(box)
if(at===null||at>=want.point){scrolls.kept+=1
return false}
scrolls.drops+=1
putTop(box,want.point)
const after=topOf(box)
if(after!==null&&after>at){scrolls.restored+=1
if(want.from==='park')scrolls.fromPark+=1}
scrolls.lag=Math.round(nowMs()-capturedAt)
scrolls.last={from:want.from??'live',lost:Math.round(at),wanted:Math.round(want.point),after:after===null?null:Math.round(after),lagMs:scrolls.lag}
if(after!==null)point=after
settle=after!==null&&after<want.point-1?{point:want.point,at:nowMs()}:null
return true}
function settleScroll(){const want=settle
settle=null
if(want===null)return false
if(humanAt>want.at)return false
const box=scroller
if(box===null)return false
const at=topOf(box)
if(at===null||at>=want.point-1)return false
putTop(box,want.point)
const after=topOf(box)
if(after!==null&&after>at){scrolls.settled+=1
point=after}
return true}
function resetScroll(){const box=watchScroll()
if(box===null){scrolls.noScroller+=1
return false}
const at=topOf(box)
if(at===null||at<=0)return false
putTop(box,0)
const after=topOf(box)
scrolls.resets+=1
scrolls.lag=Math.round(nowMs()-capturedAt)
scrolls.last={from:'category',lost:Math.round(at),wanted:0,after:after===null?null:Math.round(after),lagMs:scrolls.lag}
if(after!==null)point=after
return true}
const TRAP_MAX=24
let trapped=null
let trapDesc=null
const traps=[]
function noteTrap(kind,from,to,stack){if(traps.length>=TRAP_MAX)traps.shift()
traps.push({kind,at:Math.round(nowMs()),from:Math.round(Number(from)||0),to:Math.round(Number(to)||0),stack})}
function stackTop(){try{throw new Error('trap')}catch(err){return String(err?.stack??'').split('\n').slice(2,5).map((line)=>line.trim()).join(' | ')}}
function setTrap(on){if(on!==true){releaseTrap()
return}
if(trapped!==null)return
const box=watchScroll()
if(box===null)return
let desc=null
try{desc=Object.getOwnPropertyDescriptor(win?.Element?.prototype??{},'scrollTop')}catch{desc=null}
if(!desc||typeof desc.set!=='function'||typeof desc.get!=='function')return
try{Object.defineProperty(box,'scrollTop',{configurable:true,
get(){return desc.get.call(this)},
set(value){try{noteTrap('assign',desc.get.call(this),value,stackTop())}catch{/* диагностика не имеет права ронять присваивание */}
desc.set.call(this,value)}})
trapped=box
trapDesc=desc}catch(err){onError(err)
trapped=null
trapDesc=null}}
function releaseTrap(){const box=trapped
trapped=null
trapDesc=null
if(box===null)return
try{delete box.scrollTop}catch(err){onError(err)}}
function scrollChain(){const out=[]
let node=toolbarOf()??last?.box??last?.root??null
while(node&&out.length<14){out.push(chainRow(nameOf(node),node))
node=node.parentNode??null}
const page=doc?.scrollingElement??doc?.documentElement??null
if(page!==null)out.push(chainRow('СТРАНИЦА',page))
return out}
function chainRow(name,node){const at=topOf(node)
let flow=null
try{const style=win?.getComputedStyle?.(node)??null
flow=style===null?null:String(style.overflowY??style.overflow??'')}catch{flow=null}
const num=(value)=>{const one=Number(value)
return Number.isFinite(one)?Math.round(one):null}
return{node:name,sh:num(node?.scrollHeight),ch:num(node?.clientHeight),top:at===null?null:Math.round(at),overflow:flow,mine:node===scroller}}
const hiddenIds=()=>{if(readHidden===null)return new Set()
try{const list=readHidden()
return new Set((Array.isArray(list)?list:[]).map((one)=>String(one)))}catch(err){onError(err)
return new Set()}}
const poolPeek=()=>{if(poolOf===null)return{players:null,generation:0}
try{const value=poolOf()
return{players:Array.isArray(value?.players)?value.players:null,generation:isNum(value?.generation)?value.generation:0}}catch(err){onError(err)
return{players:null,generation:0}}}
const pricesPeek=()=>{if(pricesOf===null)return null
try{return pricesOf()??null}catch(err){onError(err)
return null}}
let clubCache={key:null,priced:null}
const pricedClub=()=>{const{players,generation}=poolPeek()
const prices=pricesPeek()
const key=`${generation}|${players===null?'null':players.length}|${prices?.builtAt??''}`
if(clubCache.key===key)return{priced:clubCache.priced,prices}
const priced=players===null?null:priceClub(players,prices)
clubCache={key,priced}
return{priced,prices}}
function enqueue(root,why='capture'){if(!root)return
if(!rows.some((one)=>one.root===root))return
if(Object.hasOwn(wakes,why))wakes[why]+=1
queue.add(root)}
function drain(){if(draining||queue.size===0)return
draining=true
frame(step)}
function step(){stats.frames+=1
const next=queue.values().next()
if(next.done){draining=false
return}
const root=next.value
queue.delete(root)
try{measureRow(root)}catch(err){onError(err)}
if(queue.size===0){draining=false
try{paint()}catch(err){onError(err)}
return}
frame(step)}
function measureRow(root){const row=rows.find((one)=>one.root===root)
if(!row||!connected(root))return
const{priced,prices}=pricedClub()
const estimate=estimateSet(row.challenges,priced,prices,row.facts,now())
const reward=rewardOf(row.facts,rewardPriceOf)
if(reward.pending&&row.facts.id!==null&&!armed.has(row.facts.id)){armed.add(row.facts.id)
reward.pending.then(()=>{measured.delete(root)
enqueue(root,'priceArrived')
drain()}).catch(()=>{})}
row.estimate=estimate
row.reward=reward
measured.set(root,{generation:pricedClub().priced===null?-1:0})
stats.measured+=1}
function forgetScreen(){parkPoint()
releaseScroll()
pending=null
settle=null
wantTop=false
point=0
seenIds=''}
function paint(){if(last===null)return false
const hostRoot=last.root
if(!connected(hostRoot)){last=null
rows=[]
forgetScreen()
return false}
if(!activeSafe()){dropAll(doc)
return false}
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,TOOLBAR_STYLESHEET,TOOLBAR_LINK_ID)
const hidden=hiddenIds()
for(const row of rows){row.hidden=row.facts.id!==null&&hidden.has(String(row.facts.id))
row.cost=priceOf(row.facts)}
const shown=visibleRows(rows,filters)
const ordered=tileOrder(shown,filters.sort,filters.showHidden)
const done=rows.filter((one)=>one.facts.complete===true).length
const signature=[epoch,filters.query,filters.sort,filters.columns,filters.pinned?1:0,filters.hideDone?1:0,filters.hideUntradeable?1:0,filters.showHidden?1:0,rows.length,done,ordered.map((row)=>{const when=deadlineOf(row.facts)
return`${row.facts.id}:${row.estimate?.kind??'?'}:${buyShown(row.estimate,row.cost)??''}:${row.reward?.kind??'?'}:${row.hidden?1:0}:${rewardTint(row.facts)??'-'}:${expiresSoon(row.facts)?1:0}:${submittedLabel(row.facts,row.submitted)??'-'}:${stamp(row.cost)}:${when===null?'':`${when.kind}${Math.floor(when.seconds/60)}`}`}).join(',')].join('|')
if(signature===mark&&connected(toolbarOf())){stats.skipped+=1
return false}
mark=signature
markGrid()
paintToolbar({shown:ordered.length,total:rows.length,done,hidden:rows.filter((one)=>one.hidden).length})
for(const row of rows){paintStrip(row)
paintTile(row)
const visible=ordered.includes(row)
setDisplay(row.root,visible)
if(row.root?.dataset)row.root.dataset[TILE_MARK]=String(row.facts.id??'')}
reorder(ordered)
stats.drawn+=1
return true}
const toolbarOf=()=>{try{return last?.root?.querySelector?.(TOOLBAR_SELECTOR)??null}catch{return null}}
function headerState(){const bar=toolbarOf()
if(bar===null)return{found:false,position:null,zIndex:null,background:null,over:null}
let style=null
try{style=win?.getComputedStyle?.(bar)??null}catch{style=null}
let rect=null
try{rect=bar.getBoundingClientRect?.()??null}catch{rect=null}
let over=null
try{if(rect&&rect.height>0&&typeof doc.elementsFromPoint==='function'){const list=Array.from(doc.elementsFromPoint(Math.round(rect.left+rect.width/2),Math.round(rect.top+rect.height/2)))
const at=list.findIndex((node)=>node===bar||bar.contains?.(node)===true)
over=at<0?list.slice(0,3).map(nameOf):list.slice(0,at).map(nameOf)}}catch{over=null}
return{found:true,position:style?.position??null,zIndex:style?.zIndex??null,
background:style?.backgroundColor??null,opacity:style?.opacity??null,
top:rect?Math.round(rect.top):null,height:rect?Math.round(rect.height):null,
over}}
function markGrid(){const box=last?.box??null
if(!box?.dataset)return
if(filters.columns<=SBC_COLUMNS_MIN){unmarkGrid(box)
return}
if(box.dataset[GRID_MARK]!=='1')box.dataset[GRID_MARK]='1'
const compact=filters.columns>=COMPACT_FROM?'1':'0'
if(box.dataset[COMPACT_MARK]!==compact)box.dataset[COMPACT_MARK]=compact
try{if(box.style?.getPropertyValue?.('--fut-sbc-cols')!==String(filters.columns))box.style?.setProperty?.('--fut-sbc-cols',String(filters.columns))}catch{/* переменная — удобство, а не условие работы */}}
function unmarkGrid(node){if(node?.dataset&&node.dataset[GRID_MARK]!==undefined)delete node.dataset[GRID_MARK]
if(node?.dataset&&node.dataset[COMPACT_MARK]!==undefined)delete node.dataset[COMPACT_MARK]
try{node?.style?.removeProperty?.('--fut-sbc-cols')}catch{/* нечего снимать */}}
function gridState(){const box=last?.box??null
if(!box)return{marked:false,boxWidth:null,display:null,columns:null,tileWidth:null,directChildren:null}
const marked=box.dataset?.[GRID_MARK]==='1'
let style=null
try{style=win?.getComputedStyle?.(box)??null}catch{style=null}
let tile=null
let tileWidth=null
let directChildren=null
try{tile=rows[0]?.root??null
tileWidth=tile?.clientWidth??null
directChildren=tile===null?null:tile.parentNode===box}catch{/* числа не обязаны быть */}
return{marked,wanted:filters.columns,compact:box.dataset?.[COMPACT_MARK]==='1',native:filters.columns<=SBC_COLUMNS_MIN,boxWidth:box.clientWidth??null,display:style?.display??null,
columns:typeof style?.gridTemplateColumns==='string'?style.gridTemplateColumns:null,tileWidth,directChildren}}
function setDisplay(node,visible){if(!node?.style)return
node.style.display=visible?'':'none'}
function reorder(ordered){const box=last?.box??null
if(!box||typeof box.appendChild!=='function')return
const current=[]
for(const node of box.children??[]){if(rows.some((one)=>one.root===node))current.push(node)}
const wanted=ordered.map((row)=>row.root)
if(current.length===wanted.length&&current.every((node,index)=>node===wanted[index]))return
for(const node of wanted){try{box.appendChild(node)}catch(err){onError(err)}}
for(const row of rows){if(wanted.includes(row.root))continue
try{box.appendChild(row.root)}catch(err){onError(err)}}
stats.orders+=1}
let parts=null
function paintToolbar(counts){const slot=toolbarSlotOf(last.root)
if(slot===null)return
let node=toolbarOf()
if(!node||!connected(node)){node=el(doc,'div',{class:'fx-bar fut-sbc-tab',dataset:{futSbcTab:'1'}})
parts=buildToolbar(node)
try{slot.parent.insertBefore(node,slot.before)}catch(err){onError(err)
parts=null
return}}
if(parts===null||parts.node!==node){clear(node)
parts=buildToolbar(node)}
updateToolbar(counts)}
function buildToolbar(node){
node.appendChild(logoLink(doc))
const search=el(doc,'input',{class:'fx-search fut-sbc-tab__search',
attrs:{type:'search',autocomplete:'off',spellcheck:'false'}})
search.value=filters.query
search.addEventListener('input',()=>{filters.query=String(search.value??'')
schedulePaint()})
node.appendChild(search)
const sort=el(doc,'select',{class:'fut-sbc-tab__sort'})
const options={}
for(const key of SORTS){const option=el(doc,'option',{attrs:{value:key}})
if(key===filters.sort)option.selected=true
options[key]=option
sort.appendChild(option)}
sort.addEventListener('change',()=>{filters.sort=SORTS.includes(sort.value)?sort.value:'ea'
rememberView({sort:filters.sort})
schedulePaint()})
node.appendChild(sort)
const toggles={hideDone:toggle('hideDone'),hideUntradeable:toggle('hideUntradeable'),showHidden:toggle('showHidden')}
for(const key of['hideDone','hideUntradeable','showHidden'])node.appendChild(toggles[key])
node.appendChild(el(doc,'span',{class:'fut-sbc-tab__spacer'}))
const columnsBox=el(doc,'span',{class:'fut-sbc-tab__cols'})
const columnsLabel=el(doc,'span',{class:'fut-sbc-tab__cols-label'})
const columns=el(doc,'select',{class:'fut-sbc-tab__sort fut-sbc-tab__cols-pick'})
const columnOptions={}
for(let value=SBC_COLUMNS_MIN;value<=SBC_COLUMNS_MAX;value+=1){const option=el(doc,'option',{text:String(value),attrs:{value:String(value)}})
if(value===filters.columns)option.selected=true
columnOptions[value]=option
columns.appendChild(option)}
columns.addEventListener('change',()=>{const picked=Number(columns.value)
if(!isColumns(picked))return
filters.columns=picked
rememberView({columns:picked})
schedulePaint()})
columnsBox.appendChild(columnsLabel)
columnsBox.appendChild(columns)
node.appendChild(columnsBox)
const count=el(doc,'span',{class:'fut-sbc-tab__count'})
node.appendChild(count)
const empty=el(doc,'span',{class:'fut-sbc-tab__empty',dataset:{on:'0'}})
node.appendChild(empty)
const pin=pinButton()
if(pin!==null)node.appendChild(pin)
return{node,search,sort,options,toggles,columns,columnsLabel,count,empty,pin}}
function pinButton(){if(writeView===null)return null
const node=el(doc,'button',{class:'fx-action fx-action-square fut-sbc-tab__pin',text:'📌',attrs:{type:'button'},dataset:{on:filters.pinned?'1':'0'}})
for(const type of['pointerdown','mousedown','mouseup','click']){node.addEventListener(type,(event)=>{event.stopPropagation()
if(type!=='click')return
filters.pinned=filters.pinned!==true
rememberView({pinned:filters.pinned})
schedulePaint()})}
return node}
function updateToolbar(counts){if(parts===null)return
const{search,sort,options,toggles,columns,columnsLabel,count,empty,pin}=parts
if(parts.node?.dataset){const mark=filters.pinned?'1':'0'
if(parts.node.dataset.futSbcPinned!==mark)parts.node.dataset.futSbcPinned=mark}
if(pin){pin.dataset.on=filters.pinned?'1':'0'
pin.setAttribute('aria-pressed',filters.pinned?'true':'false')
pin.setAttribute('title',t(filters.pinned?'sbcTab.pinOn':'sbcTab.pinOff'))
pin.setAttribute('aria-label',t(filters.pinned?'sbcTab.pinOn':'sbcTab.pinOff'))}
search.setAttribute('placeholder',t('sbcTab.search'))
search.setAttribute('aria-label',t('sbcTab.search'))
if(String(search.value??'')!==filters.query)search.value=filters.query
sort.setAttribute('aria-label',t('sbcTab.sort'))
for(const key of SORTS){options[key].textContent=t(SORT_KEYS[key])
if(sort.value!==filters.sort&&key===filters.sort)options[key].selected=true}
if(sort.value!==filters.sort)sort.value=filters.sort
sort.setAttribute('title',filters.sort==='soonest'?t('sbcTab.hint.soonest'):t('sbcTab.sort'))
toggles.hideDone.textContent=t('sbcTab.hideDone')
toggles.hideUntradeable.textContent=t('sbcTab.hideUntradeable')
toggles.showHidden.textContent=t('sbcTab.hidden',{count:counts.hidden})
for(const key of['hideDone','hideUntradeable','showHidden'])toggles[key].dataset.on=filters[key]===true?'1':'0'
columnsLabel.textContent=t('sbcTab.columns')
columns.setAttribute('aria-label',t('sbcTab.columns'))
if(Number(columns.value)!==filters.columns)columns.value=String(filters.columns)
count.textContent=`${t('sbcTab.progress',{done:counts.done,total:counts.total})} · ${t('sbcTab.shown',{shown:counts.shown,total:counts.total})}`
empty.textContent=counts.shown===0?t('sbcTab.empty'):''
empty.dataset.on=counts.shown===0?'1':'0'}
function toggle(field){const node=el(doc,'button',{class:'fx-action fut-sbc-tab__toggle',attrs:{type:'button'},dataset:{on:'0'}})
node.addEventListener('click',(event)=>{event.stopPropagation()
filters[field]=filters[field]!==true
schedulePaint()})
return node}
function schedulePaint(){mark=''
frame(()=>{try{paint()}catch(err){onError(err)}})}
function askPrices(){if(futgg===null||typeof futgg.load!=='function')return
let request=null
try{request=futgg.load()}catch(err){onError(err)
return}
if(!request||typeof request.then!=='function')return
request.then(()=>{
if(last===null)return
wakes.costArrived+=1
schedulePaint()},(err)=>{onError(err)})}
function paintStrip(row){const host=tileHostOf(row.root)
if(host===null)return
let strip=null
try{strip=row.root.querySelector?.(STRIP_SELECTOR)??null}catch{strip=null}
if(!strip||!connected(strip)){strip=el(doc,'div',{class:'fut-sbc-strip',dataset:{futSbcStrip:'1'}})
try{host.appendChild(strip)}catch(err){onError(err)
return}}
clear(strip)
const estimate=row.estimate
const top=el(doc,'div',{class:'fut-sbc-strip__line'})
strip.appendChild(top)
const said=row.cost
if(isNum(said?.percent))top.appendChild(el(doc,'span',{class:'fut-sbc-strip__votes',text:t('sbcTab.votes',{percent:said.percent}),attrs:{title:t('sbcTab.votes.hint',{votes:formatCoins(said.votes??0)})},dataset:{mood:voteMood(said.percent)}}))
if(isNum(said?.coins))top.appendChild(el(doc,'span',{class:'fut-sbc-strip__cost',text:t('sbcTab.cost',{coins:formatCoins(said.coins)}),attrs:{title:t('sbcTab.cost.hint')},dataset:{known:'1'}}))
else if(said!==null&&said!==undefined)top.appendChild(el(doc,'span',{class:'fut-sbc-strip__cost',text:t('sbcTab.cost.none'),attrs:{title:t('sbcTab.cost.none.hint')},dataset:{known:'0'}}))
const verdict=verdictLabel(estimate,t,formatCoins,said)
if(verdict!==null)top.appendChild(el(doc,'span',{class:'fut-sbc-strip__verdict',text:verdict,attrs:{title:buyCapped(estimate,said)?`${t('sbcTab.verdict.capped')} · ${t('sbcTab.estimate')}`:t('sbcTab.estimate')},dataset:{verdict:estimate?.kind??'solver'}}))
const acts=el(doc,'span',{class:'fut-sbc-strip__acts'})
top.appendChild(acts)
const done=submittedLabel(row.facts,row.submitted)
if(done!==null)acts.appendChild(el(doc,'span',{class:'fut-sbc-strip__times',text:t('sbcTab.submitted',{count:done})}))
const eye=el(doc,'button',{class:'fx-action fx-action-square fut-sbc-strip__eye',text:row.hidden?'🙈':'👁',attrs:{type:'button',title:row.hidden?t('sbcTab.unhide'):t('sbcTab.hide')},dataset:{hidden:row.hidden?'1':'0'}})
for(const type of['pointerdown','mousedown','mouseup','click']){eye.addEventListener(type,(event)=>{event.stopPropagation()
if(type!=='click')return
if(writeHidden===null||row.facts.id===null)return
try{writeHidden(row.facts.id,!row.hidden)}catch(err){onError(err)}
schedulePaint()})}
acts.appendChild(eye)
}
function pickRow(name){if(typeof name!=='string'||name.trim()==='')return null
const needle=name.trim().toLowerCase()
const row=rows.find((one)=>String(one.facts?.name??'').toLowerCase().includes(needle))
if(row===undefined)return{found:false,name}
const label=submittedLabel(row.facts,row.submitted)
return{found:true,name:row.facts.name,id:row.facts.id,windowed:row.facts.windowed===true,repeats:row.facts.repeats,
raw:row.submitted,label:label===null?null:`за всё время ${label}`,
why:submittedWhy(row.facts,row.submitted),cost:row.cost??priceOf(row.facts),
spend:spendOf(row)}}
function spendOf(row){const{priced,prices}=pricedClub()
let out=null
try{out=explainSet(row?.challenges,priced,prices,now())}catch(err){onError(err)
return null}
const shown=buyShown(row?.estimate,row?.cost)
return{...out,
shownBuy:shown,capped:buyCapped(row?.estimate,row?.cost),
line:`${out.line} || разбор: заменить карты клуба обошлось бы в ~${out.clubCoins}, докупить ~${out.buyCoins} (${out.buy} карт) | на плитке ${shown}${buyCapped(row?.estimate,row?.cost)?' (упёрлось в потолок)':''}`}}
function priceOf(facts){if(futgg===null||typeof futgg.peek!=='function')return null
try{return futgg.peek(facts?.id)}catch(err){onError(err)
return null}}
function paintTile(row){const rewardLine=tilePartOf(row.root,TILE_REWARD_SELECTOR)
if(rewardLine?.dataset){const tint=rewardTint(row.facts)
if(tint===null)delete rewardLine.dataset[REWARD_MARK]
else rewardLine.dataset[REWARD_MARK]=tint}
const expiry=tilePartOf(row.root,TILE_EXPIRY_SELECTOR)
if(expiry?.dataset){if(expiresSoon(row.facts))expiry.dataset[WHEN_MARK]='soon'
else delete expiry.dataset[WHEN_MARK]}}
return{
apply(capture){if(!capture?.root)return false
stats.captures+=1
ensureSetDtoCapture()
if(!activeSafe()){dropAll(doc)
last=null
rows=[]
return false}
const arrived=last===null||last.root!==capture.root
last={root:capture.root,box:capture.box??null}
rows=[]
queue.clear()
let index=0
for(const tile of Array.isArray(capture.tiles)?capture.tiles:[]){if(!tile?.root)continue
const facts=setFactsOf(tile.set)
const known=challengesWithMemory(tile.set,facts)
rows.push({index,root:tile.root,facts,challenges:known.challenges,challengesFrom:known.from,submitted:submittedOf(facts.id),cost:null,estimate:{kind:'visit',reason:null,clubCoins:null,buyCoins:null,buy:0},reward:rewardOf(facts,null),hidden:false})
index+=1}
mark=''
capturedAt=nowMs()
const ids=rows.map((row)=>row.facts.id).join(',')
const cat=categoryFactsOf(capture.category)
const key=cat.key??ids
const changed=cat.key!==null&&seenCategory!==null&&cat.key!==seenCategory
const relist=!changed&&seenIds!==''&&ids!==seenIds
const byHand=changed&&tookCategoryPress()
noteList(cat,ids,changed,relist,rows.length,byHand)
if(point>0)pending={point,same:!byHand,relist,at:nowMs(),from:'live'}
else if(parked!==null&&parked.key===key&&nowMs()-parked.at<=PARK_MS)pending={point:parked.point,same:true,relist,at:nowMs(),from:'park'}
else pending=null
wantTop=byHand
if(byHand){clampRow=0
if(clampWant!==null){clampWant=null
scrolls.clampLate+=1}}
parked=null
seenIds=ids
if(cat.key!==null)seenCategory=cat.key
if(arrived)askPrices()
for(const row of rows){if(observer)try{observer.observe(row.root)}catch{}
if(!observer)enqueue(row.root,'capture')}
drain()
soon(()=>{try{watchScroll()
restoreScroll()}catch(err){onError(err)}})
frame(()=>{try{paint()}catch(err){onError(err)}
try{watchScroll()
settleScroll()}catch(err){onError(err)}})
return true},
refresh(){
ensureSetDtoCapture()
if(last===null)return false
if(!connected(last.root)){
last=null
rows=[]
queue.clear()
forgetScreen()
return false}
try{return paint()}catch(err){onError(err)
return false}},
forgetParked(){const had=parked!==null
parked=null
return had},
relabel(){epoch+=1
mark=''
return this.refresh()},
state(opts){if(opts&&Object.hasOwn(opts,'trap'))setTrap(opts.trap===true)
const pick=pickRow(opts?.set)
const{players,generation}=poolPeek()
const prices=pricesPeek()
return{screen:last!==null,pick,tiles:rows.length,queued:queue.size,filters:{...filters},hidden:rows.filter((one)=>one.hidden).length,club:players===null?null:players.length,generation,ladder:Array.isArray(prices?.ladder)?prices.ladder.length:null,verdicts:rows.reduce((acc,row)=>{const kind=row.estimate?.kind??'?'
acc[kind]=(acc[kind]??0)+1
return acc},{}),
requirements:rows.reduce((acc,row)=>{const from=row.challengesFrom??'none'
acc[from]=(acc[from]??0)+1
return acc},{}),remembered:challengeMemorySize(),
squads:(()=>{const out={ea:0,guessed:0,sizes:{}}
for(const row of rows)for(const one of Array.isArray(row.challenges)?row.challenges:[]){const size=one?.squadSize
if(Number.isSafeInteger(size)&&size>0){out.ea+=1
out.sizes[size]=(out.sizes[size]??0)+1}
else out.guessed+=1}
return out})(),
submitted:rows.reduce((acc,row)=>{const why=submittedWhy(row.facts,row.submitted)
acc[why]=(acc[why]??0)+1
return acc},{}),shownTimes:rows.map((row)=>submittedLabel(row.facts,row.submitted)).filter((one)=>one!==null),
setDto:{ok:dtoCapture.ok===true,reason:dtoCapture.reason??null,sets:submittedMemorySize()},
verdictWhy:rows.reduce((acc,row)=>{const why=row.estimate?.kind==='solver'?(row.estimate?.reason??'жадный путь не сошёлся'):(row.estimate?.kind??'?')
acc[why]=(acc[why]??0)+1
return acc},{}),
cost:{...(typeof futgg?.state==='function'?futgg.state():{}),shown:rows.filter((row)=>isNum(priceOf(row.facts)?.coins)).length,voted:rows.filter((row)=>isNum(priceOf(row.facts)?.percent)).length,unknown:rows.filter((row)=>priceOf(row.facts)===null).length},
wakes:{...wakes},
grid:gridState(),
scroll:{...scrolls,why:{...scrolls.why},clampWhy:{...scrolls.clampWhy},point:Math.round(point),
parked:parked===null?null:{point:Math.round(parked.point),age:Math.round(nowMs()-parked.at)},
chain:scrollChain(),trap:trapped!==null,trapHits:traps.slice(-8)},
header:headerState(),
observer:observer!==null,styles:Boolean(doc?.getElementById?.(TOOLBAR_LINK_ID)),epoch,...stats}},
dispose(){try{observer?.disconnect?.()}catch{}
observer=null
queue.clear()
releaseScroll()
pending=null
settle=null
wantTop=false
point=0
parked=null
seenIds=''
seenCategory=null
const kept=rows
const box=last?.box??null
rows=[]
last=null
parts=null
for(const row of kept)setDisplay(row.root,true)
unmarkGrid(box)
forgetChallenges()
forgetSubmitted()
try{dtoCapture.dispose()}catch(err){onError(err)}
dtoCapture={ok:false,reason:'unavailable',dispose(){}}
try{futgg?.forget?.()}catch(err){onError(err)}
dropAll(doc)}}}
export function dropAll(doc){let count=0
for(const node of doc?.querySelectorAll?.(TOOLBAR_SELECTOR)??[]){node.remove?.()
count+=1}
for(const node of doc?.querySelectorAll?.(STRIP_SELECTOR)??[]){node.remove?.()
count+=1}
for(const node of doc?.querySelectorAll?.(TILE_ROOT_SELECTOR)??[]){if(node?.style)node.style.display=''
if(node?.dataset)delete node.dataset[TILE_MARK]}
for(const node of doc?.querySelectorAll?.(REWARD_SELECTOR)??[]){if(node?.dataset)delete node.dataset[REWARD_MARK]}
for(const node of doc?.querySelectorAll?.(WHEN_SELECTOR)??[]){if(node?.dataset)delete node.dataset[WHEN_MARK]}
for(const node of doc?.querySelectorAll?.(GRID_SELECTOR)??[]){if(node?.dataset)delete node.dataset[GRID_MARK]}
for(const node of doc?.querySelectorAll?.(COMPACT_SELECTOR)??[]){if(node?.dataset)delete node.dataset[COMPACT_MARK]}
return count}
