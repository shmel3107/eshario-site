export const LADDER_MIN_RATING=75
export const LADDER_MAX_RATING=94
export function ladderRatings(){const out=[]
for(let rating=LADDER_MIN_RATING;rating<=LADDER_MAX_RATING;rating+=1)out.push(rating)
return out}
export function defsByRating(entries){const ratings={}
const seen=new Set()
let total=0
if(!entries||typeof entries[Symbol.iterator]!=='function')return{ratings,total}
for(const entry of entries){const id=entry?.id
const rating=entry?.rating
if(!Number.isSafeInteger(id)||id<=0)continue
if(!Number.isSafeInteger(rating)||rating<LADDER_MIN_RATING||rating>LADDER_MAX_RATING)continue
if(seen.has(id))continue
seen.add(id)
const key=String(rating)
if(ratings[key]===undefined)ratings[key]=[]
ratings[key].push(id)
total+=1}
return{ratings,total}}
export const LADDER_TTL_MS=60_000
export const SOURCE_CLOSE_MS=60_000
const isNum=(value)=>typeof value==='number'&&Number.isFinite(value)
const isPrice=(value)=>isNum(value)&&value>0
async function priceOrNull(priceOf,id){try{const price=await priceOf(id)
return isPrice(price)?price:null}catch{return null}}
export function stepAttrs(record){if(!record||typeof record!=='object')return null
const attrs={}
for(const key of['leagueId','nationId','teamId']){const value=record[key]
if(Number.isSafeInteger(value)&&value>0)attrs[key]=value}
const positions=Array.isArray(record.positions)?record.positions:[]
if(positions.length>0&&(record.positionMode===2||record.positionMode===1)){attrs.possiblePositions=[...positions]
if(record.positionMode===1)attrs.positionsEstimate=true}
return Object.keys(attrs).length>0?attrs:null}
export const STEP_PICKS=24
export function cheapestPicks(found,lookup){return found.sort((a,b)=>a.price-b.price).slice(0,STEP_PICKS).map((one)=>{let attrs=null
if(lookup!==null){try{attrs=stepAttrs(lookup(one.id))}catch{attrs=null}}
return{id:one.id,price:one.price,attrs}})}
export const STEP_SAMPLE=20
export function stepPriceIndex(count,available){const have=Number.isSafeInteger(available)&&available>0?available:1
const n=Number.isFinite(count)&&count>0?count:1
return Math.min(Math.max(1,Math.round(n/STEP_SAMPLE)),have)-1}
export function stepFrom(rating,picks,count){const list=Array.isArray(picks)?picks:[]
if(list.length===0)return null
const total=Number.isFinite(count)&&count>list.length?Math.floor(count):list.length
const pick=list[stepPriceIndex(total,list.length)]
return{rating,price:pick.price,id:pick.id,attrs:pick.attrs??null,count:total,picks:list}}
export async function buildLadder(entries,priceOf,attrsOf){const ladder=[]
const lookup=typeof attrsOf==='function'?attrsOf:null
let priced=0
if(typeof priceOf!=='function')return{ladder,total:0,priced}
const{ratings,total}=defsByRating(entries)
for(const rating of ladderRatings()){const ids=ratings[String(rating)]
if(!Array.isArray(ids))continue
const found=[]
for(const id of ids){const price=await priceOrNull(priceOf,id)
if(price===null)continue
priced+=1
found.push({id,price})}
if(found.length===0)continue
const step=stepFrom(rating,cheapestPicks(found,lookup),found.length)
if(step!==null)ladder.push(step)}
return{ladder,total,priced}}
export async function buildRarityPrices(groups,priceOf){const out={}
if(typeof priceOf!=='function'||!Array.isArray(groups))return out
for(const group of groups){if(!Number.isSafeInteger(group?.rarity)||!Array.isArray(group?.ids))continue
let best=null
for(const id of group.ids){const price=await priceOrNull(priceOf,id)
if(price!==null&&(best===null||price<best))best=price}
if(best!==null)out[String(group.rarity)]=best}
return out}
export function createSolvePriceReader(deps={}){const{source,keyOf,clock}=deps
if(typeof source!=='function')throw new Error('price-ladder: нужен источник цены')
if(typeof keyOf!=='function')throw new Error('price-ladder: нужен ключ цены')
if(!clock||typeof clock.now!=='function')throw new Error('price-ladder: нужны часы (правило 6 NIGHT_BRIEF)')
const closeMs=isNum(deps.closeMs)&&deps.closeMs>0?deps.closeMs:SOURCE_CLOSE_MS
let closedUntil=0
let retries=0
let closes=0
const attempt=async(key)=>{let found
try{found=await source(key)}catch{return{ok:false,price:null}}
return found?.ok===true?{ok:true,price:isPrice(found.price)?found.price:null}:{ok:false,price:null}}
return{async priceOf(id){const key=keyOf(id)
if(key===null||key===undefined)return null
if(clock.now()<closedUntil)return undefined
let got=await attempt(key)
if(!got.ok){retries+=1
got=await attempt(key)
if(!got.ok){closedUntil=clock.now()+closeMs
closes+=1
return undefined}}
return got.price},
state:()=>({closedUntil,retries,closes,closed:clock.now()<closedUntil})}}
export function createLadderService(deps){const{players,priceOf,clock}=deps??{}
if(!players||typeof players.list!=='function')throw new Error('price-ladder: нужен справочник игроков')
if(typeof priceOf!=='function')throw new Error('price-ladder: нужна функция цены')
if(!clock||typeof clock.now!=='function')throw new Error('price-ladder: нужны часы (правило 6 NIGHT_BRIEF)')
const rarities=deps.rarities&&typeof deps.rarities.read==='function'?deps.rarities:null
const attrsOf=typeof deps.attrsOf==='function'?deps.attrsOf:undefined
const ttlMs=isNum(deps.ttlMs)&&deps.ttlMs>0?deps.ttlMs:LADDER_TTL_MS
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>true
const onRebuild=typeof deps.onRebuild==='function'?deps.onRebuild:null
const quarantine=deps.quarantine&&typeof deps.quarantine.guardSteps==='function'?deps.quarantine:null
let cached=null
let building=null
let generation=0
let stamp=null
let lastRaw=null
const build=async()=>{
const prev=lastRaw
let entries=[]
try{entries=players.list()}catch{entries=[]}
const result=await buildLadder(entries,priceOf,attrsOf)
if(result.ladder.length===0){
cached=null
return null}
let byRarity={}
if(rarities!==null){let groups=[]
try{groups=await rarities.read()}catch{groups=[]}
byRarity=await buildRarityPrices(groups,priceOf)}
lastRaw=result.ladder
const ladder=quarantine===null?result.ladder:quarantine.guardSteps('ladder',result.ladder)
if(quarantine!==null&&typeof quarantine.guardPrices==='function')byRarity=quarantine.guardPrices('byRarity',byRarity)
cached={ladder,byRarity,builtAt:clock.now(),total:result.total,priced:result.priced}
const fresh=stampOf(ladder,byRarity)
if(fresh!==stamp){stamp=fresh
generation+=1}
if(onRebuild!==null){try{onRebuild(prev,result.ladder)}catch{/* см. выше */}}
return cached}
return{
async read(opts={}){if(!isActive())return null
if(opts?.force!==true&&cached!==null&&clock.now()-cached.builtAt<ttlMs)return cached
if(building)return building
building=build().finally(()=>{building=null})
return building},
generation(){return generation}}}
function stampOf(ladder,byRarity){let out=''
for(const step of ladder){let picks=0
for(const one of Array.isArray(step?.picks)?step.picks:[])picks+=one.price
out+=`${step.rating}:${step.price}:${step.id}:${picks}|`}
for(const[rarity,price]of Object.entries(byRarity??{}))out+=`${rarity}=${price},`
return out}
