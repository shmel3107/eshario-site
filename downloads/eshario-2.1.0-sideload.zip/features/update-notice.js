import{createBridgeClient} from '../bridge/page-client.js'
import{createI18n} from '../i18n/index.js'
import{el} from '../ui/dom.js'
export const UPDATE_METHOD='update.check'
export const UPDATE_BRIDGE_PREFIX='upd'
export const UPDATE_TICK_MS=3_600_000
export const UPDATE_SITE_ORIGIN='https://eshario.com'
const LINE_SELECTOR='[data-fut-update-line="1"]'
const LINES_CAP=32
const rooms=new WeakMap()
const translators=new Map()
function translatorFor(locale){const key=typeof locale==='string'?locale:''
let t=translators.get(key)
if(t===undefined){t=createI18n({locale:key}).t
translators.set(key,t)}
return t}
export function viewOf(answer){if(!answer||answer.ok!==true||answer.show!==true)return null
if(typeof answer.latest!=='string'||!/^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(answer.latest))return null
if(typeof answer.download!=='string')return null
let url
try{url=new URL(answer.download)}catch{return null}
if(url.protocol!=='https:'||url.origin!==UPDATE_SITE_ORIGIN||url.username!==''||url.password!=='')return null
return{latest:answer.latest,download:url.href}}
function roomOf(win,deps){let room=rooms.get(win)
if(room!==undefined)return room
room={win,ask:typeof deps.ask==='function'?deps.ask:null,answer:null,asks:0,error:null,started:false,
timer:null,lines:new Set(),places:new Map(),seen:new WeakSet(),t:new WeakMap(),
setInterval:typeof deps.setInterval==='function'?deps.setInterval:win.setInterval?.bind(win)}
rooms.set(win,room)
return room}
export function ensureUpdateNotice(win,deps={}){if(!win)return null
const room=roomOf(win,deps??{})
if(room.started)return room
room.started=true
if(room.ask===null){try{const client=createBridgeClient(win,{prefix:UPDATE_BRIDGE_PREFIX})
room.ask=(params)=>client.request(UPDATE_METHOD,params)}catch(err){room.error=String(err?.message??err)
return room}}
attachInstrument(room)
void check(room,false)
try{if(typeof room.setInterval==='function'){room.timer=room.setInterval(()=>{void check(room,false)},UPDATE_TICK_MS)
room.timer?.unref?.()}}catch(err){room.error=String(err?.message??err)}
return room}
async function check(room,force){room.asks+=1
try{const answer=await room.ask(force?{force:true}:{})
room.answer=answer&&typeof answer==='object'?answer:null
room.error=null}catch(err){
room.error=String(err?.message??err)}
paintAll(room)
return report(room)}
function paintLine(room,node){const view=viewOf(room?.answer)
if(view===null){if(node.hidden!==true)node.hidden=true
return}
const t=room.t.get(node)??translatorFor('')
const text=t('update.line',{version:view.latest})
if(node.textContent!==text)node.textContent=text
if(node.getAttribute('href')!==view.download)node.setAttribute('href',view.download)
if(node.hidden!==false)node.hidden=false}
function paintAll(room){for(const node of[...room.lines]){if(node.isConnected===true)room.seen.add(node)
else if(room.seen.has(node)){room.lines.delete(node)
continue}
paintLine(room,node)}
while(room.lines.size>LINES_CAP)room.lines.delete(room.lines.values().next().value)
for(const[root,opts]of[...room.places]){if(root.isConnected===true)room.seen.add(root)
else if(room.seen.has(root)){room.places.delete(root)
continue}
syncPlace(room,root,opts)}
while(room.places.size>LINES_CAP)room.places.delete(room.places.keys().next().value)}
const stop=(event)=>{event?.stopPropagation?.()}
export function updateLine(doc,opts={}){const node=el(doc,'a',{class:'fx-update-line',dataset:{futUpdateLine:'1'},
attrs:{target:'_blank',rel:'noopener noreferrer'},on:{pointerdown:stop,mousedown:stop,click:stop}})
node.hidden=true
const room=bind(node,doc,opts)
if(room!==null)paintLine(room,node)
return node}
function bind(node,doc,opts){const win=opts?.win??doc?.defaultView??null
if(!win)return null
const room=ensureUpdateNotice(win,opts?.deps??{})
if(room===null)return null
room.t.set(node,typeof opts?.t==='function'?opts.t:translatorFor(opts?.locale))
room.lines.add(node)
return room}
export function placeUpdateLine(root,opts){if(!root||typeof root.appendChild!=='function')return null
const win=opts?.win??opts?.doc?.defaultView??null
if(!win)return null
const room=ensureUpdateNotice(win,opts?.deps??{})
if(room===null)return null
room.places.set(root,opts)
return syncPlace(room,root,opts)}
function syncPlace(room,root,opts){const found=root.querySelector?.(LINE_SELECTOR)??null
if(viewOf(room.answer)===null){if(found!==null)found.remove?.()
return null}
const t=typeof opts?.t==='function'?opts.t:translatorFor(opts?.locale)
if(found!==null){room.t.set(found,t)
paintLine(room,found)
return found}
if(typeof opts?.onShow==='function')opts.onShow()
const node=el(opts.doc,'a',{class:'fx-update-line',dataset:{futUpdateLine:'1'},
attrs:{target:'_blank',rel:'noopener noreferrer'},on:{pointerdown:stop,mousedown:stop,click:stop}})
room.t.set(node,t)
paintLine(room,node)
root.appendChild(node)
return node}
function report(room){const view=viewOf(room.answer)
const answer=room.answer??{}
return{asks:room.asks,show:view!==null,latest:typeof answer.latest==='string'?answer.latest:null,
own:typeof answer.own==='string'?answer.own:null,sideload:answer.sideload===true,
download:view?.download??null,state:answer.state??null,
lines:[...room.lines].filter((node)=>node.isConnected===true).length,
places:[...room.places.keys()].filter((root)=>root.isConnected===true).length,error:room.error}}
function attachInstrument(room){try{const box=room.win.__eshario
if(box&&typeof box==='object'&&typeof box.update!=='function'){box.update=(what)=>(what==='check'?check(room,true):report(room))}}catch{/* ручки не будет, строка всё равно живёт */}}
