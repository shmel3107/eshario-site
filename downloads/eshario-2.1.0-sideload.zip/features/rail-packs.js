import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{installPackRewardCapture} from '../adapter/game-rewards.js'
import{STORE_GRID_FEATURE} from './store-grid.js'
import{askDayBudget} from './day-budget.js'
const RAIL_STYLESHEET=new URL('../ui/home-hub.css',import.meta.url).href
const RAIL_LINK_ID='fut-companion-home-hub'
export const RAIL_PACKS_CLASS='fx-rail-packs'
export const RAIL_PACKS_COOLDOWN_MS=30_000
export const RAIL_PACKS_RETRY_MS=Object.freeze([6_000,30_000])
export const RAIL_PACKS_SETTLE_MS=8_000
export const RAIL_PACKS_GHOST_MAX=20
export const RAIL_PACKS_FEATURE=STORE_GRID_FEATURE
export function countPacks(capture){if(capture?.myPacks!==true)return null
const tiles=Array.isArray(capture.tiles)?capture.tiles:[]
const packs=[]
for(const tile of tiles){if(typeof tile?.tradable!=='boolean'||!Number.isSafeInteger(tile?.id))return null
packs.push({id:tile.id,tradable:tile.tradable})}
return packs}
export function splitOf(packs){if(!Array.isArray(packs))return null
let tradable=0
let untradable=0
for(const pack of packs){if(typeof pack?.tradable!=='boolean')return null
if(pack.tradable)tradable+=1
else untradable+=1}
return{tradable,untradable}}
export function railPacksView(mirror,live,explained=0,ghosts=[]){const split=splitOf(mirror)
if(split===null)return{show:false,reason:'no-mirror',stale:false,tradable:0,untradable:0,ghosts:0}
const real=split.tradable+split.untradable
const owed=Number.isSafeInteger(explained)&&explained>0?explained:0
const made=Array.isArray(ghosts)?ghosts:[]
const room=Number.isSafeInteger(live)?Math.max(0,live-real-owed):made.length
const counted=Math.min(made.length,room)
let tradable=split.tradable
let untradable=split.untradable
for(let at=0;at<counted;at+=1){if(made[at]?.tradable===true)tradable+=1
else untradable+=1}
const known=real+counted
const stale=Number.isSafeInteger(live)&&live-known!==owed
if(known===0)return{show:false,reason:'no-packs',stale,tradable:0,untradable:0,ghosts:0}
return{show:true,reason:null,stale,tradable,untradable,ghosts:counted}}
export function railPacksSettled(view){return view?.reason!=='no-mirror'&&view?.stale!==true}
export function createRailPacks(deps={}){const doc=deps.doc
if(!doc||typeof doc.createElement!=='function'){throw new Error('rail-packs: нужен документ')}
const t=typeof deps.t==='function'?deps.t:(key)=>key
const button=typeof deps.button==='function'?deps.button:()=>null
const live=typeof deps.live==='function'?deps.live:()=>null
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const fetchSplit=typeof deps.fetch==='function'?deps.fetch:null
const budget=deps.budget??null
const now=typeof deps.now==='function'?deps.now:null
const memory=deps.memory??null
let mirror=null
const counts={captures:0,shown:0,hidden:0,loads:0,refused:0,failed:0,opened:0,asked:0,arrived:0,unknownColor:0,quenched:0}
let lastReason=null
let ghosts=[]
let ghostsShown=0
let arrivals={ok:false,reason:'unavailable',dispose(){}}
let lastStale=false
let loading=false
let loadedAt=null
let deadEnd=null
let staleSince=null
let settleTimer=null
let memoryUse='pending'
let drift=0
function knownNow(){return Array.isArray(mirror)?mirror.length:null}
function viewNow(){return railPacksView(mirror,live(),drift,ghosts)}
function quench(tradable){if(ghosts.length===0)return false
const at=typeof tradable==='boolean'?ghosts.findIndex((one)=>one.tradable===tradable):0
if(at<0)return false
ghosts=ghosts.slice(0,at).concat(ghosts.slice(at+1))
counts.quenched+=1
return true}
function forgetGhosts(){if(ghosts.length===0)return
counts.quenched+=ghosts.length
ghosts=[]}
function quenchByList(before,after){if(ghosts.length===0)return
const seen=new Set(Array.isArray(before)?before.map((one)=>one.id):[])
for(const pack of after){if(ghosts.length===0)break
if(!seen.has(pack.id))quench(pack.tradable)}}
function armArrivals(){if(arrivals.ok)return
let view=null
try{view=doc.defaultView??null}catch{view=null}
if(view===null)return
try{arrivals=installPackRewardCapture(view,(note)=>{try{notePackArrived(note)}catch(err){onError(err)}})}catch(err){onError(err)}}
function tuneDrift(){const total=live()
const known=knownNow()
if(total===null||known===null)return
const diff=total-known
if(diff<drift)drift=diff>0?diff:0}
let restoreDone=false
function restore(){if(restoreDone)return false
if(memory===null||typeof memory.read!=='function'){memoryUse='off'
restoreDone=true
return false}
const total=live()
if(total===null)return false
restoreDone=true
let saved=null
try{saved=memory.read()}catch(err){onError(err)
memoryUse='failed'
return false}
const split=splitOf(Array.isArray(saved)?saved:null)
if(split===null||saved.length===0){memoryUse='empty'
return false}
if(split.tradable+split.untradable!==total){memoryUse='stale'
return false}
mirror=saved.map((one)=>({id:one.id,tradable:one.tradable}))
memoryUse='used'
return true}
function remember(){if(memory===null||typeof memory.write!=='function'||!Array.isArray(mirror))return
try{memory.write(mirror)}catch(err){onError(err)}}
function nodeIn(root){const found=root.querySelector?.(`[data-fut-rail-packs="1"]`)??null
if(found!==null)return found
try{ensureTheme(doc)
ensureStylesheet(doc,RAIL_STYLESHEET,RAIL_LINK_ID)}catch(err){onError(err)}
const node=el(doc,'div',{class:RAIL_PACKS_CLASS,dataset:{futRailPacks:'1'}},[
el(doc,'div',{class:'fx-rail-packs-yes'}),
el(doc,'div',{class:'fx-rail-packs-no'})])
root.appendChild(node)
return node}
function refresh(){try{if(isActive(RAIL_PACKS_FEATURE)!==true){drop()
return{show:false,reason:'locked'}}
const root=button()
if(!root||typeof root.appendChild!=='function'){lastReason='no-button'
return{show:false,reason:'no-button'}}
armArrivals()
if(mirror===null)restore()
tuneDrift()
const view=viewNow()
lastReason=view.reason
lastStale=view.stale===true
ghostsShown=view.ghosts
if(view.reason==='no-mirror'){staleSince=null
ask()
wake(nextLook())}
else if(view.stale===true){settle()
wake(nextLook())}
else staleSince=null
if(!view.show){counts.hidden+=1
drop()
return view}
const node=nodeIn(root)
write(node.querySelector('.fx-rail-packs-yes'),String(view.tradable))
write(node.querySelector('.fx-rail-packs-no'),String(view.untradable))
const title=t('railPacks.title',{tradable:view.tradable,untradable:view.untradable})
if(node.title!==title)node.title=title
counts.shown+=1
return view}catch(err){onError(err)
return{show:false,reason:'failed'}}}
function write(node,text){if(node&&node.textContent!==text)node.textContent=text}
function drop(){try{const root=button()
const node=root?.querySelector?.('[data-fut-rail-packs="1"]')??null
if(node?.remove)node.remove()}catch(err){onError(err)}}
function nextLook(){if(fetchSplit===null||now===null)return null
const total=live()
if(total===null)return null
if(staleSince!==null){const left=RAIL_PACKS_SETTLE_MS-(now()-staleSince)
if(left>0)return left}
if(deadEnd!==null&&deadEnd.live===total){if(deadEnd.tries>RAIL_PACKS_RETRY_MS.length)return null
const left=RAIL_PACKS_RETRY_MS[deadEnd.tries-1]-(now()-deadEnd.at)
if(left>0)return left}
else if(loadedAt!==null){const left=stepOf(null)-(now()-loadedAt)
if(left>0)return left}
return null}
function stepOf(tries){return tries===null?RAIL_PACKS_RETRY_MS[0]:RAIL_PACKS_RETRY_MS[tries-1]}
function wake(ms){if(settleTimer!==null||!Number.isFinite(ms)||ms===null)return
const view=doc.defaultView
if(!view||typeof view.setTimeout!=='function')return
settleTimer=view.setTimeout(()=>{settleTimer=null
try{refresh()}catch(err){onError(err)}},Math.max(250,Math.ceil(ms)+100))}
function settle(){if(now===null)return false
if(staleSince===null){staleSince=now()
return false}
if(now()-staleSince<RAIL_PACKS_SETTLE_MS)return false
return ask()}
function ask(){if(fetchSplit===null||now===null)return false
const total=live()
if(total===null)return false
let after=stepOf(null)
if(deadEnd!==null&&deadEnd.live===total){if(deadEnd.tries>RAIL_PACKS_RETRY_MS.length)return false
after=stepOf(deadEnd.tries)
if(now()-deadEnd.at<after)return false}
counts.asked+=1
void load(after).then((out)=>{if(out?.ok!==true&&out?.reason!=='failed')return
if(railPacksSettled(viewNow())){deadEnd=null
return}
const tries=deadEnd!==null&&deadEnd.live===total?deadEnd.tries+1:1
deadEnd={live:total,tries,at:now()}}).catch(onError)
return true}
const LIST_CALLS=1
async function load(after=null){if(fetchSplit===null)return{ok:false,reason:'unavailable'}
if(loading)return{ok:false,reason:'busy'}
try{if(isActive(RAIL_PACKS_FEATURE)!==true)return{ok:false,reason:'locked'}
const total=live()
if(total===null)return{ok:false,reason:'no-guard'}
if(mirror===null&&restore()&&railPacksSettled(viewNow())){refresh()
return{ok:false,reason:'remembered'}}
if(total===0&&!Array.isArray(mirror)){mirror=[]
refresh()
return{ok:false,reason:'no-packs'}}
if(railPacksSettled(viewNow()))return{ok:false,reason:'fresh'}
const wait=Number.isSafeInteger(after)?after:RAIL_PACKS_COOLDOWN_MS
if(loadedAt!==null&&now!==null&&now()-loadedAt<wait)return{ok:false,reason:'cooldown'}
loading=true
const stop=await askDayBudget(budget,LIST_CALLS)
if(stop!==null){counts.refused+=1
return{ok:false,reason:stop}}
counts.loads+=1
const openedBefore=counts.opened
const split=await fetchSplit()
if(now!==null)loadedAt=now()
if(counts.opened!==openedBefore)return{ok:false,reason:'outdated'}
const before=mirror
mirror=Array.isArray(split?.packs)?split.packs:[]
quenchByList(before,mirror)
remember()
refresh()
return{ok:true,reason:null,...splitOf(mirror)}}catch(err){counts.failed+=1
if(now!==null)loadedAt=now()
onError(err)
return{ok:false,reason:'failed'}}finally{loading=false}}
function notePackArrived(note){try{if(isActive(RAIL_PACKS_FEATURE)!==true)return{ok:false,reason:'locked'}
const count=(value)=>(Number.isSafeInteger(value)&&value>0?value:0)
const yes=count(note?.tradable)
const no=count(note?.untradable)
const mute=count(note?.unknown)
counts.arrived+=1
counts.unknownColor+=mute
if(yes+no===0){refresh()
return{ok:false,reason:'no-color'}}
const born=[]
for(let at=0;at<yes;at+=1)born.push({tradable:true})
for(let at=0;at<no;at+=1)born.push({tradable:false})
ghosts=ghosts.concat(born)
if(ghosts.length>RAIL_PACKS_GHOST_MAX)ghosts=ghosts.slice(ghosts.length-RAIL_PACKS_GHOST_MAX)
deadEnd=null
staleSince=null
const view=refresh()
return{ok:true,reason:null,tradable:view?.tradable??0,untradable:view?.untradable??0,ghosts:ghosts.length}}catch(err){onError(err)
return{ok:false,reason:'failed'}}}
return{refresh,drop,load,notePackArrived,
apply(capture){try{const counted=countPacks(capture)
if(counted===null)return{ok:false,reason:'not-my-packs'}
mirror=counted
forgetGhosts()
remember()
deadEnd=null
staleSince=null
counts.captures+=1
refresh()
return{ok:true,reason:null,...splitOf(mirror)}}catch(err){onError(err)
return{ok:false,reason:'failed'}}},
noteOpened(packId){if(!Array.isArray(mirror)||!Number.isSafeInteger(packId))return{ok:false,reason:'no-mirror'}
const at=mirror.findIndex((one)=>one.id===packId)
if(at<0){if(!quench(null))return{ok:false,reason:'unknown-pack'}
drift+=1
deadEnd=null
staleSince=null
counts.opened+=1
refresh()
return{ok:true,reason:'ghost',...splitOf(mirror)}}
mirror=mirror.slice(0,at).concat(mirror.slice(at+1))
remember()
drift+=1
deadEnd=null
staleSince=null
counts.opened+=1
refresh()
return{ok:true,reason:null,...splitOf(mirror)}},
relabel(){refresh()},
state:()=>({feature:RAIL_PACKS_FEATURE,
show:(()=>{const view=viewNow()
return view.show===true?{tradable:view.tradable,untradable:view.untradable}:null})(),
mirror:splitOf(mirror),known:Array.isArray(mirror)?mirror.length:0,live:live(),
reason:lastReason,stale:lastStale,memory:memoryUse,explained:drift,
ghosts:{held:ghosts.length,shown:ghostsShown},arrivals:arrivals.reason??(arrivals.ok?'ok':null),
counts:{...counts},loading,cooldownMs:RAIL_PACKS_COOLDOWN_MS}),
dispose(){drop()
try{arrivals.dispose()}catch(err){onError(err)}
arrivals={ok:false,reason:'unavailable',dispose(){}}
mirror=null
ghosts=[]
ghostsShown=0
deadEnd=null
drift=0
staleSince=null
if(settleTimer!==null){try{doc.defaultView?.clearTimeout?.(settleTimer)}catch{
}
settleTimer=null}}}}
