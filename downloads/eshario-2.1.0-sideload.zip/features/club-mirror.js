import{sbcIneligibleReason,cardResourceKey} from '../adapter/sbc-submit.js'
import{stopOnEaLimit} from './day-budget.js'
export const MIRROR_SCHEMA=1
export function generationFits(stamped,generation){return genOf(stamped)===genOf(generation)}
function genOf(value){const n=numberOf(value)
return n===null||!Number.isSafeInteger(n)||n<=0?null:n}
export const CLUB_READS_PER_DAY=200
export const CLUB_SESSION_RESCUE_READS=3
export const CLUB_MIRROR_PAGE=200
export const CLUB_MIRROR_MAX_PAGES=40
export const PAUSE_FROM_CARDS=2000
export const PAUSE_MIN_MS=150
export const PAUSE_MAX_MS=400
export const CLUB_READ_ATTEMPTS=3
export const CLUB_RETRY_MS=Object.freeze([1500,3500])
export const READ_MIN_SHARE=0.5
export const MIRROR_TTL_MS=24*60*60*1000
export const SETTLE_MS=5000
export const READ_JOURNAL_MAX=100
export const MIRROR_SHARDS=8
export function shardOfId(id){const n=Number(id)
return Number.isFinite(n)?Math.abs(Math.trunc(n))%MIRROR_SHARDS:0}
export const PLAYER_TYPE='player'
export const PLAYER_STAT_TYPE='players'
const STAT_TYPE_OF=Object.freeze({player:PLAYER_STAT_TYPE,kit:'kits',ball:'balls',stadium:'stadia',
vanity:'vanity',staff:'staff'})
const CONSUMABLE_TYPES=Object.freeze({training:true,health:true})
function isConsumableItem(item){try{if(item?.isConsumable?.()===true)return true}catch{/* спросим полем */}
return CONSUMABLE_TYPES[stringOf(item?.type)]===true}
export const ARRIVAL_HALL_MAX=300
export function rowOf(item){if(!item||typeof item!=='object')return null
const id=numberOf(item.id??item.itemId)
if(id===null)return null
const row={i:id,d:numberOf(item.definitionId??item.defId)??0,t:stringOf(item.type),
r:numberOf(item.rating)??0,f:numberOf(item.rareflag)??-1,
l:numberOf(item.leagueId)??-1,n:numberOf(item.nationId)??-1,m:numberOf(item.teamId)??-1,
p:numbers(item.possiblePositions),s:stringOf(item.state),u:tradableFlag(item),
o:numberOf(item.loans)??-1,x:numberOf(item.limitedUseType)??0,e:numberOf(item.utasPile)??-1,
g:numbers(item.groups)}
const primary=numberOf(item.preferredPosition)
if(row.p.length===0&&primary!==null&&primary>=0)row.q=primary
try{row.y=sbcIneligibleReason(item)??null}catch{row.y=null}
try{row.w=cardResourceKey(item)??null}catch{row.w=null}
try{row.z=item.isSpecial?.()===true?1:0}catch{row.z=0}
return row}
export function cardFromRow(row){if(!row||typeof row!=='object')return null
const id=numberOf(row.i)
if(id===null)return null
const reason=typeof row.y==='string'?row.y:null
const key=typeof row.w==='string'?row.w:null
const tradable=row.u===1?true:row.u===0?false:undefined
const card={id,itemId:id,definitionId:numberOf(row.d)??0,type:stringOf(row.t),
rating:numberOf(row.r)??0,rareflag:numberOf(row.f)??-1,
leagueId:numberOf(row.l)??-1,nationId:numberOf(row.n)??-1,teamId:numberOf(row.m)??-1,
possiblePositions:numbers(row.p),preferredPosition:numberOf(row.q)??-1,
state:stringOf(row.s),loans:numberOf(row.o)??-1,limitedUseType:numberOf(row.x)??0,
utasPile:numberOf(row.e)??-1,groups:numbers(row.g),
concept:reason==='concept',
isLimitedUse:()=>reason==='loan',
isEnrolledInAcademy:()=>reason==='academy',
isPlayer:()=>stringOf(row.t)===PLAYER_TYPE,
isSpecial:()=>row.z===1,
isLegend:()=>key!==null&&key.startsWith('icon:'),
fromMirror:true}
if(tradable!==undefined){card.tradable=tradable
card.untradeable=!tradable}
if(key!==null){if(key.startsWith('icon:'))card.iconId=Number(key.slice(5))||0
else if(key.startsWith('db:'))card.databaseId=Number(key.slice(3))||0}
return card}
export async function readClubOnce(club,deps={}){if(!club||typeof club.search!=='function')throw new Error('зеркало: адаптер клуба недоступен')
const createCriteria=typeof deps.createCriteria==='function'?deps.createCriteria:null
if(!createCriteria)throw new Error('зеркало: критерий страницы не передан')
const size=Number.isSafeInteger(deps.pageSize)&&deps.pageSize>0?deps.pageSize:CLUB_MIRROR_PAGE
const cap=Number.isSafeInteger(deps.maxPages)&&deps.maxPages>0?deps.maxPages:CLUB_MIRROR_MAX_PAGES
const pause=typeof deps.pause==='function'?deps.pause:null
const random=typeof deps.random==='function'?deps.random:Math.random
const attempts=Number.isSafeInteger(deps.attempts)&&deps.attempts>0?deps.attempts:CLUB_READ_ATTEMPTS
const retry=Array.isArray(deps.retryMs)&&deps.retryMs.length>0?deps.retryMs:CLUB_RETRY_MS
const budget=deps.budget??null
let last=[]
let pages=0
let tries=0
for(let page=0;page<cap;page+=1){
if(page>0&&pause&&last.length>=PAUSE_FROM_CARDS){await pause(PAUSE_MIN_MS+Math.floor(random()*(PAUSE_MAX_MS-PAUSE_MIN_MS+1)))}
let batch=null
let failure=null
for(let attempt=0;attempt<attempts;attempt+=1){if(attempt>0&&pause)await pause(retry[attempt-1]??retry[retry.length-1])
tries+=1
try{batch=await club.search(createCriteria({count:size,offset:page*size}))
failure=null
break}catch(err){failure=err
batch=null
if(stopOnEaLimit(budget,err)!==null)break}}
if(failure!==null)throw failure
if(!batch||typeof batch!=='object'||Array.isArray(batch)
||!Array.isArray(batch.items)||typeof batch.retrievedAll!=='boolean'){throw new Error('зеркало: EA вернула неизвестную форму страницы')}
pages+=1
if(batch.retrievedAll)return{items:batch.items,pages,retrievedAll:true,tries,reason:null}
if(batch.items.length===0)return{items:last,pages,retrievedAll:false,tries,reason:'empty-page'}
last=batch.items}
return{items:last,pages,retrievedAll:false,tries,reason:'page-limit'}}
export function readVerdict(result,options={}){const items=Array.isArray(result?.items)?result.items:[]
const got=items.length
let players=0
for(const item of items)if(stringOf(item?.type)===PLAYER_TYPE)players+=1
const expected=Math.max(0,numberOf(options.expected)??0)
if(result?.retrievedAll!==true)return{ok:false,reason:result?.reason??'partial',got,players,expected}
if(expected>0&&players<Math.floor(expected*READ_MIN_SHARE))return{ok:false,reason:'short',got,players,expected}
return{ok:true,reason:null,got,players,expected}}
export function playersInStats(list){for(const row of Array.isArray(list)?list:[]){if(stringOf(row?.type)!==PLAYER_STAT_TYPE)continue
return numberOf(row?.count)??0}
return 0}
export function countsOf(rows){const out={}
for(const row of Array.isArray(rows)?rows:[]){const type=stringOf(row?.t)
if(type==='')continue
out[type]=(out[type]??0)+1}
return out}
function statsMap(list){const out=new Map()
for(const row of Array.isArray(list)?list:[]){const type=stringOf(row?.type)
const count=numberOf(row?.count)
if(type===''||count===null)continue
out.set(type,count)}
return out}
export function compareCounts(baseline,live,mine={}){if(!Array.isArray(live)||live.length===0)return{ok:false,reason:'no-stats',checked:0,diff:[]}
if(!Array.isArray(baseline)||baseline.length===0)return{ok:false,reason:'no-baseline',checked:0,diff:[]}
const was=statsMap(baseline)
const now=statsMap(live)
const diff=[]
for(const type of new Set([...was.keys(),...now.keys()])){const before=was.get(type)??0
const after=now.get(type)??0
if(before!==after)diff.push({where:'snapshot',type,mine:before,theirs:after})}
const checked=new Set([...was.keys(),...now.keys()]).size
const players=numberOf(mine?.players)
const theirPlayers=now.get(PLAYER_STAT_TYPE)
if(players!==null&&theirPlayers!==undefined&&players!==theirPlayers){diff.push({where:'rows',type:PLAYER_STAT_TYPE,mine:players,theirs:theirPlayers})}
return{ok:diff.length===0,reason:diff.length===0?null:'diverged',checked,diff}}
export function createClubMirror(deps={}){const storage=deps.storage??null
const schedule=typeof deps.schedule==='function'?deps.schedule:(fn)=>{fn()}
const now=typeof deps.now==='function'?deps.now:()=>Date.now()
const today=typeof deps.today==='function'?deps.today:()=>localDay(now())
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const shards=[]
for(let n=0;n<MIRROR_SHARDS;n+=1)shards.push(new Map())
const dirty=new Set()
let flushing=false
let loading=false
let loaded=false
let readAt=null
let source=null
let baseline=null
let baselineMemory=null
let baselineStamp=null
const appliedSince=new Map()
let dirtyRows=0
let generation=0
let epoch=0
let changedAt=null
const reads={day:null,used:0}
let rescued=0
const stats={reads:0,rowsRead:0,pages:0,applied:0,ignored:0,removed:0,added:0,writes:0,refused:0,
verifies:0,matched:0,diverged:0,expired:0,lastDiff:[],lastReason:null,events:{ok:false,missing:[]},
baselineMoves:0,shortReads:0,lastShort:null,resyncs:0,lastResync:[],
journalRuns:0,journalAdded:0,journalRemoved:0,journalOverflows:0,journalDropped:0,
foreign:0,recalled:0,unresolved:0,lastUnknown:[],
memorySilent:0,memoryMoved:0,memoryExplained:0,memoryServerMoved:0,memoryNoStamp:0,anchors:0,
torn:0,lastTorn:null}
const hall=new Map()
function remember(items){for(const item of Array.isArray(items)?items:[]){const id=numberOf(item?.id??item?.itemId)
if(id===null||typeof item!=='object')continue
if(hall.size>=ARRIVAL_HALL_MAX&&!hall.has(id)){const oldest=hall.keys().next()
if(!oldest.done)hall.delete(oldest.value)}
hall.set(id,item)}
return hall.size}
let readMark=0
let journal=null
let lastReplay=null
function openJournal(){readMark+=1
journal={mark:readMark,rows:new Map(),deltas:new Map(),dirty:0,count:0,overflow:false}
return readMark}
function noteInJournal(op,id,row,type){if(journal===null)return
if(journal.count>=READ_JOURNAL_MAX){journal.overflow=true
return}
journal.count+=1
journal.rows.set(id,op==='add'?{op,row}:{op})
const name=STAT_TYPE_OF[stringOf(type)]??''
if(name==='')return
journal.deltas.set(name,(journal.deltas.get(name)??0)+(op==='add'?1:-1))}
function markDirty(count){const n=Number.isSafeInteger(count)&&count>0?count:0
if(n===0)return
dirtyRows+=n
if(journal!==null)journal.dirty+=n}
const everyRow=function*(){for(const shard of shards)yield*shard.values()}
const rowCount=()=>{let total=0
for(const shard of shards)total+=shard.size
return total}
const touch=(id)=>{if(loading)return
dirty.add(shardOfId(id))
if(flushing)return
flushing=true
schedule(step)}
const touchHead=()=>{if(loading)return
dirty.add('head')
if(flushing)return
flushing=true
schedule(step)}
function step(){const next=dirty.values().next()
if(next.done){flushing=false
return}
const shard=next.value
dirty.delete(shard)
try{const result=shard==='head'
?storage?.writeHead?.(encodeHead())
:storage?.writeShard?.(shard,encodeShard(shards[shard]))
stats.writes+=1
if(result&&typeof result.catch==='function')result.catch(onError)}catch(err){onError(err)}
schedule(step)}
function snapshotOf(list){return Array.isArray(list)&&list.length>0
?list.map((row)=>({type:stringOf(row?.type),count:numberOf(row?.count)??0}))
:null}
function encodeShard(bucket){const cards={}
for(const[id,row]of bucket)cards[id]=row
const out={v:MIRROR_SCHEMA,cards}
if(epoch>0)out.g=epoch
return out}
function encodeHead(){const head={v:MIRROR_SCHEMA,at:readAt,source,counts:countsOf([...everyRow()]),
baseline,reads:{day:reads.day,used:reads.used},dirty:dirtyRows}
if(epoch>0)head.g=epoch
return head}
function decodeShard(raw){const out=[]
if(!raw||typeof raw!=='object'||raw.v!==MIRROR_SCHEMA)return out
const cards=raw.cards
if(!cards||typeof cards!=='object')return out
for(const key of Object.keys(cards)){const row=cards[key]
const id=numberOf(row?.i)
if(id===null)continue
out.push([id,row])}
return out}
function tearDown(list){const claimed=genOf(epoch)
for(const bucket of shards)bucket.clear()
readAt=null
source=null
baseline=null
baselineMemory=null
baselineStamp=null
appliedSince.clear()
dirtyRows=0
let top=epoch
for(const one of list)if(one.found!==null&&one.found>top)top=one.found
epoch=top+1
stats.torn+=1
stats.lastTorn={head:claimed,shards:list.slice(0,MIRROR_SHARDS).map((one)=>({...one})),at:now()}
return stats.torn}
function bumpBaseline(type,delta){changedAt=now()
if(delta===0)return false
noteApplied(type,delta)
const name=STAT_TYPE_OF[stringOf(type)]??''
if(name==='')return false
const moved=moveSnapshot(baseline,name,delta)
if(moved)stats.baselineMoves+=1
return moved}
function noteApplied(type,delta){const name=STAT_TYPE_OF[stringOf(type)]??''
if(name===''||delta===0)return false
const next=(appliedSince.get(name)??0)+delta
if(next===0)appliedSince.delete(name)
else appliedSince.set(name,next)
return true}
function stampOf(value){const n=numberOf(value)
return n===null||n<=0?null:n}
function anchorMemory(stamp,list){const mark=stampOf(stamp)
if(mark!==baselineStamp)appliedSince.clear()
baselineStamp=mark
baselineMemory=snapshotOf(list)
stats.anchors+=1
return mark}
function explainMemoryDelta(anchor,live,applied){const was=statsMap(anchor)
const nowStats=statsMap(live)
const names=new Set([...was.keys(),...nowStats.keys(),...applied.keys()])
const diff=[]
for(const type of names){const moved=(nowStats.get(type)??0)-(was.get(type)??0)
const ours=applied.get(type)??0
if(moved!==ours)diff.push({where:'delta',type,mine:ours,theirs:moved})}
return{ok:diff.length===0,reason:diff.length===0?null:'server-moved',checked:names.size,diff}}
function moveSnapshot(snapshot,name,delta){if(snapshot===null||name===''||delta===0)return false
const row=snapshot.find((one)=>stringOf(one?.type)===name)
if(row!==undefined){row.count=Math.max(0,(numberOf(row?.count)??0)+delta)
return true}
if(delta>0){snapshot.push({type:name,count:delta})
return true}
return false}
function replayJournal(options={}){const box=journal
journal=null
if(box===null)return null
const size=box.rows.size
const mark=numberOf(options.mark)
if(mark!==null&&mark!==box.mark){stats.journalDropped+=1
markDirty(1)
return{mark:box.mark,size,added:0,removed:0,overflow:false,dropped:true}}
if(box.overflow){
stats.journalOverflows+=1
markDirty(1)
return{mark:box.mark,size,added:0,removed:0,overflow:true,dropped:false}}
let added=0
let removed=0
for(const[id,entry]of box.rows){const bucket=shards[shardOfId(id)]
if(entry.op==='add'){const row=entry.row
if(row===null||row===undefined)continue
if(!bucket.has(id))added+=1
bucket.set(id,row)
continue}
if(bucket.delete(id))removed+=1}
if(options.statsAt!=='now')for(const[name,delta]of box.deltas)moveSnapshot(baseline,name,delta)
dirtyRows+=box.dirty
if(size>0){stats.journalRuns+=1
stats.journalAdded+=added
stats.journalRemoved+=removed
changedAt=now()}
return{mark:box.mark,size,added,removed,overflow:false,dropped:false}}
function put(row){const id=numberOf(row?.i)
if(id===null)return false
noteInJournal('add',id,row,row?.t)
const bucket=shards[shardOfId(id)]
const before=bucket.get(id)
if(before!==undefined&&sameRow(before,row))return false
bucket.set(id,row)
if(before===undefined){stats.added+=1
bumpBaseline(row?.t,1)}
generation+=1
touch(id)
return true}
function drop(id){const key=numberOf(id)
if(key===null)return false
const bucket=shards[shardOfId(key)]
const row=bucket.get(key)
noteInJournal('drop',key,null,row?.t)
if(row===undefined)return false
bucket.delete(key)
bumpBaseline(row?.t,-1)
stats.removed+=1
generation+=1
touch(key)
return true}
function rollDay(){const day=today()
if(reads.day!==day){reads.day=day
reads.used=0
return true}
return false}
return{
async load(){loading=true
try{const head=await storage?.readHead?.()
if(head&&typeof head==='object'&&head.v===MIRROR_SCHEMA){readAt=numberOf(head.at)
epoch=genOf(head.g)??0
source=stringOf(head.source)||null
dirtyRows=numberOf(head.dirty)??0
baseline=Array.isArray(head.baseline)&&head.baseline.length>0?head.baseline:null
baselineMemory=null
baselineStamp=null
appliedSince.clear()
const box=head.reads
if(box&&typeof box==='object'){reads.day=stringOf(box.day)||null
reads.used=numberOf(box.used)??0}}
else{
readAt=null
source=null
baseline=null
baselineMemory=null
epoch=0}
if(readAt!==null){
const torn=[]
await Promise.all(shards.map(async(bucket,n)=>{try{const raw=await storage?.readShard?.(n)
if(!generationFits(raw?.g,epoch))torn.push({shard:n,found:genOf(raw?.g)})
for(const[id,row]of decodeShard(raw)){
if(shardOfId(id)!==n)continue
bucket.set(id,row)}}catch(err){onError(err)}}))
if(torn.length>0)tearDown(torn.sort((a,b)=>a.shard-b.shard))}}catch(err){onError(err)
readAt=null}finally{loading=false}
loaded=true
rollDay()
return this.state()},
usable(){if(!loaded||readAt===null||rowCount()===0)return{ok:false,reason:'empty'}
if(baseline===null)return{ok:false,reason:'no-baseline'}
if(now()-readAt>MIRROR_TTL_MS){stats.expired+=1
return{ok:false,reason:'expired'}}
if(dirtyRows>0)return{ok:false,reason:'dirty'}
return{ok:true,reason:null}},
settling(){return changedAt!==null&&now()-changedAt<SETTLE_MS},
verify(liveStats){stats.verifies+=1
let players=0
for(const row of everyRow())if(stringOf(row?.t)===PLAYER_TYPE)players+=1
const result=compareCounts(baseline,liveStats,{players})
stats.lastDiff=result.diff.slice(0,12)
stats.lastReason=result.reason
if(result.ok)stats.matched+=1
else stats.diverged+=1
return result},
verifyMemory(liveStats,liveStamp){const stamp=stampOf(liveStamp)
if(stamp===null){stats.memoryNoStamp+=1
return{ok:true,reason:'no-stamp',checked:0,diff:[]}}
if(baselineMemory===null||baselineStamp===null){anchorMemory(stamp,liveStats)
return{ok:true,reason:'anchored',checked:0,diff:[]}}
if(stamp===baselineStamp){stats.memorySilent+=1
return{ok:true,reason:'stamp-same',checked:0,diff:[]}}
stats.verifies+=1
stats.memoryMoved+=1
const result=explainMemoryDelta(baselineMemory,liveStats,appliedSince)
anchorMemory(stamp,liveStats)
stats.lastDiff=result.diff.slice(0,12)
stats.lastReason=result.reason
if(result.ok){stats.matched+=1
stats.memoryExplained+=1}
else{stats.diverged+=1
stats.memoryServerMoved+=1}
return result},
mayRead(options={}){rollDay()
if(reads.used<CLUB_READS_PER_DAY)return{ok:true,reason:null,used:reads.used,cap:CLUB_READS_PER_DAY,rescued}
if(options.first===true&&rescued<CLUB_SESSION_RESCUE_READS)return{ok:true,reason:'rescue',used:reads.used,cap:CLUB_READS_PER_DAY,rescued}
return{ok:false,reason:'day-limit',used:reads.used,cap:CLUB_READS_PER_DAY,rescued}},
spendRead(rescue){rollDay()
reads.used+=1
if(rescue===true)rescued+=1
stats.reads+=1
openJournal()
touchHead()
return reads.used},
readRefused(verdict){stats.shortReads+=1
stats.lastShort={reason:verdict?.reason??null,got:numberOf(verdict?.got)??0,
players:numberOf(verdict?.players)??0,expected:numberOf(verdict?.expected)??0,at:now()}
journal=null
return stats.shortReads},
put(items,meta={}){const list=Array.isArray(items)?items:[]
loading=true
try{for(const bucket of shards)bucket.clear()
for(const item of list){const row=rowOf(item)
if(row===null){stats.refused+=1
continue}
shards[shardOfId(row.i)].set(row.i,row)}}finally{loading=false}
readAt=now()
changedAt=null
source=stringOf(meta.source)||'read'
baseline=snapshotOf(meta.stats)
anchorMemory(meta.stamp,meta.memory)
dirtyRows=0
lastReplay=replayJournal({mark:meta.mark,statsAt:stringOf(meta.statsAt)})
stats.rowsRead=rowCount()
stats.pages+=numberOf(meta.pages)??0
generation+=1
epoch+=1
dirty.clear()
for(let n=0;n<MIRROR_SHARDS;n+=1)dirty.add(n)
dirty.add('head')
if(!flushing){flushing=true
schedule(step)}
return rowCount()},
applyEvent(event,lookup=null){if(!event||typeof event!=='object'){stats.ignored+=1
return 'noted'}
const ids=Array.isArray(event.ids)?event.ids:[]
const noted=()=>{stats.ignored+=1
return 'noted'}
const gone=()=>{let removed=0
for(const id of ids)if(drop(id))removed+=1
if(removed>0){stats.applied+=1
touchHead()
return 'gone'}
return noted()}
const arrive=()=>{if(lookup===null){markDirty(ids.length)
touchHead()
return 'dirty'}
let known=0
let unknown=0
let foreign=0
const missed=[]
for(const id of ids){let item=null
try{item=lookup(id)}catch{item=null}
if(item===null||item===undefined){const key=numberOf(id)
if(key!==null&&hall.has(key)){item=hall.get(key)
hall.delete(key)
stats.recalled+=1}}
if(item!==null&&item!==undefined&&isConsumableItem(item)){foreign+=1
continue}
const row=item===null||item===undefined?null:rowOf(item)
if(row===null){unknown+=1
if(missed.length<12)missed.push(String(id))
continue}
put(row)
known+=1}
if(foreign>0)stats.foreign+=foreign
if(unknown>0){stats.unresolved+=unknown
stats.lastUnknown=missed
markDirty(unknown)
touchHead()
return 'dirty'}
if(known>0){stats.applied+=1
touchHead()
return 'added'}
if(foreign>0)return noted()
return noted()}
switch(event.name){
case 'ITEM_MOVE':
if(event.from==='CLUB'&&event.to!=='CLUB')return gone()
if(event.to==='CLUB')return arrive()
if(event.from===null&&event.to===null){markDirty(ids.length)
touchHead()
return 'dirty'}
return noted()
case 'ITEM_DISCARD':
case 'ITEM_CLEARSOLD':
return ids.length>0?gone():noted()
case 'ITEM_BID':
case 'ITEM_UNDO_DISCARD':
return arrive()
case 'UNASSIGNED_ITEM_ADDED':
remember(event.items)
return noted()
default:
return noted()}},
removed(ids){
changedAt=now()
let count=0
for(const id of Array.isArray(ids)?ids:[])if(drop(id))count+=1
if(count>0)touchHead()
return count},
noteOurChange(live){if(!Array.isArray(live)||live.length===0)return{ok:false,diff:[]}
const was=statsMap(baseline)
const now=statsMap(live)
const diff=[]
for(const type of new Set([...was.keys(),...now.keys()])){const before=was.get(type)??0
const after=now.get(type)??0
if(before!==after)diff.push({type,mine:before,theirs:after})}
stats.resyncs+=1
stats.lastResync=diff.slice(0,12)
return{ok:true,diff}},
players(){const out=[]
for(const row of everyRow()){if(stringOf(row?.t)!==PLAYER_TYPE)continue
const card=cardFromRow(row)
if(card!==null)out.push(card)}
return out},
count(){return rowCount()},
rows(){return[...everyRow()]},
counts(){return countsOf([...everyRow()])},
subscribed(ok,missing){stats.events={ok:ok===true,missing:Array.isArray(missing)?[...missing]:[]}
return stats.events.ok},
generation(){return generation},
readAt(){return readAt},
state(){const size=rowCount()
let players=0
for(const row of everyRow())if(stringOf(row?.t)===PLAYER_TYPE)players+=1
return{schema:MIRROR_SCHEMA,loaded,size,players,readAt,source,generation,
record:{generation:epoch,torn:stats.torn,
last:stats.lastTorn===null?null:{...stats.lastTorn,shards:stats.lastTorn.shards.map((one)=>({...one}))}},
baseline:baseline===null?null:baseline.map((one)=>({...one})),
baselineMemory:baselineMemory===null?null:baselineMemory.map((one)=>({...one})),
memoryAnchor:{stamp:baselineStamp,applied:Object.fromEntries(appliedSince),
silent:stats.memorySilent,moved:stats.memoryMoved,explained:stats.memoryExplained,
serverMoved:stats.memoryServerMoved,noStamp:stats.memoryNoStamp,anchors:stats.anchors},
age:readAt===null?null:now()-readAt,ttlMs:MIRROR_TTL_MS,
dirty:dirtyRows,pendingShards:dirty.size,
budget:{day:reads.day,used:reads.used,cap:CLUB_READS_PER_DAY,rescued,rescueCap:CLUB_SESSION_RESCUE_READS},
counts:countsOf([...everyRow()]),
verify:{runs:stats.verifies,matched:stats.matched,diverged:stats.diverged,
reason:stats.lastReason,diff:stats.lastDiff.map((one)=>({...one}))},
events:{...stats.events,missing:[...stats.events.missing]},
reads:stats.reads,pages:stats.pages,rowsRead:stats.rowsRead,
applied:stats.applied,ignored:stats.ignored,removedRows:stats.removed,addedRows:stats.added,
refused:stats.refused,writes:stats.writes,expired:stats.expired,
baselineMoves:stats.baselineMoves,shortReads:stats.shortReads,
short:stats.lastShort===null?null:{...stats.lastShort},
resync:{runs:stats.resyncs,diff:stats.lastResync.map((one)=>({...one}))},
journal:{open:journal!==null,mark:readMark,size:journal===null?0:journal.rows.size,
runs:stats.journalRuns,added:stats.journalAdded,removed:stats.journalRemoved,
overflows:stats.journalOverflows,dropped:stats.journalDropped,
last:lastReplay===null?null:{...lastReplay}},
arrivals:{hall:hall.size,foreign:stats.foreign,recalled:stats.recalled,
unresolved:stats.unresolved,unknownIds:[...stats.lastUnknown]}}}}}
export function localDay(stamp){const date=new Date(Number(stamp)||0)
const pad=(n)=>String(n).padStart(2,'0')
return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`}
function sameRow(a,b){if(a===b)return true
if(!a||!b)return false
for(const key of Object.keys(b)){const left=a[key]
const right=b[key]
if(Array.isArray(left)&&Array.isArray(right)){if(left.length!==right.length)return false
for(let i=0;i<left.length;i+=1)if(left[i]!==right[i])return false
continue}
if(left!==right)return false}
return Object.keys(a).length===Object.keys(b).length}
function numberOf(value){const n=typeof value==='string'&&/^-?\d+$/.test(value.trim())?Number(value):value
return Number.isFinite(n)?n:null}
function stringOf(value){return typeof value==='string'?value:''}
function numbers(value){if(!Array.isArray(value))return[]
const out=[]
for(const one of value){const n=numberOf(one)
if(n!==null)out.push(n)}
return out}
function tradableFlag(item){if(item?.tradable===true)return 1
if(item?.tradable===false)return 0
if(item?.untradeable===true)return 0
if(item?.untradeable===false)return 1
return-1}
