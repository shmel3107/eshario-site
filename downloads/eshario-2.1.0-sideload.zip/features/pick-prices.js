import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{PRICE_BADGE_FEATURE,priceBadgeCoins,shortCoins,definitionOf} from './price-badges.js'
import{pickItemFacts} from '../adapter/player-picks.js'
export const PICK_PRICES_FEATURE=PRICE_BADGE_FEATURE
export const PICK_BY_PRICE_FEATURE='pickByPrice'
const PICK_STYLESHEET=new URL('../ui/pick-prices.css',import.meta.url).href
const PICK_LINK_ID='fut-companion-pick-prices'
const OURS_SELECTOR='[data-fut-pick]'
const SAID_SELECTOR='[data-fut-pick-said]'
const CURSOR_SELECTOR='[data-fut-pick-cursor]'
export function bestPickIndex(prices){const list=Array.isArray(prices)?prices:[]
let best=null
let bestAt=null
let ties=0
for(let index=0;index<list.length;index+=1){const value=list[index]
if(!Number.isSafeInteger(value)||value<=0)return null
if(best===null||value>best){best=value
bestAt=index
ties=0
continue}
if(value===best)ties+=1}
if(list.length<2||ties>0)return null
return bestAt}
export function autoPickOrder(variants,count,byPrice=false){const list=Array.isArray(variants)?variants:[]
const want=Number.isSafeInteger(count)&&count>0?Math.min(count,list.length):0
if(want===0)return[]
const num=(value)=>(Number.isSafeInteger(value)&&value>0?value:null)
const rows=[]
for(let index=0;index<list.length;index+=1){const price=num(list[index]?.price)
const rating=num(list[index]?.rating)
if((byPrice?price:rating)===null)return[]
rows.push({index,price,rating})}
if(rows.length===0)return[]
const first=(one)=>(byPrice?one.price:one.rating)
const second=(a,b)=>{const one=byPrice?a.rating:a.price
const two=byPrice?b.rating:b.price
return one===null||two===null?0:two-one}
rows.sort((a,b)=>first(b)-first(a)||second(a,b)||a.index-b.index)
return rows.slice(0,want).map((one)=>one.index)}
const ONE_ROW_UP_TO=10
export function pickGridFit(count,box,card,gap=8){const n=Number.isSafeInteger(count)&&count>0?count:0
if(n===0)return{cols:0,rows:0,zoom:1}
const rows=n>ONE_ROW_UP_TO?2:1
const shape={cols:Math.ceil(n/rows),rows}
return{...shape,zoom:pickGridZoom(box,card,shape,gap)}}
export function pickGridZoom(box,card,shape,gap=8){const cols=shape?.cols??0
const rows=shape?.rows??0
const ok=(value)=>typeof value==='number'&&Number.isFinite(value)&&value>0
if(cols<=0||rows<=0||!ok(card?.width)||!ok(card?.height)||!ok(box?.width)||!ok(box?.height))return 1
const step=ok(gap)?gap:0
const needWidth=cols*card.width+(cols-1)*step
const needHeight=rows*card.height+(rows-1)*step
const fit=Math.min(box.width/needWidth,box.height/needHeight)*0.96
if(!Number.isFinite(fit)||fit<=0)return 1
return Math.max(0.2,Math.min(1,Math.round(fit*100)/100))}
const GRID_SELECTOR='[data-fut-picks-grid]'
const CONFIRMING_SELECTOR='[data-fut-picks-confirming]'
const WIDE_SELECTOR='[data-fut-picks-wide]'
const LIVE_SELECTOR='[data-fut-pick-live]'
const TAKEN_SELECTOR='[data-fut-pick-taken]'
const GRID_GAP=8
const TIGHT_BELOW=0.7
const FIT_TRIES=5
const FRAMES_CAP=12
const PASSES_CAP=200
const MIN_ZOOM=0.28
const SANE_ZOOM=0.5
const ROOM_SHARE=0.75
const DOUBT_TRIES=6
const REGROW_TRIES=2
const REGROW_STEP=8
const REGROW_CHECKS=12
const FLOOR_CARDS=4
export function createPickPrices(deps={}){const{doc,t}=deps
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const priceOf=typeof deps.priceOf==='function'?deps.priceOf:priceBadgeCoins
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let last=null
let scheduled=false
let framed=false
let lastResult={ok:false,reason:'not-run'}
let lastPrices=[]
let lastLive=[]
let lastWaiting=0
let lastBest=null
let renders=0
let autoResult={done:false,reason:'not-run',picked:[]}
let lastFocus=null
let swaps=0
let gridFit=null
let fitTries=0
let verified=false
let doubts=0
let regrows=0
let regrowChecks=0
let fitRoom=0
let widened=false
let floor=0
let floorTries=0
let chain=0
let frameTicket=0
let gridHost=null
let fitCalls=0
let passes=0
let halted=null
let haltedAt=0
const wakes={show:0,price:0,dom:0,lang:0}
let pending=null
let selfWoke=0
let otherWoke=0
let idle=0
let mark=''
let dirty=false
const armed=new Map()
const WAKES_PER_VARIANT=2
const answered=new Set()
let said=false
let itemsOnly=false
let clickHost=null
let clickHandler=null
let keyHost=null
let keyHandler=null
let upHandler=null
let echoHandler=null
let ateEnter=false
let hitCapture=0
let hitBubble=0
let keyActed=0
let keyLast=''
let cursor=null
let dropContinue=null
let confirmResult={done:false,reason:'not-run'}
const record=(result)=>{lastResult=result
return result}
const frame=typeof deps.frame==='function'?deps.frame
:(run)=>{const raf=doc?.defaultView?.requestAnimationFrame
if(typeof raf==='function')raf.call(doc.defaultView,run)
else run()}
function apply(capture){if(!doc||!capture?.box)return record({ok:false,reason:'no-capture'})
if(last!==capture){gridFit=null
fitTries=0
verified=false
doubts=0
regrows=0
regrowChecks=0
fitRoom=0
widened=false
floor=0
floorTries=0
chain=0
passes=0
said=false
itemsOnly=false
cursor=null
hitCapture=0
hitBubble=0
keyActed=0
keyLast=''
swaps=0
armed.clear()
answered.clear()
resetWakes()
lastFocus=null
autoResult={done:false,reason:'pending',picked:[]}
arm(capture)}
last=capture
schedule('show')
return record({ok:true,reason:'pending'})}
function resetWakes(){wakes.show=0
wakes.price=0
wakes.dom=0
wakes.lang=0
selfWoke=0
otherWoke=0
idle=0
mark=''
dirty=false}
function schedule(reason){if(pending===null)pending=reason??'price'
if(scheduled)return
scheduled=true
Promise.resolve().then(()=>{scheduled=false
const why=pending??'price'
pending=null
try{settle(why)}catch(err){onError(err)}})}
function refresh(){if(!last)return false
return settle('dom').ok===true}
function relabel(){if(!last)return false
return settle('lang').ok===true}
function settle(why='dom'){if(halted)return record({ok:false,reason:'halted'})
if(!last)return record({ok:false,reason:'no-capture'})
passes+=1
if(Object.hasOwn(wakes,why))wakes[why]+=1
if(passes>PASSES_CAP){
haltedAt=passes
halted='runaway'
forget()
onError(new Error('pick prices: слишком много проходов на одном показе, фича снята'))
return record({ok:false,reason:'halted'})}
const before=stamp()
if(before===mark)idle+=1
if(why==='dom'){if(dirty)selfWoke+=1
else otherWoke+=1}
chain=0
const{box,variants}=last
if(!safeActive()){drop()
return record({ok:false,reason:'locked'})}
if(box?.isConnected===false){forget()
return record({ok:false,reason:'detached'})}
const live=(Array.isArray(variants)?variants:[]).filter((one)=>one?.card?.isConnected!==false)
if(live.length===0){forget()
return record({ok:false,reason:'empty'})}
ensureTheme(doc)
ensureStylesheet(doc,PICK_STYLESHEET,PICK_LINK_ID)
const prices=[]
let waiting=0
for(const one of live){let answer=null
try{answer=priceOf(one.item)}catch(err){onError(err)
answer=null}
if(answer!==null&&typeof answer?.then==='function'){prices.push(null)
const key=definitionOf(one.item)??`v${one.index}`
const woken=armed.get(key)??0
if(woken<WAKES_PER_VARIANT){armed.set(key,woken+1)
waiting+=1
const done=()=>{answered.add(key)
schedule('price')}
answer.then(done,done)
continue}
if(!answered.has(key))waiting+=1
continue}
prices.push(Number.isSafeInteger(answer)&&answer>0?answer:null)}
const best=bestPickIndex(prices)
lastPrices=prices
lastLive=live
lastWaiting=waiting
lastBest=best===null?null:live[best]?.index??null
const owns=last.controls??null
for(let at=0;at<live.length;at+=1){paint(live[at],prices[at],best===at,owns?.owned?.(live[at].index)??null)}
const chosen=shade(live,owns)
point()
itemsOnly=live.every((one)=>pickItemFacts(one.item).player===false)
if(itemsOnly&&!said)said=say()
const laid=grid()
if(laid)listen()
else unlisten()
renders+=1
if(gridFit===null||autoResult.done!==true||regrowChecks<REGROW_CHECKS)askFrame(waiting)
const after=stamp()
dirty=after!==before
mark=after
return record({ok:true,reason:null,variants:live.length,priced:prices.filter((value)=>value!==null).length,waiting,best:lastBest,chosen})}
function shade(live,controls){const screen=last?.screen??null
const ask=typeof controls?.isSelected==='function'?controls.isSelected:null
let chosen=0
for(const one of live){const root=one?.root
if(!root?.dataset)continue
let taken=false
if(ask){try{taken=ask(one.index)===true}catch{taken=false}}
if(taken)chosen+=1
const want=taken?'1':'0'
if(root.dataset.futPickTaken!==want)root.dataset.futPickTaken=want}
if(screen?.dataset){const want=ask&&chosen>0?'1':'0'
if(screen.dataset.futPicksChosen!==want)screen.dataset.futPicksChosen=want}
return chosen}
function chosenList(){const ask=last?.controls?.isSelected??null
if(typeof ask!=='function')return[]
const list=lastLive.length>0?lastLive:(last?.variants??[])
const out=[]
for(const one of list){const index=one?.index
if(!Number.isSafeInteger(index))continue
let taken=false
try{taken=ask(index)===true}catch{taken=false}
if(taken)out.push(index)}
return out}
function dropTarget(){if(cursor!==null)return{index:cursor,why:null}
const chosen=chosenList()
if(chosen.length>1)return{index:null,why:'ambiguous'}
return{index:chosen.length===1?chosen[0]:null,why:null}}
function point(){for(const one of lastLive){const root=one?.root
if(!root?.dataset)continue
const want=cursor!==null&&one.index===cursor?'1':'0'
if(root.dataset.futPickCursor!==want)root.dataset.futPickCursor=want}
return cursor}
function stamp(){const parts=[]
for(const one of last?.variants??[]){const node=one?.card?.querySelector?.(OURS_SELECTOR)??null
if(!node){parts.push(`${one?.index}:-`)
continue}
parts.push(`${one?.index}:${node.querySelector?.('[data-fut-pick-coins]')?.textContent??''}:${node.querySelector?.('[data-fut-pick-owned]')?.textContent??''}:${node.dataset?.futPickBest??''}`)}
parts.push(`grid:${last?.screen?.dataset?.futPicksGrid??'-'}`)
parts.push(`said:${said?'1':'-'}`)
return parts.join('|')}
const WIDEN_LEVELS=4
function remember(screen){if(!screen?.style||typeof screen.style.setProperty!=='function')return'done'
let width=0
try{width=Math.round(screen.getBoundingClientRect?.()?.width??0)}catch{width=0}
if(width>floor)floor=width
if(floorTries<DOUBT_TRIES&&(last?.variants?.length??0)<=FLOOR_CARDS){floorTries+=1
return'wait'}
if(!(floor>0))return'done'
vars(screen,{'--fut-pick-win-min':`${floor}px`})
return'done'}
function widen(screen){const doc2=screen?.ownerDocument??doc
const body=doc2?.body??null
let node=screen
for(let level=0;level<=WIDEN_LEVELS&&node;level+=1){if(node===body||node===doc2?.documentElement)break
if(node.dataset&&node.dataset.futPicksWide!=='1')node.dataset.futPicksWide='1'
node=node.parentElement??null}
return true}
function grid(){const screen=last?.screen??null
const shape=gridFit?.shape??null
if(!screen||!screen.dataset||!shape||shape.cols<=0)return false
for(const one of last.variants??[]){if(one?.root?.dataset&&one.root.dataset.futPickLive!=='1')one.root.dataset.futPickLive='1'}
vars(screen,{'--fut-pick-cols':String(shape.cols),'--fut-pick-rows':String(shape.rows),'--fut-pick-gap':`${GRID_GAP}px`})
zoomTo(screen,gridFit.zoom)
if(screen.dataset.futPicksGrid!=='1')screen.dataset.futPicksGrid='1'
gridHost=screen
return true}
function vars(node,map){const style=node?.style
if(!style||typeof style.setProperty!=='function')return false
for(const[name,value]of Object.entries(map)){try{style.setProperty(name,value)}catch{}}
return true}
const UNZOOM_CAP=1.7
function zoomTo(screen,zoom){const back=Number.isFinite(zoom)&&zoom>0?1/zoom:1
vars(screen,{'--fut-pick-zoom':String(zoom),'--fut-pick-unzoom':String(Math.round(Math.min(UNZOOM_CAP,back)*1000)/1000)})
if(screen.dataset)screen.dataset.futPicksTight=zoom<TIGHT_BELOW?'1':'0'}
function askFrame(waiting){if(framed)return
framed=true
const ticket=frameTicket
frame(()=>{framed=false
if(ticket!==frameTicket){
if(last&&(gridFit===null||autoResult.done!==true))askFrame(waiting)
return}
chain+=1
let again=false
try{again=fit()==='retry'}catch(err){onError(err)}
try{auto(waiting)}catch(err){onError(err)}
try{shade(lastLive,last?.controls??null)}catch(err){onError(err)}
if(again&&chain<FRAMES_CAP)askFrame(waiting)})}
function verifyGrid(){verified=true
const screen=last?.screen??null
const shape=gridFit?.shape??null
if(!screen||!shape||shape.cols<=0)return'stop'
const room=measureBox(last?.box)
if(room===null)return'stop'
let width=0
let height=0
for(const one of last?.variants??[]){try{const rect=one?.root?.getBoundingClientRect?.()
if(!rect||!(rect.width>0)||!(rect.height>0))continue
if(rect.width>width)width=rect.width
if(rect.height>height)height=rect.height}catch{}}
if(!(width>0)||!(height>0))return'stop'
const natural={width:width/gridFit.zoom,height:height/gridFit.zoom}
if(!(natural.width>0)||!(natural.height>0))return'stop'
const fitWidth=(room.width-(shape.cols-1)*GRID_GAP)/(shape.cols*natural.width)
const fitHeight=(room.height-(shape.rows-1)*GRID_GAP)/(shape.rows*natural.height)
const factor=Math.min(fitWidth,fitHeight)
if(!Number.isFinite(factor)||factor<=0)return'stop'
if(fitWidth<=fitHeight&&factor<SANE_ZOOM&&doubts<DOUBT_TRIES&&!roomTrusted(room)){doubts+=1
verified=false
gridFit={...gridFit,doubt:{room:room.width,wall:wallWidth(),zoom:Math.round(factor*100)/100,tries:doubts}}
return'retry'}
const next=Math.max(MIN_ZOOM,Math.min(1,Math.floor(factor*0.99*100)/100))
fitRoom=room.width
if(factor<MIN_ZOOM){gridFit={shape:null,zoom:factor,box:room,card:gridFit.card,reason:'too-small'}
ungrid(screen)
return'stop'}
if(Math.abs(next-gridFit.zoom)<0.02)return'stop'
gridFit={...gridFit,zoom:next,fixed:{from:gridFit.zoom,to:next,column:Math.round(width)}}
zoomTo(screen,next)
return'stop'}
function wallWidth(){const screen=last?.screen??null
let wide=0
const view=doc?.defaultView??null
const room=Math.round((view?.innerWidth??0)*0.96)
if(Number.isFinite(room)&&room>0)wide=room
const doc2=screen?.ownerDocument??doc
const body=doc2?.body??null
let node=screen?.parentElement??null
for(let level=0;level<WIDEN_LEVELS&&node;level+=1){if(node===body||node===doc2?.documentElement)break
let width=0
try{width=Math.round(node.getBoundingClientRect?.()?.width??0)}catch{width=0}
if(Number.isFinite(width)&&width>wide)wide=width
node=node.parentElement??null}
return wide}
function roomTrusted(room){const wall=wallWidth()
if(!(wall>0))return true
return room.width>=wall*ROOM_SHARE}
function regrow(){if(regrows>=REGROW_TRIES||regrowChecks>=REGROW_CHECKS)return'stop'
regrowChecks+=1
if(!(fitRoom>0))return'stop'
const room=measureBox(last?.box)
if(room===null||room.width<=fitRoom+REGROW_STEP)return'stop'
regrows+=1
if(gridFit?.shape==null){gridFit=null
fitTries=0}
verified=false
return'retry'}
function fit(){fitCalls+=1
if(!last)return'stop'
if(gridFit!==null){if(verified)return regrow()
return verifyGrid()}
const screen=last.screen??null
const box=last.box??null
if(!screen||!box){gridFit={shape:null,zoom:1,reason:'no-screen'}
return'stop'}
if(!widened){
if(remember(screen)==='wait')return'retry'
widened=true
widen(screen)
return'retry'}
const room=measureBox(box)
const card=measureCard()
if(room===null||card===null){fitTries+=1
if(fitTries<FIT_TRIES)return'retry'
gridFit={shape:null,zoom:1,reason:'no-measure'}
return'stop'}
const best=pickGridFit(last.variants?.length??0,room,card,GRID_GAP)
if(best.cols<=1&&best.rows<=1){gridFit={shape:null,zoom:1,reason:'single'}
return'stop'}
gridFit={box:room,card,shape:{cols:best.cols,rows:best.rows},zoom:1,reason:null,wanted:best.zoom}
if(grid())listen()
return'retry'}
function measureBox(box){try{const rect=box.getBoundingClientRect?.()
if(!rect)return null
const width=Math.round(rect.width)
const height=Math.round(rect.height)
return width>0&&height>0?{width,height}:null}catch{return null}}
function measureCard(){let width=0
let height=0
for(const one of last?.variants??[]){try{const rect=one?.root?.getBoundingClientRect?.()
if(!rect||!(rect.width>0)||!(rect.height>0))continue
if(width===0||rect.width<width)width=rect.width
if(height===0||rect.height<height)height=rect.height}catch{}}
return width>0&&height>0?{width:Math.round(width),height:Math.round(height)}:null}
function say(){const screen=last?.screen??null
if(!screen)return false
const host=screen.querySelector?.('.content-container')??screen
if(!host||typeof host.appendChild!=='function')return false
if(host.querySelector?.(SAID_SELECTOR))return true
host.appendChild(el(doc,'div',{class:'fut-pick-said',text:t('pickPrices.items'),
attrs:{'aria-hidden':'true'},dataset:{futPickSaid:'1'}}))
return true}
function auto(waiting){if(autoResult.done===true||!last)return false
const byPrice=safeByPrice()
const controls=last.controls??null
if(!controls){autoResult={done:true,reason:'no-controls',picked:[]}
return false}
const want=controls.available
if(!Number.isSafeInteger(want)||want<=0){autoResult={done:true,reason:'no-limit',picked:[]}
return false}
if(byPrice&&(lastWaiting>0||waiting>0)){autoResult={done:false,reason:'waiting',picked:[],
missing:lastWaiting}
return false}
let already=0
try{already=controls.count()}catch{already=0}
if(already>0){autoResult={done:true,reason:'human-first',picked:[]}
return false}
const seen=lastLive.map((one,at)=>{const facts=pickItemFacts(one?.item)
return{index:one?.index,price:lastPrices[at]??null,
rating:facts.player===false?null:facts.rating}})
const order=autoPickOrder(seen,want,byPrice).map((at)=>seen[at].index)
const known=byPrice?lastPrices.filter((one)=>Number.isSafeInteger(one)&&one>0).length
:seen.filter((one)=>Number.isSafeInteger(one.rating)&&one.rating>0).length
if(order.length===0){autoResult={done:true,reason:itemsOnly?'items':(known>0?'gaps':(byPrice?'no-prices':'no-ratings')),picked:[],
known,of:lastLive.length}
return false}
focus(order[0])
const picked=[]
const refused=[]
for(const index of order){const answer=controls.select(index)
if(answer?.ok===true)picked.push(index)
else refused.push({index,reason:answer?.reason??'unknown'})}
autoResult={done:true,reason:picked.length===order.length?null:'partial',picked,refused}
return picked.length>0}
function arm(capture){disarm()
const controls=capture?.controls??null
if(!controls||typeof controls.whenContinued!=='function'){confirmResult={done:false,reason:'no-controls'}
return false}
confirmResult={done:false,reason:'armed'}
dropContinue=controls.whenContinued(()=>{try{onContinued(capture)}catch(err){onError(err)}})
return true}
function disarm(){if(typeof dropContinue==='function'){try{dropContinue()}catch{}}
dropContinue=null}
function onContinued(capture){if(confirmResult.done)return false
if(last!==capture){
confirmResult={done:true,reason:'stale'}
return false}
if(!safeActive()){confirmResult={done:true,reason:'locked'}
return false}
const controls=last?.controls??null
if(!controls||typeof controls.confirm!=='function'){confirmResult={done:true,reason:'no-controls'}
return false}
let answer=null
try{answer=controls.confirm()}catch(err){onError(err)
answer={ok:false,reason:'threw'}}
confirmResult={done:true,reason:answer?.ok===true?null:(answer?.reason??'unknown')}
if(answer?.ok===true)hideWhileConfirming()
return true}
function hideWhileConfirming(){const screen=last?.screen??null
if(!screen?.dataset)return false
screen.dataset.futPicksConfirming='1'
gridHost=gridHost??screen
return true}
function listen(){const box=last?.box??null
if(!box||typeof box.addEventListener!=='function')return false
const host=doc?.defaultView??doc
if(keyHost!==host&&typeof host?.addEventListener==='function'){keyHandler=(event)=>{try{keys(event)}catch(err){onError(err)}}
host.addEventListener('keydown',keyHandler,true)
echoHandler=()=>{hitBubble+=1}
doc.addEventListener('keydown',echoHandler,false)
upHandler=(event)=>{try{release(event)}catch(err){onError(err)}}
host.addEventListener('keyup',upHandler,true)
keyHost=host}
if(clickHost===box)return true
if(clickHost)unclick()
clickHandler=(event)=>{try{tap(event)}catch(err){onError(err)}}
box.addEventListener('click',clickHandler)
clickHost=box
return true}
function unclick(){if(clickHost&&clickHandler&&typeof clickHost.removeEventListener==='function'){try{clickHost.removeEventListener('click',clickHandler)}catch{}}
clickHost=null
clickHandler=null}
function unlisten(){unclick()
if(keyHost&&typeof keyHost.removeEventListener==='function'){if(keyHandler){try{keyHost.removeEventListener('keydown',keyHandler,true)}catch{}}
if(upHandler){try{keyHost.removeEventListener('keyup',upHandler,true)}catch{}}}
if(echoHandler&&typeof doc?.removeEventListener==='function'){try{doc.removeEventListener('keydown',echoHandler,false)}catch{}}
keyHost=null
keyHandler=null
echoHandler=null
upHandler=null
ateEnter=false}
function isDropKey(key){return key==='Delete'||key==='Backspace'}
function arrowStep(key){const cols=gridFit?.shape?.cols??0
const rows=gridFit?.shape?.rows??0
if(key==='ArrowRight')return 1
if(key==='ArrowLeft')return-1
if(rows>1&&cols>0&&key==='ArrowDown')return cols
if(rows>1&&cols>0&&key==='ArrowUp')return-cols
return 0}
function typing(node){const tag=String(node?.tagName??'').toLowerCase()
if(tag==='input'||tag==='textarea'||tag==='select')return true
return node?.isContentEditable===true}
function keys(event){hitCapture+=1
const why=(reason)=>{keyLast=`${event?.key??'?'}:${reason}`
return false}
const acted=(reason)=>{keyActed+=1
keyLast=`${event?.key??'?'}:${reason}`
return true}
const eat=(mark=false)=>{if(mark)ateEnter=true
event.preventDefault?.()
event.stopPropagation?.()}
if(halted)return why('halted')
if(!last)return why('no-screen')
if(!event)return false
if(event.ctrlKey||event.altKey||event.metaKey||event.shiftKey)return why('modifier')
if(typing(event.target))return why(`typing:${String(event.target?.tagName??'?').toLowerCase()}`)
const mine=event.key==='Enter'||isDropKey(event.key)||arrowStep(event.key)!==0
if(!mine)return why('not-ours')
if(event.defaultPrevented===true)return why('prevented')
const live=lastLive
if(live.length===0)return why('no-variants')
if(event.key==='Enter'){if(!safeActive())return why('locked')
if(event.repeat===true)return why('repeat')
const controls=last?.controls??null
const full=controls?.atMax?.()===true
if(cursor!==null&&controls?.isSelected?.(cursor)!==true){eat(true)
if(full&&controls?.available!==1)return why('full')
return acted(choose(cursor)?'take':'refused')}
if(full){if(event.isTrusted!==true)return why('untrusted')
eat(true)
const answer=controls.continueNow?.()??{ok:false,reason:'unavailable'}
return acted(answer?.ok===true?'go':`no-go/${answer?.reason??'unknown'}`)}
if(cursor!==null){eat(true)
return acted(choose(cursor)?'drop':'refused')}
eat(true)
return why('no-cursor')}
if(isDropKey(event.key)){if(!safeActive())return why('locked')
const controls=last?.controls??null
const at=dropTarget()
if(at.why!==null)return why(at.why)
if(at.index===null)return why('no-target')
if(controls?.isSelected?.(at.index)!==true)return why('not-taken')
eat()
return acted(choose(at.index)?'drop':'refused')}
const step=arrowStep(event.key)
if(!safeActive())return why('locked')
const at=live.findIndex((one)=>one?.index===cursor)
let next=0
if(at<0){const picked=autoResult.picked
const start=picked.length>0?picked[picked.length-1]:(last?.controls?.current?.()??null)
const where=live.findIndex((one)=>one?.index===start)
next=where>=0?where:0}
else{next=(at+step)%live.length
if(next<0)next+=live.length}
cursor=live[next]?.index??null
focus(cursor)
point()
eat()
return acted(`cursor=${cursor}`)}
function release(event){if(!ateEnter)return false
if(event?.key!=='Enter')return false
ateEnter=false
event.stopPropagation?.()
event.stopImmediatePropagation?.()
return true}
function tap(event){if(!last)return false
const controls=last.controls??null
if(!controls)return false
const target=event?.target??null
if(!target||typeof target.closest!=='function')return false
if(target.closest('.companion-carousel-item--button--unselect'))return false
const root=target.closest('.ut-companion-carousel-item-view')
if(!root)return false
const at=(last.variants??[]).findIndex((one)=>one?.root===root)
if(at<0)return false
return choose(last.variants[at].index)}
function choose(index){const controls=last?.controls??null
if(!controls)return false
focus(index)
if(controls.isSelected(index))return controls.deselect(index)?.ok===true
const answer=controls.select(index)
if(answer?.ok===true)return true
if(answer?.reason!=='full'||controls.available!==1)return false
const taken=(last.variants??[]).find((one)=>controls.isSelected(one.index))
if(!taken||controls.deselect(taken.index)?.ok!==true)return false
swaps+=1
return controls.select(index)?.ok===true}
function focus(index){const controls=last?.controls??null
if(!controls||typeof controls.makeCurrent!=='function')return false
const answer=controls.makeCurrent(index)
lastFocus={index,reason:answer?answer.reason:'unknown',ok:answer?.ok===true}
return lastFocus.ok}
function paint(variant,coins,best,owned){const card=variant?.card
if(!card)return false
let node=card.querySelector?.(OURS_SELECTOR)??null
if(!node){node=el(doc,'div',{class:'fut-pick',attrs:{'aria-hidden':'true'},dataset:{futPick:String(variant.index)}},[
el(doc,'div',{class:'fut-pick-coins',dataset:{futPickCoins:'1'}}),
el(doc,'div',{class:'fut-pick-owned',dataset:{futPickOwned:'1'}}),
])
host(card)
card.appendChild(node)}
const text=shortCoins(coins)
write(node.querySelector?.('[data-fut-pick-coins]'),text===null?'':text)
const on=best===true&&text!==null
if(node.dataset&&node.dataset.futPickBest!==(on?'1':'0'))node.dataset.futPickBest=on?'1':'0'
write(node.querySelector?.('[data-fut-pick-owned]'),owned===true?t('pickPrices.owned'):'')
const tip=[text!==null?t('priceBadge.title',{value:coins}):'',
owned===true?t('pickPrices.owned'):''].filter(Boolean).join('\n')
if(tip){name(card,tip)
if(card.dataset&&card.dataset.futPickTip!=='1')card.dataset.futPickTip='1'}
return true}
function host(card){if(card.dataset?.futPickHost==='1')return
let position=''
try{position=doc?.defaultView?.getComputedStyle?.(card)?.position??''}catch{position=''}
if(position!=='static'||!card.style)return
card.dataset.futPickHost='1'
card.dataset.futPickPosition=card.style.position??''
card.style.position='relative'}
function restore(card){
if(card?.dataset?.futPickTip==='1'){card.removeAttribute?.('title')
delete card.dataset.futPickTip}
if(card?.dataset?.futPickHost!=='1')return
if(card.style)card.style.position=card.dataset.futPickPosition??''
delete card.dataset.futPickHost
delete card.dataset.futPickPosition}
function name(node,title){if(node?.getAttribute?.('title')===title)return
node?.setAttribute?.('title',title)}
function write(node,text){if(node&&node.textContent!==text)node.textContent=text}
function drop(){for(const node of doc?.querySelectorAll?.(OURS_SELECTOR)??[]){const card=node.parentNode
node.remove?.()
restore(card)}
if(gridHost)ungrid(gridHost)
gridHost=null
for(const screen of doc?.querySelectorAll?.(GRID_SELECTOR)??[]){ungrid(screen)}
for(const screen of doc?.querySelectorAll?.(CONFIRMING_SELECTOR)??[]){ungrid(screen)}
for(const one of doc?.querySelectorAll?.(WIDE_SELECTOR)??[]){delete one.dataset.futPicksWide}
for(const one of doc?.querySelectorAll?.(LIVE_SELECTOR)??[]){delete one.dataset.futPickLive}
for(const one of doc?.querySelectorAll?.(TAKEN_SELECTOR)??[]){delete one.dataset.futPickTaken}
for(const one of doc?.querySelectorAll?.(CURSOR_SELECTOR)??[]){delete one.dataset.futPickCursor}
for(const one of doc?.querySelectorAll?.(SAID_SELECTOR)??[]){one.remove?.()}
said=false
unlisten()}
function ungrid(screen){if(!screen?.dataset)return false
delete screen.dataset.futPicksGrid
delete screen.dataset.futPicksTight
delete screen.dataset.futPicksConfirming
delete screen.dataset.futPicksChosen
const style=screen.style
if(style&&typeof style.removeProperty==='function'){for(const name of['--fut-pick-cols','--fut-pick-rows','--fut-pick-gap','--fut-pick-zoom','--fut-pick-unzoom','--fut-pick-win-min']){try{style.removeProperty(name)}catch{}}}
return true}
function forget(){drop()
last=null
lastPrices=[]
lastLive=[]
lastWaiting=0
lastBest=null
gridFit=null
fitTries=0
verified=false
regrows=0
regrowChecks=0
fitRoom=0
widened=false
floor=0
chain=0
itemsOnly=false
cursor=null
armed.clear()
answered.clear()
frameTicket+=1
lastFocus=null
autoResult={done:false,reason:'gone',picked:[]}
disarm()
confirmResult={done:false,reason:'gone'}}
function safeActive(){try{return isActive(PICK_PRICES_FEATURE)===true}catch(err){onError(err)
return false}}
function safeByPrice(){try{return isActive(PICK_BY_PRICE_FEATURE)===true}catch(err){onError(err)
return false}}
function ownedList(){const controls=last?.controls??null
if(!controls||typeof controls.owned!=='function')return null
return (last?.variants??[]).map((one)=>controls.owned(one?.index))}
function ownedLine(){const list=ownedList()
if(list===null||list.some((one)=>one===null))return'-'
return list.map((one)=>(one===true?'1':'0')).join('')||'-'}
function ratLine(){const list=lastLive.length>0?lastLive:(last?.variants??[])
if(list.length===0)return'-'
return list.map((one)=>{const facts=pickItemFacts(one?.item)
const value=facts.player===false?null:facts.rating
return Number.isSafeInteger(value)&&value>0?String(value):'-'}).join(',')}
function selLine(){const list=chosenList()
return list.length===0?'-':list.join(',')}
function priLine(){if(lastPrices.length===0)return'-'
return lastPrices.map((one)=>(Number.isSafeInteger(one)&&one>0?String(one):'-')).join(',')}
function sizeLine(){let min=null
let max=null
let at='-'
for(const one of last?.variants??[]){let rect=null
try{rect=one?.root?.getBoundingClientRect?.()??null}catch{rect=null}
if(!rect||!(rect.width>0)||!(rect.height>0))continue
const w=Math.round(rect.width)
const h=Math.round(rect.height)
if(min===null||w<min.w)min={w,h}
if(max===null||w>max.w){max={w,h}
at=String(one?.index)}}
if(min===null)return'-'
if(max.w-min.w<=2)return`${min.w}x${min.h}`
return`${min.w}x${min.h}>${max.w}x${max.h}@${at}`}
function winLine(){const screen=last?.screen??null
const view=doc?.defaultView??null
if(!screen||!view)return'-'
let width=0
try{width=Math.round(screen.getBoundingClientRect?.()?.width??0)}catch{width=0}
const room=Math.round(view.innerWidth??0)
if(!(width>0)||!(room>0))return'-'
return`${width}/${room}`}
function roomLine(){const room=fitRoom>0?fitRoom:(gridFit?.doubt?.room??0)
const wall=wallWidth()
if(!(room>0)&&!(wall>0))return'-'
return`${room>0?Math.round(room):'-'}/${wall>0?Math.round(wall):'-'}`}
function upLine(){const screen=last?.screen??null
if(!screen)return'-'
const out=[]
let node=screen
for(let level=0;level<6&&node;level+=1){let width=0
try{width=Math.round(node.getBoundingClientRect?.()?.width??0)}catch{width=0}
out.push(width>0?String(width):'-')
if(node.dataset&&node.dataset.futPicksWide!=='1'&&level>0)break
node=node.parentElement??null}
return out.join('/')||'-'}
function line(){const g=gridFit
const size=(one)=>(one?`${one.width}x${one.height}`:'-')
return[`feature=${safeActive()?'on':'OFF'}`,
`screen=${last?'caught':'none'}`,
`variants=${(last?.variants??[]).length}`,
`badges=${doc?.querySelectorAll?.(OURS_SELECTOR)?.length??0}`,
`prices=${lastPrices.filter((one)=>one!==null).length}`,
`halted=${halted??'no'}`,
`grid=${g?.shape?`${g.shape.cols}x${g.shape.rows}`:`none(${g?.reason??'pending'})`}`,
`zoom=${g?.zoom??'-'}`,
`box=${size(g?.box)}`,
`card=${size(g?.card)}`,
`size=${sizeLine()}`,
`win=${winLine()}`,
`up=${upLine()}`,
`room=${roomLine()}`,
`doubt=${doubts}/${regrows}`,
`min=${floor>0?floor:'-'}/${floorTries}`,
`roots=${doc?.querySelectorAll?.('.ut-player-picks-view')?.length??0}`,
`mode=${safeByPrice()?'price':'rating'}`,
`auto=${autoResult.reason??'done'}`,
`picked=${autoResult.picked.length}`,
`key=${cursor===null?'-':cursor}`,
`keys=${keyHost!==null?'on':'off'}`,
`khit=${hitCapture}/${hitBubble}`,
`kdo=${keyActed}`,
`klast=${keyLast===''?'-':keyLast}`,
`ok2=${confirmResult.done?(confirmResult.reason??'ok'):confirmResult.reason}`,
`own=${ownedLine()}`,
`rat=${ratLine()}`,
`pri=${priLine()}`,
`pick=${autoResult.picked.length===0?'-':autoResult.picked.join(',')}`,
`sel=${selLine()}`,
`await=${lastWaiting}`,
`N=${last?.controls?.available??'-'}`,
`cur=${last?.controls?.current?.()??'-'}`,
`say=${lastFocus?`${lastFocus.index}:${lastFocus.reason??'ok'}`:'-'}`,
`swap=${swaps}`,
`pass=${lastResult.reason??'ok'}`,
`passes=${halted?haltedAt:passes}`,
`by=${wakes.show}s+${wakes.price}p+${wakes.dom}d+${wakes.lang}l`,
`woke=${selfWoke}self/${otherWoke}other`,
`idle=${idle}`,
`items=${itemsOnly?'yes':'no'}`].join(' ')}
function measure(){const view=doc?.defaultView??null
const out=[]
for(const node of doc?.querySelectorAll?.(OURS_SELECTOR)??[]){const card=node.parentNode??null
const chip=node.querySelector?.('[data-fut-pick-coins]')??null
let position='?'
let overflow='?'
let cut=null
let width=null
try{position=view?.getComputedStyle?.(node)?.position??'?'
overflow=view?.getComputedStyle?.(card)?.overflow??'?'}catch{}
try{const one=chip?.getBoundingClientRect?.()
const two=card?.getBoundingClientRect?.()
if(one&&two){cut=Math.round(two.top-one.top)
width=Math.round(two.width)}}catch{}
out.push({index:Number(node.dataset?.futPick),best:node.dataset?.futPickBest==='1',
coins:chip?.textContent??'',position,cardOverflow:overflow,cut,cardWidth:width,
hosted:card?.dataset?.futPickHost==='1'})}
return out}
return{apply,refresh,relabel,
state:()=>({
line:line(),
active:safeActive(),lastResult,captured:Boolean(last),
variants:(last?.variants??[]).map((one)=>({index:one.index,...pickItemFacts(one.item),
definition:definitionOf(one.item),
owned:last?.controls?.owned?.(one.index)??null})),
prices:[...lastPrices],best:lastBest,renders,
nodes:doc?.querySelectorAll?.(OURS_SELECTOR)?.length??0,
styles:Boolean(doc?.getElementById?.(PICK_LINK_ID)),
grid:{on:gridHost!==null&&gridHost.dataset?.futPicksGrid==='1',calls:fitCalls,tries:fitTries,chain,ticket:frameTicket,armed:framed,shape:null,zoom:null,box:null,card:null,reason:'pending',doubts,regrows,room:fitRoom,floor,floorTries,...(gridFit??{})},
halted,passes:halted?haltedAt:passes,
wakes:{...wakes},woke:{self:selfWoke,other:otherWoke,idle},
items:itemsOnly,said:(doc?.querySelectorAll?.(SAID_SELECTOR)?.length??0)>0,
auto:{...autoResult,byPrice:safeByPrice()},
keyboard:{cursor,listening:keyHost!==null,capture:hitCapture,bubble:hitBubble,acted:keyActed,last:keyLast||null},
confirm:{...confirmResult,confirming:last?.controls?.confirming?.()===true},
controls:last?.controls?{available:last.controls.available,selected:last.controls.count(),atMax:last.controls.atMax(),
current:last.controls.current?.()??null}:null,
focus:lastFocus?{...lastFocus}:null,
marks:measure()}),
dispose(){forget()}}}
