import{findMinBin,DEFAULT_MAX_REQUESTS as MIN_BIN_MAX_REQUESTS} from './min-bin.js'
import{normalizeKey} from './price-source.js'
export const MARKET_PRICE_FEATURES=Object.freeze(['priceSources','minBinSearch'])
export const MARKET_KEY_PREFIX='ea'
export const DEFAULT_THROTTLE_MS=30_000
export const DEFAULT_MAX_REQUESTS=MIN_BIN_MAX_REQUESTS
export function marketCacheKey(definitionId){const id=normalizeId(definitionId)
return id===null?null:`${MARKET_KEY_PREFIX}:${id}`
}
export function idFromMarketKey(key){const k=normalizeKey(key)
if(k===null)return null
if(!k.startsWith(`${MARKET_KEY_PREFIX}:`)) return normalizeId(k)
return normalizeId(k.slice(MARKET_KEY_PREFIX.length+1))}
export function criteriaForCard(id,type=null){const criteria={defId:[id]}
if(typeof type==='string'&&type!=='')criteria.type=type
return criteria}
export function createMarketPriceSource(deps={}){const{market,clock}=deps
if(typeof market!=='function') throw new Error('market-price: нужен доступ к рынку')
if(!clock||typeof clock.now!=='function'||typeof clock.sleep!=='function'){throw new Error('market-price: нужны часы (правило 6 NIGHT_BRIEF)')}
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const throttleMs=Number.isFinite(deps.throttleMs)&&deps.throttleMs>=0
?deps.throttleMs:DEFAULT_THROTTLE_MS
const maxRequests=Number.isFinite(deps.maxRequests)&&deps.maxRequests>0
?deps.maxRequests:DEFAULT_MAX_REQUESTS
const budget=deps.budget??null
const note=typeof deps.note==='function'?deps.note:undefined
const rng=typeof deps.rng==='function'?deps.rng:undefined
const lastAt=new Map()
let measurements=0
let requests=0
const forget=(now)=>{for(const[id,at]of lastAt){if(now-at>=throttleMs)lastAt.delete(id)}}
const waitMs=(key=null)=>{const now=clock.now()
forget(now)
const id=key===null||key===undefined?null:idFromMarketKey(key)
const at=id===null?undefined:lastAt.get(id)
const own=at===undefined?0:Math.max(0,throttleMs-(now-at))
const shared=Number(budget?.waitMs?.())||0
return Math.max(own,shared)}
async function source(key,hint=null){const id=idFromMarketKey(key)
if(id===null) return refuse('bad-key')
for(const feature of MARKET_PRICE_FEATURES){if(!isActive(feature)) return refuse('off')}
{const waiting=waitMs(id)
if(waiting>0) return refuse('throttled',null,null,waiting)}
const adapter=market()
if(!adapter||typeof adapter.searchTransferMarket!=='function') return refuse('no-market')
lastAt.set(id,clock.now())
measurements+=1
let found
try{found=await findMinBin({adapter,criteria:criteriaForCard(id,hint?.type??null),clock,rng,budget,prior:hint?.prior??null,maxRequests,ceiling:deps.ceiling,note,recentMs:0,
...(typeof hint?.cancelled==='function'?{cancelled:hint.cancelled}:{})})}catch(err){return refuse(String(err?.message??err))}
requests+=found.requests
if(found.stoppedBy==='no-listings') return{ok:true,price:null,reason:'no-listings'}
if(found.stoppedBy!=='converged') return refuse(found.stoppedBy,found.error,found.requests,found.waitMs)
return{ok:true,price:found.price,reason:null}}
return{source,
ready:(key=null)=>waitMs(key)===0,waitMs,
stats:()=>{forget(clock.now())
return{measurements,requests,cooling:lastAt.size}}}}
const refuse=(reason,err=null,requests=null,wait=null)=>{const count=Number.isSafeInteger(requests)&&requests>0?requests:null
const waitMs=Number.isFinite(wait)&&wait>0?Math.round(wait):null
const paced=waitMs===null?{}:{waitMs}
if((err===null||err===undefined)&&count===null)return{ok:false,price:null,reason,...paced}
const status=typeof err?.status==='number'?err.status:null
const text=err===null||err===undefined?'':String(err?.message??err).slice(0,120)
const said=status===null?text:`${status}: ${text}`
return{ok:false,price:null,reason,...paced,detail:count===null?said:`${said}${said===''?'':' '}(запросов ${count})`}}
function normalizeId(value){const n=typeof value==='string'?Number(value.trim()):value
if(typeof n!=='number'||!Number.isFinite(n)) return null
const id=Math.trunc(n)
return id>0?id:null}
