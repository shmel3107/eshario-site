import{extractItems} from '../automation/seller.js'
import{startingBidFor} from '../automation/pricing.js'
import{MIN_PRICE} from './price-grid.js'
import{itemIdsReceiptMatches,moveReceiptMatches} from '../automation/item-receipts.js'
import{isDoorRefusal} from '../adapter/action-door.js'
import{stopReasonKey} from '../automation/stop-reasons.js'
import{markListed,isListed} from '../automation/listed-mark.js'
export const LOOT_CAP=50
export const LOOT_DURATION_S=3600
export const LOOT_PILE_CLUB='club'
export function lootNameOf(item){let data=null
try{data=typeof item?.getStaticData==='function'?item.getStaticData():null}catch{return ''}
if(!data||typeof data!=='object')return ''
try{const name=data.name
if(typeof name==='string'&&name.trim()!=='')return name.trim()
const full=typeof data.getFullName==='function'?data.getFullName():''
return typeof full==='string'?full.trim():''}catch{return ''}}
function idOf(value){const raw=typeof value==='string'&&/^\d+$/.test(value.trim())?Number(value.trim()):value
const n=Number(raw)
return Number.isSafeInteger(n)&&n>0?n:null}
function coins(value){const n=Math.round(Number(value))
return Number.isSafeInteger(n)&&n>0?n:0}
export function lootRowOf(entry){const item=entry?.item
let rating=null
let definitionId=null
try{const raw=Number(item?.rating)
rating=Number.isSafeInteger(raw)&&raw>0?raw:null}catch{rating=null}
try{definitionId=idOf(item?.definitionId)}catch{definitionId=null}
return{id:idOf(item?.id),definitionId,name:lootNameOf(item),rating,
price:coins(entry?.price),listed:isListed(item),pile:entry?.pile??null}}
export function createHuntLoot(deps={}){const market=typeof deps.market==='function'?deps.market:()=>null
const budget=typeof deps.budget==='function'?deps.budget:()=>null
const sessionAt=typeof deps.sessionAt==='function'?deps.sessionAt:()=>null
const clubPile=deps.clubPile
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const caught=[]
let notes=0
let evicted=0
let sold=0
let moved=0
let refused=0
const busy=new Set()
const stampNow=()=>{let raw=null
try{raw=sessionAt()}catch(err){onError(err)
return null}
return typeof raw==='number'&&Number.isFinite(raw)?raw:null}
const refusal=(key,params)=>({ok:false,notice:{key,params:params??{}}})
const entryOf=(id)=>{const at=stampNow()
if(at===null)return null
return caught.find((row)=>row.at===at&&idOf(row.item?.id)===id)??null}
const doorNotice=(err)=>{refused+=1
const reason=err?.door?.reason
return refusal('snipe.lootDoor',{reason:typeof reason==='string'?reason:'unknown'})}
const slot=(count)=>{const owner=budget()
if(!owner||typeof owner.call!=='function')return refusal(stopReasonKey('counter-unavailable'))
let answer=null
try{answer=owner.call(count)}catch(err){onError(err)
return refusal(stopReasonKey('counter-unavailable'))}
return answer===null?null:refusal(stopReasonKey(answer))}
return{
note(item,price){if(!item||typeof item!=='object')return false
const id=idOf(item?.id)
if(id===null)return false
const at=stampNow()
if(at===null)return false
const known=caught.find((row)=>row.at===at&&idOf(row.item?.id)===id)
if(known){known.item=item
return false}
caught.push({item,price:coins(price),at,pile:null})
notes+=1
while(caught.length>LOOT_CAP){caught.shift()
evicted+=1}
return true},
loot(){const at=stampNow()
if(at===null)return[]
return caught.filter((row)=>row.at===at).map(lootRowOf)},
async sell(row,price){const id=idOf(row?.id)
if(id===null)return refusal('snipe.lootGone')
const buyNow=coins(price)
if(buyNow<=0)return refusal('snipe.lootNoMarket')
const entry=entryOf(id)
if(entry===null)return refusal('snipe.lootGone')
if(isListed(entry.item))return refusal('snipe.lootAlready')
const startingBid=startingBidFor(buyNow)
if(startingBid===null)return refusal('snipe.lootBelowMin',{min:MIN_PRICE})
const live=market()
if(!live||typeof live.list!=='function')return refusal('snipe.lootNoDoor')
if(busy.has(id))return refusal('snipe.lootBusy')
busy.add(id)
try{
let rows=null
if(typeof live.requestTransferItems==='function'){const denied=slot(1)
if(denied)return denied
try{rows=extractItems(await live.requestTransferItems())}catch(err){if(isDoorRefusal(err))return doorNotice(err)
onError(err)
return refusal('snipe.lootRefused')}}
const inList=Array.isArray(rows)&&rows.some((item)=>idOf(item?.id)===id)
const denied=slot(1)
if(denied)return denied
const receipt=await live.list(entry.item,startingBid,buyNow,LOOT_DURATION_S,{fresh:!inList,rows})
if(!itemIdsReceiptMatches(receipt,[entry.item]))return refusal('snipe.lootRefused')
markListed(entry.item)
sold+=1
return{ok:true,notice:null}}catch(err){if(isDoorRefusal(err))return doorNotice(err)
onError(err)
return refusal('snipe.lootRefused')}finally{busy.delete(id)}},
async club(row){const id=idOf(row?.id)
if(id===null)return refusal('snipe.lootGone')
const entry=entryOf(id)
if(entry===null)return refusal('snipe.lootGone')
if(entry.pile===LOOT_PILE_CLUB)return refusal('snipe.lootAlready')
const live=market()
if(!live||typeof live.move!=='function')return refusal('snipe.lootNoDoor')
if(busy.has(id))return refusal('snipe.lootBusy')
busy.add(id)
try{const denied=slot(1)
if(denied)return denied
const receipt=await live.move([entry.item],clubPile)
if(!moveReceiptMatches(receipt,[entry.item]))return refusal('snipe.lootRefused')
entry.pile=LOOT_PILE_CLUB
moved+=1
return{ok:true,notice:null}}catch(err){if(isDoorRefusal(err))return doorNotice(err)
onError(err)
return refusal('snipe.lootRefused')}finally{busy.delete(id)}},
state(){const at=stampNow()
return{session:at,held:caught.length,mine:at===null?0:caught.filter((row)=>row.at===at).length,
notes,evicted,sold,moved,refused,busy:busy.size,cap:LOOT_CAP}}}}
