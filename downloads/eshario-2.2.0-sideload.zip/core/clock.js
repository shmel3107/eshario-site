export function createClock(){return{now:()=>Date.now(),sleep:(ms)=>new Promise((resolve)=>{setTimeout(resolve,Math.max(0,Number(ms)||0))})}}
