export const LIST_PAUSE_MIN_MS=1000
export const LIST_PAUSE_MAX_MS=1300
export function listPauseMs(random){return bandPauseMs(LIST_PAUSE_MIN_MS,LIST_PAUSE_MAX_MS,random)}
export function bandPauseMs(minMs,maxMs,random){const low=Number.isFinite(minMs)&&minMs>0?Math.round(minMs):0
const high=Number.isFinite(maxMs)&&maxMs>low?Math.round(maxMs):low
if(high===low)return low
const draw=typeof random==='function'?random:Math.random
let roll=Number.NaN
try{roll=draw()}catch{return high}
if(typeof roll!=='number'||!Number.isFinite(roll))return high
const inside=Math.min(1,Math.max(0,roll))
return Math.min(high,low+Math.floor(inside*(high-low+1)))}
export const RETRY_SPREAD_SHARE=0.2
export function spreadBand(ms,share){const middle=Number.isFinite(ms)&&ms>0?ms:0
const part=Number.isFinite(share)&&share>0?Math.min(1,share):0
return Object.freeze({minMs:Math.round(middle*(1-part)),maxMs:Math.round(middle*(1+part))})}
export function paceBandProblems(bands){const bad=[]
const list=Array.isArray(bands)?bands:[]
if(list.length===0)return['пусто']
for(const one of list){const name=String(one?.name??'безымянный')
const min=Number(one?.minMs)
const max=Number(one?.maxMs)
if(!Number.isFinite(min)||!Number.isFinite(max)||min>max){bad.push(`${name}: полоса`)
continue}
if(one?.spread!==false&&min===max)bad.push(`${name}: метроном`)
const floor=Number(one?.floorMs)
if(Number.isFinite(floor)&&min<floor)bad.push(`${name}: пол`)
const named=Number(one?.namedMs)
if(Number.isFinite(named)&&(named<min||named>max))bad.push(`${name}: имя вне полосы`)}
return bad}
