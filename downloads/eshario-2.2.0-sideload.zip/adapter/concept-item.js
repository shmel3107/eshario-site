export const VIRTUAL_MARK='futVirtual'
import{findDoor} from './doors.js'
import{eaTable} from './search.js'
const positive=(value)=>(Number.isSafeInteger(value)&&value>0?value:null)
const ITEM_ENTITY_DOOR=Object.freeze({name:'item-entity',
declares:['isPlayer','getAuctionData','getBaseRating'],want:'class'})
const ITEM_TYPES=Object.freeze({NONE:'none',PLAYER:'player',MANAGER:'manager',MISC:'misc'})
const ITEM_TYPE_KEYS=Object.freeze(['PLAYER','MANAGER','NONE','MISC'])
const ITEM_SUBTYPES=Object.freeze({NONE:0,PLAYER:1,TEAM:2})
const ITEM_SUBTYPE_KEYS=Object.freeze(['NONE','PLAYER','TEAM'])
const itemTypes=(win)=>eaTable(win,'item-type',ITEM_TYPE_KEYS,ITEM_TYPES)
const itemSubtypes=(win)=>eaTable(win,'item-subtype',ITEM_SUBTYPE_KEYS,ITEM_SUBTYPES,true)
function entityClass(win){if(!win||(typeof win!=='object'&&typeof win!=='function'))return null
const found=findDoor(win,ITEM_ENTITY_DOOR)
return found.ok&&typeof found.value==='function'?found.value:null}
export function createConceptItem(win,source={}){const Entity=entityClass(win)
const definitionId=positive(source?.definitionId)
const playerType=itemTypes(win).PLAYER
if(typeof Entity!=='function'||definitionId===null||playerType===undefined)return null
const data={id:definitionId,definitionId,concept:true,type:playerType,
stackCount:1,untradeableCount:0,tradable:true}
data.subtype=itemSubtypes(win).PLAYER
const rating=positive(source?.rating)
if(rating!==null)data.rating=rating
const rareflag=source?.rareflag
if(Number.isSafeInteger(rareflag)&&rareflag>=0)data.rareflag=rareflag
const groups=source?.groups
if(Array.isArray(groups)&&groups.length>0)data.groups=[...groups]
const attrs=source?.attrs
if(attrs&&typeof attrs==='object'){for(const key of['leagueId','nationId','teamId']){if(positive(attrs[key])!==null)data[key]=attrs[key]}
if(Array.isArray(attrs.possiblePositions)&&attrs.possiblePositions.length>0){data.possiblePositions=[...attrs.possiblePositions]
data.preferredPosition=attrs.possiblePositions[0]}}
let item
try{item=new Entity(data)}catch{return null}
try{item[VIRTUAL_MARK]=true}catch{return null}
return item}
export function conceptSupport(win){const playerType=itemTypes(win).PLAYER
return{entity:typeof entityClass(win),itemType:typeof playerType,
playerType}}
export function isVirtualConcept(item){try{return item?.[VIRTUAL_MARK]===true&&item?.concept===true}catch{return false}}
export function isConceptItem(item){try{return item?.concept===true||item?.dream===true}catch{return false}}
