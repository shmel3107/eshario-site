import{findDoor} from './doors.js'
export const ITEM_CELL_DOOR=Object.freeze({name:'item-cell',
declares:['setData','getData','setComparisonData'],
methods:['getRootElement'],want:'class'})
function cellClassOf(win){const found=findDoor(win,ITEM_CELL_DOOR)
return found.ok?found.value:null}
const installations=new WeakMap()
export function installItemCellCapture(win,onCapture=()=>{}){const proto=cellClassOf(win)?.prototype
if(!proto||typeof proto.setData!=='function'||typeof proto.getData!=='function'||typeof proto.getRootElement!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let installation=installations.get(proto)
if(!installation){const original=proto.setData
const listeners=new Set()
const wrapped=function(t,e,i){const result=original.call(this,t,e,i)
const item=t
let row=null
try{row=this.getData()===item?this.getRootElement():null}catch{}
if(row&&item&&typeof item==='object'){for(const listener of listeners){try{listener(row,item)}catch{}}}
return result}
proto.setData=wrapped
installation={original,wrapped,listeners}
installations.set(proto,installation)}
installation.listeners.add(onCapture)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.listeners.delete(onCapture)
if(installation.listeners.size===0&&proto.setData===installation.wrapped){proto.setData=installation.original
installations.delete(proto)}}}}
export function createItemCell(win,item){const Cell=cellClassOf(win)
if(typeof Cell!=='function'||!item||typeof item!=='object')return null
let view=null
try{view=new Cell()}catch{return null}
try{view._generate()}catch{return null}
let painted=true
let why=null
try{view.setData(item)
view.render()}catch(err){painted=false
why=String(err?.message??err)}
let root=null
try{root=view.getRootElement?.()??null}catch{root=null}
if(!root){try{view.dealloc?.()}catch{/* уносим молча: отдавать всё равно нечего */}
return null}
return{root,painted,why,
dispose(){try{view.dealloc?.()}catch{/* уже унесён вместе со страницей */}}}}
