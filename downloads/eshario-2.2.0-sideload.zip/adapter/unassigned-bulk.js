import{stopOnEaLimit,stopsRequest,EA_LIMIT,askDayBudget} from '../features/day-budget.js'
import{reviewAction,createDoorConsent,doorConsentKey,ALLOWED,UNKNOWN} from './action-door.js'
import{itemIdOf} from './unassigned-screen.js'
export const BULK_DOORS=Object.freeze(['club','storage','quickSellItems','quickSell'])
const MOVE_DOORS=Object.freeze({club:'CLUB',storage:'STORAGE'})
const MOVE_ANSWERS=Object.freeze({club:'onMoveToClubComplete',storage:'onMoveToStorageComplete'})
const DOOR_REASONS=Object.freeze({'feature-off':'no-storage'})
export const BULK_DANGER=Object.freeze(new Set(['quickSellItems','quickSell']))
const STEP_DOORS=Object.freeze({club:['club'],storage:['storage'],discard:['quickSellItems','quickSell']})
const STORAGE_PICK='getUntradeableDuplicates'
export const BUSY_FRAMES=600
const int=(value)=>(Number.isSafeInteger(value)?value:null)
const sameIds=(a,b)=>Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((id,at)=>id===b[at])
export function doorItems(viewmodel,door){if(!viewmodel||typeof viewmodel.values!=='function')return null
const knife=BULK_DANGER.has(door)
let raw=null
try{
if(door==='club')raw=viewmodel.getMovableItems?.()
else if(door==='storage')raw=viewmodel.getUntradeableDuplicates?.()
else if(door==='quickSellItems')raw=viewmodel.getRegularItemsSection?.()
else if(door==='quickSell')raw=viewmodel.values()
else return null}catch{return null}
if(!Array.isArray(raw))return null
if(knife)raw=raw.filter((item)=>{try{return item?.isDiscardable?.()===true&&item?.isDuplicateLoanPlayer?.()!==true}catch{return false}})
const items=[]
const ids=[]
const blind=[]
let coins=0
for(const item of raw){const id=int(item?.id)
if(id===null){blind.push(item)
continue}
items.push(item)
ids.push(id)
coins+=int(item?.discardValue)??0}
return{items,ids,coins,unreadable:blind.length,blind}}
function blindCount(screen,picked){const seen=new Set()
let count=0
for(const side of[picked,screen]){const list=side?.blind
if(!Array.isArray(list)){count+=int(side?.unreadable)??0
continue}
for(const one of list){if(one!==null&&typeof one==='object'){if(seen.has(one))continue
seen.add(one)}
count+=1}}
return count}
function ratingOf(item){let value=null
try{value=item?.rating}catch{return null}
return Number.isSafeInteger(value)&&value>=0?value:null}
function fitByRating(picked,room){const items=Array.isArray(picked?.items)?picked.items:[]
const ids=Array.isArray(picked?.ids)?picked.ids:[]
const take=int(room)
if(take===null||take>=ids.length)return{items,ids,left:0}
if(take<=0)return{items:[],ids:[],left:ids.length}
const order=ids.map((id,at)=>({at,rating:ratingOf(items[at])}))
order.sort((a,b)=>{if(a.rating===b.rating)return a.at-b.at
if(a.rating===null)return 1
if(b.rating===null)return -1
return b.rating-a.rating})
const chosen=order.slice(0,take).map((one)=>one.at).sort((a,b)=>a-b)
return{items:chosen.map((at)=>items[at]),ids:chosen.map((at)=>ids[at]),left:ids.length-take}}
export function bulkPreview(screen,door){const bad=(reason,extra={})=>({ok:false,reason,door,cards:0,coins:0,locked:0,stays:0,total:0,
verdict:'forbidden',fits:null,need:0,used:null,size:null,ids:[],send:[],partial:false,left:0,unreadable:0,...extra})
if(!BULK_DOORS.includes(door))return bad('unknown-door')
if(!screen)return bad('no-screen')
if(door==='storage'&&screen.storage===false)return bad('no-storage')
const total=Array.isArray(screen.cards)?screen.cards.length:0
if(total===0)return bad('empty')
const picked=doorItems(screen.viewmodel,door)
if(!picked)return bad('no-screen')
const blind=MOVE_DOORS[door]===undefined?0:blindCount(screen,picked)
if(picked.ids.length===0)return bad(blind>0?'unreadable-items':'nothing-to-do',{stays:total,total,unreadable:blind,
verdict:blind>0?UNKNOWN:'forbidden'})
const plan={ok:true,reason:null,door,cards:picked.ids.length,coins:picked.coins,locked:0,
stays:Math.max(0,total-picked.ids.length),total,unreadable:blind,
verdict:ALLOWED,fits:null,need:picked.ids.length,used:null,size:null,partial:false,left:0,
ids:picked.ids,
send:picked.ids}
const destination=MOVE_DOORS[door]??null
const ask=(items)=>(destination===null
?reviewAction({win:screen.win,action:'discard',items})
:reviewAction({win:screen.win,action:'move',destination,items,unreadable:blind}))
const review=ask(picked.items)
const numbers={verdict:review.verdict,fits:review.fits,need:review.need,used:review.used,size:review.size,
locked:review.locked}
if(review.verdict===ALLOWED)return{...plan,...numbers}
const fits=int(review.fits)
if(review.reason==='capacity'&&fits!==null&&fits>0&&fits<picked.ids.length){const cut=fitByRating(picked,fits)
const second=ask(cut.items)
if(second.verdict===ALLOWED)return{...plan,verdict:ALLOWED,locked:second.locked,
partial:true,cards:cut.ids.length,coins:cut.items.reduce((sum,item)=>sum+(int(item?.discardValue)??0),0),
left:cut.left,stays:Math.max(0,total-cut.ids.length),
need:picked.ids.length,fits,used:review.used,size:review.size,send:cut.ids}}
return{...plan,...numbers,ok:false,reason:DOOR_REASONS[review.reason]??review.reason}}
function sendSubset(viewmodel,controller,items){if(!viewmodel||typeof viewmodel!=='object')return{ok:false,reason:'guard-unavailable',asked:0}
const own=Object.prototype.hasOwnProperty.call(viewmodel,STORAGE_PICK)
const before=own?viewmodel[STORAGE_PICK]:null
let asked=0
try{viewmodel[STORAGE_PICK]=function(){asked+=1
return items.slice()}}
catch{return{ok:false,reason:'guard-unavailable',asked:0}}
try{controller.confirmStoreUntradeablesTapped()}
finally{if(own)viewmodel[STORAGE_PICK]=before
else delete viewmodel[STORAGE_PICK]}
return asked>0?{ok:true,reason:null,asked}:{ok:false,reason:'failed',asked}}
function answerCount(response,ours){const raw=response?.data?.itemIds
if(!Array.isArray(raw))return{said:null,took:0}
let took=0
for(const entry of raw){const id=itemIdOf(entry&&typeof entry==='object'?entry.id:entry)
if(id!==null&&ours.has(id))took+=1}
return{said:raw.length,took}}
export function createUnassignedBulk(deps={}){const readScreen=typeof deps.screen==='function'?deps.screen:()=>null
const win=deps.win??null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const onKnife=typeof deps.onKnife==='function'?deps.onKnife:()=>{}
const beforeKnife=typeof deps.beforeKnife==='function'?deps.beforeKnife:()=>null
const consent=createDoorConsent({now:deps.now,windowMs:deps.consentMs})
const budget=deps.budget??null
const DOOR_CALLS=2
const grantDoor=()=>askDayBudget(budget,DOOR_CALLS)
let eaLimit=null
let limits=0
let busy=null
let receipt=0
let opened=0
let refused=0
let uncertain=0
let answers=0
let byAnswer=0
let byScreen=0
let deaf=0
let lastAnswer=null
let ear=null
let early=0
let unpressed=0
let lastUnpressed=null
let waiters=[]
const wake=(answer)=>{if(waiters.length===0)return
const list=waiters
waiters=[]
for(const done of list){try{done(answer)}catch(err){onError(err)}}}
const doorWait=()=>new Promise((done)=>{if(busy===null){done({ok:true,reason:null,took:null,said:null})
return}
if(busy.expired===true){done({ok:false,reason:'no-answer',took:null,said:null})
return}
waiters.push(done)})
const tick=()=>{if(!busy)return
busy.frames+=1
if(busy.frames>=BUSY_FRAMES){busy.expired=true
wake({ok:false,reason:'no-answer',took:null,said:null})
return}
const frame=win?.requestAnimationFrame
if(typeof frame!=='function'){busy.expired=true
wake({ok:false,reason:'no-answer',took:null,said:null})
return}
try{frame.call(win,tick)}catch(err){onError(err)
busy.expired=true
wake({ok:false,reason:'no-answer',took:null,said:null})}}
const unhear=()=>{if(ear===null)return
const{controller,name,before,tail,get,origin}=ear
ear=null
try{let now=null
try{now=Object.getOwnPropertyDescriptor(controller,name)??null}catch{return}
if(now===null||now.get!==get)return
if(before!==null){Object.defineProperty(controller,name,'value' in before?{...before,value:tail.fn}:before)
return}
delete controller[name]
if(tail.fn!==origin)controller[name]=tail.fn}catch(err){onError(err)}}
const heard=(door,ticket,response)=>{answers+=1
if(stopOnEaLimit(budget,response)!==null){eaLimit=EA_LIMIT
limits+=1}
const ours=busy!==null&&busy.receipt===ticket?busy.ids:new Set()
const counted=answerCount(response,ours)
lastAnswer={door,ok:response?.success===true,sent:ours.size,said:counted.said,took:counted.took}
if(busy!==null&&busy.receipt===ticket&&busy.door===door){byAnswer+=1
busy=null
unhear()
wake({ok:true,reason:null,took:counted.took,said:counted.said})
return}
if(ticket>receipt)early=ticket}
const hear=(controller,door,ticket)=>{unhear()
const name=MOVE_ANSWERS[door]
if(name===undefined||controller===null||typeof controller!=='object')return false
let native=null
try{native=controller[name]}catch{return false}
if(typeof native!=='function')return false
let before=null
try{before=Object.getOwnPropertyDescriptor(controller,name)??null}catch{return false}
const tail={fn:native}
const wrapped=function(){try{heard(door,ticket,arguments[1])}catch(err){onError(err)}
return tail.fn.apply(this,arguments)}
let taken=false
const get=function(){if(taken)return tail.fn
taken=true
return wrapped}
const set=function(value){tail.fn=value}
try{Object.defineProperty(controller,name,{get,set,configurable:true,enumerable:before===null?true:before.enumerable===true})}catch{return false}
ear={controller,name,before,tail,get,origin:native}
return true}
const hold=(door,ids,blind)=>{receipt+=1
if(early===receipt){early=0
byAnswer+=1
unhear()
return}
busy={door,frames:0,ids:new Set(ids),blind:int(blind)??0,receipt,expired:false}
tick()}
const ourCardsGone=(ids)=>{const screen=readScreen()
if(!screen?.viewmodel)return null
let live=null
try{live=screen.viewmodel.values()}catch{return null}
if(!Array.isArray(live))return null
const still=new Set()
for(const item of live){const id=itemIdOf(item?.id)
if(id!==null)still.add(id)}
for(const id of ids){if(still.has(id))return false}
return true}
const refuse=(plan)=>{refused+=1
unhear()
return{...plan,ok:false,reason:'guard-unavailable'}}
const stepStopWord=(plan,match)=>{if(match===null)return null
const same=sameIds(plan.ids,match)
const blind=(int(plan.unreadable)??0)>0
if(same&&!blind&&plan.partial!==true&&plan.ok===true&&plan.verdict===ALLOWED)return null
return !same?'no-match':blind?'blind-items':plan.partial===true?'no-room':(plan.reason??plan.verdict)}
const openDoor=(door,match,granted=null)=>{const pending=busy!==null&&busy.expired!==true
if(pending){refused+=1
return{ok:false,reason:'busy',door,cards:0,coins:0,locked:0,stays:0,total:0,verdict:'forbidden',fits:null,need:0,used:null,size:null,ids:[],send:[],partial:false,left:0,unreadable:0}}
const screen=readScreen()
const plan=bulkPreview(screen,door)
const destination=MOVE_DOORS[door]??null
const askHand=(reason,ids,unreadable)=>consent.ask(doorConsentKey({action:door,reason,destination,ids,unreadable}))
if(match!==null){const stop=stepStopWord(plan,match)
if(stop!==null){refused+=1
return{...plan,ok:false,reason:stop}}}
else if(plan.ok!==true&&plan.verdict!==UNKNOWN){refused+=1
consent.forget()
return plan}
if(busy!==null){if(match!==null){refused+=1
return{...plan,ok:false,reason:'busy'}}
if(!askHand('busy-timeout',[...busy.ids],busy.blind)){refused+=1
uncertain+=1
return{...plan,ok:false,uncertain:'busy-timeout',confirmable:true}}
busy=null
unhear()}
if(match===null){if(plan.verdict===UNKNOWN){if(!askHand(plan.reason,plan.ids,plan.unreadable)){refused+=1
uncertain+=1
return{...plan,ok:false,uncertain:plan.reason,confirmable:true}}}
else consent.forget()}
if(screen.box?.isConnected===false){refused+=1
return{...plan,ok:false,reason:'gone'}}
const controller=screen.controller
const picked=doorItems(screen.viewmodel,door)
if(!picked||!sameIds(picked.ids,plan.ids)){refused+=1
return{...plan,ok:false,reason:'stale'}}
const blindNow=destination===null?0:blindCount(screen,picked)
if(blindNow!==(int(plan.unreadable)??0)){refused+=1
return{...plan,ok:false,reason:'stale',unreadable:blindNow}}
const going=plan.partial===true?fitByRating(picked,plan.fits):picked
if(!sameIds(going.ids,plan.send)){refused+=1
return{...plan,ok:false,reason:'stale'}}
const again=destination===null
?reviewAction({win:screen.win,action:'discard',items:going.items})
:reviewAction({win:screen.win,action:'move',destination,items:going.items,unreadable:blindNow})
if(again.verdict!==ALLOWED&&!(again.verdict===UNKNOWN&&again.reason===plan.reason)){refused+=1
return{...plan,ok:false,reason:again.verdict===UNKNOWN?'stale':(DOOR_REASONS[again.reason]??again.reason),verdict:again.verdict,fits:again.fits,need:again.need,used:again.used,size:again.size}}
if(match===null)void askDayBudget(budget,DOOR_CALLS)
else if(granted!==null){refused+=1
return{...plan,ok:false,reason:granted}}
const ticket=receipt+1
const listening=hear(controller,door,ticket)
let seenBefore=null
try{
if(door==='club'){if(typeof controller?.storeInClub!=='function')return refuse(plan)
controller.storeInClub()}
else if(door==='storage'){if(typeof controller?.confirmStoreUntradeablesTapped!=='function')return refuse(plan)
if(plan.partial!==true)controller.confirmStoreUntradeablesTapped()
else{const said=sendSubset(screen.viewmodel,controller,going.items)
if(said.ok!==true){refused+=1
unhear()
return{...plan,ok:false,reason:said.reason}}}}
else{if(typeof controller?.quickSell!=='function')return refuse(plan)
try{seenBefore=beforeKnife()}catch(err){onError(err)
seenBefore=null}
controller.quickSell(picked.items,picked.coins)}}
catch(err){onError(err)
refused+=1
unhear()
return{...plan,ok:false,reason:'failed'}}
opened+=1
if(!listening&&MOVE_ANSWERS[door]!==undefined)deaf+=1
hold(door,going.ids,blindNow)
let armed=false
if(match!==null&&BULK_DANGER.has(door)){try{armed=onKnife({door,cards:going.ids.length,ids:[...going.ids],before:seenBefore})===true}catch(err){onError(err)
armed=false}}
return{...plan,ok:true,reason:BULK_DANGER.has(door)&&!armed?'confirm':null}}
return{
preview:(door)=>bulkPreview(readScreen(),door),
open:(door)=>openDoor(door,null),
pending:()=>(busy===null?null:{door:busy.door,cards:busy.ids.size,expired:busy.expired===true}),
knifeUnpressed(why){if(busy===null||!BULK_DANGER.has(busy.door))return false
unpressed+=1
lastUnpressed=typeof why==='string'&&why!==''?why:'none'
busy=null
unhear()
wake({ok:false,reason:'unpressed',took:null,said:null})
return true},
async step(kind,ids){const want=Array.isArray(ids)?ids.filter((id)=>Number.isSafeInteger(id)):[]
const doors=STEP_DOORS[kind]
const no=(reason)=>({ok:false,reason,door:null,cards:0,coins:0,wait:null})
if(doors===undefined)return no('no-door')
if(want.length===0)return no('no-door')
const screen=readScreen()
if(!screen?.viewmodel)return no('no-screen')
for(const door of doors){const picked=doorItems(screen.viewmodel,door)
if(!picked||!sameIds(picked.ids,want))continue
if(eaLimit!==null)return no(eaLimit)
let granted=null
if(busy===null&&screen.box?.isConnected!==false
&&stepStopWord(bulkPreview(screen,door),want)===null){granted=await grantDoor()
if(granted!==null){refused+=1
return no(granted)}}
const result=openDoor(door,want,granted)
if(result.ok===true)return{ok:true,reason:result.reason,door,cards:result.cards,coins:result.coins,wait:doorWait()}
if(stopsRequest(result.reason))return no(result.reason)
return no(result.reason==='no-match'?'mismatch':result.reason==='blind-items'?'blind':`door-${result.reason??'failed'}`)}
return no('mismatch')},
settled(){if(busy===null)return false
const own=busy.receipt
if(ourCardsGone(busy.ids)!==true)return false
if(busy===null||busy.receipt!==own)return false
busy=null
byScreen+=1
unhear()
wake({ok:true,reason:null,took:null,said:null})
return true},
state:()=>({
build:'W22D',
busy:busy?.door??null,frames:busy?.frames??0,expired:busy?.expired===true,receipt:busy?.receipt??0,opened,refused,uncertain,
answers,byAnswer,byScreen,deaf,listening:ear!==null,
eaLimit,limits,
unpressed,lastUnpressed,
answer:lastAnswer===null?null:{...lastAnswer},
consent:consent.state(),
doors:BULK_DOORS.map((door)=>{const plan=bulkPreview(readScreen(),door)
return{door,ok:plan.ok,reason:plan.reason,verdict:plan.verdict,cards:plan.cards,coins:plan.coins,
locked:plan.locked,stays:plan.stays,fits:plan.fits,need:plan.need,used:plan.used,size:plan.size,
partial:plan.partial===true,left:plan.left,
unreadable:plan.unreadable}})}),
dispose(){busy=null
unhear()
wake({ok:false,reason:'gone',took:null,said:null})
consent.forget()}}}
