const isBalance=(value)=>typeof value==='number'&&Number.isFinite(value)&&value>=0
export const COINS_TYPE='COINS'
export function createWalletAdapter(win=globalThis){return{
coins(){try{const coinType=win?.GameCurrency?.COINS??COINS_TYPE
const user=win?.services?.User?.getUser?.()
const currencies=user?.getCurrencies?.()
if(!Array.isArray(currencies))return null
const currency=currencies.find((entry)=>entry&&typeof entry==='object'&&entry.type===coinType)
return isBalance(currency?.amount)?currency.amount:null}catch{
return null}}}}
