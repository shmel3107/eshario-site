import { findEnum } from './doors.js';
export const ITEM_PILE_KEYS = Object.freeze([
'ANY', 'TRANSFER', 'PURCHASED', 'CLUB', 'INBOX', 'GIFT', 'STORAGE', 'EVOLUTION',
]);
export const ITEM_PILES = Object.freeze({
ANY: 0, TRANSFER: 5, PURCHASED: 6, CLUB: 7, INBOX: 8, GIFT: 9, STORAGE: 10, EVOLUTION: 11,
});
export function itemPiles(win) {
return liveItemPiles(win) ?? ITEM_PILES;
}
export function liveItemPiles(win) {
let found = null;
try {
found = findEnum(win, ITEM_PILE_KEYS, { name: 'item-pile', numeric: true });
} catch {
return null;
}
return found?.ok === true && found.value && typeof found.value === 'object' ? found.value : null;
}
export function pileValue(win, name) {
if (typeof name !== 'string' || name === '') return null;
const live = liveItemPiles(win);
if (live === null) return null;
const value = live[name];
return Number.isSafeInteger(value) ? value : null;
}
export function pileName(win, value) {
if (!Number.isSafeInteger(value)) return null;
const table = itemPiles(win);
for (const name of Object.keys(table)) {
if (table[name] === value) return name;
}
return null;
}
