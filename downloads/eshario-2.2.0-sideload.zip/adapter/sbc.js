import{itemPiles} from './tables.js'
import{EaRequestError,requestData} from './observable.js'
import{eaTable} from './search.js'
export function createSbcAdapter(services){const sbc=services?.SBC
if(!sbc) throw new Error('adapter: services.SBC недоступен (приложение EA не запущено?)')
const chemistryEnabled=()=>{try{return services?.Chemistry?.isFeatureEnabled?.()===true}catch{
return false}}
return{
requestSets:async()=>{const data=await requestData(sbc.requestSets(),'наборы SBC')
return requireSbcList(data,'sets','наборы SBC',['categories'])},
requestChallengesForSet:async(set)=>{const data=await requestData(sbc.requestChallengesForSet(set),'испытания набора'
)
return requireSbcList(data,'challenges','испытания набора')},
loadChallenge:async(challenge)=>{const data=await requestData(sbc.loadChallenge(challenge),'загрузка испытания'
)
const valid=data
&&typeof data==='object'
&&!Array.isArray(data)
&&data.squad
&&typeof data.squad==='object'
&&!Array.isArray(data.squad)
&&challenge?.squad===data.squad
if(!valid){throw new EaRequestError('загрузка испытания: EA вернула неизвестную форму ответа',{response:data})}
return data},
saveChallenge:(challenge)=>requestData(sbc.saveChallenge(challenge),'сохранение состава'),
challengePassport(challenge){const blank={known:false,reason:null,status:null,setId:null,limited:false,remaining:null,complete:false,times:null,repeats:null}
if(!challenge||typeof challenge!=='object')return{...blank,reason:'нет испытания'}
const status=typeof challenge.status==='string'?challenge.status:null
const setId=Number.isSafeInteger(Number(challenge.setId))?Number(challenge.setId):null
let sets=null
try{sets=sbc.repository?.getSets?.()}catch{sets=null}
if(!Array.isArray(sets)||sets.length===0)return{...blank,status,setId,reason:'память наборов пуста'}
let found=null
for(const set of sets){try{if(setId!==null&&Number(set?.id)===setId){found=set
break}}catch{/* один набор не роняет поиск */}}
if(found===null&&setId===null){for(const set of sets){try{if(set?.getChallenge?.(challenge.id)){found=set
break}}catch{/* один набор не роняет поиск */}}}
if(found===null)return{...blank,status,setId,reason:'набора нет в памяти'}
const ask=(name,fallback)=>{try{const value=typeof found[name]==='function'?found[name]():found[name]
return value===undefined?fallback:value}catch{return fallback}}
const remaining=Number(ask('getRepeatsRemaining',null))
return{known:true,reason:null,status,setId:Number.isSafeInteger(Number(found.id))?Number(found.id):setId,
limited:ask('isLimitedRepeatable',false)===true,
remaining:Number.isFinite(remaining)?remaining:null,
complete:ask('isComplete',false)===true,
times:Number.isFinite(Number(ask('timesCompleted',null)))?Number(ask('timesCompleted',null)):null,
repeats:Number.isFinite(Number(ask('repeats',null)))?Number(ask('repeats',null)):null}},
submitChallenge:async(challenge,set,skipValidation=false)=>{const data=await requestData(sbc.submitChallenge(challenge,set,skipValidation===true,chemistryEnabled()),'отправка испытания'
)
return requireSubmitResult(data,challenge,set,'отправка испытания')},
getCachedSquads:()=>sbc.getCachedSBCSquads?.()??null,
cachedChallenges(){const out=[]
let sets=null
try{sets=sbc.repository?.getSets?.()}catch{sets=null}
for(const set of Array.isArray(sets)?sets:[]){try{if(set?.hasExpired?.()===true)continue
for(const challenge of set.getChallenges?.()??[]){try{if(challenge?.isCompleted?.()===true)continue
if(challenge?.isBrickChallenge?.()===true)continue
const requirements=challenge?.eligibilityRequirements
if(!Array.isArray(requirements)||requirements.length===0)continue
out.push({setId:set.id??null,id:challenge.id??null,requirements})}catch{/* одно испытание не роняет список */}}}catch{/* один набор не роняет список */}}
return out}}}
export function createSbc(win=globalThis){return createSbcAdapter(win?.services)}
export{ITEM_PILES,ITEM_PILE_KEYS} from './tables.js'
export function createSquadAdapter(services,piles){const squad=services?.Squad
if(!squad) throw new Error('adapter: services.Squad недоступен')
return{isClubItem:(item)=>piles?.CLUB!==undefined&&item?.pile===piles.CLUB,loadActive:async()=>{const data=await requestData(squad.requestSquadByType('active'),'активный состав')
if(!data?.squad||typeof data.squad!=='object'||Array.isArray(data.squad)){throw new EaRequestError('активный состав: EA вернула неизвестную форму ответа',{response:data})}
return data.squad},saveActive:async(entity)=>{if(typeof entity?.save!=='function'){throw new EaRequestError('активный состав: EA не вернула save')}
await requestData(entity.save(),'сохранение активного состава')
return entity},requestActivePlayerIds:async()=>{const activeId=squad.getActiveSquadId()
if(!Number.isSafeInteger(activeId)){throw new EaRequestError('активный состав: EA не вернула его id')}
const data=await requestData(squad.requestSquadById(activeId),'активный состав'
)
let slots
try{slots=data?.squad?.getPlayers?.()}catch{slots=null}
if(!Array.isArray(slots)){throw new EaRequestError('активный состав: EA вернула неизвестную форму ответа',{response:data})}
const ids=[]
for(const slot of slots){const item=slot?.item
let valid
try{valid=item?.isValid?.()}catch{valid=null}
if(valid===false)continue
let player
try{player=item?.isPlayer?.()}catch{player=null}
if(valid!==true||player!==true||!Number.isSafeInteger(item.id)||item.id<=0){throw new EaRequestError('активный состав: слот игрока неизвестной формы')}
ids.push(item.id)}
return[...new Set(ids)]}}}
export function createSquad(win=globalThis){return createSquadAdapter(win?.services,itemPiles(win))}
function requireSbcList(data,field,what,companionFields=[]){const valid=data
&&typeof data==='object'
&&!Array.isArray(data)
&&Array.isArray(data[field])
&&companionFields.every((name)=>Array.isArray(data[name]))
if(!valid){throw new EaRequestError(`${what}: EA вернула неизвестную форму ответа`,{response:data})}
return data}
function requireSubmitResult(data,challenge,set,what){const valid=data
&&typeof data==='object'
&&!Array.isArray(data)
&&data.challengeId===challenge?.id
&&data.setId===set?.id
&&typeof data.credits==='number'
&&Number.isFinite(data.credits)
&&data.credits>=0
&&Array.isArray(data.grantedChallengeAwards)
&&Object.hasOwn(data,'objectiveUpdates')
&&typeof data.preOrderPacks==='number'
&&Number.isFinite(data.preOrderPacks)
&&data.preOrderPacks>=0
&&typeof data.recoveredPacks==='number'
&&Number.isFinite(data.recoveredPacks)
&&data.recoveredPacks>=0
&&typeof data.setCompleted==='boolean'
if(!valid){throw new EaRequestError(`${what}: EA вернула неизвестную форму ответа`,{response:data})}
return data}
