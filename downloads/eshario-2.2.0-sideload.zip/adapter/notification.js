export const EA_NOTICE_TYPE=Object.freeze({POSITIVE:0,NEUTRAL:1,NEGATIVE:2})
const typeOf=(win,name)=>{let live
try{live=win?.UINotificationType?.[name]}catch{live=undefined}
return Number.isFinite(live)?live:EA_NOTICE_TYPE[name]}
export function sayEaNotice(win,text,kind='NEUTRAL'){if(typeof text!=='string'||text==='')return false
const name=Object.prototype.hasOwnProperty.call(EA_NOTICE_TYPE,kind)?kind:'NEUTRAL'
let service=null
try{service=win?.services?.Notification??null}catch{service=null}
if(!service||typeof service.queue!=='function')return false
try{service.queue([text,typeOf(win,name)])
return true}catch{return false}}
