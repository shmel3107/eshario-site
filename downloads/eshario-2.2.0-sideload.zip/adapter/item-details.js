import{findDoor} from './doors.js'
import{CARD_SELECTOR} from './quick-list.js'
const installations = new WeakMap()
const CONTROLLERS=Object.freeze([
Object.freeze({name:'item-details-screen',what:'окно карты',
declares:['setupPanelViewInstanceFromData'],want:'class'}),
Object.freeze({name:'slot-details-screen',what:'карта в слоте состава',
declares:['getSlotName','initWithSBCChallenge','setSlot'],want:'class'}),
])
export function isOwnedItem(item){if(!item||typeof item!=='object')return false
const read=(fn,fallback=false)=>{try{const value=fn()
return value===undefined?fallback:value}catch{return fallback}}
const auction=read(()=>item.getAuctionData?.()??null,null)
if(!auction)return true
if(read(()=>auction.isValid?.()===true)!==true)return true
if(read(()=>auction.isWon?.()===true))return true
if(read(()=>auction.isSold?.()===true))return true
if(read(()=>auction.tradeOwner===true))return true
return read(()=>auction.isSelling?.()===true)&&read(()=>auction.isActiveTrade?.()===true)}
export function isSoldItem(item){if(!item||typeof item!=='object')return false
try{const auction=item.getAuctionData?.()??null
if(!auction||auction.isValid?.()!==true)return false
return auction.isSold?.()===true}catch{return false}}
export function detailsCardOf(root){if(!root||typeof root.querySelector!=='function')return null
return root.querySelector(CARD_SELECTOR)}
export function installItemDetailsCapture(win,onItem=()=>{}){const targets=[]
const missing=[]
for(const door of CONTROLLERS){const found=findDoor(win,door)
const proto=found.ok?found.value?.prototype:null
if(proto&&typeof proto.renderPanel==='function')targets.push(proto)
else missing.push(door.what)}
if(targets.length===0)return{ok:false,reason:'unavailable',missing,dispose(){}}
const parts=targets.map((proto)=>{let installation=installations.get(proto)
if(!installation){const original=proto.renderPanel
const listeners=new Set()
const wrapped=function(item){const result=original.apply(this,arguments)
let card=item&&typeof item==='object'?item:null
if(!card){try{card=this?.viewmodel?.current?.()?.item??null}catch{card=null}}
let root=null
try{root=typeof this?.getView==='function'?this.getView()?.getRootElement?.()??null:null}catch{root=null}
if(card&&root){for(const listener of listeners){try{listener({item:card,root,controller:this})}catch{}}}
return result}
proto.renderPanel=wrapped
installation={original,wrapped,listeners}
installations.set(proto,installation)}
installation.listeners.add(onItem)
return{proto,installation}})
let active=true
return{ok:missing.length===0,reason:missing.length===0?null:'partial',missing,dispose(){if(!active)return
active=false
for(const{proto,installation}of parts){installation.listeners.delete(onItem)
if(installation.listeners.size===0&&proto.renderPanel===installation.wrapped){proto.renderPanel=installation.original
installations.delete(proto)}}}}}
