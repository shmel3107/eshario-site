export const HOME_GRID_SELECTOR='.grid.layout-hub'
export function homeGridOf(node){try{if(node===null||node===undefined)return null
if(typeof node.closest==='function'){const found=node.closest(HOME_GRID_SELECTOR)
if(found)return found}
const up=node.parentElement??null
if(up!==null&&typeof up.matches==='function'&&up.matches(HOME_GRID_SELECTOR))return up
return null}catch{return null}}
export const HOME_STRIP_SELECTORS=Object.freeze(['.ut-unassigned-tile-view',
'.ut-player-picks-tile-view','.fc-points-tile','.ut-rewards-banner-tile-view'])
export const HOME_STRIP_SELECTOR=HOME_STRIP_SELECTORS.join(',')
export function homeStripsIn(grid){try{const kids=grid?.children
if(kids===null||kids===undefined)return 0
let count=0
for(const kid of Array.prototype.slice.call(kids)){if(kid?.style?.display==='none')continue
if(typeof kid?.matches==='function'&&kid.matches(HOME_STRIP_SELECTOR))count+=1}
return count}catch{return 0}}
