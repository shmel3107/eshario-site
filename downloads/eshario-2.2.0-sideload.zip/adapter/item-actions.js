export const ROW_DEEDS=Object.freeze({
clearSquad:Object.freeze(['infopanel.button.clear']),
club:Object.freeze(['infopanel.label.storeInClub','infopanel.button.swap']),
transfer:Object.freeze(['infopanel.label.sendTradePile']),
storage:Object.freeze(['infopanel.label.sendToStorage']),
quickSell:Object.freeze(['infopanel.label.quickSell'])})
export function eaWord(win,key){const loc=win?.services?.Localization
if(typeof key!=='string'||key===''||typeof loc?.localize!=='function')return''
let text=''
try{text=String(loc.localize(key)??'').trim()}catch{text=''}
return text===key?'':text}
export function rowDeedLabels(win,deed){const keys=Object.hasOwn(ROW_DEEDS,deed)?ROW_DEEDS[deed]:null
const loc=win?.services?.Localization
if(!keys||typeof loc?.localize!=='function')return[]
const out=[]
for(const key of keys){let text=''
try{text=String(loc.localize(key)??'').trim()}catch{text=''}
if(text!==''&&text!==key&&!out.includes(text))out.push(text)}
return out}
