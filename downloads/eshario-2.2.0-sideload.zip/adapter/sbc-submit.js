import{refusesSuperclass} from './sbc-screen.js'
import{findDoor} from './doors.js'
const SUBMIT_SERVICE_DOOR=Object.freeze({name:'sbc-service',
declares:['submitChallenge','requestSets','getCachedSBCSquads'],want:'instance'})
const OBSERVABLE_DOOR=Object.freeze({name:'ea-observable',
declares:['observe','unobserve','clearObservers'],want:'class'})
function submitServiceProto(win){if(!win||(typeof win!=='object'&&typeof win!=='function'))return null
const found=findDoor(win,SUBMIT_SERVICE_DOOR)
if(!found.ok||!found.value||typeof found.value!=='object')return null
let proto=null
try{proto=Object.getPrototypeOf(found.value)}catch{return null}
return proto&&typeof proto==='object'?proto:null}
export const SUBMIT_GESTURE=Object.freeze(['mousedown','mouseup','click','touchstart','touchend'])
export const EXCHANGE_BUTTON_SELECTOR='.sbc-button-container button.call-to-action'
export const SUBMIT_TAB_SELECTOR='button.ut-squad-tab-button-control.actionTab.right'
export const SUBMIT_TARGET_SELECTOR=`${EXCHANGE_BUTTON_SELECTOR}, ${SUBMIT_TAB_SELECTOR}`
export const SUBMIT_DOORS=Object.freeze(['exchange','tab'])
const NAV_WALK_LIMIT=16
function parentOf(controller){try{return typeof controller?.getParentViewController==='function'?controller.getParentViewController():null}catch{return null}}
function rootElementOf(view){try{const node=view?.getRootElement?.()
return node&&typeof node==='object'?node:null}catch{return null}}
function describeNode(node){try{const tag=String(node?.tagName??'?')
const list=String(node?.className??'').trim()
return list===''?tag:`${tag}.${list.split(/\s+/).join('.')}`}catch{return '?'}}
function marked(node,selector){try{return typeof node?.matches==='function'&&node.matches(selector)===true}catch{return false}}
function exchangeDoorOf(controller,root){let own=null
try{own=rootElementOf(controller?.getView?.()?.getExchangeButton?.())}catch{own=null}
if(own)return{node:own,by:'getExchangeButton',saw:null}
let found=null
try{found=root?.querySelector?.(EXCHANGE_BUTTON_SELECTOR)??null}catch{found=null}
return found?{node:found,by:'selector',saw:null}:{node:null,by:null,saw:null}}
function submitTabDoorOf(controller,root){let node=parentOf(controller)
let saw=null
for(let step=0;node&&step<NAV_WALK_LIMIT;step+=1){let overview=null
try{overview=node._overviewController??null}catch{overview=null}
let own=null
try{own=rootElementOf(overview?.getView?.()?.getRightTab?.())}catch{own=null}
if(own){if(marked(own,SUBMIT_TAB_SELECTOR))return{node:own,by:'actionTab',saw:null}
if(saw===null)saw=describeNode(own)}
node=parentOf(node)}
let found=null
try{found=root?.ownerDocument?.querySelector?.(SUBMIT_TAB_SELECTOR)??null}catch{found=null}
return found?{node:found,by:'selector',saw}:{node:null,by:null,saw}}
export function submitButtonsOf(controller,root){const found={exchange:exchangeDoorOf(controller,root),tab:submitTabDoorOf(controller,root)}
const nodes=[]
const missing=[]
const doors={}
for(const name of SUBMIT_DOORS){const door=found[name]
if(door.by!==null)nodes.push(door.node)
else missing.push(name)
doors[name]={found:door.node!==null||door.saw!==null,identified:door.by!==null,by:door.by,saw:door.saw}}
return{nodes,missing,doors}}
function liveNumber(read){try{const value=read()
return typeof value==='number'&&Number.isFinite(value)?value:null}catch{return null}}
const idOf=(item)=>{try{return String(item?.id??'')}catch{return ''}}
export function liveSubmitSnapshot(challenge){const squad=challenge?.squad
if(!squad||typeof squad!=='object')return null
let slots=null
try{slots=typeof squad.getFieldPlayers==='function'?squad.getFieldPlayers():null}catch{slots=null}
if(!Array.isArray(slots)){try{slots=typeof squad.getNonBrickSlots==='function'?squad.getNonBrickSlots():null}catch{slots=null}}
if(!Array.isArray(slots))return null
const players=[]
const normalized=[]
for(const slot of slots){let item=null
try{item=slot?.item??null}catch{item=null}
if(!item||typeof item!=='object')continue
const id=idOf(item)
if(id===''||id==='0')continue
players.push(item)
normalized.push({chemistry:slotChemistry(slot),item})}
let requirements=[]
try{requirements=Array.isArray(challenge?.eligibilityRequirements)?challenge.eligibilityRequirements:[]}catch{requirements=[]}
let key=''
try{key=String(challenge?.id??'')}catch{key=''}
let operation=null
try{operation=challenge?.eligibilityOperation??null}catch{operation=null}
return{players,slots:normalized,operation,squadRef:squad,
chemistry:liveNumber(()=>squad.getChemistry?.()),rating:liveNumber(()=>squad.getRating?.()),
requirements,signature:`${key}:${players.map(idOf).join(',')}`}}
function slotChemistry(slot){let value
try{value=slot?.chemistry}catch{value=undefined}
if(typeof value!=='number'||!Number.isFinite(value)){try{value=typeof slot?.getChemistry==='function'?slot.getChemistry():undefined}catch{value=undefined}}
return typeof value==='number'&&Number.isFinite(value)?value:null}
export function sbcIneligibleReason(item){if(!item||typeof item!=='object')return null
try{if(item.isLimitedUse?.())return 'loan'}catch{
}
try{if(item.concept)return 'concept'}catch{}
try{if(item.isEnrolledInAcademy?.())return 'academy'}catch{}
return null}
export function cardResourceKey(item){if(!item||typeof item!=='object')return null
let legend=false
try{legend=item.isLegend?.()===true}catch{legend=false}
if(legend){let icon=null
try{icon=Number(item.iconId)}catch{icon=null}
if(Number.isFinite(icon)&&icon>0)return`icon:${icon}`}
let database=null
try{database=Number(item.databaseId)}catch{database=null}
if(!Number.isFinite(database)||database<=0){let definition=null
try{definition=Number(item.definitionId??item.defId)}catch{definition=null}
database=Number.isFinite(definition)?definition&DATABASE_MASK:null}
return Number.isFinite(database)&&database>0?`db:${database}`:null}
const DATABASE_MASK=0xffffff
const installations=new WeakMap()
export function installSubmitServiceGuard(win,allow=()=>true,answered=null){const proto=submitServiceProto(win)
const idle={blocked:0,passed:0,errors:0}
if(typeof proto?.submitChallenge!=='function')return{ok:false,reason:'unavailable',state:()=>({...idle}),dispose(){}}
if(refusesSuperclass(proto.submitChallenge))return{ok:false,reason:'refused',state:()=>({...idle}),dispose(){}}
if(installations.has(proto))return{ok:false,reason:'already',state:()=>({...idle}),dispose(){}}
const original=proto.submitChallenge
let blocked=0
let passed=0
let errors=0
let listening=true
const scope={}
const report=typeof answered==='function'?answered:null
const watch=(promised,challenge,set)=>{if(report===null)return
if(!promised||typeof promised.observe!=='function')return
try{promised.observe(scope,function(source,response){if(!listening)return
try{report({success:response?.success===true,status:response?.status??null,
data:response?.data??null,challenge,set})}catch{errors+=1}})}catch{errors+=1}}
const wrap=function(){let permitted=true
try{permitted=allow(arguments[0],arguments[1])!==false}catch{errors+=1
permitted=false}
if(!permitted){blocked+=1
return refusedAnswer(win)}
passed+=1
const promised=original.apply(this,arguments)
watch(promised,arguments[0],arguments[1])
return promised}
proto.submitChallenge=wrap
installations.set(proto,wrap)
let active=true
return{ok:true,reason:null,state:()=>({blocked,passed,errors}),dispose(){if(!active)return
active=false
listening=false
if(proto.submitChallenge===wrap)proto.submitChallenge=original
installations.delete(proto)}}}
function refusal(){return{success:false,status:0,error:null,data:null}}
function refuseLater(answer){try{setTimeout(()=>{try{answer.notify(refusal())}catch{
}},0)}catch{
}}
function formAnswer(){const observers=[]
const answer={observe(scope,fn){if(typeof fn==='function')observers.push([scope,fn])},
unobserve(scope){for(let i=observers.length-1;i>=0;i-=1){if(observers[i][0]===scope)observers.splice(i,1)}},
notify(payload){for(const[scope,fn]of observers.slice()){try{fn.call(scope,answer,payload)}catch{
}}}}
return answer}
function refusedAnswer(win){const found=(!win||(typeof win!=='object'&&typeof win!=='function'))?null:findDoor(win,OBSERVABLE_DOOR)
let answer=null
try{if(found?.ok&&typeof found.value==='function')answer=new found.value()}catch{
answer=null}
if(!answer||typeof answer.notify!=='function')answer=formAnswer()
refuseLater(answer)
return answer}
