import{findDoor} from './doors.js'
export const SETTINGS_DOOR=Object.freeze({name:'server-settings',
declares:['getSettingByKey','getStringSettingByKey','isCacheExpired'],
statics:['KEY'],want:'instance',from:'registry'})
export function serverSettingKeys(win){const found=findDoor(win,SETTINGS_DOOR)
if(!found.ok)return null
try{const table=found.value?.constructor?.KEY??null
return table&&typeof table==='object'?table:null}catch{return null}}
export const SQUAD_RATING_FLOAT_KEY='SQUAD_RATING_FLOAT_CALCULATION_ENABLED'
export function squadRatingFloatEnabled(win=globalThis){const config=win?.services?.Configuration
if(!config||typeof config.checkFeatureEnabled!=='function') return null
const table=serverSettingKeys(win)
const key=table&&Object.hasOwn(table,SQUAD_RATING_FLOAT_KEY)
?table[SQUAD_RATING_FLOAT_KEY]
:null
if(key===null||key===undefined)return null
try{return Boolean(config.checkFeatureEnabled(key))}catch{return null}}
