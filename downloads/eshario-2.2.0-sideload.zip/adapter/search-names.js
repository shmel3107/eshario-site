const TEAM_KEY=(year,id)=>`global.teamabbr15.${year}.team${id}`
const LEAGUE_KEY=(year,id)=>`global.leagueabbr15.${year}.league${id}`
const RARITY_KEY=(id)=>`item.raretype${id}`
const ZONE_KEY=(id)=>`search.positions.zone${id}`
function idOf(value){const n=typeof value==='string'&&/^\d+$/.test(value.trim())?Number(value.trim()):value
return Number.isSafeInteger(n)&&n>0?n:null}
function wordOf(said,key){const text=typeof said==='string'?said.trim():''
if(text===''||text===key)return null
return text}
export function createSearchNames(win){
const loc=()=>{const box=win?.services?.Localization
return typeof box?.localize==='function'?box:null}
const year=()=>{const said=Number(win?.APP_YEAR)
return Number.isSafeInteger(said)&&said>0?said:null}
const ask=(value,kind)=>{const id=idOf(value)
if(id===null)return null
const box=loc()
if(box===null)return null
const hand=kind==='team'?win?.UTLocalizationUtil?.teamIdToAbbr15:win?.UTLocalizationUtil?.leagueIdToName
if(typeof hand==='function'){try{const said=hand(id,box)
const key=kind==='team'?TEAM_KEY(year()??'',id):LEAGUE_KEY(year()??'',id)
const word=wordOf(said,key)
if(word!==null)return word}catch{
}}
const known=year()
if(known===null)return null
const key=kind==='team'?TEAM_KEY(known,id):LEAGUE_KEY(known,id)
try{return wordOf(box.localize(key),key)}catch{return null}}
const rarity=(value)=>{const id=idOf(value)
if(id===null)return null
const box=loc()
if(box===null)return null
const key=RARITY_KEY(id)
try{return wordOf(box.localize(key),key)}catch{return null}}
const zone=(value)=>{const id=idOf(value)
if(id===null)return null
const box=loc()
if(box===null)return null
const key=ZONE_KEY(id)
try{return wordOf(box.localize(key),key)}catch{return null}}
return{club:(value)=>ask(value,'team'),league:(value)=>ask(value,'league'),rarity,zone}}
