import{pressNode} from '../features/hotkey-bind.js'
import{appMain} from './navigation.js'
export const LANDING_BUTTON='.ut-login .ut-login-content button.btn-standard.primary'
const CREDENTIAL_FIELDS='[type=password],[type=email],[name=email],[name=twoFactorCode],[autocomplete="one-time-code"]'
export const MEMORY_KEY='eshario.login.last'
export const PRESSED_MARK='futLoginPressed'
function visible(node){const box=node?.getBoundingClientRect?.()
return box?Number(box.width)>0&&Number(box.height)>0:true}
export function createLandingDoor(doc,win,opts={}){const onError=typeof opts.onError==='function'?opts.onError:()=>{}
const root=()=>doc?.documentElement??null
const marked=()=>{try{return root()?.dataset?.[PRESSED_MARK]==='1'}catch{return false}}
const button=()=>{try{return doc?.querySelector?.(LANDING_BUTTON)??null}catch(err){onError(err)
return null}}
const credentials=()=>{let nodes=null
try{nodes=doc?.querySelectorAll?.(CREDENTIAL_FIELDS)??null}catch(err){onError(err)
return false}
return Array.from(nodes??[]).some((node)=>visible(node))}
const loginRunning=()=>{let controller=null
try{const app=appMain(win)
if(app===null||app===undefined)return null
if(typeof app.getLoginController!=='function')return null
controller=app.getLoginController()}catch(err){onError(err)
return null}
if(controller===null||controller===undefined)return false
try{return controller.isRunning===true}catch(err){onError(err)
return null}}
let sessionKnown=null
const sessionLive=()=>{if(typeof sessionKnown==='boolean')return sessionKnown
let answer=null
try{const identity=win?.eadp?.identity
if(typeof identity?.checkForValidAccessToken!=='function')return null
answer=identity.checkForValidAccessToken()===true}catch(err){onError(err)
return null}
sessionKnown=answer
return answer}
return{
read(){const node=button()
let at=null
try{const value=win?.performance?.now?.()
at=Number.isFinite(value)?Math.round(value):null}catch{at=null}
return{credentials:credentials(),button:node!==null,visible:node===null?false:visible(node),disabled:node?.disabled===true,spent:marked(),at}},
askLogin(){return{running:loginRunning(),session:sessionLive()}},
press(){const node=button()
if(node===null)return false
try{const holder=root()
if(holder?.dataset)holder.dataset[PRESSED_MARK]='1'}catch(err){onError(err)}
return pressNode(node,win,onError)},
remember(report){try{win?.sessionStorage?.setItem?.(MEMORY_KEY,JSON.stringify(report))}catch(err){onError(err)}},
recall(){let raw=null
try{raw=win?.sessionStorage?.getItem?.(MEMORY_KEY)??null}catch{return null}
if(typeof raw!=='string'||raw==='')return null
try{const value=JSON.parse(raw)
return value&&typeof value==='object'?value:null}catch{return null}}}}
