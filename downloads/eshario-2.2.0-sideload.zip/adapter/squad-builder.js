import{findDoor} from './doors.js'
const SQUAD_BUILDER_DOOR=Object.freeze({name:'squad-builder-model',
declares:['generatePlayerCollection','filterDuplicates','findBestFitByPosition'],want:'class'})
export function arrangeByPositions(win,positions,players){if(!win||(typeof win!=='object'&&typeof win!=='function'))return null
const found=findDoor(win,SQUAD_BUILDER_DOOR)
const Model=found.ok?found.value:null
if(typeof Model!=='function')return null
const slots=Array.isArray(positions)?positions:[]
const list=Array.isArray(players)?[...players]:[]
if(slots.length===0||list.length===0)return null
let collection
try{collection=new Model().generatePlayerCollection(slots,list,false,null)}catch{return null}
if(!Array.isArray(collection)||collection.length!==slots.length)return null
const out=collection.slice()
let next=0
for(let slot=0;slot<out.length;slot+=1){if(out[slot]!==null&&out[slot]!==undefined)continue
out[slot]=list[next++]??null}
return out.some((item)=>item===null||item===undefined)?null:out}
