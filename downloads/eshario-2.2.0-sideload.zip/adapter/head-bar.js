import{eaRequestsOff,BEFORE_CALL} from './observable.js'
import{findDoor} from './doors.js'
import{serverSettingKeys} from './config.js'
import{askDayBudget} from '../features/day-budget.js'
import{createPersonaAdapter} from './persona.js'
const HOST={name:'fx-head-bar'}
const NO_EVENT=Object.freeze({ok:false,reason:'unavailable',division:null,divisionName:null,divisionNumber:null,divisions:null,wins:null,draws:null,losses:null})
export function readDivisionNumber(name){if(typeof name!=='string')return null
const found=/^DIV_(\d{1,3})$/.exec(name.trim())
if(found===null)return null
const value=Number(found[1])
return Number.isSafeInteger(value)&&value>0?value:null}
export function readRivalsEvent(event){if(!event||typeof event!=='object')return{...NO_EVENT,reason:'no-event'}
const count=(value)=>(Number.isSafeInteger(value)&&value>=0?value:null)
const division=count(event.division?.divisionId)
const name=typeof event.division?.localizedName==='string'&&event.division.localizedName!==''
?event.division.localizedName
:null
return{ok:division!==null,reason:division===null?'no-division':null,
division,divisionName:name,divisionNumber:readDivisionNumber(name),
divisions:count(event.numDivisions),
wins:count(event.user?.wins),draws:count(event.user?.draws),losses:count(event.user?.losses)}}
export const EA_SERVICE_IS_DISABLED=480
export const SETTINGS_RETRY_LIMIT=40
export const SETTINGS_RETRY_MS=1_500
const DOOR_CALLS=1
const USER_ACCESS_DOOR=Object.freeze({name:'user-access',
declares:['getMassInfo'],fields:['authDelegate','requestDelegate'],
want:'instance',from:'registry'})
function userAccessOf(win){const found=findDoor(win,USER_ACCESS_DOOR)
return found.ok?found.value:null}
export function readServerSettings(win=globalThis){const cold={readable:false,loaded:false,on:0,total:0,rivals:null}
try{const config=win?.services?.Configuration??null
const keys=serverSettingKeys(win)
if(config===null||typeof config.getFeatureSetting!=='function'||keys===null||typeof keys!=='object')return cold
const names=Object.keys(keys)
if(names.length===0)return cold
let on=0
for(const name of names){try{const value=config.getFeatureSetting(keys[name])
if(Number.isFinite(value)&&value>0)on+=1}catch{/* один ключ не роняет счёт */}}
const rivals=(()=>{try{const value=config.getFeatureSetting(keys.RIVALS_ENABLED)
return Number.isFinite(value)?value:null}catch{return null}})()
return{readable:true,loaded:on>0,on,total:names.length,rivals}}catch{return cold}}
const NO_RECORD=Object.freeze({ok:false,reason:'unavailable',won:null,draw:null,loss:null})
export function readMassRecord(dto){if(!dto||typeof dto!=='object')return{...NO_RECORD,reason:'silent'}
if(dto.success!==true){const status=Number.isFinite(dto.status)?dto.status:null
return{...NO_RECORD,reason:status===null?'refused':`refused-${status}`}}
const info=dto.response?.userInfo
if(!info||typeof info!=='object')return{...NO_RECORD,reason:'no-user-info'}
const count=(value)=>(Number.isSafeInteger(value)&&value>=0?value:null)
const won=count(info.won)
const draw=count(info.draw)
const loss=count(info.loss)
if(won===null||draw===null||loss===null)return{...NO_RECORD,reason:'no-record'}
return{ok:true,reason:null,won,draw,loss}}
export function createRivalsSource(win=globalThis,deps={}){
const budget=deps.budget??null
let answer=null
let asking=false
let asked=0
let failed=0
let cold=0
let pending=null
let coldAt=0
let record=null
let recordAsking=false
let recordAsked=0
let recordSends=0
const service=()=>{try{return win?.services?.Rivals??null}catch{return null}}
const now=()=>{try{return typeof win?.Date?.now==='function'?win.Date.now():Date.now()}catch{return Date.now()}}
const disabledCode=()=>{try{const value=win?.UtasErrorCode?.SERVICE_IS_DISABLED
return Number.isFinite(value)?value:EA_SERVICE_IS_DISABLED}catch{return EA_SERVICE_IS_DISABLED}}
const massDoor=()=>{try{const live=userAccessOf(win)
const Dao=live?.constructor??null
if(typeof Dao!=='function'||live===null||typeof live.getMassInfo!=='function')return null
const auth=live.authDelegate??null
const queue=live.requestDelegate??null
if(auth===null||queue===null||typeof queue.send!=='function')return null
return{Dao,auth,queue}}catch{return null}}
const classify=(dto)=>{const status=dto?.status??null
const code=dto?.error?.code??null
const settings=readServerSettings(win)
if(code!==disabledCode())return{retry:false,reason:status===null?'refused':`refused-${status}`}
if(settings.readable&&settings.loaded)return{retry:false,reason:'disabled'}
if(cold<SETTINGS_RETRY_LIMIT)return{retry:true,reason:'settings-cold'}
return{retry:false,reason:'settings-never'}}
return{
available(){const rivals=service()
return rivals!==null&&typeof rivals.getEvent==='function'},
peek(){const base=answer??pending
if(base===null||base===undefined)return base??null
if(Number.isSafeInteger(base.wins)&&Number.isSafeInteger(base.draws)&&Number.isSafeInteger(base.losses))return base
if(record===null||record.ok!==true)return base
return{...base,wins:record.won,draws:record.draw,losses:record.loss}},
recordAvailable(){return massDoor()!==null},
hasRecord(){const base=answer??pending
if(base!==null&&base!==undefined
&&Number.isSafeInteger(base.wins)&&Number.isSafeInteger(base.draws)&&Number.isSafeInteger(base.losses))return true
return record!==null&&record.ok===true},
async askDivision(){if(answer!==null)return answer
if(asking)return{...NO_EVENT,reason:'asking'}
if(eaRequestsOff(BEFORE_CALL)){pending={...NO_EVENT,reason:'requests-off'}
return pending}
if(cold>0){const wait=now()-coldAt
if(wait>=0&&wait<SETTINGS_RETRY_MS)return pending??{...NO_EVENT,reason:'settings-cold'}}
const rivals=service()
if(rivals===null||typeof rivals.getEvent!=='function')return{...NO_EVENT,reason:'unavailable'}
asking=true
try{
const stop=await askDayBudget(budget,DOOR_CALLS)
if(stop!==null){pending={...NO_EVENT,reason:stop}
return pending}
asked+=1
const observable=rivals.getEvent()
if(!observable||typeof observable.observe!=='function'){asking=false
failed+=1
answer={...NO_EVENT,reason:'no-observable'}
return answer}
const dto=await new Promise((resolve)=>{observable.observe(HOST,(source,value)=>{
try{source?.unobserve?.(HOST)}catch{/* снятие не обязано удаться */}
resolve(value??null)})})
if(dto?.success===true){pending=null
answer=readRivalsEvent(dto?.response?.event??null)
if(answer.ok!==true)failed+=1
return answer}
failed+=1
const verdict=classify(dto)
if(verdict.retry){// НЕ ЗАПОМИНАЕМ В `answer`: это «ещё не знаю», а не «нет».
cold+=1
coldAt=now()
pending={...NO_EVENT,reason:verdict.reason}
return pending}
pending=null
answer={...NO_EVENT,reason:verdict.reason}
return answer}catch(err){failed+=1
answer={...NO_EVENT,reason:'failed',error:String(err?.message??err)}
return answer}finally{asking=false}},
async askRecord(){if(record!==null)return record
if(recordAsking)return{...NO_RECORD,reason:'asking'}
if(eaRequestsOff(BEFORE_CALL))return{...NO_RECORD,reason:'requests-off'}
const door=massDoor()
if(door===null)return{...NO_RECORD,reason:'unavailable'}
recordAsking=true
try{
const stop=await askDayBudget(budget,DOOR_CALLS)
if(stop!==null)return{...NO_RECORD,reason:stop}
recordAsked+=1
let raw=null
const transport={send:(request)=>{recordSends+=1
const observable=door.queue.send(request)
try{const spy={}
observable?.observe?.(spy,(source,value)=>{if(raw===null)raw=value})}catch{/* чтение по дороге не обязано удаться */}
return observable}}
const own=new door.Dao(door.auth,transport)
await new Promise((resolve)=>{const host={}
const observable=own.getMassInfo()
if(!observable||typeof observable.observe!=='function'){resolve(null)
return}
observable.observe(host,(source)=>{
try{source?.unobserve?.(host)}catch{/* снятие не обязано удаться */}
resolve(null)})})
record=readMassRecord(raw)
return record}catch(err){record={...NO_RECORD,reason:'failed',error:String(err?.message??err)}
return record}finally{recordAsking=false}},
state(){return{available:this.available(),asked,failed,asking,answer:answer??pending,cold,
record:{answer:record,asked:recordAsked,asking:recordAsking,sends:recordSends,
door:massDoor()!==null},
settings:readServerSettings(win)}}}}
const EA_PLATFORM=Object.freeze({PC:'PC',PSN:'PSN',XBL:'XBL'})
export const PLATFORM_SIGN=Object.freeze({PSN:'playstation',XBL:'xbox',PC:'genericPC'})
export const PLATFORM_SIGN_HOST='ut-leaderboards-entry--platform'
export function platformSignOf(platform,win=globalThis){
if(typeof platform!=='string'||platform==='')return null
const ea=win?.GamePlatform
const value=(key)=>(typeof ea?.[key]==='string'&&ea[key]!==''?ea[key]:EA_PLATFORM[key])
const types=win?.UTLeaderboardsEntryView?.PlatformType
const sign=(key,hers)=>({kind:key,
sign:typeof types?.[hers]==='string'&&types[hers]!==''?types[hers]:PLATFORM_SIGN[key]})
if(platform===value('PSN'))return sign('PSN','PLAYSTATION')
if(platform===value('XBL'))return sign('XBL','XBOX')
if(platform===value('PC'))return sign('PC','GENERICPC')
return null}
export function createPlatformSign(win=globalThis,deps={}){
const personas=deps.personas??createPersonaAdapter(win)
return()=>{let persona=null
try{persona=personas.selectedPersona?.()??null}catch{return null}
if(persona===null||persona===undefined)return null
let platform=null
try{platform=persona.platform??null}catch{return null}
return platformSignOf(platform,win)}}
