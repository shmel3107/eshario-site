export const SEASON_MIN=20
export const SEASON_MAX=99
export const PAGE_YEAR_NAME='fut_year'
const DETACHED=Symbol('season:detached')
function readGlobal(win,name){try{return win?.[name]}catch{return DETACHED}}
function shortOfFullYear(full){if(!Number.isSafeInteger(full))return null
const short=full-2000
return short>=SEASON_MIN&&short<=SEASON_MAX?short:null}
export function seasonOf(win=globalThis){
const page=readGlobal(win,PAGE_YEAR_NAME)
if(page===DETACHED)return null
if(typeof page==='string'||typeof page==='number'){
const parsed=Number.parseInt(String(page),10)
const fromPage=shortOfFullYear(Number.isNaN(parsed)?null:parsed)
if(fromPage!==null)return fromPage}
const raw=readGlobal(win,'APP_YEAR_SHORT')
if(raw===DETACHED)return null
if(Number.isSafeInteger(raw)&&raw>=SEASON_MIN&&raw<=SEASON_MAX)return raw
const full=readGlobal(win,'APP_YEAR')
if(full===DETACHED)return null
return shortOfFullYear(full)}
export function seasonFits(stamped,season){if(season===null||season===undefined)return true
if(stamped===undefined||stamped===null)return true
return stamped===season}
