import{findDoor} from './doors.js'
import{refusesSuperclass} from './sbc-screen.js'
import{pressNode} from '../features/hotkey-bind.js'
export const PROMO_CLASS='ut-livemessage'
export const PROMO_FOOTER_CLASS='ut-livemessage-footer'
const PROMO_COUNTER_SELECTOR='.ut-livemessage-header--counter'
const PROMO_TITLE_SELECTOR='.ut-livemessage-header h1'
const installations=new WeakMap()
function idle(reason){return{ok:false,reason,state:()=>({ok:false,reason,shown:0,foreign:0}),dispose(){}}}
export function promoRootOf(view){let root=null
try{root=view?.getRootElement?.()??null}catch{return null}
if(!root||typeof root.classList?.contains!=='function')return null
return root.classList.contains(PROMO_CLASS)?root:null}
function textOf(root,selector){try{const node=root?.querySelector?.(selector)??null
return node===null?'':String(node.textContent??'').replace(/\s+/g,' ').trim()}catch{return ''}}
export function promoArmMs(controller){try{const message=controller?.viewModel?.current?.()??null
const value=Number(message?.duration)
return Number.isFinite(value)&&value>=0?value:null}catch{return null}}
export function promoContinueNode(view){const root=promoRootOf(view)
if(root===null)return null
let node=null
try{node=view.getContinueButton?.()?.getRootElement?.()??null}catch{return null}
if(!node||typeof node.dispatchEvent!=='function')return null
let footer=null
try{footer=node.closest?.(`.${PROMO_FOOTER_CLASS}`)??null}catch{footer=null}
if(footer===null)return null
try{if(root.contains?.(footer)!==true)return null}catch{return null}
return node}
export function promoButtonReady(node){if(!node)return false
if(node.disabled===true)return false
if(node.isConnected===false)return false
let box=null
try{box=node.getBoundingClientRect?.()??null}catch{return false}
if(box===null)return true
return Number(box.width)>0&&Number(box.height)>0}
export function pressPromoContinue(controller,win,onError=()=>{}){let view=null
try{view=controller?.getView?.()??null}catch{return{ok:false,reason:'no-view'}}
if(view===null)return{ok:false,reason:'no-view'}
if(promoRootOf(view)===null)return{ok:false,reason:'not-promo'}
const node=promoContinueNode(view)
if(node===null)return{ok:false,reason:'no-button'}
if(!promoButtonReady(node))return{ok:false,reason:'not-armed'}
try{return pressNode(node,win,onError)?{ok:true,reason:null}:{ok:false,reason:'no-gesture'}}catch(err){onError(err)
return{ok:false,reason:'failed'}}}
function handleFor(controller,win,onError){let gone=false
const scope={}
try{controller.onExit.observe(scope,function(sender){gone=true
try{(sender??controller.onExit).unobserve(scope)}catch{
}})}catch{
}
const rootNow=()=>{try{return promoRootOf(controller.getView?.()??null)}catch{return null}}
const read=()=>{const root=rootNow()
return{counter:root===null?'':textOf(root,PROMO_COUNTER_SELECTOR),
title:root===null?'':textOf(root,PROMO_TITLE_SELECTOR).slice(0,60),
armMs:promoArmMs(controller)}}
return{promo:true,
...read(),
read,
closed(){if(gone)return true
const root=rootNow()
if(root===null)return true
return root.isConnected===false},
ready(){let view=null
try{view=controller.getView?.()??null}catch{return false}
return promoButtonReady(promoContinueNode(view))},
press:()=>pressPromoContinue(controller,win,onError)}}
const PROMO_DOOR=Object.freeze({name:'live-message-screen',
declares:['startButtonCountdown','onCallToAction','navigateAndClose'],want:'class'})
function ensurePromoInstall(win){const door=findDoor(win,PROMO_DOOR)
const ctrlProto=door.ok?door.value?.prototype:null
if(typeof ctrlProto?.viewDidAppear!=='function')return{record:null,reason:'unavailable'}
if(refusesSuperclass(ctrlProto.viewDidAppear))return{record:null,reason:'refused'}
const found=installations.get(ctrlProto)
if(found!==undefined)return{record:found,reason:null}
const listeners=new Set()
const counts={shown:0,foreign:0}
const rawAppear=ctrlProto.viewDidAppear
ctrlProto.viewDidAppear=function(){const out=rawAppear.apply(this,arguments)
try{let view=null
try{view=this.getView?.()??null}catch{view=null}
if(promoRootOf(view)===null)counts.foreign+=1
else{counts.shown+=1
const handle=handleFor(this,win,()=>{})
for(const listener of listeners){try{listener(handle)}catch{
}}}}catch{
}
return out}
const record={ctrlProto,counts,listeners,raw:rawAppear,wrap:ctrlProto.viewDidAppear}
installations.set(ctrlProto,record)
return{record,reason:null}}
export function installLiveMessageCapture(win,onShown=()=>{}){const{record,reason}=ensurePromoInstall(win)
if(record===null)return idle(reason)
if(record.listeners.has(onShown))return idle('already')
record.listeners.add(onShown)
let active=true
return{ok:true,reason:null,
state:()=>({ok:active,reason:null,...record.counts}),
dispose(){if(!active)return
active=false
record.listeners.delete(onShown)
if(record.listeners.size>0)return
if(record.ctrlProto.viewDidAppear===record.wrap)record.ctrlProto.viewDidAppear=record.raw
installations.delete(record.ctrlProto)}}}
