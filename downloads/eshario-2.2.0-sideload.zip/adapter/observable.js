export class EaRequestError extends Error{
constructor(message,meta={}){super(message)
this.name='EaRequestError'
this.status=meta.status??null
this.httpStatus=meta.httpStatus??null
this.response=meta.response??null}}
export class EaRequestsOffError extends EaRequestError{
constructor(what){super(`${what}: наше отключено человеком, к EA не ходим`)
this.name='EaRequestsOffError'}}
let port=null
let passed=0
let refusedBeforeCall=0
let refusedAfterCall=0
let portErrors=0
export function setEaRequestPort(next){port=typeof next==='function'?next:null
passed=0
refusedBeforeCall=0
refusedAfterCall=0
portErrors=0}
export const BEFORE_CALL='before-call'
export const AFTER_CALL='after-call'
export function eaRequestsOff(stage){if(port===null){passed+=1
return false}
let off=false
try{off=port()===true}catch{portErrors+=1
off=false}
if(!off){passed+=1
return false}
if(stage===BEFORE_CALL)refusedBeforeCall+=1
else refusedAfterCall+=1
return true}
export function eaRequestState(){let off=null
if(port!==null){try{off=port()===true}catch{off=null}}
return{port:port!==null,off,passed,refusedBeforeCall,refusedAfterCall,portErrors}}
export function toPromise(observable,what='запрос'){return new Promise((resolve,reject)=>{
if(eaRequestsOff(AFTER_CALL)){reject(new EaRequestsOffError(what));
return}
if(!observable||typeof observable.observe!=='function'||typeof observable.unobserve!=='function'){reject(new EaRequestError('adapter: ожидался EAObservable, получено другое'));
return}
const scope={};
let settled=false;
observable.observe(scope,function(sender,response){if(settled)return;
settled=true;
try{(sender??observable).unobserve(scope)}catch{
}
resolve(response)})})}
export async function requestData(observable,what='запрос'){const response=await toPromise(observable,what)
if(!response||typeof response!=='object'){throw new EaRequestError(`${what}: EA вернула не объект`,{response})}
if(response.success!==true){const errorCode=typeof response?.error?.code==='number'
?response.error.code
:null
const httpStatus=typeof response.status==='number'
?response.status
:null
throw new EaRequestError(`${what}: EA ответила отказом`,{
status:errorCode??httpStatus,httpStatus,response})}
return response.data===undefined?response.response:response.data}
