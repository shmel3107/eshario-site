import{refusesSuperclass} from './sbc-screen.js'
const installations=new WeakMap()
import{screenPrototype}from'./screen-door.js'
export const RESULTS_DOOR=Object.freeze({name:'club-results',
declares:['validateCurrentItems','generatePinnedItemView'],
methods:['handleItemRetrieval']})
const HOOK_RETRIEVAL='handleItemRetrieval'
export const STORAGE_MODE='storage'
export const SCREEN_MARK='futStorageScreen'
export const SCREEN_SELECTOR='[data-fut-storage-screen]'
export function storageModeOf(win){try{const value=win?.ItemSearchFeature?.STORAGE
return typeof value==='string'&&value!==''?value:STORAGE_MODE}catch{return STORAGE_MODE}}
function rootOf(controller){try{const view=typeof controller?.getView==='function'?controller.getView():null
const root=typeof view?.getRootElement==='function'?view.getRootElement():null
return root??null}catch{return null}}
function mark(root,storage){if(!root?.dataset)return false
try{if(storage){if(root.dataset[SCREEN_MARK]!=='1')root.dataset[SCREEN_MARK]='1'
return true}
if(root.dataset[SCREEN_MARK]!==undefined)delete root.dataset[SCREEN_MARK]
return false}catch{return false}}
export function installStorageScreenCapture(win,onScreen=()=>{}){const proto=screenPrototype(win,RESULTS_DOOR)
if(typeof proto?.[HOOK_RETRIEVAL]!=='function')return{ok:false,reason:'unavailable',dispose(){}}
if(refusesSuperclass(proto[HOOK_RETRIEVAL]))return{ok:false,reason:'refused',dispose(){}}
let installation=installations.get(proto)
if(!installation){const listeners=new Set()
const original=proto[HOOK_RETRIEVAL]
const wrapped=function(items){const result=original.apply(this,arguments)
try{const storage=this?.clubSearchType===storageModeOf(win)
const root=rootOf(this)
mark(root,storage)
const count=Array.isArray(items)?items.length:0
for(const listener of listeners){try{listener({storage,root,count})}catch{/* слушатель молчит за себя */}}}catch{
}
return result}
proto[HOOK_RETRIEVAL]=wrapped
installation={original,wrapped,listeners}
installations.set(proto,installation)}
installation.listeners.add(onScreen)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.listeners.delete(onScreen)
if(installation.listeners.size>0)return
if(proto[HOOK_RETRIEVAL]===installation.wrapped)proto[HOOK_RETRIEVAL]=installation.original
installations.delete(proto)}}}
