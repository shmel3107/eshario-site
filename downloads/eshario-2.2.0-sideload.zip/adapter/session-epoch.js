import{personaId} from '../features/autologin.js'
export const EPOCH_REASON=Object.freeze({
CONFIRMED:'confirmed',
SWITCHED:'switched',
RELOGIN:'relogin',
LOST:'lost'})
export function identityOf(persona,platform){const id=personaId(persona)
if(id===null||id==='')return null
return{personaId:id,platform:typeof platform==='string'&&platform!==''?platform:null}}
export function sameIdentity(a,b){if(a===null||a===undefined||b===null||b===undefined)return false
return String(a.personaId)===String(b.personaId)&&(a.platform??null)===(b.platform??null)}
export function epochVerdict(was,now){const had=was?.confirmed===true
const seen=now?.identity??null
if(!had)return seen===null?null:EPOCH_REASON.CONFIRMED
if(seen===null){
return was?.identity===null?null:EPOCH_REASON.LOST}
if(was?.identity===null){return sameIdentity(was?.last??null,seen)?EPOCH_REASON.RELOGIN:EPOCH_REASON.SWITCHED}
if(!sameIdentity(was.identity,seen))return EPOCH_REASON.SWITCHED
if(now?.sameHolder===false)return EPOCH_REASON.RELOGIN
return null}
export function stopRunning(engine){return engine?.stop?.()?.ok===true}
export function stopQueue(queue,why){const now=queue?.state?.()??null
if(now===null||typeof now!=='object')return false
if(now.running!==true&&(Number(now.queue)||0)===0)return false
queue.stop(why)
return true}
export function sessionSince(startedAt,brokeAt){if(!Number.isFinite(startedAt))return null
return startedAt<(Number.isFinite(brokeAt)?brokeAt:0)?null:startedAt}
export function createSessionEpoch(deps={}){const personas=deps?.personas??null
const win=deps?.win??null
const onError=typeof deps?.onError==='function'?deps.onError:()=>{}
let confirmed=false
let identity=null
let last=null
let holder=null
let epoch=0
let reason=null
let at=null
const listeners=[]
const counts={polls:0,fires:0,byReason:Object.create(null),holderUnknown:0,readFailed:0}
const personaNow=()=>{if(personas===null||typeof personas.selectedPersona!=='function')return null
try{return personas.selectedPersona()??null}catch(err){counts.readFailed+=1
onError(err)
return null}}
const platformNow=()=>{if(personas===null||typeof personas.pricePlatform!=='function')return null
try{const value=personas.pricePlatform()
return typeof value==='string'&&value!==''?value:null}catch(err){counts.readFailed+=1
onError(err)
return null}}
const userNow=()=>{try{return win?.services?.User?.getUser?.()??null}catch(err){counts.readFailed+=1
onError(err)
return null}}
const holderSame=(user)=>{if(holder===null||user===null||user===undefined){counts.holderUnknown+=1
return null}
return user===holder}
const tell=(event)=>{for(const one of listeners){try{one(event)}catch(err){onError(err)}}}
return{
poll(now=null){counts.polls+=1
const persona=personaNow()
const seen=identityOf(persona,platformNow())
const user=userNow()
const verdict=epochVerdict({confirmed,identity,last},{identity:seen,sameHolder:holderSame(user)})
if(verdict===null)return null
const previous=identity
confirmed=true
identity=seen
if(seen!==null)last=seen
holder=seen===null?null:(user??null)
epoch+=1
reason=verdict
at=Number.isFinite(now)?now:null
counts.fires+=1
counts.byReason[verdict]=(counts.byReason[verdict]??0)+1
const event={epoch,reason:verdict,identity:seen===null?null:{...seen},previous:previous===null?null:{...previous},at}
tell(event)
return event},
subscribe(fn){if(typeof fn!=='function')return()=>{}
listeners.push(fn)
return()=>{const at2=listeners.indexOf(fn)
if(at2>=0)listeners.splice(at2,1)}},
state(){return{epoch,reason,at,confirmed,identity:identity===null?null:{...identity},
last:last===null?null:{...last},holder:holder!==null,listeners:listeners.length,
polls:counts.polls,fires:counts.fires,byReason:{...counts.byReason},
holderUnknown:counts.holderUnknown,readFailed:counts.readFailed}}}}
