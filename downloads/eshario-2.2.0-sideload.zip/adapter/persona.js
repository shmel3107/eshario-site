function platformOfSku(win,persona,sku){let own=null
try{own=persona?.platform??null}catch{own=null}
if(typeof own==='string'&&own!=='')return own
if(sku===undefined||sku===null||sku==='')return null
const map=win?.FUTDataUtils?.mapSkuToPlatform
if(typeof map!=='function')return null
try{const value=map.call(win.FUTDataUtils,sku)
return typeof value==='string'?value:null}catch{return null}}
const EA_PLATFORM=Object.freeze({PC:'PC',PSN:'PSN',XBL:'XBL'})
import{appMain} from './navigation.js'
export function createPersonaAdapter(win=globalThis){
const user=()=>{try{return win?.services?.User?.getUser?.()??null}catch{return null}}
return{
selectedPersona(){try{return user()?.getSelectedPersona?.()??null}catch{return null}},
pricePlatform(){let persona=null
try{persona=user()?.getSelectedPersona?.()??null} catch{/* still bootstrapping */}
if(persona===null||persona===undefined)return null
let sku=null
try{sku=persona?.sku??null}catch{sku=null}
const platform=platformOfSku(win,persona,sku)
if(typeof platform!=='string'||platform==='')return null
const known=win?.GamePlatform
const valueOf=(key)=>(typeof known?.[key]==='string'&&known[key]!==''?known[key]:EA_PLATFORM[key])
if(platform===valueOf('PC'))return 'pc'
return platform===valueOf('PSN')||platform===valueOf('XBL')?'ps5':null
},
listPersonas(){const u=user()
if(!u)return[]
let selected=null
let rest=[]
try{selected=u.getSelectedPersona?.()??null} catch{/* нет выбранной — это не ошибка */}
try{rest=u.getUnselectedPersonas?.()??[]} catch{/* список ещё не пришёл */}
return[selected,...(Array.isArray(rest)?rest:[])].filter((p)=>p!==null&&p!==undefined)},
selectPersona(persona){if(!persona||typeof persona!=='object'){throw new Error('adapter: нечего выбирать — персона не объект')}
if(persona.sku===undefined||persona.sku===null||persona.sku===''){throw new Error('adapter: у персоны нет sku — выбирать вслепую нельзя')}
const controller=appMain(win)?.getLoginController?.()
if(typeof controller?.switchPersona!=='function'){throw new Error('adapter: контроллер входа недоступен')}
return controller.switchPersona(persona)}}}
