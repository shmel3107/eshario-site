import{findDoor} from './doors.js'
import{FILTERS_SCREEN_DOOR,searchTypes,noWindow} from './search.js'
const SLOT_MODEL_DOOR=Object.freeze({name:'slot-search-model',
declares:['setSquad','setCurrentSlotIndex','getCurrentSlot'],want:'class'})
function classOf(win,door){if(noWindow(win))return null
const found=findDoor(win,door)
return found.ok&&typeof found.value==='function'?found.value:null}
export function createSlotSearchScreen(win,squad,slotIndex,options){const Filters=classOf(win,FILTERS_SCREEN_DOOR)
const Model=classOf(win,SLOT_MODEL_DOOR)
if(typeof Filters!=='function'||typeof Model!=='function')return{ok:false,reason:'no-classes',screen:null}
if(!squad||typeof squad!=='object')return{ok:false,reason:'no-squad',screen:null}
if(!Number.isSafeInteger(slotIndex)||slotIndex<0)return{ok:false,reason:'no-slot',screen:null}
try{const model=new Model()
model.setSquad(squad)
model.setCurrentSlotIndex(slotIndex)
const slot=model.getCurrentSlot?.()
if(!slot||!slot.item)return{ok:false,reason:'empty-slot',screen:null}
const screen=new Filters()
screen.initWithSquadContext(model)
return{ok:true,reason:null,screen,applied:tuneSearchCriteria(win,screen?.viewmodel?.searchCriteria,options)}}catch(err){return{ok:false,reason:'failed',detail:String(err?.message??err),screen:null}}}
export function tuneSearchCriteria(win,criteria,options){const blank={ok:false,reason:null,masked:null,position:null,maxBuy:null}
if(!criteria||typeof criteria!=='object')return{...blank,reason:'no-criteria'}
try{const out={ok:true,reason:null,masked:null,position:null,maxBuy:null}
const masked=Number(criteria.maskedDefId)
out.masked=Number.isSafeInteger(masked)&&masked>0?masked:null
if(out.masked!==null){const any=searchTypes(win).ANY
if(typeof any==='string'){const from=criteria.position
criteria.position=any
out.position={from:typeof from==='string'?from:null,to:criteria.position===any?any:null}}
else out.reason='no-search-type'}
const ceiling=options?.maxBuy
if(Number.isSafeInteger(ceiling)&&ceiling>0){criteria.maxBuy=ceiling
out.maxBuy=criteria.maxBuy===ceiling?ceiling:null}
return out}catch(err){return{...blank,reason:'failed',detail:String(err?.message??err)}}}
export function slotSearchSupport(win){return{filters:typeof classOf(win,FILTERS_SCREEN_DOOR),model:typeof classOf(win,SLOT_MODEL_DOOR)}}
