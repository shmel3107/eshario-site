import{findDoor,watchDoor,rememberDoor}from'./doors.js'
const watching=new WeakMap()
function dropWatch(win,name){const names=watching.get(win)
const stop=names?.get(name)
if(stop===undefined)return
names.delete(name)
try{stop()}catch{/* слой уже забыл про это ожидание */}}
export function screenClass(win,signature){if(win===null||win===undefined)return null
const door={...signature,want:'class'}
let found=null
try{found=findDoor(win,door)}catch{return null}
const name=typeof signature?.name==='string'?signature.name:null
if(found?.ok===true&&typeof found.value==='function'){if(name!==null)dropWatch(win,name)
return found.value}
if(name===null)return null
ensureWatch(win,name,door)
return null}
function ensureWatch(win,name,door){let names=watching.get(win)
if(names===undefined){names=new Map()
watching.set(win,names)}
if(names.has(name))return
let watch=null
try{watch=watchDoor(win,door)}catch{return}
names.set(name,typeof watch?.dispose==='function'?watch.dispose:()=>{})}
export function classOfLive(signature,instance,win=null){if(instance===null||typeof instance!=='object')return null
for(const name of signature?.methods??[]){if(typeof instance[name]!=='function')return null}
let proto=null
try{proto=Object.getPrototypeOf(instance)}catch{return null}
let guard=0
while(proto!==null&&proto!==undefined&&guard++<16){
let mine=true
for(const name of signature?.declares??[]){if(!Object.hasOwn(proto,name)||typeof proto[name]!=='function'){mine=false
break}}
if(mine){let ctor=null
try{ctor=proto.constructor??null}catch{return null}
if(typeof ctor!=='function'||ctor.prototype!==proto)return null
const name=typeof signature?.name==='string'?signature.name:null
if(win!==null&&win!==undefined&&name!==null){rememberDoor(win,name,ctor,instance)
dropWatch(win,name)}
return ctor}
try{proto=Object.getPrototypeOf(proto)}catch{return null}}
return null}
export function screenPrototype(win,signature){const ctor=screenClass(win,signature)
if(typeof ctor!=='function')return null
try{return ctor.prototype??null}catch{return null}}
export function liveObject(win,signature){if(win===null||win===undefined)return null
const door={...signature,want:'instance'}
let found=null
try{found=findDoor(win,door)}catch{return null}
const name=typeof signature?.name==='string'?signature.name:null
if(found?.ok===true&&found.value!==null&&found.value!==undefined){if(name!==null)dropWatch(win,name)
return found.value}
if(name===null)return null
ensureWatch(win,name,door)
return null}
export function forgetWatches(win){if(win===null||win===undefined)return
const names=watching.get(win)
if(names!==undefined)for(const stop of names.values()){try{stop()}catch{/* слой уже забыл */}}
watching.delete(win)}
