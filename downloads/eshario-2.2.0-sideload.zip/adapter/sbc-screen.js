const installations=new WeakMap()
const CONTROLLER=Object.freeze({name:'sbc-detail-panel-screen',
declares:['_eSquadBuilderSelected','_eSquadClearSelected','_eSquadExchange'],want:'class'})
import{findDoor} from './doors.js'
import{eaTable} from './search.js'
const ASSET_LOCATION_DOOR=Object.freeze({name:'asset-location-util',
statics:['getPackBackgroundImageUri','getAssetRootDir'],want:'class'})
const noWin=(win)=>!win||(typeof win!=='object'&&typeof win!=='function')
export const HOOK_ENTER='initWithSBCSet'
export const HOOK_UPDATE='_eChallengeUpdated'
const HOOKS=Object.freeze([HOOK_ENTER,HOOK_UPDATE])
export function refusesSuperclass(fn){try{return /\bthis\s*\.\s*superclass\b/.test(Function.prototype.toString.call(fn))}catch{
return true}}
export const CHALLENGE_CONTENT_SELECTOR='.challenge-content'
const CHALLENGE_BUTTONS_SELECTOR='.sbc-button-container'
const CHALLENGE_STATUS_SELECTOR='.sbc-status-container'
const CHALLENGE_DETAILS_SELECTOR='.ut-sbc-challenge-details-view'
export function challengeContentOf(root){if(!root||typeof root.querySelector!=='function')return null
if(root.isConnected===false)return null
return root.querySelector(CHALLENGE_CONTENT_SELECTOR)}
export function challengeAnchorOf(content){if(!content||typeof content.querySelector!=='function')return null
return content.querySelector(CHALLENGE_BUTTONS_SELECTOR)
??content.querySelector(CHALLENGE_STATUS_SELECTOR)}
export function challengeDetailsOf(content){if(!content||typeof content.querySelector!=='function')return null
return content.querySelector(CHALLENGE_DETAILS_SELECTOR)}
export function observeChallengeSubmitted(challenge,onSubmitted=()=>{},deps={}){const win=deps.win??globalThis
const sources=[challenge?.onDataChange,challenge?.onSave].filter((one)=>one&&typeof one.observe==='function'&&typeof one.unobserve==='function')
if(sources.length===0)return{ok:false,reason:'no-observable',dispose(){},state:()=>({fired:0})}
const completed=completedStatusOf(win)
const scope={}
let known=fieldItemIds(challenge?.squad)
let times=completionsOf(challenge)
let armed=true
let fired=0
let active=true
const handler=(sender,payload)=>{if(!active)return
const nowIds=fieldItemIds(challenge?.squad)
const nowTimes=completionsOf(challenge)
const finished=armed&&((completed!==null&&payload&&payload.status===completed)
||nowTimes>times
||isCompleted(challenge)===true)
times=Math.max(times,nowTimes)
if(!finished){
if(nowIds.length>0){known=nowIds
if(isCompleted(challenge)!==true)armed=true}
return}
armed=false
fired+=1
const ids=known.length>0?known:nowIds
try{onSubmitted(ids)}catch{
}}
for(const source of sources){try{source.observe(scope,handler)}catch{}}
return{ok:true,reason:null,state:()=>({fired,known:known.length,times,armed}),dispose(){if(!active)return
active=false
for(const source of sources){try{source.unobserve(scope)}catch{}}}}}
export function observeSquadChanges(squad,onChange=()=>{}){const source=squad?.onDataUpdated
if(!source||typeof source.observe!=='function'||typeof source.unobserve!=='function'){return{ok:false,reason:'no-observable',dispose(){}}}
const scope={}
let active=true
const handler=()=>{if(!active)return
try{onChange()}catch{
}}
try{source.observe(scope,handler)}catch{return{ok:false,reason:'refused',dispose(){}}}
return{ok:true,reason:null,dispose(){if(!active)return
active=false
try{source.unobserve(scope)}catch{}}}}
export function squadFieldSignature(squad){const slots=squadSlots(squad)
const parts=[]
for(let index=0;index<slots.length;index+=1){const id=slotItemId(slots[index])
if(id!==null)parts.push(`${index}:${id}`)}
return{signature:parts.join(','),count:parts.length}}
export function squadFieldSlotPairs(squad){const out=[]
const slots=squadSlots(squad)
for(let index=0;index<slots.length;index+=1){const id=slotItemId(slots[index])
if(id!==null)out.push([index,id])}
return out}
function squadSlots(squad){try{const slots=squad?.getNonBrickSlots?.()
if(Array.isArray(slots))return slots}catch{/* следующий настоящий метод */}
try{const slots=squad?.getSBCSlots?.()
if(Array.isArray(slots))return slots}catch{/* нет живых слотов */}
return[]}
function slotItemId(slot){let id
try{id=slot?.item?.id}catch{return null}
if(typeof id==='number')return Number.isFinite(id)&&id>0?String(id):null
return typeof id==='string'&&id!==''&&id!=='0'?id:null}
function completionsOf(challenge){let value
try{value=Number(challenge?.timesCompleted)}catch{return 0}
return Number.isFinite(value)?value:0}
function isCompleted(challenge){try{return challenge?.isCompleted?.()===true}catch{return false}}
const CHALLENGE_STATUS=Object.freeze({UNDEFINED:0,IN_PROGRESS:1,COMPLETED:2})
const CHALLENGE_STATUS_KEYS=Object.freeze(['UNDEFINED','IN_PROGRESS','COMPLETED'])
function completedStatusOf(win){const table=eaTable(win,'sbc-status',CHALLENGE_STATUS_KEYS,CHALLENGE_STATUS,true)
const value=table?.COMPLETED
return Number.isSafeInteger(value)?value:CHALLENGE_STATUS.COMPLETED}
function fieldItemIds(squad){let slots=null
try{slots=typeof squad?.getFieldPlayers==='function'?squad.getFieldPlayers():null}catch{slots=null}
if(!Array.isArray(slots)){try{slots=typeof squad?.getNonBrickSlots==='function'?squad.getNonBrickSlots():null}catch{slots=null}}
const ids=[]
for(const slot of Array.isArray(slots)?slots:[]){let id
try{id=slot?.item?.id}catch{id=null}
if(typeof id==='number'&&Number.isFinite(id)&&id>0)ids.push(id)
else if(typeof id==='string'&&id!=='')ids.push(id)}
return ids}
export function installSbcScreenCapture(win,onChallenge=()=>{}){const found=noWin(win)?null:findDoor(win,CONTROLLER)
const proto=found?.ok&&typeof found.value==='function'?found.value.prototype??null:null
const missing=HOOKS.filter((name)=>typeof proto?.[name]!=='function')
const refused=HOOKS.filter((name)=>typeof proto?.[name]==='function'&&refusesSuperclass(proto[name]))
const usable=HOOKS.filter((name)=>!missing.includes(name)&&!refused.includes(name))
const permanent=missing.length===0&&refused.length>0
if(!proto||usable.length===0){const reason=missing.length===HOOKS.length?'unavailable':'refused'
const named=missing.length===HOOKS.length?[CONTROLLER.name]:missing
const idle={ok:false,reason,permanent,missing:named,refused,wrapped:[],listeners:0}
return{...idle,state:()=>({...idle,missing:[...named],refused:[...refused],wrapped:[]}),dispose(){}}}
let installation=installations.get(proto)
if(!installation){installation={originals:new Map(),wrapped:new Map(),listeners:new Set()}
installations.set(proto,installation)}
const listeners=installation.listeners
for(const name of usable){if(installation.wrapped.get(name)===proto[name])continue
const original=proto[name]
const wrap=function(){const result=original.apply(this,arguments)
notify(this,listeners,name)
return result}
proto[name]=wrap
installation.originals.set(name,original)
installation.wrapped.set(name,wrap)}
listeners.add(onChallenge)
const wrappedNow=()=>HOOKS.filter((name)=>installation.wrapped.has(name)&&installation.wrapped.get(name)===proto[name])
const wrapped=wrappedNow()
const ok=wrapped.length===HOOKS.length
let active=true
return{ok,reason:ok?null:(missing.length===HOOKS.length?'unavailable':refused.length>0&&missing.length===0?'refused':'partial'),
permanent,missing,refused,wrapped,
state:()=>({ok:wrappedNow().length===HOOKS.length,reason:ok?null:'partial',permanent,
missing:[...missing],refused:[...refused],wrapped:wrappedNow(),listeners:listeners.size}),
dispose(){if(!active)return
active=false
installation.listeners.delete(onChallenge)
if(installation.listeners.size>0)return
for(const[name,original]of installation.originals){if(proto[name]===installation.wrapped.get(name))proto[name]=original}
installations.delete(proto)}}}
function notify(controller,listeners,hook){let challenge=null
let set=null
let root=null
try{challenge=controller?._challenge??null}catch{challenge=null}
try{set=controller?._set??null}catch{set=null}
try{root=typeof controller?.getView==='function'?controller.getView()?.getRootElement?.()??null:null}catch{root=null}
if(!challenge||!root)return
for(const listener of listeners){try{listener({challenge,set,root,controller,hook})}catch{}}}
const SQUAD_SUMMARY_SELECTOR='.ut-squad-summary.sbc-summary'
const SUMMARY_RIGHT_SELECTOR='.ut-squad-summary-info--right,.ut-squad-summary-info--end'
export function squadSummaryOf(panelRoot){if(!panelRoot||typeof panelRoot.querySelector!=='function')return null
if(panelRoot.isConnected===false)return null
let node=panelRoot
for(let step=0;step<SUMMARY_LOOKUP_DEPTH;step+=1){const parent=node?.parentElement??null
if(!parent)return null
if(typeof parent.querySelector==='function'){const bar=parent.querySelector(SQUAD_SUMMARY_SELECTOR)
if(bar)return bar}
node=parent}
return null}
const SUMMARY_LOOKUP_DEPTH=8
export function summaryRightOf(bar){if(!bar||typeof bar.querySelector!=='function')return null
return bar.querySelector(SUMMARY_RIGHT_SELECTOR)}
export function squadLiveNumbers(squad){return{rating:liveNumberOf(()=>squad?.getRating?.()),
chemistry:liveNumberOf(()=>squad?.getChemistry?.())}}
function liveNumberOf(read){let value
try{value=read()}catch{return null}
return typeof value==='number'&&Number.isFinite(value)?value:null}
export function refreshSquadNumbers(squad){if(squad===null||squad===undefined||typeof squad!=='object'){
return{ok:false,rating:false,chemistry:false,reason:'no-squad'}}
const ratingDoor=typeof squad._calculateRating==='function'
const chemistryDoor=typeof squad.updateChemistry==='function'
if(!ratingDoor&&!chemistryDoor)return{ok:false,rating:false,chemistry:false,reason:'no-door'}
let rating=false
let chemistry=false
let reason=null
if(ratingDoor){try{squad._calculateRating()
rating=true}catch{reason='rating-threw'}}
else reason='no-rating-door'
if(chemistryDoor){const voBefore=chemistryWorkOf(squad)
const numberBefore=liveNumberOf(()=>squad?.getChemistry?.())
try{squad.updateChemistry()
chemistry=chemistryWorkOf(squad)!==voBefore||liveNumberOf(()=>squad?.getChemistry?.())!==numberBefore
if(!chemistry&&reason===null)reason='chemistry-silent'}
catch{if(reason===null)reason='chemistry-threw'}}
else if(reason===null)reason='no-chemistry-door'
return{ok:rating||chemistry,rating,chemistry,reason}}
function chemistryWorkOf(squad){try{return squad.chemistryVO}catch{return undefined}}
export function repaintSquadNumbers(controller,squad){if(squad===null||squad===undefined||typeof squad!=='object'){
return{ok:false,reason:'no-squad',steps:0}}
const found=overviewControllerOf(controller)
if(found.controller===null)return{ok:false,reason:found.reason,steps:found.steps}
let view=null
try{view=typeof found.controller.getView==='function'?found.controller.getView():null}catch{view=null}
if(view===null||view===undefined)return{ok:false,reason:'no-view',steps:found.steps}
const rating=liveNumberOf(()=>squad?.getRating?.())
const chemistry=liveNumberOf(()=>squad?.getChemistry?.())
if(rating===null&&chemistry===null)return{ok:false,reason:'no-numbers',steps:found.steps}
let painted=false
if(rating!==null&&typeof view.setRating==='function'){
try{view.setRating(rating)
painted=true}catch{/* её вид падать нам не даёт */}}
if(chemistry!==null&&typeof view.setChemistry==='function'){
try{view.setChemistry(chemistry)
painted=true}catch{/* её вид падать нам не даёт */}}
return{ok:painted,reason:painted?null:'no-door',steps:found.steps}}
function overviewControllerOf(controller){let one=controller
let steps=0
while(one!==null&&one!==undefined&&steps<OVERVIEW_CLIMB){
let own=null
try{own=one._overviewController??null}catch{own=null}
if(own!==null)return{controller:own,reason:null,steps}
let up=null
try{up=typeof one.getParentViewController==='function'?one.getParentViewController():null}catch{up=null}
one=up
steps+=1}
return{controller:null,reason:'no-overview',steps}}
const OVERVIEW_CLIMB=6
export function squadFieldRatings(squad){const out=[]
for(const slot of squadSlots(squad)){let rating
try{rating=slot?.item?.rating}catch{rating=undefined}
if(typeof rating==='number'&&Number.isFinite(rating)&&rating>0)out.push(rating)}
return out}
export function challengeAwardsOf(challenge){let list=null
try{list=challenge?.awards}catch{return[]}
return Array.isArray(list)?list.filter((one)=>one!==null&&one!==undefined):[]}
export function setAwardsOf(set){return challengeAwardsOf(set)}
export function setChallengeCountOf(set){let count=null
try{count=Number(set?.challengesCount)}catch{return null}
return Number.isSafeInteger(count)&&count>0?count:null}
export function rewardImageOf(win,award){if(!award||typeof award!=='object')return null
try{if(award.isPack===true){const found=noWin(win)?null:findDoor(win,ASSET_LOCATION_DOOR)
const host=found?.ok?found.value:null
const build=typeof host?.getPackBackgroundImageUri==='function'?host.getPackBackgroundImageUri:null
if(typeof build!=='function')return null
const uri=build.call(host,award.assetId)
return typeof uri==='string'&&uri.trim()!==''?uri:null}
if(award.isCoin===true)return COIN_IMAGE
if(award.isXP===true)return XP_IMAGE
return null}catch{return null}}
const COIN_IMAGE='images/IconCoins.png'
const XP_IMAGE='images/rewards/season-points.png'
export function frozenKeyOf(challenge){let id=null
try{id=Number(challenge?.id)}catch{return null}
return Number.isSafeInteger(id)&&id>=0?`c${id}`:null}
