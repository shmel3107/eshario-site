const WALK_LIMIT = 12;
export function onCurrentScreen(controller){if(!controller||typeof controller!=='object')return null
if(typeof controller.getParentViewController!=='function')return null
let node=controller
for(let step=0;step<WALK_LIMIT;step+=1){let parent=null
try{parent=node.getParentViewController?.()??null}catch{return null}
if(!parent)return true
const said=currentOf(parent)
if(said!==undefined&&said!==node)return false
node=parent}
return null}
function currentOf(parent){for(const name of['getCurrentController','getCurrentViewController']){if(typeof parent?.[name]!=='function')continue
try{return parent[name]()??null}catch{return null}}
return undefined}
