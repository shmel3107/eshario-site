import{requestData} from './observable.js'
import{appMain,liveViewController} from './navigation.js'
function fitsTabBar(one){if(one===null||typeof one!=='object')return false
try{if(typeof one._getIndexOfTabBarItemByTag!=='function')return false
return Number.isSafeInteger(one.constructor?.TabTag?.STORE)}catch{return false}}
function liveTabBar(win){let shown=null
try{shown=appMain(win)?.getRootViewController?.()?.getPresentedViewController?.()??null}catch{shown=null}
if(fitsTabBar(shown))return shown
let one=liveViewController(win)
let guard=0
while(one!==null&&one!==undefined&&guard++<16){if(fitsTabBar(one))return one
let up=null
try{up=one.getParentViewController?.()??null}catch{return null}
one=up}
return null}
export function storeRailButton(win){
try{const bar=liveTabBar(win)
if(bar===null)return null
const tag=bar.constructor?.TabTag?.STORE
if(!Number.isSafeInteger(tag))return null
const index=bar._getIndexOfTabBarItemByTag(tag)
if(!Number.isSafeInteger(index)||index<0)return null
const item=bar.childViewControllers?.[index]?.tabBarItem
const root=item?.getRootElement?.()??null
return root&&typeof root.appendChild==='function'?root:null}catch{return null}}
export function unopenedPackCount(win){try{const user=win?.services?.User?.getUser?.()
const value=user?.unopenedPacks
return Number.isSafeInteger(value)&&value>=0?value:null}catch{return null}}
export async function requestPackSplit(win){const store=win?.services?.Store
const kind=win?.PurchasePackType?.ALL
if(typeof store?.getPacks!=='function'||typeof kind!=='string'){throw new Error('tab-rail: у EA нет getPacks')}
const payload=await requestData(store.getPacks(kind,true,true),'список паков')
const list=Array.isArray(payload?.packs)?payload.packs:[]
const packs=[]
for(const pack of list){if(pack?.isMyPack!==true)continue
if(typeof pack.tradable!=='boolean'||!Number.isSafeInteger(pack.id))continue
packs.push({id:pack.id,tradable:pack.tradable})}
return{packs}}
export function installObjectiveRewardWatch(win,onChange=()=>{}){let dispatcher=null
try{dispatcher=typeof win?.getDefaultDispatcher==='function'?win.getDefaultDispatcher():null}catch{dispatcher=null}
if(!dispatcher||typeof dispatcher.addObserver!=='function'||typeof dispatcher.removeObserver!=='function'){return{ok:false,reason:'no-dispatcher',dispose(){}}}
const names=win?.AppNotification
const attached=[]
for(const member of ['OBJECTIVE_AVAILABLE_REWARD_COUNT_CHANGE','OBJECTIVE_UPDATE']){const key=names?.[member]
if(typeof key!=='string'||key==='')continue
const target={}
try{dispatcher.addObserver(key,target,()=>{try{onChange()}catch{
}})
attached.push({key,target})}catch{
}}
if(attached.length===0)return{ok:false,reason:'no-events',dispose(){}}
let active=true
return{ok:attached.length===2,reason:attached.length===2?null:'partial',
dispose(){if(!active)return
active=false
for(const{key,target}of attached){try{dispatcher.removeObserver(key,target)}catch{
}}}}}
const PACK_COUNT_WATCH_DEAD=Object.freeze({ok:false,reason:'dead-event',dispose(){}})
export function installPackCountWatch(){return PACK_COUNT_WATCH_DEAD}
