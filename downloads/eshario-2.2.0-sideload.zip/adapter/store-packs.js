import{itemPiles} from './tables.js'
import{screenClass,screenPrototype,liveObject,classOfLive}from'./screen-door.js'
import{APP_MAIN_DOOR,VIEW_CONTROLLER_DOOR}from'./navigation.js'
export const STORE_HUB_DOOR=Object.freeze({name:'store-hub',
declares:['openFCPointsPurchaseFlow','setupPointsTileDisplay','onPackLoadComplete']})
export const STORE_PACKS_DOOR=Object.freeze({name:'store-packs-screen',
declares:['eRevealExpired','eCheckPackOdds','updateViewCategories']})
export const STORE_VIEW_DOOR=Object.freeze({name:'store-view',
declares:['clearPacks','clearNimbleMTXItems','generatePack']})
export const PACK_ANIMATION_DOOR=Object.freeze({name:'pack-animation',
declares:['initWithPackData','setAnimationCallback','runAnimation']})
export const PACK_ARTICLE_DOOR=Object.freeze({name:'pack-article',
declares:['isArticleExpired','open','purchase','getPrice']})
export const TAB_BAR_DOOR=Object.freeze({name:'tab-bar',
declares:['initWithViewControllers','_getIndexOfTabBarItemByTag','setSelectedIndexByTag']})
export const HOME_HUB_DOOR=Object.freeze({name:'home-hub',
declares:['onLiveMessagesRetrieved','displayLoyaltyRewards']})
export const UNASSIGNED_LIST_DOOR=Object.freeze({name:'unassigned-list',
declares:['updateItemSectionOptions','updateDuplicateSectionOptions'],
methods:['renderView']})
export const UNASSIGNED_SPLIT_DOOR=Object.freeze({name:'unassigned-split',
declares:['unassignedListChanged','nItemActivated']})
export const ITEM_SORT_DOOR=Object.freeze({name:'item-sort',
declares:['sortByType'],fields:['sortByRecency','sort','sortType']})
export function pileNumber(win,name){
const value=itemPiles(win)[name]
return Number.isSafeInteger(value)?value:undefined}
const GROUP_MY_PACKS='mypacks'
export const NOTICE_UNASSIGNED_ADDED='notification.UnassignedItemAdded'
const DATABASE_ID_MASK=16777215
function storeHubClass(win){return screenClass(win,STORE_HUB_DOOR)}
function storePacksClass(win){return screenClass(win,STORE_PACKS_DOOR)}
function tabBarClass(win){const found=screenClass(win,TAB_BAR_DOOR)
if(typeof found==='function')return found
return classOfLive(TAB_BAR_DOOR,liveTabBar(win),win)}
function liveTabBar(win){const shown=presentedController(win)
if(classOfLive(TAB_BAR_DOOR,shown)!==null)return shown
let one=liveObject(win,VIEW_CONTROLLER_DOOR)
let guard=0
while(one!==null&&one!==undefined&&guard++<16){if(classOfLive(TAB_BAR_DOOR,one)!==null)return one
let up=null
try{up=one.getParentViewController?.()??null}catch{return null}
one=up}
return null}
function homeHubClass(win){return screenClass(win,HOME_HUB_DOOR)}
function unassignedListClass(win){return screenClass(win,UNASSIGNED_LIST_DOOR)}
function unassignedSplitClass(win){return screenClass(win,UNASSIGNED_SPLIT_DOOR)}
function appMain(win){const direct=win?.getAppMain
if(typeof direct==='function'){try{return direct.call(win)??null}catch{return null}}
return liveObject(win,APP_MAIN_DOOR)}
function presentedController(win){try{return appMain(win)?.getRootViewController?.()?.getPresentedViewController?.()??null}catch{return null}}
export function defaultDispatcher(win){const direct=win?.getDefaultDispatcher
if(typeof direct==='function'){try{return direct.call(win)??null}catch{return null}}
try{return appMain(win)?.getDefaultDispatcher?.()??null}catch{return null}}
const installations=new WeakMap()
const shownPacks=new WeakMap()
const tabInstallations=new WeakMap()
const packOpenInstallations=new WeakMap()
const packAnimationInstallations=new WeakMap()
export function readStorePacks(view,packs){const entities=Array.isArray(packs)?packs:[]
const views=Array.isArray(view?.storePacks)?view.storePacks:[]
const box=view?.__itemList??null
if(!box||typeof box.appendChild!=='function')return null
if(views.length===0||views.length!==entities.length)return null
const tiles=[]
for(let index=0;index<views.length;index+=1){const one=views[index]
const entity=entities[index]
let root=null
let id=null
try{root=one?.getRootElement?.()??null
id=one?.getArticleId?.()??null}catch{return null}
if(!root||typeof root.querySelector!=='function')return null
if(!Number.isSafeInteger(id)||id<0||id!==entity?.id)return null
if(typeof entity?.tradable!=='boolean'||typeof entity?.isMyPack!=='boolean')return null
tiles.push({root,id,tradable:entity.tradable,myPack:entity.isMyPack,odds:readPackOdds(entity,id),
players:minPlayersOf(entity),
assetId:readPackAsset(entity),
oddsRaw:Array.isArray(entity.odds)?entity.odds.length:-1})}
return{box,tiles,myPacks:tiles.every((tile)=>tile.myPack===true)}}
export function readPackAsset(entity){const value=entity?.assetId
if(Number.isSafeInteger(value))return value
return typeof value==='string'&&value!==''?value:null}
export function minPlayersOf(entity){const value=entity?.playerQuantity
return Number.isSafeInteger(value)&&value>0?value:null}
const ODDS_LOST_SAMPLE=8
export function readPackOddsLost(entity,taken){const rows=Array.isArray(entity?.odds)?entity.odds:[]
const shown=new Set((Array.isArray(taken)?taken:[]).map((one)=>String(one?.text??'')))
const lost=[]
for(const row of rows){const text=typeof row?.description==='string'?row.description.trim():''
if(shown.has(text))continue
lost.push({type:Number.isFinite(row?.category)?row.category:null,
packId:Number.isFinite(row?.packId)?row.packId:null,
text,
odds:typeof row?.odds==='string'?row.odds.trim():''})}
return{total:lost.length,rows:lost.slice(0,ODDS_LOST_SAMPLE)}}
export function readPackOdds(entity,id,opts){const rows=Array.isArray(entity?.odds)?entity.odds:[]
const picks=opts?.picks===true
const out=[]
for(const row of rows){let group=null
try{if(row?.isPlayer?.(id)===true)group='players'
else if(row?.isClub?.(id)===true)group='club'
else if(picks&&row?.isPlayerPicks?.(id)===true)group='picks'}catch{return[]}
if(group===null)continue
const text=typeof row?.description==='string'?row.description.trim():''
const odds=typeof row?.odds==='string'?row.odds.trim():''
if(text===''||odds==='')continue
if(group==='picks'){const packId=Number(row?.packId)
out.push({group,text,odds,packId:Number.isFinite(packId)?packId:null})
continue}
out.push({group,text,odds})}
return out}
export function storeNavigation(win){const Hub=storeHubClass(win)
if(typeof Hub!=='function')return null
try{const presented=presentedController(win)
const nav=presented?.getCurrentViewController?.()??null
return isStoreNavigation(win,nav)?nav:null}catch{return null}}
export function isStoreNavigation(win,nav){const Hub=storeHubClass(win)
if(typeof Hub!=='function'||!nav||typeof nav.getRootController!=='function')return false
try{return nav.getRootController() instanceof Hub}catch{return false}}
function atStoreHub(nav){try{return nav?.getCurrentController?.()===nav?.getRootController?.()}catch{return false}}
export function openMyPacks(win,nav){const Ctor=storePacksClass(win)
const group=win?.PurchaseDisplayGroup?.MYPACKS??GROUP_MY_PACKS
if(typeof Ctor!=='function'||typeof group!=='string'||group==='')return{ok:false,reason:'unavailable'}
if(!isStoreNavigation(win,nav)||typeof nav.pushViewController!=='function')return{ok:false,reason:'not-store'}
if(!atStoreHub(nav))return{ok:false,reason:'not-at-hub'}
try{const screen=new Ctor(group)
if(typeof screen.init!=='function')return{ok:false,reason:'unavailable'}
screen.init()
nav.pushViewController(screen)
return{ok:true,reason:null}}catch(err){return{ok:false,reason:'failed',detail:String(err?.message??err)}}}
export function goStoreHub(win){const nav=storeNavigation(win)
if(!nav)return{ok:false,reason:'not-store'}
if(atStoreHub(nav))return{ok:true,reason:'already'}
if(typeof nav.popToRootViewController!=='function')return{ok:false,reason:'no-navigation'}
try{nav.popToRootViewController()
return{ok:true,reason:null}}catch(err){return{ok:false,reason:'failed',detail:String(err?.message??err)}}}
export const JUMP_CALLS=3
export const BACK_CALLS=1
export const HUB_CALLS=2
export const HUB_BACK_CALLS=HUB_CALLS+BACK_CALLS
export const FAR_BACK_CALLS=12
export function backPlan(win){const far={calls:FAR_BACK_CALLS,landed:'far'}
const here=currentNavigation(win)
if(!here)return far
let under=null
try{const list=Array.isArray(here.childViewControllers)?here.childViewControllers:null
under=list!==null&&list.length>=2?list[list.length-2]:null}catch{return far}
if(!under)return far
const Packs=storePacksClass(win)
try{if(typeof Packs==='function'&&under instanceof Packs)return{calls:BACK_CALLS,landed:'packs'}}catch{return far}
const store=storeTab(win)
if(!store||store.nav!==here)return far
try{if(under===here.getRootController?.())return{calls:HUB_BACK_CALLS,landed:'hub'}}catch{return far}
return far}
export function goToUnassigned(win){const nav=storeNavigation(win)
if(!nav)return{ok:false,reason:'not-store'}
let current=null
try{current=nav.getCurrentController?.()??null}catch{return{ok:false,reason:'failed'}}
if(!current)return{ok:false,reason:'failed'}
const Split=unassignedSplitClass(win)
const List=unassignedListClass(win)
try{if((typeof Split==='function'&&current instanceof Split)
||(typeof List==='function'&&current instanceof List))return{ok:true,reason:'already'}}catch{return{ok:false,reason:'failed'}}
if(typeof current.gotoUnassigned!=='function')return{ok:false,reason:'unavailable'}
try{current.gotoUnassigned()
return{ok:true,reason:null}}catch(err){return{ok:false,reason:'failed',detail:String(err?.message??err)}}}
export function backFromUnassigned(win){const nav=storeNavigation(win)
if(!nav)return{ok:false,reason:'not-store'}
if(typeof nav.popViewController!=='function')return{ok:false,reason:'no-navigation'}
const Split=unassignedSplitClass(win)
const List=unassignedListClass(win)
let current=null
try{current=nav.getCurrentController?.()??null}catch{return{ok:false,reason:'failed'}}
if(!current)return{ok:false,reason:'failed'}
let unassigned=false
try{unassigned=(typeof Split==='function'&&current instanceof Split)
||(typeof List==='function'&&current instanceof List)}catch{return{ok:false,reason:'failed'}}
if(!unassigned)return{ok:false,reason:'not-unassigned'}
try{nav.popViewController()
return{ok:true,reason:null}}catch(err){return{ok:false,reason:'failed',detail:String(err?.message??err)}}}
export function picksPending(win){try{const value=win?.services?.User?.getUser?.()?.hasPlayerPicksPending
return typeof value==='boolean'?value:null}catch{return null}}
export function tabBar(win){const Bar=tabBarClass(win)
if(typeof Bar!=='function')return null
try{const one=liveTabBar(win)
return one instanceof Bar?one:null}catch{return null}}
export function currentNavigation(win){try{const one=presentedController(win)?.getCurrentViewController?.()??null
return one&&typeof one.getCurrentController==='function'?one:null}catch{return null}}
export function atUnassigned(win,nav){const List=unassignedListClass(win)
const Split=unassignedSplitClass(win)
let current=null
try{current=nav?.getCurrentController?.()??null}catch{return false}
if(!current)return false
try{return(typeof Split==='function'&&current instanceof Split)
||(typeof List==='function'&&current instanceof List)}catch{return false}}
export function storeTab(win){const bar=tabBar(win)
const list=Array.isArray(bar?.childViewControllers)?bar.childViewControllers:null
if(!list)return null
for(let index=0;index<list.length;index+=1){const nav=list[index]
if(isStoreNavigation(win,nav))return{index,nav}}
return null}
export function goStorePacks(win){
if(picksPending(win)===true)return{ok:false,reason:'pick-pending'}
const here=currentNavigation(win)
if(!here)return{ok:false,reason:'no-navigation'}
if(!atUnassigned(win,here))return{ok:false,reason:'not-unassigned'}
if(typeof here.popViewController!=='function')return{ok:false,reason:'no-navigation'}
const store=storeTab(win)
if(!store)return{ok:false,reason:'no-store-tab'}
try{here.popViewController()}catch(err){return{ok:false,reason:'failed',detail:String(err?.message??err)}}
const Packs=storePacksClass(win)
try{const under=here.getCurrentController?.()??null
if(typeof Packs==='function'&&under instanceof Packs)return{ok:true,reason:null,landed:'packs',tab:'same'}}catch{
}
const bar=tabBar(win)
const moved=store.nav!==here
if(moved){if(typeof bar?.setSelectedIndex!=='function')return{ok:true,reason:'no-tab-bar',landed:'other',tab:'stuck'}
try{bar.setSelectedIndex(store.index)}catch(err){return{ok:true,reason:'failed',landed:'other',tab:'stuck',detail:String(err?.message??err)}}}
if(typeof store.nav.popToRootViewController!=='function')return{ok:true,reason:'no-navigation',landed:'other',tab:moved?'switched':'same'}
try{store.nav.popToRootViewController()}catch(err){return{ok:true,reason:'failed',landed:'other',tab:moved?'switched':'same',detail:String(err?.message??err)}}
const opened=openMyPacks(win,store.nav)
return{ok:true,reason:opened.ok===true?null:opened.reason,landed:opened.ok===true?'packs':'hub',tab:moved?'switched':'same'}}
export function unassignedScreen(win){const nav=storeNavigation(win)
if(!nav)return null
let current=null
try{current=nav.getCurrentController?.()??null}catch{return null}
if(!current)return null
const List=unassignedListClass(win)
const Split=unassignedSplitClass(win)
try{if(typeof List==='function'&&current instanceof List){return typeof current.getUnassignedItems==='function'?current:null}
if(typeof Split==='function'&&current instanceof Split){const inner=current.listViewController??null
return typeof inner?.getUnassignedItems==='function'?inner:null}}catch{return null}
return null}
export function atHomeHub(win){const Hub=homeHubClass(win)
if(typeof Hub!=='function')return false
const nav=currentNavigation(win)
if(!nav)return null
let current=null
try{current=nav.getCurrentController?.()??null}catch{return null}
if(!current)return null
try{return current instanceof Hub}catch{return null}}
export function packNoticePlan(win){let hub=null
try{hub=atHomeHub(win)}catch{hub=null}
let screen=null
try{screen=unassignedScreen(win)}catch{screen=null}
return{refresh:screen!==null,announce:hub!==false}}
export function notePackOpened(win,items,opts={}){const done=[]
const net=opts.net!==false
const notice=opts.notice!==null&&typeof opts.notice==='object'?opts.notice:packNoticePlan(win)
let hubNow=null
try{hubNow=atHomeHub(win)}catch{hubNow=null}
const announceNet=hubNow!==false
const failed=[]
const step=(name,run)=>{try{run()
done.push(name)}catch{failed.push(name)}}
const pile=pileNumber(win,'PURCHASED')
const repo=win?.repositories?.Item
if(pile!==undefined&&typeof repo?.setDirty==='function')step('pile-dirty',()=>repo.setDirty(pile))
else failed.push('pile-dirty')
const list=Array.isArray(items)?items:[]
const dispatcher=defaultDispatcher(win)
const name=win?.AppNotification?.UNASSIGNED_ITEM_ADDED??NOTICE_UNASSIGNED_ADDED
const mayAnnounce=!announceNet||(net&&notice.announce===true)
if(list.length>0&&typeof dispatcher?.notify==='function'&&typeof name==='string'&&name!==''&&mayAnnounce){
step('announce',()=>dispatcher.notify(name,{fxPackFlow:true},{items:list}))}
else failed.push('announce')
const user=win?.services?.User
if(net)step('currencies',()=>{if(typeof user?.requestCurrencies!=='function')throw new Error('no currencies')
user.requestCurrencies()})
else failed.push('currencies')
step('unopened',()=>{const one=user?.getUser?.()
if(typeof one?.decrementNumUnopenedPacks!=='function')throw new Error('no counter')
one.decrementNumUnopenedPacks()})
step('store-dirty',()=>{const store=win?.repositories?.Store
if(typeof store?.setDirty!=='function')throw new Error('no store repo')
store.setDirty()})
const screen=net&&notice.refresh===true?unassignedScreen(win):null
if(screen!==null)step('refresh',()=>screen.getUnassignedItems())
else failed.push('refresh')
const sent=(done.includes('currencies')?1:0)+(done.includes('refresh')?1:0)
+(done.includes('announce')&&announceNet?1:0)
return{ok:done.includes('pile-dirty'),reason:done.includes('pile-dirty')?null:'guard-unavailable',done,failed,sent}}
export function installStoreTabCapture(win,onStoreTab=()=>{}){const Bar=tabBarClass(win)
const proto=typeof Bar==='function'?Bar.prototype??null:null
if(!proto||typeof proto.show!=='function'||typeof proto._eTabSelected!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let installation=tabInstallations.get(proto)
if(!installation){const original=proto.show
const originalTap=proto._eTabSelected
const listeners=new Set()
const notify=(controller)=>{let nav=null
try{nav=isStoreNavigation(win,controller)&&atStoreHub(controller)?controller:null}catch{nav=null}
if(!nav)return
for(const listener of listeners){try{listener({nav})}catch{}}}
const wrapped=function(controller,animated){const changed=this?.currentController!==controller
const result=original.call(this,controller,animated)
if(changed)notify(controller)
return result}
const wrappedTap=function(sender,type,data){const result=originalTap.call(this,sender,type,data)
const index=Number(data?.index)
const controller=Number.isInteger(index)&&index>=0?this?.childViewControllers?.[index]??null:null
if(controller)notify(controller)
return result}
proto.show=wrapped
proto._eTabSelected=wrappedTap
installation={original,originalTap,wrapped,wrappedTap,listeners}
tabInstallations.set(proto,installation)}
installation.listeners.add(onStoreTab)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.listeners.delete(onStoreTab)
if(installation.listeners.size>0)return
if(proto.show===installation.wrapped)proto.show=installation.original
if(proto._eTabSelected===installation.wrappedTap)proto._eTabSelected=installation.originalTap
tabInstallations.delete(proto)}}}
export function packCardFacts(item){const read=(fn)=>{try{return fn()}catch{return null}}
return{id:read(()=>{const value=item?.id
return Number.isSafeInteger(value)?value:null}),
player:read(()=>(typeof item?.isPlayer==='function'?item.isPlayer()===true:null)),
rating:read(()=>{const value=item?.rating
return typeof value==='number'&&Number.isFinite(value)?value:null}),
special:read(()=>(typeof item?.isSpecial==='function'?item.isSpecial()===true:null))}}
export function readPackContents(response){const items=Array.isArray(response?.items)?response.items:null
if(!items)return null
return items.map((item)=>packCardFacts(item))}
export function packCardName(item){try{const value=item?.getStaticData?.()?.name??item?.displayName??item?.name
return typeof value==='string'?value.trim().replace(/\s+/g,' '):''}catch{return ''}}
export function readPackDrops(response){const items=Array.isArray(response?.items)?response.items:null
if(!items)return null
return items.map((item)=>({...packCardFacts(item),name:packCardName(item)}))}
export function installPackOpenCapture(win,onContents=()=>{}){const proto=screenPrototype(win,PACK_ARTICLE_DOOR)
if(!proto||typeof proto.open!=='function'||typeof proto.purchase!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let installation=packOpenInstallations.get(proto)
if(!installation){const listeners=new Set()
const watch=(result,entity)=>{if(!result||typeof result.observe!=='function'||typeof result.unobserve!=='function')return
const scope={}
const packId=Number.isSafeInteger(entity?.id)?entity.id:null
const myPack=typeof entity?.isMyPack==='boolean'?entity.isMyPack:null
result.observe(scope,function(source,answer){try{source?.unobserve?.(scope)
const cards=readPackContents(answer?.response)
const ok=answer?.success===true&&cards!==null
const raw=answer?.error?.code??answer?.status
const code=Number.isSafeInteger(raw)?raw:null
const drops=readPackDrops(answer?.response)
for(const listener of listeners){try{listener({cards,drops,packId,myPack,ok,code})}catch{}}}catch{}})}
const wrap=(name)=>{const original=proto[name]
const wrapped=function(){const result=original.apply(this,arguments)
try{watch(result,this)}catch{}
return result}
proto[name]=wrapped
return{original,wrapped}}
installation={open:wrap('open'),purchase:wrap('purchase'),listeners}
packOpenInstallations.set(proto,installation)}
installation.listeners.add(onContents)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.listeners.delete(onContents)
if(installation.listeners.size>0)return
if(proto.open===installation.open.wrapped)proto.open=installation.open.original
if(proto.purchase===installation.purchase.wrapped)proto.purchase=installation.purchase.original
packOpenInstallations.delete(proto)}}}
export const PACK_SHOW_MARK='__fxPackShow'
export const PACK_SHOW_WATCHDOG_MS=15_000
export function pickShowItem(win,items){const list=Array.isArray(items)?items.filter((item)=>item!==null&&item!==undefined):[]
if(list.length===0)return null
let players=[]
try{players=list.filter((item)=>item?.isPlayer?.()===true)}catch{players=[]}
if(players.length>0){const Utils=screenClass(win,ITEM_SORT_DOOR)
if(typeof Utils!=='function')return players[0]
try{const utils=new Utils()
if(typeof utils.sortByType!=='function')return players[0]
return[...players].sort((one,two)=>utils.sortByType(one,two))[0]??players[0]}catch{return players[0]}}
let best=null
for(const item of list){if(best===null){best=item
continue}
const was=typeof best?.discardValue==='number'?best.discardValue:null
const now=typeof item?.discardValue==='number'?item.discardValue:null
if(was!==null&&now!==null&&was<now)best=item}
return best}
export function showPackAnimation(win,options={}){const Ctor=screenClass(win,PACK_ANIMATION_DOOR)
const item=options?.item??null
const onEnd=typeof options.onEnd==='function'?options.onEnd:()=>{}
const alive=typeof options.alive==='function'?options.alive:()=>true
if(typeof Ctor!=='function')return{ok:false,reason:'unavailable'}
if(!item)return{ok:false,reason:'no-item'}
const nav=storeNavigation(win)
if(!nav)return{ok:false,reason:'not-store'}
let presenter=null
try{presenter=nav.getCurrentController?.()??null}catch{return{ok:false,reason:'failed'}}
if(typeof presenter?.presentViewController!=='function'
||typeof presenter?.dismissViewController!=='function')return{ok:false,reason:'unavailable'}
let show=null
try{show=new Ctor()}catch{return{ok:false,reason:'failed'}}
if(typeof show?.initWithPackData!=='function'||typeof show?.setAnimationCallback!=='function')return{ok:false,reason:'unavailable'}
let presented=false
let done=false
let timer=null
const finish=(reason)=>{if(done)return
done=true
if(timer!==null){try{win?.clearTimeout?.(timer)}catch{}
timer=null}
if(presented){try{presenter.dismissViewController(false,()=>{try{show.dealloc?.()}catch{}})}catch{}}
else{try{show.dealloc?.()}catch{}}
try{onEnd(reason)}catch{}}
try{show.initWithPackData(item,options?.tier??null)
show.setAnimationCallback(()=>finish('shown'))
show[PACK_SHOW_MARK]=true
show.modalDisplayStyle='fullscreen'}catch{try{show.dealloc?.()}catch{}
return{ok:false,reason:'failed'}}
const frame=typeof options.frame==='function'?options.frame
:(run)=>{const raf=win?.requestAnimationFrame
if(typeof raf==='function')raf.call(win,run)
else run()}
try{frame(()=>{
let now=null
try{now=nav.getCurrentController?.()??null}catch{now=null}
if(now!==presenter||alive()!==true){finish('gone')
return}
try{presenter.presentViewController(show,true)
presented=true}catch{finish('failed')
return}
try{timer=win?.setTimeout?.(()=>{timer=null
finish('watchdog')},PACK_SHOW_WATCHDOG_MS)??null}catch{timer=null}})}catch{finish('failed')}
return{ok:true,reason:null}}
export function installPackAnimationCapture(win,decide=()=>null){const proto=screenPrototype(win,PACK_ANIMATION_DOOR)
if(!proto||typeof proto.runAnimation!=='function'||typeof proto.runCallback!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let installation=packAnimationInstallations.get(proto)
if(!installation){const original=proto.runAnimation
const judges=new Set()
const skip=(controller,original)=>{let done=false
const run=()=>{if(done)return
done=true
try{controller.runCallback()}catch{try{original.call(controller)}catch{}}}
if(typeof win?.requestAnimationFrame==='function')win.requestAnimationFrame(run)
else setTimeout(run,0)}
const wrapped=function(){
if(picksPending(win)===true)return original.apply(this,arguments)
if(this?.[PACK_SHOW_MARK]===true)return original.apply(this,arguments)
let verdict=null
try{const facts=packCardFacts(this?.presentedItem)
for(const judge of judges){const answer=judge({item:this?.presentedItem,facts})
if(answer&&answer.show===false){verdict=answer
break}}}catch{verdict=null}
if(!verdict)return original.apply(this,arguments)
skip(this,original)
return undefined}
proto.runAnimation=wrapped
installation={original,wrapped,judges}
packAnimationInstallations.set(proto,installation)}
installation.judges.add(decide)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.judges.delete(decide)
if(installation.judges.size>0)return
if(proto.runAnimation===installation.wrapped)proto.runAnimation=installation.original
packAnimationInstallations.delete(proto)}}}
export function unassignedInCache(win){const pile=pileNumber(win,'PURCHASED')
const repo=win?.repositories?.Item
if(pile===undefined||typeof repo?.numItemsInCache!=='function')return null
try{const value=repo.numItemsInCache(pile)
return Number.isSafeInteger(value)&&value>=0?value:null}catch{return null}}
export function unassignedCacheFresh(win){const pile=pileNumber(win,'PURCHASED')
const repo=win?.repositories?.Item
if(pile===undefined||typeof repo?.isDirty!=='function')return null
try{const dirty=repo.isDirty(pile)
return typeof dirty==='boolean'?!dirty:null}catch{return null}}
function storeSeam(win){const proto=screenPrototype(win,STORE_VIEW_DOOR)
if(!proto||typeof proto.setPacks!=='function')return null
const found=installations.get(proto)
if(found)return found
const original=proto.setPacks
const packListeners=new Set()
const catalogListeners=new Set()
const wrapped=function(...args){const result=original.apply(this,args)
const packs=args[0]
if(packListeners.size>0){let capture=null
try{capture=readStorePacks(this,packs)}catch{capture=null}
if(capture){for(const listener of packListeners){try{listener(capture)}catch{}}}}
if(catalogListeners.size>0){let catalog=null
try{catalog=readStoreCatalog(this,packs,win)}catch{catalog=null}
for(const listener of catalogListeners){try{listener(catalog)}catch{}}}
if(this&&typeof this==='object'&&Array.isArray(packs))shownPacks.set(this,packs)
return result}
proto.setPacks=wrapped
const originalUpdate=typeof proto.updatePack==='function'?proto.updatePack:null
const wrappedUpdate=originalUpdate===null?null:function(...args){const result=originalUpdate.apply(this,args)
const packs=shownPacks.get(this)
if(catalogListeners.size>0&&packs){let catalog=null
try{catalog=readStoreCatalog(this,packs,win)}catch{catalog=null}
if(catalog){for(const listener of catalogListeners){try{listener(catalog)}catch{}}}}
return result}
if(wrappedUpdate)proto.updatePack=wrappedUpdate
const installation={proto,original,wrapped,originalUpdate,wrappedUpdate,packListeners,catalogListeners}
installations.set(proto,installation)
return installation}
function seamHandle(installation,listeners,onCapture){listeners.add(onCapture)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
listeners.delete(onCapture)
const{proto,packListeners,catalogListeners,wrapped,original,originalUpdate,wrappedUpdate}=installation
if(packListeners.size===0&&catalogListeners.size===0&&proto.setPacks===wrapped){proto.setPacks=original
if(wrappedUpdate&&proto.updatePack===wrappedUpdate)proto.updatePack=originalUpdate
installations.delete(proto)}}}}
export function installStorePacksCapture(win,onCapture=()=>{}){const installation=storeSeam(win)
if(!installation)return{ok:false,reason:'unavailable',dispose(){}}
return seamHandle(installation,installation.packListeners,onCapture)}
export function installStoreCatalogCapture(win,onCatalog=()=>{}){const installation=storeSeam(win)
if(!installation)return{ok:false,reason:'unavailable',dispose(){}}
return seamHandle(installation,installation.catalogListeners,onCatalog)}
export function readStoreCatalog(view,packs,win=null){const entities=Array.isArray(packs)?packs:[]
const views=Array.isArray(view?.storePacks)?view.storePacks:[]
const box=view?.__itemList??null
if(!box||typeof box.appendChild!=='function')return null
if(views.length===0||views.length!==entities.length)return null
const tiles=[]
for(let index=0;index<views.length;index+=1){const one=views[index]
const entity=entities[index]
let root=null
let id=null
try{root=one?.getRootElement?.()??null
id=one?.getArticleId?.()??null}catch{return null}
if(!root||typeof root.querySelector!=='function')return null
if(!Number.isSafeInteger(id)||id<0||id!==entity?.id)return null
if(typeof entity?.tradable!=='boolean'||typeof entity?.isMyPack!=='boolean')return null
if(entity.isMyPack===true)return null
if(!Number.isSafeInteger(entity.itemQuantity))return null
const odds=readPackOdds(entity,id,{picks:true})
tiles.push({root,id,
tradable:entity.tradable,
items:entity.itemQuantity,
players:minPlayersOf(entity),
kind:typeof entity.contentType==='string'?entity.contentType:'',
playerPick:entity.isPlayerPickPack===true,
recommended:entity.isSegmented===true,
coins:articlePrice(entity,win,'COINS'),
points:articlePrice(entity,win,'POINTS'),
endsAt:Number.isFinite(entity.end)&&entity.end>0?entity.end:null,
limit:Number.isFinite(entity.quantity)&&entity.quantity>0?entity.quantity:null,
left:Number.isFinite(entity.userAvailableQuantity)&&entity.userAvailableQuantity>=0?entity.userAvailableQuantity:null,
worldLeft:Number.isFinite(entity.globalAvailableQuantity)&&entity.globalAvailableQuantity>=0?entity.globalAvailableQuantity:null,
odds,
oddsLost:readPackOddsLost(entity,odds),
desc:readPackDescription(entity,win),
oddsRaw:Array.isArray(entity.odds)?entity.odds.length:-1,
preview:readPreviewPack(entity)})}
return{box,screen:view,tiles}}
export function promoTimeLeft(win,seconds){if(!Number.isFinite(seconds)||seconds<=0)return null
const loc=win?.services?.Localization
if(typeof loc?.localizePromoTimeRemaining!=='function')return null
try{const text=loc.localizePromoTimeRemaining(Math.floor(seconds))
return typeof text==='string'&&text.trim()!==''?text.trim():null}catch{return null}}
export function readPackDescription(entity,win){const key=entity?.packDesc
if(typeof key!=='string'||key.trim()==='')return[]
const loc=win?.services?.Localization
if(typeof loc?.localize!=='function')return[]
let text=''
try{text=loc.localize(key)}catch{return[]}
if(typeof text!=='string')return[]
if(text.trim()===key.trim())return[]
return text.split('\n')
.map((one)=>one.trim().replace(/\s+/g,' '))
.filter((one)=>one!=='')}
function articlePrice(entity,win,name){const currency=win?.GameCurrency?.[name]??name
if(typeof currency!=='string'||currency==='')return null
if(typeof entity?.getPrice!=='function')return null
try{const value=entity.getPrice(currency)
return Number.isFinite(value)&&value>0?value:null}catch{return null}}
export function readPreviewPack(entity){const items=entity?.itemCollection
if(!Array.isArray(items))return null
const expires=entity?.previewExpireTime
return{items:items.slice(),
expiresAt:Number.isFinite(expires)&&expires>0?expires:null,
refreshed:entity?.wasRefreshed===true,
best:entity?.previewItem&&typeof entity.previewItem==='object'?entity.previewItem:null}}
export function previewDefinitionId(item,win){const direct=item?.definitionId??item?.defId
if(Number.isSafeInteger(direct)&&direct>0)return direct
const raw=item?.resourceId
const mask=Number.isSafeInteger(win?.ItemIdMask?.DATABASE)?win.ItemIdMask.DATABASE:DATABASE_ID_MASK
if(!Number.isSafeInteger(raw)||raw<=0||!Number.isSafeInteger(mask)||mask<=0)return null
const id=raw&mask
return Number.isSafeInteger(id)&&id>0?id:null}
