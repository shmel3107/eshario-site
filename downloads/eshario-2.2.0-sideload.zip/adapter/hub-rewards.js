import{requestData} from './observable.js'
function objectives(win){const service=win?.services?.Objectives
return service&&typeof service==='object'?service:null}
export function objectivesEnabled(win){const service=objectives(win)
if(service===null||typeof service.isFeatureEnabled!=='function')return null
try{const value=service.isFeatureEnabled()
return typeof value==='boolean'?value:null}catch{return null}}
export function activeCampaign(win){const service=objectives(win)
const repo=service?.objectivesRepository
if(!repo||typeof repo.getActiveCampaign!=='function')return null
try{const campaign=repo.getActiveCampaign()
return campaign&&typeof campaign==='object'?campaign:null}catch{return null}}
export function rewardSetsOf(win,level){const utils=win?.FCRewardUtils??screenClass(win,REWARD_UTILS_DOOR)
const keys=win?.FcasServerFeatureSetting??TOKEN_SETTINGS
const config=win?.services?.FCConfiguration
if(typeof utils?.filterDisabledTokenRewardSets!=='function'||!keys||typeof config?.checkFeatureEnabled!=='function')return null
if(!Array.isArray(level?.rewardSets))return null
try{const generic=config.checkFeatureEnabled(keys.SEASON_GENERIC_TOKEN_ENABLED)===true
const specific=config.checkFeatureEnabled(keys.SEASON_SPECIFIC_TOKEN_ENABLED)===true
const sets=utils.filterDisabledTokenRewardSets(level.rewardSets,generic,specific)
return Array.isArray(sets)?sets:null}catch{return null}}
export function levelClaimable(win,campaign,level){if(!level||typeof level.isClaimable!=='function')return null
try{const xp=campaign?.xp
if(!Number.isFinite(xp))return null
const claimable=level.isClaimable(xp)
if(typeof claimable!=='boolean')return null
if(claimable!==true)return false
const sets=rewardSetsOf(win,level)
if(sets===null)return null
return sets.length>0}catch{return null}}
function allLevels(win,campaign){const out=[]
try{const levels=campaign?.getLevels?.()
if(!Array.isArray(levels))return out
for(const level of levels){if(!level||typeof level!=='object')continue
out.push({level,pass:false})
if(campaign?.hasPremium!==true)continue
try{const paid=campaign.getPremiumLevelById?.(level.id)
if(paid&&typeof paid==='object')out.push({level:paid,pass:true})}catch{
}}}catch{return out}
return out}
const int=(value)=>(Number.isSafeInteger(value)?value:0)
function campaignFacts(campaign){const ask=(fn)=>{try{const value=fn()
return typeof value==='boolean'?value:null}catch{return null}}
let levels=0
let tiers=null
try{const list=campaign?.getLevels?.()
levels=Array.isArray(list)?list.length:0}catch{levels=0}
try{const count=campaign?.getClaimableTierCount?.()
tiers=Number.isSafeInteger(count)?count:null}catch{tiers=null}
return{xp:Number.isFinite(campaign?.xp)?campaign.xp:null,levels,tiers,
unseen:ask(()=>campaign?.hasOutstandingRewards?.()),
milestones:ask(()=>campaign?.hasOutstandingMilestoneRewards?.()),
pass:campaign?.hasPremium===true}}
export function readHubRewards(win){const idle=(reason)=>({ok:false,reason,campaignId:null,claimable:[],choice:0,empty:0,levels:0,unreadable:0,groups:0,
groupsAll:0,groupsExpired:0,groupsBlocked:0,claimAll:null,
campaign:{xp:null,levels:0,tiers:null,unseen:null,milestones:null,pass:false}})
const enabled=objectivesEnabled(win)
if(enabled===false)return idle('objectives-off')
if(enabled===null)return idle('unreadable-objectives')
const campaign=activeCampaign(win)
if(campaign===null)return idle('no-campaign')
const campaignId=Number.isSafeInteger(campaign.id)?campaign.id:null
if(campaignId===null)return idle('no-campaign')
const choiceType=win?.FCRewardGrantType?.CHOICE
const claimable=[]
let choice=0
let empty=0
let unreadable=0
const levels=allLevels(win,campaign)
for(const{level,pass}of levels){const ready=levelClaimable(win,campaign,level)
if(ready===null){unreadable+=1
continue}
if(ready!==true){
try{if(level.isClaimable?.(campaign.xp)===true)empty+=1}catch{unreadable+=1}
continue}
if(choiceType!==undefined&&level.rewardSetFlow===choiceType){choice+=1
continue}
const id=Number.isSafeInteger(level.id)?level.id:null
if(id===null){unreadable+=1
continue}
claimable.push({kind:'level',id,pass})}
let groups=0
try{for(const one of claimableGroups(win)){groups+=1
claimable.push({kind:'group',id:one.id,title:one.title})}}catch{unreadable+=1}
const counted=groupCounts(win)
return{ok:true,reason:null,campaignId,claimable,choice,empty,levels:levels.length,unreadable,groups,
groupsAll:counted.total,groupsExpired:counted.expired,groupsBlocked:counted.blocked,
claimAll:claimAllEnabled(win),
campaign:campaignFacts(campaign)}}
export function findLevel(win,levelId,pass){const campaign=activeCampaign(win)
if(campaign===null)return null
try{const level=pass===true?campaign.getPremiumLevelById?.(levelId):campaign.getLevelById?.(levelId)
if(!level||typeof level!=='object')return null
return{campaign,level}}catch{return null}}
export async function claimHubReward(win,campaign,level){const service=objectives(win)
if(service===null||typeof service.claimLevelReward!=='function'){throw new Error('hub-rewards: у EA нет claimLevelReward')}
const payload=await requestData(service.claimLevelReward(campaign.id,level),'награда FC Hub')
const rewards=Array.isArray(payload?.rewards)?payload.rewards:[]
return{rewards,hasUTRewards:payload?.hasUTRewards===true}}
export async function grantHubItems(win){const service=objectives(win)
if(service===null||typeof service.claimMetaUTRewards!=='function'){throw new Error('hub-rewards: у EA нет claimMetaUTRewards')}
const payload=await requestData(service.claimMetaUTRewards(),'выдача вещей FC Hub')
return{items:Array.isArray(payload?.rewards)?payload.rewards:[]}}
export function readRewardKinds(win,rewards){const types=win?.FCRewardType??REWARD_KINDS
const out={coins:0,packs:0,items:0,xp:0,other:0,unreadable:0}
const list=Array.isArray(rewards)?rewards:[]
for(const reward of list){if(!reward||typeof reward!=='object'){out.unreadable+=1
continue}
try{const kind=reward.awardType??reward.type
const count=Math.max(1,int(reward.count))
if(types===undefined||kind===undefined){out.unreadable+=1
continue}
if(kind===types.COIN){out.coins+=int(reward.value)
continue}
if(kind===types.PACK){out.packs+=count
continue}
if(kind===types.ITEM||kind===types.CONSUMABLE_ITEM){out.items+=count
continue}
if(kind===types.SEASON_XP){out.xp+=1
continue}
out.other+=count}catch{out.unreadable+=1}}
return out}
export function readRewardLoot(win,rewards){const items=[]
let packs=0
const types=win?.FCRewardType??REWARD_KINDS
const list=Array.isArray(rewards)?rewards:[]
for(const reward of list){if(!reward||typeof reward!=='object')continue
try{const item=reward.item??reward.utItem??null
if(item&&typeof item==='object')items.push(item)
const kind=reward.awardType??reward.type
if(reward.isPack===true||(types!==undefined&&kind!==undefined&&kind===types.PACK))packs+=1}catch{
}}
return{items,packs}}
export function noteRewardLoot(win,loot,opts={}){const done=[]
const failed=[]
const step=(name,run)=>{try{run()
done.push(name)}catch{failed.push(name)}}
const items=Array.isArray(loot?.items)?loot.items.filter((one)=>one&&typeof one==='object'):[]
const packs=Number.isSafeInteger(loot?.packs)&&loot.packs>0?loot.packs:0
const net=opts.net!==false
if(items.length>0){const pile=pileNumber(win,'PURCHASED')
const repo=win?.repositories?.Item
if(pile!==undefined&&typeof repo?.setDirty==='function')step('pile-dirty',()=>repo.setDirty(pile))
else failed.push('pile-dirty')
const dispatcher=defaultDispatcher(win)
const name=win?.AppNotification?.UNASSIGNED_ITEM_ADDED??NOTICE_UNASSIGNED_ADDED
if(net&&typeof dispatcher?.notify==='function'&&typeof name==='string'&&name!==''){
step('announce',()=>dispatcher.notify(name,{hubRewardFlow:true},{items}))}
else failed.push('announce')}
if(packs>0){step('unopened',()=>{const one=win?.services?.User?.getUser?.()
if(typeof one?.incrementNumUnopenedPacks!=='function')throw new Error('no counter')
for(let i=0;i<packs;i+=1)one.incrementNumUnopenedPacks()})}
return{ok:failed.length===0,reason:failed.length===0?null:failed[0],done,failed}}
export async function loadObjectiveCategories(win){const service=objectives(win)
if(service===null||typeof service.requestCategories!=='function'){throw new Error('hub-rewards: у EA нет requestCategories')}
const payload=await requestData(service.requestCategories(),'категории задач')
const list=Array.isArray(payload?.categories)?payload.categories:[]
return{count:list.length}}
export function claimAllEnabled(win){const service=objectives(win)
if(service===null||typeof service.isObjectivesClaimAllEnabled!=='function')return null
try{const value=service.isObjectivesClaimAllEnabled()
return typeof value==='boolean'?value:null}catch{return null}}
function categoriesNow(win){const repo=objectives(win)?.objectivesRepository
if(!repo||typeof repo.getCategories!=='function')return[]
try{const list=repo.getCategories()
return Array.isArray(list)?list:[]}catch{return[]}}
function groupExpired(group){try{return group?.hasExpired?.()===true}catch{return true}}
function groupTokenBlocked(win,group){try{const utils=win?.UTEventTokenUtils??screenClass(win,EVENT_TOKEN_UTILS_DOOR)
const service=win?.services?.EventToken
if(typeof utils?.hasEventTokenReward!=='function')return false
if(typeof service?.isEventTokenEarningDisabled!=='function')return false
const rewards=group?.rewards?.rewards
if(!Array.isArray(rewards))return false
if(utils.hasEventTokenReward(rewards)!==true)return false
return service.isEventTokenEarningDisabled()===true}catch{return false}}
function groupReady(win,group,all){try{if(group===null||typeof group!=='object')return false
if(groupExpired(group))return false
if(groupTokenBlocked(win,group))return false
const done=group.isClaimable?.()===true
if(all!==true){
return done&&group.hasUnclaimedObjectiveRewards?.()!==true}
const ask=group.isAnyObjectiveClaimable
if(typeof ask==='function'){const ready=ask.call(group)
if(typeof ready==='boolean')return ready}
const count=group.countNumberOfUnclaimedObjectives?.()
return done||(Number.isSafeInteger(count)&&count>0)}catch{
return false}}
export function claimableGroups(win){const out=[]
const all=claimAllEnabled(win)===true
for(const category of categoriesNow(win)){let groups=[]
try{groups=category?.getGroups?.()??[]}catch{groups=[]}
if(!Array.isArray(groups))continue
for(const group of groups){if(!groupReady(win,group,all))continue
const id=group?.compositeId
if(id===undefined||id===null)continue
out.push({id,category,group,title:typeof group?.name==='string'?group.name:''})}}
return out}
function groupCounts(win){let total=0
let expired=0
let blocked=0
for(const category of categoriesNow(win)){let groups=[]
try{groups=category?.getGroups?.()??[]}catch{groups=[]}
if(!Array.isArray(groups))continue
for(const group of groups){total+=1
if(groupExpired(group)){expired+=1
continue}
if(groupTokenBlocked(win,group))blocked+=1}}
return{total,expired,blocked}}
export function findGroup(win,compositeId){for(const one of claimableGroups(win)){if(one.id===compositeId)return one}
return null}
async function loadGroupDetails(win,category,compositeId){const service=objectives(win)
if(service===null||typeof service.requestGroup!=='function')return null
const payload=await requestData(service.requestGroup(category,compositeId),'подробности группы задач')
const group=payload?.group
return group&&typeof group==='object'?group:null}
function skipError(message){const err=new Error(message)
err.skip=true
return err}
export async function claimGroupReward(win,category,compositeId){const all=claimAllEnabled(win)===true
const call=all?category?.groupClaimAll:category?.claimGroupRewards
if(typeof call!=='function'){throw new Error('hub-rewards: у категории нет вызова наград группы')}
const fresh=await loadGroupDetails(win,category,compositeId)
if(fresh===null){throw skipError('hub-rewards: подробностей группы задач нет')}
if(!groupReady(win,fresh,all)){throw skipError('hub-rewards: забирать в группе задач уже нечего')}
const payload=await requestData(call.call(category,compositeId),'награды задач')
const ids=Array.isArray(payload?.objectiveIds)?payload.objectiveIds:[]
const rewards=Array.isArray(payload?.rewards)?payload.rewards:[]
return{objectives:ids.length,path:all?'claim-all':'group',rewards}}
import{screenPrototype,screenClass}from'./screen-door.js'
import{HOME_HUB_DOOR,pileNumber,defaultDispatcher,NOTICE_UNASSIGNED_ADDED}from'./store-packs.js'
const REWARD_KINDS=Object.freeze({COIN:'coin',PACK:'pack',ITEM:'item',
CONSUMABLE_ITEM:'consumable_item',SEASON_XP:'season_xp'})
const TOKEN_SETTINGS=Object.freeze({SEASON_GENERIC_TOKEN_ENABLED:'enableSeasonGenericToken',
SEASON_SPECIFIC_TOKEN_ENABLED:'enableSeasonSpecificToken'})
export const REWARD_UTILS_DOOR=Object.freeze({name:'reward-utils',
statics:['filterDisabledTokenRewardSets','filterDisabledTokenRewards']})
export const EVENT_TOKEN_UTILS_DOOR=Object.freeze({name:'event-token-utils',
statics:['hasEventTokenReward','isEventTokenRewardType']})
const homeInstallations=new WeakMap()
export function installHomeHubCapture(win,onShown=()=>{}){const idle=(reason)=>({ok:false,reason,state:()=>({ok:false,reason,shown:0}),dispose(){}})
const proto=screenPrototype(win,HOME_HUB_DOOR)
if(typeof proto?.viewDidAppear!=='function')return idle('unavailable')
if(homeInstallations.has(proto))return idle('already')
const raw=proto.viewDidAppear
let shown=0
proto.viewDidAppear=function(){
const out=raw.apply(this,arguments)
try{const view=this.getView?.()??null
const tile=view?.getObjectivesTile?.()??null
const root=tile?.getRootElement?.()??null
if(root&&typeof root.appendChild==='function'){shown+=1
onShown({tile,root})}}catch{
}
return out}
const wrap=proto.viewDidAppear
homeInstallations.set(proto,wrap)
let active=true
return{ok:true,reason:null,
state:()=>({ok:active,reason:null,shown}),
dispose(){if(!active)return
active=false
if(proto.viewDidAppear===wrap)proto.viewDidAppear=raw
homeInstallations.delete(proto)}}}
