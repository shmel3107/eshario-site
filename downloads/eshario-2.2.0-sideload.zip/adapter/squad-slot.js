import{screenPrototype}from'./screen-door.js'
import{SQUAD_SCREEN_DOOR}from'./squad-screen.js'
export const SQUAD_SLOT_DOOR=Object.freeze({name:'squad-slot',
declares:['renderTactical','_renderItem','renderPedestal'],
methods:['render','getRootElement']})
const installations=new WeakMap()
export function installSquadSlotCapture(win,onCapture=()=>{}){const proto=screenPrototype(win,SQUAD_SLOT_DOOR)
if(!proto||typeof proto.render!=='function'||typeof proto.getRootElement!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let installation=installations.get(proto)
if(!installation){const original=proto.render
const listeners=new Set()
const wrapped=function(slot,renderConcept,renderChemistry,renderRestrictions){const result=original.call(this,slot,renderConcept,renderChemistry,renderRestrictions)
let root=null
let item=null
try{root=this.getRootElement();item=typeof slot?.getItem==='function'?slot.getItem():null}catch{}
if(root){for(const listener of listeners){try{listener(root,item)}catch{}}}
return result}
proto.render=wrapped
installation={original,wrapped,listeners}
installations.set(proto,installation)}
installation.listeners.add(onCapture)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.listeners.delete(onCapture)
if(installation.listeners.size===0&&proto.render===installation.wrapped){proto.render=installation.original
installations.delete(proto)}}}}
export function installSquadSelectionCapture(win,onCapture=()=>{}){const proto=screenPrototype(win,SQUAD_SCREEN_DOOR)
if(!proto||typeof proto._eItemTap!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let installation=installations.get(proto)
if(!installation){const original=proto._eItemTap
const listeners=new Set()
const wrapped=function(event,type,data){let item=null
try{const index=data?.slotIndex
const slot=Number.isInteger(index)?this?._squad?.getSlot?.(index):null
item=slot?.getItem?.()??null}catch{}
const result=original.call(this,event,type,data)
if(item&&typeof item==='object'){for(const listener of listeners){try{listener(item)}catch{}}}
return result}
proto._eItemTap=wrapped
installation={original,wrapped,listeners}
installations.set(proto,installation)}
installation.listeners.add(onCapture)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.listeners.delete(onCapture)
if(installation.listeners.size===0&&proto._eItemTap===installation.wrapped){proto._eItemTap=installation.original
installations.delete(proto)}}}}
