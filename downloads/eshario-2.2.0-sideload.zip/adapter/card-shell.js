import{findDoor}from'./doors.js'
export const ITEM_VIEW_DOOR=Object.freeze({name:'item-view',
declares:['setShell','setLocalShell','requestResource'],want:'class',from:'globals'})
const CDN_SHELL=/\/itemBGs\/(?:([0-9a-fA-F-]{36})|large)\/cards_bg_e_(\d+)_(\d+)_(\d+)\.png/
const FALLBACK_SHELL=/images\/Items\/cards_bg_e_(?:1_999_0|999_d_0)\.png/
export function shellKind(url){if(typeof url!=='string'||url.indexOf('cards_bg_e_')<0)return null
if(FALLBACK_SHELL.test(url))return 'fallback'
if(url.indexOf('/itemBGs/')<0)return 'local'
return url.indexOf('/itemBGs/large/')>=0?'cdn-large':'cdn'}
export function shellLabel(url){if(typeof url!=='string')return null
const m=CDN_SHELL.exec(url)
if(m===null)return FALLBACK_SHELL.test(url)?'NOT FOUND':null
const guid=m[1]?m[1].slice(0,8):'large'
return guid+' '+m[3]+'_'+m[4]}
const installs=new WeakMap()
export function installShellWatch(win,listener){const found=findDoor(win,ITEM_VIEW_DOOR)
const proto=found.ok?found.value?.prototype??null:null
if(!proto||typeof proto.loadAsset!=='function')return{ok:false,reason:found.why??'unavailable',dispose(){}}
let installation=installs.get(proto)
if(!installation){const original=proto.loadAsset
const listeners=new Set()
const tell=(view,url,kind,item,type)=>{for(const one of listeners){try{one(view,url,kind,item,type)}catch{/* прибор молчит, отрисовка идёт */}}}
const wrapped=function(url){const result=original.apply(this,arguments)
if(listeners.size>0){const kind=shellKind(url)
if(kind!==null)tell(this,url,kind,arguments[2],arguments[1])}
return result}
proto.loadAsset=wrapped
const originalOk=typeof proto.onLoadAssetSuccess==='function'?proto.onLoadAssetSuccess:null
let wrappedOk=null
if(originalOk!==null){wrappedOk=function(type,img){const result=originalOk.apply(this,arguments)
if(listeners.size>0){let url=null
try{url=typeof img?.src==='string'?img.src:null}catch{url=null}
const kind=shellKind(url)
if(kind==='cdn'||kind==='cdn-large')tell(this,url,'loaded',arguments[2],type)
else if(kind==='fallback')tell(this,url,'stub-loaded',arguments[2],type)}
return result}
proto.onLoadAssetSuccess=wrappedOk}
installation={original,wrapped,originalOk,wrappedOk,listeners}
installs.set(proto,installation)}
installation.listeners.add(listener)
let active=true
const own=installation
return{ok:true,reason:null,dispose(){if(!active)return
active=false
own.listeners.delete(listener)
if(own.listeners.size>0)return
if(proto.loadAsset===own.wrapped)proto.loadAsset=own.original
if(own.wrappedOk!==null&&proto.onLoadAssetSuccess===own.wrappedOk)proto.onLoadAssetSuccess=own.originalOk
installs.delete(proto)}}}
export function askShell(view,url,type,item,onFail){if(typeof view?.loadAsset!=='function')return false
try{view.loadAsset(url,type,item,function(){try{onFail()}catch{/* тишина */}})
return true}catch{return false}}
export function shellSlot(view,type){try{return view?.assets?.get?.(type)??null}catch{return null}}
export function shellFacts(win,item){let rareflag=null
let tier=null
let concept=null
let known=null
let count=null
try{rareflag=Number.isSafeInteger(item?.rareflag)?item.rareflag:null}catch{rareflag=null}
try{tier=typeof item?.getTier==='function'?item.getTier():null}catch{tier=null}
try{concept=typeof item?.concept==='boolean'?item.concept:null}catch{concept=null}
let book=null
try{book=win?.repositories?.Rarity??null}catch{book=null}
try{count=typeof book?.length==='number'?book.length:null}catch{count=null}
try{known=rareflag===null||typeof book?.get!=='function'?null:Boolean(book.get(rareflag))}catch{known=null}
return{rareflag,tier,concept,known,count}}
export function screenTitle(doc){try{const node=doc?.querySelector?.('.ut-navigation-bar-view .title')
const text=typeof node?.textContent==='string'?node.textContent.trim():''
return text===''?null:text.slice(0,40)}catch{return null}}
export function eaBuild(doc){try{const src=doc?.querySelector?.('script[src*="compiled_1.js"]')?.src??''
const m=/[?&]_=(\d+)/.exec(src)
return m===null?null:m[1]}catch{return null}}
