import{refusesSuperclass} from './sbc-screen.js'
import{findDoor} from './doors.js'
const installations=new WeakMap()
const SET_VIEW=Object.freeze({name:'sbc-challenges-view',
declares:['setSBCSet','clearChallenges','eChallengeRowSelected'],want:'class'})
const LOCALIZATION_UTIL=Object.freeze({name:'localization-util',
statics:['buildRewardString','injuryTypeToName'],want:'class'})
function doorClass(win,door){if(!win||(typeof win!=='object'&&typeof win!=='function'))return null
const found=findDoor(win,door)
return found.ok&&typeof found.value==='function'?found.value:null}
const UNTRADEABLE_KEY='infopanel.context.untradeable'
export const HOOK_SET_SBC_SET='setSBCSet'
export const CHALLENGES_HOST_SELECTOR='.ut-sbc-challenges-view--challenges'
export const CHALLENGE_ROW_SELECTOR='.ut-sbc-challenge-table-row-view'
export const CHALLENGE_CONTENT_SELECTOR='.ut-sbc-challenge-table-row-view--content'
export const SET_INFO_SELECTOR='.ut-sbc-set-info-view'
export const SET_STATUS_SELECTOR='.sbc-status-container'
export const SET_EXPIRY_SELECTOR='.expiry'
export function installSbcSetCapture(win,onSet=()=>{}){const proto=doorClass(win,SET_VIEW)?.prototype??null
if(typeof proto?.[HOOK_SET_SBC_SET]!=='function'){return{ok:false,reason:'unavailable',missing:[SET_VIEW.name],refused:[],dispose(){}}}
if(refusesSuperclass(proto[HOOK_SET_SBC_SET])){return{ok:false,reason:'refused',missing:[],refused:[HOOK_SET_SBC_SET],permanent:true,dispose(){}}}
let installation=installations.get(proto)
if(!installation){const listeners=new Set()
const original=proto[HOOK_SET_SBC_SET]
const wrapped=function(set){const result=original.apply(this,arguments)
notify(this,set,listeners)
return result}
proto[HOOK_SET_SBC_SET]=wrapped
installation={original,wrapped,listeners}
installations.set(proto,installation)}
installation.listeners.add(onSet)
let active=true
return{ok:true,reason:null,missing:[],refused:[],dispose(){if(!active)return
active=false
installation.listeners.delete(onSet)
if(installation.listeners.size>0)return
if(proto[HOOK_SET_SBC_SET]===installation.wrapped)proto[HOOK_SET_SBC_SET]=installation.original
installations.delete(proto)}}}
function notify(view,set,listeners){let root=null
try{root=typeof view?.getRootElement==='function'?view.getRootElement():null}catch{root=null}
if(!root||!set)return
let host=null
try{host=root.querySelector?.(CHALLENGES_HOST_SELECTOR)??null}catch{host=null}
if(!host)return
const rows=pairRows(host,set)
for(const listener of listeners){try{listener({set,view,root,host,rows})}catch{}}}
export function pairRows(host,set){let list=null
try{list=typeof set?.getChallenges==='function'?set.getChallenges():null}catch{list=null}
if(!Array.isArray(list)||list.length===0)return[]
const sorted=list.slice().sort((a,b)=>priorityOf(a)-priorityOf(b))
let nodes=[]
try{nodes=Array.from(host?.children??[]).filter((node)=>node?.matches?.(CHALLENGE_ROW_SELECTOR)===true)}catch{nodes=[]}
const pairs=[]
const count=Math.min(nodes.length,sorted.length)
for(let at=0;at<count;at+=1){if(nodes[at]&&sorted[at])pairs.push({root:nodes[at],challenge:sorted[at]})}
return pairs}
function priorityOf(challenge){try{const value=Number(challenge?.priority)
return Number.isFinite(value)?value:Number.MAX_SAFE_INTEGER}catch{return Number.MAX_SAFE_INTEGER}}
export function challengeFactsOf(challenge){const read=(fn,fallback=null)=>{try{const value=fn()
return value===undefined?fallback:value}catch{return fallback}}
const id=read(()=>Number(challenge?.id),null)
let awards=read(()=>challenge?.awards,null)
if(!Array.isArray(awards))awards=[]
return{
id:Number.isFinite(id)?id:null,
name:read(()=>(typeof challenge?.name==='string'?challenge.name:''),'')??'',
done:read(()=>challenge?.isCompleted?.()===true,false)===true,
started:read(()=>challenge?.isInProgress?.()===true,false)===true,
brick:read(()=>challenge?.isBrickChallenge?.()===true,false)===true,
award:awards.length>0?awards[0]:null,
awards}}
export function requirementTextsOf(challenge){const out=[]
for(const pair of requirementPairsOf(challenge)){if(pair.text!==null)out.push(pair.text)}
return out}
export function requirementPairsOf(challenge){let list=null
try{list=challenge?.eligibilityRequirements}catch{list=null}
if(!Array.isArray(list))return[]
const out=[]
for(const one of list){let text=null
try{const said=one?.buildString?.()
if(typeof said==='string'&&said.trim()!=='')text=said.trim()}catch{/* одно требование не роняет остальные */}
out.push({raw:one,text})}
return out}
export function rewardTextOf(win,award){if(!award||typeof award!=='object')return null
try{const host=doorClass(win,LOCALIZATION_UTIL)
const build=host?.buildRewardString
const localization=win?.services?.Localization
if(typeof build!=='function'||!localization)return null
const text=build.call(host,award,localization)
if(typeof text!=='string')return null
const said=text.trim()
if(said==='')return null
return said===untradeableTailOf(localization)?null:said}catch{return null}}
function untradeableTailOf(localization){try{const word=localization?.localize?.(UNTRADEABLE_KEY)
if(typeof word!=='string')return null
const said=word.trim()
return said===''||said===UNTRADEABLE_KEY?null:'('+said+')'}catch{return null}}
