export const TRADE_ACCESS=Object.freeze({NONE:0,BANNED:1,ALLOWED:2,CONSOLE_ONLY:3,UNAVAILABLE:4,MAINTENANCE:100})
const levelOf=(win,name)=>{const value=win?.TradeAccessLevel?.[name]
return Number.isFinite(value)?value:TRADE_ACCESS[name]}
export function readTradeAccess(win=globalThis){let user=null
try{user=win?.services?.User?.getUser?.()??null}catch{user=null}
if(!user||typeof user!=='object')return{known:false,allowed:false,consoleOnly:false,level:null}
let level=null
try{level=Number.isFinite(user.tradeAccess)?user.tradeAccess:null}catch{level=null}
let allowed=null
try{if(typeof user.hasTradeAccess==='function')allowed=user.hasTradeAccess()===true}catch{allowed=null}
if(allowed===null)allowed=level!==null&&level===levelOf(win,'ALLOWED')
return{known:true,allowed,consoleOnly:allowed===false&&level!==null&&level===levelOf(win,'CONSOLE_ONLY'),level}}
