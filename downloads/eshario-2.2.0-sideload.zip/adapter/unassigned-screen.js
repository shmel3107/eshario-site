import{stopOnEaLimit,stopsRequest,EA_LIMIT,askDayBudget} from '../features/day-budget.js'
import{toPromise} from './observable.js'
import{pileRoom,storagePileEnabled,reviewAction,redeemableEntity,ALLOWED,UNKNOWN} from './action-door.js'
import{screenPrototype,screenClass}from'./screen-door.js'
import{pileNumber,UNASSIGNED_LIST_DOOR}from'./store-packs.js'
import{localizationUtil}from'./squad-screen.js'
export const UNASSIGNED_SCREEN_DOOR=UNASSIGNED_LIST_DOOR
const PLAYER_PICK_SUBTYPE=237
function playerPickSubtype(win){const live=win?.ItemSubType?.PLAYER_PICK_ITEM
return Number.isSafeInteger(live)?live:PLAYER_PICK_SUBTYPE}
export{pileRoom}
export{storagePileEnabled as storageEnabled}
export function pileLoaded(win,name){const pile=pileNumber(win,name)
const repo=win?.repositories?.Item
if(pile===undefined||typeof repo?.isDirty!=='function'||typeof repo?.numItemsInCache!=='function')return null
let dirty=null
let used=null
try{dirty=repo.isDirty(pile)
used=repo.numItemsInCache(pile)}catch{return null}
if(typeof dirty!=='boolean'||!Number.isSafeInteger(used))return null
return !(dirty===true&&used===0)}
function pileFacts(win,name){const room=pileRoom(win,name)
const loaded=pileLoaded(win,name)
return room===null?null:{...room,loaded}}
const screenInstallations=new WeakMap()
export function unassignedName(item){let value=null
try{value=item?.getStaticData?.()?.name??item?.displayName??item?.name??null}catch{return null}
const text=typeof value==='string'?value.trim():''
return text===''?null:text}
const ITEM_FACTS=Object.freeze([['movable','isMovable'],['misc','isMiscItem'],['storable','isStorable'],
['vanity','isVanityItem'],['duplicate','isDuplicate'],['tradeableDuplicate','isTradeableDuplicate'],
['untradeableDuplicate','isUnTradeableDuplicate'],['discardable','isDiscardable'],['duplicateLoan','isDuplicateLoanPlayer']])
export function unassignedFacts(item,win=null){if(!item||typeof item!=='object')return null
if(!Number.isSafeInteger(item.id)||item.id<0)return null
if(!Number.isSafeInteger(item.definitionId)||item.definitionId<1)return null
if(typeof item.tradable!=='boolean')return null
if(!Number.isSafeInteger(item.discardValue)||item.discardValue<0)return null
let rating=null
try{const value=item.rating
rating=Number.isSafeInteger(value)&&value>=0?value:null}catch{rating=null}
const facts={id:item.id,definitionId:item.definitionId,tradable:item.tradable,discardValue:item.discardValue,rating}
try{for(const[field,method]of ITEM_FACTS){if(typeof item[method]!=='function')return null
const value=item[method]()
if(typeof value!=='boolean')return null
facts[field]=value}}catch{return null}
return{...facts,...brainFacts(item,win)}}
function brainFacts(item,win){const out={type:null,subtype:null,nationId:null,tier:null,
special:null,limitedUse:null,player:null,redeemable:false,pick:false,dupClub:null,dupClubId:null}
const ask=(method)=>{try{return typeof item[method]==='function'?item[method]():null}catch{return null}}
const field=(name)=>{try{const value=item[name]
return Number.isSafeInteger(value)?value:null}catch{return null}}
try{out.type=typeof item.type==='string'?item.type:null}catch{out.type=null}
out.subtype=field('subtype')
out.nationId=field('nationId')
out.leagueId=field('leagueId')
const tier=ask('getTier')
out.tier=Number.isSafeInteger(tier)?tier:null
const special=ask('isSpecial')
out.special=typeof special==='boolean'?special:null
const loan=ask('isLimitedUse')
out.limitedUse=typeof loan==='boolean'?loan:null
const player=ask('isPlayer')
out.player=typeof player==='boolean'?player:null
out.redeemable=redeemableEntity(item,win)===true
const kinds=win?.ItemSubType??null
out.pick=out.subtype===playerPickSubtype(win)
Object.assign(out,clubCopy(item,win,out))
return out}
function clubCopy(item,win,facts){const out={dupClub:null,dupClubId:null}
let id=null
try{id=Number.isSafeInteger(item.duplicateId)&&item.duplicateId>0?item.duplicateId:null}catch{id=null}
if(id===null)return out
let club=null
try{club=win?.repositories?.Item?.getClub?.()??null}catch{club=null}
if(!club||typeof club.getItem!=='function')return out
let copy=null
try{copy=club.getItem(facts.type,null,id)??null}catch{copy=null}
if(!copy||typeof copy!=='object')return out
let same=false
try{same=Number.isSafeInteger(copy.definitionId)&&copy.definitionId===item.definitionId}catch{same=false}
if(!same)return out
let tradable=null
try{tradable=typeof copy.tradable==='boolean'?copy.tradable:null}catch{tradable=null}
if(tradable===null)return out
return{dupClub:tradable?'tradable':'untradeable',dupClubId:id}}
export function unassignedCatalog(win){if(!win||typeof win!=='object')return EMPTY_CATALOG
const known=catalogs.get(win)
if(known)return known
const loc=win?.services?.Localization??null
const util=localizationUtil(win)
const kinds=win?.ItemSubType??null
const styles=[]
if(loc&&typeof util?.playStyleIdToName==='function'&&kinds){for(const[name,value]of Object.entries(kinds)){if(!/^TRAINING_PLAYERSTYLE_/.test(name)||!Number.isSafeInteger(value))continue
let label=null
try{label=util.playStyleIdToName(value,loc)}catch{label=null}
if(typeof label==='string'&&label.trim()!=='')styles.push({id:value,name:label})}}
styles.sort((a,b)=>a.id-b.id)
const leagues=[]
const nations=[]
const seen=new Set()
const pushNation=(id,name)=>{if(!Number.isSafeInteger(id)||id<0||seen.has(id))return
if(typeof name!=='string'||name.trim()==='')return
seen.add(id)
nations.push({id,name})}
const top=Array.isArray(win?.TOP_NINE_NATIONS)?win.TOP_NINE_NATIONS:[]
if(loc&&typeof util?.nationIdToName==='function'){for(const id of top){let label=null
try{label=util.nationIdToName(id,loc)}catch{label=null}
pushNation(id,label)}}
let all=[]
try{all=win?.repositories?.TeamConfig?.getNations?.()??[]}catch{all=[]}
const tail=(Array.isArray(all)?all:[]).filter((one)=>Number.isSafeInteger(one?.id)&&!seen.has(one.id)
&&typeof one?.name==='string'&&one.name.trim()!=='')
try{tail.sort((a,b)=>String(a.name).localeCompare(String(b.name)))}catch{/* сравнение недоступно — остаётся её порядок */}
for(const one of tail)pushNation(one?.id,one?.name)
if(loc&&typeof util?.leagueIdToName==='function'){let all=[]
try{all=win?.repositories?.TeamConfig?.getLeagues?.()??[]}catch{all=[]}
const rows=[]
for(const one of Array.isArray(all)?all:[]){const id=one?.id
if(!Number.isSafeInteger(id)||id<0)continue
let label=typeof one?.name==='string'&&one.name.trim()!==''?one.name:null
if(label===null){try{label=util.leagueIdToName(id,loc)}catch{label=null}}
if(typeof label!=='string'||label.trim()==='')continue
rows.push({id,name:label,abbr:typeof one?.abbreviation==='string'?one.abbreviation:''})}
const rank=(row)=>{const top=LEAGUE_TOP.indexOf(row.abbr)
if(top>=0)return top
return LEAGUE_LAST.includes(row.abbr)?LEAGUE_TOP.length+1:LEAGUE_TOP.length}
try{rows.sort((a,b)=>{const ra=rank(a)
const rb=rank(b)
return ra!==rb?ra-rb:String(a.name).localeCompare(String(b.name))})}catch{/* сравнение недоступно — остаётся её порядок */}
for(const row of rows)leagues.push({id:row.id,name:row.name})}
const catalog={styles,nations,leagues}
if(styles.length>0||nations.length>0||leagues.length>0)catalogs.set(win,catalog)
return catalog}
const EMPTY_CATALOG=Object.freeze({styles:[],nations:[],leagues:[]})
const catalogs=new WeakMap()
const LEAGUE_TOP=Object.freeze(['ENG 1','ENG 2','ENG 3','ENG 4','FRA 1','FRA 2',
'ITA 1','ITA 2','GER 1','GER 2','GER 3','ESP 1','ESP 2'])
const LEAGUE_LAST=Object.freeze(['AUT 1','CZE 1'])
export function readUnassignedScreen(controller,win){const viewmodel=controller?.viewmodel??null
if(!viewmodel||typeof viewmodel.values!=='function')return null
let box=null
try{box=controller.getView?.()?.getRootElement?.()??null}catch{box=null}
if(!box||typeof box.querySelector!=='function')return null
let list=[]
try{list=viewmodel.values()}catch{return null}
if(!Array.isArray(list))return null
const cards=[]
const blind=[]
for(const item of list){const facts=unassignedFacts(item,win)
if(facts)cards.push(facts)
else blind.push(item)}
return{box,controller,viewmodel,cards,unreadable:blind.length,blind,
nameOf(id){if(!Number.isSafeInteger(id))return null
for(const item of list){let own=null
try{own=item?.id}catch{own=null}
if(own===id)return unassignedName(item)}
return null},
catalog:unassignedCatalog(win),
capacity:{transfer:pileFacts(win,'TRANSFER'),storage:pileFacts(win,'STORAGE')},
storage:storagePileEnabled(win),
win}}
export function installUnassignedScreenCapture(win,onCapture=()=>{}){const proto=screenPrototype(win,UNASSIGNED_SCREEN_DOOR)
if(!proto||typeof proto.renderView!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let installation=screenInstallations.get(proto)
if(!installation){const original=proto.renderView
const listeners=new Set()
const wrapped=function(){const result=original.apply(this,arguments)
let capture=null
try{capture=readUnassignedScreen(this,win)}catch{capture=null}
if(capture){for(const listener of listeners){try{listener(capture)}catch{}}}
return result}
proto.renderView=wrapped
installation={original,wrapped,listeners}
screenInstallations.set(proto,installation)}
installation.listeners.add(onCapture)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.listeners.delete(onCapture)
if(installation.listeners.size===0&&proto.renderView===installation.wrapped){proto.renderView=installation.original
screenInstallations.delete(proto)}}}}
const STEP_PILES=Object.freeze({transfer:['TRANSFER',false],club:['CLUB',false],storage:['STORAGE',true],
'club-out':['TRANSFER',false]})
export function itemIdOf(value){if(typeof value==='number')return Number.isSafeInteger(value)?value:null
if(typeof value!=='string'||value.trim()==='')return null
const number=Number(value)
return Number.isSafeInteger(number)?number:null}
function idsFrom(raw){if(!Array.isArray(raw))return null
const out=new Set()
for(const entry of raw){const id=itemIdOf(entry&&typeof entry==='object'?entry.id:entry)
if(id!==null)out.add(id)}
return out}
function rereadScreen(controller){if(typeof controller?.getUnassignedItems!=='function')return false
try{controller.getUnassignedItems()
return true}catch{return false}}
export function createUnassignedPerform(deps={}){const readScreen=typeof deps.screen==='function'?deps.screen:()=>null
const win=deps.win??null
const budget=deps.budget??null
const STEP_CALLS=2
return async function perform(kind,ids,expect){const wanted=Array.isArray(ids)?ids.filter((id)=>Number.isSafeInteger(id)):[]
if(wanted.length===0)return{ok:false,reason:'nothing-to-do'}
const screen=readScreen()
if(!screen?.viewmodel)return{ok:false,reason:'no-screen'}
if(kind==='club-out')return performClubOut(screen,win,wanted,expect,budget)
const collect=()=>{let live=[]
try{live=screen.viewmodel.values()}catch{return{ok:false,reason:'no-screen'}}
const byId=new Map()
for(const item of Array.isArray(live)?live:[]){const id=itemIdOf(item?.id)
if(id!==null&&!byId.has(id))byId.set(id,item)}
const found=[]
for(const id of wanted){const item=byId.get(id)
if(item)found.push(item)}
if(found.length===0)return{ok:false,reason:'stale'}
const door=reviewAction(kind==='discard'||kind==='redeem'
?{win:screen.win??win,action:kind,items:found}
:{win:screen.win??win,action:'move',destination:STEP_PILES[kind]?.[0]??null,items:found})
if(door.verdict!==ALLOWED)return{ok:false,reason:door.verdict===UNKNOWN?`door-${door.reason}`:door.reason,door}
return{ok:true,entities:found}}
let ready=collect()
if(ready.ok!==true)return ready
const word=await askDayBudget(budget,STEP_CALLS)
if(word!==null)return{ok:false,reason:word}
ready=collect()
if(ready.ok!==true)return ready
const entities=ready.entities
const service=win?.services?.Item
const finish=(result)=>{
if(result?.ok===true)rereadScreen(screen.controller)
return result}
if(kind==='discard'){if(typeof service?.discard!=='function')return{ok:false,reason:'guard-unavailable'}
return finish(await settle(toPromise(service.discard(entities)),entities,budget))}
if(kind==='redeem'){if(typeof service?.redeem!=='function')return{ok:false,reason:'guard-unavailable'}
if(entities.length!==1)return{ok:false,reason:'chunk-too-big'}
return finish(await settle(toPromise(service.redeem(entities[0])),entities,budget))}
const spec=STEP_PILES[kind]
const pile=spec?pileNumber(win,spec[0]):undefined
if(!spec||pile===undefined||typeof service?.move!=='function')return{ok:false,reason:'guard-unavailable'}
return finish(await settle(toPromise(spec[1]?service.move(entities,pile,true):service.move(entities,pile)),entities,budget))}}
export function createUnassignedNativeStep(deps={}){
const bulk=deps.bulk&&typeof deps.bulk.step==='function'?deps.bulk:null
return async function nativeStep(kind,ids){const wanted=Array.isArray(ids)?ids.filter((id)=>Number.isSafeInteger(id)):[]
if(bulk===null||wanted.length===0)return{ok:false,reason:'not-native',why:'no-door'}
let said=null
try{said=await bulk.step(kind,wanted)}catch{return{ok:false,reason:'not-native',why:'failed'}}
if(said?.ok!==true&&stopsRequest(said?.reason))return{ok:false,reason:said.reason,door:said?.door??null}
if(said?.ok!==true)return{ok:false,reason:'not-native',why:said?.reason??'no-door'}
if(said.reason==='confirm')return{ok:true,reason:'confirm',count:0,cards:said.cards,door:said.door}
let answer=null
try{answer=await said.wait}catch{answer=null}
if(answer?.reason==='unpressed')return{ok:true,reason:'confirm',count:0,cards:said.cards,door:said.door}
if(answer?.ok!==true)return{ok:false,reason:answer?.reason??'no-answer',door:said.door}
const heard=Number.isSafeInteger(answer.said)&&Number.isSafeInteger(answer.took)
if(heard&&answer.took===0)return{ok:false,reason:'uncertain',door:said.door}
return{ok:true,reason:null,count:heard?Math.min(answer.took,said.cards):said.cards,cards:said.cards,door:said.door}}}
async function performClubOut(screen,win,wanted,expect,budget=null){const box=screen?.win??win
let club=null
try{club=box?.repositories?.Item?.getClub?.()??null}catch{club=null}
if(!club||typeof club.getItem!=='function')return{ok:false,reason:'no-club'}
const want=expect&&typeof expect==='object'?expect:null
if(!want)return{ok:false,reason:'no-expect'}
const collect=()=>{const found=[]
for(const id of wanted){const definition=want[id]
if(!Number.isSafeInteger(definition))return{ok:false,reason:'no-expect'}
let item=null
try{item=club.getItem('player',null,id)??null}catch{item=null}
if(!item||typeof item!=='object')continue
let same=false
try{same=Number.isSafeInteger(item.definitionId)&&item.definitionId===definition}catch{same=false}
if(!same)return{ok:false,reason:'club-copy-changed'}
let tradable=null
try{tradable=typeof item.tradable==='boolean'?item.tradable:null}catch{tradable=null}
if(tradable!==true)return{ok:false,reason:'club-copy-untradable'}
found.push(item)}
if(found.length===0)return{ok:false,reason:'stale'}
const door=reviewAction({win:box,action:'move',destination:'TRANSFER',items:found})
if(door.verdict!==ALLOWED)return{ok:false,reason:door.verdict===UNKNOWN?`door-${door.reason}`:door.reason,door}
return{ok:true,entities:found}}
let ready=collect()
if(ready.ok!==true)return ready
const service=box?.services?.Item
const pile=pileNumber(box,'TRANSFER')
if(pile===undefined||typeof service?.move!=='function')return{ok:false,reason:'guard-unavailable'}
const word=await askDayBudget(budget,1)
if(word!==null)return{ok:false,reason:word}
ready=collect()
if(ready.ok!==true)return ready
const result=await settle(toPromise(service.move(ready.entities,pile)),ready.entities,budget)
if(result?.ok===true)rereadScreen(screen.controller)
return result}
async function settle(promise,entities,budget=null){let raw=null
try{raw=await promise}catch(err){
if(stopOnEaLimit(budget,err)!==null)return{ok:false,reason:EA_LIMIT}
return{ok:false,reason:'uncertain'}}
if(raw?.success!==true){if(stopOnEaLimit(budget,raw)!==null)return{ok:false,reason:EA_LIMIT}
return{ok:false,reason:'uncertain'}}
const moved=idsFrom(raw?.data?.itemIds)
const swapped=idsFrom(raw?.data?.clubDuplicates)
if(moved===null&&swapped===null)return{ok:false,reason:'uncertain'}
let taken=0
for(const item of entities){const id=itemIdOf(item?.id)
if(id!==null&&moved?.has(id)===true){taken+=1
continue}
const twin=itemIdOf(item?.duplicateId)
if(twin!==null&&swapped?.has(twin)===true)taken+=1}
if(taken===0)return{ok:false,reason:'uncertain'}
return{ok:true,reason:null,count:taken}}
