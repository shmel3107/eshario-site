import{findDoor,watchDoor,findEnum}from'./doors.js'
export const APP_MAIN_DOOR=Object.freeze({name:'app-main',
declares:['getRootViewController','getLoginController'],
want:'instance',
instanceVia:Object.freeze(['getRootViewController','getLoginController',
'getDefaultDispatcher','getConfigRepository','getNetworkErrorController'])})
export function appMain(win){const found=findDoor(win,APP_MAIN_DOOR)
if(found.ok)return found.value
watchDoor(win,APP_MAIN_DOOR)
return null}
export function warmNavigationDoors(win){appMain(win)
liveController(win)}
export const SECTIONS_DOOR=Object.freeze({name:'deep-link-sections',
keys:Object.freeze(['HOME','SBC','STORE','AUCTION','UNASSIGNED','OBJECTIVES'])})
export function deepLinkSections(win){const found=findEnum(win,SECTIONS_DOOR.keys,{name:SECTIONS_DOOR.name})
return found.ok?found.value:null}
export const VIEW_CONTROLLER_DOOR=Object.freeze({name:'view-controller',
declares:['getNavigationController','getRootNavigationController'],
want:'instance',instanceVia:'getNavigationController'})
export function liveViewController(win){const found=findDoor(win,VIEW_CONTROLLER_DOOR)
if(found.ok)return found.value
watchDoor(win,VIEW_CONTROLLER_DOOR)
return null}
const liveController=liveViewController
export function liveNavigation(win){let nav=null
try{nav=liveController(win)?.getNavigationController?.()??null}catch{return null}
return typeof nav?.pushViewController==='function'?nav:null}
export function liveCurrentController(win){try{const nav=liveController(win)?.getNavigationController?.()??null
const current=typeof nav?.getCurrentController==='function'?nav.getCurrentController():null
return current??null}catch{return null}}
export const DEEP_LINK_PROTOCOL='easfc://'
export const DEEP_LINK_FEATURE='fut'
export const SAFE_ARG=/^[A-Za-z0-9_-]+$/
export function buildDeepLinkUrl(sectionId,args=[]){if(typeof sectionId!=='string'||sectionId===''){throw new Error('adapter: пустой идентификатор раздела')}
if(!SAFE_ARG.test(sectionId)){throw new Error(`adapter: недопустимый идентификатор раздела «${sectionId}»`)}
const parts=[DEEP_LINK_PROTOCOL+DEEP_LINK_FEATURE,sectionId]
for(const arg of args){const value=String(arg)
if(!SAFE_ARG.test(value)){throw new Error(`adapter: недопустимый аргумент ссылки «${value}»`)}
parts.push(value)}
return parts.join('/')}
export function createNavigationAdapter(services,sections,appWindow=globalThis){const url=services?.URL
if(!url||typeof url.process!=='function'||typeof url.isValidDeepLinkID!=='function'){throw new Error('adapter: services.URL недоступен')}
if(!sections||typeof sections!=='object'){throw new Error('adapter: таблица разделов DeepLinkSection недоступна')}
const sectionId=(name)=>{if(typeof name!=='string'||!Object.hasOwn(sections,name)) return null
const value=sections[name]
return typeof value==='string'&&value!==''?value:null}
return{sectionId,
isAvailable(name){const id=sectionId(name)
if(id===null)return false
try{return Boolean(url.isValidDeepLinkID(id))}catch{return false}},
pushScreen(screen){if(!screen||typeof screen!=='object') return{ok:false,reason:'no-screen'}
try{
const app=appMain(appWindow)
const root=app?.getRootViewController?.()
const presented=root?.getPresentedViewController?.()
const current=presented?.getCurrentViewController?.()
if(typeof current?.pushViewController==='function'){current.pushViewController(screen)
return{ok:true,reason:null}}
const nav=liveController(appWindow)?.getNavigationController?.()
if(typeof nav?.pushViewController!=='function'){return{ok:false,reason:'no-navigation'}}
nav.pushViewController(screen)
return{ok:true,reason:null}}catch(err){return{ok:false,reason:'failed',detail:String(err?.message??err)}}},
go(name,args=[]){const id=sectionId(name)
if(id===null) return{ok:false,reason:'unknown-section',url:null}
let link
try{link=buildDeepLinkUrl(id,args)}catch(err){return{ok:false,reason:'bad-argument',url:null,detail:err.message}}
try{if(!url.isValidDeepLinkID(id)) return{ok:false,reason:'not-registered',url:link}
return url.process(link)
?{ok:true,reason:null,url:link}
:{ok:false,reason:'rejected',url:link}}catch(err){return{ok:false,reason:'failed',url:link,detail:String(err?.message??err)}}}}}
export function createNavigation(win=globalThis){
warmNavigationDoors(win)
return createNavigationAdapter(win?.services,deepLinkSections(win),win)}
