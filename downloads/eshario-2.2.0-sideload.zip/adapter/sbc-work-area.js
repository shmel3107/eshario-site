const seen={overview:null,installed:false}
const stats={calls:0,restored:0,watched:0}
const RESTORE_FRAMES=60
import{findDoor} from './doors.js'
const get=(read)=>{try{return read()}catch{return null}}
const SQUAD_OVERVIEW_DOOR=Object.freeze({name:'squad-overview-screen',
declares:['initWithSquad','_eDragEnd','_eDragStart'],want:'class'})
const viewOf=()=>get(()=>seen.overview?.getView?.())??null
function aliveNow(){const view=viewOf()
const pitch=get(()=>view?._pitch)??get(()=>view?.getPitch?.())??null
return[get(()=>view?.isInteractionEnabled?.()),get(()=>pitch?.isInteractionEnabled?.())]}
export function createWorkAreaProbe(win=globalThis){return{install:()=>install(win),restore:()=>restore(win),
state:()=>({installed:seen.installed,known:seen.overview!==null,alive:aliveNow(),...stats,frames:RESTORE_FRAMES})}}
function install(win){if(seen.installed)return false
if(!win||(typeof win!=='object'&&typeof win!=='function'))return false
const found=findDoor(win,SQUAD_OVERVIEW_DOOR)
const proto=found.ok&&typeof found.value==='function'?found.value.prototype??null:null
if(typeof proto?.initWithSquad!=='function')return false
seen.installed=true
const enter=proto.initWithSquad
proto.initWithSquad=function(){seen.overview=this
return enter.apply(this,arguments)}
return true}
function restore(win){stats.calls+=1
const run=()=>{const view=viewOf()
if(get(()=>view?.isInteractionEnabled?.())!==false)return
try{view.setInteractionState(true)
stats.restored+=1}catch{}}
const frame=win?.requestAnimationFrame
if(typeof frame!=='function'){run()
return false}
let left=RESTORE_FRAMES
const step=()=>{run()
left-=1
if(left>0)frame.call(win,step)
else stats.watched+=1}
frame.call(win,step)
return true}
