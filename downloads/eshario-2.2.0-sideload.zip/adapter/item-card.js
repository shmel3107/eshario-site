import{createConceptItem}from './concept-item.js'
export const CARD_STEPS=Object.freeze(['no-factory','no-item','create','init','render','no-root','mount'])
export function mountItemCard(win,host,source={}){if(!win||!host)return{ok:false,step:'no-factory'}
const factory=win?.UTItemViewFactory
if(typeof factory?.createSmallItem!=='function')return{ok:false,step:'no-factory'}
const item=createConceptItem(win,{definitionId:source?.definitionId,
rating:Number.isSafeInteger(source?.rating)&&source.rating>0?source.rating:null})
if(item===null)return{ok:false,step:'no-item'}
let view=null
try{view=factory.createSmallItem(item)}catch{return{ok:false,step:'create'}}
if(!view)return{ok:false,step:'create'}
try{view.init?.()}catch{return dispose(view,null,'init')}
try{view.render(item)}catch{return dispose(view,null,'render')}
let root=null
try{root=view.getRootElement?.()??null}catch{root=null}
if(!root)return dispose(view,null,'no-root')
try{host.appendChild(root)}catch{return dispose(view,null,'mount')}
return{ok:true,node:root,dispose:()=>{dispose(view,root,'drop')}}}
function dispose(view,root,step){try{view?.dealloc?.()}catch{
}
try{root?.remove?.()}catch{
}
return{ok:false,step}}
