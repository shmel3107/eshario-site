export function popupOpen(win){const door=win?.getKeyboardEventController
if(typeof door!=='function')return null
let controller=null
try{controller=door.call(win)}catch{return null}
const table=controller?.eventDelegates
if(!table||typeof table.get!=='function')return null
const priorities=win?.KeyboardEventPriority
for(const name of['POPUP','ACTIVE_ELEMENT']){const key=priorities?.[name]
if(typeof key!=='number')return null
let list=null
try{list=table.get(key)}catch{return null}
if(!Array.isArray(list))return null
if(list.length>0)return true}
return false}
