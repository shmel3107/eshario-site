import { screenClass, screenPrototype } from './screen-door.js'
export const SQUAD_SCREEN_DOOR = Object.freeze({
name: 'squad-screen',
declares: ['onWindowSizeChange', '_updateDragDrop', '_pushSquadToView'],
methods: ['_eItemTap'],
})
export const SQUAD_ACTIONS_DOOR = Object.freeze({
name: 'squad-actions',
declares: ['_setViewButtonStates', '_getFormationDPIndex'],
})
export const SQUAD_ENTITY_DOOR = Object.freeze({
name: 'squad-entity',
declares: ['getOwner', 'getCaptain'],
statics: ['TOTAL_MAX_CHEM', 'FIELD_PLAYERS'],
})
export const CLUB_PICK_DOOR = Object.freeze({
name: 'club-pick',
declares: ['initWithCriteriaAndSquad', 'initWithCriteriaAndSBCChallenge'],
methods: ['updateItemList'],
})
export const CLUB_RESULTS_VIEW_DOOR = Object.freeze({
name: 'club-results-view',
declares: ['setSubTypesOptions', 'renderAcademyItems'],
methods: ['setItemsWithChemDiff'],
})
export const LOCALIZATION_DOOR = Object.freeze({
name: 'localization-util',
statics: ['nationIdToName', 'leagueIdToName', 'teamIdToAbbr15'],
})
export function localizationUtil(win) {
const direct = win?.UTLocalizationUtil
if (direct !== null && direct !== undefined) return direct
return screenClass(win, LOCALIZATION_DOOR)
}
const installations = new WeakMap()
function wrapAfter(proto, name, listener) {
if (!proto || typeof proto[name] !== 'function') return { ok: false, dispose() {} }
let byName = installations.get(proto)
if (!byName) { byName = new Map(); installations.set(proto, byName) }
let installation = byName.get(name)
if (!installation) {
const original = proto[name]
const listeners = new Set()
const wrapped = function (...args) {
const result = original.apply(this, args)
for (const one of listeners) { try { one(this, args) } catch { /* наш вердикт не роняет экран EA */ } }
return result
}
proto[name] = wrapped
installation = { original, wrapped, listeners }
byName.set(name, installation)
}
installation.listeners.add(listener)
let active = true
return {
ok: true,
dispose() {
if (!active) return
active = false
installation.listeners.delete(listener)
if (installation.listeners.size === 0 && proto[name] === installation.wrapped) {
proto[name] = installation.original
byName.delete(name)
}
},
}
}
export function installSquadScreenCapture(win, onCapture = () => {}) {
const proto = screenPrototype(win, SQUAD_SCREEN_DOOR)
if (!proto || typeof proto._pushSquadToView !== 'function') {
return { ok: false, reason: 'unavailable', dispose() {} }
}
const say = (hook) => (self, args) => {
let view = null
let root = null
let squad = null
try { view = typeof self?.getView === 'function' ? self.getView() : null } catch { view = null }
try { root = typeof view?.getRootElement === 'function' ? view.getRootElement() : null } catch { root = null }
try { squad = self?._squad ?? (hook === 'push' ? args?.[0] ?? null : null) } catch { squad = null }
onCapture({ squad, view, root, hook })
}
const push = wrapAfter(proto, '_pushSquadToView', say('push'))
const change = wrapAfter(proto, '_eSquadDataChange', say('change'))
return {
ok: push.ok,
reason: push.ok ? null : 'unavailable',
dispose() { push.dispose(); change.dispose() },
}
}
export function installSquadActionsCapture(win, onCapture = () => {}) {
const proto = screenPrototype(win, SQUAD_ACTIONS_DOOR)
if (!proto || typeof proto._setViewButtonStates !== 'function') {
return { ok: false, reason: 'unavailable', dispose() {} }
}
const hand = wrapAfter(proto, '_setViewButtonStates', (self) => {
let root = null
let squad = null
try {
const view = typeof self?.getView === 'function' ? self.getView() : null
root = typeof view?.getRootElement === 'function' ? view.getRootElement() : null
} catch { root = null }
try { squad = self?._squad ?? null } catch { squad = null }
onCapture({ squad, root })
})
return { ok: hand.ok, reason: hand.ok ? null : 'unavailable', dispose() { hand.dispose() } }
}
const SUMMARY_SELECTOR = '.ut-squad-summary'
const SUMMARY_INFO_CLASS = 'ut-squad-summary-info'
const SUMMARY_NOT_LEFT = ['ut-squad-summary-info--right', 'ut-squad-summary-info--end']
const FORMATION_SELECTOR = 'h1.ut-squad-summary-label'
const SUMMARY_NOT_LEFT_SELECTORS = SUMMARY_NOT_LEFT.map((name) => `.${name}`)
const CHEMISTRY_SELECTOR = '.chemistry-summary'
const FOREIGN_SUMMARY = ['sbc-summary', 'totw']
export function squadBannerOf(root) {
if (!root || typeof root.querySelector !== 'function') return null
if (root.isConnected === false) return null
let bar = null
try { bar = root.querySelector(SUMMARY_SELECTOR) } catch { return null }
if (!bar) return null
try {
for (const alien of FOREIGN_SUMMARY) if (bar.classList?.contains?.(alien) === true) return null
if (bar.querySelector(FORMATION_SELECTOR) === null) return null
if (!SUMMARY_NOT_LEFT_SELECTORS.some((one) => bar.querySelector(one) !== null)) return null
if (bar.querySelector(CHEMISTRY_SELECTOR) === null) return null
} catch { return null }
return bar
}
export function bannerLeftOf(bar) {
const kids = bar?.children
if (!kids || typeof kids.length !== 'number') return null
for (let at = 0; at < kids.length; at += 1) {
const one = kids[at]
try {
if (one?.classList?.contains?.(SUMMARY_INFO_CLASS) !== true) continue
if (SUMMARY_NOT_LEFT.some((alien) => one.classList.contains(alien) === true)) continue
} catch { continue }
return one
}
return null
}
const ACTIONS_SELECTOR = '.ut-squad-actions-view'
const ACTIONS_GROUP_SELECTOR = '.ut-squad-actions-view--panel .ut-button-group'
export function actionsGroupOf(root) {
if (!root || typeof root.querySelector !== 'function') return null
if (root.isConnected === false) return null
try {
if (root.classList?.contains?.('ut-squad-actions-view') !== true
&& root.querySelector(ACTIONS_SELECTOR) === null) return null
return root.querySelector(ACTIONS_GROUP_SELECTOR)
} catch { return null }
}
export function squadFieldSlots(squad) {
let slots = null
try { slots = typeof squad?.getFieldPlayers === 'function' ? squad.getFieldPlayers() : null } catch { slots = null }
return Array.isArray(slots) ? slots : []
}
export function slotItemOf(slot) {
let item = null
try { item = typeof slot?.getItem === 'function' ? slot.getItem() : slot?.item ?? null } catch { return null }
if (item === null || item === undefined) return null
let id
try { id = item.id } catch { return null }
if (typeof id === 'number') return Number.isFinite(id) && id > 0 ? item : null
return typeof id === 'string' && id !== '' && id !== '0' ? item : null
}
export function slotItemIdOf(slot) {
const item = slotItemOf(slot)
if (item === null) return null
let id
try { id = item.id } catch { return null }
const number = Number(id)
return Number.isSafeInteger(number) && number > 0 ? number : null
}
export function slotPositionNameOf(slot) {
let name
try { name = slot?.uniquePositionName ?? slot?.generalPositionName ?? '' } catch { return null }
const text = typeof name === 'string' ? name.trim() : ''
return text === '' ? null : text
}
export function squadFieldRatings(squad) {
const out = []
for (const slot of squadFieldSlots(squad)) {
const item = slotItemOf(slot)
if (item === null) continue
let rating
try { rating = item.rating } catch { rating = undefined }
if (typeof rating === 'number' && Number.isFinite(rating) && rating > 0) out.push(rating)
}
return out
}
export function squadChemistryNow(squad) {
let value
try { value = typeof squad?.getChemistry === 'function' ? squad.getChemistry() : undefined } catch { return null }
return typeof value === 'number' && Number.isFinite(value) ? value : null
}
export function squadChemistryMax(win) {
let value
try { value = screenClass(win, SQUAD_ENTITY_DOOR)?.TOTAL_MAX_CHEM } catch { return null }
return Number.isSafeInteger(value) && value > 0 ? value : null
}
export function squadFormationName(squad) {
let name
try { name = squad?.getFormation?.()?.displayName } catch { return null }
const text = typeof name === 'string' ? name.trim() : ''
return text === '' ? null : text
}
export function itemTradeable(item) {
let value
try { value = typeof item?.isTradeable === 'function' ? item.isTradeable() : undefined } catch { return null }
return typeof value === 'boolean' ? value : null
}
const PICK_LIST_SELECTOR = '.paginated-item-list > ul'
const PICK_ROW_SELECTOR = 'li.listFUTItem'
const PICK_PINNED_SELECTOR = '.ut-pinned-item'
const PICK_CHEM_SELECTOR = '.ut-list-chemistry-tag-view'
const pickNumbers = new WeakMap()
export function installClubPickCapture(win, onCapture = () => {}) {
const controllerProto = screenPrototype(win, CLUB_PICK_DOOR)
const viewProto = screenPrototype(win, CLUB_RESULTS_VIEW_DOOR)
if (!controllerProto || typeof controllerProto.updateItemList !== 'function') {
return { ok: false, reason: 'unavailable', dispose() {} }
}
const numbers = wrapAfter(viewProto, 'setItemsWithChemDiff', (self, args) => {
pickNumbers.set(self, {
items: Array.isArray(args?.[0]) ? args[0] : [],
team: Array.isArray(args?.[1]) ? args[1] : [],
delta: Array.isArray(args?.[2]) ? args[2] : [],
card: Array.isArray(args?.[3]) ? args[3] : [],
cardDelta: Array.isArray(args?.[4]) ? args[4] : [],
})
})
const hand = wrapAfter(controllerProto, 'updateItemList', (self, args) => {
let view = null
let root = null
try { view = typeof self?.getView === 'function' ? self.getView() : null } catch { view = null }
try { root = typeof view?.getRootElement === 'function' ? view.getRootElement() : null } catch { root = null }
let said = null
if (view !== null) {
said = pickNumbers.get(view) ?? null
pickNumbers.delete(view)
}
onCapture({
controller: self, view, root,
items: Array.isArray(args?.[0]) ? args[0] : [],
numbers: said,
})
})
return {
ok: hand.ok,
reason: hand.ok ? null : 'unavailable',
dispose() { hand.dispose(); numbers.dispose() },
}
}
export function pickPanelOf(root) {
if (!root || typeof root.querySelector !== 'function') return null
if (root.isConnected === false) return null
try {
if (root.classList?.contains?.('ut-club-search-results-view') !== true) return null
if (root.querySelector(PICK_LIST_SELECTOR) === null) return null
} catch { return null }
return root
}
export function pickListOf(root) {
if (!root || typeof root.querySelector !== 'function') return null
try { return root.querySelector(PICK_LIST_SELECTOR) } catch { return null }
}
export function pickRowsOf(root) {
const list = pickListOf(root)
if (list === null) return []
let rows = null
try { rows = list.querySelectorAll(PICK_ROW_SELECTOR) } catch { return [] }
return rows === null ? [] : Array.from(rows)
}
export function pickPinnedOf(root) {
if (!root || typeof root.querySelector !== 'function') return null
try { return root.querySelector(PICK_PINNED_SELECTOR) } catch { return null }
}
export function pickChemTagOf(row) {
if (!row || typeof row.querySelector !== 'function') return null
try { return row.querySelector(PICK_CHEM_SELECTOR) } catch { return null }
}
export function pickRelayout(view) {
if (!view || typeof view.updateListTopPosition !== 'function') return false
try { view.updateListTopPosition(); return true } catch { return false }
}
export function pickShow(controller, items) {
if (!controller || typeof controller.updateItemList !== 'function') return false
if (!Array.isArray(items)) return false
try { controller.updateItemList(items); return true } catch { return false }
}
export function pickPageItems(controller) {
const model = controller?.clubViewModel
if (!model || typeof model.getPageItems !== 'function') return null
let items = null
try { items = model.getPageItems() } catch { return null }
return Array.isArray(items) ? items : null
}
export function clubSearchAll(win, criteria) {
let club = null
try { club = win?.repositories?.Item?.getClub?.() ?? null } catch { return null }
if (!club || typeof club.search !== 'function' || !criteria) return null
let found = null
try { found = club.search(criteria) } catch { return null }
return Array.isArray(found) ? found : null
}
export function clubHasAllItems(win, criteria) {
let club = null
try { club = win?.repositories?.Item?.getClub?.() ?? null } catch { return null }
if (!club || typeof club.hasAllItems !== 'function' || !criteria) return null
let answer
try { answer = club.hasAllItems(criteria) } catch { return null }
return typeof answer === 'boolean' ? answer : null
}
export function itemWords(win, item) {
const out = []
const push = (value) => {
const text = typeof value === 'string' ? value.trim() : ''
if (text !== '' && !out.includes(text)) out.push(text)
}
let data = null
try { data = typeof item?.getStaticData === 'function' ? item.getStaticData() : null } catch { data = null }
push(data?.name)
push(data?.firstName)
push(data?.lastName)
push(data?.commonName)
const loc = win?.services?.Localization ?? null
const util = localizationUtil(win)
if (loc !== null && util !== null) {
try { if (Number.isFinite(item?.teamId)) push(util.teamIdToAbbr15(item.teamId, loc)) } catch { /* слова клуба нет */ }
try { if (Number.isFinite(item?.leagueId)) push(util.leagueIdToName(item.leagueId, loc)) } catch { /* слова лиги нет */ }
try { if (Number.isFinite(item?.nationId)) push(util.nationIdToName(item.nationId, loc)) } catch { /* слова нации нет */ }
}
return out
}
export function itemRatingOf(item) {
let rating
try { rating = item?.rating } catch { return null }
return typeof rating === 'number' && Number.isFinite(rating) && rating > 0 ? rating : null
}
export function pickCriteriaOf(controller) {
let criteria = null
try { criteria = controller?.searchCriteria ?? null } catch { return null }
return criteria === null || criteria === undefined ? null : criteria
}
