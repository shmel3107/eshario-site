export function createTeamConfig(win=globalThis){const repo=win?.repositories?.TeamConfig
const get=typeof repo?.getLinkedTeam==='function'?repo.getLinkedTeam.bind(repo):null
return{
available:get!==null,
linkedTeam(teamId){if(get===null)return teamId
if(typeof teamId!=='number'||!Number.isFinite(teamId)) return teamId
try{const linked=get(teamId)
return typeof linked==='number'&&Number.isFinite(linked)?linked:teamId}catch{
return teamId}}}}
