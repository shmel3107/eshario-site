import{FILTER_FIELDS,FIELD_NAMES,FIELD_REACH,REACH,ZONES,isDefault,splitCriteria} from '../features/filters.js'
import{findDoor,findEnum} from './doors.js'
const CRITERIA_DOOR=Object.freeze({name:'search-criteria',
declares:['mapCategoryToSubType','mapSubTypeToCategory','hasValidDefId'],want:'class'})
export const FILTERS_SCREEN_DOOR=Object.freeze({name:'market-filters-screen',
declares:['initWithSearchCriteria','initWithSquadContext','eResetSelected','eSearchSelected'],want:'class'})
export const SEARCH_TYPE=Object.freeze({PLAYER:'player',STAFF:'staff',ANY:'any'})
export const SEARCH_CATEGORY=Object.freeze({MANAGER:'manager',DEFID:'definitionId',ANY:'any'})
export const SEARCH_SORT=Object.freeze({RATING:'ovr',RECENCY:'recent',VALUE:'value'})
export function eaTable(win,name,keys,fallback,numeric=false){if(noWindow(win))return fallback
let found=null
try{found=findEnum(win,keys,{name,numeric})}catch{return fallback}
return found?.ok===true&&found.value&&typeof found.value==='object'?found.value:fallback}
export const SEARCH_TYPE_KEYS=Object.freeze(['PLAYER','STAFF','ANY'])
export const SEARCH_CATEGORY_KEYS=Object.freeze(['MANAGER','DEFID','ANY'])
export const SEARCH_SORT_KEYS=Object.freeze(['RATING','RECENCY','VALUE'])
export const POSITION_KEYS=Object.freeze(['GK','ST','CB','LW'])
export const searchTypes=(win)=>eaTable(win,'search-type',SEARCH_TYPE_KEYS,SEARCH_TYPE)
export const searchCategories=(win)=>eaTable(win,'search-category',SEARCH_CATEGORY_KEYS,SEARCH_CATEGORY)
export const searchSorts=(win)=>eaTable(win,'search-sort',SEARCH_SORT_KEYS,SEARCH_SORT)
export const positionIds=(win)=>eaTable(win,'player-position',POSITION_KEYS,POSITION_ID,true)
export const POSITION_ORDER=Object.freeze(['GK','SW','RWB','RB','RCB','CB','LCB','LB','LWB','RDM','CDM','LDM','RM','RCM','CM','LCM','LM','RAM','CAM','LAM','RF','CF','LF','RW','RS','ST','LS','LW'])
export const POSITION_ID=Object.freeze(Object.fromEntries(POSITION_ORDER.map((name,index)=>[name,index])))
const ZONE_EDGES=Object.freeze({[ZONES.DEFENDERS]:['SW','LWB'],[ZONES.MIDFIELDERS]:['RDM','LAM'],
[ZONES.ATTACKERS]:['RF','LW'],[ZONES.OUTFIELD]:['SW','LW']})
export const CASCADING_FIELDS=Object.freeze(['type','category','subtypes','zone','position','authenticity'
])
export const MARKET_PARAMS=Object.freeze({authenticity:'authenticity',category:'cat',club:'team',count:'num',defId:'definitionId',icontraits:'icontraits',league:'leag',level:'lev',maskedDefId:'maskedDefId',maxBid:'macr',maxBuy:'maxb',minBid:'micr',minBuy:'minb',nation:'nat',offset:'start',playStyle:'playStyle',position:'pos',primaryColor:'primaryColor',rarities:'rarityIds',secondaryColor:'secondaryColor',type:'type',zone:'zone'})
export const ZONE_PARAMS=Object.freeze({[ZONES.DEFENDERS]:'defense',[ZONES.MIDFIELDERS]:'midfield',[ZONES.ATTACKERS]:'attacker'})
function zoneSent(value){return Object.hasOwn(ZONE_PARAMS,String(value))}
export function zoneBand(zone){const edges=Object.hasOwn(ZONE_EDGES,String(zone))?ZONE_EDGES[String(zone)]:null
if(edges===null)return null
const min=POSITION_ID[edges[0]],max=POSITION_ID[edges[1]]
if(!Number.isSafeInteger(min)||!Number.isSafeInteger(max))return null
return{min,max}}
export function criteriaClass(win){if(noWindow(win))return null
const found=findDoor(win,CRITERIA_DOOR)
if(found.ok&&typeof found.value==='function')return found.value
let live=null
try{live=win?.services?.User?.getUser?.()?.marketSearchCriteria??null}catch{return null}
if(!live||typeof live!=='object')return null
for(const name of CRITERIA_DOOR.declares){if(typeof live[name]!=='function')return null}
let Ctor=null
try{Ctor=live.constructor??null}catch{return null}
return typeof Ctor==='function'?Ctor:null}
export const APPLY_ORDER=Object.freeze([...CASCADING_FIELDS,...FIELD_NAMES.filter((name)=>!CASCADING_FIELDS.includes(name))])
export function noWindow(win){return !win||(typeof win!=='object'&&typeof win!=='function')}
function same(a,b){if(Array.isArray(a)||Array.isArray(b)){if(!Array.isArray(a)||!Array.isArray(b))return false
return a.length===b.length&&a.every((item,i)=>item===b[i])}
return a===b}
function notSentFields(values,applied){const out=[]
for(const name of applied){const reach=Object.hasOwn(FIELD_REACH,name)?FIELD_REACH[name]:null
if(reach===REACH.SERVER||reach===REACH.SERVER_VIA)continue
if(isDefault(name,values[name]))continue
if(reach===REACH.SERVER_PART&&(name!=='zone'||zoneSent(values[name])))continue
out.push(name)}
return out.sort()}
export function applyCriteria(dto,criteria){if(!dto||typeof dto!=='object') throw new Error('adapter: нет объекта критериев EA')
const values=criteria??{}
const applied=[]
const failed=[]
for(const name of APPLY_ORDER){if(!Object.hasOwn(values,name))continue
if(!Object.hasOwn(FILTER_FIELDS,name))continue
const value=values[name]
try{dto[name]=Array.isArray(value)?[...value]:value
applied.push(name)}catch(err){failed.push({field:name,error:String(err?.message??err)})}}
const rejected=[]
for(const name of applied){let actual
try{actual=dto[name]}catch(err){failed.push({field:name,error:String(err?.message??err)})
continue}
if(!same(actual,values[name])){rejected.push({field:name,wanted:values[name],actual})}}
return{applied,rejected,failed,notSent:notSentFields(values,applied)}}
export function readCriteria(dto){if(!dto||typeof dto!=='object') throw new Error('adapter: нет объекта критериев EA')
const criteria={}
const missing=[]
for(const name of FIELD_NAMES){let value
try{value=dto[name]}catch{missing.push(name)
continue}
if(value===undefined){missing.push(name);continue}
criteria[name]=Array.isArray(value)?[...value]:value}
return{criteria,missing}}
export function createCriteria(win,criteria){const Ctor=criteriaClass(win)
if(Ctor===null) throw new Error('adapter: набор критериев EA недоступен')
const dto=new Ctor()
const result=applyCriteria(dto,criteria)
return{dto,...result}}
function itemValue(item,name){try{return item?.[name]}catch{return undefined}}
export function createLotFilter(criteria,win=null){const{local}=splitCriteria(criteria)
const values=criteria??{}
const checks=[]
const unsupported=[]
const reasons={}
const count=(key)=>{reasons[key]=(reasons[key]??0)+1}
if(Object.hasOwn(local,'ovrMin')||Object.hasOwn(local,'ovrMax')){const min=Object.hasOwn(local,'ovrMin')?local.ovrMin:null
const max=Object.hasOwn(local,'ovrMax')?local.ovrMax:null
const label=[min!==null?'ovrMin':null,max!==null?'ovrMax':null].filter(Boolean).join('+')
checks.push({field:label,test(item){const rating=itemValue(item,'rating')
if(!Number.isFinite(rating)||rating<=0){count('rating-unreadable');return false}
if(min!==null&&rating<min){count('rating-low');return false}
if(max!==null&&rating>max){count('rating-high');return false}
return true}})}
if(Object.hasOwn(local,'excludeDefIds')){const banned=new Set(local.excludeDefIds)
checks.push({field:'excludeDefIds',test(item){const id=itemValue(item,'definitionId')
if(!Number.isFinite(id)||id<=0){count('defId-unreadable');return false}
if(banned.has(id)){count('defId-excluded');return false}
return true}})}
if(Object.hasOwn(local,'defId')){const wanted=new Set(local.defId)
if(wanted.size>0){checks.push({field:'defId',test(item){const id=itemValue(item,'definitionId')
const base=itemValue(item,'databaseId')
const hasId=Number.isFinite(id)&&id>0,hasBase=Number.isFinite(base)&&base>0
if(!hasId&&!hasBase){count('defId-unreadable');return false}
if((hasId&&wanted.has(id))||(hasBase&&wanted.has(base)))return true
count('defId-other');return false}})}}
if(Object.hasOwn(local,'zone')){const named=typeof values.position==='string'&&values.position!==''&&values.position!=='any'
const band=named?null:zoneBand(local.zone)
if(!named&&band===null)unsupported.push('zone')
else if(band!==null){checks.push({field:'zone',test(item){const pos=itemValue(item,'preferredPosition')
if(!Number.isSafeInteger(pos)||pos<0){count('position-unreadable');return false}
if(pos<band.min||pos>band.max){count('zone-outside');return false}
return true}})}}
if(Object.hasOwn(local,'preferredPositionOnly')&&local.preferredPositionOnly===true){const name=values.position
const table=positionIds(win)
const wanted=typeof name==='string'&&Number.isSafeInteger(table?.[name])?table[name]:null
if(wanted===null)unsupported.push('preferredPositionOnly')
else checks.push({field:'preferredPositionOnly',test(item){const preferred=itemValue(item,'preferredPosition')
if(!Number.isSafeInteger(preferred)||preferred<0){count('position-unreadable');return false}
if(preferred!==wanted){count('position-alternate');return false}
return true}})}
let seen=0,kept=0
const api={fields:checks.map((check)=>check.field),unsupported,
keep(item){seen+=1
for(const check of checks){if(!check.test(item))return false}
kept+=1
return true},
state(){return{fields:[...api.fields],unsupported:[...unsupported],seen,kept,dropped:seen-kept,reasons:{...reasons}}}}
return api}
export function createMarketCriteria(win,criteria){const{server,local,dead}=splitCriteria(criteria)
const built=createCriteria(win,server)
return{...built,localFields:Object.keys(local).sort(),dead:[...dead].sort(),filter:createLotFilter(criteria,win)}}
export function criteriaReport(criteria){const{server,local,dead}=splitCriteria(criteria)
const sent=[]
for(const name of Object.keys(server).sort()){if(isDefault(name,server[name]))continue
if(!Object.hasOwn(MARKET_PARAMS,name))continue
if(name==='zone'&&!zoneSent(server[name]))continue
sent.push(`${name}=${MARKET_PARAMS[name]}`)}
return{sent,local:Object.keys(local).sort(),dead:[...dead].sort(),
line:`рынок сузит: ${sent.length?sent.join(' '):'ничем'} | по выдаче: ${Object.keys(local).sort().join(' ')||'нечего'} | не значит ничего: ${[...dead].sort().join(' ')||'ничего'}`}}
const EA_OWN_FIELDS=new Set(['sort','sortBy'])
function serverWhole(name,value){return name==='defId'&&Array.isArray(value)&&value.length<=1}
export function readLocalMatch(win,dto,items){if(!dto||typeof dto!=='object')return null
let criteria
try{criteria=readCriteria(dto).criteria}catch{return null}
const{local,dead}=splitCriteria(criteria)
const filter=createLotFilter(criteria,win)
const unsupported=new Set(filter.unsupported)
const localNames=Object.keys(local).filter((name)=>!unsupported.has(name)&&!serverWhole(name,local[name])).sort()
const deadNames=[...dead,...filter.unsupported].filter((name)=>!EA_OWN_FIELDS.has(name)).sort()
if(localNames.length===0&&deadNames.length===0)return null
const list=Array.isArray(items)?items:[]
for(const item of list)filter.keep(item)
const state=filter.state()
return{local:localNames,dead:deadNames,seen:state.seen,kept:state.kept}}
export function createClubCriteria(win,page={}){const Ctor=criteriaClass(win)
if(Ctor===null) throw new Error('adapter: набор критериев EA недоступен')
const dto=new Ctor()
if(Number.isFinite(page.count)&&page.count>0)dto.count=page.count
if(Number.isFinite(page.offset)&&page.offset>=0)dto.offset=page.offset
return dto}
export function createSbcStorageCriteria(win,page={}){const Ctor=criteriaClass(win),type=searchTypes(win).PLAYER
if(Ctor===null)throw new Error('adapter: SBC Storage search unavailable')
const count=Number.isSafeInteger(page.count)&&page.count>0?page.count:150
const offset=Number.isSafeInteger(page.offset)&&page.offset>=0?page.offset:0
const dto=new Ctor()
Object.assign(dto,{type,count,offset})
if(dto.type!==type||dto.count!==count||dto.offset!==offset)throw new Error('adapter: SBC Storage criteria rejected by EA')
return dto}
export function createManagerCriteria(win,page={},squad=null){const Ctor=criteriaClass(win)
const types=searchTypes(win)
const type=types.STAFF,category=searchCategories(win).MANAGER
const sortBy=searchSorts(win).VALUE,any=types.ANY
if(Ctor===null){throw new Error('adapter: набор критериев EA недоступен')}
let position=any
try{position=squad?.getManager?.()?.generalPositionName||any}catch{position=any}
const dto=new Ctor()
Object.assign(dto,{type,category,sortBy,position})
if(Number.isSafeInteger(page.count)&&page.count>0)dto.count=page.count
if(Number.isSafeInteger(page.offset)&&page.offset>=0)dto.offset=page.offset
if(dto.type!==type||dto.category!==category||dto.sortBy!==sortBy||dto.position!==position){throw new Error('adapter: manager criteria отвергнуты EA')}
return dto}
export function readUserCriteria(win){let dto
try{dto=win?.services?.User?.getUser?.()?.marketSearchCriteria}catch{return null}
if(!dto||typeof dto!=='object') return null
return readCriteria(dto)}
export function createFiltersScreen(win,dto){const found=noWindow(win)?null:findDoor(win,FILTERS_SCREEN_DOOR)
const Ctor=found?.ok?found.value:null
if(typeof Ctor!=='function') throw new Error('adapter: экран фильтров недоступен')
const screen=new Ctor()
if(typeof screen.initWithSearchCriteria!=='function'){throw new Error('adapter: у экрана фильтров нет initWithSearchCriteria')}
screen.initWithSearchCriteria(dto)
return screen}
