import{screenPrototype,screenClass}from'./screen-door.js'
export const PACK_REVEAL_VIEW_DOOR=Object.freeze({name:'pack-reveal-view',
declares:['toggleDuplicateWarning','toggleReplacementWarning','generateListRow']})
export const PACK_REVEAL_DOOR=Object.freeze({name:'pack-reveal-controller',
declares:['eDuplicateCheck','eBuyWithCoins','eBuyWithPoints']})
const packOfView=new WeakMap()
const installations=new WeakMap()
export function revealPrice(pack,win,name){const currency=win?.GameCurrency?.[name]??name
if(typeof pack?.getPrice!=='function')return null
try{const value=pack.getPrice(currency)
return Number.isFinite(value)&&value>0?value:null}catch{return null}}
export function peekItemFacts(item){const def=Number(item?.definitionId??item?.defId)
const quick=Number(item?.discardValue)
return{def:Number.isSafeInteger(def)&&def>0?def:null,
tradable:typeof item?.tradable==='boolean'?item.tradable:null,
quick:Number.isFinite(quick)&&quick>=0?Math.round(quick):null}}
export function readPackReveal(view,pack,win=null){let root=null
try{root=view?.getRootElement?.()??null}catch{return null}
if(!root||typeof root.querySelector!=='function')return null
const list=view.__list??root.querySelector('ul')??null
if(!list||typeof list.appendChild!=='function')return null
const views=Array.isArray(view.listRows)?view.listRows:[]
const rows=[]
for(const one of views){let node=null
let item=null
try{node=one?.getRootElement?.()??null
item=one?.getData?.()??null}catch{return null}
if(!node||!item||typeof item!=='object')return null
rows.push({root:node,item})}
const id=Number.isSafeInteger(pack?.id)?pack.id:null
return{root,list,rows,pack:{id,
tradable:typeof pack?.tradable==='boolean'?pack.tradable:null,
coins:revealPrice(pack,win,'COINS')}}}
export function installPackRevealCapture(win,onShow=()=>{}){const viewProto=screenPrototype(win,PACK_REVEAL_VIEW_DOOR)
const ctlProto=screenPrototype(win,PACK_REVEAL_DOOR)
if(!viewProto||typeof viewProto.render!=='function')return{ok:false,reason:'unavailable',dispose(){}}
if(!ctlProto||typeof ctlProto.viewDidAppear!=='function')return{ok:false,reason:'unavailable',dispose(){}}
const view=seam(viewProto,'render',(original)=>function(...args){const result=original.apply(this,args)
const live=installations.get(viewProto)
if(live&&live.listeners.size>0){let capture=null
try{capture=readPackReveal(this,packOfView.get(this)??null,win)}catch{capture=null}
if(capture){for(const listener of live.listeners){try{listener(capture)}catch{}}}}
return result})
const ctl=seam(ctlProto,'viewDidAppear',(original)=>function(...args){try{const shown=this.getView?.()
if(shown&&this.pack)packOfView.set(shown,this.pack)}catch{}
return original.apply(this,args)})
view.listeners.add(onShow)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
view.listeners.delete(onShow)
if(view.listeners.size===0){release(view)
release(ctl)}}}}
function seam(proto,method,wrap){const found=installations.get(proto)
if(found)return found
const original=proto[method]
const wrapped=wrap(original)
proto[method]=wrapped
const record={proto,method,original,wrapped,listeners:new Set()}
installations.set(proto,record)
return record}
function release(record){if(record.proto[record.method]===record.wrapped)record.proto[record.method]=record.original
installations.delete(record.proto)}
export const ITEM_VIEW_FACTORY_DOOR=Object.freeze({name:'item-view-factory',
statics:['createLargeItem','createSmallItem']})
export function mountRevealCard(win,host,item){const Factory=screenClass(win,ITEM_VIEW_FACTORY_DOOR)
if(typeof Factory?.createLargeItem!=='function')return{ok:false,step:'no-factory'}
if(!host||typeof host.appendChild!=='function'||!item||typeof item!=='object')return{ok:false,step:'no-item'}
let view=null
try{view=Factory.createLargeItem(item)}catch{return{ok:false,step:'create'}}
if(!view)return{ok:false,step:'create'}
const drop=()=>{try{view.dealloc?.()}catch{/* вьюха уже снята */}}
try{view.init?.()}catch{drop()
return{ok:false,step:'init'}}
try{view.supportSecondaryViews=false}catch{/* поле заперто: вторичных вьюх просто не будет */}
try{view.render(item)}catch{drop()
return{ok:false,step:'render'}}
let root=null
try{root=view.getRootElement?.()??null}catch{root=null}
if(!root){drop()
return{ok:false,step:'no-root'}}
try{host.appendChild(root)}catch{drop()
return{ok:false,step:'mount'}}
return{ok:true,node:root,dispose(){try{root.remove?.()}catch{/* узел уже снят */}
drop()}}}
