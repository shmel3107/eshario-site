import{itemPiles} from './tables.js'
import{readCriteria,createCriteria,noWindow,eaTable} from './search.js'
import{pileRoom} from './action-door.js'
import{findDoor} from './doors.js'
import{appMain,liveCurrentController} from './navigation.js'
const SEARCH_MODEL_DOOR=Object.freeze({name:'bucketed-search-model',
declares:['resetSearch','getCategoryTabVisible','mapCategoryToCategoryGroup'],want:'class'})
const NAME_ENGINE_DOOR=Object.freeze({name:'player-name-engine',
declares:['getEntriesForString'],want:'class'})
const ITEM_TYPES=Object.freeze({NONE:'none',PLAYER:'player',MANAGER:'manager',MISC:'misc'})
const ITEM_TYPE_KEYS=Object.freeze(['PLAYER','MANAGER','NONE','MISC'])
const ITEM_SUBTYPES=Object.freeze({NONE:0,PLAYER:1,TEAM:2})
const ITEM_SUBTYPE_KEYS=Object.freeze(['NONE','PLAYER','TEAM'])
const SEARCH_LEVELS=Object.freeze({ANY:'any',BRONZE:'bronze',SILVER:'silver',GOLD:'gold'})
const SEARCH_LEVEL_KEYS=Object.freeze(['ANY','BRONZE','SILVER','GOLD'])
const itemTypes=(win)=>eaTable(win,'item-type',ITEM_TYPE_KEYS,ITEM_TYPES)
const itemSubtypes=(win)=>eaTable(win,'item-subtype',ITEM_SUBTYPE_KEYS,ITEM_SUBTYPES,true)
const searchLevels=(win)=>eaTable(win,'search-level',SEARCH_LEVEL_KEYS,SEARCH_LEVELS)
export const TRANSFERS_HUB_ROOT='.TransfersHub'
export const TRANSFERS_HUB_GRID='.grid.layout-hub'
export const MARKET_TILE='.ut-tile-transfer-market'
export const TRANSFER_LIST_TILE='.ut-tile-transfer-list'
export const TRANSFER_TARGETS_TILE='.ut-tile-transfer-targets'
export const TILE_CONTENT_SELECTOR='.ut-tile-content-transfers'
export const TILE_SLOTS_LABEL='.total-transfers-data > .label'
export const TILE_BIG_VALUE='.total-transfers-data > .value'
export const TILE_DISABLED='disabled'
export const SEARCH_SCREEN_ROOT='.ut-market-search-filters-view'
export const SEARCH_BUTTON_BOX='.button-container'
export const NATIVE_BUTTON_CLASS='btn-standard'
export function currentScreenController(win){try{
const app=appMain(win)
const root=app?.getRootViewController?.()
const presented=root?.getPresentedViewController?.()??null
if(presented!==null){const tab=typeof presented.getCurrentViewController==='function'?presented.getCurrentViewController():null
const nav=tab??presented
const current=typeof nav?.getCurrentController==='function'?nav.getCurrentController():null
if(current!==null&&current!==undefined)return current}}catch{/* приложение не поймано — идём второй дорогой */}
return liveCurrentController(win)}
export function readLiveMarketCriteria(win){const controller=currentScreenController(win)
let dto=null
try{dto=controller?.viewmodel?.searchCriteria??null}catch{return null}
if(!dto||typeof dto!=='object')return null
try{return readCriteria(dto)}catch{return null}}
export function liveMarketFilters(win){const controller=currentScreenController(win)
if(controller===null||controller===undefined)return null
try{const vm=controller.viewmodel
if(!vm||typeof vm!=='object')return null
if(typeof vm.updateSearchCriteria!=='function')return null
const dto=vm.searchCriteria
if(!dto||typeof dto!=='object')return null
if(vm.isMarketSearch!==true)return null
if(controller.squadContext!==null&&controller.squadContext!==undefined)return null
const view=typeof controller.getView==='function'?controller.getView():null
if(!view||typeof view.setFilters!=='function')return null
return{controller,viewmodel:vm,view}}catch{return null}}
export function showSearchMinBid(win,value){const live=liveMarketFilters(win)
if(live===null)return{ok:false,reason:'no-screen'}
const{view,viewmodel}=live
if(typeof view.setMinBidPrice!=='function')return{ok:false,reason:'no-door'}
let was=null
try{was=viewmodel.searchCriteria?.minBid??null}catch{was=null}
try{view.setMinBidPrice(value===null?0:value)}catch(err){return{ok:false,reason:`view: ${err?.message??err}`}}
return{ok:true,reason:'painted',was:typeof was==='number'&&Number.isFinite(was)?was:null}}
export function restoreSearchMinBid(win,mine){const live=liveMarketFilters(win)
if(live===null)return{ok:false,reason:'no-screen'}
const{view}=live
if(typeof view.setMinBidPrice!=='function')return{ok:false,reason:'no-door'}
try{view.setMinBidPrice(typeof mine==='number'&&Number.isFinite(mine)&&mine>0?mine:0)}
catch(err){return{ok:false,reason:`view: ${err?.message??err}`}}
return{ok:true,reason:'restored'}}
const fieldNumber=(value)=>(typeof value==='number'&&Number.isFinite(value)&&value>0?Math.trunc(value):null)
export function showSearchPair(win,pair){const live=liveMarketFilters(win)
if(live===null)return{ok:false,reason:'no-screen'}
const{view,viewmodel}=live
const said=pair!==null&&typeof pair==='object'?pair:{}
const wantBid=Object.hasOwn(said,'minBid')
const wantBuy=Object.hasOwn(said,'minBuy')
const wantTop=Object.hasOwn(said,'maxBid')
if(!wantBid&&!wantBuy&&!wantTop)return{ok:false,reason:'nothing'}
if(wantBid&&typeof view.setMinBidPrice!=='function')return{ok:false,reason:'no-door'}
if(wantBuy&&typeof view.setMinBuyNowPrice!=='function')return{ok:false,reason:'no-door'}
if(wantTop&&typeof view.setMaxBidPrice!=='function')return{ok:false,reason:'no-door'}
let was={minBid:null,minBuy:null,maxBid:null}
try{const live2=viewmodel.searchCriteria??{}
was={minBid:fieldNumber(live2.minBid),minBuy:fieldNumber(live2.minBuy),maxBid:fieldNumber(live2.maxBid)}}catch{was={minBid:null,minBuy:null,maxBid:null}}
try{if(wantBid)view.setMinBidPrice(0)
if(wantTop)view.setMaxBidPrice(fieldNumber(said.maxBid)??0)
if(wantBuy)view.setMinBuyNowPrice(fieldNumber(said.minBuy)??0)
if(wantBid)view.setMinBidPrice(fieldNumber(said.minBid)??0)}
catch(err){return{ok:false,reason:`view: ${err?.message??err}`}}
return{ok:true,reason:'painted',was,seat:viewmodel}}
export function restoreSearchPair(win,mine,seat=null){const said=mine!==null&&typeof mine==='object'?mine:{}
if(seat!==null){const live=liveMarketFilters(win)
if(live===null)return{ok:false,reason:'no-screen'}
if(live.viewmodel!==seat)return{ok:false,reason:'other-screen'}}
const back=showSearchPair(win,said)
return back.ok===true?{ok:true,reason:'restored'}:{ok:false,reason:back.reason}}
export function readMarketFilterCriteria(win){const live=liveMarketFilters(win)
if(live===null)return null
try{return readCriteria(live.viewmodel.searchCriteria)}catch{return null}}
export function readLiveMarketDefaults(win){const live=liveMarketFilters(win)
if(live===null)return null
let dto=null
try{dto=live.viewmodel.defaultSearchCriteria??null}catch{return null}
if(!dto||typeof dto!=='object')return null
try{const found=noWindow(win)?null:findDoor(win,SEARCH_MODEL_DOOR)
const Ctor=found?.ok?found.value:null
if(typeof Ctor==='function'){const spare=new Ctor()
spare.searchFeature=live.viewmodel.searchFeature
spare.defaultSearchCriteria.update(dto)
spare.resetSearch()
return readCriteria(spare.searchCriteria)}}catch{
}
try{return readCriteria(dto)}catch{return null}}
export function restoreLiveMarketCriteria(win,criteria){const live=liveMarketFilters(win)
if(live===null)return{ok:false,reason:'no-screen'}
if(!criteria||typeof criteria!=='object'||Array.isArray(criteria))return{ok:false,reason:'no-criteria'}
const{viewmodel,view}=live
const empty=readLiveMarketDefaults(win)
const values={...(empty?.criteria??{}),...criteria}
let count=null
try{count=viewmodel.searchCriteria.count}catch{count=null}
if(typeof count==='number'&&Number.isFinite(count))values.count=count
values.offset=0
let made=null
try{made=createCriteria(win,values)}catch(err){return{ok:false,reason:`no-dto: ${err?.message??err}`}}
try{viewmodel.updateSearchCriteria(made.dto)}catch(err){return{ok:false,reason:`model: ${err?.message??err}`}}
try{
if(viewmodel.getCategoryTabVisible?.()===true){const tabs=view.getTabMenuComponent?.()??null
if(tabs&&typeof tabs.setActiveTab==='function')tabs.setActiveTab(viewmodel.searchBucket)}
view.setFilters(viewmodel,false)
const player=viewmodel.playerData??null
if(player)view.setPlayerSearch(player)
else if(typeof view.resetPlayerName==='function')view.resetPlayerName()
const now=viewmodel.searchCriteria
view.setMinBidPrice(now.minBid)
view.setMaxBidPrice(now.maxBid)
view.setMinBuyNowPrice(now.minBuy)
view.setMaxBuyNowPrice(now.maxBuy)}catch(err){return{ok:false,reason:`view: ${err?.message??err}`}}
return{ok:true,reason:'',applied:made.applied,rejected:made.rejected}}
export function handOffToSearchForm(win,criteria,openScreen){
if(!criteria||typeof criteria!=='object'||Array.isArray(criteria))return{ok:false,reason:'no-criteria'}
const live=restoreLiveMarketCriteria(win,criteria)
if(live?.ok===true)return{ok:true,road:'live',rejected:fieldNames(live.rejected)}
if(live?.reason!=='no-screen')return{ok:false,reason:live?.reason??'no-screen'}
if(typeof openScreen!=='function')return{ok:false,reason:'no-navigation'}
let opened=null
try{opened=openScreen(criteria)}catch(err){return{ok:false,reason:`failed: ${err?.message??err}`}}
if(opened?.ok!==true)return{ok:false,reason:opened?.reason??'no-navigation'}
return{ok:true,road:'screen',rejected:fieldNames(opened.rejected)}}
function fieldNames(list){return(Array.isArray(list)?list:[])
.map((one)=>(typeof one==='string'?one:String(one?.field??'')))
.filter((one)=>one!=='')}
export function liveSearchButton(win){const live=liveMarketFilters(win)
if(live===null)return null
let root=null
try{root=live.view?.getRootElement?.()??null}catch{return null}
if(root===null||root===undefined)return null
try{return root.querySelector?.(`${SEARCH_BUTTON_BOX} .${NATIVE_BUTTON_CLASS}.primary`)??null}catch{return null}}
export const NAME_SUGGESTIONS=6
export function readPlayerNames(win,query,limit=NAME_SUGGESTIONS){const text=String(query??'').trim()
if(text==='')return []
const engineDoor=noWindow(win)?null:findDoor(win,NAME_ENGINE_DOOR)
const Engine=engineDoor?.ok?engineDoor.value:null
if(typeof Engine!=='function')return []
let data=null
try{data=win?.repositories?.Item?.getStaticData?.()}catch{return []}
if(!Array.isArray(data)||data.length===0)return []
let found=[]
try{const engine=new Engine(data)
found=engine.getEntriesForString(text,Number.isSafeInteger(limit)&&limit>0?limit:NAME_SUGGESTIONS)
try{engine.dealloc?.()}catch{
}}catch{return []}
if(!Array.isArray(found))return []
const out=[]
for(const entry of found){const id=Number(entry?.id)
if(!Number.isSafeInteger(id)||id<=0)continue
const name=nameOf(entry)
if(name==='')continue
const rating=Number(entry?.rating)
out.push({id,name,rating:Number.isSafeInteger(rating)&&rating>0?rating:null})}
return out}
export function nameOf(entry){const common=String(entry?.commonName??'').trim()
if(common!=='')return common
const first=String(entry?.firstName??'').trim()
const last=String(entry?.lastName??'').trim()
return `${first} ${last}`.trim()}
export function playerEntryOf(win,definitionId){const id=Number(definitionId)
if(!Number.isSafeInteger(id)||id<=0)return null
let data=null
try{data=win?.repositories?.Item?.getStaticData?.()}catch{return null}
if(!Array.isArray(data)||data.length===0)return null
for(const entry of data){if(Number(entry?.id)!==id)continue
const name=nameOf(entry)
if(name==='')return null
const rating=Number(entry?.rating)
return{id,name,rating:Number.isSafeInteger(rating)&&rating>0?rating:null}}
return null}
export function readCardTypes(win){const dp=win?.factories?.DataProvider
if(typeof dp?.getItemRarityDP!=='function')return null
const itemType=itemTypes(win).PLAYER
const subType=itemSubtypes(win).PLAYER
const anyLevel=searchLevels(win).ANY
if(itemType===undefined||subType===undefined||anyLevel===undefined)return null
let rows=null
try{rows=dp.getItemRarityDP({itemSubTypes:[subType],itemTypes:[itemType],quality:anyLevel,tradableOnly:true})}catch{return null}
if(!Array.isArray(rows))return null
const out=[]
const seen=new Set()
for(const row of rows){const id=Number(row?.id)
if(!Number.isSafeInteger(id)||id<0||seen.has(id))continue
const name=String(row?.label??'').trim()
if(name==='')continue
seen.add(id)
out.push({id,name})}
return out}
export function marketOffByTile(root){let tile=null
try{tile=root?.querySelector?.(MARKET_TILE)??null}catch{return null}
if(!tile)return null
let names=''
try{names=typeof tile.className==='string'?tile.className:String(tile.className??'')}catch{return null}
return names.split(/\s+/).includes(TILE_DISABLED)}
export function tradePileNow(win){const miss={known:false,items:[],room:null}
const pile=itemPiles(win).TRANSFER
const repo=win?.repositories?.Item
if(!repo)return miss
let dirty=null
try{dirty=repo.isDirty?.(pile)}catch{return miss}
if(typeof dirty!=='boolean'||dirty===true)return miss
let items=null
try{items=repo.getTransferItems?.()}catch{return miss}
if(!Array.isArray(items))return miss
return{known:true,items,room:pileRoom(win,'TRANSFER')}}
export function watchPileNow(win){const miss={known:false,items:[]}
const pile=itemPiles(win).INBOX
const repo=win?.repositories?.Item
if(!repo)return miss
let dirty=null
try{dirty=repo.isDirty?.(pile)}catch{return miss}
if(typeof dirty!=='boolean'||dirty===true)return miss
let said=null
try{said=repo.getWatchedItems?.()}catch{return miss}
if(said===null||said===undefined)return miss
let items=null
try{items=Array.isArray(said)?said:Array.from(said)}catch{return miss}
if(!Array.isArray(items))return miss
return{known:true,items}}
export function auctionSecondsLeft(item){let auction=null
try{auction=typeof item?.getAuctionData==='function'?item.getAuctionData():null}catch{return null}
if(auction===null||typeof auction!=='object')return null
let live=null
try{live=typeof auction.isActiveTrade==='function'?auction.isActiveTrade():null}catch{return null}
if(live!==true)return null
let left=null
try{left=typeof auction.getSecondsRemaining==='function'?auction.getSecondsRemaining():null}catch{return null}
const seconds=Number(left)
return Number.isFinite(seconds)&&seconds>0?Math.floor(seconds):null}
export function auctionWonNow(item){let auction=null
try{auction=typeof item?.getAuctionData==='function'?item.getAuctionData():null}catch{return null}
if(auction===null||typeof auction!=='object')return null
let left=null
try{left=typeof auction.getSecondsRemaining==='function'?auction.getSecondsRemaining():null}catch{return null}
const seconds=Number(left)
if(!Number.isFinite(seconds))return null
if(seconds>0)return false
let won=null
try{won=typeof auction.isWon==='function'?auction.isWon():null}catch{return null}
return typeof won==='boolean'?won:null}
export function auctionWinningNow(item){let auction=null
try{auction=typeof item?.getAuctionData==='function'?item.getAuctionData():null}catch{return null}
if(auction===null||typeof auction!=='object')return null
let top=null
try{top=typeof auction.isHighestBid==='function'?auction.isHighestBid():null}catch{return null}
if(typeof top!=='boolean')return null
if(top!==true)return false
let live=null
try{live=typeof auction.isActiveTrade==='function'?auction.isActiveTrade():null}catch{return null}
return typeof live==='boolean'?live:null}
export function auctionOutbidNow(item){let auction=null
try{auction=typeof item?.getAuctionData==='function'?item.getAuctionData():null}catch{return null}
if(auction===null||typeof auction!=='object')return null
let out=null
try{out=typeof auction.isOutbid==='function'?auction.isOutbid():null}catch{return null}
return typeof out==='boolean'?out:null}
export function marketResultsLive(win){const controller=currentScreenController(win)
if(controller===null||controller===undefined)return false
try{return typeof controller.getSelectedItem==='function'
&&typeof controller.initWithSearchCriteria==='function'}catch{return false}}
export function marketCapInput(win){const controller=currentScreenController(win)
try{const view=typeof controller?.getView==='function'?controller.getView():null
const row=view?._maxBuyNowPriceRow
const control=typeof row?.getCurrencyInput==='function'?row.getCurrencyInput():null
const node=typeof control?.getRootElement==='function'?control.getRootElement():null
return node??null}catch{return null}}
