import{readLocalMatch,readCriteria,criteriaReport,FILTERS_SCREEN_DOOR,noWindow} from './search.js'
import{findDoor} from './doors.js'
import{appMain} from './navigation.js'
const SEARCH_CHAINS=new WeakMap()
const chainOf=(item)=>{let chain=SEARCH_CHAINS.get(item)
if(chain===undefined){chain=[]
SEARCH_CHAINS.set(item,chain)}
return chain}
export function installSearchWrap(item,make){const link={inner:item.searchTransferMarket,fn:null}
link.fn=make(function inner(...args){return link.inner.apply(this,args)})
chainOf(item).push(link)
item.searchTransferMarket=link.fn
return link}
export function restoreSearch(item,link){if(!item||!link)return false
const chain=chainOf(item)
const at=chain.indexOf(link)
if(at<0)return false
chain.splice(at,1)
if(item.searchTransferMarket===link.fn){item.searchTransferMarket=link.inner
return true}
for(const other of chain){if(other.inner===link.fn){other.inner=link.inner
return true}}
return false}
const RESULTS_SCREEN_DOOR=Object.freeze({name:'market-results-screen',
declares:['setPinnedItem','refreshList','setItemListViewDelegate'],want:'class'})
const PAGINATION_DOOR=Object.freeze({name:'market-pagination',
declares:['getNumItemsPerPage','setPageItems','getCurrentPageItems','setPageIndex'],
want:'class',from:'globals'})
export function marketPageSize(win){if(noWindow(win))return null
const found=findDoor(win,PAGINATION_DOOR)
if(!found.ok||typeof found.value!=='function')return null
let read=null
try{read=found.value.prototype?.getNumItemsPerPage}catch{return null}
if(typeof read!=='function')return null
let size=null
try{size=read.call({})}catch{return null}
return Number.isSafeInteger(size)&&size>0?size:null}
export function catchNextSearch(win,deps={}){const item=win?.services?.Item
if(!item||typeof item.searchTransferMarket!=='function')return null
const onItems=typeof deps.onItems==='function'?deps.onItems:()=>{}
const onMiss=typeof deps.onMiss==='function'?deps.onMiss:()=>{}
const report=(err)=>{try{deps.onError?.(err)}catch{}}
const deadlineMs=Number.isSafeInteger(deps.deadlineMs)&&deps.deadlineMs>0?deps.deadlineMs:15_000
let link=null
let done=false
let timer=null
let watched=null
const unwrap=()=>{if(link!==null){restoreSearch(item,link)
link=null}}
const stopTimer=()=>{if(timer===null)return
try{win?.clearTimeout?.(timer)}catch{
}
timer=null}
const unwatch=()=>{if(watched===null)return
const{observable,scope}=watched
watched=null
try{observable?.unobserve?.(scope)}catch{
}}
const finish=(items,status=null,criteria=null)=>{if(done)return
done=true
unwrap()
stopTimer()
unwatch()
if(items===null)onMiss(status)
else{try{onItems(items,criteria)}catch(err){report(err)}}}
function makeWrapped(inner){return function wrapped(...args){
unwrap()
let out
try{out=inner.apply(this,args)}catch(err){finish(null)
throw err}
let asked=null
try{asked=readCriteria(args[0]).criteria}catch{asked=null}
try{const scope={}
watched={observable:out,scope}
out?.observe?.(scope,function(sender,response){watched=null
try{(sender??out).unobserve(scope)}catch{
}
if(response&&typeof response==='object'&&response.success!==true){const code=typeof response?.error?.code==='number'
?response.error.code
:(typeof response.status==='number'?response.status:null)
finish(null,code)
return}
const items=response?.data?.items
finish(Array.isArray(items)?items:[],null,asked)})}catch(err){report(err)
finish(null)}
return out}}
link=installSearchWrap(item,makeWrapped)
try{timer=win?.setTimeout?.(()=>{timer=null
finish(null)},deadlineMs)??null}catch(err){report(err)}
return{dispose(){if(done)return
done=true
unwrap()
stopTimer()
unwatch()}}}
export function tapSearchWire(win,opts={}){const item=win?.services?.Item
if(!item||typeof item.searchTransferMarket!=='function')return null
const report=(err)=>{try{opts.onError?.(err)}catch{}}
const whole=(value)=>(Number.isSafeInteger(value)&&value>0?value:null)
let calls=0,sent=null
const makeTap=(inner)=>function tap(...args){calls+=1
let read=null
try{read=readCriteria(args[0]).criteria}catch(err){report(err)}
let lots=null
try{const said=args[0]?.count
lots=Number.isSafeInteger(said)&&said>0?said:null}catch(err){report(err)}
sent=read===null
?{call:calls,lots,maxBid:null,minBid:null,maxBuy:null,minBuy:null}
:{call:calls,lots,maxBid:whole(read.maxBid),minBid:whole(read.minBid),
maxBuy:whole(read.maxBuy),minBuy:whole(read.minBuy)}
return inner.apply(this,args)}
const link=installSearchWrap(item,makeTap)
return{calls:()=>calls,
lastSent:()=>(sent===null?null:{...sent}),
dispose(){restoreSearch(item,link)}}}
export const WIDE_PAGE_LOTS=47
function pageConfig(win){let Repo=null
try{Repo=win?.EAConfigurationRepository??null}catch{return null}
if(!Repo)return null
const key=Repo.KEY_ITEMS_PER_PAGE
const market=Repo.ITEMS_PER_PAGE?.TRANSFER_MARKET
const club=Repo.ITEMS_PER_PAGE?.CLUB
if(typeof key!=='string'||typeof market!=='string'||typeof club!=='string')return null
let app=null
try{app=appMain(win)}catch{app=null}
if(app===null){try{app=typeof win?.getAppMain==='function'?win.getAppMain():null}catch{return null}}
let store=null
try{store=app?.getConfigRepository?.()??null}catch{return null}
if(!store||typeof store.getConfigObject!=='function'||typeof store.setDataObject!=='function')return null
let box=null
try{box=store.getConfigObject(key)}catch{return null}
if(!box||typeof box!=='object')return null
return{store,key,box,market,club}}
const pageDebt=new WeakMap()
export function marketPageDebt(win){return pageDebt.get(win)??null}
export function widenMarketPage(win,lots=WIDE_PAGE_LOTS,hands={}){if(noWindow(win))return null
if(!Number.isSafeInteger(lots)||lots<=0)return null
const found=pageConfig(win)
if(found===null)return null
const{store,key,box,market,club}=found
const onError=typeof hands?.onError==='function'?hands.onError:null
const debt=pageDebt.get(win)??null
const wasMarket=debt===null?box[market]:debt.market
const wasClub=debt===null?box[club]:debt.club
const write=(value)=>{const half={}
half[club]=wasClub
half[market]=value
const whole={}
whole[key]=half
try{store.setDataObject(whole)}catch{return false}
let said=null
try{said=store.getConfigObject(key)?.[market]}catch{return false}
return said===value}
if(!write(lots))return null
let back=false
return()=>{if(back)return
back=true
if(write(wasMarket)){pageDebt.delete(win)
return}
pageDebt.set(win,{market:wasMarket,club:wasClub})
if(onError!==null)onError(`страница рынка: возврат к ${String(wasMarket)} не прошёл, вернём следующим поиском`)}}
export function marketPageSetting(win){const found=pageConfig(win)
if(found===null)return null
let said=null
try{said=found.store.getConfigObject(found.key)?.[found.market]}catch{return null}
return Number.isSafeInteger(said)&&said>0?said:null}
const SEARCH_SCREENS=Object.freeze(['UTMarketSearchFiltersViewController',
'UTMarketSearchResultsViewController'])
function pageViewSender(win){let pin=null
try{pin=win?.services?.PIN??null}catch{return null}
const send=typeof pin?.sendData==='function'?pin.sendData:null
if(send===null)return null
let type=null
try{type=win?.PINEventType?.PAGE_VIEW??null}catch{return null}
if(type===undefined||type===null)return null
let evt=null
try{evt=win?.PIN_PAGEVIEW_EVT_TYPE??null}catch{return null}
if(evt===undefined||evt===null)return null
return{send,type,evt,pin}}
function screenTelemetryId(win,name){let screen=null
try{screen=win?.[name]??null}catch{return null}
let read=null
try{read=screen?.prototype?._getTelemetryId}catch{return null}
if(typeof read!=='function')return null
let said=null
try{said=read.call({})}catch{return null}
return typeof said==='string'&&said!==''?said:null}
function sendPageView(win,pgid){const door=pageViewSender(win)
if(door===null||typeof pgid!=='string'||pgid==='')return false
const payload={type:door.evt,pgid}
try{door.send.call(door.pin,door.type,payload)}catch{return false}
return true}
export function marketSearchPageViews(win){if(noWindow(win))return null
if(pageViewSender(win)===null)return null
const filtersId=screenTelemetryId(win,SEARCH_SCREENS[0])
const resultsId=screenTelemetryId(win,SEARCH_SCREENS[1])
if(filtersId===null||resultsId===null)return null
return{filters:()=>sendPageView(win,filtersId),
results:()=>sendPageView(win,resultsId)}}
const INSTALLATIONS=new WeakMap()
const equal=(a,b)=>Array.isArray(a)&&Array.isArray(b)?a.length===b.length&&a.every((x,i)=>x===b[i]):a===b
export function readMarketResultSnapshot(pagination){let items
try{items=pagination?.getCurrentPageItems?.()}catch{return null}
if(!Array.isArray(items))return null
const prices=[]
for(const item of items){try{const value=item?.getAuctionData?.()?.buyNowPrice;if(Number.isSafeInteger(value)&&value>0)prices.push(value)}catch{}}
let page=1;try{const value=pagination?.getCurrentPageIndex?.();if(Number.isSafeInteger(value)&&value>=1)page=value}catch{}
return{count:items.length,minBuy:prices.length?Math.min(...prices):null,maxBuy:prices.length?Math.max(...prices):null,page}}
export const INSTALL_ATTEMPTS=30
export const INSTALL_DELAY_MS=1000
const deadInstall=()=>({ok:false,refresh(){},relabel(){return false},state(){return null},dispose(){}})
export function installMarketSearchQuick(win,opts={}){if(INSTALLATIONS.has(win))return INSTALLATIONS.get(win)
const{mount,onError=()=>{}}=opts
if(typeof mount!=='function')return deadInstall()
const report=(err)=>{try{onError(err)}catch{}}
let live=null,timer=null,attempts=0,disposed=false
const attach=()=>{live=attachMarketSearchQuick(win,opts);return live!==null}
const schedule=()=>{if(disposed)return
attempts+=1
if(attempts>INSTALL_ATTEMPTS){report(new Error('market quick: экраны поиска рынка не появились за '+INSTALL_ATTEMPTS+' с — врезка не встала'));return}
try{timer=win?.setTimeout?.(()=>{timer=null
if(disposed)return
if(!attach())schedule()},INSTALL_DELAY_MS)??null}catch(err){report(err)}}
const facade={get ok(){return live!==null},
refresh(){live?.refresh?.()},
state(){return live?.state?.()??null},
relabel(){return live?.relabel?.()===true},
dispose(){disposed=true
if(timer!==null){try{win?.clearTimeout?.(timer)}catch{
}
timer=null}
try{live?.dispose?.()}catch(err){report(err)}
live=null
INSTALLATIONS.delete(win)}}
INSTALLATIONS.set(win,facade)
if(!attach())schedule()
return facade}
function attachMarketSearchQuick(win,{mount,mountResult=()=>null,isActive=()=>true,onError=()=>{}}={}){
if(noWindow(win))return null
const filtersDoor=findDoor(win,FILTERS_SCREEN_DOOR),resultsDoor=findDoor(win,RESULTS_SCREEN_DOOR)
const Filters=filtersDoor.ok?filtersDoor.value:null,Results=resultsDoor.ok?resultsDoor.value:null
if(typeof Filters!=='function'||typeof Results!=='function')return null
const fp=Filters.prototype,rp=Results.prototype
const original={appear:fp.viewDidAppear,leave:fp.viewWillDisappear,reset:fp.eResetSelected,search:fp.eSearchSelected,result:rp.viewDidAppear,resultLeave:rp.viewWillDisappear}
if(Object.values(original).some((fn)=>typeof fn!=='function'))return null
const views=new WeakMap(),resultViews=new WeakMap(),pages=new WeakMap();let active=null,activeResult=null
const report=(err)=>{try{onError(err)}catch{}}
const clear=(controller)=>{const api=views.get(controller);try{api?.destroy?.()}catch(err){report(err)}views.delete(controller)}
const clearResult=(controller)=>{const state=resultViews.get(controller);if(!state)return
try{controller?.onDataChange?.unobserve?.(state.token)}catch(err){report(err)}
try{state.api?.destroy?.()}catch(err){report(err)}resultViews.delete(controller)}
const sync=(controller)=>{if(!controller||controller.squadContext){clear(controller);return}
if(isActive()!==true){clear(controller);return}
if(views.has(controller))return
try{const root=controller.getView?.()?.getRootElement?.(),criteria=controller.viewmodel?.searchCriteria
if(!root||!criteria)return
const api=mount({root,criteria});if(api)views.set(controller,api)}catch(err){report(err)}}
const localMatchOf=(controller)=>{let items
try{items=controller?.paginationViewModel?.getCurrentPageItems?.()}catch{return null}
try{return readLocalMatch(win,controller?.searchCriteria,items)}catch(err){report(err);return null}}
let lastMatch=null
const renderResult=(controller)=>{const state=resultViews.get(controller),value=readMarketResultSnapshot(controller?.paginationViewModel)
const match=localMatchOf(controller)
if(match!==null||value!==null)lastMatch=match
if(state&&value)state.api?.update?.({...value,honest:match})}
const syncResult=(controller)=>{if(!controller||controller.squadContext||isActive()!==true){clearResult(controller);return}
if(resultViews.has(controller))return
try{const root=controller.getView?.()?.getRootElement?.(),observable=controller.onDataChange
if(!root||typeof observable?.observe!=='function')return
const api=mountResult({root});if(!api)return
const token={},handler=()=>Promise.resolve().then(()=>{try{renderResult(controller)}catch(err){report(err)}})
resultViews.set(controller,{api,token,handler});observable.observe(token,handler);renderResult(controller)}catch(err){clearResult(controller);report(err)}}
function appeared(...args){const value=original.appear.apply(this,args);active=this;sync(this);return value}
function left(...args){clear(this);if(active===this)active=null;return original.leave.apply(this,args)}
function reset(...args){const value=original.reset.apply(this,args);try{views.get(this)?.reset?.()}catch(err){report(err)}return value}
function search(...args){const api=views.get(this)
if(isActive()===true&&api){let parsed
try{parsed=api.read?.()}catch(err){report(err);return undefined}
if(!parsed?.ok){api.showInvalid?.(parsed?.invalid??[]);return undefined}
const criteria=this.viewmodel?.searchCriteria
if(!criteria){api.showInvalid?.(['definitionId']);return undefined}
try{for(const[key,value]of Object.entries(parsed.criteria??{})){criteria[key]=Array.isArray(value)?[...value]:value
if(!equal(criteria[key],value)){api.showInvalid?.([key==='defId'?'definitionId':key==='rarities'?'rarityId':key]);return undefined}}}catch(err){report(err);api.showInvalid?.(['definitionId']);return undefined}
if(Number.isSafeInteger(parsed.page)&&parsed.page>1)pages.set(criteria,parsed.page)}
return original.search.apply(this,args)}
function resultAppeared(...args){const page=pages.get(this.searchCriteria);pages.delete(this.searchCriteria)
if(page!==undefined){try{this.paginationViewModel?.setPageIndex?.(page)
if(this.paginationViewModel?.getCurrentPageIndex?.()!==page)throw new Error('market page rejected by EA')}catch(err){report(err)}}
activeResult=this;syncResult(this);return original.result.apply(this,args)}
function resultLeft(...args){clearResult(this);if(activeResult===this)activeResult=null;return original.resultLeave.apply(this,args)}
fp.viewDidAppear=appeared;fp.viewWillDisappear=left;fp.eResetSelected=reset;fp.eSearchSelected=search;rp.viewDidAppear=resultAppeared;rp.viewWillDisappear=resultLeft
const api={ok:true,refresh(){sync(active);syncResult(activeResult)},
state(){let criteria=null
try{const dto=activeResult?.searchCriteria
if(dto&&typeof dto==='object')criteria=criteriaReport(readCriteria(dto).criteria)}catch(err){report(err)}
return{criteria,match:lastMatch}},
relabel(){let done=false
try{done=views.get(active)?.relabel?.()===true||done}catch(err){report(err)}
try{done=resultViews.get(activeResult)?.api?.relabel?.()===true||done}catch(err){report(err)}
return done},dispose(){clear(active);clearResult(activeResult);active=null;activeResult=null
if(fp.viewDidAppear===appeared)fp.viewDidAppear=original.appear
if(fp.viewWillDisappear===left)fp.viewWillDisappear=original.leave
if(fp.eResetSelected===reset)fp.eResetSelected=original.reset
if(fp.eSearchSelected===search)fp.eSearchSelected=original.search
if(rp.viewDidAppear===resultAppeared)rp.viewDidAppear=original.result
if(rp.viewWillDisappear===resultLeft)rp.viewWillDisappear=original.resultLeave}}
return api}
