export const DATABASE_ID_MASK = 0xffffff
export function createStaticPlayers(win=globalThis){const repoNow=()=>{const repo=win?.repositories?.Item
return typeof repo?.getStaticData==='function'?repo:null}
let namesOf=null
let namedRaw=null
return{
get available(){return repoNow()!==null},
ready(){const repo=repoNow()
if(repo===null)return null
const size=storeSize(repo)
if(size!==null)return size>0
if(typeof repo.hasStaticData!=='function')return null
try{return repo.hasStaticData()===true}catch{return null}},
list(){const repo=repoNow()
if(repo===null)return[]
let raw
try{raw=repo.getStaticData()}catch{
return[]}
if(!raw||typeof raw[Symbol.iterator]!=='function')return[]
const out=[]
for(const entry of raw){const id=entry?.id
const rating=entry?.rating
if(!Number.isSafeInteger(id)||id<=0||id>DATABASE_ID_MASK)continue
if(!Number.isSafeInteger(rating)||rating<1||rating>99)continue
out.push({id,rating})}
return out},
nameOf(id){if(!Number.isSafeInteger(id)||id<=0||id>DATABASE_ID_MASK)return null
const repo=repoNow()
if(repo===null)return null
let raw
try{raw=repo.getStaticData()}catch{return null}
if(!raw||typeof raw[Symbol.iterator]!=='function')return null
if(namesOf===null||namedRaw!==raw){namedRaw=raw
namesOf=new Map
for(const entry of raw){const one=entry?.id
if(!Number.isSafeInteger(one)||one<=0||one>DATABASE_ID_MASK)continue
const name=pickName(entry)
if(name!==null)namesOf.set(one,name)}}
return namesOf.get(id)??null}}}
function storeSize(repo){let store
try{store=repo?.staticData}catch{return null}
if(store===null||typeof store!=='object')return null
let size
try{size=store.size}catch{return null}
return Number.isSafeInteger(size)&&size>=0?size:null}
function pickName(entry){for(const key of['commonName','lastName','firstName']){const value=entry?.[key]
if(typeof value!=='string')continue
const said=value.trim()
if(said!=='')return said}
return null}
