import{screenPrototype}from'./screen-door.js'
export const TRANSFER_LIST_DOOR=Object.freeze({name:'transfer-list',
declares:['_clearSold','_relistAll']})
const installations = new WeakMap()
export function installClearSoldGuard(win,hand){const proto=screenPrototype(win,TRANSFER_LIST_DOOR)
if(!proto||typeof proto._clearSold!=='function')return{ok:false,reason:'unavailable',dispose(){}}
if(typeof hand?.shouldGuard!=='function'||typeof hand?.run!=='function'){
return{ok:false,reason:'no-hand',dispose(){}}}
let installation=installations.get(proto)
if(!installation){const original=proto._clearSold
const box={hand:null}
const wrapped=function(){const owner=box.hand
if(owner===null)return original.apply(this,arguments)
let take=false
try{take=owner.shouldGuard()===true}catch{take=false}
if(!take)return original.apply(this,arguments)
const controller=this
const view=()=>{try{return typeof controller.getView==='function'?controller.getView():null}catch{return null}}
const hands={lock:()=>{try{view()?.setInteractionState?.(false)}catch{/* вид уехал */}},
unlock:()=>{try{view()?.setInteractionState?.(true)}catch{/* вид уехал */}},
refresh:()=>{try{controller.refreshList?.()}catch{/* список уехал */}}}
try{const done=owner.run(hands)
if(done&&typeof done.then==='function')done.then(()=>{},()=>{hands.unlock()
hands.refresh()})}
catch{hands.unlock()
hands.refresh()}
return undefined}
proto._clearSold=wrapped
installation={original,wrapped,box}
installations.set(proto,installation)}
installation.box.hand=hand
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
if(installation.box.hand===hand)installation.box.hand=null
if(proto._clearSold===installation.wrapped&&installation.box.hand===null){proto._clearSold=installation.original
installations.delete(proto)}}}}
export function clearSoldGuarded(win){const proto=screenPrototype(win,TRANSFER_LIST_DOOR)
const installation=proto?installations.get(proto):null
return Boolean(installation&&proto._clearSold===installation.wrapped&&installation.box.hand!==null)}
