import{pileValue} from './tables.js'
import{findDoor} from './doors.js'
import{cardLockKey,cardLockedNow} from '../features/card-locks.js'
import{objectivesEnabled,levelClaimable,findLevel,findGroup} from './hub-rewards.js'
import{serverSettingKeys} from './config.js'
export const ALLOWED='allowed'
export const FORBIDDEN='forbidden'
export const UNKNOWN='unknown'
export const DESTINATIONS=Object.freeze(['CLUB','TRANSFER','STORAGE'])
const UNCAPPED=Object.freeze(new Set(['CLUB','EVOLUTION']))
const int=(value)=>(Number.isSafeInteger(value)?value:null)
const answer=(verdict,reason,extra={})=>({verdict,reason,
need:int(extra.need)??0,locked:int(extra.locked)??0,
fits:extra.fits===null||extra.fits===undefined?null:int(extra.fits),
used:extra.used===null||extra.used===undefined?null:int(extra.used),
size:extra.size===null||extra.size===undefined?null:int(extra.size),
destination:extra.destination??null,unlimited:extra.unlimited===true,matched:int(extra.matched)??null,
amount:extra.amount===null||extra.amount===undefined?null:int(extra.amount),
coins:extra.coins===null||extra.coins===undefined?null:int(extra.coins),
floor:extra.floor===null||extra.floor===undefined?null:int(extra.floor),
unreadable:int(extra.unreadable)??0})
export function itemFact(item,method){if(!item||typeof item!=='object')return null
if(typeof item[method]!=='function')return null
try{const value=item[method]()
return typeof value==='boolean'?value:null}catch{return null}}
export function pileRoom(win,name){const pile=pileValue(win,name)
const repo=win?.repositories?.Item
if(pile===null||!repo)return null
let used=null
let size=null
try{used=repo.numItemsInCache?.(pile)
size=repo.getPileSize?.(pile)}catch{return null}
if(int(used)===null||used<0||int(size)===null||size<0||used>size)return null
return{used,size}}
export function pileCapacity(win,name,need){const want=int(need)??0
const pile=pileValue(win,name)
const repo=win?.repositories?.Item
if(pile===null||!repo)return answer(UNKNOWN,'unreadable-capacity',{need:want,destination:name})
let used=null
let size=null
let full=null
try{used=repo.numItemsInCache?.(pile)
size=repo.getPileSize?.(pile)
full=repo.isPileFull?.(pile)}catch{return answer(UNKNOWN,'unreadable-capacity',{need:want,destination:name})}
if(typeof full!=='boolean')return answer(UNKNOWN,'unreadable-capacity',{need:want,destination:name})
if(int(used)===null||used<0||int(size)===null||size<0){return answer(UNKNOWN,'unreadable-capacity',{need:want,destination:name})}
if(size===0){if(full)return answer(FORBIDDEN,'capacity',{need:want,fits:0,used,size,destination:name})
return UNCAPPED.has(name)
?answer(ALLOWED,null,{need:want,fits:null,used,size,destination:name,unlimited:true})
:answer(UNKNOWN,'unreadable-capacity',{need:want,used,size,destination:name})}
const free=Math.max(0,size-used)
return used+want<=size
?answer(ALLOWED,null,{need:want,fits:free,used,size,destination:name})
:answer(FORBIDDEN,'capacity',{need:want,fits:free,used,size,destination:name})}
export function storagePileEnabled(win){const key=serverSettingKeys(win)?.STORAGE_PILE_ENABLED
const config=win?.services?.Configuration
const check=config?.checkFeatureEnabled
if(typeof check!=='function'||key===undefined)return null
try{const value=check.call(config,key)
return typeof value==='boolean'?value:null}catch{return null}}
export function marketEnabled(win){const market=win?.services?.TransferMarket
const check=market?.isFeatureEnabledForUser
if(typeof check!=='function')return null
try{const value=check.call(market)
return typeof value==='boolean'?value:null}catch{return null}}
const num=(value)=>(typeof value==='number'&&Number.isFinite(value)?value:null)
function numberFact(host,method){if(!host||typeof host[method]!=='function')return null
try{return num(host[method]())}catch{return null}}
export function pileFull(win,name){const pile=pileValue(win,name)
const repo=win?.repositories?.Item
if(pile===null||typeof repo?.isPileFull!=='function')return null
try{const value=repo.isPileFull(pile)
return typeof value==='boolean'?value:null}catch{return null}}
export function coinsOf(win){const service=win?.services?.User
if(!service||typeof service.getUser!=='function')return null
try{const user=service.getUser()
if(!user||typeof user.getCurrency!=='function')return null
const value=int(user.getCurrency(win?.GameCurrency?.COINS??'COINS')?.amount)
return value===null||value<0?null:value}catch{return null}}
function newItemsRoom(win){return pileRoom(win,'PURCHASED')}
const PRICE_GRID_DOOR=Object.freeze({name:'price-grid',
statics:['PRICE_TIERS','getIncrementAboveVal','getIncrementBelowVal'],want:'class',
from:'globals'})
function bidLimits(win){const found=findDoor(win,PRICE_GRID_DOOR)
if(!found.ok||typeof found.value!=='function')return null
const Grid=found.value
let min=null
try{const tiers=Grid.PRICE_TIERS
if(!Array.isArray(tiers))return null
for(const tier of tiers){const step=int(tier?.min)
if(step===null||step<=0)continue
if(min===null||step<min)min=step}}catch{return null}
if(min===null)return null
let max=null
try{max=int(Grid.getIncrementAboveVal(Number.MAX_SAFE_INTEGER))}catch{return null}
return max===null||max<min?null:{min,max}}
export function isRelistableAuction(auction){if(!auction||typeof auction!=='object')return null
const expired=itemFact(auction,'isExpired')
if(expired===true)return true
const valid=itemFact(auction,'isValid')
const inactive=itemFact(auction,'isInactive')
if(expired===null||valid===null||inactive===null)return null
return valid===true&&inactive===true}
export function soldFact(auction){if(!auction||typeof auction!=='object')return null
if(typeof auction.isSold==='function'){try{const value=auction.isSold()
return typeof value==='boolean'?value:null}catch{return null}}
const state=auction.tradeState??auction._tradeState
if(typeof auction.tradeOwner!=='boolean'||typeof state!=='string')return null
return auction.tradeOwner===true&&state==='closed'}
export function isSoldAuction(auction){return soldFact(auction)===true}
function auctionOf(item){if(!item||typeof item!=='object')return null
if(typeof item.getAuctionData!=='function')return null
try{const data=item.getAuctionData()
return data&&typeof data==='object'?data:null}catch{return null}}
export function canMoveTo(item,destination){if(destination==='CLUB')return itemFact(item,'isMovable')
if(destination==='STORAGE'){const storable=itemFact(item,'isStorable')
const untradeable=itemFact(item,'isUnTradeableDuplicate')
if(storable===null||untradeable===null)return null
return storable===true&&untradeable===true}
if(destination==='TRANSFER'){const movable=itemFact(item,'isMovable')
const duplicate=itemFact(item,'isTradeableDuplicate')
if(movable===true||duplicate===true)return true
if(movable===null||duplicate===null)return null
return false}
return null}
const worst=(a,b)=>{if(a.verdict===FORBIDDEN||b.verdict===FORBIDDEN)return a.verdict===FORBIDDEN?a:b
if(a.verdict===UNKNOWN||b.verdict===UNKNOWN)return a.verdict===UNKNOWN?a:b
return a}
function reviewItems(items,destination,need){let unreadable=0
for(const item of items){const can=canMoveTo(item,destination)
if(can===false)return answer(FORBIDDEN,'predicate',{need,destination})
if(can===null)unreadable+=1}
return unreadable>0
?answer(UNKNOWN,'unreadable-predicate',{need,destination})
:answer(ALLOWED,null,{need,destination})}
function reviewMove(request){const items=Array.isArray(request.items)?request.items:[]
const destination=request.destination
if(!DESTINATIONS.includes(destination))return answer(UNKNOWN,'unknown-destination',{destination:destination??null})
const need=items.length
const blind=int(request.unreadable)??0
if(need===0)return blind>0
?answer(UNKNOWN,'unreadable-items',{need:0,destination,unreadable:blind})
:answer(FORBIDDEN,'empty',{need:0,destination})
if(destination==='STORAGE'){const feature=storagePileEnabled(request.win)
if(feature===false)return answer(FORBIDDEN,'feature-off',{need,destination})
if(feature===null)return answer(UNKNOWN,'unreadable-feature',{need,destination})}
const predicate=reviewItems(items,destination,need)
if(predicate.verdict===FORBIDDEN)return predicate
const room=worst(predicate,pileCapacity(request.win,destination,need))
if(blind===0||room.verdict===FORBIDDEN)return room
return answer(UNKNOWN,'unreadable-items',{need,destination,unreadable:blind,
fits:room.fits,used:room.used,size:room.size})}
function itemLocked(item){let key=null
try{key=cardLockKey(item)}catch{return true}
if(key===null)return null
try{return cardLockedNow(key)}catch{return true}}
function reviewDiscard(request){const items=Array.isArray(request.items)?request.items:[]
const need=items.length
if(need===0)return answer(FORBIDDEN,'empty',{need:0})
let unreadable=0
let locked=0
let unreadableLocks=0
for(const item of items){const discardable=itemFact(item,'isDiscardable')
const loan=itemFact(item,'isDuplicateLoanPlayer')
if(discardable===false||loan===true)return answer(FORBIDDEN,'predicate',{need})
if(discardable===null||loan===null)unreadable+=1
const shut=itemLocked(item)
if(shut===true)locked+=1
else if(shut===null)unreadableLocks+=1}
if(locked>0)return answer(UNKNOWN,'locked-card',{need,locked})
if(unreadableLocks>0)return answer(UNKNOWN,'unreadable-locks',{need})
return unreadable>0?answer(UNKNOWN,'unreadable-predicate',{need}):answer(ALLOWED,null,{need})}
export function redeemableEntity(item,win){if(!item||typeof item!=='object')return null
const kinds=win?.ItemSubType??null
let subtype=null
try{subtype=Number.isSafeInteger(item.subtype)?item.subtype:null}catch{subtype=null}
if(Number.isSafeInteger(kinds?.PLAYER_PICK_ITEM)&&subtype===kinds.PLAYER_PICK_ITEM)return false
let unreadable=false
for(const method of REDEEM_METHODS){const said=itemFact(item,method)
if(said===true)return true
if(said===null)unreadable=true}
if(kinds&&subtype!==null){for(const name of REDEEM_SUBTYPES){if(kinds[name]===subtype)return true}}
return unreadable?null:false}
const REDEEM_METHODS=Object.freeze(['isFreePack','isDraftToken','isCoinBoost'])
const REDEEM_SUBTYPES=Object.freeze(['FREE_COINS','FREE_XP','FREE_PACK','DRAFT_TOKEN','COIN_BOOST'])
function reviewRedeem(request){const items=Array.isArray(request.items)?request.items:[]
const need=items.length
if(need===0)return answer(FORBIDDEN,'empty',{need:0})
let unreadable=0
let locked=0
let unreadableLocks=0
for(const item of items){const gift=redeemableEntity(item,request.win)
if(gift===false)return answer(FORBIDDEN,'predicate',{need})
if(gift===null)unreadable+=1
const shut=itemLocked(item)
if(shut===true)locked+=1
else if(shut===null)unreadableLocks+=1}
if(locked>0)return answer(UNKNOWN,'locked-card',{need,locked})
if(unreadableLocks>0)return answer(UNKNOWN,'unreadable-locks',{need})
return unreadable>0?answer(UNKNOWN,'unreadable-predicate',{need}):answer(ALLOWED,null,{need})}
function reviewList(request){const items=Array.isArray(request.items)?request.items:[]
if(typeof request.fresh!=='boolean')return answer(UNKNOWN,'unreadable-origin',{need:1,destination:'TRANSFER'})
const market=marketEnabled(request.win)
if(market===false)return answer(FORBIDDEN,'market-off',{need:1,destination:'TRANSFER'})
if(market===null)return answer(UNKNOWN,'unreadable-market',{need:1,destination:'TRANSFER'})
if(items.length!==1)return answer(UNKNOWN,'unreadable-item',{need:1,destination:'TRANSFER'})
const tradeable=itemFact(items[0],'isTradeable')
if(tradeable===false)return answer(FORBIDDEN,'predicate',{need:1,destination:'TRANSFER'})
if(tradeable===null)return answer(UNKNOWN,'unreadable-predicate',{need:1,destination:'TRANSFER'})
const own=auctionOf(items[0])
if(own!==null){const selling=itemFact(own,'isSelling')
if(selling===true)return answer(FORBIDDEN,'already-selling',{need:1,destination:'TRANSFER'})
if(selling===null)return answer(UNKNOWN,'unreadable-predicate',{need:1,destination:'TRANSFER'})}
if(request.fresh!==true)return answer(ALLOWED,null,{need:1,destination:'TRANSFER'})
const rows=Array.isArray(request.rows)?request.rows:null
if(rows===null)return pileCapacity(request.win,'TRANSFER',1)
let selling=0
let unreadable=0
for(const row of rows){const auction=auctionOf(row)
const active=auction===null?null:itemFact(auction,'isSelling')
if(active===null)unreadable+=1
else if(active===true)selling+=1}
const room=pileRoom(request.win,'TRANSFER')
if(room===null)return answer(UNKNOWN,'unreadable-capacity',{need:1,destination:'TRANSFER'})
if(unreadable>0)return answer(UNKNOWN,'unreadable-rows',{need:1,destination:'TRANSFER',used:selling,size:room.size})
const free=Math.max(0,room.size-selling)
return selling<room.size
?answer(ALLOWED,null,{need:1,fits:free,used:selling,size:room.size,destination:'TRANSFER'})
:answer(FORBIDDEN,'capacity',{need:1,fits:0,used:selling,size:room.size,destination:'TRANSFER'})}
function reviewRows(request,match){const rows=Array.isArray(request.rows)?request.rows:null
if(rows===null)return answer(UNKNOWN,'unreadable-rows',{need:0})
let matched=0
let unreadable=0
for(const row of rows){const auction=auctionOf(row)??(row&&typeof row==='object'?row:null)
const hit=auction===null?null:match(auction)
if(hit===null)unreadable+=1
else if(hit===true)matched+=1}
if(unreadable>0)return answer(UNKNOWN,'unreadable-rows',{need:matched,matched,unreadable})
return matched>0
?answer(ALLOWED,null,{need:matched,matched})
:answer(FORBIDDEN,'empty',{need:0,matched:0})}
function auctionForBid(lot){const own=auctionOf(lot)
if(own!==null)return own
return lot&&typeof lot==='object'&&typeof lot.getSecondsRemaining==='function'?lot:null}
function creditedCost(auction,amount){const highest=itemFact(auction,'isHighestBid')
if(highest===null)return null
if(highest!==true)return amount
const current=num(auction.currentBid)
return current===null?null:Math.max(0,amount-current)}
function reviewBuy(request){const need=1
const market=marketEnabled(request.win)
if(market===false)return answer(FORBIDDEN,'market-off',{need})
if(market===null)return answer(UNKNOWN,'unreadable-market',{need})
const auction=auctionForBid(request.lot)
if(auction===null)return answer(UNKNOWN,'unreadable-lot',{need})
const left=numberFact(auction,'getSecondsRemaining')
if(left===null)return answer(UNKNOWN,'unreadable-lot',{need})
if(left<=0)return answer(FORBIDDEN,'dead-lot',{need})
const amount=int(request.amount)
const price=num(auction.buyNowPrice)
if(amount===null||price===null)return answer(UNKNOWN,'unreadable-price',{need,amount})
if(price<=0)return answer(FORBIDDEN,'no-buy-now',{need,amount})
if(amount!==price)return answer(FORBIDDEN,'price-mismatch',{need,amount})
const room=newItemsRoom(request.win)
if(room===null)return answer(UNKNOWN,'unreadable-capacity',{need,amount,destination:'PURCHASED'})
if(room.used>=room.size){return answer(FORBIDDEN,'new-items-full',
{need,amount,fits:0,used:room.used,size:room.size,destination:'PURCHASED'})}
const owed=creditedCost(auction,amount)
if(owed===null)return answer(UNKNOWN,'unreadable-lot',{need,amount})
const coins=coinsOf(request.win)
if(coins===null)return answer(UNKNOWN,'unreadable-coins',{need,amount:owed})
if(coins<owed)return answer(FORBIDDEN,'not-enough-coins',{need,amount:owed,coins})
return answer(ALLOWED,null,{need,amount:owed,coins,
fits:Math.max(0,room.size-room.used),used:room.used,size:room.size,destination:'PURCHASED'})}
function reviewBid(request){const need=1
const amount=int(request.amount)
if(amount===null)return answer(UNKNOWN,'unreadable-price',{need,amount})
const market=marketEnabled(request.win)
if(market===false)return answer(FORBIDDEN,'market-off',{need,amount})
if(market===null)return answer(UNKNOWN,'unreadable-market',{need,amount})
const auction=auctionForBid(request.lot)
if(auction===null)return answer(UNKNOWN,'unreadable-lot',{need,amount})
const left=numberFact(auction,'getSecondsRemaining')
if(left===null)return answer(UNKNOWN,'unreadable-lot',{need,amount})
if(left<=0)return answer(FORBIDDEN,'dead-lot',{need,amount})
const full=pileFull(request.win,'INBOX')
if(full===null)return answer(UNKNOWN,'unreadable-capacity',{need,amount,destination:'INBOX'})
if(full===true){const room=pileRoom(request.win,'INBOX')
const watched=typeof auction.watched==='boolean'?auction.watched:null
const seen={need,amount,used:room===null?null:room.used,size:room===null?null:room.size,destination:'INBOX'}
if(watched===null)return answer(UNKNOWN,'unreadable-lot',seen)
if(watched===false)return answer(FORBIDDEN,'watch-list-full',{...seen,fits:0})}
const limits=bidLimits(request.win)
if(limits===null)return answer(UNKNOWN,'unreadable-limits',{need,amount})
if(amount<limits.min||amount>limits.max)return answer(FORBIDDEN,'bid-out-of-grid',{need,amount})
const current=num(auction.currentBid)
const starting=num(auction.startingBid)
const buyNow=num(auction.buyNowPrice)
if(current===null||starting===null||buyNow===null)return answer(UNKNOWN,'unreadable-price',{need,amount})
if(amount<starting||amount<=current)return answer(FORBIDDEN,'bid-too-low',{need,amount})
if(buyNow>0&&amount>=buyNow)return answer(FORBIDDEN,'bid-at-buy-now',{need,amount})
const highest=itemFact(auction,'isHighestBid')
if(highest===null)return answer(UNKNOWN,'unreadable-lot',{need,amount})
if(highest===true)return answer(FORBIDDEN,'already-highest',{need,amount})
const coins=coinsOf(request.win)
if(coins===null)return answer(UNKNOWN,'unreadable-coins',{need,amount})
if(coins<amount)return answer(FORBIDDEN,'not-enough-coins',{need,amount,coins})
return answer(ALLOWED,null,{need,amount,coins})}
function reviewBidGrid(request){const limits=bidLimits(request.win)
return limits===null
?answer(UNKNOWN,'unreadable-limits')
:answer(ALLOWED,null,{floor:limits.min})}
function reviewClaim(request){const need=1
const enabled=objectivesEnabled(request.win)
if(enabled===false)return answer(FORBIDDEN,'objectives-off',{need})
if(enabled===null)return answer(UNKNOWN,'unreadable-objectives',{need})
const levelId=int(request.levelId)
if(levelId===null)return answer(UNKNOWN,'unreadable-reward',{need})
const found=findLevel(request.win,levelId,request.pass===true)
if(found===null)return answer(FORBIDDEN,'reward-gone',{need})
const ready=levelClaimable(request.win,found.campaign,found.level)
if(ready===null)return answer(UNKNOWN,'unreadable-reward',{need})
if(ready!==true)return answer(FORBIDDEN,'reward-gone',{need})
const choice=request.win?.FCRewardGrantType?.CHOICE
if(choice!==undefined&&found.level.rewardSetFlow===choice)return answer(FORBIDDEN,'reward-choice',{need})
return answer(ALLOWED,null,{need})}
function reviewClaimGroup(request){const need=1
const enabled=objectivesEnabled(request.win)
if(enabled===false)return answer(FORBIDDEN,'objectives-off',{need})
if(enabled===null)return answer(UNKNOWN,'unreadable-objectives',{need})
const id=request.groupId
if(id===undefined||id===null)return answer(UNKNOWN,'unreadable-reward',{need})
return findGroup(request.win,id)===null
?answer(FORBIDDEN,'reward-gone',{need})
:answer(ALLOWED,null,{need})}
export const LOT_REFUSALS=Object.freeze(['dead-lot','no-buy-now','price-mismatch',
'bid-too-low','bid-at-buy-now','already-highest'])
export function isLotRefusal(review){return review?.verdict===FORBIDDEN&&LOT_REFUSALS.includes(review?.reason)}
export function reviewAction(request={}){const action=request?.action
if(action==='move')return reviewMove(request)
if(action==='discard')return reviewDiscard(request)
if(action==='redeem')return reviewRedeem(request)
if(action==='list')return reviewList(request)
if(action==='relist'){
const market=marketEnabled(request.win)
if(market===false)return answer(FORBIDDEN,'market-off',{need:0,matched:0})
if(market===null)return answer(UNKNOWN,'unreadable-market',{need:0,matched:0})
return reviewRows(request,isRelistableAuction)}
if(action==='clear')return reviewRows(request,soldFact)
if(action==='market'){const market=marketEnabled(request.win)
if(market===true)return answer(ALLOWED,null,{need:0})
if(market===false)return answer(FORBIDDEN,'market-off',{need:0})
return answer(UNKNOWN,'unreadable-market',{need:0})}
if(action==='buy')return reviewBuy(request)
if(action==='bid')return reviewBid(request)
if(action==='bid-grid')return reviewBidGrid(request)
if(action==='claim')return reviewClaim(request)
if(action==='claim-group')return reviewClaimGroup(request)
return answer(UNKNOWN,'unknown-action')}
export class DoorRefusedError extends Error{constructor(review){super(`door: ${review?.verdict??UNKNOWN} (${review?.reason??'?'})`)
this.name='DoorRefusedError'
this.door=review??null}}
export function isDoorRefusal(err){return err instanceof DoorRefusedError}
function fingerprint(ids){if(!Array.isArray(ids))return 'none'
if(ids.length===0)return 'empty'
return `${ids.length}.${ids.map((id)=>String(id)).sort().join(',')}`}
export function doorConsentKey(parts){const action=parts?.action??'?'
const reason=parts?.reason??'?'
const destination=parts?.destination??'-'
const blind=int(parts?.unreadable)??0
return `${action}:${reason}:${destination}:${fingerprint(parts?.ids)}+${blind}`}
export function createDoorConsent(deps={}){const now=typeof deps.now==='function'?deps.now:()=>Date.now()
const windowMs=Number.isFinite(deps.windowMs)&&deps.windowMs>0?deps.windowMs:8000
let given=null
return{
ask(key){const at=now()
if(given!==null&&given.key===key&&at-given.at<=windowMs){given=null
return true}
given={key,at:Number.isFinite(at)?at:0}
return false},
forget(){given=null},
state:()=>(given===null?null:{key:given.key,at:given.at})}}
