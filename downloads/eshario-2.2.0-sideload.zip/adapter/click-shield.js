export function appBusy(win){const shield=win?.gClickShield
if(!shield||typeof shield.isShowing!=='function')return null
try{return shield.isShowing()===true}catch{return null}}
const SHIELD_NODE='.ut-click-shield.showing'
export function shieldUp(win,doc){const said=appBusy(win)
if(said!==null)return said
const page=doc??win?.document??null
if(!page)return null
try{return page.querySelector?.(SHIELD_NODE)!=null}catch{return null}}
export function shieldKind(win,doc){const counter=win?.gClickShield?.shieldCounter
if(counter&&typeof counter==='object'){const full=Number(counter.FULL)
const loading=Number(counter.LOADING)
const interaction=Number(counter.INTERACTION)
if(Number.isFinite(full)&&Number.isFinite(loading)&&Number.isFinite(interaction)){if(full>0||loading>0)return 'request'
return interaction>0?'redraw':'none'}}
const page=doc??win?.document??null
if(!page)return null
let root=null
try{root=page.querySelector?.('.ut-click-shield')??null}catch{return null}
if(!root)return null
let up=false
let quiet=false
try{up=root.classList?.contains?.('showing')===true
quiet=root.classList?.contains?.('interaction')===true}catch{return null}
if(!up)return 'none'
return quiet?'redraw':'request'}
