import{pileName} from './tables.js'
import{findEnum} from './doors.js'
import{appMain} from './navigation.js'
export const ITEM_EVENTS=Object.freeze({
unassigned:'UNASSIGNED_ITEM_ADDED',
move:'ITEM_MOVE',
list:'ITEM_LIST',
discard:'ITEM_DISCARD',
undoDiscard:'ITEM_UNDO_DISCARD',
clearSold:'ITEM_CLEARSOLD',
bid:'ITEM_BID'})
const EVENT_DOOR_KEYS=Object.freeze(['ITEM_MOVE','ITEM_LIST','ITEM_DISCARD'])
function eventNames(win){const found=findEnum(win,EVENT_DOOR_KEYS,{name:'item-events'})
return found.ok?found.value:null}
const idsOf=(data)=>{const list=Array.isArray(data?.itemIds)?data.itemIds:[]
const out=[]
for(const id of list){if(id===null||id===undefined)continue
const text=String(id)
if(text!=='')out.push(text)}
return out}
const itemsOf=(data)=>(Array.isArray(data?.items)?data.items.filter((item)=>item&&typeof item==='object'):[])
export function pileNameOf(win,value){return pileName(win,value)}
export function installItemEvents(win,onEvent=()=>{}){let dispatcher=null
try{dispatcher=typeof win?.getDefaultDispatcher==='function'?win.getDefaultDispatcher():null}catch{dispatcher=null}
if(dispatcher===null){try{dispatcher=appMain(win)?.getDefaultDispatcher?.()??null}catch{dispatcher=null}}
if(!dispatcher||typeof dispatcher.addObserver!=='function'||typeof dispatcher.removeObserver!=='function'){return{ok:false,reason:'no-dispatcher',missing:Object.values(ITEM_EVENTS),dispose(){}}}
const names=eventNames(win)
const missing=[]
const attached=[]
for(const member of Object.values(ITEM_EVENTS)){const key=names?.[member]
if(typeof key!=='string'||key===''){missing.push(member)
continue}
const target={}
const handler=(sender,event,data)=>{try{onEvent({name:member,ids:idsOf(data),items:itemsOf(data),
from:pileNameOf(win,data?.sourcePile),to:pileNameOf(win,data?.destinationPile)})}catch{
}}
try{dispatcher.addObserver(key,target,handler)
attached.push({key,target})}catch{missing.push(member)}}
if(attached.length===0)return{ok:false,reason:'no-events',missing,dispose(){}}
let active=true
return{ok:missing.length===0,reason:missing.length===0?null:'partial',missing,
dispose(){if(!active)return
active=false
for(const{key,target}of attached){try{dispatcher.removeObserver(key,target)}catch{}}}}}
