import{screenPrototype}from'./screen-door.js'
export const PICKS_VIEW_DOOR=Object.freeze({name:'player-picks-view',
declares:['setOwnershipDescription','renderSelectedPicks'],
methods:['setCarouselItems']})
export const PICKS_CONTROLLER_DOOR=Object.freeze({name:'player-picks-controller',
declares:['isPendingSelectionContext','setPendingSelectionContext'],
methods:['initWithPicks','onButtonTapped']})
const pickInstallations=new WeakMap()
const controlInstallations=new WeakMap()
const controllersByPicks=new WeakMap()
export function readPickVariants(view,picks){const wanted=Array.isArray(picks)?picks:[]
const holder=view?._carouselItemsContainer??null
const views=Array.isArray(holder?.carouselItems)?holder.carouselItems:[]
const box=holder?.__carouselItemsContainer??null
if(!box||typeof box.querySelector!=='function')return null
if(views.length===0||views.length!==wanted.length)return null
const variants=[]
for(let index=0;index<views.length;index+=1){const one=views[index]
let root=null
try{root=one?.getRootElement?.()??null}catch{return null}
if(!root||typeof root.querySelector!=='function')return null
if(String(root.getAttribute?.('data-index')??'')!==String(index))return null
const item=one?.item??null
if(!item||typeof item!=='object'||item!==wanted[index])return null
const card=root.querySelector('.item')
if(!card)return null
variants.push({index,root,card,item})}
const screen=typeof box.closest==='function'?box.closest('.ut-player-picks-view'):null
return{box,screen,variants}}
export function pickItemFacts(item){const read=(fn)=>{try{return fn()}catch{return null}}
return{definitionId:read(()=>{const value=item?.definitionId
return Number.isSafeInteger(value)&&value>0?value:null}),
rating:read(()=>{const value=item?.rating
return typeof value==='number'&&Number.isFinite(value)?value:null}),
tradable:read(()=>(typeof item?.tradable==='boolean'?item.tradable:null)),
player:read(()=>(typeof item?.isPlayer==='function'?item.isPlayer()===true:null))}}
export function installPlayerPicksCapture(win,onCapture=()=>{}){const proto=screenPrototype(win,PICKS_VIEW_DOOR)
if(!proto||typeof proto.setCarouselItems!=='function')return{ok:false,reason:'unavailable',dispose(){}}
let installation=pickInstallations.get(proto)
if(!installation){const original=proto.setCarouselItems
const listeners=new Set()
const wrapped=function(picks){const result=original.call(this,picks)
let capture=null
try{capture=readPickVariants(this,picks)}catch{capture=null}
if(capture){// Родной путь выбора едет вместе с вариантами и той же сверкой.
try{capture.controls=readPickControls(this,picks)}catch{capture.controls=null}
for(const listener of listeners){try{listener(capture)}catch{}}}
return result}
proto.setCarouselItems=wrapped
installation={original,wrapped,listeners}
pickInstallations.set(proto,installation)}
installation.listeners.add(onCapture)
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.listeners.delete(onCapture)
if(installation.listeners.size===0&&proto.setCarouselItems===installation.wrapped){proto.setCarouselItems=installation.original
pickInstallations.delete(proto)}}}}
export function installPlayerPickControls(win){const proto=screenPrototype(win,PICKS_CONTROLLER_DOOR)
if(!proto||typeof proto.initWithPicks!=='function')return{ok:false,reason:'unavailable',dispose(){}}
try{const states=win?.PlayerPicksState
picksStates=states&&typeof states==='object'?states:null}catch{picksStates=null}
let installation=controlInstallations.get(proto)
if(!installation){const original=proto.initWithPicks
const wrapped=function(picks,available){const result=original.call(this,picks,available)
try{if(Array.isArray(picks)&&picks.length>0)controllersByPicks.set(picks,this)}catch{}
return result}
proto.initWithPicks=wrapped
installation={original,wrapped,users:0}
installation.taps=installTapWatch(proto)
controlInstallations.set(proto,installation)}
installation.users+=1
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
installation.users-=1
if(installation.users<=0&&proto.initWithPicks===installation.wrapped){proto.initWithPicks=installation.original
installation.taps?.dispose?.()
controlInstallations.delete(proto)}}}}
function installTapWatch(proto){if(typeof proto?.onButtonTapped!=='function')return{ok:false,dispose(){}}
const original=proto.onButtonTapped
const wrapped=function(sender,event,params){const result=original.call(this,sender,event,params)
try{if(isContinueEvent(event)){const listeners=continueListeners.get(this)
if(listeners)for(const listener of[...listeners]){try{listener()}catch{}}}}catch{}
return result}
proto.onButtonTapped=wrapped
return{ok:true,dispose(){if(proto.onButtonTapped===wrapped)proto.onButtonTapped=original}}}
const CONTINUE_EVENT='UTPlayerPicksView.Event.CONTINUE'
function isContinueEvent(event){if(typeof event!=='string'||event==='')return false
return event===CONTINUE_EVENT}
const continueListeners=new WeakMap()
let picksStates=null
export function readPickControls(view,picks){const wanted=Array.isArray(picks)&&picks.length>0?picks:null
if(!wanted)return null
let controller=null
try{controller=controllersByPicks.get(wanted)??null}catch{return null}
if(!controller)return null
let ownView=null
try{ownView=controller.getView?.()??null}catch{return null}
if(ownView!==view||controller.picks!==wanted)return null
for(const name of['markSelectedByItem','deselectByItem','isItemSelected','isAtMaxPicks']){if(typeof controller[name]!=='function')return null}
const size=wanted.length
const raw=controller.availablePicks
const available=Number.isSafeInteger(raw)&&raw>0&&raw<=size?raw:null
const ask=(fn)=>{try{return fn()}catch{return null}}
const isSelected=(index)=>ask(()=>controller.isItemSelected(wanted[index])===true)
const move=(index,want)=>{if(!Number.isSafeInteger(index)||index<0||index>=size)return{ok:false,reason:'no-variant'}
const now=isSelected(index)
if(now===null)return{ok:false,reason:'ea-error'}
if(now===want)return{ok:false,reason:want?'already':'not-selected'}
if(want){const full=ask(()=>controller.isAtMaxPicks()===true)
if(full===null)return{ok:false,reason:'ea-error'}
if(full)return{ok:false,reason:'full'}}
let thrown=false
try{if(want)controller.markSelectedByItem(wanted[index])
else controller.deselectByItem(wanted[index])}catch{thrown=true}
if(thrown)return{ok:false,reason:'ea-error'}
return isSelected(index)===want?{ok:true,reason:null}:{ok:false,reason:'refused'}}
const current=()=>{const value=controller.carouselCurrentIndex
return Number.isSafeInteger(value)&&value>=0&&value<size?value:null}
const makeCurrent=(index)=>{if(!Number.isSafeInteger(index)||index<0||index>=size)return{ok:false,reason:'no-variant'}
if(typeof controller.onCarouselScrolled!=='function')return{ok:false,reason:'unavailable'}
if(!Array.isArray(controller.ownership)||controller.ownership.length<size)return{ok:false,reason:'unavailable'}
if(current()===index)return{ok:false,reason:'already'}
let event=null
try{event=view?.constructor?.Event?.CAROUSEL_SCROLLED??null}catch{event=null}
let thrown=false
try{controller.onCarouselScrolled(view,event,{index})}catch{thrown=true}
if(thrown)return{ok:false,reason:'ea-error'}
return current()===index?{ok:true,reason:null}:{ok:false,reason:'refused'}}
const owned=(index)=>{if(!Number.isSafeInteger(index)||index<0||index>=size)return null
const list=controller.ownership
if(!Array.isArray(list)||list.length<size)return null
return list[index]===true}
const whenContinued=(listener)=>{if(typeof listener!=='function')return()=>{}
let set=continueListeners.get(controller)
if(!set){set=new Set()
continueListeners.set(controller,set)}
set.add(listener)
return()=>{set.delete(listener)}}
const confirm=()=>{if(typeof controller.eConfirmSelection!=='function')return{ok:false,reason:'unavailable'}
if(!isConfirmState())return{ok:false,reason:'not-confirming'}
const chosen=controller.selectedPicks
if(!Array.isArray(chosen)||chosen.length===0)return{ok:false,reason:'empty'}
let event=null
try{event=view?.constructor?.Event?.CONFIRM_PICK??null}catch{event=null}
let thrown=false
try{controller.eConfirmSelection(view,event,undefined)}catch{thrown=true}
return thrown?{ok:false,reason:'ea-error'}:{ok:true,reason:null}}
const isConfirmState=()=>inState('CONFIRM')
const isChoiceState=()=>inState('CHOICE')
function inState(name){const states=picksStates
if(!states)return false
const state=controller.modalState
if(state===undefined||state===null)return false
if(Object.hasOwn(states,name)&&state===states[name])return true
return states[state]===name}
const continueNow=()=>{if(typeof controller.onButtonTapped!=='function')return{ok:false,reason:'unavailable'}
if(!isChoiceState())return{ok:false,reason:'not-choosing'}
const full=ask(()=>controller.isAtMaxPicks()===true)
if(full!==true)return{ok:false,reason:'not-full'}
const chosen=controller.selectedPicks
if(!Array.isArray(chosen)||chosen.length===0)return{ok:false,reason:'empty'}
let thrown=false
try{controller.onButtonTapped(view,CONTINUE_EVENT,undefined)}catch{thrown=true}
if(thrown)return{ok:false,reason:'ea-error'}
return isConfirmState()?{ok:true,reason:null}:{ok:false,reason:'refused'}}
return{available,size,
count:()=>{const list=controller.selectedPicks
return Array.isArray(list)?list.length:0},
current,
makeCurrent,
owned,
whenContinued,
confirming:isConfirmState,
continueNow,
confirm,
atMax:()=>ask(()=>controller.isAtMaxPicks()===true)===true,
isSelected:(index)=>isSelected(index)===true,
select:(index)=>move(index,true),
deselect:(index)=>move(index,false)}}
