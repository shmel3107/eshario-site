import{refusesSuperclass} from './sbc-screen.js'
import{requestData} from './observable.js'
import{findDoor} from './doors.js'
import{appMain,liveNavigation} from './navigation.js'
const installations=new WeakMap()
const HUB_VIEW=Object.freeze({name:'sbc-hub-view',
declares:['populateTiles','eTilePreviewSelected','populateNavigation'],want:'class'})
const SET_FACTORY=Object.freeze({name:'sbc-set-factory',
declares:['createSet','createChallenge','createSetChallenges'],want:'class'})
export const HOOK_CREATE_SET='createSet'
export const HOOK_POPULATE='populateTiles'
export const HUB_CONTAINER_SELECTOR='.container'
export const HUB_TILES_SELECTOR='.layout-hub'
export const TILE_ROOT_SELECTOR='.ut-sbc-set-tile-view'
const SQUAD_FIELD_PLAYERS=11
export function installSbcHubCapture(win,onTiles=()=>{}){const proto=doorProto(win,HUB_VIEW)
if(typeof proto?.[HOOK_POPULATE]!=='function'){return{ok:false,reason:'unavailable',missing:[HUB_VIEW.name],refused:[],dispose(){}}}
if(refusesSuperclass(proto[HOOK_POPULATE])){return{ok:false,reason:'refused',missing:[],refused:[HOOK_POPULATE],dispose(){}}}
let installation=installations.get(proto)
if(!installation){const listeners=new Set()
const original=proto[HOOK_POPULATE]
const wrapped=function(sets,category){const result=original.apply(this,arguments)
notify(this,listeners,category)
return result}
proto[HOOK_POPULATE]=wrapped
installation={original,wrapped,listeners}
installations.set(proto,installation)}
installation.listeners.add(onTiles)
let active=true
return{ok:true,reason:null,missing:[],refused:[],dispose(){if(!active)return
active=false
installation.listeners.delete(onTiles)
if(installation.listeners.size>0)return
if(proto[HOOK_POPULATE]===installation.wrapped)proto[HOOK_POPULATE]=installation.original
installations.delete(proto)}}}
function notify(view,listeners,category){let root=null
try{root=typeof view?.getRootElement==='function'?view.getRootElement():null}catch{root=null}
if(!root)return
const tiles=[]
let list=null
try{list=view?.sbcSetTiles}catch{list=null}
for(const tile of Array.isArray(list)?list:[]){let tileRoot=null
let set=null
try{tileRoot=typeof tile?.getRootElement==='function'?tile.getRootElement():null}catch{tileRoot=null}
try{set=typeof tile?.getData==='function'?tile.getData():null}catch{set=null}
if(!tileRoot||!set)continue
tiles.push({root:tileRoot,set})}
let box=null
try{box=root.querySelector?.(HUB_TILES_SELECTOR)??null}catch{box=null}
for(const listener of listeners){try{listener({view,root,box,tiles,category:category??null})}catch{}}}
const submittedMemory=new Map()
const factoryInstalls=new WeakMap()
export function installSetDtoCapture(win){const proto=doorProto(win,SET_FACTORY)
if(typeof proto?.[HOOK_CREATE_SET]!=='function')return{ok:false,reason:'unavailable',dispose(){}}
if(refusesSuperclass(proto[HOOK_CREATE_SET]))return{ok:false,reason:'refused',dispose(){}}
let installation=factoryInstalls.get(proto)
if(!installation){const original=proto[HOOK_CREATE_SET]
const wrapped=function(dto){rememberSubmitted(dto)
return original.apply(this,arguments)}
proto[HOOK_CREATE_SET]=wrapped
installation={original,wrapped}
factoryInstalls.set(proto,installation)}
let active=true
return{ok:true,reason:null,dispose(){if(!active)return
active=false
if(proto[HOOK_CREATE_SET]===installation.wrapped)proto[HOOK_CREATE_SET]=installation.original
factoryInstalls.delete(proto)}}}
function rememberSubmitted(dto){try{const id=Number(dto?.setId)
if(!Number.isSafeInteger(id)||id<=0)return
submittedMemory.set(id,{allTime:times(dto?.timesCompleted),inWindow:times(dto?.timesCompletedInInterval)})}catch{/* чужое построение не роняем ничем */}}
function times(value){if(value===null||value===undefined||value==='')return null
const number=Number(value)
return Number.isSafeInteger(number)&&number>=0?number:null}
export function submittedOf(setId){const id=Number(setId)
if(!Number.isSafeInteger(id))return null
return submittedMemory.get(id)??null}
export function submittedMemorySize(){return submittedMemory.size}
export function forgetSubmitted(){submittedMemory.clear()}
export function categoryFactsOf(category){const read=(fn,fallback=null)=>{try{const value=fn()
return value===undefined?fallback:value}catch{return fallback}}
const raw=read(()=>category?.id)
const id=Number.isFinite(Number(raw))&&raw!==null&&raw!==''?Number(raw):null
return{key:id===null?null:`c${id}`,name:String(read(()=>category?.name,'')??'')}}
export function setFactsOf(set){const read=(fn,fallback=null)=>{try{const value=fn()
return value===undefined?fallback:value}catch{return fallback}}
const num=(value)=>(Number.isFinite(Number(value))?Number(value):null)
const text=(value)=>(typeof value==='string'?value:'')
return{id:num(read(()=>set?.id)),name:text(read(()=>set?.name,'')),description:text(read(()=>set?.description,'')),done:num(read(()=>set?.challengesCompletedCount)),total:num(read(()=>set?.challengesCount)),complete:read(()=>set?.isComplete?.()===true),repeatable:read(()=>set?.isRepeatable===true),repeatsRemaining:num(read(()=>set?.getRepeatsRemaining?.())),
windowed:read(()=>set?.isLimitedRepeatable===true)===true,
repeats:num(read(()=>set?.repeats)),
timesInWindow:num(read(()=>set?.timesCompleted)),notExpirable:read(()=>set?.notExpirable===true),
endsIn:read(()=>set?.notExpirable===true)===true?null:num(read(()=>set?.getTimeRemaining?.())),refreshIn:num(read(()=>set?.getRefreshTimeRemaining?.())),
startedAt:num(read(()=>set?.startTime)),favourite:read(()=>set?.isFavourite===true)===true,featured:read(()=>set?.isFeatured===true)===true,awards:awardsOf(set)}}
function awardsOf(set){let list=null
try{list=set?.awards}catch{list=null}
const out=[]
for(const award of Array.isArray(list)?list:[]){try{out.push({isPack:award?.isPack===true,isCoin:award?.isCoin===true,isXP:award?.isXP===true,isEventToken:award?.isEventToken===true,
tradable:award?.tradable===true,
sale:rewardSaleOf(award),count:Number.isFinite(Number(award?.count))?Number(award.count):null,value:Number.isFinite(Number(award?.value))?Number(award.value):null,item:award?.item??null})}catch{/* одна награда не роняет остальные */}}
return out}
export function rewardSaleOf(award){if(!award||typeof award!=='object')return null
try{
if(award.isCoin===true)return 'coins'
if(award.isEventToken===true||award.isXP===true)return null
if(award.isChampionQualificationPoints===true||award.isChampionStageEntry===true)return null}catch{return null}
const mark=rewardMarkOf(award)
if(mark===null)return null
return mark===true?'no':'yes'}
export function rewardMarkOf(award){if(!award||typeof award!=='object')return null
try{
if(award.isCoin===true||award.isXP===true||award.isEventToken===true)return false
if(award.isChampionQualificationPoints===true||award.isChampionStageEntry===true)return false
if(typeof award.tradable!=='boolean')return null
return award.tradable===false}catch{return null}}
export function challengeFactsOf(set){let list=null
try{list=set?.getChallenges?.()}catch{list=null}
if(!Array.isArray(list)||list.length===0)return null
const out=[]
for(const challenge of list){try{if(challenge?.isCompleted?.()===true)continue
if(challenge?.isBrickChallenge?.()===true)continue
const requirements=challenge?.eligibilityRequirements
out.push({id:Number.isFinite(Number(challenge?.id))?Number(challenge.id):null,requirements:Array.isArray(requirements)?requirements:[],formation:typeof challenge?.formation==='string'&&challenge.formation!==''?challenge.formation:null,squadSize:squadSizeOf(challenge)})}catch{/* одно испытание не роняет список */}}
return out}
function squadSizeOf(challenge){try{const squad=challenge?.squad
if(squad===null||squad===undefined)return null
if(typeof squad.getNumOfRequiredPlayers!=='function')return null
const size=Number(squad.getNumOfRequiredPlayers())
return Number.isSafeInteger(size)&&size>0&&size<=SQUAD_FIELD_PLAYERS?size:null}catch{return null}}
const challengeMemory=new Map()
export function challengesWithMemory(set,facts={}){const key=facts?.id===null||facts?.id===undefined?null:String(facts.id)
const stamp=[facts?.done??null,facts?.total??null,facts?.timesInWindow??null]
const fresh=challengeFactsOf(set)
if(fresh!==null){const list=key===null?fresh:carrySquadSizes(fresh,challengeMemory.get(key)?.challenges)
if(key!==null)challengeMemory.set(key,{stamp,challenges:list})
return{challenges:list,from:'live'}}
if(key===null)return{challenges:null,from:'none'}
const kept=challengeMemory.get(key)
if(kept===undefined)return{challenges:null,from:'none'}
if(stamp.some((value,index)=>value!==kept.stamp[index])){challengeMemory.delete(key)
return{challenges:null,from:'none'}}
return{challenges:kept.challenges,from:'memory'}}
function carrySquadSizes(fresh,kept){if(!Array.isArray(kept)||kept.length===0)return fresh
const known=new Map()
for(const one of kept){const size=one?.squadSize
if(one?.id===null||one?.id===undefined)continue
if(!Number.isSafeInteger(size)||size<=0)continue
known.set(one.id,size)}
if(known.size===0)return fresh
return fresh.map((one)=>{if(one?.squadSize!==null&&one?.squadSize!==undefined)return one
if(one?.id===null||one?.id===undefined)return one
const size=known.get(one.id)
return size===undefined?one:{...one,squadSize:size}})}
export function challengeMemorySize(){return challengeMemory.size}
export function forgetChallenges(){challengeMemory.clear()}
export function openSetChallenge(win,set){const refusal=refuseOpen(win)
if(refusal!==null)return{ok:false,reason:refusal,run:null}
if(!set)return{ok:false,reason:'no-set',run:null}
const sbc=win.services.SBC
const Screen=squadScreenOf(win)
const run=(async()=>{const data=await requestData(sbc.requestChallengesForSet(set),'испытания набора')
const challenge=firstOpenChallenge(data?.challenges ?? (Array.isArray(data)?data:null))
if(challenge===null)return{ok:false,reason:'no-challenge'}
await requestData(sbc.loadChallenge(challenge),'загрузка испытания')
const nav=navigationOf(win)
if(nav===null)return{ok:false,reason:'no-navigation'}
const screen=new Screen()
screen.initWithSBCSet(set,challenge.id)
nav.pushViewController(screen)
return{ok:true,reason:null,challengeId:challenge.id??null}})()
return{ok:true,reason:null,run}}
function refuseOpen(win){const sbc=win?.services?.SBC
if(!sbc||typeof sbc.requestChallengesForSet!=='function'||typeof sbc.loadChallenge!=='function')return'no-service'
if(squadScreenOf(win)===null)return'no-screen'
if(navigationOf(win)===null)return'no-navigation'
return null}
export function canOpenSetChallenge(win){return refuseOpen(win)===null}
function firstOpenChallenge(list){for(const challenge of Array.isArray(list)?list:[]){try{if(challenge?.isCompleted?.()===true)continue
if(challenge?.isBrickChallenge?.()===true)continue
if(challenge?.hasExpired?.()===true)continue
return challenge}catch{/* одно испытание не роняет поиск */}}
return null}
const HOOK_INIT_WITH_SET='initWithSBCSet'
const SBC_SQUAD_PHONE_DOOR=Object.freeze({name:'sbc-squad-phone-screen',
declares:[HOOK_INIT_WITH_SET,'_ePopupSubmitSelected','_ePopupClosed'],want:'class'})
const SBC_SQUAD_SPLIT_DOOR=Object.freeze({name:'sbc-squad-split-screen',
declares:[HOOK_INIT_WITH_SET,'_eRequirementsNotificationTap','_eRequirementsTap'],want:'class'})
const PHONE_PORTRAIT_QUERY='(max-device-width: 599px) and (orientation: portrait)'
const PHONE_LANDSCAPE_QUERY='(min-aspect-ratio: 32/19) and (max-device-width: 1023px) and (orientation: landscape)'
function isPhoneLayout(win){try{const types=win?.enums?.UIDeviceTypes
const body=win?.document?.getElementsByTagName?.('body')?.[0]
const list=body?.classList
if(types&&list){const phone=list.contains(types.PHONE)===true
const landscape=list.contains(types.LANDSCAPE)===true
if(phone||landscape)return phone}
const ask=win?.matchMedia
if(typeof ask!=='function')return false
return ask.call(win,PHONE_PORTRAIT_QUERY).matches===true||ask.call(win,PHONE_LANDSCAPE_QUERY).matches===true}catch{return false}}
function doorProto(win,door){if(!win||(typeof win!=='object'&&typeof win!=='function'))return null
const found=findDoor(win,door)
return found.ok&&typeof found.value==='function'?found.value.prototype??null:null}
function squadScreenOf(win){if(!win||(typeof win!=='object'&&typeof win!=='function'))return null
const door=isPhoneLayout(win)?SBC_SQUAD_PHONE_DOOR:SBC_SQUAD_SPLIT_DOOR
const found=findDoor(win,door)
const Screen=found.ok?found.value:null
return typeof Screen==='function'&&typeof Screen.prototype?.[HOOK_INIT_WITH_SET]==='function'?Screen:null}
function navigationOf(win){try{const current=appMain(win)?.getRootViewController?.()?.getPresentedViewController?.()?.getCurrentViewController?.()
if(typeof current?.pushViewController==='function')return current}catch{/* приложение не поймано — идём второй дорогой */}
return liveNavigation(win)}
export function tileHostOf(tileRoot){if(!tileRoot||typeof tileRoot.appendChild!=='function')return null
return tileRoot}
export const TILE_REWARD_SELECTOR='.tile-reward-list-view'
export const TILE_EXPIRY_SELECTOR='.sbc-status-container .expiry'
export function tilePartOf(tileRoot,selector){try{return tileRoot?.querySelector?.(selector)??null}catch{return null}}
export function toolbarSlotOf(hubRoot){if(!hubRoot||typeof hubRoot.querySelector!=='function')return null
const container=hubRoot.querySelector(HUB_CONTAINER_SELECTOR)
if(!container)return null
const tiles=container.querySelector(HUB_TILES_SELECTOR)
return{parent:container,before:tiles??container.firstChild??null}}
