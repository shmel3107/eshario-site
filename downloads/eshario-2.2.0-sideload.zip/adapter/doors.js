const ROOT_SIGNATURE=Object.freeze(['conforms','dealloc','init','isSubClass'])
const ROOT_HOOK_METHOD='init'
const memory=new WeakMap()
function roomOf(win){if(win===null||(typeof win!=='object'&&typeof win!=='function'))return null
let room=memory.get(win)
if(room===undefined){room={found:new Map(),missed:new Map(),waiting:new Map(),unhook:null}
memory.set(win,room)}
return room}
function ownMethods(proto){if(!proto||(typeof proto!=='object'&&typeof proto!=='function'))return[]
const out=[]
let names=[]
try{names=Object.getOwnPropertyNames(proto)}catch{return[]}
for(const key of names){if(key==='constructor')continue
let d=null
try{d=Object.getOwnPropertyDescriptor(proto,key)}catch{continue}
if(d&&typeof d.value==='function')out.push(key)}
return out}
function hasMethods(proto,methods){if(methods.length===0)return true
const seen=new Set()
let p=proto
let guard=0
while(p&&guard++<16){for(const name of ownMethods(p))seen.add(name)
try{p=Object.getPrototypeOf(p)}catch{break}}
for(const name of methods){if(!seen.has(name))return false}
return true}
function declaresMethods(proto,declares){if(declares.length===0)return true
const own=new Set(ownMethods(proto))
for(const name of declares){if(!own.has(name))return false}
return true}
function declaresAccessors(proto,accessors){if(accessors.length===0)return true
if(!proto)return false
let names=[]
try{names=Object.getOwnPropertyNames(proto)}catch{return false}
const own=new Set()
for(const key of names){let d=null
try{d=Object.getOwnPropertyDescriptor(proto,key)}catch{continue}
if(d&&(typeof d.get==='function'||typeof d.set==='function'))own.add(key)}
for(const name of accessors){if(!own.has(name))return false}
return true}
function hasFields(instance,fields){if(fields.length===0)return true
if(!instance||typeof instance!=='object')return false
for(const name of fields){let ok=false
try{ok=Object.hasOwn(instance,name)||name in instance}catch{ok=false}
if(!ok)return false}
return true}
function hasStatics(ctor,statics){if(statics.length===0)return true
if(typeof ctor!=='function')return false
for(const name of statics){let ok=false
try{ok=Object.hasOwn(ctor,name)}catch{ok=false}
if(!ok)return false}
return true}
function normalize(signature){const name=typeof signature?.name==='string'?signature.name:null
const declares=Array.isArray(signature?.declares)?signature.declares.filter((s)=>typeof s==='string'):[]
const methods=Array.isArray(signature?.methods)?signature.methods.filter((s)=>typeof s==='string'):[]
const accessors=Array.isArray(signature?.accessors)?signature.accessors.filter((s)=>typeof s==='string'):[]
const fields=Array.isArray(signature?.fields)?signature.fields.filter((s)=>typeof s==='string'):[]
const statics=Array.isArray(signature?.statics)?signature.statics.filter((s)=>typeof s==='string'):[]
const want=signature?.want==='instance'?'instance':'class'
const instanceVia=(()=>{const said=signature?.instanceVia
if(typeof said==='string'&&said!=='')return[said]
if(!Array.isArray(said))return[]
return said.filter((one)=>typeof one==='string'&&one!=='')})()
const from=signature?.from==='registry'||signature?.from==='globals'?signature.from:'any'
const ok=name!==null&&(declares.length+methods.length+accessors.length+fields.length+statics.length)>0
return{ok,name,declares,methods,accessors,fields,statics,want,from,instanceVia}}
function instanceFits(instance,sig){if(!instance||typeof instance!=='object')return false
let proto=null
try{proto=Object.getPrototypeOf(instance)}catch{return false}
if(!proto)return false
if(!declaresMethods(proto,sig.declares))return false
if(!declaresAccessors(proto,sig.accessors))return false
if(!hasMethods(proto,sig.methods))return false
if(!hasFields(instance,sig.fields))return false
if(sig.statics.length>0&&!hasStatics(instance.constructor,sig.statics))return false
return true}
function classFits(ctor,sig){if(typeof ctor!=='function'||!ctor.prototype)return false
if(!declaresMethods(ctor.prototype,sig.declares))return false
if(!declaresAccessors(ctor.prototype,sig.accessors))return false
if(!hasMethods(ctor.prototype,sig.methods))return false
if(!hasStatics(ctor,sig.statics))return false
if(sig.fields.length>0)return false
return true}
const REGISTRIES=Object.freeze(['services','repositories','accessobjects'])
function searchRegistries(win,sig){const hits=[]
for(const registryName of REGISTRIES){let registry=null
try{registry=win?.[registryName]??null}catch{registry=null}
if(!registry||typeof registry!=='object')continue
let keys=[]
try{keys=Object.keys(registry)}catch{keys=[]}
for(const key of keys){let value=null
try{value=registry[key]}catch{continue}
if(instanceFits(value,sig))hits.push(value)}}
return hits}
function searchGlobals(win,sig){const hits=new Set()
let names=[]
try{names=Object.getOwnPropertyNames(win)}catch{return[]}
for(const name of names){let value=null
try{value=win[name]}catch{continue}
if(typeof value!=='function'||!value.prototype)continue
if(classFits(value,sig))hits.add(value)
let proto=null
try{proto=Object.getPrototypeOf(value.prototype)}catch{proto=null}
let guard=0
while(proto&&guard++<16){let ctor=null
try{ctor=proto.constructor}catch{ctor=null}
if(typeof ctor==='function'&&ctor.prototype===proto&&classFits(ctor,sig))hits.add(ctor)
try{proto=Object.getPrototypeOf(proto)}catch{break}}}
return[...hits]}
export const MISS_COOLDOWN_MS=1000
export const MISS_COOLDOWN_CAP_MS=30_000
function miss(why,ms,matches=0){return{ok:false,value:null,source:null,ms,why,matches}}
function remember(room,name,why,ms,matches){const before=room.missed.get(name)
const wait=before===undefined?MISS_COOLDOWN_MS:Math.min(before.wait*2,MISS_COOLDOWN_CAP_MS)
room.missed.set(name,{why,matches,at:now(),wait})
return miss(why,ms,matches)}
export function findDoor(win,signature){const started=now()
const sig=normalize(signature)
if(!sig.ok)return miss('bad-signature',0)
const room=roomOf(win)
if(room===null)return miss('no-window',0)
const cached=room.found.get(sig.name)
if(cached!==undefined)return{ok:true,value:cached.value,source:'cache',ms:cached.ms,why:null,matches:cached.matches}
const missed=room.missed.get(sig.name)
if(missed!==undefined&&(now()-missed.at)<missed.wait){
return{ok:false,value:null,source:null,ms:0,why:missed.why,matches:missed.matches}}
let hits=[]
let source=null
if(sig.from!=='globals'){hits=searchRegistries(win,sig)
if(hits.length>0)source='registry'}
const globalsWorthIt=sig.want!=='instance'
if(sig.from!=='registry'&&hits.length===0&&globalsWorthIt){hits=searchGlobals(win,sig)
if(hits.length>0)source='globals'}
const unique=uniqueBy(hits,sig.want)
if(unique.length===0)return remember(room,sig.name,'not-found',now()-started,0)
if(unique.length>1)return remember(room,sig.name,'ambiguous',now()-started,unique.length)
const value=unique[0]
const ms=now()-started
room.missed.delete(sig.name)
room.found.set(sig.name,{value,ms,matches:1,source})
return{ok:true,value,source,ms,why:null,matches:1}}
function uniqueBy(hits,want){const byClass=new Map()
for(const hit of hits){let ctor=null
if(typeof hit==='function')ctor=hit
else{try{ctor=hit?.constructor??null}catch{ctor=null}}
const key=ctor??hit
if(!byClass.has(key))byClass.set(key,hit)}
const out=[]
for(const[ctor,hit]of byClass){if(want==='instance'){out.push(typeof hit==='function'?null:hit)}
else out.push(typeof hit==='function'?hit:ctor)}
return out.filter((v)=>v!==null&&v!==undefined)}
export function findEnum(win,keys,opts={}){const started=now()
const wanted=Array.isArray(keys)?keys.filter((k)=>typeof k==='string'):[]
if(wanted.length<3)return{ok:false,value:null,ms:0,why:'bad-signature',matches:0}
const name=typeof opts.name==='string'?opts.name:null
const room=roomOf(win)
if(room===null)return{ok:false,value:null,ms:0,why:'no-window',matches:0}
if(name!==null){const cached=room.found.get(`__enum-${name}`)
if(cached!==undefined)return{ok:true,value:cached.value,ms:cached.ms,why:null,matches:1}
const missedEnum=room.missed.get(`__enum-${name}`)
if(missedEnum!==undefined&&(now()-missedEnum.at)<missedEnum.wait){
return{ok:false,value:null,ms:0,why:missedEnum.why,matches:missedEnum.matches}}}
const numeric=opts.numeric===true
const hits=[]
const seen=new Set()
const fits=(bag)=>{let bagKeys=[]
try{bagKeys=Object.keys(bag)}catch{return false}
for(const key of wanted){if(!bagKeys.includes(key))return false
if(numeric&&typeof bag[key]!=='number')return false}
return true}
const scan=(bag,depth)=>{if(!bag||typeof bag!=='object'||seen.has(bag)||depth>2)return
seen.add(bag)
if(fits(bag))hits.push(bag)
let bagKeys=[]
try{bagKeys=Object.keys(bag)}catch{return}
for(const key of bagKeys){let value=null
try{value=bag[key]}catch{continue}
if(value&&typeof value==='object')scan(value,depth+1)}}
let names=[]
try{names=Object.getOwnPropertyNames(win)}catch{names=[]}
for(const globalName of names){let value=null
try{value=win[globalName]}catch{continue}
if(value&&typeof value==='object'){scan(value,0)
continue}
if(typeof value!=='function')continue
let statics=[]
try{statics=Object.getOwnPropertyNames(value)}catch{continue}
for(const key of statics){if(key==='prototype'||key==='length'||key==='name')continue
let bag=null
try{bag=value[key]}catch{continue}
if(bag&&typeof bag==='object')scan(bag,1)}}
const unique=[...new Set(hits)]
const ms=now()-started
const missEnum=(why,matches)=>{if(name!==null){const before=room.missed.get(`__enum-${name}`)
const wait=before===undefined?MISS_COOLDOWN_MS:Math.min(before.wait*2,MISS_COOLDOWN_CAP_MS)
room.missed.set(`__enum-${name}`,{why,matches,at:now(),wait})}
return{ok:false,value:null,ms,why,matches}}
if(unique.length===0)return missEnum('not-found',0)
if(unique.length>1)return missEnum('ambiguous',unique.length)
if(name!==null){room.missed.delete(`__enum-${name}`)
room.found.set(`__enum-${name}`,{value:unique[0],ms,matches:1,source:'globals'})}
return{ok:true,value:unique[0],ms,why:null,matches:1}}
export function watchDoor(win,signature,onFound=null){const sig=normalize(signature)
if(!sig.ok)return{ok:false,why:'bad-signature',dispose(){}}
const room=roomOf(win)
if(room===null)return{ok:false,why:'no-window',dispose(){}}
const cached=room.found.get(sig.name)
if(cached!==undefined){if(onFound!==null){try{onFound({value:cached.value,instance:cached.instance??null,ms:cached.ms})}catch{}}
return{ok:true,why:null,dispose(){}}}
let list=room.waiting.get(sig.name)
if(list===undefined){
const probe=sig.declares[0]??sig.methods[0]??null
list={sig,probe,started:now(),listeners:new Set(),hooks:null,viaClass:null}
room.waiting.set(sig.name,list)}
if(onFound!==null)list.listeners.add(onFound)
const viaHooked=sig.instanceVia.length===0?false:ensureMethodHook(win,room,sig,list)
const rootHooked=ensureRootHook(win,room)
const hooked=viaHooked||rootHooked
if(!hooked){closeWaiting(room,sig.name)
return{ok:false,why:'no-root-class',dispose(){}}}
let active=true
return{ok:true,why:null,dispose(){if(!active)return
active=false
const current=room.waiting.get(sig.name)
if(current===undefined)return
if(onFound!==null)current.listeners.delete(onFound)
if(current.listeners.size===0)closeWaiting(room,sig.name)}}}
function unhookMethods(list){if(list===null||typeof list!=='object')return
const hooks=list.hooks
if(!Array.isArray(hooks))return
list.hooks=null
for(const hook of hooks){try{if(hook.proto[hook.name]===hook.wrapped)hook.proto[hook.name]=hook.original}catch{/* прототип заперт */}}}
function methodHooksStanding(room){for(const list of room.waiting.values()){
if(Array.isArray(list.hooks)&&list.hooks.length>0)return true}
return false}
function closeWaiting(room,name){const list=room.waiting.get(name)??null
room.waiting.delete(name)
unhookMethods(list)
if(room.waiting.size===0)releaseRootHook(room)
return list}
function rearmMethodHooks(win,room){for(const list of[...room.waiting.values()]){
if(!Array.isArray(list.hooks)||list.hooks.length===0)continue
unhookMethods(list)
ensureMethodHook(win,room,list.sig,list)}}
function ensureMethodHook(win,room,sig,list){if(list===undefined||list===null)return false
if(Array.isArray(list.hooks)&&list.hooks.length>0)return true
const cls=findDoor(win,{name:`__class-${sig.name}`,
declares:sig.declares,methods:sig.methods,statics:sig.statics,want:'class',from:sig.from})
if(!cls.ok)return false
list.viaClass=cls.value
const proto=cls.value?.prototype
if(!proto)return false
const room2=room
const win2=win
const hooks=[]
for(const name of sig.instanceVia){const original=proto[name]
if(typeof original!=='function')continue
const wrapped=function(...args){const answer=original.apply(this,args)
try{caught(room2,sig.name,this)}catch{rearmMethodHooks(win2,room2)}
return answer}
proto[name]=wrapped
hooks.push({proto,name,original,wrapped})}
if(hooks.length===0)return false
list.hooks=hooks
return true}
function caught(room,name,instance){const list=room.waiting.get(name)
if(list===undefined)return
const byClass=typeof list.viaClass==='function'
if(byClass){let ours=false
try{ours=instance instanceof list.viaClass}catch{ours=false}
if(!ours)return}
else if(!instanceFits(instance,list.sig))return
const value=list.sig.want==='instance'?instance:(instance?.constructor??null)
if(value===null||value===undefined)return
const ms=now()-list.started
room.missed.delete(name)
room.found.set(name,{value,instance,ms,matches:1,source:'live'})
closeWaiting(room,name)
for(const listener of list.listeners){try{listener({value,instance,ms})}catch{}}}
function ensureRootHook(win,room){if(room.unhook!==null)return true
const root=findDoor(win,{name:'__root-class',declares:ROOT_SIGNATURE,want:'class',from:'globals'})
if(!root.ok)return false
const proto=root.value.prototype
const original=proto?.[ROOT_HOOK_METHOD]
if(typeof original!=='function')return false
const wrapped=function(...args){const answer=original.apply(this,args)
try{inspect(room,this)}catch{/* наша слепота её экран не роняет */}
return answer}
proto[ROOT_HOOK_METHOD]=wrapped
room.unhook=()=>{if(proto[ROOT_HOOK_METHOD]===wrapped)proto[ROOT_HOOK_METHOD]=original}
return true}
function releaseRootHook(room){if(room.unhook===null)return
try{room.unhook()}catch{}
room.unhook=null}
function inspect(room,instance){if(room.waiting.size===0)return
const done=[]
for(const[name,list]of room.waiting){
if(list.probe!==null&&typeof instance?.[list.probe]!=='function')continue
if(!instanceFits(instance,list.sig))continue
let ctor=null
try{ctor=instance.constructor??null}catch{ctor=null}
const value=list.sig.want==='instance'?instance:ctor
if(value===null||value===undefined)continue
const ms=now()-list.started
room.missed.delete(name)
room.found.set(name,{value,instance,ms,matches:1,source:'live'})
done.push({name,list,value,instance,ms})}
for(const item of done){closeWaiting(room,item.name)
for(const listener of item.list.listeners){try{listener({value:item.value,instance:item.instance,ms:item.ms})}catch{}}}}
export function doors(win=globalThis){const room=roomOf(win)===null?undefined:memory.get(win)
if(room===undefined)return{found:[],pending:[],hooked:false,total:0}
const found=[]
for(const[name,entry]of room.found){if(name.startsWith('__'))continue
found.push({name,source:entry.source??'cache',ms:entry.ms})}
found.sort((a,b)=>a.name<b.name?-1:1)
return{found,pending:[...room.waiting.keys()].sort(),
hooked:room.unhook!==null||methodHooksStanding(room),total:found.length}}
export function rememberDoor(win,name,value,instance=null){if(roomOf(win)===null)return false
if(typeof name!=='string'||name===''||name.startsWith('__'))return false
if(value===null||value===undefined)return false
const room=memory.get(win)
if(room===undefined)return false
room.missed.delete(name)
room.found.set(name,{value,instance,ms:0,matches:1,source:'live'})
return true}
export function forgetDoors(win=globalThis){if(roomOf(win)===null)return
const room=memory.get(win)
if(room===undefined)return
for(const list of room.waiting.values())unhookMethods(list)
releaseRootHook(room)
room.found.clear()
room.waiting.clear()
memory.delete(win)}
function now(){try{return Math.round(performance.now())}catch{return Date.now()}}
