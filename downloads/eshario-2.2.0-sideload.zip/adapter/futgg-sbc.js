export const FUTGG_ORIGIN='https://www.fut.gg'
export const LIST_PATH='/api/fut/sbc/'
export const VOTES_PATH='/api/voting/entities/'
export const SET_TYPE=20
export const TTL_MS=600_000
export const PAGE_CAP=6
export const VOTES_PER_REQUEST=200
export const VOTES_REQUEST_CAP=2
export function listUrl(page=1){const n=Number(page)
return Number.isSafeInteger(n)&&n>1?`${FUTGG_ORIGIN}${LIST_PATH}?page=${n}`:`${FUTGG_ORIGIN}${LIST_PATH}`}
export function votesUrl(ids){const list=[]
for(const raw of Array.isArray(ids)?ids:[]){const id=Number(raw)
if(Number.isSafeInteger(id)&&id>0)list.push(`${SET_TYPE}_${id}`)}
return `${FUTGG_ORIGIN}${VOTES_PATH}?identifiers=${list.join(',')}`}
export function parseSets(body){const out=[]
const challenges=[]
const data=Array.isArray(body?.data)?body.data:[]
for(const entry of data){const eaId=int(entry?.eaId)
const id=int(entry?.id)
if(eaId===null||id===null)continue
out.push({eaId,id,cost:coins(entry?.cost),costPc:coins(entry?.costPc)})
for(const one of Array.isArray(entry?.challenges)?entry.challenges:[]){const challengeId=int(one?.eaId)
if(challengeId===null)continue
challenges.push({eaId:challengeId,setEaId:eaId,cost:coins(one?.cheapestSolutionPrice),costPc:coins(one?.cheapestSolutionPricePc)})}}
return{sets:out,challenges,page:int(body?.currentPage),totalPages:int(body?.totalPages)}}
export function parseVotes(body){const out=new Map()
const data=Array.isArray(body?.data)?body.data:[]
for(const entry of data){const mark=typeof entry?.entityIdentifier==='string'?entry.entityIdentifier:''
const parts=mark.split('_')
if(parts.length!==2||Number(parts[0])!==SET_TYPE)continue
const id=int(parts[1])
const total=count(entry?.totalVotes)
const up=count(entry?.upvotes)
const down=count(entry?.downvotes)
if(id===null||total===null||up===null||down===null)continue
out.set(id,{up,down,total})}
return out}
export function coinsOf(entry,platform){if(!entry)return null
if(platform==='pc')return entry.costPc??null
if(platform==='ps5')return entry.cost??null
return null}
export function votePercent(votes){const total=count(votes?.total)
const up=count(votes?.up)
if(total===null||up===null||total<=0)return null
return Math.round(Math.min(up,total)/total*100)}
export function createFutggSbc(deps={}){const net=typeof deps.fetch==='function'?deps.fetch:null
const now=typeof deps.clock==='function'?deps.clock:()=>Date.now()
const platformOf=typeof deps.platform==='function'?deps.platform:()=>null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const ttl=Number.isFinite(Number(deps.ttlMs))?Number(deps.ttlMs):TTL_MS
let entries=new Map()
let challengeEntries=new Map()
let loadedAt=null
let inFlight=null
let lastReason=null
const stats={loads:0,cached:0,requests:0,failures:0,pages:0,sets:0,voted:0,challenges:0}
const fresh=()=>loadedAt!==null&&now()-loadedAt<ttl
async function ask(url){stats.requests+=1
const response=await net(url)
const status=Number(response?.status)
if(!Number.isFinite(status)||status<200||status>=300)throw new Error(`http-${response?.status??'?'}`)
return await response.json()}
async function run(){const collected=new Map()
const collectedChallenges=new Map()
let page=1
let pages=1
while(page<=pages&&page<=PAGE_CAP){const parsed=parseSets(await ask(listUrl(page)))
for(const set of parsed.sets)if(!collected.has(set.eaId))collected.set(set.eaId,{id:set.id,cost:set.cost,costPc:set.costPc,votes:null})
for(const one of parsed.challenges)if(!collectedChallenges.has(one.eaId))collectedChallenges.set(one.eaId,{setEaId:one.setEaId,cost:one.cost,costPc:one.costPc})
if(page===1&&parsed.totalPages!==null&&parsed.totalPages>0)pages=parsed.totalPages
stats.pages+=1
page+=1}
if(collected.size===0)throw new Error('пустой список')
entries=collected
challengeEntries=collectedChallenges
loadedAt=now()
stats.sets=collected.size
stats.challenges=collectedChallenges.size
const ids=[...collected.values()].map((one)=>one.id)
for(let taken=0,batch=0;taken<ids.length&&batch<VOTES_REQUEST_CAP;taken+=VOTES_PER_REQUEST,batch+=1){const slice=ids.slice(taken,taken+VOTES_PER_REQUEST)
const votes=parseVotes(await ask(votesUrl(slice)))
for(const entry of collected.values()){const found=votes.get(entry.id)
if(found!==undefined)entry.votes=found}}
stats.voted=[...collected.values()].filter((one)=>one.votes!==null).length
return{ok:true,reason:null,sets:collected.size}}
return{
load(){const before=stats.requests
if(net===null){lastReason='доставки нет'
return Promise.resolve({ok:false,reason:lastReason,requests:0,cached:false})}
if(fresh()){stats.cached+=1
return Promise.resolve({ok:true,reason:null,requests:0,cached:true})}
if(inFlight!==null)return inFlight
stats.loads+=1
inFlight=run().then((result)=>{inFlight=null
lastReason=null
return{...result,requests:stats.requests-before,cached:false}},(err)=>{inFlight=null
stats.failures+=1
lastReason=String(err?.message??err)
onError(err)
return{ok:false,reason:lastReason,requests:stats.requests-before,cached:false}})
return inFlight},
peek(eaId){const key=int(eaId)
if(key===null)return null
const entry=entries.get(key)
if(entry===undefined)return null
return{coins:coinsOf(entry,platformOf()),percent:votePercent(entry.votes),votes:entry.votes===null?null:entry.votes.total}},
peekChallenge(eaId){const key=int(eaId)
if(key===null)return null
const entry=challengeEntries.get(key)
if(entry===undefined)return null
return{coins:coinsOf(entry,platformOf()),setEaId:entry.setEaId??null}},
size(){return entries.size},
forget(){entries=new Map()
challengeEntries=new Map()
loadedAt=null
lastReason=null},
state(){return{sets:entries.size,challengePrices:challengeEntries.size,loadedAt,ageMs:loadedAt===null?null:now()-loadedAt,fresh:fresh(),
platform:platformOf(),reason:lastReason,...stats}}}}
function int(value){const n=Number(value)
return Number.isSafeInteger(n)&&n>0?n:null}
function count(value){const n=Number(value)
return Number.isSafeInteger(n)&&n>=0?n:null}
function coins(value){const n=Number(value)
return Number.isFinite(n)&&n>0?Math.round(n):null}
