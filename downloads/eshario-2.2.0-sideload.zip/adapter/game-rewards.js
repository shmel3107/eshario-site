import{refusesSuperclass} from './sbc-screen.js'
import{packCardName} from './store-packs.js'
import{screenPrototype}from'./screen-door.js'
export const GAME_REWARDS_VIEW_DOOR=Object.freeze({name:'game-rewards-view',
declares:['setSbcChallenge','setSbcSet']})
export const GAME_REWARDS_DOOR=Object.freeze({name:'game-rewards-controller',
declares:['checkRewards','setButtonText'],
methods:['viewDidAppear','onButtonTapped']})
const installations=new WeakMap()
const tapped=new WeakSet()
function idle(reason){return{ok:false,reason,state:()=>({ok:false,reason,marked:0,shown:0,foreign:0,arrived:0}),dispose(){}}}
const arrived=new WeakSet()
function count(value){const n=Number(value)
return Number.isFinite(n)&&n>0?n:0}
export function readRewardFacts(rewards){const out={coins:0,packs:0,packsTradable:0,packsUntradable:0,packsUnknown:0,cards:0,xp:0,other:0,names:[],unreadable:0,total:0}
const list=Array.isArray(rewards)?rewards:[]
out.total=list.length
for(const vo of list){if(!vo||typeof vo!=='object'){out.unreadable+=1
continue}
try{if(vo.isCoin===true){out.coins+=count(vo.value)
continue}
if(vo.isPack===true){const many=Math.max(1,count(vo.count))
out.packs+=many
if(vo.tradable===true)out.packsTradable+=many
else if(vo.tradable===false)out.packsUntradable+=many
else out.packsUnknown+=many
continue}
if(vo.isItem===true){out.cards+=Math.max(1,count(vo.count))
const name=packCardName(vo.item)
if(name!=='')out.names.push(name)
continue}
if(vo.isXP===true){out.xp+=1
continue}
out.other+=1}catch{
out.unreadable+=1}}
return out}
export function pressRewardsButton(controller){if(!controller||typeof controller!=='object')return{ok:false,reason:'no-window'}
if(tapped.has(controller))return{ok:false,reason:'already-tapped'}
if(controller.rewardsCarouselSetup!==true)return{ok:false,reason:'not-shown'}
let view=null
try{view=controller.getView?.()??null}catch{view=null}
if(!view||typeof view!=='object')return{ok:false,reason:'no-view'}
try{if(typeof view.onButtonTapped==='function'){view.onButtonTapped()
return{ok:true,reason:null}}
if(typeof controller.onButtonTapped==='function'){controller.onButtonTapped()
return{ok:true,reason:'controller'}}}catch{return{ok:false,reason:'failed'}}
return{ok:false,reason:'no-door'}}
function ensureRewardsInstall(win){const viewProto=screenPrototype(win,GAME_REWARDS_VIEW_DOOR)
const ctrlProto=screenPrototype(win,GAME_REWARDS_DOOR)
if(typeof viewProto?.setSbcChallenge!=='function'
||typeof viewProto?.setSbcSet!=='function'
||typeof ctrlProto?.viewDidAppear!=='function'
||typeof ctrlProto?.onButtonTapped!=='function')return{record:null,reason:'unavailable'}
for(const fn of [viewProto.setSbcChallenge,viewProto.setSbcSet,ctrlProto.viewDidAppear,ctrlProto.onButtonTapped]){if(refusesSuperclass(fn))return{record:null,reason:'refused'}}
const found=installations.get(ctrlProto)
if(found!==undefined)return{record:found,reason:null}
const marks=new WeakMap()
const shownListeners=new Set()
const packListeners=new Set()
const counts={marked:0,shown:0,foreign:0,arrived:0}
const rawChallenge=viewProto.setSbcChallenge
const rawSet=viewProto.setSbcSet
const rawAppear=ctrlProto.viewDidAppear
const rawTapped=ctrlProto.onButtonTapped
const mark=(raw,source)=>function(){try{marks.set(this,source)
counts.marked+=1}catch{
}
return raw.apply(this,arguments)}
viewProto.setSbcChallenge=mark(rawChallenge,'challenge')
viewProto.setSbcSet=mark(rawSet,'set')
ctrlProto.onButtonTapped=function(){try{tapped.add(this)}catch{
}
const out=rawTapped.apply(this,arguments)
try{announce(this)}catch{
}
return out}
const handleFor=(controller,source)=>{let closed=false
const scope={}
try{controller.onExit.observe(scope,function(sender){closed=true
try{(sender??controller.onExit).unobserve(scope)}catch{
}})}catch{
}
let facts=readRewardFacts(null)
try{facts=readRewardFacts(controller.rewards)}catch{
}
return{source,ready:controller.rewardsCarouselSetup===true,rewards:facts,
closed:()=>closed||tapped.has(controller),press:()=>pressRewardsButton(controller)}}
const announce=(controller)=>{if(packListeners.size===0)return
if(arrived.has(controller))return
let facts=null
try{facts=readRewardFacts(controller.rewards)}catch{return}
if(facts.packs<1)return
arrived.add(controller)
counts.arrived+=1
let source=null
try{const view=controller.getView?.()??null
source=view===null?null:marks.get(view)??null}catch{source=null}
const note=Object.freeze({source,packs:facts.packs,tradable:facts.packsTradable,
untradable:facts.packsUntradable,unknown:facts.packsUnknown})
for(const listener of packListeners){try{listener(note)}catch{
}}}
ctrlProto.viewDidAppear=function(){
const out=rawAppear.apply(this,arguments)
try{let view=null
try{view=this.getView?.()??null}catch{view=null}
const source=view===null?undefined:marks.get(view)
if(source===undefined)counts.foreign+=1
else{counts.shown+=1
const handle=handleFor(this,source)
for(const listener of shownListeners){try{listener(handle)}catch{
}}}}catch{
}
return out}
const record={viewProto,ctrlProto,marks,counts,shown:shownListeners,packs:packListeners,
raw:{challenge:rawChallenge,set:rawSet,appear:rawAppear,tap:rawTapped},
wrap:{challenge:viewProto.setSbcChallenge,set:viewProto.setSbcSet,appear:ctrlProto.viewDidAppear,tap:ctrlProto.onButtonTapped}}
installations.set(ctrlProto,record)
return{record,reason:null}}
function handleOf(record,listeners,listener){let active=true
return{ok:true,reason:null,
state:()=>({ok:active,reason:null,...record.counts}),
dispose(){if(!active)return
active=false
listeners.delete(listener)
if(record.shown.size>0||record.packs.size>0)return
const{viewProto,ctrlProto,raw,wrap}=record
if(viewProto.setSbcChallenge===wrap.challenge)viewProto.setSbcChallenge=raw.challenge
if(viewProto.setSbcSet===wrap.set)viewProto.setSbcSet=raw.set
if(ctrlProto.viewDidAppear===wrap.appear)ctrlProto.viewDidAppear=raw.appear
if(ctrlProto.onButtonTapped===wrap.tap)ctrlProto.onButtonTapped=raw.tap
installations.delete(ctrlProto)}}}
export function installGameRewardsCapture(win,onShown=()=>{}){const{record,reason}=ensureRewardsInstall(win)
if(record===null)return idle(reason)
if(record.shown.size>0)return idle('already')
record.shown.add(onShown)
return handleOf(record,record.shown,onShown)}
export function installPackRewardCapture(win,onArrived=()=>{}){const{record,reason}=ensureRewardsInstall(win)
if(record===null)return idle(reason)
if(record.packs.has(onArrived))return idle('already')
record.packs.add(onArrived)
return handleOf(record,record.packs,onArrived)}
