export const STOP_REASON_KEYS=Object.freeze({captcha:'automation.stop.captcha',fatal:'automation.stop.fatal','out-of-coins':'automation.stop.outOfCoins','spend-limit':'automation.stop.spendLimit','loss-limit':'automation.stop.lossLimit','purchase-limit':'automation.stop.purchaseLimit','search-limit':'automation.stop.searchLimit','action-limit':'automation.stop.actionLimit','time-limit':'automation.stop.timeLimit','bad-state':'automation.stop.badState','unassigned-full':'automation.stop.unassignedFull','unassigned-unavailable':'automation.stop.unassignedUnavailable',cancelled:'automation.stop.cancelled','iteration-cap':'automation.stop.iterationCap',
throttled:'automation.stop.throttled','place-failed':'automation.stop.placeFailed','save-failed':'automation.stop.saveFailed','day-budget':'automation.stop.dayBudget','search-hour':'automation.stop.searchHour','market-budget':'automation.stop.marketBudget','market-rest':'automation.stop.marketRest','hour-cap':'automation.stop.hourCap',
'counter-unavailable':'automation.stop.counterUnavailable',
'market-off':'automation.stop.marketOff','market-unreadable':'automation.stop.marketUnreadable',
'session-over':'automation.stop.sessionOver','consent-required':'automation.stop.consentRequired',
'too-many-matches':'automation.stop.tooManyMatches','filter-changed':'automation.stop.filterChanged',
'buy-blocked':'automation.stop.buyBlocked','bid-blocked':'automation.stop.bidBlocked',
'move-blocked':'automation.stop.moveBlocked','list-blocked':'automation.stop.listBlocked',
rest:'automation.stop.marketRest',
unknown:'automation.stop.unknown'
})
export const CALM_STOPS=Object.freeze(['cancelled','purchase-limit','search-limit',
'action-limit','time-limit','spend-limit','loss-limit','iteration-cap','session-over',
'day-budget','search-hour','market-budget','hour-cap','too-many-matches','filter-changed'])
export const CRITICAL_STOPS=Object.freeze(Object.keys(STOP_REASON_KEYS)
.filter((reason)=>!CALM_STOPS.includes(reason)))
export const isCriticalStop=(reason)=>CRITICAL_STOPS.includes(reason)
export const DOOR_CAUSE_KEYS=Object.freeze({'new-items-full':'automation.door.newItemsFull',
'watch-list-full':'automation.door.watchListFull','not-enough-coins':'automation.door.noCoins',
'market-off':'automation.door.marketOff','bid-out-of-grid':'automation.door.bidGrid',
capacity:'automation.door.noRoom',predicate:'automation.door.notAllowed',
'already-selling':'automation.door.selling','locked-card':'automation.door.locked',
'frozen-card':'automation.door.frozen','feature-off':'automation.door.featureOff',
'unreadable-market':'automation.door.unreadable','unreadable-lot':'automation.door.unreadable',
'unreadable-price':'automation.door.unreadable','unreadable-capacity':'automation.door.unreadable',
'unreadable-coins':'automation.door.unreadable','unreadable-limits':'automation.door.unreadable',
'unreadable-predicate':'automation.door.unreadable','unreadable-items':'automation.door.unreadable',
'unreadable-rows':'automation.door.unreadable','unreadable-origin':'automation.door.unreadable',
'unreadable-item':'automation.door.unreadable','unreadable-feature':'automation.door.unreadable',
'unreadable-locks':'automation.door.unreadable','frozen-unreadable':'automation.door.unreadable'})
const DOOR_STOP_KEYS=Object.freeze({'buy-blocked':'automation.stop.buyBlockedWhy',
'bid-blocked':'automation.stop.bidBlockedWhy','move-blocked':'automation.stop.moveBlockedWhy',
'list-blocked':'automation.stop.listBlockedWhy'})
export function stopReasonKey(reason,door=null){if(typeof door==='string'&&door!==''
&&Object.hasOwn(DOOR_STOP_KEYS,reason))return DOOR_STOP_KEYS[reason]
return Object.hasOwn(STOP_REASON_KEYS,reason)?STOP_REASON_KEYS[reason]:'automation.stop.unknown'
}
