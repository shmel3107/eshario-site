import{tradabilityOf} from '../features/club-analysis.js'
export const REQUIREMENT_KEY=Object.freeze({TEAM_STAR_RATING:0,PLAYER_COUNT:2,PLAYER_QUALITY:3,SAME_NATION_COUNT:4,SAME_LEAGUE_COUNT:5,SAME_CLUB_COUNT:6,NATION_COUNT:7,LEAGUE_COUNT:8,CLUB_COUNT:9,NATION_ID:10,LEAGUE_ID:11,CLUB_ID:12,SCOPE:13,LEGEND_COUNT:15,NUM_TROPHY_REQUIRED:16,PLAYER_LEVEL:17,PLAYER_RARITY:18,TEAM_RATING:19,PLAYER_COUNT_COMBINED:21,PLAYER_RARITY_GROUP:25,PLAYER_MIN_OVR:26,PLAYER_EXACT_OVR:27,PLAYER_MAX_OVR:28,FIRST_OWNER_PLAYERS_COUNT:30,PLAYER_TRADABILITY:33,CHEMISTRY_POINTS:35,ALL_PLAYERS_CHEMISTRY_POINTS:36})
export const COMPARE=Object.freeze({GREATER:0,LOWER:1,EXACT:2})
export const OPERATION=Object.freeze({AND:'AND',OR:'OR'})
export const QUALITY=Object.freeze({BRONZE:1,SILVER:2,GOLD:3})
export const RATING_TIER=Object.freeze({NONE:0,BRONZE:1,SILVER:2,GOLD:3})
export const TIER_BOUNDS=Object.freeze({BRONZE_MAX:64,SILVER_MAX:74})
export function tierOf(player){const rating=Number(player?.rating)
if(!Number.isFinite(rating))return RATING_TIER.NONE
if(rating<=TIER_BOUNDS.BRONZE_MAX)return RATING_TIER.BRONZE
if(rating<=TIER_BOUNDS.SILVER_MAX)return RATING_TIER.SILVER
return RATING_TIER.GOLD}
export function groupsOf(player){return Array.isArray(player?.groups)?player.groups:[]}
export const LEGENDS_CLUB_ID=112658
export const LEGENDS_LEAGUE_ID=2118
const firstNum=(...values)=>{for(const value of values)if(isNum(value))return value
return undefined}
export const nationOf=(p)=>firstNum(p?.nationId,p?.nation)
export const leagueOf=(p)=>firstNum(p?.leagueId,p?.league)
export const clubOf=(p)=>firstNum(p?.teamId,p?.club,p?.clubId)
export function linkedClubOf(p,linkedTeam){const raw=clubOf(p)
if(raw===undefined||typeof linkedTeam!=='function') return raw
try{const linked=linkedTeam(raw)
return isNum(linked)?linked:raw}catch{
return raw}}
export const rarityOf=(p)=>firstNum(p?.rareflag,p?.rarity)
export function isLegendCard(player){if(player?.isLegend===true)return true
if(typeof player?.isLegend==='function'){try{return player.isLegend()===true}catch{return false}}
return clubOf(player)===LEGENDS_CLUB_ID||leagueOf(player)===LEGENDS_LEAGUE_ID}
export function isFirstOwner(player){if(player?.firstOwner===true)return true
return Number(player?.owners)===1}
export const KEY_NAMES=Object.freeze(Object.fromEntries(Object.entries(REQUIREMENT_KEY).map(([name,value])=>[value,name])))
const isNum=(value)=>typeof value==='number'&&Number.isFinite(value)
export const MEASURABLE_KEYS=Object.freeze(new Set([REQUIREMENT_KEY.PLAYER_COUNT,REQUIREMENT_KEY.PLAYER_COUNT_COMBINED,REQUIREMENT_KEY.NATION_COUNT,REQUIREMENT_KEY.LEAGUE_COUNT,REQUIREMENT_KEY.CLUB_COUNT,REQUIREMENT_KEY.SAME_NATION_COUNT,REQUIREMENT_KEY.SAME_LEAGUE_COUNT,REQUIREMENT_KEY.SAME_CLUB_COUNT,REQUIREMENT_KEY.TEAM_RATING,REQUIREMENT_KEY.TEAM_STAR_RATING,REQUIREMENT_KEY.CHEMISTRY_POINTS,REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS,REQUIREMENT_KEY.PLAYER_MIN_OVR,REQUIREMENT_KEY.PLAYER_MAX_OVR,
REQUIREMENT_KEY.PLAYER_EXACT_OVR,REQUIREMENT_KEY.NATION_ID,REQUIREMENT_KEY.LEAGUE_ID,REQUIREMENT_KEY.CLUB_ID,REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_TRADABILITY,REQUIREMENT_KEY.LEGEND_COUNT,REQUIREMENT_KEY.FIRST_OWNER_PLAYERS_COUNT,
REQUIREMENT_KEY.PLAYER_QUALITY,REQUIREMENT_KEY.PLAYER_LEVEL,REQUIREMENT_KEY.PLAYER_RARITY_GROUP]))
export const UNMEASURABLE_BY_EA=Object.freeze(new Set([REQUIREMENT_KEY.SCOPE,REQUIREMENT_KEY.NUM_TROPHY_REQUIRED]))
export function isMeasurable(key){return MEASURABLE_KEYS.has(key)}
const COMBINED_KEYS=Object.freeze(new Set([REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS,REQUIREMENT_KEY.NATION_ID,REQUIREMENT_KEY.LEAGUE_ID,REQUIREMENT_KEY.CLUB_ID,REQUIREMENT_KEY.PLAYER_MIN_OVR,REQUIREMENT_KEY.PLAYER_MAX_OVR,REQUIREMENT_KEY.PLAYER_EXACT_OVR,REQUIREMENT_KEY.PLAYER_TRADABILITY]))
function dtoKeys(raw){if(typeof raw?.keys!=='function') return null
try{const keys=raw.keys()
return Array.isArray(keys)?keys.map(Number).filter(isNum):null}catch{return null}}
function dtoValues(raw,key){if(typeof raw?.getValue!=='function') return[]
try{const values=raw.getValue(key)
return(Array.isArray(values)?values:[values]).map(Number).filter(isNum)}catch{return[]}}
function dtoValuesAreNumbers(raw,key){if(typeof raw?.getValue!=='function')return false
try{const values=raw.getValue(key)
const list=Array.isArray(values)?values:[values]
return list.length>0&&list.every((one)=>typeof one==='number'&&Number.isFinite(one))}catch{return false}}
export function parseRequirement(raw){
const keys=dtoKeys(raw)
if(keys&&keys.length>0){const compare=isNum(raw?.scope)?raw.scope:COMPARE.GREATER
const count=isNum(raw?.count)&&raw.count>=0?raw.count:null
const entries=keys.map((key)=>{const values=dtoValues(raw,key);
if(!dtoValuesAreNumbers(raw,key))return{key,value:null,values:[],name:KEY_NAMES[key]??`UNKNOWN_${key}`}
return{key,value:values[0]??null,values,name:KEY_NAMES[key]??`UNKNOWN_${key}`
}})
if(entries.some((entry)=>entry.value===null))return null
if(entries.length>1){return{key:null,compare,value:null,values:[],count,name:'COMBINED',combined:entries}}
const[entry]=entries
return{key:entry.key,compare,value:entry.value,values:entry.values,count,name:entry.name,combined:null}}
if(isNum(raw?.key)&&isNum(raw?.value)){const key=raw.key
const value=raw.value
const values=Array.isArray(raw.values)&&raw.values.every(isNum)
?[...raw.values]
:[value]
return{key,compare:isNum(raw.compare)?raw.compare:COMPARE.GREATER,value,values,count:isNum(raw.count)?raw.count:null,name:KEY_NAMES[key]??`UNKNOWN_${key}`,combined:null}}
const key=raw?.eligibilityKey
if(!isNum(key))return null
if(!isNum(raw?.eligibilityValue))return null
const compare=isNum(raw?.scope)?raw.scope:COMPARE.GREATER
const value=raw.eligibilityValue
const count=isNum(raw?.count)?raw.count:null
return{key,compare,value,values:[value],count,name:KEY_NAMES[key]??`UNKNOWN_${key}`,combined:null}}
export const COUNT_BASED_KEYS=Object.freeze(new Set([REQUIREMENT_KEY.NATION_ID,REQUIREMENT_KEY.LEAGUE_ID,REQUIREMENT_KEY.CLUB_ID,REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_TRADABILITY,REQUIREMENT_KEY.PLAYER_MIN_OVR,REQUIREMENT_KEY.PLAYER_MAX_OVR,REQUIREMENT_KEY.PLAYER_EXACT_OVR,
REQUIREMENT_KEY.PLAYER_LEVEL,REQUIREMENT_KEY.PLAYER_RARITY_GROUP]))
export function needOf(req){if(Array.isArray(req?.combined))return isNum(req?.count)?req.count:null
if(!COUNT_BASED_KEYS.has(req?.key))return isNum(req?.value)?req.value:null
return isNum(req?.count)?req.count:null}
export function parseRequirements(list){const parsed=[]
let skipped=0
for(const raw of Array.isArray(list)?list:[]){const req=parseRequirement(raw)
if(req)parsed.push(req)
else skipped+=1}
return{requirements:parsed,skipped}}
export function satisfies(compare,have,need){if(!isNum(have)||!isNum(need))return false
if(compare===COMPARE.LOWER)return have<=need
if(compare===COMPARE.EXACT)return have===need
return have>=need}
export function measure(squad,key,req=null,opts={}){const players=Array.isArray(squad?.players)?squad.players:[]
const value=isNum(req?.value)?req.value:null
const values=Array.isArray(req?.values)&&req.values.length>0
?req.values.filter(isNum)
:(value===null?[]:[value])
const hasValue=(candidate)=>values.includes(candidate)
const linkedTeam=typeof opts?.linkedTeam==='function'?opts.linkedTeam:undefined
const club=(p)=>linkedClubOf(p,linkedTeam)
const countWhere=(predicate)=>players.filter((p)=>{try{return predicate(p)===true}catch{return false}}).length
const distinct=(readField)=>new Set(players.map(readField).filter((v)=>v!==undefined)).size
const maxSame=(readField)=>{const counts=new Map()
for(const p of players){const value=readField(p)
if(value===undefined)continue
counts.set(value,(counts.get(value)??0)+1)}
return counts.size===0?0:Math.max(...counts.values())}
switch(key){case REQUIREMENT_KEY.PLAYER_COUNT:case REQUIREMENT_KEY.PLAYER_COUNT_COMBINED:return players.length
case REQUIREMENT_KEY.NATION_COUNT:return distinct(nationOf)
case REQUIREMENT_KEY.LEAGUE_COUNT:return distinct(leagueOf)
case REQUIREMENT_KEY.CLUB_COUNT:return distinct(club)
case REQUIREMENT_KEY.SAME_NATION_COUNT:return maxSame(nationOf)
case REQUIREMENT_KEY.SAME_LEAGUE_COUNT:return maxSame(leagueOf)
case REQUIREMENT_KEY.SAME_CLUB_COUNT:return maxSame(club)
case REQUIREMENT_KEY.TEAM_RATING:case REQUIREMENT_KEY.TEAM_STAR_RATING:if(key===REQUIREMENT_KEY.TEAM_STAR_RATING&&typeof squad?.getStarRating==='function'){try{const rating=squad.getStarRating()
return isNum(rating)?rating:undefined}catch{return undefined}}
if(typeof squad?.getRating==='function'){try{const rating=squad.getRating()
return isNum(rating)?rating:undefined}catch{return undefined}}
return isNum(squad?.rating)?squad.rating:undefined
case REQUIREMENT_KEY.CHEMISTRY_POINTS:{if(typeof squad?.getChemistry==='function'){try{const chemistry=squad.getChemistry()
return isNum(chemistry)?chemistry:undefined}catch{return undefined}}
return isNum(squad?.chemistry)?squad.chemistry:undefined}
case REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS:{let slots=[]
if(typeof squad?.getSBCSlots==='function'){try{slots=squad.getSBCSlots()}catch{slots=[]}}else if(Array.isArray(squad?.slots))slots=Array.isArray(squad?.brickSlots)?squad.slots.concat(squad.brickSlots):squad.slots
if(!Array.isArray(slots)||slots.length===0)return players.length===0?0:undefined
const chemistry=slots.map((slot)=>slot?.chemistry).filter(isNum)
if(chemistry.length!==slots.length)return undefined
if(req?.compare===COMPARE.LOWER)return Math.max(...chemistry)
if(req?.compare===COMPARE.EXACT){return chemistry.every((points)=>points===chemistry[0])?chemistry[0]:-1}
return Math.min(...chemistry)}
case REQUIREMENT_KEY.PLAYER_MIN_OVR:return value===null?undefined:countWhere((p)=>isNum(p?.rating)&&p.rating>=value)
case REQUIREMENT_KEY.PLAYER_MAX_OVR:return value===null?undefined:countWhere((p)=>isNum(p?.rating)&&p.rating<=value)
case REQUIREMENT_KEY.PLAYER_EXACT_OVR:return value===null?undefined:countWhere((p)=>isNum(p?.rating)&&p.rating===value)
case REQUIREMENT_KEY.NATION_ID:return value===null?undefined:countWhere((p)=>hasValue(nationOf(p)))
case REQUIREMENT_KEY.LEAGUE_ID:return value===null?undefined:countWhere((p)=>hasValue(leagueOf(p)))
case REQUIREMENT_KEY.CLUB_ID:{
if(values.length===0)return undefined
const wanted=new Set()
for(const one of values){wanted.add(one)
wanted.add(linkedTeam===undefined?one:linkedClubOf({teamId:one},linkedTeam))}
return countWhere((p)=>wanted.has(club(p)))}
case REQUIREMENT_KEY.PLAYER_RARITY:return value===null?undefined:countWhere((p)=>hasValue(rarityOf(p)))
case REQUIREMENT_KEY.PLAYER_TRADABILITY:return value===null
?undefined
:countWhere((p)=>tradabilityOf(p)===(value===0?'tradeable':'untradeable'))
case REQUIREMENT_KEY.PLAYER_LEVEL:return value===null?undefined:countWhere((p)=>hasValue(tierOf(p)))
case REQUIREMENT_KEY.PLAYER_RARITY_GROUP:{if(value===null||values.length===0)return undefined
let total=0
for(const group of values)total+=countWhere((p)=>groupsOf(p).includes(group))
return total}
case REQUIREMENT_KEY.PLAYER_QUALITY:{
const tiers=[...new Set(players.map(tierOf))].filter((t)=>t!==RATING_TIER.NONE)
if(tiers.length===0)return-1
if(req?.compare===COMPARE.GREATER)return Math.min(...tiers)
if(req?.compare===COMPARE.LOWER)return Math.max(...tiers)
return tiers.length===1?tiers[0]:-1}
case REQUIREMENT_KEY.LEGEND_COUNT:return countWhere(isLegendCard)
case REQUIREMENT_KEY.FIRST_OWNER_PLAYERS_COUNT:return countWhere(isFirstOwner)
default:
return undefined}}
function measureCombined(squad,req,opts){if(!Array.isArray(req?.combined)||req.combined.length<2)return undefined
if(!req.combined.every((entry)=>COMBINED_KEYS.has(entry.key)))return undefined
const players=Array.isArray(squad?.players)?squad.players:[]
let slots=[]
if(typeof squad?.getSBCSlots==='function'){try{slots=squad.getSBCSlots()}catch{slots=[]}}else if(Array.isArray(squad?.slots))slots=squad.slots
const linkedTeam=typeof opts?.linkedTeam==='function'?opts.linkedTeam:undefined
const matches=(player,slot,entry)=>{const value=entry.value
switch(entry.key){case REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS:return isNum(slot?.chemistry)&&slot.chemistry===value
case REQUIREMENT_KEY.NATION_ID:return nationOf(player)===value
case REQUIREMENT_KEY.LEAGUE_ID:return leagueOf(player)===value
case REQUIREMENT_KEY.CLUB_ID:return linkedClubOf(player,linkedTeam)===value
case REQUIREMENT_KEY.PLAYER_MIN_OVR:return isNum(player?.rating)&&player.rating>=value
case REQUIREMENT_KEY.PLAYER_MAX_OVR:return isNum(player?.rating)&&player.rating<=value
case REQUIREMENT_KEY.PLAYER_EXACT_OVR:return player?.rating===value
case REQUIREMENT_KEY.PLAYER_TRADABILITY:return tradabilityOf(player)===(value===0?'tradeable':'untradeable')
default:return false}}
return players.filter((player,index)=>(req.combined.every((entry)=>matches(player,slots[index],entry)))).length}
export function isMeasurableRequirement(req){if(Array.isArray(req?.combined)){return req.combined.length>1&&req.combined.every((entry)=>COMBINED_KEYS.has(entry.key))}
return isMeasurable(req?.key)}
export function measureRequirement(squad,req,opts={}){return Array.isArray(req?.combined)
?measureCombined(squad,req,opts)
:measure(squad,req?.key,req,opts)}
export function checkSquad(squad,requirements,opts={}){const{requirements:parsed,skipped}=parseRequirements(requirements)
const failed=[]
const unknown=[]
let passed=0
for(const req of parsed){
if(!isMeasurableRequirement(req)){unknown.push({...req,have:null,why:'unsupported'})
continue}
const have=measureRequirement(squad,req,opts)
const need=needOf(req)
if(have===undefined||need===null){
unknown.push({...req,have:null,why:'no-data'})
continue}
if(!satisfies(req.compare,have,need)){failed.push({...req,have,need})}else{passed+=1}}
const operation=opts?.operation===OPERATION.OR?OPERATION.OR:OPERATION.AND
const ok=operation===OPERATION.OR
?passed>0
:failed.length===0&&unknown.length===0&&skipped===0
return{
ok,failed:ok&&operation===OPERATION.OR?[]:failed,unknown:ok&&operation===OPERATION.OR?[]:unknown,skipped,checked:parsed.length}}
