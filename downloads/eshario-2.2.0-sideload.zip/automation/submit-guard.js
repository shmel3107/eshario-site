import{REQUIREMENT_KEY,checkSquad,parseRequirements} from './sbc-requirements.js'
const isNum=(value)=>typeof value==='number'&&Number.isFinite(value)
const idOf=(item)=>String(item?.id??item?.itemId??'')
const CHEMISTRY_KEYS=new Set([REQUIREMENT_KEY.CHEMISTRY_POINTS,REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS])
function isChemistryReq(req){if(CHEMISTRY_KEYS.has(req?.key))return true
return Array.isArray(req?.combined)&&req.combined.some((entry)=>CHEMISTRY_KEYS.has(entry?.key))}
function isPerSlotReq(req){if(req?.key===REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS)return true
return Array.isArray(req?.combined)&&req.combined.some((entry)=>entry?.key===REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS)}
export function submitGuard(input={}){const blockers=[]
const warnings=[]
const players=Array.isArray(input.squad?.players)?input.squad.players:[]
if(players.length===0)blockers.push({code:'empty-squad',confirmable:false})
const badIds=(list)=>{const wanted=new Set((Array.isArray(list)?list:[]).map(String))
return players.map(idOf).filter((id)=>id!==''&&wanted.has(id))}
const locked=badIds(input.lockedIds)
if(locked.length>0)blockers.push({code:'locked-card',ids:locked,confirmable:false})
const active=badIds(input.activeSquadIds)
if(active.length>0)blockers.push({code:'active-squad-card',ids:active,confirmable:true})
const unbought=players.filter((p)=>p?.virtual===true).map(idOf)
if(unbought.length>0)blockers.push({code:'unbought-virtual',ids:unbought,confirmable:false})
const squadRef=input.squadRef??null
const judgeSquad={players,slots:Array.isArray(input.slots)?input.slots:[],
chemistry:isNum(input.liveChemistry)?input.liveChemistry:undefined}
if(typeof squadRef?.getRating==='function')judgeSquad.getRating=()=>squadRef.getRating()
if(typeof squadRef?.getChemistry==='function')judgeSquad.getChemistry=()=>squadRef.getChemistry()
const checked=checkSquad(judgeSquad,input.requirements,{operation:input.operation,linkedTeam:input.linkedTeam})
const shortReqs=checked.failed.filter((req)=>!isChemistryReq(req))
const unknownReqs=checked.unknown.filter((req)=>!isChemistryReq(req))
const chemFailed=checked.failed.filter(isChemistryReq)
const chemUnknown=checked.unknown.filter(isChemistryReq)
if(shortReqs.length>0)blockers.push({code:'requirements-short',reqs:shortReqs,confirmable:true})
if(unknownReqs.length>0||checked.skipped>0)blockers.push({code:'requirements-unknown',reqs:unknownReqs,skipped:checked.skipped,confirmable:true})
if(chemUnknown.length>0){const perSlot=chemUnknown.some(isPerSlotReq)
blockers.push({code:perSlot?'needs-live-player-chemistry':'needs-live-chemistry',confirmable:false})}
if(chemFailed.length>0)blockers.push({code:'live-chemistry-short',confirmable:false})
if(isNum(input.offlineChemistry)&&isNum(input.liveChemistry)&&input.offlineChemistry!==input.liveChemistry
&&parseRequirements(input.requirements).requirements.some(isChemistryReq)){warnings.push(`chemistry-estimate-mismatch:${input.offlineChemistry}!=${input.liveChemistry}`)}
return{allowed:blockers.length===0,blockers,warnings}}
