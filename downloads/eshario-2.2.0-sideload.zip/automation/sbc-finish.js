import{measureRequirement,needOf,tierOf,REQUIREMENT_KEY,COMPARE,OPERATION} from './sbc-requirements.js'
export const FINISH_MS=2000
export const FINISH_SIGNAL=1.05
export const FINISH_GUARD=10
export const BOUND_UNIT=250
export const BOUND_CAP=120_000
export const BOUND_MS=800
export const FINISH_CALL_MS=FINISH_MS+BOUND_MS
export const PROBE_COST=2.6
export const POLISH_SHARE=0.05
const DIVISOR=11
const isNum=(v)=>typeof v==='number'&&Number.isFinite(v)
export function relaxedOf(judge){const counts=[]
const filters=[]
let rating=null
if(judge.operation===OPERATION.OR)return{counts,filters,rating,relaxedAll:true}
const additive=[REQUIREMENT_KEY.PLAYER_LEVEL,REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_RARITY_GROUP,
REQUIREMENT_KEY.PLAYER_MIN_OVR,REQUIREMENT_KEY.PLAYER_MAX_OVR,REQUIREMENT_KEY.PLAYER_EXACT_OVR,
REQUIREMENT_KEY.NATION_ID,REQUIREMENT_KEY.LEAGUE_ID,REQUIREMENT_KEY.CLUB_ID,REQUIREMENT_KEY.PLAYER_TRADABILITY,
REQUIREMENT_KEY.LEGEND_COUNT,REQUIREMENT_KEY.FIRST_OWNER_PLAYERS_COUNT]
for(const req of judge.parsed){if(Array.isArray(req?.combined))continue
const need=needOf(req)
if(req.key===REQUIREMENT_KEY.TEAM_RATING){if(req.compare===COMPARE.GREATER&&isNum(need))rating=Math.max(rating??0,need)
continue}
if(req.key===REQUIREMENT_KEY.PLAYER_QUALITY&&isNum(need)){const keep=req.compare===COMPARE.GREATER?(t)=>t>=need
:req.compare===COMPARE.LOWER?(t)=>t<=need:(t)=>t===need
filters.push((card)=>keep(tierOf(card)))
continue}
if(req.key===REQUIREMENT_KEY.CHEMISTRY_POINTS&&req.compare!==COMPARE.LOWER&&isNum(need)&&need>0
&&Array.isArray(judge.positions)&&judge.positions.length===judge.size){const slots=new Set(judge.positions)
const fits=(card)=>(Array.isArray(card?.possiblePositions)&&card.possiblePositions.some((p)=>slots.has(p))?1:0)
const want=Math.min(judge.size,Math.ceil(need/3))
counts.push({req,need:want,compare:COMPARE.GREATER,of:fits,cap:want,derived:'в позиции'})
continue}
if(!additive.includes(req.key)||!isNum(need))continue
const opts={linkedTeam:judge.linkedTeam}
counts.push({req,need,compare:req.compare,
of:(card)=>{const v=measureRequirement({players:[card]},req,opts)
return isNum(v)?v:0},
cap:req.compare===COMPARE.GREATER?need:need+1})}
return{counts,filters,rating,relaxedAll:false}}
function countsOk(relax,have){for(let i=0;i<relax.counts.length;i+=1){const c=relax.counts[i]
const v=have[i]
if(c.range!==undefined){if(v<c.range[0]||v>c.range[1])return false
continue}
if(c.compare===COMPARE.GREATER?v<c.need:c.compare===COMPARE.LOWER?v>c.need:v!==c.need)return false}
return true}
export function ratingPasses(S,m,H,t,R,float){const okFloat=2*(S*(DIVISOR-m)+DIVISOR*H)>=242*R-11
const okInt=S+H-m*Math.min(t,99)>=DIVISOR*R
return float===true?okFloat:float===false?okInt:okFloat&&okInt}
export function*boundSteps(cards,judge,relaxIn=relaxedOf(judge),opts={}){const unit=isNum(opts.unit)&&opts.unit>0?opts.unit:BOUND_UNIT
const cap=isNum(opts.cap)&&opts.cap>0?opts.cap:Infinity
const tick=typeof opts.tick==='function'?opts.tick:null
const priceOf=typeof opts.priceOf==='function'?opts.priceOf:(card)=>card.price
let cells=0
let paid=0
const forcedIn=Array.isArray(opts.forced)?opts.forced:[]
const n=judge.size-forcedIn.length
if(n<0)return{lb:null,work:0}
let field=cards.filter((card)=>relaxIn.filters.every((keep)=>keep(card)))
if(relaxIn.relaxedAll){const cheap=field.slice().sort((a,b)=>priceOf(a)-priceOf(b)).slice(0,n)
return{lb:cheap.length===n?cheap.reduce((s,c)=>s+priceOf(c),0):null,work:0}}
const asFilter=new Set()
relaxIn.counts.forEach((c,i)=>{if(c.range!==undefined||(c.compare!==COMPARE.GREATER&&c.compare!==COMPARE.EXACT))return
const fromForced=forcedIn.reduce((s,f)=>s+(f.vec?.[i]??0),0)
if(c.need-fromForced<n)return
if(!field.every((card)=>c.of(card)<=1))return
if(c.need-fromForced>n){asFilter.add(-1)
return}
field=field.filter((card)=>c.of(card)===1)
asFilter.add(i)})
if(asFilter.has(-1))return{lb:null,work:0}
const keepAt=relaxIn.counts.map((c,i)=>i).filter((i)=>{if(asFilter.has(i))return false
const c=relaxIn.counts[i]
return!(c.compare===COMPARE.GREATER&&c.range===undefined&&c.need<=n&&field.every((card)=>c.of(card)>=1))})
const relax=keepAt.length===relaxIn.counts.length?relaxIn:{...relaxIn,counts:keepAt.map((i)=>relaxIn.counts[i])}
const forced=keepAt.length===relaxIn.counts.length?forcedIn
:forcedIn.map((f)=>({...f,vec:keepAt.map((i)=>f.vec?.[i]??0)}))
const caps=relax.counts.map((c)=>c.cap)
const radix=[]
let PC=1
for(const cap1 of caps){radix.push(PC)
PC*=cap1+1}
const R=relax.rating
const withRating=R!==null
const groups=new Map()
for(const card of field){const vec=relax.counts.map((c)=>c.of(card))
const key=`${withRating?card.rating:0}|${vec.join(',')}`
let g=groups.get(key)
if(g===undefined){g={rating:withRating?card.rating:0,vec,cards:[]}
groups.set(key,g)}
g.cards.push(card)}
for(const g of groups.values()){g.cards.sort((a,b)=>priceOf(a)-priceOf(b))
g.cards.length=Math.min(g.cards.length,n)
g.prices=g.cards.map((card)=>priceOf(card))
g.pre=[0]
for(const p of g.prices)g.pre.push(g.pre[g.pre.length-1]+p)}
const list=[...groups.values()]
const maxR=list.reduce((m,g)=>Math.max(m,g.rating),0)
const SUM=withRating?maxR*n+1:1
const SIZE=(n+1)*SUM*PC
const at=(k,s,c)=>(k*SUM+s)*PC+c
const decode=(code)=>caps.map((cap1,i)=>Math.floor(code/radix[i])%(cap1+1))
const encode=(vals)=>vals.reduce((sum,v,i)=>sum+Math.min(v,caps[i])*radix[i],0)
const decoded=Array.from({length:PC},(u,c)=>decode(c))
const forcedVec=caps.map((u,i)=>forced.reduce((s,f)=>s+(f.vec?.[i]??0),0))
const joinedOk=(a,b)=>countsOk(relax,caps.map((cap1,i)=>Math.min(a[i]+b[i]+forcedVec[i],cap1)))
let over=false
function*pay(count){cells+=count
while(cells-paid*unit>=unit){paid+=1
if(tick!==null)tick()
if(paid>cap){over=true
return}
yield}}
function*addGroup(dp,g){const next=dp.slice()
const shifts=[]
for(let c=0;c<PC;c+=1){const row=[]
for(let t=0;t<=g.prices.length;t+=1)row.push(encode(decoded[c].map((v,i)=>v+g.vec[i]*t)))
shifts.push(row)}
for(let k=0;k<n;k+=1){for(let s=0;s<SUM;s+=1){for(let c=0;c<PC;c+=1){const base=dp[at(k,s,c)]
if(base===Infinity)continue
for(let t=1;t<=g.prices.length&&k+t<=n;t+=1){const s2=s+t*g.rating
if(s2>=SUM)break
const idx=at(k+t,s2,shifts[c][t])
const v=base+g.pre[t]
if(v<next[idx])next[idx]=v}}
yield*pay(PC)
if(over)return next}}
return next}
const empty=()=>{const dp=new Float64Array(SIZE).fill(Infinity)
dp[at(0,0,0)]=0
return dp}
const traceOf=(ordered,k,s,c)=>{const layers=[empty()]
for(const g of ordered){const it=addGroup(layers[layers.length-1],g)
let step=it.next()
while(!step.done)step=it.next()
layers.push(step.value)}
const picked=[]
let state={k,s,c}
for(let j=ordered.length;j>0;j-=1){const g=ordered[j-1]
const here=layers[j][at(state.k,state.s,state.c)]
if(layers[j-1][at(state.k,state.s,state.c)]===here)continue
let found=false
for(let t=1;t<=g.prices.length&&t<=state.k&&!found;t+=1){const s0=state.s-t*g.rating
if(s0<0)break
for(let c0=0;c0<PC&&!found;c0+=1){if(encode(decoded[c0].map((v,i)=>v+g.vec[i]*t))!==state.c)continue
if(layers[j-1][at(state.k-t,s0,c0)]+g.pre[t]!==here)continue
picked.push({rating:g.rating,copies:t,prices:g.prices.slice(0,t),cards:g.cards.slice(0,t)})
state={k:state.k-t,s:s0,c:c0}
found=true}}
if(!found)return null}
return picked}
const profileOf=(parts)=>(parts.some((one)=>one===null)?{profile:null,squad:null}:{
profile:parts.flat().sort((a,b)=>b.rating-a.rating).map((one)=>`${one.copies}×${withRating?one.rating:'любой'}(${one.prices.join('+')})`).join(' '),
squad:parts.flat().flatMap((one)=>one.cards)})
if(!withRating){let dp=empty()
for(const g of list){dp=yield*addGroup(dp,g)
if(over)return{lb:null,cut:true,work:paid}}
let best=Infinity
let arg=null
for(let c=0;c<PC;c+=1){const v=dp[at(n,0,c)]
if(v<best&&joinedOk(decoded[c],caps.map(()=>0))){best=v
arg=c}}
if(best===Infinity)return{lb:null,work:paid}
return{lb:best,work:paid,...(opts.profile===true?profileOf([traceOf(list,n,0,arg)]):{})}}
const ratings=[...new Set(list.map((g)=>g.rating))].sort((a,b)=>a-b)
const allR=[...ratings,...forced.map((f)=>f.rating)]
if(allR.length===0)return{lb:null,work:paid}
const minR=Math.min(...allR)
const topR=Math.max(maxR,...forced.map((f)=>f.rating))
const Sf=forced.reduce((s,f)=>s+f.rating,0)
const lowAt=new Map()
let low=empty()
for(let t=minR-1;t<=topR;t+=1){for(const g of list)if(g.rating===t){low=yield*addGroup(low,g)
if(over)return{lb:null,cut:true,work:paid}}
lowAt.set(t,low)}
let high=empty()
let arg=null
let best=Infinity
for(let t=topR;t>=minR-1;t-=1){for(const g of list)if(g.rating===t+1){high=yield*addGroup(high,g)
if(over)return{lb:null,cut:true,work:paid}}
const lowT=lowAt.get(t)
const mF=forced.filter((f)=>f.rating>=t+1).length
const HF=forced.filter((f)=>f.rating>=t+1).reduce((s,f)=>s+f.rating,0)
for(let m=0;m<=n;m+=1){for(let H=0;H<SUM;H+=1){for(let cH=0;cH<PC;cH+=1){const hv=high[at(m,H,cH)]
if(hv===Infinity||hv>=best)continue
for(let S=DIVISOR*t;S<=DIVISOR*t+10;S+=1){const L=S-Sf-H
if(L<0||L>=SUM)continue
if(!ratingPasses(S,m+mF,H+HF,t,R,judge.float))continue
for(let cL=0;cL<PC;cL+=1){const lv=lowT[at(n-m,L,cL)]
if(lv===Infinity||hv+lv>=best)continue
if(!joinedOk(decoded[cH],decoded[cL]))continue
best=hv+lv
arg={t,m,H,cH,L,cL}}}}
yield*pay(PC)
if(over)return{lb:null,cut:true,work:paid}}}}
if(best===Infinity)return{lb:null,work:paid}
if(opts.profile!==true)return{lb:best,work:paid}
const highOrder=[]
for(let t=topR;t>=arg.t+1;t-=1)for(const g of list)if(g.rating===t)highOrder.push(g)
const lowOrder=[]
for(let t=minR-1;t<=arg.t;t+=1)for(const g of list)if(g.rating===t)lowOrder.push(g)
return{lb:best,work:paid,...profileOf([traceOf(highOrder,arg.m,arg.H,arg.cH),traceOf(lowOrder,n-arg.m,arg.L,arg.cL)])}}
export function lowerBound(cards,judge,relax=relaxedOf(judge),opts={}){const it=boundSteps(cards,judge,relax,opts)
for(;;){const step=it.next()
if(step.done)return step.value}}
function rngOf(seed){let a=seed>>>0
return()=>{a=(a+0x6D2B79F5)>>>0
let t=a
t=Math.imul(t^(t>>>15),t|1)
t^=t+Math.imul(t^(t>>>7),t|61)
return((t^(t>>>14))>>>0)/4294967296}}
export function*annealSteps(cards,ctx,opts={}){const n=ctx.size
const restarts=isNum(opts.restarts)?opts.restarts:3
const priceOf=typeof ctx.priceOf==='function'?ctx.priceOf:(card)=>card.price
const relax=opts.relax??{filters:[]}
const pool=cards.filter((card)=>relax.filters.every((keep)=>keep(card)))
if(pool.length<n)return{cards:null,cost:null,evaluations:0}
const keyMemo=new Map()
const keyOf=(card)=>{if(keyMemo.has(card))return keyMemo.get(card)
let key=null
try{key=typeof ctx.keyOf==='function'?ctx.keyOf(card)??null:null}catch{key=null}
if(key===null)key=card
keyMemo.set(card,key)
return key}
const index=(field)=>{const map=new Map()
for(const card of pool){const v=card[field]
if(!isNum(v))continue
let list=map.get(v)
if(list===undefined){list=[]
map.set(v,list)}
list.push(card)}
return map}
const byRating=index('rating')
const byLeague=index('leagueId')
const byNation=index('nationId')
const byClub=index('teamId')
const cheapTop=pool.slice(0,Math.min(pool.length,3000))
const HEAD=80
const pickFrom=(list,rnd)=>(list===undefined||list.length===0?null:list[Math.floor(Math.pow(rnd(),2)*Math.min(list.length,HEAD))])
let evaluations=0
let best=null
let bestCards=null
let owed=0
const pay=()=>{owed+=PROBE_COST
while(owed>=1){owed-=1
ctx.tick()}}
const replay=ctx.laps&&Array.isArray(ctx.laps.runs)?ctx.laps:null
const laps={runs:[],polish:0}
const out=()=>ctx.stopped()||(replay===null&&ctx.now()>=ctx.until)
function*measure(squad){evaluations+=1
pay()
const short=ctx.shortfall(squad)
yield
return short}
function*accept(squad,cost){if(best!==null&&cost>=best)return
const told=ctx.verdict(squad)
for(let i=0;i<Math.max(1,told?.tries??1);i+=1){evaluations+=1
pay()}
yield
if(Array.isArray(told?.order)){best=cost
bestCards=told.order.slice()}}
const costOf=(squad)=>squad.reduce((s,c)=>s+priceOf(c),0)
const began=ctx.now()
const runsUntil=ctx.now()+Math.max(0,ctx.until-ctx.now())*(1-POLISH_SHARE)
for(let seed=1;seed<=restarts&&!out()&&(replay===null||seed<=replay.runs.length);seed+=1){const rnd=rngOf(seed*7919)
const lapAt=evaluations
const left=runsUntil-ctx.now()
const until=ctx.now()+Math.max(1,left/(restarts-seed+1))
const squad=[]
const keys=new Set()
const start=Array.isArray(opts.starts)?opts.starts[seed-1]:undefined
if(Array.isArray(start)&&start.length===n){for(const card of start){squad.push(card)
keys.add(keyOf(card))}
yield*accept(squad,costOf(squad))}
for(let guard=0;squad.length<n&&guard<100_000;guard+=1){const card=cheapTop[Math.floor(rnd()*Math.min(cheapTop.length,600))]
if(keys.has(keyOf(card)))continue
keys.add(keyOf(card))
squad.push(card)}
if(squad.length<n)break
let cost=costOf(squad)
let short=yield*measure(squad)
let lambda=800
let temp=600
let iter=0
while(!out()&&(replay===null?ctx.now()<until:evaluations-lapAt<replay.runs[seed-1])){iter+=1
if((iter&1023)===0){temp=Math.max(5,temp*0.97)
if(short>0)lambda=Math.min(20_000,lambda*1.02)}
const slot=Math.floor(rnd()*n)
const gone=squad[slot]
const roll=rnd()
if(roll<0.12){const other=(slot+1+Math.floor(rnd()*(n-1)))%n
const mate=squad[Math.floor(rnd()*n)]
const group=rnd()<0.5?byLeague.get(mate.leagueId):byNation.get(mate.nationId)
const a=pickFrom(group,rnd)
const b=pickFrom(group,rnd)
const goneB=squad[other]
if(a===null||b===null||a===b||keyOf(a)===keyOf(b))continue
const stay=new Set(keys)
stay.delete(keyOf(gone))
stay.delete(keyOf(goneB))
if(stay.has(keyOf(a))||stay.has(keyOf(b)))continue
squad[slot]=a
squad[other]=b
const cost2=cost-priceOf(gone)-priceOf(goneB)+priceOf(a)+priceOf(b)
const short2=yield*measure(squad)
const delta=(cost2+lambda*short2)-(cost+lambda*short)
if(delta<=0||rnd()<Math.exp(-delta/temp)){keys.delete(keyOf(gone))
keys.delete(keyOf(goneB))
keys.add(keyOf(a))
keys.add(keyOf(b))
cost=cost2
short=short2
if(short===0)yield*accept(squad,cost)}
else{squad[slot]=gone
squad[other]=goneB}
continue}
let cand=null
if(roll<0.36){const mate=squad[Math.floor(rnd()*n)]
const dim=rnd()
cand=dim<0.45?pickFrom(byLeague.get(mate.leagueId),rnd)
:dim<0.9?pickFrom(byNation.get(mate.nationId),rnd):pickFrom(byClub.get(mate.teamId),rnd)}
else if(roll<0.58){const delta=Math.round((rnd()-0.5)*6)
cand=pickFrom(byRating.get(gone.rating+delta),rnd)}
else if(roll<0.80)cand=pickFrom(rnd()<0.5?byLeague.get(gone.leagueId):byNation.get(gone.nationId),rnd)
else cand=cheapTop[Math.floor(Math.pow(rnd(),3)*cheapTop.length)]
if(cand===null||cand===gone)continue
if(keyOf(cand)!==keyOf(gone)&&keys.has(keyOf(cand)))continue
squad[slot]=cand
const cost2=cost-priceOf(gone)+priceOf(cand)
const short2=yield*measure(squad)
const delta=(cost2+lambda*short2)-(cost+lambda*short)
if(delta<=0||rnd()<Math.exp(-delta/temp)){keys.delete(keyOf(gone))
keys.add(keyOf(cand))
cost=cost2
short=short2
if(short===0)yield*accept(squad,cost)}
else squad[slot]=gone}
laps.runs.push(evaluations-lapAt)}
const polishAt=evaluations
const done=()=>(replay===null?out():ctx.stopped()||evaluations-polishAt>=replay.polish)
if(bestCards!==null){let squad=bestCards.slice()
let moved=true
while(moved&&!done()){moved=false
for(let slot=0;slot<squad.length&&!done();slot+=1){const gone=squad[slot]
const keys=new Set(squad.filter((c,i)=>i!==slot).map(keyOf))
for(const cand of pool){if(priceOf(cand)>=priceOf(gone)||done())break
if(keys.has(keyOf(cand)))continue
const trial=squad.slice()
trial[slot]=cand
if((yield*measure(trial))!==0)continue
const was=best
yield*accept(trial,costOf(trial))
if(best!==was){squad=trial
moved=true
break}}}}}
laps.polish=evaluations-polishAt
return{cards:bestCards,cost:best,evaluations,laps,ms:ctx.now()-began}}
export function*finishSteps(ctx){const priceOf=typeof ctx.priceOf==='function'?ctx.priceOf:(card)=>card.price
const field=ctx.pool.slice().sort((a,b)=>priceOf(a)-priceOf(b))
const seed=Array.isArray(ctx.seed)&&ctx.seed.length===ctx.size?ctx.seed:null
const seedCost=seed===null?null:seed.reduce((s,c)=>s+priceOf(c),0)
const report={state:null,field:field.length,seed:seedCost,bound:null,boundCut:false,boundWork:0,ratio:null,
best:null,after:null,proven:false,needEdge:true,evaluations:0,signal:FINISH_SIGNAL,ms:FINISH_MS}
let lb=null
if(ctx.judge!==null){const told=yield*boundSteps(field,ctx.judge,relaxedOf(ctx.judge),{tick:ctx.tick,cap:BOUND_CAP,priceOf})
lb=isNum(told.lb)&&told.lb>0?told.lb:null
report.bound=lb
report.boundCut=told.cut===true
report.boundWork=told.work??0}
report.ratio=lb!==null&&isNum(seedCost)?seedCost/lb:null
if(report.ratio!==null&&report.ratio<=FINISH_SIGNAL){report.state='signal'
report.needEdge=false
return{chosen:null,report}}
const until=Math.min(ctx.now()+FINISH_MS,isNum(ctx.deadline)?ctx.deadline:Infinity)
const got=yield*annealSteps(field,{...ctx,until},{starts:seed===null?[]:[seed],relax:ctx.judge===null?undefined:relaxedOf(ctx.judge)})
report.evaluations=got.evaluations
report.laps=got.laps??null
report.best=got.cost
const least=[seedCost,got.cost].filter(isNum)
const cheapest=least.length===0?null:Math.min(...least)
report.after=lb!==null&&cheapest!==null?cheapest/lb:null
report.proven=lb!==null&&isNum(got.cost)&&got.cost<=lb
report.needEdge=!(report.proven||(report.after!==null&&report.after<=FINISH_SIGNAL))
report.state=got.cards===null?'none':'found'
return{chosen:got.cards,report}}
