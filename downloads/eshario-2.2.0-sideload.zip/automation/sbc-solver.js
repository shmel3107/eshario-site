import{checkSquad,parseRequirements,measureRequirement,satisfies,isMeasurableRequirement,needOf,tierOf,rarityOf,groupsOf,nationOf,leagueOf,clubOf,linkedClubOf,KEY_NAMES,OPERATION,REQUIREMENT_KEY,RATING_TIER,COMPARE} from './sbc-requirements.js'
import{tradabilityOf} from '../features/club-analysis.js'
import{squadRating,squadRatingBounds,MAX_RATING} from './squad-rating.js'
import{squadChemistry,arrangeForFormation,isId,contributionsOf,isLegend,isLeagueHero,isSuperChem,FIELD_PLAYERS,SLOT_MAX_CHEMISTRY,LEGENDS_CLUB_ID,LEAGUE_HERO_CLUB_ID,LEGENDS_LEAGUE_ID,FALLBACK_THRESHOLDS} from './squad-chemistry.js'
import{searchBurnOf,explainBurnOf,virtualBuysFrom,topNeed,BUCKET_KEYS,SELL_SWAP_ADVANTAGE} from './card-value.js'
import{finishSteps,FINISH_GUARD} from './sbc-finish.js'
export{submitGuard} from './submit-guard.js'
export const MAX_EVALUATIONS=20_000
export const MAX_ROUNDS=50
export const ROUNDS_BUDGET=13
export const TIME_BUDGET_MS=5000
export const TIME_CHECK_EVERY=4000
export const PRUNE_WORK_DIVISOR=32
export const TRACE_STEPS=400
export const betterRepairSwap=(one,than)=>than===null||than===undefined
||one.perPoint<than.perPoint
||(one.perPoint===than.perPoint&&one.score<than.score)
export const REPAIR_WATCH=16
export const REPAIR_IMPROVEMENTS=8
export const REPAIR_PANIC_SHARE=0.4
export const THIN_BUCKET_KEEP=5
export const CLOCK_LIMIT_SHARE=0.9
export const REPAIR_PANIC_PHASE='A'
export const SPECIAL_RARITY_MIN=2
export const SPECIAL_SWAP_CEILING=2000
export const GATE_RESERVE=8000
export const MAX_COUNTERWEIGHTS=null
export const CIRCLE_FIRST_SHARE=0.25
export const CIRCLE_SHARE=0.5
export const CIRCLE_DRY_ROUNDS=2
export const COUNTERWEIGHT_RESERVE=0.1
export const SEED_CLUSTERS=3
const isNum=(value)=>typeof value==='number'&&Number.isFinite(value)
const MB26_VIEWED=128
export const mb26Delta=(inValue,outValue,inAt,outAt)=>inValue===outValue||!isId(inValue)||!isId(outValue)?0
:2*(inAt-outAt+1)
const mb26Sign=(req)=>{const values=[...new Set((Array.isArray(req?.values)?req.values:[]).filter(isNum))].sort((a,b)=>a-b)
const need=needOf(req)
return`${req?.key}|${req?.compare}|${isNum(req?.count)?req.count:'-'}|${isNum(need)?need:'-'}|${values.join(',')}`}
const MB26_PASSPORTS=Object.freeze([
{area:'A',mode:'club+market',requirements:[
{key:REQUIREMENT_KEY.LEAGUE_ID,compare:COMPARE.EXACT,count:11,value:308,values:[308,4]},
{key:REQUIREMENT_KEY.SAME_CLUB_COUNT,compare:COMPARE.LOWER,count:null,value:5,values:[5]},
{key:REQUIREMENT_KEY.PLAYER_RARITY_GROUP,compare:COMPARE.GREATER,count:2,value:4,values:[4]},
{key:REQUIREMENT_KEY.TEAM_RATING,compare:COMPARE.GREATER,count:null,value:68,values:[68]},
{key:REQUIREMENT_KEY.CHEMISTRY_POINTS,compare:COMPARE.GREATER,count:null,value:10,values:[10]}]},
{area:'B',mode:'club',requirements:[
{key:REQUIREMENT_KEY.SAME_LEAGUE_COUNT,compare:COMPARE.GREATER,count:null,value:4,values:[4]},
{key:REQUIREMENT_KEY.NATION_COUNT,compare:COMPARE.LOWER,count:null,value:5,values:[5]},
{key:REQUIREMENT_KEY.CLUB_COUNT,compare:COMPARE.LOWER,count:null,value:6,values:[6]},
{key:REQUIREMENT_KEY.PLAYER_RARITY_GROUP,compare:COMPARE.GREATER,count:4,value:4,values:[4]},
{key:REQUIREMENT_KEY.TEAM_RATING,compare:COMPARE.GREATER,count:null,value:81,values:[81]},
{key:REQUIREMENT_KEY.CHEMISTRY_POINTS,compare:COMPARE.GREATER,count:null,value:31,values:[31]}]},
{area:'C',mode:'club+market',requirements:[
{key:REQUIREMENT_KEY.SAME_NATION_COUNT,compare:COMPARE.GREATER,count:null,value:4,values:[4]},
{key:REQUIREMENT_KEY.SAME_LEAGUE_COUNT,compare:COMPARE.GREATER,count:null,value:3,values:[3]},
{key:REQUIREMENT_KEY.CLUB_COUNT,compare:COMPARE.LOWER,count:null,value:5,values:[5]},
{key:REQUIREMENT_KEY.PLAYER_RARITY_GROUP,compare:COMPARE.EXACT,count:11,value:4,values:[4]},
{key:REQUIREMENT_KEY.TEAM_RATING,compare:COMPARE.GREATER,count:null,value:81,values:[81]},
{key:REQUIREMENT_KEY.CHEMISTRY_POINTS,compare:COMPARE.GREATER,count:null,value:31,values:[31]}]}]
.map((one)=>({...one,sign:one.requirements.map(mb26Sign).sort().join(';')})))
const mb26FormSign=(requirements)=>requirements.map(mb26Sign).sort().join(';')
export function preferenceOf(player,options={}){const untradeable=tradabilityOf(player)==='untradeable'?0:1
const price=priceOf(player,options?.cachedPriceOf)
const rating=isNum(player?.rating)?player.rating:0
return{untradeable,price,rarity:rarityWeightOf(player),rating}}
const rarityWeightOf=(player)=>{const rarity=rarityOf(player)
return isNum(rarity)?rarity:0}
function priceOf(player,cachedPriceOf){if(typeof cachedPriceOf==='function'){try{const cached=cachedPriceOf(player)
if(isNum(cached)&&cached>0)return cached}catch{
}}
if(isNum(player?.lastSalePrice)&&player.lastSalePrice>0)return player.lastSalePrice
return Number.POSITIVE_INFINITY}
export function comparePreference(a,b,options={}){const pa=preferenceOf(a,options)
const pb=preferenceOf(b,options)
return compareKnownPreference(a,b,pa,pb,options?.ratingUp===true)}
function compareKnownPreference(a,b,pa,pb,ratingUp){if(pa.untradeable!==pb.untradeable)return pa.untradeable-pb.untradeable
if(pa.price!==pb.price)return pa.price-pb.price
const ra=pa.rarity??0
const rb=pb.rarity??0
if(ra!==rb)return ra-rb
if(pa.rating!==pb.rating)return ratingUp===true?pb.rating-pa.rating:pa.rating-pb.rating
return String(a?.id??'').localeCompare(String(b?.id??''))}
export function shortfallOf(squad,requirements,opts={}){const deficits=[]
for(const req of requirements)deficits.push(deficitOf(measureRequirement(squad,req,opts),req))
return foldDeficits(deficits,opts?.operation)}
const deficitOf=(have,req)=>{const need=needOf(req)
if(have===undefined||need===null)return Number.MAX_SAFE_INTEGER
return satisfies(req.compare,have,need)?0:Math.abs(need-have)}
const foldDeficits=(deficits,operation)=>{if(deficits.length===0)return Number.MAX_SAFE_INTEGER
return operation===OPERATION.OR
?Math.min(...deficits)
:deficits.reduce((sum,value)=>Math.min(Number.MAX_SAFE_INTEGER,sum+value),0)}
const COUNTER_ADDITIVE_KEYS=Object.freeze(new Set([REQUIREMENT_KEY.PLAYER_COUNT,REQUIREMENT_KEY.PLAYER_COUNT_COMBINED,REQUIREMENT_KEY.PLAYER_MIN_OVR,REQUIREMENT_KEY.PLAYER_MAX_OVR,REQUIREMENT_KEY.PLAYER_EXACT_OVR,REQUIREMENT_KEY.NATION_ID,REQUIREMENT_KEY.LEAGUE_ID,REQUIREMENT_KEY.CLUB_ID,REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_TRADABILITY,REQUIREMENT_KEY.PLAYER_LEVEL,REQUIREMENT_KEY.PLAYER_RARITY_GROUP,REQUIREMENT_KEY.LEGEND_COUNT,REQUIREMENT_KEY.FIRST_OWNER_PLAYERS_COUNT]))
const COUNTER_BUCKET_KEYS=Object.freeze(new Map([[REQUIREMENT_KEY.NATION_COUNT,['nation','distinct']],[REQUIREMENT_KEY.LEAGUE_COUNT,['league','distinct']],[REQUIREMENT_KEY.CLUB_COUNT,['club','distinct']],[REQUIREMENT_KEY.SAME_NATION_COUNT,['nation','max']],[REQUIREMENT_KEY.SAME_LEAGUE_COUNT,['league','max']],[REQUIREMENT_KEY.SAME_CLUB_COUNT,['club','max']]]))
export function makeJudgeCounter(requirements,opts={}){const linkedTeam=typeof opts?.linkedTeam==='function'?opts.linkedTeam:undefined
const readers={nation:nationOf,league:leagueOf,club:(p)=>linkedClubOf(p,linkedTeam)}
const plan=[]
const fields=[]
let served=0
for(const req of Array.isArray(requirements)?requirements:[]){const key=Array.isArray(req?.combined)?null:req?.key
if(key!==null&&COUNTER_ADDITIVE_KEYS.has(key)){
let zero
try{zero=measureRequirement({players:[]},req,opts)}catch{zero=undefined}
if(zero===0){plan.push({kind:'count',req,memo:new Map(),blind:false})
served+=1
continue}}
const bucket=key===null?undefined:COUNTER_BUCKET_KEYS.get(key)
if(bucket!==undefined){const[field,fold]=bucket
let f=fields.indexOf(field)
if(f===-1){f=fields.length
fields.push(field)}
plan.push({kind:fold,req,at:f})
served+=1
continue}
plan.push({kind:'judge',req})}
if(served===0)return null
const contribOf=(one,card)=>{let told=one.memo.get(card)
if(told===undefined){let measured
try{measured=measureRequirement({players:[card]},one.req,opts)}catch{measured=undefined}
told=isNum(measured)?measured:null
one.memo.set(card,told)}
return told}
const valueMemo=fields.map(()=>new Map())
const valueOf=(f,card)=>{const memo=valueMemo[f]
const told=memo.get(card)
if(told!==undefined||memo.has(card))return told
const value=readers[fields[f]](card)
memo.set(card,value)
return value}
const open=()=>{const boxes=fields.map(()=>({counts:new Map(),hist:new Map(),live:0,top:0}))
const base=plan.map(()=>0)
const scratch=plan.map(()=>0)
let trusted=true
const addCard=(card)=>{for(let f=0;f<fields.length;f+=1){const value=valueOf(f,card)
if(value===undefined)continue
const box=boxes[f]
const was=box.counts.get(value)??0
if(was===0)box.live+=1
else box.hist.set(was,(box.hist.get(was)??0)-1)
const now=was+1
box.counts.set(value,now)
box.hist.set(now,(box.hist.get(now)??0)+1)
if(now>box.top)box.top=now}}
const rebase=(fixedPlayers,chosen)=>{for(const box of boxes){box.counts.clear()
box.hist.clear()
box.live=0
box.top=0}
for(let r=0;r<plan.length;r+=1)base[r]=0
for(const list of[fixedPlayers,chosen]){for(const card of Array.isArray(list)?list:[]){addCard(card)
for(let r=0;r<plan.length;r+=1){const one=plan[r]
if(one.kind!=='count'||one.blind)continue
const told=contribOf(one,card)
if(told===null){one.blind=true
continue}
base[r]+=told}}}}
const distinctAfter=(box,outValue,inValue)=>{if(outValue===inValue)return box.live
let live=box.live
if(outValue!==undefined&&box.counts.get(outValue)===1)live-=1
if(inValue!==undefined&&(box.counts.get(inValue)??0)===0)live+=1
return live}
const maxSameAfter=(box,outValue,inValue)=>{if(outValue===inValue)return box.live===0?0:box.top
let live=box.live
let top=box.top
if(outValue!==undefined){const was=box.counts.get(outValue)??0
if(was===1)live-=1
if(was===top&&(box.hist.get(was)??0)===1)top=was-1}
if(inValue!==undefined){const was=box.counts.get(inValue)??0
if(was===0)live+=1
if(was+1>top)top=was+1}
return live===0?0:top}
return{
rebase,
get trusted(){return trusted},
distrust(){trusted=false},
score(outCard,inCard,squad){for(let r=0;r<plan.length;r+=1){const one=plan[r]
let have
if(one.kind==='count'&&!one.blind){const out=contribOf(one,outCard)
const inc=contribOf(one,inCard)
if(out===null||inc===null){one.blind=true
have=measureRequirement(squad,one.req,opts)}
else have=base[r]-out+inc}
else if(one.kind==='distinct'||one.kind==='max'){const box=boxes[one.at]
const outValue=valueOf(one.at,outCard)
const inValue=valueOf(one.at,inCard)
have=one.kind==='distinct'?distinctAfter(box,outValue,inValue):maxSameAfter(box,outValue,inValue)}
else have=measureRequirement(squad,one.req,opts)
scratch[r]=deficitOf(have,one.req)}
return foldDeficits(scratch,opts?.operation)}}}
return{open,
served,
plan:plan.map((one)=>one.kind)}}
const CHEM_POINTS_CAP=1024
const chemTableOf=(steps)=>{if(!Array.isArray(steps)||steps.length===0)return null
let cap=0
for(const step of steps){const need=step?.requirement
if(!isNum(need)||!isNum(step?.points))return undefined
if(need>cap)cap=need}
if(!Number.isInteger(cap)||cap<0||cap>CHEM_POINTS_CAP)return undefined
const table=new Float64Array(cap+1)
for(let at=0;at<=cap;at+=1){let sum=0
for(const step of steps){if(at>=step.requirement)sum+=step.points}
table[at]=sum}
return table}
const chemPointsBy=(table,contributions)=>{if(table===null||contributions<=0)return 0
return table[contributions>=table.length?table.length-1:contributions]}
export function makeChemCounter(positions,opts={}){if(!Array.isArray(positions)||positions.length!==FIELD_PLAYERS)return null
for(const one of positions){if(!isNum(one))return null}
const thresholds=opts?.thresholds??FALLBACK_THRESHOLDS
const tableClub=chemTableOf(thresholds?.club)
const tableLeague=chemTableOf(thresholds?.league)
const tableNation=chemTableOf(thresholds?.nation)
if(tableClub===undefined||tableLeague===undefined||tableNation===undefined)return null
const linked=typeof opts?.linkedTeam==='function'?opts.linkedTeam:null
const manager=opts?.manager&&typeof opts.manager==='object'?opts.manager:null
const normalizeClub=(teamId)=>{if(!isId(teamId)||linked===null)return teamId
try{const told=linked(teamId)
return isId(told)?told:teamId}catch{return teamId}}
const clubAt=new Map()
const leagueAt=new Map()
const nationAt=new Map()
const numberOf=(map,id)=>{let at=map.get(id)
if(at===undefined){at=map.size
map.set(id,at)}
return at}
const factsFor=(card)=>{const alive=card!=null&&card?.valid!==false
const own=card?.possiblePositions
const fit=new Uint8Array(FIELD_PLAYERS)
if(Array.isArray(own))for(let at=0;at<FIELD_PLAYERS;at+=1){if(own.includes(positions[at]))fit[at]=1}
const legend=alive&&isLegend(card)
const top=alive&&(legend||isLeagueHero(card)||isSuperChem(card))
const give=alive?contributionsOf(card,{manager:false}):null
const club=alive?normalizeClub(clubOf(card)):undefined
const league=alive?leagueOf(card):undefined
const nation=alive?nationOf(card):undefined
return{fit,alive:alive?1:0,legend:legend?1:0,top:top?1:0,
club:alive&&isId(club)&&club!==LEGENDS_CLUB_ID&&club!==LEAGUE_HERO_CLUB_ID?numberOf(clubAt,club):-1,
league:alive&&isId(league)&&league!==LEGENDS_LEAGUE_ID?numberOf(leagueAt,league):-1,
nation:alive&&isId(nation)?numberOf(nationAt,nation):-1,
addClub:alive?give.club:0,addLeague:alive?give.league:0,addNation:alive?give.nation:0}}
const cards=new WeakMap()
const factsOf=(card)=>{if(card===null||typeof card!=='object')return factsFor(card)
let told=cards.get(card)
if(told===undefined){told=factsFor(card)
cards.set(card,told)}
return told}
const mGive=manager===null?null:contributionsOf(manager,{manager:true})
const mClub=manager===null?undefined:normalizeClub(clubOf(manager))
const mLeague=manager===null?undefined:leagueOf(manager)
const mNation=manager===null?undefined:nationOf(manager)
const mClubAt=manager!==null&&isId(mClub)&&mClub!==LEGENDS_CLUB_ID&&mClub!==LEAGUE_HERO_CLUB_ID?numberOf(clubAt,mClub):-1
const mLeagueAt=manager!==null&&isId(mLeague)&&mLeague!==LEGENDS_LEAGUE_ID?numberOf(leagueAt,mLeague):-1
const mNationAt=manager!==null&&isId(mNation)?numberOf(nationAt,mNation):-1
const mClubAdd=manager===null?0:mGive.club
const mLeagueAdd=manager===null?0:mGive.league
const mNationAdd=manager===null?0:mGive.nation
const grow=(arr,need)=>{if(need<arr.length)return arr
const next=new Int32Array(Math.max(need+1,arr.length*2))
next.set(arr)
return next}
const open=()=>{let cClub=new Int32Array(Math.max(8,clubAt.size))
let cLeague=new Int32Array(Math.max(8,leagueAt.size))
let cNation=new Int32Array(Math.max(8,nationAt.size))
const slotCard=new Array(FIELD_PLAYERS).fill(null)
const basePlayers=new Array(FIELD_PLAYERS).fill(null)
const slotLive=new Uint8Array(FIELD_PLAYERS)
const slotTop=new Uint8Array(FIELD_PLAYERS)
const slotClub=new Int32Array(FIELD_PLAYERS)
const slotLeague=new Int32Array(FIELD_PLAYERS)
const slotNation=new Int32Array(FIELD_PLAYERS)
const slotPoints=new Float64Array(FIELD_PLAYERS)
const moved=new Int32Array(FIELD_PLAYERS)
let legendsInPos=0
let trusted=true
let touched=0
const attach=(at,card)=>{const one=factsOf(card)
slotCard[at]=card
const live=one.alive===1&&one.fit[at]===1
slotLive[at]=live?1:0
slotTop[at]=live&&one.top===1?1:0
slotClub[at]=one.club
slotLeague[at]=one.league
slotNation[at]=one.nation
if(!live)return
if(one.club>=0&&one.addClub>0){cClub=grow(cClub,one.club)
cClub[one.club]+=one.addClub}
if(one.league>=0&&one.addLeague>0){cLeague=grow(cLeague,one.league)
cLeague[one.league]+=one.addLeague}
if(one.nation>=0&&one.addNation>0){cNation=grow(cNation,one.nation)
cNation[one.nation]+=one.addNation}
if(one.legend===1)legendsInPos+=1}
const detach=(at)=>{if(slotLive[at]===1){const one=factsOf(slotCard[at])
if(one.club>=0&&one.addClub>0)cClub[one.club]-=one.addClub
if(one.league>=0&&one.addLeague>0)cLeague[one.league]-=one.addLeague
if(one.nation>=0&&one.addNation>0)cNation[one.nation]-=one.addNation
if(one.legend===1)legendsInPos-=1
slotLive[at]=0}
slotCard[at]=null}
const rebase=(arranged)=>{for(let at=0;at<FIELD_PLAYERS;at+=1)detach(at)
cClub.fill(0)
cLeague.fill(0)
cNation.fill(0)
legendsInPos=0
for(let at=0;at<FIELD_PLAYERS;at+=1){const card=Array.isArray(arranged)?arranged[at]:null
basePlayers[at]=card
attach(at,card)}}
const score=(arranged)=>{touched=0
for(let at=0;at<FIELD_PLAYERS;at+=1){const card=arranged[at]
if(card===basePlayers[at])continue
moved[touched]=at
touched+=1
detach(at)
attach(at,card)}
let chemistry=0
for(let at=0;at<FIELD_PLAYERS;at+=1){if(slotLive[at]===0){slotPoints[at]=0
continue}
let raw=slotTop[at]===1?SLOT_MAX_CHEMISTRY:0
const club=slotClub[at]
if(club>=0)raw+=chemPointsBy(tableClub,cClub[club]+(club===mClubAt?mClubAdd:0))
const league=slotLeague[at]
if(league>=0){const live=cLeague[league]
raw+=chemPointsBy(tableLeague,live+(league===mLeagueAt?mLeagueAdd:0)+(live>0?legendsInPos:0))}
const nation=slotNation[at]
if(nation>=0)raw+=chemPointsBy(tableNation,cNation[nation]+(nation===mNationAt?mNationAdd:0))
const points=raw>SLOT_MAX_CHEMISTRY?SLOT_MAX_CHEMISTRY:raw
slotPoints[at]=points
chemistry+=points}
for(let k=0;k<touched;k+=1){const at=moved[k]
detach(at)
attach(at,basePlayers[at])}
return chemistry}
return{rebase,score,
points:slotPoints,
get touched(){return touched},
get trusted(){return trusted},
distrust(){trusted=false}}}
return{open}}
function qualityTierGate(requirements,operation){if(operation===OPERATION.OR)return null
const checks=[]
for(const req of Array.isArray(requirements)?requirements:[]){if(req?.key!==REQUIREMENT_KEY.PLAYER_QUALITY)continue
const need=needOf(req)
if(!isNum(need))continue
if(req.compare===COMPARE.GREATER)checks.push((tier)=>tier>=need)
else if(req.compare===COMPARE.LOWER)checks.push((tier)=>tier<=need)
else checks.push((tier)=>tier===need)}
if(checks.length===0)return null
return(tier)=>tier!==RATING_TIER.NONE&&checks.every((check)=>check(tier))}
const RARITY_GATE_KEYS=new Set([REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_RARITY_GROUP])
function rarityValuesOf(req){const list=Array.isArray(req?.values)&&req.values.length>0?req.values:[req?.value]
return list.filter(isNum)}
function virtualFamilyOf(player){if(player?.virtual!==true)return'real'
const id=String(player?.id??'')
if(id.startsWith('buy:r'))return'b13'
if(id.startsWith('buy:g'))return'b10'
if(/^buy:[lnc]\d/.test(id))return'b14'
return'base'}
function raritySays(player,family,group,values,dictionary){if(group){if(family==='b10'||family==='base'||family==='b14')return'no'
const own=player?.groups
if(Array.isArray(own))return own.some((one)=>values.includes(one))?'yes':'no'
if(family!=='real')return'no'
const known=dictionary===null?null:dictionary[rarityOf(player)]
if(!Array.isArray(known))return'unknown'
return known.some((one)=>isNum(one)&&values.includes(one))?'yes':'no'}
if(family==='base'||family==='b14')return'no'
const flag=family==='real'?rarityOf(player):player?.rareflag
if(!isNum(flag))return family==='real'?'unknown':'no'
return values.includes(flag)?'yes':'no'}
function rarityLegalityGate(requirements,operation,size,dictionary){const rarity=(Array.isArray(requirements)?requirements:[])
.filter((req)=>RARITY_GATE_KEYS.has(req?.key))
const covers=operation===OPERATION.OR?[]
:rarity.filter((req)=>(req.compare===COMPARE.GREATER||req.compare===COMPARE.EXACT)
&&req.count===size&&rarityValuesOf(req).length>0)
if(covers.length===0){const reason=rarity.length===0?'none'
:operation===OPERATION.OR?'or'
:rarity.some((req)=>req.compare===COMPARE.LOWER)?'lower':'partial'
return{covered:false,reason,verdict:null}}
const rules=covers.map((req)=>({group:req.key===REQUIREMENT_KEY.PLAYER_RARITY_GROUP,values:rarityValuesOf(req)}))
return{covered:true,reason:'active',verdict:(player,family)=>{let quiet=false
for(const rule of rules){const said=raritySays(player,family,rule.group,rule.values,dictionary)
if(said==='yes')return'keep'
if(said==='unknown')quiet=true}
return quiet?'unknown':'cut'}}}
export function solveSquad(input={}){const steps=solveSquadWithExact(input)
for(;;){const step=steps.next()
if(step.done)return unwrap(step.value)}}
function unwrap(result){if(result&&typeof result==='object'&&'__goal'in result)delete result.__goal
if(result&&typeof result==='object'&&'__exactIn'in result)delete result.__exactIn
return result}
export async function solveSquadPaced(input={},opts={}){const slice=isNum(opts.slice)&&opts.slice>0?Math.floor(opts.slice):500
const pause=typeof opts.pause==='function'?opts.pause:null
const base=typeof input.now==='function'?input.now:Date.now
let idle=0
const steps=solveSquadWithExact({...input,now:()=>base()-idle})
let taken=0
for(;;){const step=steps.next()
if(step.done)return unwrap(step.value)
taken+=1
if(pause&&taken%slice===0){const at=base()
await pause()
idle+=base()-at}}}
function virtualSegmentsOf(value){if(value===null||typeof value!=='object')return null
const rows=Array.isArray(value.segments)?value.segments:[{speed:value.speed}]
const out=[]
let from=0
for(const one of rows){const speed=one?.speed
if(!isNum(speed)||!(speed>0))return null
const until=isNum(one?.until)&&one.until>from?Math.floor(one.until):null
out.push({from,until,speed})
if(until===null)break
from=until}
if(out.length===0)return null
out[out.length-1].until=null
return out}
function virtualElapsedOf(segments,spent){let ms=0
for(const one of segments){const top=one.until===null?spent:Math.min(spent,one.until)
if(top>one.from)ms+=(top-one.from)/one.speed
if(one.until!==null&&spent<=one.until)break}
return ms}
function*solveSquadSteps(input={}){
const policy=sanitizeSbcPolicy(input.policy)
const protectedIds=Array.isArray(input.protectedIds)?input.protectedIds:[]
const club=Array.isArray(input.club)
?input.club.filter((item)=>isSbcAllowed(item,policy,protectedIds))
:[]
const size=isNum(input.size)&&input.size>0?Math.floor(input.size):11
const base=isNum(input.maxEvaluations)&&input.maxEvaluations>0
?Math.floor(input.maxEvaluations)
:MAX_EVALUATIONS
const fixed=sanitizeFixed(input.fixed,size)
const{requirements,skipped}=parseRequirements(input.requirements)
const operation=input.operation===OPERATION.OR?OPERATION.OR:OPERATION.AND
const market=input.mode==='club+market'&&input.market&&typeof input.market==='object'?input.market:null
const mb26Knob=(()=>{const raw=input.mb26
if(raw==='off')return{off:true,force:false,limit:MB26_VIEWED,unit:'admissible'}
if(raw&&typeof raw==='object')return{off:false,force:raw.force===true,
limit:isNum(raw.limit)&&raw.limit>0?Math.floor(raw.limit):MB26_VIEWED,
unit:raw.unit==='all'?'all':'admissible'}
return{off:false,force:false,limit:MB26_VIEWED,unit:'admissible'}})()
const mb26Area=(()=>{if(mb26Knob.off)return{area:false,reason:'off'}
if(skipped>0)return{area:false,reason:'skipped'}
if(requirements.some((req)=>Array.isArray(req?.combined)))return{area:false,reason:'combined'}
if(requirements.some((req)=>KEY_NAMES[req?.key]===undefined))return{area:false,reason:'unreadable'}
if(requirements.some((req)=>!isMeasurableRequirement(req)))return{area:false,reason:'unmeasurable'}
if(operation!==OPERATION.AND)return{area:false,reason:'operation'}
if(size!==11)return{area:false,reason:'size'}
const positions=input.formationPositions
if(!Array.isArray(positions)||positions.length!==size||!positions.every(isNum))return{area:false,reason:'positions'}
if(fixed===null||fixed.players.length>0)return{area:false,reason:'fixed'}
if(input.manager!==undefined&&input.manager!==null)return{area:false,reason:'manager'}
if(requirements.some((req)=>req?.key===REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS))return{area:false,reason:'all-player-chemistry'}
const chemistry=requirements.filter((req)=>req?.key===REQUIREMENT_KEY.CHEMISTRY_POINTS)
if(chemistry.length!==1||chemistry[0].compare!==COMPARE.GREATER)return{area:false,reason:'chemistry-shape'}
const sign=mb26FormSign(requirements)
const passport=MB26_PASSPORTS.find((one)=>one.sign===sign)
if(passport===undefined)return{area:false,reason:'passport'}
if(passport.mode!==(market===null?'club':'club+market'))return{area:false,reason:'mode'}
return{area:passport.area,reason:`allowed-${passport.area}`}})()
const mb26=input.__mb26&&typeof input.__mb26==='object'?input.__mb26:{rounds:0,viewedMax:0}
const chemOrderOf=()=>({area:mb26Area.area,reason:mb26Area.reason,rounds:mb26.rounds,viewedMax:mb26.viewedMax})
const mb26Live=!mb26Knob.off&&(mb26Area.area!==false||mb26Knob.force===true)
const mb26Limit=mb26Knob.limit
const mb26Unit=mb26Knob.unit
if(fixed===null){return{ok:false,reason:'invalid-fixed',squad:null,failed:[],evaluations:0,chemOrder:chemOrderOf()}}
const freeSize=size-fixed.players.length
if(skipped>0&&operation===OPERATION.AND){return{ok:false,reason:'unparsed-requirement',squad:null,failed:[],evaluations:0,chemOrder:chemOrderOf()}}
const unknown=requirements.filter((req)=>!isMeasurableRequirement(req))
if((operation===OPERATION.AND&&unknown.length>0)
||(operation===OPERATION.OR&&unknown.length===requirements.length)){return{ok:false,reason:'unknown-requirement',squad:null,failed:unknown.map((req)=>({...req,have:null})),evaluations:0,chemOrder:chemOrderOf()}}
const FLOOR_DEPTH=10
const depth=input.poolDepth==='full'?'full':input.poolDepth==='floored'?'floored':'auto'
const spentBefore=isNum(input.__spent)&&input.__spent>0?Math.floor(input.__spent):0
const widened=input.__widened===true
const poolFloor=(()=>{if(depth==='full'||operation===OPERATION.OR)return null
let need=null
for(const one of requirements){if(one?.key!==REQUIREMENT_KEY.TEAM_RATING)continue
if(one.compare===COMPARE.LOWER)continue
const value=needOf(one)
if(isNum(value)&&(need===null||value>need))need=value}
return need===null?null:need-FLOOR_DEPTH})()
const ratingUp=operation===OPERATION.AND&&requirements.some((one)=>one?.key===REQUIREMENT_KEY.TEAM_RATING
&&one.compare!==COMPARE.LOWER&&isNum(needOf(one)))
const THIN_SAFE=new Set([REQUIREMENT_KEY.TEAM_RATING,REQUIREMENT_KEY.PLAYER_COUNT,REQUIREMENT_KEY.PLAYER_QUALITY,REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_RARITY_GROUP,REQUIREMENT_KEY.PLAYER_MIN_OVR,REQUIREMENT_KEY.PLAYER_EXACT_OVR,REQUIREMENT_KEY.PLAYER_MAX_OVR])
const THIN_IDENTITY=new Set([...BUCKET_KEYS,REQUIREMENT_KEY.PLAYER_TRADABILITY])
const thinSafeOnly=requirements.every((one)=>THIN_SAFE.has(one?.key))
const thinWide=!thinSafeOnly&&requirements.every((one)=>Array.isArray(one?.combined)
?one.combined.every((entry)=>THIN_SAFE.has(entry?.key)||THIN_IDENTITY.has(entry?.key))
:THIN_SAFE.has(one?.key)||THIN_IDENTITY.has(one?.key))
const thinning=depth==='auto'&&poolFloor!==null&&(thinSafeOnly||thinWide)
const shape=thinning?'thinned':poolFloor!==null?'floored':'full'
const bucketKeep=Math.min(size,THIN_BUCKET_KEEP)
const exactNarrow=Array.isArray(input.__exact)&&input.__exact.length>0?input.__exact:null
const exactLinked=typeof input.linkedTeam==='function'?input.linkedTeam:undefined
const marketPrices=market===null?null
:exactNarrow===null?market.prices:exactMarketOf(market.prices,exactNarrow,exactLinked)
const pool=market?club.concat(virtualBuysFrom(marketPrices,{copies:size,requirements,linkedTeam:typeof input.linkedTeam==='function'?input.linkedTeam:undefined})):club
const RARITY_REQUIREMENT_KEYS=new Set([REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_RARITY_GROUP])
const simple=(()=>{if(skipped>0)return{ok:false,reason:'unparsed',rarity:null}
if(operation!==OPERATION.AND)return{ok:false,reason:'operation',rarity:null}
if(fixed.players.length>0)return{ok:false,reason:'fixed',rarity:null}
if(market!==null)return{ok:false,reason:'mode',rarity:null}
if(requirements.some((req)=>Array.isArray(req.combined)))return{ok:false,reason:'combined',rarity:null}
if(requirements.length!==2)return{ok:false,reason:'key',rarity:null}
if(requirements.some((req)=>!isMeasurableRequirement(req)))return{ok:false,reason:'key',rarity:null}
const rating=requirements.filter((req)=>req.key===REQUIREMENT_KEY.TEAM_RATING)
const rarity=requirements.filter((req)=>RARITY_REQUIREMENT_KEYS.has(req.key))
if(rating.length!==1||rarity.length!==1)return{ok:false,reason:'key',rarity:null}
if(rating[0].compare!==COMPARE.GREATER||rarity[0].compare!==COMPARE.GREATER)return{ok:false,reason:'need',rarity:null}
const ratingNeed=needOf(rating[0])
const rarityNeed=needOf(rarity[0])
if(!isNum(ratingNeed)||!isNum(rarityNeed))return{ok:false,reason:'need',rarity:null}
if(!(rarityNeed>=1&&rarityNeed<=size))return{ok:false,reason:'need',rarity:null}
const values=Array.isArray(rarity[0].values)?rarity[0].values:[]
if(values.length===0||!values.every(isNum))return{ok:false,reason:'need',rarity:null}
return{ok:true,reason:'allowed',rarity:rarity[0]}})()
const mb23Knob=input.mb23==='off'||input.mb23==='latch'||input.mb23==='phase'?input.mb23:'on'
const latchArea=simple.ok&&mb23Knob!=='off'&&mb23Knob!=='phase'
const phaseArea=simple.ok&&mb23Knob!=='off'&&mb23Knob!=='latch'
const mb23=input.__mb23&&typeof input.__mb23==='object'?input.__mb23:{
entryShown:null,fullBoundaries:0,wins:0,lastShown:null,armed:false,latchArmedAt:null,
postWinStoppedAt:null,boundaries:[],
phaseRounds:0,phaseCandidates:0,phaseAccepted:0,phaseFallback:0,rarityBefore:null}
const rarityDictionary=(()=>{const fromMarket=market?.prices?.rarityGroups
if(fromMarket&&typeof fromMarket==='object')return fromMarket
const fromValuation=input.valuation?.prices?.rarityGroups
return fromValuation&&typeof fromValuation==='object'?fromValuation:null})()
const rarityGate=rarityLegalityGate(requirements,operation,size,rarityDictionary)
const rarityCut={covered:rarityGate.covered,reason:rarityGate.reason,cut:0,kept:0,unknownKept:0,
keptBy:{real:0,base:0,b13:0,b10:0,b14:0},cutBy:{real:0,base:0,b13:0,b10:0,b14:0}}
const rarityMine=(player)=>{const id=player?.id??player?.itemId
return id!==undefined&&fixed.ids.has(id)}
const legal=rarityGate.covered===false
?(()=>{for(const player of pool){if(rarityMine(player))continue
rarityCut.kept+=1
rarityCut.keptBy[virtualFamilyOf(player)]+=1}
return pool})()
:pool.filter((player)=>{if(rarityMine(player))return true
const family=virtualFamilyOf(player)
const said=rarityGate.verdict(player,family)
if(said==='cut'){rarityCut.cut+=1
rarityCut.cutBy[family]+=1
return false}
rarityCut.kept+=1
rarityCut.keptBy[family]+=1
if(said==='unknown')rarityCut.unknownKept+=1
return true})
const allowsTier=qualityTierGate(requirements,operation)
const fieldAll=allowsTier===null?legal:legal.filter((player)=>allowsTier(tierOf(player)))
const field=exactNarrow===null?fieldAll
:fieldAll.filter((player)=>exactKeeps(player,exactNarrow,exactLinked))
const inherited=input.__budget&&typeof input.__budget==='object'?input.__budget:null
const roundsBudget=isNum(input.roundsBudget)&&input.roundsBudget>=0?input.roundsBudget:ROUNDS_BUDGET
const roundsFloor=Math.floor(roundsBudget*Math.max(1,size*field.length))
const budget=inherited??{base,rounds:roundsFloor,ceiling:Math.max(base,roundsFloor)}
let cap=inherited===null?budget.ceiling:base
let limit=cap
let startsLimit=cap
let capPanicAt=isNum(input.__panicAt)&&input.__panicAt>=0?input.__panicAt:null
let kicked=input.__kicked===true
let stage='starts'
let evaluations=0
const repairPanic=isNum(input.repairPanicShare)&&input.repairPanicShare>=0
?input.repairPanicShare:REPAIR_PANIC_SHARE
const virtualClock=virtualSegmentsOf(input.virtualClock)
const clockMode=input.disableTimeBudget===true?'disabled'
:virtualClock!==null?'virtual':'live'
const budgetMs=isNum(input.timeBudgetMs)&&input.timeBudgetMs>0?input.timeBudgetMs:TIME_BUDGET_MS
const clock=clockMode==='virtual'
?()=>virtualElapsedOf(virtualClock,spentBefore+evaluations+Math.floor((clockState.prunedFree??0)/PRUNE_WORK_DIVISOR))
:typeof input.now==='function'?input.now:Date.now
const clockState=input.__clock&&typeof input.__clock==='object'?input.__clock:{
budgetMs,startedAt:null,clockAt:null,forecast:null,stopped:false,
awake:false,wakeAt:null,spentAtWake:null,improvementsBooked:0,acceptedSwaps:0,roundsCut:0,pruned:0,prunedFree:0}
const startedAt=clockMode==='disabled'?null:clock()
if(!isNum(clockState.startedAt)&&isNum(startedAt))clockState.startedAt=startedAt
if(!isNum(clockState.budgetMs))clockState.budgetMs=budgetMs
const deadline=clockMode==='disabled'?null
:isNum(input.__deadline)?input.__deadline
:isNum(startedAt)?startedAt+budgetMs:null
let timeStopped=false
let clockAt=0
const sample=(at)=>{const elapsed=at-clockState.startedAt
const spent=spentBefore+evaluations
if(!isNum(elapsed)||!(elapsed>0)||!(spent>=TIME_CHECK_EVERY))return
const speed=spent/elapsed
if(!Number.isFinite(speed)||!(speed>0))return
const forecast=speed*clockState.budgetMs
clockState.forecast=forecast
clockState.clockAt=Math.max(0,Math.floor(repairPanic*Math.floor(CLOCK_LIMIT_SHARE*forecast)))
wakeIfDue()}
const outOfTime=(force)=>{if(timeStopped)return true
if(deadline===null)return false
if(force!==true&&evaluations-clockAt<TIME_CHECK_EVERY)return false
clockAt=evaluations
const at=clock()
if(!isNum(at))return false
sample(at)
if(at<deadline)return false
timeStopped=true
clockState.stopped=true
cap=0
limit=0
startsLimit=0
return true}
const budgetOf=()=>({...budget,timeStopped,pruned:clockState.pruned??0,prunedFree:clockState.prunedFree??0})
const panicNow=()=>{if(capPanicAt===null)return null
return isNum(clockState.clockAt)?Math.min(capPanicAt,clockState.clockAt):capPanicAt}
function wakeIfDue(){if(clockState.awake===true)return true
const at=panicNow()
if(at===null)return false
const spent=spentBefore+evaluations
if(!(spent>=at))return false
clockState.awake=true
clockState.wakeAt=at
clockState.spentAtWake=spent
return true}
const panicOf=()=>({awake:clockState.awake===true,wakeAt:clockState.wakeAt??null,currentAt:panicNow(),
spentAtWake:clockState.spentAtWake??null,improvementsBooked:clockState.improvementsBooked??0,
acceptedSwaps:clockState.acceptedSwaps??0,roundsCut:clockState.roundsCut??0,
forecast:isNum(clockState.forecast)?clockState.forecast:null})
if(inherited===null&&typeof input.onBudget==='function'){try{input.onBudget(budgetOf())}catch{
}}
let floorCut=0
let thinCut=0
const shapingOf=()=>({depth:shape,floor:poolFloor,floorCut,thinCut,keep:bucketKeep,wide:thinning?thinWide:null,...(widened?{widened:true}:{}),
rarityCut:{...rarityCut,keptBy:{...rarityCut.keptBy},cutBy:{...rarityCut.cutBy}}})
if(field.length<freeSize){return{ok:false,reason:'not-enough-players',squad:null,failed:[],evaluations:0,shaping:shapingOf(),budget:budgetOf(),panic:panicOf(),chemOrder:chemOrderOf()}}
const keyOfRaw=typeof input.footballerKeyOf==='function'?input.footballerKeyOf:null
const keyOf=keyOfRaw===null?null:(player)=>{try{const key=keyOfRaw(player)
return key===undefined||key===null?null:key}catch{return null}}
const fixedKeys=new Set()
if(keyOf!==null)for(const one of fixed.players){const key=keyOf(one)
if(key!==null)fixedKeys.add(key)}
const seen=new Set(fixed.ids)
const candidates=[]
const cachedPriceOf=typeof input.cachedPriceOf==='function'?input.cachedPriceOf:undefined
const valuation=input.valuation&&typeof input.valuation==='object'?input.valuation:null
const preferences=new Map(field.map((player)=>[player,valuation
?{untradeable:0,price:searchBurnOf(player,valuation.prices,{classes:valuation.classes,isDuplicate:valuation.isDuplicate,priceOf:cachedPriceOf,
futureRatings:valuation.futureRatings}),rarity:rarityWeightOf(player),rating:isNum(player?.rating)?player.rating:0}
:preferenceOf(player,{cachedPriceOf})]))
const ordered=field.slice().sort((a,b)=>compareKnownPreference(a,b,preferences.get(a),preferences.get(b),ratingUp))
const linkedTeam=typeof input.linkedTeam==='function'?input.linkedTeam:undefined
const bucketCount=thinning&&!thinWide?new Map():null
const bucketKeyOf=(player)=>{const club=linkedClubOf(player,linkedTeam)
return`${isNum(player?.rating)?player.rating:'x'}|${isNum(player?.rareflag)?player.rareflag:'x'}|${isNum(leagueOf(player))?leagueOf(player):'x'}|${isNum(nationOf(player))?nationOf(player):'x'}|${isNum(club)?club:'x'}|${tradabilityOf(player)==='untradeable'?1:0}`}
const wideBuckets=thinning&&thinWide?new Map():null
const passed=wideBuckets===null?null:[]
for(const player of ordered){const id=player.id??player.itemId
if(id!==undefined&&seen.has(id))continue
if(keyOf!==null&&fixedKeys.size>0){const key=keyOf(player)
if(key!==null&&fixedKeys.has(key))continue}
if(poolFloor!==null&&isNum(player?.rating)&&player.rating<poolFloor){floorCut+=1
continue}
if(bucketCount!==null){const bucket=`${isNum(player?.rating)?player.rating:'x'}|${isNum(player?.rareflag)?player.rareflag:'x'}`
const held=bucketCount.get(bucket)??0
if(held>=bucketKeep){thinCut+=1
continue}
bucketCount.set(bucket,held+1)}
if(wideBuckets!==null){const key=bucketKeyOf(player)
let held=wideBuckets.get(key)
if(held===undefined){held={spots:new Set(),firsts:[],extras:[]}
wideBuckets.set(key,held)}
const spot=Array.isArray(player?.possiblePositions)?player.possiblePositions[0]:'x'
if(!held.spots.has(spot)&&held.firsts.length<bucketKeep){held.spots.add(spot)
held.firsts.push(player)}
else if(held.extras.length<bucketKeep)held.extras.push(player)}
if(id!==undefined)seen.add(id)
if(passed===null)candidates.push(player)
else passed.push(player)}
if(passed!==null){const kept=new Set()
for(const held of wideBuckets.values()){for(const one of held.firsts.slice(0,bucketKeep))kept.add(one)
for(const one of held.extras.slice(0,Math.max(0,bucketKeep-held.firsts.length)))kept.add(one)}
for(const player of passed){if(kept.has(player))candidates.push(player)
else thinCut+=1}}
const printed=(result,how)=>{if(result&&typeof result==='object'&&result.shaping)result.shaping.kept=how
return result}
const betterOf=(narrow,wide)=>{const total=Math.max(isNum(narrow?.evaluations)?narrow.evaluations:0,isNum(wide?.evaluations)?wide.evaluations:0)
const stopped=narrow?.budget?.timeStopped===true||wide?.budget?.timeStopped===true
if(stopped)for(const one of[narrow,wide]){if(one?.budget&&typeof one.budget==='object')one.budget.timeStopped=true}
const keep=(one,how)=>{if(one&&typeof one==='object'&&isNum(one.evaluations)&&one.evaluations<total)one.evaluations=total
if(one&&typeof one==='object'&&one.panic&&typeof one.panic==='object')one.panic=panicOf()
if(one&&typeof one==='object'&&one.chemOrder&&typeof one.chemOrder==='object')one.chemOrder=chemOrderOf()
if(one&&typeof one==='object'&&one.ok!==true&&isNum(one.unmet)&&one.unmet>0&&clockState.stopped===true)one.unfinished=true
return printed(one,how)}
if(wide?.ok===true)return keep(wide,'widened')
if(narrow?.ok===true)return keep(narrow,'narrow')
const near=narrow?.__goal
const far=wide?.__goal
if(near===undefined||far===undefined)return keep(wide,'widened')
return closerToGoal(far,near)<0?keep(wide,'widened'):keep(narrow,'narrow')}
if(candidates.length<freeSize){if(shape!=='full'&&(floorCut>0||thinCut>0)){return printed(yield*solveSquadSteps({...input,poolDepth:shape==='thinned'?'floored':'full',maxEvaluations:cap,__budget:budget,__deadline:deadline,__spent:spentBefore,__widened:true,__panicAt:capPanicAt,__kicked:kicked,__clock:clockState,__mb26:mb26}),'widened')}
return{ok:false,reason:'not-enough-players',squad:null,failed:[],evaluations:spentBefore,shaping:shapingOf(),budget:budgetOf(),panic:panicOf(),chemOrder:chemOrderOf()}}
const keyCountsOf=(list)=>{const counts=new Map()
if(keyOf===null)return counts
for(const one of list){const key=keyOf(one)
if(key===null)continue
counts.set(key,(counts.get(key)??0)+1)}
return counts}
const keyConflict=(counts,inPlayer,outPlayer)=>{if(keyOf===null)return false
const key=keyOf(inPlayer)
if(key===null)return false
const held=counts.get(key)??0
return held-(keyOf(outPlayer)===key?1:0)>0}
const keySwap=(counts,inPlayer,outPlayer)=>{if(keyOf===null)return
const outKey=keyOf(outPlayer)
if(outKey!==null){const left=(counts.get(outKey)??0)-1
if(left>0)counts.set(outKey,left)
else counts.delete(outKey)}
const inKey=keyOf(inPlayer)
if(inKey!==null)counts.set(inKey,(counts.get(inKey)??0)+1)}
const tick=()=>{evaluations+=1
outOfTime(false)}
const PRUNE_CHECK_EVERY=TIME_CHECK_EVERY*PRUNE_WORK_DIVISOR
const pruneTick=(frees)=>{clockState.pruned=(clockState.pruned??0)+1
if(frees!==true)return
const now=(clockState.prunedFree??0)+1
clockState.prunedFree=now
if(now%PRUNE_CHECK_EVERY===0)outOfTime(true)}
const trace=input.trace===true?{starts:[],swaps:[],buys:[],phases:{},circles:[],rounds:[],cut:{swaps:0,buys:0,rounds:0},
before:spentBefore,panicAt:null,widened,
counter:{served:0,plan:[],lies:0},
chem:{served:false,trials:0,asked:0,touched:0,lies:0},
panic:{rounds:0,past:0,cut:0,blocked:0,byStage:{},after:{rounds:0,cut:0}}}:null
const tracing=trace!==null
const traceId=(player)=>(player?.virtual===true?String(player?.id??'buy'):String(player?.id??''))
const traceStep=(row)=>{if(trace.swaps.length<TRACE_STEPS)trace.swaps.push(row)
else trace.cut.swaps+=1}
const traceRound=(row)=>{const box=trace.panic
box.rounds+=1
if(row.panic)box.past+=1
if(row.cut)box.cut+=1
if(row.cut&&!row.phase)box.blocked+=1
const by=box.byStage[row.stage]??(box.byStage[row.stage]={rounds:0,past:0,cut:0})
by.rounds+=1
if(row.panic)by.past+=1
if(row.cut)by.cut+=1
if(row.after===true){box.after.rounds+=1
if(row.cut)box.after.cut+=1}
if(trace.rounds.length<TRACE_STEPS)trace.rounds.push(row)
else trace.cut.rounds+=1}
const traceBuy=(row)=>{if(trace.buys.length<TRACE_STEPS)trace.buys.push(row)
else trace.cut.buys+=1}
const floatRating=typeof input.floatRating==='boolean'?input.floatRating:null
const scoreOpts={linkedTeam,operation}
const measurable=operation===OPERATION.OR
?requirements.filter(isMeasurableRequirement)
:requirements
const makeSquad=typeof input.squadFactory==='function'?input.squadFactory:null
const judgeCounter=makeSquad!==null||input.__noCounter===true?null:makeJudgeCounter(measurable,scoreOpts)
if(tracing&&judgeCounter!==null){trace.counter.served=judgeCounter.served
trace.counter.plan=judgeCounter.plan}
const audit=input.__counterAudit!==null&&typeof input.__counterAudit==='object'?input.__counterAudit:null
const formationPositions=Array.isArray(input.formationPositions)?input.formationPositions:null
const freePositions=formationPositions===null?null:formationPositions.filter((unused,slot)=>!fixed.bySlot.has(slot))
const composeFull=(free)=>{if(fixed.players.length===0)return free
const full=[]
let next=0
for(let slot=0;slot<size;slot+=1){const pinned=fixed.bySlot.get(slot)
full.push(pinned===undefined?free[next++]:pinned)}
return full}
const arrangedFor=(free)=>fixed.players.length===0
?arrangeForFormation(free,formationPositions)
:composeFull(arrangeForFormation(free,freePositions))
const bricks=brickPlanOf(input.bricks,formationPositions)
const chemSquadOf=(arranged)=>{const base={players:arranged,rating:teamRating(arranged,floatRating)}
if(bricks!==null)return brickChemSquadOf(base,arranged)
const chem=squadChemistry({players:arranged,formationPositions,manager:input.manager,linkedTeam,thresholds:input.chemistryThresholds})
if(!chem.ok)return base
return{...base,chemistry:chem.chemistry,slots:chem.slots.map((slot)=>({chemistry:slot.points}))}}
const brickChemSquadOf=(base,arranged)=>{const chem=squadChemistry({players:bricks.fill(arranged),formationPositions:bricks.positions,manager:input.manager,linkedTeam,thresholds:input.chemistryThresholds})
if(!chem.ok)return base
const slots=[]
const brickSlots=[]
chem.slots.forEach((slot,at)=>(bricks.at.has(at)?brickSlots:slots).push({chemistry:slot.points}))
return{...base,chemistry:chem.chemistry,slots,brickSlots}}
const squadOf=(free)=>{
const players=fixed.players.length===0?free
:formationPositions===null?fixed.players.concat(free)
:arrangedFor(free)
if(makeSquad){try{const live=makeSquad(players)
if(live&&typeof live==='object') return live}catch{
}}
if(formationPositions===null)return{players,rating:teamRating(players,floatRating)}
return chemSquadOf(fixed.players.length===0?arrangedFor(free):players)}
const chemAsksSlots=requirements.some((req)=>req?.key===REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS
||(Array.isArray(req?.combined)&&req.combined.some((one)=>one?.key===REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS)))
const chemCounter=makeSquad!==null||formationPositions===null||chemAsksSlots
||size!==FIELD_PLAYERS||input.__noChemCounter===true
?null
:makeChemCounter(formationPositions,{manager:input.manager,linkedTeam,thresholds:input.chemistryThresholds})
if(tracing&&chemCounter!==null)trace.chem.served=true
const chemNeeds=chemCounter===null?[]:measurable
.filter((req)=>req?.key===REQUIREMENT_KEY.CHEMISTRY_POINTS)
.map((req)=>({compare:req.compare,need:needOf(req)}))
.filter((one)=>one.need!==null)
const chemTaken=(told)=>{for(const one of chemNeeds){if(satisfies(one.compare,told,one.need))return true}
return false}
const chemAudit=input.__chemAudit!==null&&typeof input.__chemAudit==='object'?input.__chemAudit:null
const repairExit=isNum(input.repairImprovements)&&input.repairImprovements>=0
?Math.floor(input.repairImprovements):REPAIR_IMPROVEMENTS
const panicPhase=input.repairPanicPhase==='A'||input.repairPanicPhase==='B'
?input.repairPanicPhase:REPAIR_PANIC_PHASE
const burnOf=(player)=>{const value=preferences.get(player)?.price
return isNum(value)?value:Number.POSITIVE_INFINITY}
const costDelta=(inCost,outCost)=>{if(inCost===outCost)return 0
if(!Number.isFinite(inCost))return Number.POSITIVE_INFINITY
if(!Number.isFinite(outCost))return Number.NEGATIVE_INFINITY
return inCost-outCost}
const shownCtx=valuation===null?null:{classes:valuation.classes,isDuplicate:valuation.isDuplicate,priceOf:cachedPriceOf,futureRatings:valuation.futureRatings}
const shownOf=(free)=>{if(shownCtx===null)return{cost:0,unknown:free.length}
let cost=0
let unknown=0
for(const player of free){let value=null
try{value=explainBurnOf(player,valuation.prices,shownCtx).cost}catch{value=null}
if(isNum(value))cost+=value
else unknown+=1}
return{cost,unknown}}
if(input.__finish!==null&&typeof input.__finish==='object'){const finishOut=(state,report={})=>({ok:false,reason:`finish-${state}`,squad:null,failed:[],
evaluations:spentBefore+evaluations,buys:[],spend:0,finish:{needEdge:true,...report,state},
shaping:shapingOf(),budget:budgetOf(),panic:panicOf(),chemOrder:chemOrderOf()})
if(fixed.players.length>0)return finishOut('fixed')
if(bricks!==null)return finishOut('bricks')
if(valuation===null||shownCtx===null)return finishOut('no-valuation')
const finishPrices=new Map()
const finishPriceOf=(player)=>{if(finishPrices.has(player))return finishPrices.get(player)
let value=preferences.get(player)?.price
if(!isNum(value)){try{value=searchBurnOf(player,valuation.prices,shownCtx)}catch{value=null}}
const price=isNum(value)&&value>=0?value:null
finishPrices.set(player,price)
return price}
const finishGuarded=(player)=>{if(player?.virtual===true)return false
let shown=null
try{shown=explainBurnOf(player,valuation.prices,shownCtx).cost}catch{shown=null}
return!isNum(shown)||finishPriceOf(player)>FINISH_GUARD*Math.max(shown,1)}
const finishField=[]
const finishIds=new Set()
for(const player of pool){const id=player?.id??player?.itemId
if(id!==undefined&&finishIds.has(String(id)))continue
if(id!==undefined)finishIds.add(String(id))
if(finishPriceOf(player)===null||finishGuarded(player))continue
finishField.push(player)}
const finishById=new Map(finishField.map((one)=>[String(one?.id??one?.itemId),one]))
const seedIds=Array.isArray(input.__finish.seed)?input.__finish.seed:null
let finishSeed=null
if(seedIds!==null&&seedIds.length===freeSize){const found=seedIds.map((one)=>{const known=finishById.get(String(one?.id??one?.itemId??one))
if(known!==undefined)return known
if(one?.virtual===true&&finishPriceOf(one)!==null){finishField.push(one)
finishById.set(String(one.id),one)
return one}
return undefined})
if(found.every((one)=>one!==undefined))finishSeed=found}
const finishRated=requirements.some((one)=>one?.key===REQUIREMENT_KEY.TEAM_RATING)
const finishJudge=!finishRated||(size===11&&freeSize===11)
?{size:freeSize,parsed:requirements,operation,positions:formationPositions,linkedTeam,float:floatRating}:null
const told=yield*finishSteps({pool:finishField,seed:finishSeed,size:freeSize,judge:finishJudge,priceOf:finishPriceOf,keyOf,
shortfall:(free)=>shortfallOf(squadOf(free),measurable,scoreOpts),
verdict:(free)=>{const orders=[free,free.slice().reverse()]
for(let r=1;r<free.length;r+=1)orders.push([...free.slice(r),...free.slice(0,r)])
let tries=0
for(const order of orders){tries+=1
if(checkSquad(squadOf(order),input.requirements,{linkedTeam,operation}).ok)return{order,tries}}
return{order:null,tries}},
tick,now:()=>clock(),deadline:isNum(deadline)?deadline:Infinity,stopped:()=>timeStopped,
...(input.__finish.laps&&typeof input.__finish.laps==='object'?{laps:input.__finish.laps}:{})})
const report={...told.report,evaluations,dropped:pool.length-finishField.length}
if(told.chosen===null)return finishOut(report.state,report)
const squad=squadOf(told.chosen)
const verdict=checkSquad(squad,input.requirements,{linkedTeam,operation})
const buys=squad.players.filter((p)=>p?.virtual===true)
const spend=buys.reduce((sum,p)=>sum+(isNum(p?.buyPrice)?p.buyPrice:0),0)
return{ok:verdict.ok,reason:verdict.ok?null:'finish-verdict',squad,failed:verdict.failed??[],evaluations:spentBefore+evaluations,buys,spend,
finish:report,shaping:shapingOf(),budget:budgetOf(),panic:panicOf(),chemOrder:chemOrderOf()}}
const trail=input.__trail===true?[]:null
const trailAt=(at)=>{if(trail===null)return
const free=winner?.chosen
if(!Array.isArray(free))return
const shown=shownOf(free.filter((player)=>player?.virtual!==true))
const spend=free.reduce((sum,player)=>sum+(player?.virtual===true&&isNum(player.buyPrice)?player.buyPrice:0),0)
const now=clockMode==='disabled'?null:clock()
trail.push({at,spent:spentBefore+evaluations,
ms:isNum(now)&&isNum(clockState.startedAt)?Math.round(now-clockState.startedAt):null,
best:winner?.best??null,burn:isNum(winner?.burn)?winner.burn:null,
shown:shown.unknown===0?shown.cost:null,spend,total:shown.unknown===0?shown.cost+spend:null})}
const rarityMember=new Map()
const countsRarity=(player)=>{let told=rarityMember.get(player)
if(told===undefined){told=measureRequirement({players:[player]},simple.rarity,scoreOpts)===1
rarityMember.set(player,told)}
return told}
const rarityShortOf=(free)=>{const have=measureRequirement(squadOf(free),simple.rarity,scoreOpts)
const need=needOf(simple.rarity)
if(have===undefined||need===null)return null
return satisfies(simple.rarity.compare,have,need)?0:Math.abs(need-have)}
const descend=function*(startChosen,startRest,mark,seeded,pulse=null,fromLegal=false){let chosen=startChosen
let rest=startRest
const spentAtStart=evaluations
const keyCounts=keyCountsOf(chosen)
const chemTally=chemCounter===null?null:chemCounter.open()
const tally=judgeCounter===null?null:judgeCounter.open()
if(tally!==null)tally.rebase(fixed.players,chosen)
if(chemTally!==null)chemTally.rebase(arrangedFor(chosen))
const trialSquadOf=(free)=>{if(chemTally===null||chemTally.trusted!==true)return squadOf(free)
const arranged=arrangedFor(free)
const told=chemTally.score(arranged)
if(tracing){trace.chem.trials+=1
trace.chem.touched+=chemTally.touched}
if(chemAudit!==null){const truth=chemSquadOf(arranged)
chemAudit.trials+=1
chemAudit.touched+=chemTally.touched
let same=truth.chemistry===told
if(same&&Array.isArray(truth.slots)){for(let at=0;at<truth.slots.length;at+=1){if(truth.slots[at]?.chemistry!==chemTally.points[at]){same=false
break}}}
if(!same){chemAudit.lies+=1
if(chemAudit.first===null)chemAudit.first={told,truth:truth.chemistry,at:evaluations}}
return truth}
if(!chemTaken(told))return{players:arranged,rating:teamRating(arranged,floatRating),chemistry:told}
if(tracing)trace.chem.asked+=1
const truth=chemSquadOf(arranged)
if(truth.chemistry!==told){chemTally.distrust()
if(tracing)trace.chem.lies+=1}
return truth}
const ratingGates=(free,target)=>{const players=fixed.players.length===0?free:fixed.players.concat(free)
const base=players.length-free.length
const row=new Array(free.length)
const memo=new Map()
let cuts=0
for(let s=0;s<free.length;s+=1){const out=free[s]?.rating
let told=memo.get(out)
if(told===undefined){told=ratingGateOf(players,base+s,target,floatRating)
memo.set(out,told)}
row[s]=told
if(told>0)cuts+=1}
return cuts>0?row:null}
const scoreOf=(trial,outCard,inCard)=>{const squad=trialSquadOf(trial)
if(tally===null||tally.trusted!==true)return shortfallOf(squad,measurable,scoreOpts)
const told=tally.score(outCard,inCard,squad)
if(audit!==null){audit.trials+=1
const checked=shortfallOf(squad,measurable,scoreOpts)
if(checked!==told){audit.lies+=1
if(audit.first===null)audit.first={told,truth:checked,at:evaluations}}
return checked}
if(told!==0)return told
const truth=shortfallOf(squad,measurable,scoreOpts)
if(truth!==0){tally.distrust()
if(tracing)trace.counter.lies+=1}
return truth}
let mb26Score=null
let mb26Fit=null
const mb26PairsOf=()=>{const width=rest.length
const slots=chosen.length
if(width===0||slots===0)return[]
const span=slots*width
if(mb26Score===null||mb26Score.length<span){mb26Score=new Int32Array(span)
mb26Fit=new Uint8Array(span)}
const clubs=new Map()
const leagues=new Map()
const nations=new Map()
const outClub=[]
const outLeague=[]
const outNation=[]
for(const player of chosen){const club=linkedClubOf(player,linkedTeam)
const league=leagueOf(player)
const nation=nationOf(player)
outClub.push(club)
outLeague.push(league)
outNation.push(nation)
clubs.set(club,(clubs.get(club)??0)+1)
leagues.set(league,(leagues.get(league)??0)+1)
nations.set(nation,(nations.get(nation)??0)+1)}
const outClubAt=outClub.map((one)=>clubs.get(one)??0)
const outLeagueAt=outLeague.map((one)=>leagues.get(one)??0)
const outNationAt=outNation.map((one)=>nations.get(one)??0)
const inClub=[]
const inLeague=[]
const inNation=[]
const inClubAt=[]
const inLeagueAt=[]
const inNationAt=[]
for(const player of rest){const club=linkedClubOf(player,linkedTeam)
const league=leagueOf(player)
const nation=nationOf(player)
inClub.push(club)
inLeague.push(league)
inNation.push(nation)
inClubAt.push(clubs.get(club)??0)
inLeagueAt.push(leagues.get(league)??0)
inNationAt.push(nations.get(nation)??0)}
const census=new Map()
for(let i=0;i<slots;i+=1){const base=i*width
for(let j=0;j<width;j+=1){const at=base+j
const fit=mb26Unit==='all'||!keyConflict(keyCounts,rest[j],chosen[i])
mb26Fit[at]=fit?1:0
if(!fit)continue
const score=mb26Delta(inClub[j],outClub[i],inClubAt[j],outClubAt[i])
+mb26Delta(inLeague[j],outLeague[i],inLeagueAt[j],outLeagueAt[i])
+mb26Delta(inNation[j],outNation[i],inNationAt[j],outNationAt[i])
mb26Score[at]=score
census.set(score,(census.get(score)??0)+1)}}
let left=mb26Limit
let edge=null
for(const score of[...census.keys()].sort((one,two)=>two-one)){if(left<=0)break
edge=score
left-=census.get(score)}
if(edge===null)return[]
let quota=census.get(edge)+(left<0?left:0)
const picked=[]
for(let at=0;at<span;at+=1){if(mb26Fit[at]===0)continue
const score=mb26Score[at]
if(score<edge)continue
if(score===edge){if(quota<=0)continue
quota-=1}
picked.push(at)}
picked.sort((one,two)=>mb26Score[two]-mb26Score[one]||one-two)
return picked}
const beat=pulse===null?null:(now,at)=>{pulse.chosen=now
pulse.rest=at
pulse.best=best
pulse.swaps+=1}
let best=seeded===undefined?shortfallOf(squadOf(chosen),measurable,scoreOpts):seeded
if(seeded===undefined){tick()
yield}
let everLegal=fromLegal===true||best===0
for(let round=0;round<MAX_ROUNDS&&best>0&&evaluations<limit;round+=1){let bestSwap=null
let better=0
let viewed=0
const watch=tracing?[]:null
const roundAt=evaluations
const gate=ratingBound?ratingGates(chosen,ratingFloor-best+1):null
const panic=wakeIfDue()
const phaseOk=panicPhase==='B'?stage==='starts':kicked===false
const cutAt=everLegal===false&&panic&&phaseOk?repairExit:0
let cut=false
let paid=null
const sweep=function*(phase,order){const width=rest.length
const span=order===null?chosen.length*width:order.length
let i=0
let j=-1
let gi=gate===null?0:gate[0]
for(let at=0;at<span&&evaluations<limit&&!cut;at+=1){if(order===null){j+=1
if(j>=width){j=0
i+=1
gi=gate===null?0:gate[i]}}
else{const code=order[at]
i=Math.floor(code/width)
j=code-i*width
gi=gate===null?0:gate[i]}
if(keyConflict(keyCounts,rest[j],chosen[i])){if(tracing&&rest[j]?.virtual===true)traceBuy({at:mark,phase:'fix',buy:traceId(rest[j]),out:traceId(chosen[i]),why:'copy'})
continue}
if(phase===true){
if(!countsRarity(rest[j])||countsRarity(chosen[i]))continue
paid.add(i*rest.length+j)}
else if(paid!==null&&paid.has(i*rest.length+j))continue
const cutHere=(rest[j]?.rating??0)<gi
if(cutHere&&ratingBoundFrees){pruneTick(true)
continue}
viewed+=1
if(cutHere){pruneTick(false)
tick()
yield
continue}
const trial=chosen.slice()
trial[i]=rest[j]
const score=scoreOf(trial,chosen[i],rest[j])
tick()
yield
if(score>=best){if(tracing&&rest[j]?.virtual===true)traceBuy({at:mark,phase:'fix',buy:traceId(rest[j]),out:traceId(chosen[i]),why:'no-gain',score,best})
continue}
better+=1
const delta=costDelta(burnOf(rest[j]),burnOf(chosen[i]))
const perPoint=delta/(best-score)
const swap={i,j,score,perPoint,at:better}
if(watch!==null&&watch.length<REPAIR_WATCH)watch.push({at:better,i,score,per:perPoint,delta,spent:evaluations-roundAt})
if(betterRepairSwap(swap,bestSwap))bestSwap=swap
if(cutAt>0&&phase!==true&&better>=cutAt)cut=true}}
if(phaseArea){const short=rarityShortOf(chosen)
if(mb23.rarityBefore===null&&short!==null)mb23.rarityBefore=short
if(isNum(short)&&short>0){mb23.phaseRounds+=1
paid=new Set()
const phaseAt=evaluations
yield*sweep(true,null)
mb23.phaseCandidates+=evaluations-phaseAt
if(bestSwap!==null)mb23.phaseAccepted+=1
else mb23.phaseFallback+=1}}
if(bestSwap===null&&!cut){const order=mb26Live?mb26PairsOf():null
if(order!==null)mb26.rounds+=1
yield*sweep(false,order)}
if(mb26Live&&viewed>mb26.viewedMax)mb26.viewedMax=viewed
if(cutAt>0){clockState.improvementsBooked=(clockState.improvementsBooked??0)+better
if(bestSwap!==null)clockState.acceptedSwaps=(clockState.acceptedSwaps??0)+1
if(cut)clockState.roundsCut=(clockState.roundsCut??0)+1}
if(tracing)traceRound({at:mark,round,gated:everLegal===false,panic,phase:phaseOk,stage,after:kicked,cut,improvements:better,first:watch,from:roundAt,spent:evaluations-roundAt,
taken:bestSwap===null?null:{at:bestSwap.at,i:bestSwap.i,score:bestSwap.score,per:bestSwap.perPoint,
delta:costDelta(burnOf(rest[bestSwap.j]),burnOf(chosen[bestSwap.i]))}})
if(bestSwap===null) break;// Улучшать больше нечем.
const out=chosen[bestSwap.i]
if(tracing)traceStep({at:mark,phase:'fix',round,out:traceId(out),in:traceId(rest[bestSwap.j]),score:bestSwap.score,was:best,per:bestSwap.perPoint})
keySwap(keyCounts,rest[bestSwap.j],out)
chosen=chosen.slice()
chosen[bestSwap.i]=rest[bestSwap.j]
rest=rest.slice()
rest[bestSwap.j]=out
if(tally!==null)tally.rebase(fixed.players,chosen)
if(chemTally!==null)chemTally.rebase(arrangedFor(chosen))
best=bestSwap.score
if(best===0)everLegal=true
if(beat!==null)beat(chosen,rest)}
for(let round=0;round<MAX_ROUNDS&&best===0&&evaluations<limit;round+=1){let bestSwap=null
const gate=ratingBound?ratingGates(chosen,ratingFloor):null
for(let i=0;i<chosen.length&&evaluations<limit;i+=1){const outCost=burnOf(chosen[i])
const outTrad=preferences.get(chosen[i])?.untradeable??1
const outRating=isNum(chosen[i]?.rating)?chosen[i].rating:0
const gi=gate===null?0:gate[i]
for(let j=0;j<rest.length&&evaluations<limit;j+=1){
if((preferences.get(rest[j])?.untradeable??1)>outTrad){if(tracing&&rest[j]?.virtual===true)traceBuy({at:mark,phase:'cheap',buy:traceId(rest[j]),out:traceId(chosen[i]),why:'trade-order'})
continue}
const saving=costDelta(burnOf(rest[j]),outCost)
if(!(saving<0)){if(tracing&&rest[j]?.virtual===true)traceBuy({at:mark,phase:'cheap',buy:traceId(rest[j]),out:traceId(chosen[i]),why:'not-cheaper',cost:burnOf(rest[j]),outCost})
continue}
if(rest[j]?.virtual===true&&tradabilityOf(chosen[i])==='untradeable'
&&!(outCost>=burnOf(rest[j])*SELL_SWAP_ADVANTAGE)){if(tracing)traceBuy({at:mark,phase:'cheap',buy:traceId(rest[j]),out:traceId(chosen[i]),why:'club-first',cost:burnOf(rest[j]),outCost})
continue}
if(keyConflict(keyCounts,rest[j],chosen[i])){if(tracing&&rest[j]?.virtual===true)traceBuy({at:mark,phase:'cheap',buy:traceId(rest[j]),out:traceId(chosen[i]),why:'copy'})
continue}
if((rest[j]?.rating??0)<gi){if(ratingBoundFrees)pruneTick(true)
else{pruneTick(false)
tick()
yield}
continue}
const trial=chosen.slice()
trial[i]=rest[j]
const score=scoreOf(trial,chosen[i],rest[j])
tick()
yield
if(score!==0){if(tracing&&rest[j]?.virtual===true)traceBuy({at:mark,phase:'cheap',buy:traceId(rest[j]),out:traceId(chosen[i]),why:'breaks',score})
continue}
const inRating=isNum(rest[j]?.rating)?rest[j].rating:0
const spent=ratingFloor===null?0:Math.max(0,outRating-inRating)
const perPoint=spent===0?Number.NEGATIVE_INFINITY:saving/spent
if(bestSwap===null||perPoint<bestSwap.perPoint
||(perPoint===bestSwap.perPoint&&saving<bestSwap.saving)){bestSwap={i,j,saving,perPoint}}}}
if(bestSwap===null) break;// Дешевле уже не становится.
const out=chosen[bestSwap.i]
if(tracing)traceStep({at:mark,phase:'cheap',round,out:traceId(out),in:traceId(rest[bestSwap.j]),saving:bestSwap.saving,per:bestSwap.perPoint})
keySwap(keyCounts,rest[bestSwap.j],out)
chosen=chosen.slice()
chosen[bestSwap.i]=rest[bestSwap.j]
rest=rest.slice()
rest[bestSwap.j]=out
if(tally!==null)tally.rebase(fixed.players,chosen)
if(chemTally!==null)chemTally.rebase(arrangedFor(chosen))
if(beat!==null)beat(chosen,rest)}
const told=outcomeOf(chosen,best)
if(tracing)trace.starts.push({at:mark,best,burn:told.burn,spend:told.spend,unmet:told.unmet,lack:told.lack,evaluations:evaluations-spentAtStart,ids:chosen.map(traceId)})
return{chosen,rest,...told}}
function outcomeOf(chosen,best){const burn=chosen.reduce((sum,player)=>sum+burnOf(player),0)
const spend=chosen.reduce((sum,player)=>sum+(player?.virtual===true&&isNum(player.buyPrice)?player.buyPrice:0),0)
let unmet=0
let lack=0
if(best>0){const finalSquad=squadOf(chosen)
for(const req of measurable){const have=measureRequirement(finalSquad,req,scoreOpts)
const need=needOf(req)
if(have===undefined||need===null||!satisfies(req.compare,have,need)){unmet+=1
if(isNum(have)&&isNum(need)){const gap=req.compare===COMPARE.LOWER?have-need:Math.abs(need-have)
lack+=Math.min(1,Math.max(0,gap/Math.max(need,1)))}
else lack+=1}}}
return{best,burn,spend,unmet,lack}}
const closerToGoal=(a,b)=>{const fa=a.best===0
const fb=b.best===0
if(fa!==fb)return fa?-1:1
if(fa)return a.burn<b.burn?-1:a.burn>b.burn?1:0
if(a.unmet!==b.unmet)return a.unmet-b.unmet
if(a.lack!==b.lack)return a.lack-b.lack
if(a.best!==b.best)return a.best-b.best
return a.burn<b.burn?-1:a.burn>b.burn?1:0}
const ratingFloor=(()=>{let floor=null
for(const r of measurable){if(r?.key!==REQUIREMENT_KEY.TEAM_RATING)continue
if(r.compare===COMPARE.LOWER)continue
const need=needOf(r)
if(isNum(need)&&(floor===null||need>floor))floor=need}
return floor})()
const ratingBound=input.__noRatingBound!==true&&ratingFloor!==null
&&operation===OPERATION.AND&&makeSquad===null
const ratingBoundFrees=input.__ratingBoundFrees===true
const starts=[]
let seedTag='all'
const addStart=(chosen,kind)=>{if(chosen.length<freeSize)return
const key=chosen.map((player)=>String(player?.id??'')).join('|')
if(starts.some((start)=>start.key===key))return
const taken=new Set(chosen)
starts.push({key,chosen,rest:candidates.filter((player)=>!taken.has(player)),kind:tracing?`${seedTag}:${kind??'plain'}`:null})}
const takeUnique=(source,count)=>{if(keyOf===null)return source.slice(0,count)
const taken=[]
const used=new Set()
for(const one of source){const key=keyOf(one)
if(key!==null){if(used.has(key))continue
used.add(key)}
taken.push(one)
if(taken.length>=count)break}
return taken}
const IDENTITY_KEYS=new Set([REQUIREMENT_KEY.NATION_ID,REQUIREMENT_KEY.LEAGUE_ID,REQUIREMENT_KEY.CLUB_ID])
const identityReqs=measurable.filter((r)=>{if(r?.compare===COMPARE.LOWER)return false
const need=needOf(r)
if(!isNum(need)||need<2)return false
if(Array.isArray(r?.combined))return r.combined.some((entry)=>IDENTITY_KEYS.has(entry?.key))
return IDENTITY_KEYS.has(r?.key)})
const identityValuesOf=(r)=>{if(Array.isArray(r?.values)&&r.values.length>0)return r.values.filter(isNum)
return isNum(r?.value)?[r.value]:[]}
const staticMatch=(player,entry)=>{const value=entry?.value
switch(entry?.key){case REQUIREMENT_KEY.NATION_ID:return nationOf(player)===value
case REQUIREMENT_KEY.LEAGUE_ID:return leagueOf(player)===value
case REQUIREMENT_KEY.CLUB_ID:return linkedClubOf(player,linkedTeam)===value
case REQUIREMENT_KEY.PLAYER_MIN_OVR:return isNum(player?.rating)&&player.rating>=value
case REQUIREMENT_KEY.PLAYER_MAX_OVR:return isNum(player?.rating)&&player.rating<=value
case REQUIREMENT_KEY.PLAYER_EXACT_OVR:return player?.rating===value
case REQUIREMENT_KEY.PLAYER_TRADABILITY:return tradabilityOf(player)===(value===0?'tradeable':'untradeable')
default:return false}}
const identityMatch=(player,r)=>{if(Array.isArray(r?.combined)){for(const entry of r.combined){if(entry?.key===REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS)continue
if(!staticMatch(player,entry))return false}
return true}
const values=identityValuesOf(r)
if(values.length===0)return false
switch(r.key){case REQUIREMENT_KEY.NATION_ID:return values.includes(nationOf(player))
case REQUIREMENT_KEY.LEAGUE_ID:return values.includes(leagueOf(player))
default:{const club=linkedClubOf(player,linkedTeam)
return values.some((value)=>club===value||club===linkedClubOf({teamId:value},linkedTeam))}}}
const COUNT_FORM_KEYS=new Set([REQUIREMENT_KEY.PLAYER_LEVEL,REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_RARITY_GROUP])
const formValuesOf=(one)=>{if(Array.isArray(one?.values)&&one.values.length>0)return one.values.filter(isNum)
return isNum(one?.value)?[one.value]:[]}
const formMatch=(player,entry)=>{const values=formValuesOf(entry)
switch(entry?.key){case REQUIREMENT_KEY.PLAYER_LEVEL:return values.includes(tierOf(player))
case REQUIREMENT_KEY.PLAYER_RARITY:return values.includes(rarityOf(player))
case REQUIREMENT_KEY.PLAYER_RARITY_GROUP:return values.some((value)=>groupsOf(player).includes(value))
default:return staticMatch(player,entry)}}
const formsWhere=(allow)=>{const out=[]
for(const r of measurable){if(!allow(r?.compare))continue
const need=needOf(r)
if(!isNum(need)||need<0)continue
const combined=Array.isArray(r?.combined)
?r.combined.filter((entry)=>entry?.key!==REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS)
:null
if(combined===null?!COUNT_FORM_KEYS.has(r?.key):!combined.some((entry)=>COUNT_FORM_KEYS.has(entry?.key)))continue
const entries=combined===null?[r]:combined
out.push({need,name:tracing?`${r?.name??r?.key}=${formValuesOf(combined===null?r:combined[0]).join('/')}`:'form',match:(player)=>entries.every((entry)=>formMatch(player,entry))})}
return out}
const countForms=formsWhere((compare)=>compare===COMPARE.GREATER||compare===COMPARE.EXACT).filter((form)=>form.need>=1)
const formCaps=formsWhere((compare)=>compare===COMPARE.LOWER||compare===COMPARE.EXACT)
const held=(form)=>(fixed.players.length===0?0:fixed.players.filter((one)=>form.match(one)).length)
const formNeed=(form)=>form.need-held(form)
const capRoom=()=>formCaps.map((form)=>form.need-held(form))
const capFits=(one,room)=>{for(let i=0;i<formCaps.length;i+=1)if(formCaps[i].match(one)&&room[i]<1)return false
return true}
const capTake=(one,room)=>{for(let i=0;i<formCaps.length;i+=1)if(formCaps[i].match(one))room[i]-=1}
const takeForms=(pool,count,closed)=>{const taken=[]
const used=new Set()
const chosen=new Set()
const left=countForms.map((form)=>({form,left:formNeed(form)}))
const room=capRoom()
const hold=(one)=>{const key=keyOf===null?null:keyOf(one)
if(key!==null){if(used.has(key))return false
used.add(key)}
capTake(one,room)
taken.push(one)
chosen.add(one)
return true}
while(taken.length<count){let best=null
for(const one of pool){if(chosen.has(one))continue
const key=keyOf===null?null:keyOf(one)
if(key!==null&&used.has(key))continue
if(!capFits(one,room))continue
let gain=0
for(const row of left)if(row.left>0&&row.form.match(one))gain+=1
if(gain===0)continue
const price=burnOf(one)
if(best===null||price<best.price||(price===best.price&&gain>best.gain))best={one,gain,price}}
if(best===null)break
if(!hold(best.one))break
for(const row of left)if(row.left>0&&row.form.match(best.one)){row.left-=1
if(closed!==null)closed.push(`${row.form.name}←${traceId(best.one)}`)}}
for(const one of pool){if(taken.length>=count)break
if(chosen.has(one))continue
if(!capFits(one,room))continue
hold(one)}
return taken}
const plant=(seed,source,kind)=>{if(seed.length===0)return false
const taken=new Set(seed)
const usedKeys=new Set()
if(keyOf!==null)for(const one of seed){const key=keyOf(one)
if(key!==null)usedKeys.add(key)}
const room=capRoom()
for(const one of seed)capTake(one,room)
const filled=seed.slice()
for(const one of source){if(filled.length>=freeSize)break
if(taken.has(one))continue
const key=keyOf===null?null:keyOf(one)
if(key!==null&&usedKeys.has(key))continue
if(!capFits(one,room))continue
capTake(one,room)
filled.push(one)
if(key!==null)usedKeys.add(key)}
const before=starts.length
addStart(filled,kind)
return starts.length>before}
const seedIdentity=(source,r)=>{const already=fixed.players.length===0?0
:fixed.players.filter((one)=>identityMatch(one,r)).length
const wanted=Math.min(needOf(r)-already,freeSize)
if(wanted<1)return
const closed=tracing?[]:null
const seed=takeForms(source.filter((player)=>identityMatch(player,r)),wanted,closed)
if(plant(seed,source,tracing?`identity:${r?.name??r?.key}=${identityValuesOf(r).join('/')}x${wanted}`:'identity')
&&closed!==null&&closed.length>0)starts[starts.length-1].cover=closed}
const takeCovering=(source,count)=>{if(freePositions===null)return takeUnique(source,count)
const need=new Map()
for(const position of freePositions)need.set(position,(need.get(position)??0)+1)
const taken=[]
const chosen=new Set()
const used=new Set()
const hold=(one)=>{const key=keyOf===null?null:keyOf(one)
if(key!==null){if(used.has(key))return false
used.add(key)}
taken.push(one)
chosen.add(one)
return true}
for(const one of source){if(taken.length>=count)break
const spots=Array.isArray(one?.possiblePositions)?one.possiblePositions:[]
let hit=null
for(const spot of spots)if((need.get(spot)??0)>0){hit=spot
break}
if(hit===null)continue
if(hold(one))need.set(hit,need.get(hit)-1)}
for(const one of source){if(taken.length>=count)break
if(!chosen.has(one))hold(one)}
return taken}
const clusters={leagues:new Set(),nations:new Set(),clubs:new Set(),seeded:0}
const chemistryReq=measurable.some((r)=>(r?.key===REQUIREMENT_KEY.CHEMISTRY_POINTS||r?.key===REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS)&&r.compare!==COMPARE.LOWER)
const SEED_DIMS=[{read:leagueOf,plan:'leagues',same:REQUIREMENT_KEY.SAME_LEAGUE_COUNT,count:REQUIREMENT_KEY.LEAGUE_COUNT,rank:8,least:5,take:null},{read:nationOf,plan:'nations',same:REQUIREMENT_KEY.SAME_NATION_COUNT,count:REQUIREMENT_KEY.NATION_COUNT,rank:8,least:5,take:null},{read:(player)=>linkedClubOf(player,linkedTeam),plan:'clubs',same:REQUIREMENT_KEY.SAME_CLUB_COUNT,count:REQUIREMENT_KEY.CLUB_COUNT,rank:4,least:4,take:7}]
const seedNeed=(key,min)=>topNeed(measurable,key,min)
const squeezeNeed=(key)=>{let best=null
for(const req of measurable){if(req?.key!==key||req.compare!==COMPARE.LOWER)continue
const need=needOf(req)
if(isNum(need)&&need>=1&&(best===null||need<best))best=need}
return best}
const clusterTried=chemistryReq||SEED_DIMS.some((dim)=>seedNeed(dim.same,2)!==null||seedNeed(dim.count,2)!==null||squeezeNeed(dim.count)!==null)
const byValue=(source,read)=>{const by=new Map()
for(const one of source){const value=read(one)
if(!isNum(value))continue
const list=by.get(value)
if(list===undefined)by.set(value,[one])
else list.push(one)}
return by}
const rankValues=(groups,size,least,limit=SEED_CLUSTERS)=>{const scored=[]
for(const[value,list]of groups){if(list.length<least)continue
const costs=list.map(burnOf).sort((a,b)=>a<b?-1:a>b?1:0)
let sum=0
for(let i=0;i<Math.min(size,costs.length);i+=1)sum+=costs[i]
scored.push({value,sum})}
scored.sort((a,b)=>a.sum!==b.sum?(a.sum<b.sum?-1:1):a.value-b.value)
return scored.slice(0,limit).map((one)=>one.value)}
const clusterSeeds=(source)=>{for(const dim of SEED_DIMS){const groups=byValue(source,dim.read)
const same=seedNeed(dim.same,2)
if(same!==null)for(const value of rankValues(groups,same,same)){clusters[dim.plan].add(value)
const already=fixed.players.filter((one)=>dim.read(one)===value).length
const wanted=Math.min(same-already,freeSize)
if(wanted<1)continue
if(plant(takeCovering(groups.get(value),wanted),source,tracing?`same:${dim.plan}=${value}x${wanted}`:'same'))clusters.seeded+=1}
const spread=seedNeed(dim.count,2)
if(spread!==null){const held=new Set()
for(const one of fixed.players){const value=dim.read(one)
if(isNum(value))held.add(value)}
const wanted=spread-held.size
const seed=[]
const usedKeys=new Set()
for(const one of source){if(seed.length>=wanted)break
const value=dim.read(one)
if(!isNum(value)||held.has(value))continue
const key=keyOf===null?null:keyOf(one)
if(key!==null&&usedKeys.has(key))continue
held.add(value)
if(key!==null)usedKeys.add(key)
clusters[dim.plan].add(value)
seed.push(one)}
if(plant(seed,source,tracing?`spread:${dim.plan}x${seed.length}`:'spread'))clusters.seeded+=1}
if(chemistryReq)for(const value of rankValues(groups,Math.min(freeSize,dim.rank),dim.least)){clusters[dim.plan].add(value)
if(plant(takeCovering(groups.get(value),dim.take===null?freeSize:Math.min(freeSize,dim.take)),source,tracing?`chem:${dim.plan}=${value}`:'chem'))clusters.seeded+=1}
const squeeze=squeezeNeed(dim.count)
if(squeeze!==null){const held=new Set()
for(const one of fixed.players){const value=dim.read(one)
if(isNum(value))held.add(value)}
const picked=new Set(held)
for(const value of rankValues(groups,Math.min(freeSize,dim.rank),dim.least,Math.max(1,squeeze-held.size))){picked.add(value)
clusters[dim.plan].add(value)}
if(picked.size>0&&picked.size<=squeeze){const narrow=source.filter((one)=>picked.has(dim.read(one)))
if(narrow.length>=freeSize)if(plant(takeCovering(narrow,freeSize),source,tracing?`squeeze:${dim.plan}x${picked.size}`:'squeeze'))clusters.seeded+=1}}}}
const seedForms=(source)=>{if(countForms.length===0)return
if(countForms.every((form)=>formNeed(form)<1))return
const closed=tracing?[]:null
if(plant(takeForms(source,freeSize,closed),source,tracing?`forms:${countForms.map((form)=>form.name).join('+')}`:'forms')
&&closed!==null&&closed.length>0)starts[starts.length-1].cover=closed}
const seedFrom=(source,tag)=>{seedTag=tag
for(const r of identityReqs)seedIdentity(source,r)
if(clusterTried)clusterSeeds(source)
seedForms(source)
if(ratingFloor!==null){const tall=source.filter((player)=>isNum(player?.rating)&&player.rating>=ratingFloor)
if(tall.length>=freeSize&&tall.length<source.length)addStart(takeUnique(tall,freeSize),'even')}
addStart(takeUnique(source,freeSize),'wide')}
const clustersOf=()=>({leagues:[...clusters.leagues].sort((a,b)=>a-b),nations:[...clusters.nations].sort((a,b)=>a-b),clubs:[...clusters.clubs].sort((a,b)=>a-b),seeded:clusters.seeded})
const heirOf=(list)=>{if(!Array.isArray(list)||list.length!==freeSize)return null
const byId=new Map()
for(const one of candidates){const id=one?.id??one?.itemId
if(id!==undefined&&!byId.has(id))byId.set(id,one)}
const seat=[]
const used=new Set()
for(const one of list){const found=byId.get(one?.id??one?.itemId)
if(found===undefined||used.has(found))return null
used.add(found)
seat.push(found)}
return seat}
const floorlessOrder=()=>{if(valuation===null)return null
const plain=new Map()
let raised=false
for(const player of candidates){const price=searchBurnOf(player,valuation.prices,{classes:valuation.classes,isDuplicate:valuation.isDuplicate,priceOf:cachedPriceOf,futureRatings:valuation.futureRatings,__noRarityFloor:true})
const held=preferences.get(player)
if(isNum(held?.price)&&price<held.price)raised=true
plain.set(player,{untradeable:0,price,rarity:rarityWeightOf(player),rating:isNum(player?.rating)?player.rating:0})}
if(!raised)return null
return candidates.slice().sort((a,b)=>compareKnownPreference(a,b,plain.get(a),plain.get(b),ratingUp))}
const heir=heirOf(input.__heir)
if(heir!==null)addStart(heir,'heir')
if(market){const clubOnly=candidates.filter((player)=>player?.virtual!==true)
if(clubOnly.length>=freeSize)seedFrom(clubOnly,'club')}
seedFrom(candidates,'all')
{const floorless=floorlessOrder()
if(floorless!==null)addStart(takeUnique(floorless,freeSize),'floorless')}
if(starts.length===0){if(shape!=='full'&&(floorCut>0||thinCut>0)){return printed(yield*solveSquadSteps({...input,poolDepth:shape==='thinned'?'floored':'full',maxEvaluations:cap,__budget:budget,__deadline:deadline,__spent:spentBefore,__widened:true,__panicAt:capPanicAt,__kicked:kicked,__clock:clockState,__mb26:mb26}),'widened')}
return{ok:false,reason:'not-enough-players',squad:null,failed:[],evaluations:spentBefore,shaping:shapingOf(),budget:budgetOf(),panic:panicOf(),chemOrder:chemOrderOf()}}
if(tracing)trace.planted=starts.map((start)=>(start.cover===undefined?start.kind:`${start.kind} cover[${start.cover.join(',')}]`))
const counterweights=isNum(input.counterweights)&&input.counterweights>=0
?Math.floor(input.counterweights)
:MAX_COUNTERWEIGHTS
const reserve=ratingFloor!==null&&counterweights!==0?Math.floor(cap*COUNTERWEIGHT_RESERVE):0
limit=cap-reserve
startsLimit=limit
if(capPanicAt===null)capPanicAt=repairPanic*startsLimit
wakeIfDue()
if(tracing)trace.panicAt=capPanicAt
const outcomes=[]
const seeded=[]
for(let at=0;at<starts.length;at+=1){if(evaluations>=startsLimit)break
const start=starts[at]
const best=shortfallOf(squadOf(start.chosen),measurable,scoreOpts)
tick()
yield
seeded.push({at,start,seed:outcomeOf(start.chosen,best)})}
if(tracing)trace.phases.seed=evaluations
const repairRound=Math.max(1,size*candidates.length)
const scale=isNum(input.circleScale)&&input.circleScale>0?input.circleScale:1
const quantumOf=(share)=>Math.max(1,Math.floor(share*scale*repairRound))
const runners=seeded.map(({at,start,seed})=>({at,start,seed,mark:tracing?`${at}:${start.kind}`:null,pulse:{chosen:start.chosen,rest:start.rest,best:seed.best,swaps:0},steps:null,done:false,out:null,spent:0,dry:0,alive:true,goal:seed}))
const lap=function*(runner,allow,bound=startsLimit){if(runner.steps===null)runner.steps=descend(runner.start.chosen,runner.start.rest,runner.mark,runner.seed.best,runner.pulse)
const before=evaluations
const swaps=runner.pulse.swaps
const was=runner.pulse.best
while(evaluations-before<allow&&evaluations<bound){const step=runner.steps.next()
if(step.done){runner.done=true
runner.out=step.value
break}
yield}
runner.spent+=evaluations-before
runner.goal=runner.done?runner.out:outcomeOf(runner.pulse.chosen,runner.pulse.best)
if(runner.pulse.swaps>swaps||runner.pulse.best<was)runner.dry=0
else runner.dry+=evaluations-before
if(runner.done||runner.dry>=repairRound)runner.alive=false}
let champion=null
while(evaluations<startsLimit&&!outOfTime(true)){let pick=null
for(const runner of runners){if(!runner.alive)continue
if(pick===null||closerToGoal(runner.goal,pick.goal)<0)pick=runner}
if(pick===null)break
yield*lap(pick,quantumOf(pick.steps===null?CIRCLE_FIRST_SHARE:CIRCLE_SHARE))
if(pick.goal.best===0){champion=pick
break}}
if(champion!==null&&!champion.done&&evaluations<startsLimit)yield*lap(champion,startsLimit-evaluations)
if(champion===null)for(const runner of runners){if(champion===null||closerToGoal(runner.goal,champion.goal)<0)champion=runner}
let winner=champion.done?champion.out:{chosen:champion.pulse.chosen,rest:champion.pulse.rest,...champion.goal}
trailAt('starts')
const kicks={tried:0,taken:0,saved:0}
if(tracing)trace.phases.starts=evaluations-trace.phases.seed
limit=cap
let kickAt=0
const counterweight=function*(win){if(ratingFloor===null||counterweights===0)return win
for(let kick=0;(counterweights===null||kick<counterweights)&&win.best===0&&evaluations<cap;kick+=1){const squadNow=win.chosen
let suspectAt=-1
for(let i=0;i<squadNow.length;i+=1){const rating=squadNow[i]?.rating
if(!isNum(rating)||rating>=ratingFloor)continue
if(suspectAt===-1||rating<squadNow[suspectAt].rating)suspectAt=i}
if(suspectAt===-1)break
const suspect=squadNow[suspectAt]
const inSquad=new Set(squadNow)
const occupied=keyCountsOf(squadNow)
const replacement=candidates.find((player)=>!inSquad.has(player)&&isNum(player?.rating)&&player.rating>=ratingFloor&&!keyConflict(occupied,player,suspect))
if(replacement===undefined)break
const restart=squadNow.slice()
restart[suspectAt]=replacement
const taken=new Set(restart)
const rest=candidates.filter((player)=>!taken.has(player)&&player!==suspect)
kicks.tried+=1
kickAt+=1
kicked=true
const was=stage
stage='kick'
const result=yield*descend(restart,rest,tracing?`kick${kickAt}`:null,undefined,null,true)
stage=was
outcomes.push(result)
if(result.best===0&&result.burn<win.burn){kicks.taken+=1
if(Number.isFinite(win.burn)&&Number.isFinite(result.burn))kicks.saved+=win.burn-result.burn
win=result
continue}
break}
return win}
winner=yield*counterweight(winner)
trailAt('counterweight')
if(tracing)trace.phases.counterweight=evaluations-trace.phases.starts-trace.phases.seed
const circles={resumed:false,extraSpent:0,improved:false,stopped:false,stoppedBy:null,speedDropped:0,speed:null}
const dryLimit=Math.max(1,Math.floor((isNum(input.circleDry)&&input.circleDry>0?input.circleDry:CIRCLE_DRY_ROUNDS)*repairRound))
if(winner.best===0){const beforeCircles=evaluations
stage='circles'
if(latchArea&&mb23.entryShown===null&&mb23.lastShown===null){const shown=shownOf(winner.chosen)
if(shown.unknown===0){mb23.entryShown=shown.cost
mb23.lastShown=shown.cost}}
let dry=0
let lapWork=0
let round=0
while(cap-evaluations>=repairRound&&!outOfTime(true)){let pick=null
for(const runner of runners){if(!runner.alive)continue
if(pick===null||closerToGoal(runner.goal,pick.goal)<0)pick=runner}
if(pick===null)break
circles.resumed=true
const spentAt=evaluations
const was=pick.goal.best
let won=false
yield*lap(pick,quantumOf(pick.steps===null?CIRCLE_FIRST_SHARE:CIRCLE_SHARE),cap)
if(pick.goal.best===0){if(!pick.done&&evaluations<cap)yield*lap(pick,cap-evaluations,cap)
const rival=pick.done?pick.out:{chosen:pick.pulse.chosen,rest:pick.pulse.rest,...pick.goal}
if(rival.burn<winner.burn){winner=yield*counterweight(rival)
circles.improved=true
won=true}}
if(won||pick.goal.best<was)dry=0
else dry+=evaluations-spentAt
if(dry>=dryLimit){circles.stopped=true
circles.stoppedBy='dry'
break}
const rest=cap-evaluations
lapWork+=evaluations-spentAt
const full=lapWork>=repairRound
let postWin=false
if(full){const work=lapWork
lapWork=0
round+=1
mb23.fullBoundaries+=1
if(latchArea){const shown=shownOf(winner.chosen)
const before=mb23.lastShown
const after=shown.unknown>0?null:shown.cost
let wonLap=false
if(after!==null){if(before!==null&&after<before){wonLap=true
mb23.wins+=1
mb23.armed=true
mb23.latchArmedAt=round}
mb23.lastShown=after}
mb23.boundaries.push({round,work,before,after,won:wonLap})
if(mb23.boundaries.length>3)mb23.boundaries.shift()
if(after!==null&&!wonLap&&mb23.armed){mb23.postWinStoppedAt=round
postWin=true}}}
if(postWin){circles.stopped=true
circles.stoppedBy='post-win'
break}
const row=full&&tracing?[]:null
let cheapest=null
for(const runner of runners){if(!runner.alive)continue
const short=runner.goal.best
const removed=runner.seed.best-short
const priced=short>0&&removed>0&&runner.spent>=repairRound
const projected=priced?short*(runner.spent/removed):null
let dropped=false
if(priced){if(cheapest===null||projected<cheapest)cheapest=projected
if(projected>rest){runner.alive=false
circles.speedDropped+=1
dropped=true}}
if(row!==null)row.push({at:runner.mark,spent:runner.spent,best:short,removed,projected,dropped})}
if(cheapest!==null)circles.speed={rounds:round,projected:cheapest,remaining:rest}
if(row!==null)trace.circles.push({round,remaining:rest,live:row})
if(cheapest!==null&&cheapest>rest){circles.stopped=true
circles.stoppedBy='speed'
break}}
if(circles.stoppedBy===null&&circles.speedDropped>0&&!runners.some((runner)=>runner.alive)){circles.stopped=true
circles.stoppedBy='speed'}
circles.extraSpent=evaluations-beforeCircles}
circles.entryShown=mb23.entryShown
circles.fullBoundaries=mb23.fullBoundaries
circles.wins=mb23.wins
circles.lastShown=mb23.lastShown
circles.latchArmedAt=mb23.latchArmedAt
circles.postWinStoppedAt=mb23.postWinStoppedAt
circles.boundaries=mb23.boundaries.map((one)=>({...one}))
if(tracing)trace.phases.circles=evaluations-trace.phases.counterweight-trace.phases.starts-trace.phases.seed
const spentPerStart=[]
for(const runner of runners){if(runner.steps===null)continue
spentPerStart.push({at:runner.at,spent:runner.spent})
outcomes.push(runner.done?runner.out:{chosen:runner.pulse.chosen,rest:runner.pulse.rest,...runner.goal})
if(tracing&&!runner.done)trace.starts.push({at:runner.mark,best:runner.goal.best,burn:runner.goal.burn,spend:runner.goal.spend,unmet:runner.goal.unmet,lack:runner.goal.lack,evaluations:runner.spent,ids:runner.pulse.chosen.map(traceId)})}
const startsReport={planted:starts.length,scored:seeded.length,descended:spentPerStart.length,spent:spentPerStart}
trailAt('circles')
const gateCap=clockState.stopped===true?Math.max(cap,evaluations+GATE_RESERVE):cap
const clubGate={tried:0,taken:0}
if(market!==null&&winner.best===0){const settled=new Set()
for(let guard=0;guard<size*2&&evaluations<gateCap;guard+=1){const squadNow=winner.chosen
let buyAt=-1
for(let i=0;i<squadNow.length;i+=1){if(squadNow[i]?.virtual!==true||settled.has(squadNow[i]))continue
buyAt=i
break}
if(buyAt===-1)break
const buy=squadNow[buyAt]
const price=isNum(buy?.buyPrice)&&buy.buyPrice>0?buy.buyPrice:burnOf(buy)
const inSquad=new Set(squadNow)
const occupied=keyCountsOf(squadNow)
clubGate.tried+=1
let found=null
for(const player of candidates){if(evaluations>=gateCap)break
if(player?.virtual===true||inSquad.has(player))continue
if(tradabilityOf(player)!=='untradeable')continue
if(!(burnOf(player)<price*SELL_SWAP_ADVANTAGE))continue
if(keyConflict(occupied,player,buy))continue
const trial=squadNow.slice()
trial[buyAt]=player
const score=shortfallOf(squadOf(trial),measurable,scoreOpts)
tick()
yield
if(score===0){found=trial
break}}
if(found===null){settled.add(buy)
continue}
if(tracing)traceBuy({at:'club-gate',phase:'gate',buy:traceId(buy),out:traceId(found[buyAt]),why:'club-first',cost:price,outCost:burnOf(found[buyAt])})
clubGate.taken+=1
winner={...winner,chosen:found}}
if(clubGate.taken>0)winner={...winner,burn:winner.chosen.reduce((sum,player)=>sum+burnOf(player),0),spend:winner.chosen.reduce((sum,player)=>sum+(player?.virtual===true&&isNum(player.buyPrice)?player.buyPrice:0),0)}}
const specGate={tried:0,taken:0}
const wantsRarity=requirements.some((req)=>{if(req?.key===REQUIREMENT_KEY.PLAYER_RARITY||req?.key===REQUIREMENT_KEY.PLAYER_RARITY_GROUP)return true
return Array.isArray(req?.combined)&&req.combined.some((entry)=>entry?.key===REQUIREMENT_KEY.PLAYER_RARITY||entry?.key===REQUIREMENT_KEY.PLAYER_RARITY_GROUP)})
if(!wantsRarity&&winner.best===0){const hopeless=new Set()
for(let guard=0;guard<size*2&&evaluations<gateCap;guard+=1){const squadNow=winner.chosen
let specAt=-1
for(let i=0;i<squadNow.length;i+=1){const flag=rarityOf(squadNow[i])
if(!isNum(flag)||flag<SPECIAL_RARITY_MIN)continue
if(hopeless.has(squadNow[i]))continue
specAt=i
break}
if(specAt===-1)break
const spec=squadNow[specAt]
const inSquad=new Set(squadNow)
const occupied=keyCountsOf(squadNow)
specGate.tried+=1
let found=null
for(const virtualTier of[false,true]){if(found!==null)break
for(const player of candidates){if(evaluations>=gateCap)break
if((player?.virtual===true)!==virtualTier)continue
if(inSquad.has(player))continue
const flag=rarityOf(player)
if(isNum(flag)&&flag>=SPECIAL_RARITY_MIN)continue
if(burnOf(player)>SPECIAL_SWAP_CEILING)continue
if(keyConflict(occupied,player,spec))continue
const trial=squadNow.slice()
trial[specAt]=player
const score=shortfallOf(squadOf(trial),measurable,scoreOpts)
tick()
yield
if(score===0){found=trial
break}}}
if(found===null){hopeless.add(spec)
continue}
specGate.taken+=1
winner={...winner,chosen:found}}
if(specGate.taken>0)winner={...winner,burn:winner.chosen.reduce((sum,player)=>sum+burnOf(player),0),spend:winner.chosen.reduce((sum,player)=>sum+(player?.virtual===true&&isNum(player.buyPrice)?player.buyPrice:0),0)}}
let budgeted=false
if(market&&isNum(market.maxSpend)&&winner.best===0&&winner.spend>market.maxSpend){let within=null
for(const outcome of outcomes){if(outcome.best!==0||outcome.spend>market.maxSpend)continue
if(within===null||outcome.burn<within.burn)within=outcome}
if(within!==null){winner=within
budgeted=true}}
if(tracing)trace.phases.gate=evaluations-trace.phases.starts-trace.phases.counterweight-trace.phases.circles-trace.phases.seed
trailAt('gates')
const chosen=winner.chosen
const squad=squadOf(chosen)
const verdict=checkSquad(squad,input.requirements,{linkedTeam,operation})
const deficitPhase={state:phaseArea?(mb23.phaseRounds>0?'allowed':'no-deficit'):'blocked',
reason:phaseArea?(mb23.phaseRounds>0?'allowed':'no-deficit'):(simple.ok?'off':simple.reason),
rounds:mb23.phaseRounds,candidates:mb23.phaseCandidates,accepted:mb23.phaseAccepted,
fallbackRounds:mb23.phaseFallback,
rarityShortfall:{before:mb23.rarityBefore,after:phaseArea?rarityShortOf(chosen):null}}
const buys=squad.players.filter((p)=>p?.virtual===true)
const spend=buys.reduce((sum,p)=>sum+(isNum(p?.buyPrice)?p.buyPrice:0),0)
if(verdict.ok){if(market&&isNum(market.maxSpend)&&spend>market.maxSpend){return{ok:false,reason:'over-budget',squad,failed:[],evaluations:spentBefore+evaluations,buys,spend,counterweight:kicks,circles,deficitPhase,specGate,clubGate,starts:startsReport,shaping:shapingOf(),budget:budgetOf(),panic:panicOf(),chemOrder:chemOrderOf(),...(clusterTried?{clusters:clustersOf()}:{}),...(tracing?{trace}:{})}}
return{ok:true,reason:null,squad,failed:[],evaluations:spentBefore+evaluations,buys,spend,counterweight:kicks,circles,deficitPhase,specGate,clubGate,starts:startsReport,shaping:shapingOf(),budget:budgetOf(),panic:panicOf(),chemOrder:chemOrderOf(),...(trail===null?{}:{trail}),...(clusterTried?{clusters:clustersOf()}:{}),...(evaluations>=startsLimit?{exhausted:true}:{}),...(budgeted?{budgeted:true}:{}),
__goal:{best:winner.best,burn:winner.burn,unmet:0,lack:0},...(tracing?{trace}:{})}}
const wider=shape==='full'?null:shape==='thinned'&&thinCut>0?'floored':(floorCut>0||thinCut>0)?'full':null
const widerPool=wider===null?0:candidates.length+thinCut+(wider==='full'?floorCut:0)
const widerRound=size*widerPool
const narrow={ok:false,
reason:evaluations>=startsLimit?'search-exhausted':'no-solution',squad,failed:verdict.failed,evaluations:spentBefore+evaluations,buys,spend,counterweight:kicks,circles,deficitPhase,specGate,clubGate,starts:startsReport,shaping:shapingOf(),budget:budgetOf(),panic:panicOf(),chemOrder:chemOrderOf(),...(clusterTried?{clusters:clustersOf()}:{}),unmet:winner.unmet,lack:winner.lack,
...(clockState.stopped===true&&winner.unmet>0?{unfinished:true}:{}),
__goal:{best:winner.best,burn:winner.burn,unmet:winner.unmet,lack:winner.lack},
__exactIn:{field,freeSize,fixed:fixed.players,cost:(player)=>preferences.get(player)?.price,buckets:market===null?null:market.prices?.buckets??null,allowsTier},...(tracing?{trace}:{})}
if(wider!==null&&cap-evaluations>=widerRound){const far=yield*solveSquadSteps({...input,poolDepth:wider,maxEvaluations:cap-evaluations,__budget:budget,__deadline:deadline,__spent:spentBefore+evaluations,__widened:true,__panicAt:capPanicAt,__kicked:kicked,__clock:clockState,__mb23:mb23,__mb26:mb26,__heir:winner.chosen})
return betterOf(narrow,far)}
return narrow}
const EXACT_DIMS=Object.freeze([
{key:REQUIREMENT_KEY.NATION_COUNT,dim:'nation',cap:REQUIREMENT_KEY.SAME_NATION_COUNT},
{key:REQUIREMENT_KEY.LEAGUE_COUNT,dim:'league',cap:REQUIREMENT_KEY.SAME_LEAGUE_COUNT},
{key:REQUIREMENT_KEY.CLUB_COUNT,dim:'club',cap:REQUIREMENT_KEY.SAME_CLUB_COUNT}])
const EXACT_SPARE=4
export const EXACT_SETS=24
const EXACT_WINS=2
const EXACT_SCAN=4000
const EXACT_BUCKET_DEEP=4
function exactValueOf(player,dim,linkedTeam){if(dim==='nation')return nationOf(player)
if(dim==='league')return leagueOf(player)
return linkedClubOf(player,linkedTeam)}
function exactKeeps(player,exact,linkedTeam){for(const one of exact){
if(!one.values.has(exactValueOf(player,one.dim,linkedTeam)))return false}
return true}
function exactMarketOf(prices,exact,linkedTeam){if(!prices||typeof prices!=='object')return prices
const buckets=Array.isArray(prices.buckets)?prices.buckets:null
if(buckets===null)return prices
const keeps=(bucket)=>{for(const one of exact){const value=one.dim==='nation'?bucket.nationId
:one.dim==='league'?bucket.leagueId
:typeof linkedTeam==='function'?linkedTeam(bucket.teamId):bucket.teamId
if(!one.values.has(value))return false}
return true}
return{...prices,buckets:buckets.filter(keeps)}}
function exactCombos(list,size,must){const out=[]
const rest=list.filter((one)=>!must.includes(one))
if(must.length>size)return out
const pick=(from,chosen)=>{if(out.length>=EXACT_SCAN)return
if(chosen.length===size){out.push([...chosen])
return}
for(let i=from;i<rest.length;i+=1){chosen.push(rest[i])
pick(i+1,chosen)
chosen.pop()
if(out.length>=EXACT_SCAN)return}}
pick(0,[...must])
return out}
function exactSupplyOf(carried,linkedTeam){const rows=[]
const allows=typeof carried.allowsTier==='function'?carried.allowsTier:null
const cost=typeof carried.cost==='function'?carried.cost:()=>0
for(const player of Array.isArray(carried.field)?carried.field:[]){
if(player?.virtual===true)continue
const price=cost(player)
rows.push({nation:nationOf(player),league:leagueOf(player),club:linkedClubOf(player,linkedTeam),
price:isNum(price)?price:Number.POSITIVE_INFINITY,mine:true})}
const buckets=Array.isArray(carried.buckets)?carried.buckets:[]
for(const bucket of buckets){if(allows!==null&&!allows(tierOf(bucket)))continue
const picks=Array.isArray(bucket.picks)?bucket.picks:[]
let taken=0
for(const pick of picks){if(taken>=EXACT_BUCKET_DEEP)break
if(!isNum(pick?.price)||pick.price<=0)continue
taken+=1
rows.push({nation:bucket.nationId,league:bucket.leagueId,
club:typeof linkedTeam==='function'?linkedTeam(bucket.teamId):bucket.teamId,
price:pick.price,mine:false})}}
return rows}
const exactRowValue=(row,dim)=>(dim==='nation'?row.nation:dim==='league'?row.league:row.club)
function exactPlanOf(input,base){const carried=base?.__exactIn
if(!carried||base?.ok===true)return null
if(base.reason!=='no-solution'&&base.reason!=='search-exhausted')return null
if(base.budget?.timeStopped===true)return null
const operation=input.operation===OPERATION.OR?OPERATION.OR:OPERATION.AND
if(operation!==OPERATION.AND)return null
const{requirements}=parseRequirements(input.requirements)
const linkedTeam=typeof input.linkedTeam==='function'?input.linkedTeam:undefined
const failed=new Set((base.failed??[]).map((one)=>one?.key))
const freeSize=isNum(carried.freeSize)&&carried.freeSize>0?carried.freeSize:0
if(freeSize===0)return null
const fixed=Array.isArray(carried.fixed)?carried.fixed:[]
const specs=[]
let hitFailed=false
for(const spec of EXACT_DIMS){const req=requirements.find((one)=>one.key===spec.key
&&(one.compare===COMPARE.EXACT||one.compare===COMPARE.LOWER))
if(req===undefined)continue
const n=needOf(req)
if(!isNum(n)||n<1)continue
if(failed.has(spec.key))hitFailed=true
const must=[]
for(const one of fixed){const value=exactValueOf(one,spec.dim,linkedTeam)
if(value===undefined||value===null)continue
if(!must.includes(value))must.push(value)}
if(must.length>n)return null
specs.push({dim:spec.dim,n,cap:spec.cap,must})}
if(specs.length===0||hitFailed!==true)return null
specs.sort((a,b)=>a.n-b.n)
const caps=new Map()
for(const spec of EXACT_DIMS){const req=requirements.find((one)=>one.key===spec.cap
&&(one.compare===COMPARE.EXACT||one.compare===COMPARE.LOWER))
if(req===undefined)continue
const k=needOf(req)
if(isNum(k)&&k>0)caps.set(spec.dim,k)}
const supply=exactSupplyOf(carried,linkedTeam)
if(supply.length<freeSize)return null
const rankedOf=(rows,spec)=>{const byValue=new Map()
for(const row of rows){const value=exactRowValue(row,spec.dim)
if(value===undefined||value===null)continue
if(!byValue.has(value))byValue.set(value,[])
byValue.get(value).push(row.price)}
const deep=Math.max(1,Math.ceil(freeSize/spec.n))
const weight=new Map()
for(const[value,prices]of byValue){const cheap=prices.slice().sort((a,b)=>a-b).slice(0,deep)
if(cheap.length<deep)continue
weight.set(value,cheap.reduce((sum,one)=>sum+one,0))}
for(const value of spec.must){if(!weight.has(value))return null}
const ranked=[...weight.entries()].sort((a,b)=>a[1]-b[1]).map(([value])=>value)
const out=[...spec.must]
for(const value of ranked){if(out.length>=spec.n+EXACT_SPARE)break
if(!out.includes(value))out.push(value)}
return out}
const grown=[]
const build=(index,parts,rows)=>{if(grown.length>=EXACT_SCAN)return
if(index===specs.length){grown.push({parts,rows})
return}
const spec=specs[index]
const values=rankedOf(rows,spec)
if(values===null)return
for(const combo of exactCombos(values,spec.n,spec.must)){const set=new Set(combo)
const next=rows.filter((row)=>set.has(exactRowValue(row,spec.dim)))
if(next.length<freeSize)continue
build(index+1,[...parts,{dim:spec.dim,n:spec.n,values:set}],next)
if(grown.length>=EXACT_SCAN)return}}
build(0,[],supply)
const scored=[]
for(const one of grown){let ok=true
for(const part of one.parts){const cap=caps.get(part.dim)
if(!isNum(cap))continue
let fits=0
for(const value of part.values){let count=0
for(const row of one.rows){if(exactRowValue(row,part.dim)===value)count+=1}
fits+=Math.min(count,cap)}
if(fits<freeSize){ok=false
break}}
if(!ok)continue
const prices=one.rows.map((row)=>row.price).sort((a,b)=>a-b).slice(0,freeSize)
scored.push({parts:one.parts,price:prices.reduce((sum,two)=>sum+two,0)})}
if(scored.length===0)return null
scored.sort((a,b)=>a.price-b.price)
return{dims:specs.map((one)=>({dim:one.dim,n:one.n})),
sets:scored.slice(0,EXACT_SETS).map((one)=>one.parts)}}
function exactMarked(answer,mark){if(!answer||typeof answer!=='object')return answer
return{...answer,shaping:{...(answer.shaping&&typeof answer.shaping==='object'?answer.shaping:{}),exact:mark}}}
function exactCostOf(answer){const burn=answer?.__goal?.burn
if(isNum(burn))return burn
const spend=answer?.spend
return isNum(spend)?spend:Number.POSITIVE_INFINITY}
function*solveSquadWithExact(input={}){const base=yield*solveSquadSteps(input)
const shrink=input.__finish!==null&&typeof input.__finish==='object'?null:exactPlanOf(input,base)
if(base&&typeof base==='object')delete base.__exactIn
if(shrink===null)return base
const ceiling=base?.budget?.ceiling
const phaseCap=isNum(ceiling)&&ceiling>0?Math.floor(ceiling):0
if(phaseCap<=0)return base
const phaseBudget={base:phaseCap,rounds:isNum(base?.budget?.rounds)?base.budget.rounds:0,ceiling:phaseCap}
const phaseClock={budgetMs:null,startedAt:null,clockAt:null,forecast:null,stopped:false,
awake:false,wakeAt:null,spentAtWake:null,improvementsBooked:0,acceptedSwaps:0,roundsCut:0,pruned:0,prunedFree:0}
let left=phaseCap
let spent=isNum(base?.evaluations)?base.evaluations:0
let deadline=null
let tried=0
const wins=[]
for(let i=0;i<shrink.sets.length;i+=1){if(left<=0)break
const share=Math.max(1,Math.floor(left/(shrink.sets.length-i)))
const child=yield*solveSquadSteps({...input,__exact:shrink.sets[i],maxEvaluations:share,
__budget:phaseBudget,__spent:spent,__clock:phaseClock,timeBudgetMs:TIME_BUDGET_MS,
...(deadline===null?{}:{__deadline:deadline})})
tried+=1
if(child&&typeof child==='object')delete child.__exactIn
const used=Math.max(0,(isNum(child?.evaluations)?child.evaluations:spent)-spent)
spent+=used
left-=Math.max(used,1)
if(deadline===null&&isNum(phaseClock.startedAt))deadline=phaseClock.startedAt+TIME_BUDGET_MS
if(child?.ok===true){wins.push({answer:child,at:tried})
if(wins.length>=EXACT_WINS)break}
if(phaseClock.stopped===true)break}
const mark={dims:shrink.dims,planned:shrink.sets.length,tried,solvedAt:null}
if(wins.length===0)return exactMarked(base,mark)
wins.sort((a,b)=>exactCostOf(a.answer)-exactCostOf(b.answer))
mark.solvedAt=wins[0].at
return exactMarked(wins[0].answer,mark)}
export function isSbcPlayer(item){try{return item&&typeof item==='object'
&&typeof item.isPlayer==='function'
&&item.isPlayer()===true}catch{return false}}
function sanitizeFixed(value,size){const players=[]
const bySlot=new Map()
const ids=new Set()
for(const entry of Array.isArray(value)?value:[]){const player=entry?.player
const slot=entry?.slot
if(!isSbcPlayer(player))return null
if(!Number.isSafeInteger(slot)||slot<0||slot>=size)return null
if(bySlot.has(slot))return null
const id=player.id??player.itemId
if(id!==undefined){if(ids.has(id))return null
ids.add(id)}
bySlot.set(slot,player)
players.push(player)}
return{players,bySlot,ids}}
export function sanitizeSbcPolicy(value){const clean=(list,min)=>[...new Set((Array.isArray(list)?list:[])
.filter((id)=>Number.isSafeInteger(id)&&id>=min))].slice(0,50)
return{leagues:clean(value?.leagues,1),rarities:clean(value?.rarities,0),protectTradeable:value?.protectTradeable===true,protectSpecial:value?.protectSpecial===true,includeStorage:value?.includeStorage===true}}
export function isSbcAllowed(item,policy={},protectedIds=[]){if(!isSbcPlayer(item))return false
if(protectedIds.some?.((id)=>String(id)===String(item.id)))return false
if(policy.leagues?.length
&&(!Number.isSafeInteger(item.leagueId)||policy.leagues.includes(item.leagueId)))return false
if(policy.rarities?.length
&&(!Number.isSafeInteger(item.rareflag)||policy.rarities.includes(item.rareflag)))return false
if(policy.protectTradeable&&tradabilityOf(item)!=='untradeable') return false
if(policy.protectSpecial){try{if(item.isSpecial()!==false)return false}catch{return false}}
return true}
export function brickPlanOf(raw,positions){if(!Array.isArray(raw)||raw.length===0||!Array.isArray(positions))return null
if(positions.length+raw.length!==FIELD_PLAYERS)return null
const at=new Map()
for(const one of raw){if(!Number.isInteger(one?.at)||one.at<0||one.at>=FIELD_PLAYERS||at.has(one.at))return null
if(!isNum(one?.position)||!one?.player||typeof one.player!=='object')return null
at.set(one.at,one.player)}
const full=[]
let next=0
for(let slot=0;slot<FIELD_PLAYERS;slot+=1)full.push(at.has(slot)?raw.find((one)=>one.at===slot).position:positions[next++])
const fill=(arranged)=>{if(!Array.isArray(arranged)||arranged.length!==positions.length)return arranged
const out=[]
let card=0
for(let slot=0;slot<FIELD_PLAYERS;slot+=1)out.push(at.has(slot)?at.get(slot):arranged[card++])
return out}
return{at,positions:full,fill}}
export function teamRating(players,float=null){if(float===null)return squadRatingBounds({field:players}).rating
return squadRating({field:players,float})}
export function ratingGateOf(players,slot,target,float=null){const field=Array.isArray(players)?players.slice():[]
for(let v=0;v<=MAX_RATING;v+=1){field[slot]={rating:v}
if(teamRating(field,float)>=target)return v}
return MAX_RATING+1}
