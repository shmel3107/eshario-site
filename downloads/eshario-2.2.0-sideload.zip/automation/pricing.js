import{netAfterTax} from '../features/tax.js'
import{floorToValidPrice,isValidPrice,MIN_PRICE,AUCTION_MAX_BID} from '../features/price-grid.js'
export const NO_SALE=Object.freeze({NO_PRICE:'no-market-price',BELOW_MIN:'below-minimum',NOT_PROFITABLE:'not-profitable',ABOVE_MAX:'above-maximum',
BAND_BELOW_PROFIT:'band-below-profit'
})
const isMoney=(value)=>typeof value==='number'&&Number.isFinite(value)&&value>=0
export function proceedsOf(price){return isMoney(price)?netAfterTax(price):0}
export function profitAt(input={}){const proceeds=proceedsOf(input.price)
const buyPrice=isMoney(input.buyPrice)?input.buyPrice:0
const minProfit=isMoney(input.minProfit)?input.minProfit:0
const profit=proceeds-buyPrice
return{ok:profit>=minProfit&&profit>0,proceeds,profit}}
export function sellPriceFor(input={}){const marketPrice=isMoney(input.marketPrice)?input.marketPrice:null
const buyPrice=isMoney(input.buyPrice)?input.buyPrice:0
const marginPercent=isMoney(input.marginPercent)?input.marginPercent:0
const minProfit=isMoney(input.minProfit)?input.minProfit:0
if(marketPrice===null||marketPrice<=0){return fail(NO_SALE.NO_PRICE)}
const wanted=marketPrice*(1-Math.min(marginPercent,100) / 100);
if(wanted<MIN_PRICE)return fail(NO_SALE.BELOW_MIN);
if(wanted>AUCTION_MAX_BID)return fail(NO_SALE.ABOVE_MAX);
const price=floorToValidPrice(wanted);
if(!isValidPrice(price))return fail(NO_SALE.BELOW_MIN);
const money=profitAt({price,buyPrice,minProfit});
if(!money.ok){return{ok:false,price:null,proceeds:money.proceeds,profit:money.profit,reason:NO_SALE.NOT_PROFITABLE}}
return{ok:true,price,proceeds:money.proceeds,profit:money.profit,reason:null}}
export function startingBidFor(buyNowPrice,opts={}){if(!isValidPrice(buyNowPrice))return null;
const discount=isMoney(opts.discountPercent)?Math.min(opts.discountPercent,100):5;
const wanted=buyNowPrice*(1-discount / 100);
const bid=floorToValidPrice(wanted);
if(!isValidPrice(bid)||bid>buyNowPrice)return null;
return bid}
function fail(reason){return{ok:false,price:null,proceeds:0,profit:0,reason}}
