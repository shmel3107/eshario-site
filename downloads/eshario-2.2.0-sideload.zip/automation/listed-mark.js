const listed = new WeakSet()
export function markListed(item){if(item===null||typeof item!=='object')return false
listed.add(item)
return true}
export function isListed(item){return item!==null&&typeof item==='object'&&listed.has(item)}
