export const FIELD_PLAYERS=11
export const SUB_PLAYERS=7
export const MAX_RATING=99
export function squadRating(squad={}){const field=valid(squad.field)
const subs=valid(squad.subs)
const divisor=FIELD_PLAYERS+subs.length
const sum=total(field)+total(subs)
if(divisor===0)return 0
const bonus=squad.float===true
?floatBonus(field,subs,sum,divisor)
:integerBonus(field,subs,sum,divisor)
return clamp(Math.floor((sum+bonus) / divisor));
}
function integerBonus(field,subs,sum,divisor){const average=Math.min(Math.floor(sum / divisor),MAX_RATING);
let bonus=0;
for(const rating of field)if(rating>average)bonus+=rating-average;
for(const rating of subs)if(rating>average)bonus+=Math.floor(0.5*(rating-average));
return bonus}
function floatBonus(field,subs,sum,divisor){const average=Math.min(sum / divisor,MAX_RATING);
let totalWithBonus=sum;
for(const rating of field)if(rating>average)totalWithBonus+=rating-average;
for(const rating of subs)if(rating>average)totalWithBonus+=0.5*(rating-average);
return Math.round(totalWithBonus)-sum}
export function squadRatingBounds(squad={}){const integer=squadRating({...squad,float:false});
const float=squadRating({...squad,float:true});
return{
rating:Math.min(integer,float),integer,float,certain:integer===float}}
export function squadRatingExact(squad={}){const field=valid(squad.field)
const subs=valid(squad.subs)
const divisor=FIELD_PLAYERS+subs.length
const sum=total(field)+total(subs)
if(divisor===0)return 0
const exact=(bonus)=>clamp((sum+bonus)/divisor)
if(squad.float===true)return exact(floatBonus(field,subs,sum,divisor))
if(squad.float===false)return exact(integerBonus(field,subs,sum,divisor))
return Math.min(exact(floatBonus(field,subs,sum,divisor)),exact(integerBonus(field,subs,sum,divisor)))}
function valid(list){if(!Array.isArray(list))return[];
const out=[];
for(const entry of list){const rating=Number(typeof entry==='object'&&entry!==null?entry.rating:entry);
if(Number.isFinite(rating)&&rating>0)out.push(rating)}
return out}
function total(list){return list.reduce((acc,rating)=>acc+rating,0)}
function clamp(value){return Math.min(Math.max(value,0),MAX_RATING)}
