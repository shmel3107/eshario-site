import{planSales,soldSalesOf,soldRowsOf,marketPriceOf,ACTION} from './sell-plan.js'
import{NO_SALE} from './pricing.js'
import{itemIdsReceiptMatches,moveReceiptMatches} from './item-receipts.js'
import{THROTTLED,restMarketAfterThrottle,askBudgetRound,readBudgetRound} from '../features/day-budget.js'
import{isDoorRefusal,ALLOWED,UNKNOWN as DOOR_UNKNOWN} from '../adapter/action-door.js'
import{listPauseMs,bandPauseMs} from '../core/pace-jitter.js'
export const MAX_ITERATIONS=10_000
export const DEFAULT_DURATION=3600
export function extractItems(data){if(data
&&typeof data==='object'
&&!Array.isArray(data)
&&Array.isArray(data.items)){return data.items}
return null}
export function isAvailableForListing(item){if(!item||typeof item!=='object') return false
if(typeof item.getAuctionData!=='function') return false
try{const auction=item.getAuctionData()
if(!auction||typeof auction.isValid!=='function') return false
return auction.isValid()!==true}catch{return false}}
const statusOf=(err)=>(typeof err?.status==='number'?err.status:null)
export function createSeller(deps={}){const{market,session,stop,clock}=deps
if(!market||typeof market.requestTransferItems!=='function'||typeof market.list!=='function'){throw new Error('seller: нужен рынок с requestTransferItems и list')}
if(!session||typeof session.snapshot!=='function') throw new Error('seller: нужна сессия')
if(!stop
||typeof stop.shouldStop!=='function'
||typeof stop.shouldStopBeforeAction!=='function'
){throw new Error('seller: нужны условия остановки')}
if(!clock||typeof clock.sleep!=='function') throw new Error('seller: нужны часы (правило 6 NIGHT_BRIEF)')
const options=deps.options??{}
const onEvent=typeof deps.onEvent==='function'?deps.onEvent:()=>{}
const emit=(name,payload)=>{try{onEvent(name,payload)}catch{
}}
const budgetCall=(count=1)=>{const day=deps.budget
return day!==null&&day!==undefined&&typeof day.call==='function'?day.call(count):null}
const warmRound=async(count=1)=>{const day=deps.budget
if(day===null||day===undefined||typeof day.warm!=='function')return null
try{return await day.warm(count)}catch{
return null}}
const settleRound=async()=>{const day=deps.budget
if(day===null||day===undefined||typeof day.settle!=='function')return null
try{return await day.settle({market:false})}catch{return null}}
const budgetDoors={warm:(count)=>warmRound(count),take:(count)=>budgetCall(count),settle:()=>settleRound()}
const spendRound=(count=1)=>askBudgetRound(budgetDoors,count)
const readRound=(count=1)=>readBudgetRound(budgetDoors,count)
const throttleStop=(failure,stage)=>{if(failure?.category!==THROTTLED)return null
if(restMarketAfterThrottle(deps.budget))emit('rest-market',{stage})
return{reason:THROTTLED,detail:{stage}}}
const fixedListDelayMs=Number.isFinite(options.listDelayMs)?options.listDelayMs:null
const listDelay=()=>(fixedListDelayMs===null?listPauseMs(deps.random):fixedListDelayMs)
const CYCLE_DELAY_BAND_MS=Object.freeze({minMs:27_000,maxMs:33_000})
const fixedCycleDelayMs=Number.isFinite(options.cycleDelayMs)?options.cycleDelayMs:null
const cycleDelay=()=>(fixedCycleDelayMs===null
?bandPauseMs(CYCLE_DELAY_BAND_MS.minMs,CYCLE_DELAY_BAND_MS.maxMs,deps.random)
:fixedCycleDelayMs)
const duration=Number.isFinite(options.duration)?options.duration:DEFAULT_DURATION
const iterationCap=Number.isFinite(options.maxIterations)?options.maxIterations:MAX_ITERATIONS
const maxActions=Number.isInteger(options.maxActions)&&options.maxActions>=0
?options.maxActions
:null
const moveKeptTo=((typeof options.moveKeptTo==='number'&&Number.isFinite(options.moveKeptTo))
||(typeof options.moveKeptTo==='string'&&options.moveKeptTo!==''))?options.moveKeptTo:null
let iteration=0
let attemptedActions=0
let running=false
let cancelled=false
let wakeCall=null
let wakeSignal=null
const armWake=()=>{wakeSignal=new Promise((resolve)=>{wakeCall=resolve})}
armWake()
const wakeUp=()=>{if(wakeCall===null)return
const call=wakeCall
wakeCall=null
call()}
const nap=(ms)=>{if(cancelled)return Promise.resolve()
return Promise.race([clock.sleep(ms),wakeSignal])}
const counted=new Set()
let skippedNoPrice=0
const noPrice=new Set()
const reserveAction=async(stage)=>{const before=stop.shouldStopBeforeAction(session.snapshot())
if(before.stop){return{reason:before.reason,detail:{...(before.detail??{}),stage}}}
if(maxActions!==null&&attemptedActions>=maxActions){return{reason:'action-limit',detail:{limit:maxActions,value:attemptedActions,stage}}}
const money=await spendRound(1)
if(money!==null)return{reason:money.reason,detail:{stage,door:money.door}}
attemptedActions+=1
return null}
const skipNoPrice=(item,field)=>{skippedNoPrice+=1
if(item?.id!==undefined&&item?.id!==null)noPrice.add(item.id)
emit('no-price',{stage:'market-data',field,item})}
const hydrateMarketData=async(items)=>{const ready=[]
let touched=false
for(const item of items){if(marketPriceOf(item,options.marketPrice)!==null){ready.push(item)
continue}
if(item?.id!==undefined&&noPrice.has(item.id))continue
if(typeof item?.getMarketAverage!=='function'){return{items:ready,touched,stop:{stop:true,reason:'bad-state',detail:{stage:'market-data',field:'getMarketAverage'}}}}
if(typeof market.requestMarketData!=='function'){return{items:ready,touched,stop:{stop:true,reason:'bad-state',detail:{stage:'market-data',field:'requestMarketData'}}}}
const before=stop.shouldStop(session.snapshot())
if(before.stop)return{items:ready,touched,stop:before}
const permit=await readRound(1)
if(permit!==null){return{items:ready,touched,
stop:{stop:true,reason:permit.reason,detail:{stage:'market-data',door:permit.door}}}}
touched=true
try{const response=await market.requestMarketData(item)
if(!response
||typeof response!=='object'
||Array.isArray(response)
||!Array.isArray(response.marketData)){skipNoPrice(item,'marketData')
await nap(listDelay())
continue}
if(marketPriceOf(item,options.marketPrice)===null){skipNoPrice(item,'price')
await nap(listDelay())
continue}
ready.push(item)
emit('market-data',{item})
await nap(listDelay())}catch(err){const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'market-data',category:failure.category})
const halt=throttleStop(failure,'market-data')
if(halt)return{items:ready,touched,stop:{stop:true,reason:halt.reason,detail:halt.detail}}
if(failure.stop){return{items:ready,touched,stop:{stop:true,reason:failure.category,detail:{stage:'market-data'}}}}
}}
return{items:ready,touched,stop:null}}
const moveKept=async(item)=>{if(moveKeptTo===null||session.isDryRun()) return null
if(typeof market.move!=='function')return{reason:'bad-state',detail:{stage:'move',field:'move'}}
const blocked=await reserveAction('move')
if(blocked)return blocked
try{const receipt=await market.move([item],moveKeptTo)
if(!moveReceiptMatches(receipt,[item])){return{reason:'bad-state',detail:{stage:'move',field:'itemIds'}}}
session.recordMove(1)
emit('moved',{pile:moveKeptTo})
return null}catch(err){
if(isDoorRefusal(err)){emit('door',{stage:'move',verdict:err.door?.verdict,reason:err.door?.reason,fits:err.door?.fits,need:err.door?.need})
return null}
const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'move',category:failure.category})
const halt=throttleStop(failure,'move')
if(halt)return halt
return['captcha','fatal','out-of-coins'].includes(failure.category)
?{reason:failure.category,detail:{stage:'move'}}
:null}}
const sayDoorSkip=(stage,door)=>{if(door.verdict===DOOR_UNKNOWN){emit('door',{stage,verdict:door.verdict,reason:door.reason,matched:door.matched,unreadable:door.unreadable})}}
const sayClearSkip=(door,unbooked)=>{if(door.verdict!==ALLOWED){sayDoorSkip('clear',door)
return}
if(unbooked>0)emit('door',{stage:'clear',verdict:DOOR_UNKNOWN,reason:'unbooked-sold',matched:door.matched,unbooked})}
const unbookedSales=(rows)=>{let count=0
for(const sale of soldRowsOf(rows)){const id=sale.tradeId
if(typeof id!=='string'||id===''||!counted.has(id))count+=1}
return count}
const askDoor=(request)=>(typeof market.review==='function'
?market.review(request)
:{verdict:DOOR_UNKNOWN,reason:'no-judge',matched:null})
const finish=(reason,detail)=>{running=false
const result={reason,detail:detail??null,stats:session.stats(),iterations:iteration,skippedNoPrice}
emit('stopped',result)
return result}
async function housekeeping(name,call,record,idField){if(typeof call!=='function') return null
if(session.isDryRun())return null
const stage=name==='relisted'?'relist':'clear'
const blocked=await reserveAction(stage)
if(blocked)return blocked
try{const data=await call()
const ids=(data
&&typeof data==='object'
&&!Array.isArray(data)
&&Array.isArray(data[idField]))?data[idField]:null
if(ids===null){emit('failure',{stage:name,category:'bad-shape'})
return{reason:'bad-state',detail:{stage,field:idField}}}
const count=ids.length
record(count)
emit(name,{count})
return count}catch(err){
if(isDoorRefusal(err)){emit('door',{stage,verdict:err.door?.verdict,reason:err.door?.reason,matched:err.door?.matched})
return null}
const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:name,category:failure.category})
const halt=throttleStop(failure,stage)
if(halt)return halt
return failure.stop
?{reason:failure.category,detail:{stage}}
:null}}
return{isRunning:()=>running,
cancel(){cancelled=true
wakeUp()},
async run(){running=true
cancelled=false
armWake()
for(;iteration<iterationCap;iteration+=1){if(cancelled) return finish('cancelled')
const before=stop.shouldStop(session.snapshot())
if(before.stop)return finish(before.reason,before.detail)
const listPermit=await readRound(1)
if(listPermit!==null)return finish(listPermit.reason,{stage:'list-items',door:listPermit.door})
if(cancelled) return finish('cancelled')
let items
try{items=extractItems(await market.requestTransferItems())
if(items===null){return finish('bad-state',{stage:'list-items',field:'items'})}}catch(err){const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'list-items',category:failure.category})
const halt=throttleStop(failure,'list-items')
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop) return finish(failure.category,{stage:'list-items'})
await nap(cycleDelay())
continue}
for(const sale of soldSalesOf(items)){const key=sale.tradeId??`${sale.coins}:${counted.size}`
if(counted.has(key))continue
counted.add(key)
emit('sold',{price:sale.coins,exact:sale.exact,tradeId:sale.tradeId,item:sale.item})}
const available=items.filter(isAvailableForListing)
let stale=false
const hydrated=await hydrateMarketData(available)
if(hydrated.touched)stale=true
if(hydrated.stop?.stop){return finish(hydrated.stop.reason,hydrated.stop.detail)}
const plan=planSales(hydrated.items,options)
emit('planned',{iteration,total:items.length,plan:plan.length})
for(const row of plan){if(cancelled) return finish('cancelled')
if(row.action===ACTION.KEEP){
if(row.reason===NO_SALE.BAND_BELOW_PROFIT||row.reason==='no-band'){
emit('kept',{item:row.item,reason:row.reason})}
stale=true
const moved=await moveKept(row.item)
if(moved?.reason)return finish(moved.reason,moved.detail)
continue}
const beforeAction=stop.shouldStop(session.snapshot())
if(beforeAction.stop)return finish(beforeAction.reason,beforeAction.detail)
if(session.isDryRun()){
if(row.action===ACTION.LIST)session.recordListing(row.price)
else session.recordQuickSell(row.price)
emit('would-sell',{action:row.action,price:row.price,item:row.item,clamped:row.clamped??null})
continue}
if(row.action===ACTION.QUICK_SELL&&typeof market.discard!=='function'){
return finish('bad-state',{stage:row.action,field:'discard'})}
const blocked=await reserveAction(row.action)
if(blocked)return finish(blocked.reason,blocked.detail)
stale=true
try{if(row.action===ACTION.LIST){
const receipt=await market.list(row.item,row.startingBid??row.price,row.price,duration,{fresh:false})
if(!itemIdsReceiptMatches(receipt,[row.item])){return finish('bad-state',{stage:row.action,field:'itemIds'})}
session.recordListing(row.price)
emit('listed',{price:row.price,item:row.item,clamped:row.clamped??null})} else{const receipt=await market.discard([row.item])
if(!itemIdsReceiptMatches(receipt,[row.item])){return finish('bad-state',{stage:row.action,field:'itemIds'})}
session.recordQuickSell(row.price)
emit('quick-sold',{price:row.price,item:row.item})}}catch(err){
if(isDoorRefusal(err)){emit('door',{stage:row.action,verdict:err.door?.verdict,reason:err.door?.reason,fits:err.door?.fits,need:err.door?.need})
continue}
const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:row.action,category:failure.category})
const halt=throttleStop(failure,row.action)
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop)return finish(failure.category,{stage:row.action})
continue}
await nap(listDelay())}
let rows=items
const staleRead=stale?await readRound(1):null
if(stale&&staleRead!==null)rows=null
else if(stale){try{rows=extractItems(await market.requestTransferItems())}catch(err){const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'list-items',category:failure.category})
const halt=throttleStop(failure,'list-items')
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop)return finish(failure.category,{stage:'list-items'})
rows=null}}
const relistDoor=askDoor({action:'relist',rows})
let awaited=false
const relist=relistDoor.verdict===ALLOWED
?await housekeeping('relisted',typeof market.relist==='function'?()=>{awaited=true
return market.relist(rows)}:null,(n)=>session.recordRelist(n),
'auctionIds'
)
:sayDoorSkip('relist',relistDoor)
if(relist?.reason)return finish(relist.reason,relist.detail)
let clearRows=rows
const clearRead=awaited?await readRound(1):null
if(awaited&&clearRead!==null)clearRows=null
else if(awaited){try{clearRows=extractItems(await market.requestTransferItems())}catch(err){const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'list-items',category:failure.category})
const halt=throttleStop(failure,'list-items')
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop)return finish(failure.category,{stage:'list-items'})
clearRows=null}}
const clearDoor=askDoor({action:'clear',rows:clearRows})
const unbooked=unbookedSales(clearRows)
const cleared=clearDoor.verdict===ALLOWED&&unbooked===0
?await housekeeping('cleared',typeof market.clear==='function'?()=>market.clear(clearRows):null,(n)=>session.recordCleared(n),
'itemIds'
)
:sayClearSkip(clearDoor,unbooked)
if(cleared?.reason)return finish(cleared.reason,cleared.detail)
await nap(cycleDelay())}
return finish('iteration-cap',{cap:iterationCap})}}}
