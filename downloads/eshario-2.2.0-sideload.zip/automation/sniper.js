import{MIN_PRICE,nextPrice} from '../features/price-grid.js'
import{createBreakSchedule} from './breaks.js'
import{itemIdsReceiptMatches,moveReceiptMatches} from './item-receipts.js'
import{ACTION,planSales} from './sell-plan.js'
import{purchasePolicyProblems,rankPurchaseCandidates} from './purchase-policy.js'
import{extractItems} from './seller.js'
import{isDoorRefusal,isLotRefusal,ALLOWED,UNKNOWN as DOOR_UNKNOWN} from '../adapter/action-door.js'
import{EA_STATUS} from '../adapter/error-codes.js'
import{ITEM_EVENTS} from '../adapter/item-events.js'
import{createLotFilter} from '../adapter/search.js'
import{THROTTLED,COUNTER_UNAVAILABLE,restMarketAfterThrottle,askBudgetRound,readBudgetRound,budgetStopName} from '../features/day-budget.js'
import{AFTER_BUY_DEFAULT,AFTER_BUY_PILE,afterBuyOf,SEARCH_REFRESH,SEARCH_REFRESH_KEY,SEARCH_REFRESH_DEFAULT,searchRefreshOf} from './options-input.js'
import{proceedsOf} from './pricing.js'
import{lootNameOf} from '../features/hunt-loot.js'
import{markListed} from './listed-mark.js'
import{bandPauseMs,spreadBand} from '../core/pace-jitter.js'
import{RUN_SPREAD_SHARE,TIME_LIMIT} from './stop-conditions.js'
const BID_STAGES=Object.freeze(['buy','bid'])
const RACE_LOST=Object.freeze({category:'gone',stop:false})
export const LOT_TAKEN=426
export const LOT_GONE_ON_MONEY=Object.freeze([EA_STATUS.PERMISSION_DENIED,EA_STATUS.NO_TRADE_EXISTS,LOT_TAKEN])
export const REFUSED_TOO_FAST=Object.freeze([521,512])
export function refusedTooFast(status){return REFUSED_TOO_FAST.includes(status)}
export function raceLostOnMoney(stage,status){return BID_STAGES.includes(stage)
&&LOT_GONE_ON_MONEY.includes(status)}
export function racePartsOf(marks){const at=(name)=>{const said=marks?.[name]
return Number.isFinite(said)?said:null}
const span=(from,to)=>{const a=at(from)
const b=at(to)
return a===null||b===null||b<a?null:b-a}
const toBid=span('answer','bid')
const draw=span('answer','drawn')
const gate=span('gateFrom','gateTo')
const hold=span('holdFrom','holdTo')
const known=[draw,gate,hold].reduce((sum,one)=>(one===null?sum:sum+one),0)
return{toBid,draw,gate,
gateBridge:span('gateFrom','gateRound'),gateWire:span('gateRound','gateTo'),
hold,rest:toBid===null?null:Math.max(0,toBid-known),wait:span('bid','done')}}
export const MAX_ITERATIONS=100_000
export const DEFAULT_SEARCH_BAND_MS=Object.freeze({minMs:1_500,maxMs:2_100})
export const DEFAULT_SEARCH_DELAY_MS=(DEFAULT_SEARCH_BAND_MS.minMs+DEFAULT_SEARCH_BAND_MS.maxMs)/2
export const DEFAULT_SEARCH_PAGE=1
export const SEARCH_PAGE_LOTS=21
export function pageLotsOf(criteria){const said=Number(criteria?.count)
return Number.isSafeInteger(said)&&said>0?said:SEARCH_PAGE_LOTS}
export const MIN_BID_FLOOR=150
export const MIN_BID_STEP=50
export const MIN_BID_TOP=1_000
export function minBidRefreshAt(iteration,aim=0){const ring=minBidRing(aim)
if(ring.length===0)return null
const step=Number.isSafeInteger(iteration)&&iteration>=0?iteration%ring.length:0
return ring[step]}
export function minBidRing(aim=0){const top=Number.isSafeInteger(aim)&&aim>0
?Math.min(MIN_BID_TOP,aim-1)
:MIN_BID_TOP
const steps=[]
for(let value=MIN_BID_FLOOR;value<=top;value+=MIN_BID_STEP)steps.push(value)
if(steps.length===0)return []
steps.push(null)
return steps}
export const MIN_BUY_FLOOR=200
export const MIN_BUY_STEP=50
export const MIN_BUY_TOP=1_000
export const MIN_BUY_AIM_SHARE=66
export const PAIR_MIN_BID_TOP=500
export function minBuyRing(aim=0){const share=Number.isSafeInteger(aim)&&aim>0
?Math.floor(aim*MIN_BUY_AIM_SHARE/100)
:MIN_BUY_TOP
const top=Math.min(MIN_BUY_TOP,share)
const steps=[]
for(let value=MIN_BUY_FLOOR;value<=top;value+=MIN_BUY_STEP)steps.push(value)
return steps}
export function pairMinBidRing(buy){const said=Number.isSafeInteger(buy)&&buy>0?buy:0
const top=Math.min(PAIR_MIN_BID_TOP,said-MIN_BID_STEP)
const steps=[]
for(let value=MIN_BID_FLOOR;value<=top;value+=MIN_BID_STEP)steps.push(value)
return steps}
export function pairRing(aim=0,ownBuy=null){const held=Number.isSafeInteger(ownBuy)&&ownBuy>0
const out=[]
if(held){for(const bid of pairMinBidRing(ownBuy))out.push({minBuy:null,minBid:bid})
return out}
for(const buy of minBuyRing(aim)){for(const bid of pairMinBidRing(buy))out.push({minBuy:buy,minBid:bid})}
return out}
export function pairRefreshAt(iteration,aim=0,ownBuy=null){const ring=pairRing(aim,ownBuy)
if(ring.length===0)return null
const step=Number.isSafeInteger(iteration)&&iteration>=0?iteration%ring.length:0
return ring[step]}
export const BID_REFRESH_TOP=15_000_000
export const BID_REFRESH_STEP=1_000
export const BID_REFRESH_RING=1000
export function bidRefreshAt(iteration,floor=0){const step=Number.isSafeInteger(iteration)&&iteration>=0
?iteration%BID_REFRESH_RING
:0
const said=BID_REFRESH_TOP-step*BID_REFRESH_STEP
const bottom=Number.isSafeInteger(floor)&&floor>0?floor:0
return said>bottom?said:BID_REFRESH_TOP}
export function narrowedToCap(criteria,cap,bidding){const said=criteria??{}
if(bidding===true)return{criteria:said,cap:null}
if(!Number.isSafeInteger(cap)||cap<=0)return{criteria:said,cap:null}
const form=Number(said.maxBuy)
const asked=Number.isSafeInteger(form)&&form>0?form:null
if(asked!==null&&asked<=cap)return{criteria:said,cap:null}
return{criteria:{...said,maxBuy:cap},cap}}
export function refreshedCriteria(criteria,iteration,mode=SEARCH_REFRESH_DEFAULT){const said=criteria??{}
const how=searchRefreshOf(mode)
if(how===SEARCH_REFRESH.OFF)return{criteria:said,bid:null,minBid:null,minBuy:null,how}
const spinMaxBid=(base)=>{const aim=targetCapOf(base)
const bid=bidRefreshAt(iteration,aim??0)
return{criteria:{...base,maxBid:bid},bid}}
if(how===SEARCH_REFRESH.PAIR){const ownBuy=Number(said.minBuy)
const seat=pairRefreshAt(iteration,targetCapOf(said)??0,Number.isSafeInteger(ownBuy)&&ownBuy>0?ownBuy:null)
if(seat===null){const bare=spinMaxBid(said)
return{criteria:bare.criteria,bid:bare.bid,minBid:null,minBuy:null,how}}
const paired=spinMaxBid(seat.minBuy===null?{...said,minBid:seat.minBid}:{...said,minBuy:seat.minBuy,minBid:seat.minBid})
return{criteria:paired.criteria,bid:paired.bid,minBid:seat.minBid,minBuy:seat.minBuy,how}}
if(how===SEARCH_REFRESH.MIN_BID){const aim=targetCapOf(said)??0
if(minBidRing(aim).length===0){const bare=spinMaxBid(said)
return{criteria:bare.criteria,bid:bare.bid,minBid:null,minBuy:null,how}}
let base=said
const minBid=minBidRefreshAt(iteration,aim)
if(minBid===null){const rest={...said}
delete rest.minBid
base=rest}
else base={...said,minBid}
const spun=spinMaxBid(base)
return{criteria:spun.criteria,bid:spun.bid,minBid,minBuy:null,how}}
const spun=spinMaxBid(said)
return{criteria:spun.criteria,bid:spun.bid,minBid:null,minBuy:null,how}}
export function searchPageOf(value){if(!Number.isFinite(value))return DEFAULT_SEARCH_PAGE
return Math.max(1,Math.trunc(value))}
export const DEFAULT_JITTER_MS=(DEFAULT_SEARCH_BAND_MS.maxMs-DEFAULT_SEARCH_BAND_MS.minMs)/2
export const SAFE_PAUSE_FLOOR_MS=1_200
export const MOVE_PAUSE_BAND_MS=Object.freeze({minMs:1_300,maxMs:1_900})
export const MOVE_PAUSE_MS=(MOVE_PAUSE_BAND_MS.minMs+MOVE_PAUSE_BAND_MS.maxMs)/2
export const MOVE_PAUSE_JITTER_MS=(MOVE_PAUSE_BAND_MS.maxMs-MOVE_PAUSE_BAND_MS.minMs)/2
export const BUY_PAUSE_BAND_MS=Object.freeze({minMs:1_000,maxMs:1_600})
export const BUY_PAUSE_MS=(BUY_PAUSE_BAND_MS.minMs+BUY_PAUSE_BAND_MS.maxMs)/2
export const BUY_PAUSE_JITTER_MS=(BUY_PAUSE_BAND_MS.maxMs-BUY_PAUSE_BAND_MS.minMs)/2
export const BUY_PAUSE_FLOOR_MS=BUY_PAUSE_BAND_MS.minMs
export const HUMAN_JITTER_MS=300
export const HUMAN_BREAK_SHARE=0.1
export function defaultRhythmProblems(band=DEFAULT_SEARCH_BAND_MS,
jitterMs=DEFAULT_JITTER_MS,floorMs=SAFE_PAUSE_FLOOR_MS){const bad=[]
const min=Number(band?.minMs)
const max=Number(band?.maxMs)
if(!Number.isFinite(min)||!Number.isFinite(max)||min>max)return['band']
if(min<floorMs)bad.push('band-min')
const middle=(min+max)/2
const jitter=Number.isFinite(jitterMs)?Math.abs(jitterMs):0
if(middle-jitter<floorMs)bad.push('jitter')
return bad}
export const WORK_BAND_MS=Object.freeze({minMs:270_000,maxMs:360_000})
export const BREAK_BAND_MS=Object.freeze({minMs:120_000,maxMs:180_000})
export const WORK_MS=5*60_000
export const BREAK_MS=150_000
export const SESSION_MS=15*60_000
export const SESSION_PHASE=Object.freeze({WORK:'work',BREAK:'break',ASK:'ask'})
export const SESSION_OVER='session-over'
export const MAX_PER_SEARCH_DEFAULT=1
export const MATCH_GUARD_DEFAULT=5
export const TOO_MANY_MATCHES='too-many-matches'
export const STANDARD_UNASSIGNED_LIMIT=5
const TRACKED_BID_LIMIT=1000
export function rollJitter(spread,roll){if(!Number.isFinite(spread)||spread<=0)return 0
let value=0
try{value=Number(roll?.())}catch{value=0}
if(!Number.isFinite(value))value=0
const frac=Math.min(1,Math.max(0,value))
return Math.round((frac*2-1)*Math.abs(spread))}
export function pauseBandOf(base,spread,floorMs=0){const said=Number.isFinite(base)&&base>0?base:0
const half=Number.isFinite(spread)&&spread>0?Math.abs(spread):0
const floor=Number.isFinite(floorMs)&&floorMs>0?floorMs:0
const middle=Math.max(said,floor)
const low=Math.max(floor,middle-half)
return Object.freeze({minMs:Math.round(low),maxMs:Math.round(Math.max(low,middle+half))})}
export function extractLots(data){if(data
&&typeof data==='object'
&&!Array.isArray(data)
&&Array.isArray(data.items)){return data.items}
return null}
export function receiptShapeOf(value){if(value===null||value===undefined)return String(value)
if(Array.isArray(value))return `array(${value.length})`
if(typeof value!=='object')return typeof value
const parts=[]
for(const key of Object.keys(value).slice(0,8)){let said='?'
try{const one=value[key]
said=one===null?'null':(Array.isArray(one)?`array(${one.length})`:typeof one)}catch{said='throw'}
parts.push(`${key}=${said}`)}
return parts.length===0?'{}':parts.join(' ')}
export function bidReceiptOf(data){if(data
&&typeof data==='object'
&&!Array.isArray(data)
&&Number.isSafeInteger(data.coins)
&&data.coins>=0
&&Array.isArray(data.items)
&&data.items.length>0
&&data.items.every((item)=>item&&typeof item==='object')){return{coins:data.coins,items:data.items}}
if(data
&&typeof data==='object'
&&!Array.isArray(data)
&&Array.isArray(data.itemIds)
&&data.itemIds.length>0){return{coins:null,items:[],itemIds:[...data.itemIds]}}
return null}
export const PROVEN_REFUSALS=Object.freeze(['gone','out-of-coins','captcha','fatal','throttled','card-throttled'])
export function bidOutcome(answer){const category=typeof answer?.category==='string'?answer.category:null
if(category!==null)return PROVEN_REFUSALS.includes(category)?'refused':'unknown'
const receipt=answer?.receipt
return receipt===null||receipt===undefined?'unknown':'bought'}
export function unassignedCountOf(data){return data&&typeof data==='object'&&!Array.isArray(data)
&&Array.isArray(data.items)
?data.items.length
:null}
export function auctionOf(lot){if(typeof lot?.getAuctionData==='function'){try{const auction=lot.getAuctionData()
if(auction&&typeof auction==='object') return auction}catch{return null}}
return null}
function auctionTradeId(auction){const value=auction?.tradeId
if(typeof value==='number'&&Number.isFinite(value))return String(value)
if(typeof value==='string'&&value!=='')return value
return null}
function auctionIsOutbid(auction){if(typeof auction?.isOutbid==='function'){try{return auction.isOutbid()===true}catch{return false}}
return auction?.bidState==='outbid'}
export function buyNowPriceOf(lot){const value=auctionOf(lot)?.buyNowPrice
return typeof value==='number'&&Number.isFinite(value)&&value>0?value:null}
export function secondsLeftOf(lot){const value=auctionOf(lot)?.expires
return typeof value==="number"&&Number.isFinite(value)&&value>=0?value:-1}
export function currentBidOf(lot){const value=auctionOf(lot)?.currentBid
return typeof value==='number'&&Number.isFinite(value)&&value>=0?value:null}
function startingBidOf(lot){const value=auctionOf(lot)?.startingBid
return typeof value==='number'&&Number.isFinite(value)&&value>0?value:null}
export function pileOrNull(value){if(typeof value==='number'&&Number.isFinite(value)) return value
if(typeof value==='string'&&value!=='') return value
return null}
export const CAP_TARGET='target-cap'
export const CAP_OPTIONS='max-price'
export function targetCapOf(criteria){const said=Number(criteria?.maxBuy)
return Number.isSafeInteger(said)&&said>0?said:null}
export function buyCeilingOf(criteria,maxPrice){const settings=Number.isFinite(maxPrice)?maxPrice:Infinity
const said=targetCapOf(criteria)
const goal=said===null?Infinity:said
if(said===null)return{cap:settings,goal,source:Number.isFinite(settings)?CAP_OPTIONS:null}
return said<=settings?{cap:said,goal,source:CAP_TARGET}:{cap:settings,goal,source:CAP_OPTIONS}}
export function priceCapMissing(filters,maxPrice){const list=Array.isArray(filters)?filters.filter(Boolean):[]
return list.length===0||list.some((one)=>!Number.isFinite(buyCeilingOf(one,maxPrice).cap))}
export function bidPriceFor(lot,maxBid,liveMin=null){if(!Number.isFinite(maxBid)||maxBid<=0)return null
const current=currentBidOf(lot)
if(current===null)return null
const next=current===0?startingBidOf(lot):nextPrice(current)
if(next===null||next>maxBid)return null
if(next<MIN_PRICE&&Number.isSafeInteger(liveMin)&&next<liveMin)return null
return next}
const statusOf=(err)=>(typeof err?.status==='number'?err.status:null)
const isMoney=(value)=>Number.isSafeInteger(value)&&value>=0
export function overflowSafetyProblems(options={},stop={}){if(options?.allowUnassignedOverflow!==true)return[]
let limits={}
try{limits=typeof stop?.limits==='function'?stop.limits():{}}catch{limits={}}
const problems=[]
const maxPurchases=limits?.maxPurchases
if(!Number.isSafeInteger(maxPurchases)||maxPurchases<=0){problems.push('maxPurchases')}
return[...new Set(problems)]}
function cardNumbersOf(criteria){const raw=criteria?.defId
if(!Array.isArray(raw))return[]
const out=[]
for(const value of raw){const id=Number(value)
if(!Number.isSafeInteger(id)||id<=0)continue
if(!out.includes(id))out.push(id)}
return out}
export function searchRing(filters){const list=Array.isArray(filters)?filters:[]
const ring=[]
for(let index=0;index<list.length;index+=1){const criteria=list[index]
const cards=cardNumbersOf(criteria)
if(cards.length<2){ring.push({set:index,defId:cards.length===1?cards[0]:null,criteria})
continue}
for(const id of cards)ring.push({set:index,defId:id,criteria:{...criteria,defId:[id]}})}
return ring}
export function createSniper(deps={}){const{market,session,stop,clock,filters}=deps
const dice=typeof deps.random==='function'?deps.random:Math.random
if(!market||typeof market.searchTransferMarket!=='function'||typeof market.bid!=='function'){throw new Error('sniper: нужен рынок с searchTransferMarket и bid')}
if(!session
||typeof session.snapshot!=='function'
||typeof session.recordAction!=='function'
){throw new Error('sniper: нужна сессия')}
if(!stop
||typeof stop.shouldStop!=='function'
||typeof stop.shouldStopBeforePurchase!=='function'
||typeof stop.shouldStopBeforeBid!=='function'
){throw new Error('sniper: нужны условия остановки')}
if(!clock||typeof clock.sleep!=='function') throw new Error('sniper: нужны часы (правило 6 NIGHT_BRIEF)')
if(!Array.isArray(filters)||filters.length===0) throw new Error('sniper: нужен хотя бы один набор фильтров')
const wire=deps.wire&&typeof deps.wire.calls==='function'&&typeof deps.wire.lastSent==='function'
?deps.wire
:null
const openWidePage=()=>{if(typeof deps.widePage!=='function')return null
let back=null
try{back=deps.widePage()}catch{return null}
return typeof back==='function'?back:null}
const pageViews=typeof deps.pageViews==='function'?deps.pageViews:null
const tellScreen=(which)=>{if(pageViews===null)return
try{const door=pageViews()
if(door&&typeof door[which]==='function')door[which]()}catch{
}}
const ring=searchRing(filters)
const ringSearches=ring.map(()=>0)
let lastSearchAt=null
const handPort=typeof deps.handOnScreen==='function'?deps.handOnScreen:null
const handOnScreen=()=>{if(handPort===null)return false
try{return handPort()===true}catch{return false}}
let yields=0
let yielding=false
let searchCounterRetried=false
let overTargetCap=0
let overMaxPrice=0
let lastLots=null
let lastAffordable=null
let lastCeiling=null
let lastBidRefresh=null
let lastPageFull=null
let pageFulls=0
let lastFresh=null
let seenTrades=null
const triedLots=new Map()
const lotKeyOf=(lot)=>auctionTradeId(auctionOf(lot))
const rememberTried=(lot,at)=>{const key=lotKeyOf(lot)
if(key===null)return
if(!triedLots.has(key))triedLots.set(key,at)}
const notTried=(lot)=>{const key=lotKeyOf(lot)
return key===null||!triedLots.has(key)}
let lastBidSent=null
let lastMinBidSent=null
let lastMinBuySent=null
let lastSentSeen=false
let lastSentLots=null
let lastBidDrift=null
let dryStreak=0
let emptyStreak=0
let misses=0
let lastMiss=null
let linkLost=0
let lastLink=null
let lastFail=null
const noteFail=(stage,status)=>{lastFail={stage:typeof stage==='string'&&stage!==''?stage:'other',
status:Number.isFinite(status)?status:null,
search:session.snapshot().searches}
return lastFail}
const RACE_KEEP=24
let raceMarks=null
let racesLost=0
let raceSeq=0
let lastRace=null
const raceLog=[]
const raceAnswer=()=>{raceMarks={answer:clock.now(),nth:0}}
const raceTry=()=>{if(raceMarks===null)return
raceMarks.nth+=1
for(const key of['gateFrom','gateRound','gateTo','holdFrom','holdTo','bid','done'])delete raceMarks[key]}
const raceMark=(name)=>{if(raceMarks!==null)raceMarks[name]=clock.now()}
const raceDone=(outcome,stage)=>{if(raceMarks===null)return
if(outcome==='lost')racesLost+=1
raceSeq+=1
lastRace=Object.freeze({seq:raceSeq,outcome,stage,nth:raceMarks.nth,...racePartsOf(raceMarks)})
raceLog.push(lastRace)
if(raceLog.length>RACE_KEEP)raceLog.shift()}
const TOO_FAST_STOP=Object.freeze({category:THROTTLED,stop:true})
const judgeFailure=(stage,status)=>{if(raceLostOnMoney(stage,status))return RACE_LOST
if(refusedTooFast(status)){session.recordFailure(status)
return TOO_FAST_STOP}
return session.recordFailure(status)}
const options=deps.options??{}
const coinBalance=typeof deps.coinBalance==='function'?deps.coinBalance:null
const budget=deps.budget??null
const budgetSearch=()=>(budget!==null&&typeof budget.search==='function'?budget.search():null)
const budgetCall=(count=1)=>(budget!==null&&typeof budget.call==='function'?budget.call(count):null)
const budgetWarm=(count)=>(budget!==null&&typeof budget.warm==='function'
?budget.warm(count)
:Promise.resolve(null))
const budgetSettle=async(opts)=>{if(budget===null||typeof budget.settle!=='function')return null
try{return await budget.settle(opts)}catch{return null}}
const budgetDoors={warm:(count)=>budgetWarm(count),take:(count)=>budgetCall(count),
settle:()=>budgetSettle({market:false})}
const saidReason=(reason)=>budgetStopName(reason)??reason
const spendRound=(count=1)=>askBudgetRound(budgetDoors,count)
const readRound=(count=1)=>readBudgetRound(budgetDoors,count)
const buyRatePort=()=>{const said=typeof deps.buyRate==='function'?deps.buyRate():deps.buyRate
return said&&typeof said.take==='function'?said:null}
const takeBidSlot=()=>{const rate=buyRatePort()
return rate===null?COUNTER_UNAVAILABLE:rate.take()}
const releaseBidSlot=()=>{const rate=buyRatePort()
if(rate!==null&&typeof rate.release==='function')rate.release()}
const settleBidSlot=async()=>{const rate=buyRatePort()
if(rate===null||typeof rate.settle!=='function')return null
try{const said=await rate.settle()
return typeof said==='string'?said:null}catch{return COUNTER_UNAVAILABLE}}
const lotFilters=new Map()
const filterFor=(index)=>{if(lotFilters.has(index))return lotFilters.get(index)
const criteria=ring[index]?.criteria
const sieve=typeof market.lotFilter==='function'
?market.lotFilter(criteria)
:createLotFilter(criteria)
lotFilters.set(index,sieve)
return sieve}
const rotationState=()=>({size:ring.length,
seats:ring.map((seat,index)=>({set:seat.set,defId:seat.defId,searches:ringSearches[index]}))})
function ratingOf(item){let raw=null
try{raw=Number(item?.rating)}catch{return null}
return Number.isSafeInteger(raw)&&raw>0?raw:null}
const filterState=()=>{const fields=new Set(),unsupported=new Set(),reasons={}
let seen=0,kept=0
for(const sieve of lotFilters.values()){let one=null
try{one=sieve.state()}catch{one=null}
if(one===null)continue
for(const name of one.fields)fields.add(name)
for(const name of one.unsupported)unsupported.add(name)
for(const[name,count]of Object.entries(one.reasons))reasons[name]=(reasons[name]??0)+count
seen+=one.seen
kept+=one.kept}
return{fields:[...fields].sort(),unsupported:[...unsupported].sort(),
seen,kept,dropped:seen-kept,reasons,
lastLots,lastAffordable,lastCeiling,lastBidRefresh,lastPageFull,pageFulls,racesLost,dryStreak,emptyStreak,
lastFresh,lastBidSent,lastMinBidSent,lastMinBuySent,lastSentSeen,lastBidDrift:lastBidDrift===null?null:{...lastBidDrift},
lastFail:lastFail===null?null:{...lastFail},
pile:pileGauge(),
linkLost,lastLink:lastLink===null?null:{...lastLink},
lastRace,
answers,
overTargetCap,overMaxPrice,
misses,miss:lastMiss===null?null:{...lastMiss}}}
const onEvent=typeof deps.onEvent==='function'?deps.onEvent:()=>{}
const emit=(name,payload)=>{try{onEvent(name,payload)}catch{
}}
const maxPrice=Number.isFinite(options.maxPrice)?options.maxPrice:Infinity
const searchDelayGiven=Number.isFinite(options.searchDelayMs)?options.searchDelayMs:null
const searchDelayMs=searchDelayGiven!==null?searchDelayGiven:DEFAULT_SEARCH_DELAY_MS
const buyDelayGiven=Number.isFinite(options.buyDelayMs)?options.buyDelayMs:null
const jitterGiven=Number.isFinite(options.jitterMs)?options.jitterMs:null
const jitterMs=jitterGiven!==null?jitterGiven
:(searchDelayGiven!==null?HUMAN_JITTER_MS:DEFAULT_JITTER_MS)
const buyJitterMs=jitterGiven!==null?jitterGiven:HUMAN_JITTER_MS
const page=searchPageOf(options.page)
const refreshMode=searchRefreshOf(options[SEARCH_REFRESH_KEY])
const iterationCap=Number.isFinite(options.maxIterations)?options.maxIterations:MAX_ITERATIONS
const maxBid=Number.isFinite(options.maxBid)?options.maxBid:0
const allowUnassignedOverflow=options.allowUnassignedOverflow===true
const purchasePolicy=options.purchasePolicy??{}
const policyProblems=purchasePolicyProblems(options.purchasePolicy)
if(policyProblems.length>0){throw new Error(`sniper: неверная purchase policy: ${policyProblems.join(', ')}`)}
const overflowProblems=overflowSafetyProblems(options,stop)
if(overflowProblems.length>0){throw new Error(`sniper: overflow требует безопасные пределы: ${overflowProblems.join(', ')}`)}
const maxPerSearch=Number.isSafeInteger(options.maxPerSearch)&&options.maxPerSearch>0
?options.maxPerSearch
:MAX_PER_SEARCH_DEFAULT
const matchGuard=options.matchGuard===false
?0
:(Number.isSafeInteger(options.matchGuard)&&options.matchGuard>=0
?options.matchGuard
:MATCH_GUARD_DEFAULT)
const explicitMoveTo=pileOrNull(options.moveTo)
const immediateList=options.immediateList?.enabled===true
?options.immediateList
:null
if(immediateList&&explicitMoveTo!==null){throw new Error('sniper: immediate list несовместим с moveTo')}
const afterBuy=afterBuyOf(options.afterBuy)
const moveTo=explicitMoveTo!==null
?explicitMoveTo
:(immediateList!==null?null:AFTER_BUY_PILE[afterBuy])
if(immediateList
&&(typeof market.requestMarketData!=='function'
||typeof market.list!=='function'
)){throw new Error('sniper: immediate list требует requestMarketData и list')}
const breakInput=options.breaks??{}
const breakBandOf=(value,ours)=>{const ms=Number(value)
if(!Number.isFinite(ms)||ms<=0)return ours
return Object.freeze({minMs:Math.round(ms*(1-HUMAN_BREAK_SHARE)),
maxMs:Math.round(ms*(1+HUMAN_BREAK_SHARE))})}
const breakZeroOf=(value)=>(Number(value)===0?0:undefined)
const breaks=createBreakSchedule({...breakInput,
workMs:breakZeroOf(breakInput.workMs),restMs:breakZeroOf(breakInput.restMs),
workBandMs:breakBandOf(breakInput.workMs,WORK_BAND_MS),
restBandMs:breakBandOf(breakInput.restMs,BREAK_BAND_MS),
random:dice})
const runLimitMs=(()=>{let said={}
try{said=typeof stop?.limits==='function'?stop.limits():{}}catch{said={}}
const ms=Number(said?.maxDurationMs)
return Number.isFinite(ms)&&ms>0?ms:null})()
const sessionGiven=Number.isFinite(options.sessionMs)&&options.sessionMs>0
const sessionBand=spreadBand(SESSION_MS,RUN_SPREAD_SHARE)
const sessionMs=sessionGiven
?options.sessionMs
:(runLimitMs??bandPauseMs(sessionBand.minMs,sessionBand.maxMs,dice))
const sessionFromLimit=!sessionGiven&&runLimitMs!==null
const startedAt=clock.now()
let askContinue=false
let iteration=0
let cursor=0
let answers=0
let running=false
let cancelled=false
let wakeCall=null
let wakeSignal=null
const armWake=()=>{wakeSignal=new Promise((resolve)=>{wakeCall=resolve})}
armWake()
const wakeUp=()=>{if(wakeCall===null)return
const call=wakeCall
wakeCall=null
call()}
const nap=(ms)=>{if(cancelled)return Promise.resolve()
return Promise.race([clock.sleep(ms),wakeSignal])}
const acceptedBids=new Map()
const rememberAcceptedBid=(lot,price)=>{const tradeId=auctionTradeId(auctionOf(lot))
if(tradeId===null)return
acceptedBids.delete(tradeId)
acceptedBids.set(tradeId,price)
while(acceptedBids.size>TRACKED_BID_LIMIT){acceptedBids.delete(acceptedBids.keys().next().value)}}
const reportObservedOutbids=(lots)=>{for(const lot of lots){const auction=auctionOf(lot)
const tradeId=auctionTradeId(auction)
if(tradeId===null||!acceptedBids.has(tradeId)||!auctionIsOutbid(auction))continue
const price=acceptedBids.get(tradeId)
acceptedBids.delete(tradeId)
session.recordOutbid()
emit('outbid',{price,item:lot,tradeId})}}
const searchesLeftToday=()=>{if(budget===null||typeof budget.searchesLeft!=='function')return null
try{const said=budget.searchesLeft()
return Number.isSafeInteger(said)&&said>=0?said:null}catch{return null}}
const hourAdviceNow=()=>{if(budget===null||typeof budget.hourAdvice!=='function')return null
try{const said=budget.hourAdvice()
return said&&typeof said==='object'?said:null}catch{return null}}
const nextRestAt=()=>{if(!breaks.isEnabled())return startedAt+sessionMs
return Math.min(startedAt+sessionMs,
startedAt+breaks.workEndsAt(Math.max(0,clock.now()-startedAt)))}
const sessionState=()=>{const now=clock.now()
const left=searchesLeftToday()
if(askContinue){return{startedAt,phase:SESSION_PHASE.ASK,nextChangeAt:startedAt+sessionMs,
askContinue:true,searchesLeftToday:left,yielding,yields}}
const rest=breaks.shouldRest(Math.max(0,now-startedAt))
return rest.rest
?{startedAt,phase:SESSION_PHASE.BREAK,nextChangeAt:now+rest.forMs,askContinue:false,searchesLeftToday:left,yielding,yields}
:{startedAt,phase:SESSION_PHASE.WORK,nextChangeAt:nextRestAt(),askContinue:false,searchesLeftToday:left,yielding,yields}}
const summaryState=()=>{const stats=session.stats()
const caught=session.isDryRun()?stats.wouldBuy:stats.purchases
const priced=Number.isSafeInteger(stats.listings)?stats.listings:0
const off=immediateList===null?'no-sale-price':(priced<caught?'partial':null)
return{caught,spent:stats.spent,lastSearchAt,
expectedProfit:off===null&&caught>0?proceedsOf(stats.listedValue)-stats.spent:null,
expectedProfitOff:caught===0?'nothing-caught':off,
searchesLeft:searchesLeftToday(),
hourAdvice:hourAdviceNow()}}
const buyPause=()=>{
const band=buyDelayGiven!==null
?pauseBandOf(buyDelayGiven,buyJitterMs,BUY_PAUSE_FLOOR_MS)
:pauseBandOf(BUY_PAUSE_MS,BUY_PAUSE_JITTER_MS,BUY_PAUSE_FLOOR_MS)
return nap(bandPauseMs(band.minMs,band.maxMs,dice))}
const searchPause=(base)=>{const band=pauseBandOf(base,jitterMs,SAFE_PAUSE_FLOOR_MS)
return nap(bandPauseMs(band.minMs,band.maxMs,dice))}
const movePause=()=>nap(MOVE_PAUSE_MS+rollJitter(MOVE_PAUSE_JITTER_MS,dice))
const restMarket=(stage)=>{const done=restMarketAfterThrottle(budget)
if(done)emit('rest-market',{stage})
return done}
const throttleStop=(failure,stage)=>{if(failure?.category!==THROTTLED)return null
restMarket(stage)
return{reason:THROTTLED,detail:{stage}}}
const reserveAction=async(stage)=>{if(session.isDryRun())return null
if(cancelled)return{reason:'cancelled',detail:{stage}}
const before=typeof stop.shouldStopBeforeAction==='function'
?stop.shouldStopBeforeAction(session.snapshot())
:stop.shouldStop(session.snapshot())
if(before.stop&&before.reason!=='search-limit'){return{reason:before.reason,detail:{...(before.detail??{}),stage}}}
let bidSlot=false
if(BID_STAGES.includes(stage)){const hour=takeBidSlot()
if(hour!==null){emit('failure',{stage,category:hour})
return{reason:hour,detail:{stage}}}
bidSlot=true
const settled=await settleBidSlot()
if(settled!==null){releaseBidSlot()
emit('failure',{stage,category:settled})
return{reason:settled,detail:{stage,door:'settle'}}}}
const money=await spendRound(1)
if(money!==null){if(bidSlot)releaseBidSlot()
emit('failure',{stage,category:money.reason})
return{reason:saidReason(money.reason),detail:{stage,door:money.door}}}
if(cancelled){if(bidSlot)releaseBidSlot()
return{reason:'cancelled',detail:{stage}}}
session.recordAction()
return null}
const refreshCoins=(stage)=>{if(session.isDryRun())return null
let value
if(coinBalance===null){value=session.snapshot()?.coins}else{try{value=coinBalance()}catch{value=null}}
if(!isMoney(value)){return{reason:'bad-state',detail:{field:'coins',stage}}}
session.setCoins(value)
return null}
const unknownWrite=(price,category,stage,spend)=>{const before=session.snapshot()?.coins
session.recordUnknown(price,spend)
const expected=isMoney(before)&&isMoney(price)?Math.max(0,before-price):null
let live=null
if(coinBalance===null){live=session.snapshot()?.coins}else{try{live=coinBalance()}catch{live=null}}
const seen=isMoney(live)?live:null
emit('bid-unknown',{stage,price,category,expected,live:seen,matched:expected!==null&&seen!==null&&seen===expected})
return{reason:'bad-state',detail:{stage,field:'bid-outcome',category,price,expected,live:seen}}}
const moveBought=async(lot)=>{if(!moveTo||typeof market.move!=='function') return{moved:false}
await movePause()
const reserved=await reserveAction('move')
if(reserved)return reserved
try{const receipt=await market.move([lot],moveTo)
if(!moveReceiptMatches(receipt,[lot])){return{reason:'bad-state',detail:{stage:'move',field:'itemIds'}}}
session.recordMove(1)
emit('moved',{pile:moveTo,afterBuy})
return{moved:true}}catch(err){
if(isDoorRefusal(err)){emit('door',{stage:'move',verdict:err.door?.verdict,reason:err.door?.reason,fits:err.door?.fits,need:err.door?.need})
return{moved:false}}
const failure=judgeFailure('move',noteFail('move',statusOf(err)).status)
emit('failure',{stage:'move',category:failure.category})
const halt=throttleStop(failure,'move')
if(halt)return halt
return['captcha','fatal','out-of-coins'].includes(failure.category)
?{reason:failure.category,detail:{stage:'move'}}
:{moved:false}}}
const listBought=async(lot,buyPrice)=>{if(immediateList===null)return null
let stage='market-data'
const permit=await readRound(1)
if(permit!==null)return{reason:saidReason(permit.reason),detail:{stage,door:permit.door}}
try{const response=await market.requestMarketData(lot)
if(!response
||typeof response!=='object'
||Array.isArray(response)
||!Array.isArray(response.marketData)){return{reason:'bad-state',detail:{stage,field:'marketData'}}}
emit('market-data',{item:lot})
if(cancelled) return{reason:'cancelled'}
const row=planSales([lot],{...immediateList,buyPrice:()=>buyPrice})[0]
if(row?.action!==ACTION.LIST){return{reason:'bad-state',detail:{stage:'immediate-list',field:row?.reason??'price'}}}
if(session.isDryRun()){session.recordListing(row.price)
emit('would-sell',{action:ACTION.LIST,price:row.price,item:lot,clamped:row.clamped??null})
return null}
let rows=null
if(typeof market.requestTransferItems==='function'){stage='transfer-list'
const listSlot=budgetCall(1)
if(listSlot!==null)return{reason:listSlot,detail:{stage}}
const listSettled=await budgetSettle({market:false})
if(listSettled!==null)return{reason:listSettled,detail:{stage}}
rows=extractItems(await market.requestTransferItems())}
const blocked=await reserveAction('immediate-list')
if(blocked)return blocked
stage='immediate-list'
const receipt=await market.list(lot,row.startingBid??row.price,row.price,3600,{fresh:true,rows})
if(!itemIdsReceiptMatches(receipt,[lot])){return{reason:'bad-state',detail:{stage,field:'itemIds'}}}
session.recordListing(row.price)
markListed(lot)
emit('listed',{price:row.price,item:lot,clamped:row.clamped??null})
return null}catch(err){
if(isDoorRefusal(err)){emit('door',{stage:'immediate-list',verdict:err.door?.verdict,reason:err.door?.reason,fits:err.door?.fits,need:err.door?.need})
return{reason:'list-blocked',detail:{stage:'immediate-list',door:err.door?.reason??null}}}
const failure=judgeFailure(stage,noteFail(stage,statusOf(err)).status)
emit('failure',{stage,category:failure.category,price:buyPrice,item:lot})
const halt=throttleStop(failure,stage)
if(halt)return halt
const reason=['captcha','fatal','out-of-coins'].includes(failure.category)
?failure.category
:'bad-state'
return{reason,detail:{stage}}}}
const askDoor=(request)=>(typeof market.review==='function'
?market.review(request)
:{verdict:DOOR_UNKNOWN,reason:'no-judge',need:1,fits:null})
const liveBidFloor=()=>{const said=askDoor({action:'bid-grid'})
return said?.verdict===ALLOWED&&Number.isSafeInteger(said?.floor)?said.floor:null}
const doorStop=(stage,review)=>{emit('door',{stage,verdict:review?.verdict,reason:review?.reason,
fits:review?.fits,need:review?.need,used:review?.used,size:review?.size,coins:review?.coins})
return isLotRefusal(review)
?null
:{reason:stage==='bid'?'bid-blocked':'buy-blocked',detail:{stage,door:review?.reason??null}}}
const readUnassigned=async()=>{if(typeof market.requestUnassignedItems!=='function'){emit('failure',{stage:'unassigned',category:'unavailable'})
return{stop:{reason:'unassigned-unavailable',detail:{stage:'unassigned'}},count:null}}
const permit=await readRound(1)
raceMark('gateRound')
if(permit!==null){emit('failure',{stage:'unassigned',category:permit.reason})
return{stop:{reason:saidReason(permit.reason),detail:{stage:'unassigned',door:permit.door}},count:null}}
try{const count=unassignedCountOf(await market.requestUnassignedItems())
if(count===null){emit('failure',{stage:'unassigned',category:'bad-shape'})
return{stop:{reason:'unassigned-unavailable',detail:{stage:'unassigned'}},count:null}}
return{stop:null,count}}catch(err){const failure=judgeFailure('unassigned',noteFail('unassigned',statusOf(err)).status)
emit('failure',{stage:'unassigned',category:failure.category})
const halt=throttleStop(failure,'unassigned')
if(halt)return{stop:halt,count:null}
const reason=['captcha','fatal','out-of-coins'].includes(failure.category)
?failure.category
:'unassigned-unavailable'
return{stop:{reason,detail:{stage:'unassigned'}},count:null}}}
let pileDrift=0
let pileFeed=null
const PILE_PURCHASED='PURCHASED'
let pileGauge=()=>({'прочитано':null,'событиями':pileDrift,'своих':0,'счёт':null})
const applyPileEvent=(event)=>{const name=event?.name
if(name===ITEM_EVENTS.unassigned){const added=Array.isArray(event?.items)?event.items.length:0
if(added>0)pileDrift+=added
return}
if(name===ITEM_EVENTS.move&&event?.from===PILE_PURCHASED){const gone=Array.isArray(event?.ids)?event.ids.length:0
if(gone>0)pileDrift-=gone}}
const openPileFeed=()=>{if(typeof deps.pileFeed!=='function')return null
let stop=null
try{stop=deps.pileFeed((event)=>{applyPileEvent(event)})}catch{return null}
return typeof stop==='function'?stop:null}
const linkLostStop=async(guard,price,category,stage)=>{
const before=session.snapshot()?.coins
let live=null
if(coinBalance===null){live=before}else{try{live=coinBalance()}catch{live=null}}
const spent=isMoney(before)&&isMoney(price)&&isMoney(live)&&price>0&&live===Math.max(0,before-price)
if(spent){const said=unknownWrite(price,category,stage,stage==='buy')
return{reason:said.reason,detail:said.detail}}
const held=typeof guard?.count==='function'?guard.count():null
const said=await readUnassigned()
if(said.stop!==null)return said.stop
const grew=held!==null&&said.count>held
linkLost+=1
lastLink={stage,category,price,pile:said.count,search:answers}
emit('link-lost',{stage,category,price,pile:said.count})
const wrote=unknownWrite(price,category,stage,grew)
return{reason:wrote.reason,detail:wrote.detail}}
const unassignedGate=()=>{let seen=null
let zero=0
let mine=0
const guard=async(allowOverflow)=>{if(allowOverflow===true)return null
if(seen===null){const beforeAsk=pileDrift
const said=await readUnassigned()
if(said.stop!==null)return said.stop
seen=said.count
zero=beforeAsk}
const count=Math.max(0,seen+(pileDrift-zero)+mine)
return count>=STANDARD_UNASSIGNED_LIMIT
?{reason:'unassigned-full',detail:{stage:'unassigned',count,limit:STANDARD_UNASSIGNED_LIMIT}}
:null}
guard.mine=(stayed,real)=>{if(real===true&&pileFeed!==null){mine+=1
return}
if(stayed===true)mine+=1}
pileGauge=()=>({'прочитано':seen,'событиями':pileDrift-zero,'своих':mine,
'счёт':seen===null?null:Math.max(0,seen+(pileDrift-zero)+mine)})
guard.count=()=>(seen===null?null:Math.max(0,seen+(pileDrift-zero)+mine))
guard.resync=(count)=>{if(!Number.isSafeInteger(count)||count<0)return
seen=count
zero=pileDrift
mine=0}
guard.forget=()=>{if(pileFeed!==null)return
seen=null
zero=0
mine=0}
return guard}
const finish=(rawReason,rawDetail)=>{running=false
const merged=rawReason===TIME_LIMIT&&sessionFromLimit
if(merged)askContinue=true
const reason=merged?SESSION_OVER:rawReason
const detail=merged?{askContinue:true,sessionMs,...(rawDetail??{})}:rawDetail
if(pileFeed!==null){try{pileFeed()}catch{
}
pileFeed=null}
yielding=false
const result={reason,detail:detail??null,stats:session.stats(),iterations:iteration,filter:filterState(),
session:sessionState(),summary:summaryState(),rotation:rotationState()}
emit('stopped',result)
return result}
return{isRunning:()=>running,
cancel(){cancelled=true
wakeUp()},
filterAt:(n)=>ring[n%ring.length].criteria,
filterState,
rotationState,
sessionState,
summaryState,
raceState:()=>raceLog.map((one)=>({...one})),
async run(){running=true
cancelled=false
triedLots.clear()
armWake()
pileDrift=0
linkLost=0
lastLink=null
pileFeed=openPileFeed()
const guardPile=unassignedGate()
const rate=buyRatePort()
if(rate!==null&&typeof rate.load==='function'){try{await rate.load()}catch{
}}
const settleCycle=async()=>{if(cancelled)return{reason:'cancelled'}
const after=stop.shouldStop(session.snapshot())
if(after.stop)return{reason:after.reason,detail:after.detail}
if(clock.now()-startedAt>=sessionMs){askContinue=true
return{reason:SESSION_OVER,detail:{askContinue:true,sessionMs}}}
if(iteration+1>=iterationCap)return{reason:'iteration-cap',detail:{cap:iterationCap}}
await searchPause(searchDelayMs)
return null}
for(;iteration<iterationCap;iteration+=1){if(cancelled) return finish('cancelled')
const cycleCoins=refreshCoins('cycle')
if(cycleCoins)return finish(cycleCoins.reason,cycleCoins.detail)
const before=stop.shouldStop(session.snapshot())
if(before.stop)return finish(before.reason,before.detail)
if(clock.now()-startedAt>=sessionMs){askContinue=true
return finish(SESSION_OVER,{askContinue:true,sessionMs})}
const rest=breaks.shouldRest(clock.now()-startedAt)
if(rest.rest){session.recordRest()
emit('rest',{forMs:rest.forMs,cycle:rest.cycle})
await nap(rest.forMs)
continue}
const seatIndex=cursor%ring.length
const seat=ring[seatIndex]
const criteria=seat.criteria
const marketDoor=askDoor({action:'market'})
if(marketDoor?.verdict!==ALLOWED){const reason=marketDoor?.reason==='market-off'?'market-off':'market-unreadable'
emit('door',{stage:'market',verdict:marketDoor?.verdict,reason:marketDoor?.reason})
return finish(reason,{stage:'search',door:marketDoor?.reason??null})}
if(handOnScreen()){if(!yielding){yielding=true
yields+=1
emit('waiting',{stage:'search',reason:'hand-on-screen',forMs:searchDelayMs})}
await searchPause(searchDelayMs)
continue}
yielding=false
const slot=budgetSearch()
if(slot==='budget'){emit('waiting',{stage:'search',reason:slot,forMs:searchDelayMs})
await searchPause(searchDelayMs)
continue}
if(slot===COUNTER_UNAVAILABLE&&!searchCounterRetried){searchCounterRetried=true
emit('waiting',{stage:'search',reason:slot,forMs:searchDelayMs})
await searchPause(searchDelayMs)
continue}
if(slot!==null)return finish(slot,{stage:'search'})
searchCounterRetried=false
const settledSearch=await budgetSettle({market:true})
if(settledSearch!==null)return finish(settledSearch,{stage:'search',door:'settle'})
let cleared=false
try{cleared=typeof market.clearMarketCache==='function'&&market.clearMarketCache()===true}catch{cleared=false}
if(!cleared)return finish('bad-state',{stage:'cache-clear'})
session.recordSearch()
lastSearchAt=clock.now()
cursor+=1
ringSearches[seatIndex]+=1
const narrow=narrowedToCap(criteria,buyCeilingOf(criteria,maxPrice).cap,maxBid>0)
const asked=refreshedCriteria(narrow.criteria,iteration,refreshMode)
emit('search',{iteration,criteria:asked.criteria,defId:seat.defId,bidRefresh:asked.bid,narrowedTo:narrow.cap})
const wireBefore=wire===null?null:wire.calls()
let lots
const widePage=openWidePage()
tellScreen('filters')
try{const said=await market.searchTransferMarket(asked.criteria,page)
raceAnswer()
tellScreen('results')
lots=extractLots(said)
if(lots===null){return finish('bad-state',{stage:'search',field:'items'})}}catch(err){const failure=judgeFailure('search',noteFail('search',statusOf(err)).status)
emit('failure',{stage:'search',category:failure.category})
const halt=throttleStop(failure,'search')
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop) return finish(failure.category,{stage:'search'})
const settledAfterFailure=await settleCycle()
if(settledAfterFailure)return finish(settledAfterFailure.reason,settledAfterFailure.detail)
continue}finally{if(widePage!==null)widePage()}
answers+=1
reportObservedOutbids(lots)
const sieve=filterFor(seatIndex)
const passed=lots.filter((lot)=>{try{return sieve.keep(lot)===true}catch{return false}})
const ceiling=buyCeilingOf(criteria,maxPrice)
const selected=rankPurchaseCandidates(passed.map((lot)=>({lot})),purchasePolicy,{byPrice:false})
const priceRankOf=(lot)=>buyNowPriceOf(lot)??Number.POSITIVE_INFINITY
const freshFirst=[...selected.eligible].sort((left,right)=>(secondsLeftOf(right.lot)-secondsLeftOf(left.lot))
||(priceRankOf(left.lot)-priceRankOf(right.lot)))
const priced=rankPurchaseCandidates(freshFirst.map(({lot})=>({lot,price:buyNowPriceOf(lot)})),purchasePolicy,{byPrice:false}).eligible
const withinCap=priced.filter((entry)=>entry.price!==null&&entry.price<=ceiling.cap)
const seenAgain=withinCap.length-withinCap.filter((entry)=>notTried(entry.lot)).length
const affordable=withinCap.filter((entry)=>notTried(entry.lot))
if(seenAgain>0)emit('lot-memory',{skipped:seenAgain,left:affordable.length})
if(matchGuard>0&&answers===1&&affordable.length>=matchGuard){emit('guard',{stage:'search',reason:TOO_MANY_MATCHES,matched:affordable.length,guard:matchGuard})
return finish(TOO_MANY_MATCHES,{stage:'search',matched:affordable.length,guard:matchGuard})}
for(const entry of priced){if(entry.price===null||entry.price<=ceiling.cap)continue
if(ceiling.source===CAP_TARGET)overTargetCap+=1
else overMaxPrice+=1}
const bidLots=freshFirst.map(({lot})=>lot).filter((lot)=>notTried(lot))
session.recordPolicySkipped?.(selected.skipped)
lastLots=lots.length
lastAffordable=affordable.length
lastCeiling=Number.isFinite(ceiling.cap)?ceiling.cap:null
lastBidRefresh=asked.bid
{const came=lots.map((lot)=>auctionTradeId(auctionOf(lot)))
lastFresh=seenTrades===null
?came.length
:came.reduce((sum,id)=>sum+(id===null||!seenTrades.has(id)?1:0),0)
seenTrades=new Set(came.filter((id)=>id!==null))}
{const after=wire===null?null:wire.calls()
const mine=wireBefore!==null&&after!==null&&after-wireBefore===1
const sent=mine?wire.lastSent():null
lastBidSent=sent===null?null:sent.maxBid
lastMinBidSent=sent===null?null:sent.minBid
lastMinBuySent=sent===null?null:sent.minBuy
lastSentSeen=sent!==null
lastSentLots=sent===null?null:(Number.isSafeInteger(sent.lots)?sent.lots:null)
lastBidDrift=sent===null||asked.bid===null||lastBidSent===asked.bid
?null
:{want:asked.bid,got:lastBidSent}}
lastPageFull=lots.length>=(lastSentLots??pageLotsOf(asked.criteria))
if(lastPageFull)pageFulls+=1
dryStreak=affordable.length>0?0:dryStreak+1
emptyStreak=lots.length>0?0:emptyStreak+1
emit('found',{iteration,total:lots.length,kept:passed.length,dropped:lots.length-passed.length,
pageFull:lastPageFull,bidRefresh:asked.bid,dryStreak,emptyStreak,
affordable:affordable.length,policySkipped:selected.skipped,
overTargetCap,overMaxPrice,ceiling:Number.isFinite(ceiling.cap)?ceiling.cap:null,capFrom:ceiling.source})
raceMark('drawn')
guardPile.forget()
let boughtThisSearch=0
let triedThisSearch=0
for(const entry of affordable){if(cancelled) return finish('cancelled')
raceTry()
if(triedThisSearch>=maxPerSearch){emit('per-search-cap',{cap:maxPerSearch,skipped:affordable.length-triedThisSearch,bought:boughtThisSearch})
break}
const beforeBuy=stop.shouldStop(session.snapshot())
if(beforeBuy.stop&&beforeBuy.reason!=='search-limit'){return finish(beforeBuy.reason,beforeBuy.detail)}
raceMark('gateFrom')
const unassigned=await guardPile(allowUnassignedOverflow)
raceMark('gateTo')
if(unassigned)return finish(unassigned.reason,unassigned.detail)
const liveCoins=refreshCoins('buy')
if(liveCoins)return finish(liveCoins.reason,liveCoins.detail)
const beforePurchase=stop.shouldStopBeforePurchase(session.snapshot(),entry.price)
if(beforePurchase.stop){return finish(beforePurchase.reason,beforePurchase.detail)}
if(session.isDryRun()){
session.recordPurchase(entry.price)
boughtThisSearch+=1
guardPile.mine(immediateList===null&&moveTo===null,false)
raceMark('bid')
triedThisSearch+=1
raceDone('dry','buy')
emit('would-buy',{price:entry.price,item:entry.lot})
if(moveTo!==null)emit('would-move',{pile:moveTo,afterBuy})
const listed=await listBought(entry.lot,entry.price)
if(listed?.reason)return finish(listed.reason,listed.detail)}else{
const door=askDoor({action:'buy',lot:entry.lot,amount:entry.price})
if(door.verdict!==ALLOWED){const stop=doorStop('buy',door)
if(stop)return finish(stop.reason,stop.detail)
continue}
raceMark('holdFrom')
const reserved=await reserveAction('buy')
raceMark('holdTo')
if(reserved)return finish(reserved.reason,reserved.detail)
rememberTried(entry.lot,iteration)
triedThisSearch+=1
raceMark('bid')
try{const answer=await market.bid(entry.lot,entry.price,'buy')
raceMark('done')
const receipt=bidReceiptOf(answer)
const mine=receipt!==null&&Array.isArray(receipt.itemIds)
?itemIdsReceiptMatches(answer,[entry.lot])
:true
if(receipt===null||!mine){
emit('failure',{stage:'buy',category:`расписка не понята: ${receiptShapeOf(answer)} совпало=${mine?'да':'нет'}`,
price:entry.price,item:entry.lot})
return finish('bad-state',{stage:'buy',field:'bid-result',shape:receiptShapeOf(answer)})}
session.recordPurchase(entry.price)
boughtThisSearch+=1
raceDone('bought','buy')
emit('bought',{price:entry.price,item:entry.lot})
const listed=await listBought(entry.lot,entry.price)
if(listed?.reason)return finish(listed.reason,listed.detail)
const moved=await moveBought(entry.lot)
if(moved?.reason)return finish(moved.reason,moved.detail)
guardPile.mine(immediateList===null&&moved?.moved!==true,true)
const synced=refreshCoins('buy-response')
if(synced)return finish(synced.reason,synced.detail)}catch(err){
raceMark('done')
if(isDoorRefusal(err)){if(isLotRefusal(err.door)){if(typeof session.releaseAction!=='function'){return finish('bad-state',{stage:'buy',field:'action-slot'})}
session.releaseAction()}
const stop=doorStop('buy',err.door)
if(stop)return finish(stop.reason,stop.detail)
continue}
const said=noteFail('buy',statusOf(err)).status
const failure=judgeFailure('buy',said)
raceDone(raceLostOnMoney('buy',said)?'lost':'blocked','buy')
if(failure.category==='gone'){misses+=1
lastMiss={name:lootNameOf(entry.lot),rating:ratingOf(entry.lot),price:entry.price}}
emit('failure',{stage:'buy',category:failure.category,price:entry.price,item:entry.lot})
if(bidOutcome({category:failure.category})==='unknown'){const said=await linkLostStop(guardPile,entry.price,failure.category,'buy')
return finish(said.reason,said.detail)}
const halt=throttleStop(failure,'buy')
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop) return finish(failure.category,{stage:'buy'})
await buyPause()
continue}}
await buyPause()}
if(maxBid>0){for(const lot of bidLots){if(cancelled) return finish('cancelled')
if(!notTried(lot))continue
raceTry()
const beforeBid=stop.shouldStop(session.snapshot())
if(beforeBid.stop&&beforeBid.reason!=='search-limit'){return finish(beforeBid.reason,beforeBid.detail)}
const price=bidPriceFor(lot,Math.min(maxBid,ceiling.goal),liveBidFloor())
if(price===null)continue
raceMark('gateFrom')
const unassigned=await guardPile(false)
raceMark('gateTo')
if(unassigned)return finish(unassigned.reason,unassigned.detail)
const liveCoins=refreshCoins('bid')
if(liveCoins)return finish(liveCoins.reason,liveCoins.detail)
const beforeBidAmount=stop.shouldStopBeforeBid(session.snapshot(),price)
if(beforeBidAmount.stop){return finish(beforeBidAmount.reason,beforeBidAmount.detail)}
if(session.isDryRun()){
session.recordBid(price)
raceMark('bid')
raceDone('dry','bid')
emit('would-bid',{price,item:lot})}else{
const door=askDoor({action:'bid',lot,amount:price})
if(door.verdict!==ALLOWED){const stop=doorStop('bid',door)
if(stop)return finish(stop.reason,stop.detail)
continue}
raceMark('holdFrom')
const reserved=await reserveAction('bid')
raceMark('holdTo')
if(reserved)return finish(reserved.reason,reserved.detail)
rememberTried(lot,iteration)
raceMark('bid')
try{const receipt=bidReceiptOf(await market.bid(lot,price,'bid'))
raceMark('done')
if(bidOutcome({receipt})==='unknown'){const said=unknownWrite(price,'bid-result','bid',false)
return finish(said.reason,{...said.detail,field:'bid-result'})}
session.recordBid(price)
rememberAcceptedBid(lot,price)
const synced=refreshCoins('bid-response')
if(synced)return finish(synced.reason,synced.detail)
raceDone('bought','bid')
emit('bid',{price,item:lot})}catch(err){
raceMark('done')
if(isDoorRefusal(err)){if(isLotRefusal(err.door)){if(typeof session.releaseAction!=='function'){return finish('bad-state',{stage:'bid',field:'action-slot'})}
session.releaseAction()}
const stop=doorStop('bid',err.door)
if(stop)return finish(stop.reason,stop.detail)
continue}
const code=noteFail('bid',statusOf(err)).status
const failure=judgeFailure('bid',code)
raceDone(raceLostOnMoney('bid',code)?'lost':'blocked','bid')
emit('failure',{stage:'bid',category:failure.category})
if(bidOutcome({category:failure.category})==='unknown'){const said=unknownWrite(price,failure.category,'bid',false)
return finish(said.reason,said.detail)}
const halt=throttleStop(failure,'bid')
if(halt)return finish(halt.reason,halt.detail)
if(failure.stop) return finish(failure.category,{stage:'bid'})
await buyPause()
continue}}
await buyPause()}}
const settled=await settleCycle()
if(settled)return finish(settled.reason,settled.detail)}
return finish('iteration-cap',{cap:iterationCap})}}}
