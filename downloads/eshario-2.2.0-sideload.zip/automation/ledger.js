import{createCachedProvider} from '../core/storage-provider.js'
import{proceedsOf} from './pricing.js'
import{itemLabel} from './journal.js'
import{createDayProfit,sanitizeDayBook} from '../features/head-counters.js'
export const LEDGER_KEY='automation.ledger'
export const LEDGER_READ='ledger.read'
export const LEDGER_WRITE='ledger.write'
export const DEALS_LIMIT=50
export const SEEN_LIMIT=200
export const LEDGER_FLUSH_EVERY=5
export const LEDGER_FLUSH_AFTER_MS=10_000
export const DEAL=Object.freeze({BOUGHT:'bought',SOLD:'sold',QUICK:'quick'
})
const isMoney=(v)=>typeof v==='number'&&Number.isFinite(v)&&v>=0
const isCount=(v)=>typeof v==='number'&&Number.isFinite(v)&&v>=0
export function emptyLedger(){return{bought:{count:0,coins:0},sold:{count:0,net:0,estimated:0},quick:{count:0,coins:0},deals:[],seen:[],seq:0,today:null}}
export function sanitizeLedger(stored){if(!stored||typeof stored!=='object'||Array.isArray(stored)) return emptyLedger()
const{bought,sold,quick,deals,seen,seq}=stored
if(!isCount(bought?.count)||!isMoney(bought?.coins))return emptyLedger()
if(!isCount(sold?.count)||!isMoney(sold?.net)||!isCount(sold?.estimated))return emptyLedger()
if(!isCount(quick?.count)||!isMoney(quick?.coins))return emptyLedger()
if(!Array.isArray(deals)||!Array.isArray(seen))return emptyLedger()
if(!isCount(seq))return emptyLedger()
const cleanDeals=[]
for(const raw of deals){const deal=sanitizeDeal(raw)
if(deal===null)return emptyLedger()
cleanDeals.push(deal)}
const cleanSeen=[]
for(const id of seen){if(typeof id!=='string'||id==='') return emptyLedger()
cleanSeen.push(id)}
const today=cleanToday(stored.today)
if(today===false)return emptyLedger()
return{bought:{count:Math.floor(bought.count),coins:bought.coins},sold:{count:Math.floor(sold.count),net:sold.net,estimated:Math.floor(sold.estimated)},quick:{count:Math.floor(quick.count),coins:quick.coins},deals:cleanDeals.slice(Math.max(0,cleanDeals.length-DEALS_LIMIT)),seen:cleanSeen.slice(Math.max(0,cleanSeen.length-SEEN_LIMIT)),seq:Math.floor(seq),today}}
function cleanToday(stored){if(stored===undefined||stored===null)return null
if(typeof stored!=='object'||Array.isArray(stored))return false
if(typeof stored.day!=='string'||stored.day==='')return false
const book=sanitizeDayBook(stored)
return book===null?false:{day:stored.day,...book}}
function sanitizeDeal(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw)) return null
if(raw.kind!==DEAL.BOUGHT&&raw.kind!==DEAL.SOLD&&raw.kind!==DEAL.QUICK)return null
if(!Number.isFinite(raw.seq)||raw.seq<=0)return null
if(!Number.isFinite(raw.at))return null
if(!isMoney(raw.coins))return null
if(!isMoney(raw.net))return null
if(raw.item!==null&&typeof raw.item!=='string') return null
if(typeof raw.estimated!=='boolean') return null
return{seq:Math.floor(raw.seq),at:raw.at,kind:raw.kind,coins:raw.coins,net:raw.net,item:raw.item,estimated:raw.estimated}}
export function profitOf(totals){const income=(totals?.sold?.net??0)+(totals?.quick?.coins??0)
const spent=totals?.bought?.coins??0
return income-spent}
export function createBridgeLedgerProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function') throw new Error('ledger: мост недоступен')
return createCachedProvider({fetch:()=>bridge.request(LEDGER_READ),push:(value)=>bridge.request(LEDGER_WRITE,value),sanitize:sanitizeLedger,fallback:emptyLedger,onError:opts.onError})}
export function createLedger(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('ledger: нужны часы (правило 6 NIGHT_BRIEF)')}
const provider=deps.provider??null
const flushEvery=Number.isFinite(deps.flushEvery)&&deps.flushEvery>0
?Math.floor(deps.flushEvery):LEDGER_FLUSH_EVERY
const flushAfterMs=Number.isFinite(deps.flushAfterMs)&&deps.flushAfterMs>=0
?deps.flushAfterMs:LEDGER_FLUSH_AFTER_MS
let all=emptyLedger()
if(provider){try{all=sanitizeLedger(provider.read())}catch{all=emptyLedger()}}
const today=createDayProfit({clock,profitOf})
today.restore(all.today)
let since=emptyLedger()
const seen=new Set(all.seen)
let pending=0
let flushedAt=clock.now()
function flush(){pending=0
flushedAt=clock.now()
if(!provider)return false
try{provider.write({bought:{...all.bought},sold:{...all.sold},quick:{...all.quick},deals:all.deals.map((d)=>({...d})),seen:[...all.seen],seq:all.seq,today:today.dump()})
return true}catch{
return false}}
function maybeFlush(){if(!provider)return
pending+=1
if(pending>=flushEvery||clock.now()-flushedAt>=flushAfterMs)flush()}
function addDeal(kind,coins,net,item,estimated){all.seq+=1
const deal={seq:all.seq,at:clock.now(),kind,coins,net,item:item??null,estimated}
for(const book of[all,since]){book.deals.push(deal)
if(book.deals.length>DEALS_LIMIT)book.deals.splice(0,book.deals.length-DEALS_LIMIT)}
maybeFlush()
return deal}
function remember(tradeId){if(tradeId===null)return
seen.add(tradeId)
all.seen.push(tradeId)
if(all.seen.length>SEEN_LIMIT){const dropped=all.seen.splice(0,all.seen.length-SEEN_LIMIT)
for(const id of dropped)seen.delete(id)}}
return{
record(event,payload){const price=payload?.price
if(!isMoney(price)||price<=0)return null
const item=typeof payload?.item==='string'?payload.item:itemLabel(payload?.item)
if(event==='bought'){all.bought.count+=1;all.bought.coins+=price
since.bought.count+=1;since.bought.coins+=price
today.bought(price)
return addDeal(DEAL.BOUGHT,price,0,item,false)}
if(event==='sold'){
const tradeId=payload?.tradeId===undefined||payload?.tradeId===null
?null:String(payload.tradeId)
if(tradeId!==null&&seen.has(tradeId))return null
remember(tradeId)
const estimated=payload?.exact!==true
const net=proceedsOf(price)
all.sold.count+=1;all.sold.net+=net
since.sold.count+=1;since.sold.net+=net
if(estimated){all.sold.estimated+=1;since.sold.estimated+=1}
today.sold(price,net,estimated)
return addDeal(DEAL.SOLD,price,net,item,estimated)}
if(event==='quick-sold'){
all.quick.count+=1;all.quick.coins+=price
since.quick.count+=1;since.quick.coins+=price
today.quick(price)
return addDeal(DEAL.QUICK,price,price,item,false)}
return null},
allTime:()=>({...snapshot(all,clock.now()),today:today.state()}),
today:()=>today.state(),
session:()=>snapshot(since,clock.now()),
pending:()=>pending,
flush,
reset(){all=emptyLedger()
since=emptyLedger()
seen.clear()
today.restore(null)
flush()
return true}}}
function snapshot(book,now){return{now,bought:{...book.bought},sold:{...book.sold},quick:{...book.quick},profit:profitOf(book),estimated:book.sold.estimated>0,deals:book.deals.map((d)=>({...d})).reverse()}}
