import{bandPauseMs} from '../core/pace-jitter.js'
const MAX_CYCLES=10_000
export function createBreakSchedule(opts={}){
const given=(value)=>(typeof value==='number'&&Number.isFinite(value)&&value>=0?value:null)
const bandOf=(band)=>{const min=Number(band?.minMs)
const max=Number(band?.maxMs)
return Number.isFinite(min)&&min>0&&Number.isFinite(max)&&max>=min?{minMs:min,maxMs:max}:null}
const workGiven=given(opts.workMs)
const restGiven=given(opts.restMs)
const workBand=workGiven===null?bandOf(opts.workBandMs):null
const restBand=restGiven===null?bandOf(opts.restBandMs):null
const dice=typeof opts.random==='function'?opts.random:undefined
const enabled=(workGiven!==null?workGiven>0:workBand!==null)
&&(restGiven!==null?restGiven>0:restBand!==null)
const rollWork=()=>(workGiven!==null?workGiven:bandPauseMs(workBand.minMs,workBand.maxMs,dice))
const rollRest=()=>(restGiven!==null?restGiven:bandPauseMs(restBand.minMs,restBand.maxMs,dice))
const cycles=[]
const cycleAt=(elapsed)=>{if(cycles.length===0)cycles.push({index:0,startMs:0,workMs:rollWork(),restMs:rollRest()})
let last=cycles[cycles.length-1]
while(elapsed>=last.startMs+last.workMs+last.restMs&&cycles.length<MAX_CYCLES){const startMs=last.startMs+last.workMs+last.restMs
last={index:cycles.length,startMs,workMs:rollWork(),restMs:rollRest()}
cycles.push(last)}
for(let at=cycles.length-1;at>=0;at-=1){if(elapsed>=cycles[at].startMs)return cycles[at]}
return cycles[0]}
return{isEnabled:()=>enabled,
shouldRest(elapsedMs){if(!enabled)return{rest:false,forMs:0,cycle:0}
const elapsed=typeof elapsedMs==='number'&&Number.isFinite(elapsedMs)&&elapsedMs>=0
?elapsedMs
:0
const one=cycleAt(elapsed)
const position=elapsed-one.startMs
if(position<one.workMs)return{rest:false,forMs:0,cycle:one.index}
const forMs=one.workMs+one.restMs-position
return forMs>0?{rest:true,forMs,cycle:one.index}:{rest:false,forMs:0,cycle:one.index}},
workEndsAt(elapsedMs){if(!enabled)return 0
const elapsed=typeof elapsedMs==='number'&&Number.isFinite(elapsedMs)&&elapsedMs>=0
?elapsedMs
:0
const one=cycleAt(elapsed)
return one.startMs+one.workMs}}}
