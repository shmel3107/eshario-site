const isReceiptId=(id)=>((typeof id==='number'&&Number.isFinite(id))
||(typeof id==='string'&&id!==''))
export function receiptItemIds(data){if(!data
||typeof data!=='object'
||Array.isArray(data)
||!Array.isArray(data.itemIds))return null
if(data.itemIds.some((id)=>!isReceiptId(id)))return null
return data.itemIds}
export function itemIdsReceiptMatches(data,items){const said=receiptItemIds(data)
if(said===null||!Array.isArray(items)||items.length===0)return false
const expectedIds=items.map((item)=>item?.id)
if(expectedIds.some((id)=>!isReceiptId(id)))return false
const expected=new Set(expectedIds)
const received=new Set(said)
if(expected.size!==expectedIds.length
||received.size!==said.length
||received.size!==expected.size)return false
return expectedIds.every((id)=>received.has(id))}
export function moveReceiptMatches(data,items){return itemIdsReceiptMatches(data,items)}
