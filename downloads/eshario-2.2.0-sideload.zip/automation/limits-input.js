import{LIMIT_KEYS,RUN_SPREAD_SHARE} from './stop-conditions.js'
import{spreadBand,bandPauseMs} from '../core/pace-jitter.js'
export const LIMIT_FIELDS=Object.freeze([{key:'minCoins',labelKey:'automation.limit.minCoins',scale:1,unitKey:null},{key:'maxSpend',labelKey:'automation.limit.maxSpend',scale:1,unitKey:null},{key:'maxLossCoins',labelKey:'automation.limit.maxLossCoins',scale:1,unitKey:null},{key:'maxPurchases',labelKey:'automation.limit.maxPurchases',scale:1,unitKey:null},{key:'maxActions',labelKey:'automation.limit.maxActions',scale:1,unitKey:null},{key:'maxSearches',labelKey:'automation.limit.maxSearches',scale:1,unitKey:null},
{key:'maxDurationMs',labelKey:'automation.limit.maxDuration',scale:60_000,unitKey:'automation.limit.minutes',minMs:60_000,maxMs:60*60_000,spreadShare:()=>RUN_SPREAD_SHARE}].map(Object.freeze))
export const BELOW_MIN='below-min'
export const ABOVE_MAX='above-max'
export function boundsOf(field){const low=Number(field?.minMs)
const high=Number(field?.maxMs)
return{minMs:Number.isFinite(low)?low:null,maxMs:Number.isFinite(high)?high:null}}
export function spreadOf(field){const ms=typeof field?.spreadMs==='function'?Number(field.spreadMs()):Number.NaN
const share=typeof field?.spreadShare==='function'?Number(field.spreadShare()):Number.NaN
const saidMs=Number.isFinite(ms)&&ms>0?ms:0
const saidShare=Number.isFinite(share)&&share>0?share:0
if(saidMs===0&&saidShare===0)return null
return{spreadMs:saidMs,share:saidShare}}
const SEPARATORS=/[\s  ,']/g
const FRACTION_SEPARATORS=/[\s  ']/g
export function parseLimitInput(text,opts={}){const fraction=opts?.fraction===true
if(text===null||text===undefined)return{ok:true,value:null,reason:null}
if(typeof text==='number'){return Number.isFinite(text)&&text>=0
?{ok:true,value:text,reason:null}
:{ok:false,value:null,reason:'not-a-number'}}
if(typeof text!=='string') return{ok:false,value:null,reason:'not-a-number'}
const cleaned=text.replace(fraction?FRACTION_SEPARATORS:SEPARATORS,'')
if(cleaned==='') return{ok:true,value:null,reason:null}
const said=fraction?cleaned.replace(',','.'):cleaned
const shape=fraction?/^\d+(\.\d{1,2})?$/:/^\d+$/
if(!shape.test(said)){
return{ok:false,value:null,reason:/^-\d+$/.test(cleaned)?'negative':'not-a-number'}}
const value=Number(said)
if(!Number.isFinite(value)) return{ok:false,value:null,reason:'not-a-number'}
if(!Number.isSafeInteger(Math.round(value))) return{ok:false,value:null,reason:'too-big'}
return{ok:true,value,reason:null}}
export const SAFE_LIMIT_DEFAULTS=Object.freeze({maxActions:45,maxDurationMs:15*60_000})
export function parseLimits(input={},opts={}){const limits={}
const errors=[]
const defaults=opts?.defaults===null?{}:(opts?.defaults??SAFE_LIMIT_DEFAULTS)
const rolled=(field,ms)=>{const share=typeof field?.spreadShare==='function'?Number(field.spreadShare()):Number.NaN
if(!Number.isFinite(share)||share<=0||!Number.isFinite(ms)||ms<=0)return ms
const band=spreadBand(ms,share)
return bandPauseMs(band.minMs,band.maxMs,opts?.random)}
for(const field of LIMIT_FIELDS){const raw=input?.[field.key]
const parsed=parseLimitInput(raw,{fraction:field.scale>1})
if(!parsed.ok){errors.push({key:field.key,reason:parsed.reason})
continue}
if(parsed.value!==null){const ms=Math.round(parsed.value*field.scale)
const bounds=boundsOf(field)
if(bounds.minMs!==null&&ms<bounds.minMs){errors.push({key:field.key,reason:BELOW_MIN})
continue}
if(bounds.maxMs!==null&&ms>bounds.maxMs){errors.push({key:field.key,reason:ABOVE_MAX})
continue}
limits[field.key]=rolled(field,ms)
continue}
if(Object.hasOwn(defaults,field.key))limits[field.key]=rolled(field,defaults[field.key])}
return{limits,errors}}
export function limitsToInput(limits={}){const out={}
for(const field of LIMIT_FIELDS){const value=limits?.[field.key]
out[field.key]=typeof value==='number'&&Number.isFinite(value)
?String(value / field.scale)
:''
}
return out}
export const COVERS_ALL_LIMITS=LIMIT_FIELDS.length===LIMIT_KEYS.length;
