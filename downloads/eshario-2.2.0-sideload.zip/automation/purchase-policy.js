const frozen = (value) => Object.freeze(value);
export const POLICY_DIMENSIONS = Object.freeze([
{ id: 'rating', targetKey: 'targetRatings', exceptionKey: 'exceptionRatings', kind: 'number', min: 1, max: 99 },
{ id: 'quality', targetKey: 'targetQualities', exceptionKey: 'exceptionQualities', kind: 'number', min: 1, max: 3 },
{ id: 'rarity', targetKey: 'targetRarities', exceptionKey: 'exceptionRarities', kind: 'number', min: 0, max: Number.MAX_SAFE_INTEGER },
{ id: 'position', targetKey: 'targetPositions', exceptionKey: 'exceptionPositions', kind: 'number', min: 0, max: Number.MAX_SAFE_INTEGER },
{ id: 'chemistryStyle', targetKey: 'targetChemistryStyles', exceptionKey: 'exceptionChemistryStyles', kind: 'number', min: 0, max: Number.MAX_SAFE_INTEGER },
{ id: 'nation', targetKey: 'targetNations', exceptionKey: 'exceptionNations', kind: 'number', min: 1, max: Number.MAX_SAFE_INTEGER },
{ id: 'league', targetKey: 'targetLeagues', exceptionKey: 'exceptionLeagues', kind: 'number', min: 1, max: Number.MAX_SAFE_INTEGER },
{ id: 'club', targetKey: 'targetClubs', exceptionKey: 'exceptionClubs', kind: 'number', min: 1, max: Number.MAX_SAFE_INTEGER },
].map(frozen));
export const POLICY_FIELDS = Object.freeze([]);
export function definitionIdOf(item) {
const raw = item?.definitionId ?? item?.defId;
const value = typeof raw === 'string' && /^\d+$/.test(raw.trim())
? Number(raw.trim())
: raw;
return Number.isSafeInteger(value) && value > 0 ? value : null;
}
export function policyValueOf(item, dimension) {
try {
if (dimension === 'rating') return knownNumber(item?.rating, 1, 99);
if (dimension === 'quality') {
if (typeof item?.getTier !== 'function') return { known: false };
return knownNumber(item.getTier(), 1, 3);
}
if (dimension === 'rarity') return knownNumber(item?.rareflag, 0);
if (dimension === 'position') return knownNumber(item?.preferredPosition, 0);
if (dimension === 'chemistryStyle') return knownNumber(item?.playStyle, 0);
if (dimension === 'nation') return knownNumber(item?.nationId, 1);
if (dimension === 'league') return knownNumber(item?.leagueId, 1);
if (dimension === 'club') return knownNumber(item?.teamId, 1);
} catch {
return { known: false };
}
return { known: false };
}
export function parsePurchasePolicy(input = {}) {
const policy = {};
const errors = [];
const targetMode = parseMode(input?.targetMode);
policy.targetMode = targetMode.value;
if (!targetMode.ok) errors.push({ key: 'targetMode', reason: 'invalid-mode' });
for (const dimension of POLICY_DIMENSIONS) {
const parsed = parseDimensionList(input?.[dimension.targetKey], dimension);
policy[dimension.targetKey] = parsed.values;
if (!parsed.ok) errors.push({ key: dimension.targetKey, reason: 'invalid-value' });
}
const exceptionMode = parseMode(input?.exceptionMode);
policy.exceptionMode = exceptionMode.value;
if (!exceptionMode.ok) errors.push({ key: 'exceptionMode', reason: 'invalid-mode' });
for (const dimension of POLICY_DIMENSIONS) {
const parsed = parseDimensionList(input?.[dimension.exceptionKey], dimension);
policy[dimension.exceptionKey] = parsed.values;
if (!parsed.ok) errors.push({ key: dimension.exceptionKey, reason: 'invalid-value' });
}
if (targetMode.ok && configuredCount(policy, 'target') > 1 && policy.targetMode === null) {
errors.push({ key: 'targetMode', reason: 'required-mode' });
}
if (exceptionMode.ok && configuredCount(policy, 'exception') > 1 && policy.exceptionMode === null) {
errors.push({ key: 'exceptionMode', reason: 'required-mode' });
}
return { policy, errors };
}
export function purchasePolicyProblems(policy) {
if (policy === undefined || policy === null) return [];
if (!policy || typeof policy !== 'object' || Array.isArray(policy)) return ['purchasePolicy'];
const problems = [];
if (![undefined, null, 'all', 'any'].includes(policy.targetMode)) problems.push('targetMode');
for (const dimension of POLICY_DIMENSIONS) {
const value = policy[dimension.targetKey];
if (value !== undefined && !validDimensionArray(value, dimension)) problems.push(dimension.targetKey);
}
if (![undefined, null, 'all', 'any'].includes(policy.exceptionMode)) problems.push('exceptionMode');
for (const dimension of POLICY_DIMENSIONS) {
const value = policy[dimension.exceptionKey];
if (value !== undefined && !validDimensionArray(value, dimension)) problems.push(dimension.exceptionKey);
}
if (problems.length > 0) return problems;
if (configuredCount(policy, 'target') > 1 && !['all', 'any'].includes(policy.targetMode)) problems.push('targetMode');
if (configuredCount(policy, 'exception') > 1 && !['all', 'any'].includes(policy.exceptionMode)) problems.push('exceptionMode');
return problems;
}
export function purchaseDecision(item, policy = {}) {
const id = definitionIdOf(item);
const rank = Infinity;
const target = evaluateGroup(item, policy, 'target');
if (target.state === 'unknown') return { allowed: false, definitionId: id, reason: 'unknown-target', rank };
if (target.state === 'miss') return { allowed: false, definitionId: id, reason: 'target-miss', rank };
const exception = evaluateGroup(item, policy, 'exception');
if (exception.state === 'unknown') return { allowed: false, definitionId: id, reason: 'unknown-exception', rank };
if (exception.state === 'match') return { allowed: false, definitionId: id, reason: 'excepted', rank };
return { allowed: true, definitionId: id, reason: null, rank };
}
export function rankPurchaseCandidates(candidates, policy = {}, options = {}) {
const byPrice = options.byPrice !== false;
let skipped = 0;
const eligible = [];
for (const [index, entry] of (Array.isArray(candidates) ? candidates : []).entries()) {
const decision = purchaseDecision(entry?.lot, policy);
if (!decision.allowed) {
skipped += 1;
continue;
}
eligible.push({ entry, index, rank: decision.rank });
}
eligible.sort((left, right) => (compareRank(left.rank, right.rank)
|| (byPrice ? comparePrice(left.entry?.price, right.entry?.price) : 0)
|| left.index - right.index));
return { eligible: eligible.map(({ entry }) => entry), skipped };
}
function evaluateGroup(item, policy, side) {
const entries = [];
for (const dimension of POLICY_DIMENSIONS) {
const key = side === 'target' ? dimension.targetKey : dimension.exceptionKey;
const accepted = Array.isArray(policy?.[key]) ? policy[key] : [];
if (accepted.length === 0) continue;
const actual = policyValueOf(item, dimension.id);
entries.push({
dimension: dimension.id,
state: actual.known ? (accepted.includes(actual.value) ? 'match' : 'miss') : 'unknown',
});
}
if (entries.length === 0) return { state: side === 'target' ? 'match' : 'miss' };
const mode = entries.length === 1 ? 'all' : policy?.[`${side}Mode`];
if (entries.some((entry) => entry.state === 'unknown')) return { state: 'unknown' };
if (mode === 'any') {
if (entries.some((entry) => entry.state === 'match')) return { state: 'match' };
return { state: 'miss' };
}
if (entries.some((entry) => entry.state === 'miss')) return { state: 'miss' };
return { state: 'match' };
}
function configuredCount(policy, side) {
return POLICY_DIMENSIONS.reduce((count, dimension) => {
const key = side === 'target' ? dimension.targetKey : dimension.exceptionKey;
return count + (Array.isArray(policy?.[key]) && policy[key].length > 0 ? 1 : 0);
}, 0);
}
function parseDimensionList(raw, dimension) {
return parseNumberList(raw, dimension);
}
function parseMode(raw) {
if (raw === undefined || raw === null || String(raw).trim() === '') return { ok: true, value: null };
if (typeof raw !== 'string') return { ok: false, value: null };
const value = raw.trim().toLowerCase();
return ['all', 'any'].includes(value) ? { ok: true, value } : { ok: false, value: null };
}
function parseNumberList(raw, dimension) {
if (raw === undefined || raw === null || raw === '') return { ok: true, values: [] };
if (typeof raw !== 'string') return { ok: false, values: [] };
const tokens = raw.trim() === '' ? [] : raw.trim().split(/[\s,;]+/);
const values = [];
for (const token of tokens) {
if (!/^\d+$/.test(token)) return { ok: false, values: [] };
const value = Number(token);
if (!validNumber(value, dimension)) return { ok: false, values: [] };
if (!values.includes(value)) values.push(value);
}
return { ok: true, values };
}
function validDimensionArray(value, dimension) {
if (!Array.isArray(value)) return false;
return validNumberArray(value, dimension);
}
const validNumberArray = (value, dimension) => Array.isArray(value)
&& value.every((entry) => validNumber(entry, dimension));
const validNumber = (value, dimension) => Number.isSafeInteger(value)
&& value >= dimension.min && value <= dimension.max;
function knownNumber(value, min, max = Number.MAX_SAFE_INTEGER) {
return Number.isSafeInteger(value) && value >= min && value <= max
? { known: true, value }
: { known: false };
}
const compareRank = (left, right) => left === right ? 0 : (left < right ? -1 : 1);
const comparePrice = (left, right) => {
const a = typeof left === 'number' && Number.isFinite(left) ? left : Infinity;
const b = typeof right === 'number' && Number.isFinite(right) ? right : Infinity;
return a === b ? 0 : (a < b ? -1 : 1);
};
