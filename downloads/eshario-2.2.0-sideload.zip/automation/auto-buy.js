import{createBreakSchedule} from './breaks.js'
import{bandPauseMs} from '../core/pace-jitter.js'
import{moveReceiptMatches} from './item-receipts.js'
import{bidReceiptOf,bidOutcome,unassignedCountOf,pileOrNull,buyNowPriceOf,STANDARD_UNASSIGNED_LIMIT,WORK_BAND_MS,BREAK_BAND_MS} from './sniper.js'
import{isDoorRefusal,isLotRefusal,ALLOWED,UNKNOWN as DOOR_UNKNOWN} from '../adapter/action-door.js'
import{listingsOf,CARD_THROTTLE_MS} from '../features/min-bin.js'
import{COUNTER_UNAVAILABLE,restMarketAfterThrottle,BUDGET_STOPS} from '../features/day-budget.js'
import{adviceLevel} from '../features/head-counters.js'
export const AUTO_BUY_RHYTHM=Object.freeze({
buy:Object.freeze({minMs:2_200,maxMs:2_800}),
move:Object.freeze({minMs:800,maxMs:1_200}),
breaks:Object.freeze({workBandMs:WORK_BAND_MS,restBandMs:BREAK_BAND_MS})})
export const SOFT_STREAK=3
export const SOFT_REST_BAND_MS=Object.freeze({minMs:55_000,maxMs:70_000})
export const CARD_THROTTLED='card-throttled'
export const SKIP_FAILURES=Object.freeze(['gone','no-lot','transient','unknown',CARD_THROTTLED])
export const SOFT_FAILURES=Object.freeze(['unknown'])
export const STOP_FAILURES=Object.freeze(['captcha','fatal','out-of-coins','throttled'])
export const ACCOUNT_STOPS=Object.freeze(['captcha','fatal','throttled'])
export{BUDGET_STOPS} from '../features/day-budget.js'
const statusOf=(err)=>(typeof err?.status==='number'?err.status:null)
const isMoney=(value)=>Number.isSafeInteger(value)&&value>=0
const isPrice=(value)=>typeof value==='number'&&Number.isFinite(value)&&value>0
const idOrNull=(value)=>((typeof value==='number'&&Number.isFinite(value))||(typeof value==='string'&&value!=='')?String(value):null)
export const HOUR_BID_CAP=60
export const HOUR_WINDOW_MS=3_600_000
export const HOUR_CAP_REFUSAL='hour-cap'
export const RECEIPT_UNRESOLVED='receipt-unresolved'
export function readBuyStamps(stored,now,windowMs){const list=Array.isArray(stored)
?stored
:(stored&&typeof stored==='object'&&Array.isArray(stored.stamps)?stored.stamps:[])
const out=[]
for(const value of list){if(!Number.isFinite(value)||value>now)continue
if(now-value>=windowMs)continue
out.push(value)}
return out.sort((a,b)=>a-b)}
export function buyAdviceOf(used,cap){if(!Number.isSafeInteger(used)||!Number.isSafeInteger(cap)||cap<=0)return{advice:null,over:null}
return{advice:adviceLevel(used,cap),over:Math.max(0,used-cap)}}
export function createBuyRate(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('auto-buy: часовому потолку нужны часы (правило 6 NIGHT_BRIEF)')}
if(deps.owner){const owner=deps.owner
const buy=()=>owner.state()?.buy??null
return{cap:buy()?.cap??HOUR_BID_CAP,windowMs:HOUR_WINDOW_MS,
load(){return owner.load().then((state)=>({used:state?.buy?.used??0,
left:Math.max(0,(state?.buy?.cap??HOUR_BID_CAP)-(state?.buy?.used??0))}))},
left(){const window=buy()
return window===null?0:Math.max(0,window.cap-window.used)},
refusal(){return owner.refusal('bid')},
nextAt(){const window=buy()
return window!==null&&window.used>=window.cap&&Number.isSafeInteger(window.oldest)
?window.oldest+HOUR_WINDOW_MS:null},
take(){return owner.take('bid')},
settle(){return typeof owner.settle==='function'?owner.settle('bid'):Promise.resolve(null)},
warm(){return typeof owner.warm==='function'?owner.warm('bid',1):Promise.resolve(null)},
release(){return owner.release('bid')},
state(){const window=buy()
return{cap:window?.cap??HOUR_BID_CAP,windowMs:HOUR_WINDOW_MS,used:window?.used??0,
left:window===null?0:Math.max(0,window.cap-window.used),available:window!==null,
...buyAdviceOf(window?.used,window?.cap??HOUR_BID_CAP),
until:window!==null&&window.used>=window.cap&&Number.isSafeInteger(window.oldest)
?window.oldest+HOUR_WINDOW_MS:null,
refused:owner.refusedCount()}}}}
const cap=Number.isSafeInteger(deps.cap)&&deps.cap>0?deps.cap:HOUR_BID_CAP
const windowMs=Number.isSafeInteger(deps.windowMs)&&deps.windowMs>0?deps.windowMs:HOUR_WINDOW_MS
const storage=deps.storage??null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let stamps=[]
let refused=0
let pending=null
let ready=storage===null||typeof storage.read!=='function'
let broken=false
const unavailable=()=>(broken||!ready?COUNTER_UNAVAILABLE:null)
const prune=(now)=>{stamps=stamps.filter((at)=>at<=now&&now-at<windowMs)}
const save=()=>{if(storage===null||typeof storage.write!=='function')return
try{const done=storage.write({stamps:[...stamps]})
if(done&&typeof done.catch==='function')done.catch((err)=>{broken=true
onError(err)})}catch(err){broken=true
onError(err)}}
return{cap,windowMs,
load(){if(pending!==null)return pending
pending=(async()=>{if(storage===null||typeof storage.read!=='function')return{used:0,left:cap}
try{const stored=await storage.read()
stamps=readBuyStamps(stored,clock.now(),windowMs).slice(-cap)
broken=false
ready=true}catch(err){onError(err)
broken=true
pending=null
throw err}
return{used:stamps.length,left:Math.max(0,cap-stamps.length)}})()
return pending},
left(){if(unavailable()!==null)return 0
prune(clock.now())
return Math.max(0,cap-stamps.length)},
refusal(){const blocked=unavailable()
if(blocked!==null)return blocked
prune(clock.now())
return null},
nextAt(){const now=clock.now()
prune(now)
return stamps.length<cap?null:stamps[0]+windowMs},
take(){const blocked=unavailable()
if(blocked!==null){refused+=1
return blocked}
const now=clock.now()
prune(now)
stamps.push(now)
save()
return null},
settle(){return Promise.resolve(unavailable())},
warm(){return Promise.resolve(unavailable())},
release(){if(unavailable()!==null)return false
prune(clock.now())
if(stamps.length===0)return false
stamps.pop()
save()
return true},
state(){const now=clock.now()
prune(now)
return{cap,windowMs,used:stamps.length,left:Math.max(0,cap-stamps.length),
available:unavailable()===null,
advice:adviceLevel(stamps.length,cap),over:Math.max(0,stamps.length-cap),
until:stamps.length>=cap?stamps[0]+windowMs:null,refused}}}}
export const LOT_PAGE=20
export const BUDGET_WAITS=1
const BUDGET_PAD_MS=250
const BUDGET_MAX_WAIT_MS=65_000
export const PRICE_TOLERANCE=Object.freeze({coins:300,share:0.05})
export function toleranceFor(reference){if(!isPrice(reference))return 0
return Math.max(PRICE_TOLERANCE.coins,reference*PRICE_TOLERANCE.share)}
export function priceLawLimit(reference){return isPrice(reference)?reference+toleranceFor(reference):null}
export function withinPriceLaw(price,reference){if(!isPrice(price))return false
const limit=priceLawLimit(reference)
return limit===null||price<=limit}
export function buyCeilingOf(target){const price=target?.price
const limit=priceLawLimit(target?.reference)
if(!isPrice(price))return limit===null?null:Math.floor(limit)
return limit===null?price:Math.min(price,Math.floor(limit))}
export function buyTargetOf(one){return{...one,reference:Number.isFinite(one?.want)&&one.want>0?one.want:null}}
export function batchCeiling(targets){let sum=0
for(const one of Array.isArray(targets)?targets:[]){const cap=buyCeilingOf(one)
if(isPrice(cap))sum+=cap}
return sum}
export function cheapestLot(lots,ceiling){let best=null
if(!isPrice(ceiling))return null
for(const lot of Array.isArray(lots)?lots:[]){const price=buyNowPriceOf(lot)
if(price===null||price>ceiling)continue
if(best===null||price<best.price)best={lot,price}}
return best}
export function lotIdentityRefusal(lot,target,ceiling){if(lot===null||typeof lot!=='object'||Array.isArray(lot))return 'no-lot'
if(idOrNull(lot?.id)===null)return 'no-lot'
const want=idOrNull(target?.id)
if(want===null)return 'no-target'
const has=idOrNull(lot?.definitionId)
if(has===null||has!==want)return 'wrong-card'
const price=buyNowPriceOf(lot)
if(!isPrice(ceiling)||price===null||price>ceiling)return 'over-ceiling'
return null}
export function createLotFinder(deps={}){const market=deps.market
if(!market||typeof market.searchTransferMarket!=='function'){throw new Error('auto-buy: точечному поиску нужен рынок с searchTransferMarket')}
const clock=deps.clock
if(!clock||typeof clock.sleep!=='function'){throw new Error('auto-buy: точечному поиску нужны часы (правило 6 NIGHT_BRIEF)')}
const criteriaOf=typeof deps.criteriaOf==='function'?deps.criteriaOf:null
if(criteriaOf===null){throw new Error('auto-buy: точечному поиску нужны критерии карты')}
const budget=deps.budget??null
const page=Number.isSafeInteger(deps.page)&&deps.page>0?deps.page:LOT_PAGE
const waitOf=()=>{try{const said=typeof budget?.waitMs==='function'?budget.waitMs():null
return Number.isFinite(said)&&said>0?said:null}catch{return null}}
const reserve=async()=>{if(budget===null||typeof budget.take!=='function')return null
for(let attempt=0;attempt<=BUDGET_WAITS;attempt+=1){const refusal=budget.take()
if(refusal===null){if(typeof budget.settle!=='function')return null
let answered=null
try{answered=await budget.settle()}catch{answered=null}
return typeof answered==='string'?{word:answered,waitMs:waitOf()}:null}
if(refusal!=='budget')return{word:refusal,waitMs:waitOf()}
if(attempt===BUDGET_WAITS)return{word:refusal,waitMs:waitOf()}
const wait=waitOf()
await clock.sleep(Math.min(Math.max(Number(wait)||0,0)+BUDGET_PAD_MS,BUDGET_MAX_WAIT_MS))}
return{word:'budget',waitMs:waitOf()}}
return async function find(target){const id=target?.id
if(id===null||id===undefined||id==='')return{ok:false,reason:'no-lot',detail:{field:'id'}}
const ceiling=buyCeilingOf(target)
if(!isPrice(ceiling))return{ok:false,reason:'no-lot',detail:{field:'price'}}
const refusal=await reserve()
if(refusal!==null)return{ok:false,reason:refusal.word,waitMs:refusal.waitMs,detail:{stage:'search'}}
if(typeof market.clearMarketCache!=='function')return{ok:false,reason:'cache-unclean',detail:{stage:'search',field:'clearMarketCache'}}
let cleared=false
try{cleared=market.clearMarketCache()===true}catch{cleared=false}
if(!cleared)return{ok:false,reason:'cache-unclean',detail:{stage:'search'}}
let data
try{data=await market.searchTransferMarket({...criteriaOf(id,typeof target?.type==='string'?target.type:null),count:page,maxBuy:ceiling},1)}catch(err){return{ok:false,error:err,detail:{stage:'search'}}}
let lots
try{lots=listingsOf(data)}catch{
return{ok:false,reason:'unknown',detail:{stage:'search',field:'items'}}}
const ours=[]
let sameCard=0
for(const one of lots){const said=lotIdentityRefusal(one,target,ceiling)
if(said===null||said==='over-ceiling')sameCard+=1
if(said===null)ours.push(one)}
const best=cheapestLot(ours,ceiling)
if(best!==null)return{ok:true,lot:best.lot,price:best.price}
return{ok:false,reason:lots.length>0&&sameCard===0?'wrong-card':'no-lot',detail:{stage:'search',lots:lots.length}}}}
export function pauseFor(range,random){const min=Math.max(0,Number(range?.minMs)||0)
const max=Math.max(min,Number(range?.maxMs)||min)
return bandPauseMs(min,max,random)}
export function readTargets(targets){if(!Array.isArray(targets)||targets.length===0){return{ok:false,index:-1,field:'targets'}}
const out=[]
for(let index=0;index<targets.length;index+=1){const target=targets[index]
if(!target||typeof target!=='object'||Array.isArray(target)){return{ok:false,index,field:'target'}}
if((target.lot===null||target.lot===undefined)
&&(target.id===null||target.id===undefined||target.id==='')){return{ok:false,index,field:'lot'}}
if(!isPrice(buyCeilingOf(target))){return{ok:false,index,field:'price'}}
out.push(target)}
return{ok:true,targets:out}}
export function createAutoBuy(deps={}){const{market,session,stop,clock}=deps
if(!market||typeof market.bid!=='function'){throw new Error('auto-buy: нужен рынок с bid')}
if(!session||typeof session.snapshot!=='function'){throw new Error('auto-buy: нужна сессия')}
if(!stop||typeof stop.shouldStop!=='function'){throw new Error('auto-buy: нужны условия остановки')}
if(!clock||typeof clock.now!=='function'||typeof clock.sleep!=='function'){throw new Error('auto-buy: нужны часы (правило 6 NIGHT_BRIEF)')}
const random=typeof deps.random==='function'?deps.random:Math.random
const moveTo=pileOrNull(deps.moveTo)
const coinBalance=typeof deps.coinBalance==='function'?deps.coinBalance:null
const findLot=typeof deps.findLot==='function'?deps.findLot:null
const buyRate=deps.buyRate&&typeof deps.buyRate.take==='function'?deps.buyRate:null
const budget=deps.budget&&typeof deps.budget.call==='function'?deps.budget:null
const budgetCall=(count=1)=>(budget!==null?budget.call(count):null)
const DOOR_TAKE='take'
const DOOR_SETTLE='settle'
const DOOR_WARM='warm'
const budgetOnce=async(count)=>{const refusal=budgetCall(count)
if(refusal!==null)return{word:refusal,door:DOOR_TAKE}
if(budget===null||typeof budget.settle!=='function')return null
let settled=null
try{settled=await budget.settle({market:false})}catch{settled=COUNTER_UNAVAILABLE}
return typeof settled==='string'?{word:settled,door:DOOR_SETTLE}:null}
const budgetDoor=async(stage,retry,extra={})=>{let out=await budgetOnce(1)
if(out===null)return null
const said=(one)=>({reason:one.word,detail:{stage,door:one.door,...extra}})
if(out.word!==COUNTER_UNAVAILABLE)return said(out)
if(out.door===DOOR_TAKE){let asked=COUNTER_UNAVAILABLE
try{asked=typeof budget?.warm==='function'?await budget.warm(1):COUNTER_UNAVAILABLE}catch{asked=COUNTER_UNAVAILABLE}
if(typeof asked==='string')return said({word:asked,door:DOOR_WARM})
out=await budgetOnce(1)
return out===null?null:said(out)}
if(!retry)return said(out)
let asked=COUNTER_UNAVAILABLE
try{asked=typeof budget?.warm==='function'?await budget.warm(1):COUNTER_UNAVAILABLE}catch{asked=COUNTER_UNAVAILABLE}
if(typeof asked==='string')return said({word:asked,door:DOOR_WARM})
out=await budgetOnce(1)
return out===null?null:said(out)}
const bidDoor=async(stage,index)=>{if(buyRate===null)return null
const where=()=>({stage,index,cap:buyRate.cap??HOUR_BID_CAP,until:buyRate.nextAt?.()??null})
let capped=buyRate.take()
if(capped===COUNTER_UNAVAILABLE&&typeof buyRate.warm==='function'){let asked=COUNTER_UNAVAILABLE
try{asked=await buyRate.warm()}catch{asked=COUNTER_UNAVAILABLE}
if(typeof asked==='string')return{reason:asked,detail:{...where(),door:DOOR_WARM}}
capped=buyRate.take()}
if(capped!==null)return{reason:capped,detail:{...where(),door:DOOR_TAKE}}
if(typeof buyRate.settle!=='function')return null
let settled=null
try{settled=await buyRate.settle()}catch{settled=COUNTER_UNAVAILABLE}
return typeof settled==='string'?{reason:settled,detail:{...where(),door:DOOR_SETTLE}}:null}
const place=typeof deps.place==='function'?deps.place:null
const save=typeof deps.save==='function'?deps.save:null
const onEvent=typeof deps.onEvent==='function'?deps.onEvent:()=>{}
const emit=(name,payload)=>{try{onEvent(name,payload)}catch{
}}
let running=false
let cancelled=false
let unaccepted=0
const sleep=(range)=>clock.sleep(pauseFor(range,random))
const breaks=createBreakSchedule({...AUTO_BUY_RHYTHM.breaks,random})
let lastThrottle=null
const throttleWord=(target,stage)=>{const raw=Number(target?.id)
const card=Number.isSafeInteger(raw)&&raw>0?raw:null
const at=clock.now()
const previous=lastThrottle!==null&&Number.isFinite(at)&&at-lastThrottle.at<CARD_THROTTLE_MS
?lastThrottle.card
:null
const market=card===null||(previous!==null&&previous!==card)
if(card!==null&&Number.isFinite(at))lastThrottle={card,at}
if(market&&restMarketAfterThrottle(budget))emit('rest-market',{stage})
return market?'throttled':CARD_THROTTLED}
const failureWord=(category,target,stage)=>(category==='throttled'?throttleWord(target,stage):category)
const reserveAction=(stage)=>{if(session.isDryRun?.()===true)return null
if(cancelled&&stage!=='save')return{reason:'cancelled',detail:{stage}}
const before=typeof stop.shouldStopBeforeAction==='function'
?stop.shouldStopBeforeAction(session.snapshot())
:stop.shouldStop(session.snapshot())
if(before.stop&&before.reason!=='search-limit'){return{reason:before.reason,detail:{...(before.detail??{}),stage}}}
session.recordAction()
return null}
const refreshCoins=(stage)=>{if(session.isDryRun?.()===true)return null
let value
if(coinBalance===null){value=session.snapshot()?.coins}else{try{value=coinBalance()}catch{value=null}}
if(!isMoney(value)){return{reason:'bad-state',detail:{field:'coins',stage}}}
session.setCoins(value)
return null}
const unknownBid=(price,category,index,field)=>{const before=session.snapshot()?.coins
session.recordUnknown(price,true)
const expected=isMoney(before)&&isPrice(price)?Math.max(0,before-price):null
let live=null
if(coinBalance===null){live=session.snapshot()?.coins}else{try{live=coinBalance()}catch{live=null}}
const seen=isMoney(live)?live:null
emit('bid-unknown',{stage:'buy',index,price,category,expected,live:seen,matched:expected!==null&&seen!==null&&seen===expected})
return{reason:'bad-state',detail:{stage:'buy',index,field,category,price,expected,live:seen}}}
const askDoor=(request)=>(typeof market.review==='function'
?market.review(request)
:{verdict:DOOR_UNKNOWN,reason:'no-judge',need:1,fits:null})
const guardUnassigned=async()=>{if(session.isDryRun?.()===true)return null
if(typeof market.requestUnassignedItems!=='function'){emit('failure',{stage:'unassigned',category:'unavailable'})
return{reason:'unassigned-unavailable',detail:{stage:'unassigned'}}}
const slot=await budgetDoor('unassigned',true)
if(slot!==null){emit('failure',{stage:'unassigned',category:slot.reason})
return slot}
try{const count=unassignedCountOf(await market.requestUnassignedItems())
if(count===null){emit('failure',{stage:'unassigned',category:'bad-shape'})
return{reason:'unassigned-unavailable',detail:{stage:'unassigned'}}}
unaccepted=count
return count>=STANDARD_UNASSIGNED_LIMIT
?{reason:'unassigned-full',detail:{stage:'unassigned',count,limit:STANDARD_UNASSIGNED_LIMIT}}
:null}catch(err){const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'unassigned',category:failure.category})
return{reason:STOP_FAILURES.includes(failure.category)?failure.category:'unassigned-unavailable',
detail:{stage:'unassigned'}}}}
const isItemId=(id)=>(typeof id==='number'&&Number.isFinite(id))||(typeof id==='string'&&id!=='')
const sameItem=(one,id)=>isItemId(one?.id)&&String(one.id)===String(id)
const unassignedItemsOf=(data)=>(data&&typeof data==='object'&&!Array.isArray(data)&&Array.isArray(data.items)?data.items:null)
const boughtItemOf=async(receipt,lot)=>{const named=Array.isArray(receipt?.items)&&receipt.items.length>0?receipt.items[0]:null
if(named!==null&&named!==undefined)return{item:named,how:'items'}
const ids=Array.isArray(receipt?.itemIds)?receipt.itemIds:[]
const id=ids.length>0?ids[0]:null
if(!isItemId(id))return{item:null,how:'no-id'}
if(sameItem(lot,id))return{item:lot,how:'lot'}
if(typeof market.requestUnassignedItems!=='function')return{item:null,how:'no-door'}
const slot=await budgetDoor('receipt',true)
if(slot!==null)return{item:null,how:'budget',stop:slot}
let items=null
try{items=unassignedItemsOf(await market.requestUnassignedItems())}catch(err){const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'receipt',category:failure.category})
return{item:null,how:'failed'}}
if(items===null)return{item:null,how:'bad-shape'}
const found=items.find((one)=>sameItem(one,id))??null
return{item:found,how:found===null?'not-found':'unassigned'}}
const moveBought=async(lot)=>{if(moveTo===null||typeof market.move!=='function'){return{reason:'bad-state',detail:{stage:'move',field:'pile'}}}
const slot=await budgetDoor('move',false)
if(slot!==null)return slot
const reserved=reserveAction('move')
if(reserved)return reserved
try{const receipt=await market.move([lot],moveTo)
if(!moveReceiptMatches(receipt,[lot])){return{reason:'bad-state',detail:{stage:'move',field:'itemIds'}}}
session.recordMove(1)
unaccepted=Math.max(0,unaccepted-1)
emit('moved',{pile:moveTo})
return null}catch(err){
if(isDoorRefusal(err)){emit('door',{stage:'move',verdict:err.door?.verdict,reason:err.door?.reason,fits:err.door?.fits,need:err.door?.need})
return{reason:'move-blocked',detail:{stage:'move',door:err.door?.reason??null}}}
const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'move',category:failure.category})
return{reason:STOP_FAILURES.includes(failure.category)?failure.category:'bad-state',detail:{stage:'move'}}}}
return{isRunning:()=>running,
cancel(){cancelled=true},
async run(targets,onProgress,context={}){if(running){return{ok:false,reason:'busy',detail:null,planned:0,bought:0,placed:0,spent:0,saved:false,rows:[],stats:session.stats()}}
const parsed=readTargets(targets)
if(parsed.ok!==true){return{ok:false,reason:'bad-state',detail:{stage:'plan',field:parsed.field,index:parsed.index},
planned:Array.isArray(targets)?targets.length:0,bought:0,placed:0,spent:0,saved:false,rows:[],stats:session.stats()}}
const plan=parsed.targets
running=true
cancelled=false
unaccepted=0
const startedAt=clock.now()
const rows=plan.map((target,index)=>({index,id:target.id??null,name:target.name??null,
row:typeof target.row==='string'&&target.row!==''?target.row:null,
price:buyCeilingOf(target),status:'not-tried',paid:null,reason:null,placedId:null,
age:Number.isFinite(target?.age)?target.age:null,
origin:typeof target?.origin==='string'?target.origin:null}))
let bought=0
let placed=0
let spent=0
let softStreak=0
let stopped=null
const tell=typeof onProgress==='function'
?()=>{try{onProgress({done:bought,planned:plan.length,spent})}catch{
}}
:()=>{}
const finish=async()=>{running=false
let saved=false
const shut=stopped!==null&&ACCOUNT_STOPS.includes(stopped.reason)
if(shut&&placed>0)emit('save-skipped',{placed,why:stopped.reason})
if(placed>0&&save!==null&&!shut&&session.isDryRun?.()!==true){const slot=await budgetDoor('save',false)
const reserved=slot!==null?slot:reserveAction('save')
if(reserved){if(stopped===null)stopped=reserved}else{try{await save(context)
saved=true
emit('saved',{placed})}catch(err){const failure=session.recordFailure(statusOf(err))
emit('failure',{stage:'save',category:failure.category})
if(stopped===null)stopped={reason:STOP_FAILURES.includes(failure.category)?failure.category:'save-failed',
detail:{stage:'save'}}}}}
const result={ok:stopped===null&&bought===plan.length,
reason:stopped?.reason??null,detail:stopped?.detail??null,
planned:plan.length,bought,placed,spent,saved,rows,stats:session.stats()}
emit('stopped',result)
return result}
const pile=await guardUnassigned()
if(pile){stopped=pile
return finish()}
for(let index=0;index<plan.length;index+=1){const target=plan[index]
const row=rows[index]
const ceiling=buyCeilingOf(target)
if(cancelled){stopped={reason:'cancelled',detail:null}
break}
const coins=refreshCoins('batch')
if(coins){stopped=coins
break}
const before=stop.shouldStop(session.snapshot())
if(before.stop&&before.reason!=='search-limit'){stopped={reason:before.reason,detail:before.detail}
break}
const projected=stop.shouldStopBeforePurchase(session.snapshot(),ceiling)
if(projected.stop){stopped={reason:projected.reason,detail:projected.detail}
break}
if(unaccepted>=STANDARD_UNASSIGNED_LIMIT){stopped={reason:'unassigned-full',
detail:{stage:'buy',count:unaccepted,limit:STANDARD_UNASSIGNED_LIMIT}}
break}
if(session.isDryRun?.()===true){session.recordPurchase(ceiling)
spent+=ceiling
bought+=1
row.status='would-buy'
row.paid=ceiling
tell()
emit('would-buy',{price:ceiling,item:target.lot})}else{
let lot=target.lot??null
let price=ceiling
if(lot===null){if(findLot===null){stopped={reason:'bad-state',detail:{stage:'lot',index,field:'findLot'}}
break}
let found=null
try{found=await findLot(target)}catch(err){found={ok:false,error:err}}
if(found?.ok===true&&isPrice(found.price)&&found.price<=ceiling){lot=found.lot
price=found.price
emit('lot',{index,price,limit:ceiling,age:rows[index].age,origin:rows[index].origin})}else if(found?.error!==undefined&&found?.error!==null){const failure=session.recordFailure(statusOf(found.error))
const category=failureWord(failure.category,target,'lot')
emit('failure',{stage:'lot',category})
if(STOP_FAILURES.includes(category)){stopped={reason:category,detail:{stage:'lot',index}}
break}
row.status='skipped'
row.reason=category
softStreak=SOFT_FAILURES.includes(category)?softStreak+1:0
if(softStreak>=SOFT_STREAK){softStreak=0
session.recordRest()
const rest=pauseFor(SOFT_REST_BAND_MS,random)
emit('rest',{forMs:rest,why:'soft-streak'})
await clock.sleep(rest)}
continue}else{const refusal=String(found?.reason??'no-lot')
if(Object.hasOwn(BUDGET_STOPS,refusal)){stopped={reason:BUDGET_STOPS[refusal],
detail:{stage:'lot',index,waitMs:Number.isFinite(found?.waitMs)?found.waitMs:null}}
break}
if(refusal==='cache-unclean'){stopped={reason:'bad-state',detail:{stage:'lot',index,field:'market-cache'}}
break}
const named=refusal==='unknown'||refusal==='wrong-card'?refusal:'no-lot'
emit('failure',{stage:'lot',category:named})
row.status='skipped'
row.reason=named
softStreak=SOFT_FAILURES.includes(row.reason)?softStreak+1:0
if(softStreak>=SOFT_STREAK){softStreak=0
session.recordRest()
const rest=pauseFor(SOFT_REST_BAND_MS,random)
emit('rest',{forMs:rest,why:'soft-streak'})
await clock.sleep(rest)}
continue}}
const wrong=lotIdentityRefusal(lot,target,ceiling)
if(wrong!==null){emit('failure',{stage:'buy',category:wrong})
row.status='skipped'
row.reason=wrong
continue}
const door=askDoor({action:'buy',lot,amount:price})
if(door.verdict!==ALLOWED){emit('door',{stage:'buy',verdict:door.verdict,reason:door.reason,
fits:door.fits,need:door.need,used:door.used,size:door.size,coins:door.coins})
if(!isLotRefusal(door)){stopped={reason:'buy-blocked',detail:{stage:'buy',index,door:door.reason??null}}
break}
row.status='skipped'
row.reason=door.reason==='dead-lot'?'gone':'unknown'
continue}
const daySlot=await budgetDoor('buy',false,{index})
if(daySlot!==null){stopped=daySlot
break}
const capped=await bidDoor('buy',index)
if(capped!==null){stopped=capped
break}
const reserved=reserveAction('buy')
if(reserved){stopped=reserved
break}
let receipt=null
try{receipt=bidReceiptOf(await market.bid(lot,price,'buy'))}catch(err){
if(isDoorRefusal(err)){emit('door',{stage:'buy',verdict:err.door?.verdict,reason:err.door?.reason,
fits:err.door?.fits,need:err.door?.need,used:err.door?.used,size:err.door?.size,coins:err.door?.coins})
if(!isLotRefusal(err.door)){stopped={reason:'buy-blocked',detail:{stage:'buy',index,door:err.door?.reason??null}}
break}
if(typeof session.releaseAction!=='function'||(buyRate!==null&&typeof buyRate.release!=='function')){stopped={reason:'bad-state',detail:{stage:'buy',index,field:'reserved-slots'}}
break}
session.releaseAction()
if(buyRate!==null)buyRate.release()
row.status='skipped'
row.reason=err.door?.reason==='dead-lot'?'gone':'unknown'
continue}
const failure=session.recordFailure(statusOf(err))
const category=failureWord(failure.category,target,'buy')
emit('failure',{stage:'buy',category})
if(bidOutcome({category})==='unknown'){spent+=price
row.status='unknown'
row.reason=category
tell()
stopped=unknownBid(price,category,index,'bid-outcome')
break}
if(STOP_FAILURES.includes(category)){stopped={reason:category,detail:{stage:'buy',index}}
break}
row.status='skipped'
row.reason=category
softStreak=SOFT_FAILURES.includes(category)?softStreak+1:0
if(softStreak>=SOFT_STREAK){softStreak=0
session.recordRest()
const rest=pauseFor(SOFT_REST_BAND_MS,random)
emit('rest',{forMs:rest,why:'soft-streak'})
await clock.sleep(rest)}
continue}
if(bidOutcome({receipt})==='unknown'){
spent+=price
row.status='unknown'
row.reason='bid-result'
tell()
stopped=unknownBid(price,'bid-result',index,'bid-result')
break}
session.recordPurchase(price)
spent+=price
bought+=1
unaccepted+=1
softStreak=0
row.status='bought'
row.paid=price
tell()
emit('bought',{price,item:receipt.items[0]??lot})
const synced=refreshCoins('buy-response')
if(synced){stopped=synced
break}
const carried=await boughtItemOf(receipt,lot)
emit('receipt',{how:carried.how,shape:Array.isArray(receipt?.itemIds)?'itemIds':'items',lotNamed:sameItem(lot,Array.isArray(receipt?.itemIds)?receipt.itemIds[0]:null)})
if(carried.stop){stopped=carried.stop
break}
if(carried.item===null||carried.item===undefined){
stopped={reason:RECEIPT_UNRESOLVED,detail:{stage:'place',index,how:carried.how,name:target?.name??null}}
break}
const moved=await moveBought(carried.how==='items'?lot:carried.item)
if(moved){stopped=moved
break}
await sleep(AUTO_BUY_RHYTHM.move)
if(place!==null){const card=carried.item
let put
try{put=place(target,card,context)}catch(err){put={ok:false,reason:err?.message??'failed'}}
if(put?.ok===true){placed+=1
row.status='placed'
row.placedId=put?.id??(card?.id??null)
emit('placed',{index,slot:put?.slot??null})}else{stopped={reason:'place-failed',detail:{stage:'place',index,why:put?.reason??null}}
break}}}
if(index<plan.length-1){await sleep(AUTO_BUY_RHYTHM.buy)
const due=breaks.shouldRest(clock.now()-startedAt)
if(due.rest){session.recordRest()
emit('rest',{forMs:due.forMs,why:'batch'})
await clock.sleep(due.forMs)}}}
return finish()}}}
