import{nationOf,leagueOf,clubOf} from './sbc-requirements.js'
export const FIELD_PLAYERS=11
export const SLOT_MAX_CHEMISTRY=3
export const MAX_CHEMISTRY=FIELD_PLAYERS*SLOT_MAX_CHEMISTRY
export const LEGENDS_CLUB_ID=112658
export const LEGENDS_LEAGUE_ID=2118
export const LEAGUE_HERO_CLUB_ID=114605
export const FALLBACK_THRESHOLDS=Object.freeze({club:Object.freeze([Object.freeze({requirement:2,points:1}),Object.freeze({requirement:4,points:1}),Object.freeze({requirement:7,points:1})]),league:Object.freeze([Object.freeze({requirement:3,points:1}),Object.freeze({requirement:5,points:1}),Object.freeze({requirement:8,points:1})]),nation:Object.freeze([Object.freeze({requirement:2,points:1}),Object.freeze({requirement:5,points:1}),Object.freeze({requirement:8,points:1})])})
const isNum=(value)=>typeof value==='number'&&Number.isFinite(value)
export const isId=(value)=>isNum(value)&&value>0
export function isLegend(p){return p?.legend===true||clubOf(p)===LEGENDS_CLUB_ID||leagueOf(p)===LEGENDS_LEAGUE_ID}
export function isLeagueHero(p){return p?.leagueHero===true||clubOf(p)===LEAGUE_HERO_CLUB_ID}
export function isSuperChem(p){return p?.superChem===true}
export function contributionsOf(p,{manager=false}={}){const legend=!manager&&isLegend(p)
const hero=!manager&&isLeagueHero(p)
const chem=!manager&&isSuperChem(p)
return{club:!chem&&(hero||legend||manager)?0:1,league:hero||chem?2:1,nation:legend?2:1}}
function pointsFor(contributions,thresholds){if(!Array.isArray(thresholds)||thresholds.length===0)return 0
const cap=thresholds.reduce((max,t)=>Math.max(max,t.requirement),0)
const capped=Math.min(contributions,cap)
return thresholds.reduce((sum,t)=>capped>=t.requirement?sum+t.points:sum,0)}
const pointsTables=new WeakMap()
const POINTS_CAP=1024
function pointsTableFor(thresholds){if(!Array.isArray(thresholds)||thresholds.length===0)return null
let memo=pointsTables.get(thresholds)
if(memo!==undefined){if(memo.snapshot.length!==thresholds.length*2)memo=undefined
else for(let at=0;at<thresholds.length;at+=1){const step=thresholds[at]
if(memo.snapshot[at*2]!==step?.requirement||memo.snapshot[at*2+1]!==step?.points){memo=undefined
break}}}
if(memo===undefined){const cap=thresholds.reduce((max,t)=>Math.max(max,t.requirement),0)
if(!Number.isInteger(cap)||cap<0||cap>POINTS_CAP)return null
const table=new Int32Array(cap+1)
for(let at=0;at<=cap;at+=1)table[at]=pointsFor(at,thresholds)
const snapshot=[]
for(const step of thresholds)snapshot.push(step?.requirement,step?.points)
memo={table,snapshot}
pointsTables.set(thresholds,memo)}
return memo.table}
function pointsBy(table,thresholds,contributions){if(table===null||!Number.isInteger(contributions)||contributions<0)return pointsFor(contributions,thresholds)
return table[contributions>=table.length?table.length-1:contributions]}
const chemAlive=new Uint8Array(FIELD_PLAYERS)
const chemInPos=new Uint8Array(FIELD_PLAYERS)
const chemLegend=new Uint8Array(FIELD_PLAYERS)
const chemClub=new Array(FIELD_PLAYERS)
const chemLeague=new Array(FIELD_PLAYERS)
const chemNation=new Array(FIELD_PLAYERS)
const chemLeaguesInPos=new Set
const chemUniversal=new Set
function chemAdd(map,id,amount,inPosition){if(!isId(id)||amount<=0)return
const entry=map.get(id)??{contributions:0,missed:0}
if(inPosition)entry.contributions+=amount
else entry.missed+=amount
map.set(id,entry)}
function chemParam(slot,map,id,table,thresholds,inPosition){if(!isId(id))return 0
const entry=map.get(id)
if(!entry||entry.contributions<=0)return 0
const points=pointsBy(table,thresholds,entry.contributions)
if(!inPosition){slot.missed+=points
return 0}
slot.points+=points
return points}
export function squadChemistry(input={}){const players=Array.isArray(input.players)?input.players:[]
const positions=Array.isArray(input.formationPositions)?input.formationPositions:[]
if(players.length!==FIELD_PLAYERS)return{ok:false,reason:'need-11-players'}
if(positions.length!==FIELD_PLAYERS||!positions.every(isNum))return{ok:false,reason:'need-11-positions'}
const thresholds=input.thresholds??FALLBACK_THRESHOLDS
const fallback=input.thresholds===undefined
const manager=input.manager&&typeof input.manager==='object'?input.manager:null
const linkedTeam=typeof input.linkedTeam==='function'?input.linkedTeam:null
const normalizeClub=(teamId)=>{if(!isId(teamId)||linkedTeam===null)return teamId
try{const linked=linkedTeam(teamId)
return isId(linked)?linked:teamId}catch{return teamId}}
let legendsInPos=0
let legendsAll=0
chemLeaguesInPos.clear()
for(let at=0;at<FIELD_PLAYERS;at+=1){const p=players[at]
const alive=p!=null&&p?.valid!==false
const own=p?.possiblePositions
const inPosition=Array.isArray(own)&&own.includes(positions[at])
chemAlive[at]=alive?1:0
chemInPos[at]=inPosition?1:0
const legend=alive&&isLegend(p)
chemLegend[at]=legend?1:0
if(legend){legendsAll+=1
if(inPosition)legendsInPos+=1}
chemClub[at]=alive?normalizeClub(clubOf(p)):undefined
const league=alive?leagueOf(p):undefined
chemLeague[at]=league
chemNation[at]=alive?nationOf(p):undefined
if(alive&&inPosition)chemLeaguesInPos.add(league)}
const legendsOut=legendsAll-legendsInPos
const counters={club:new Map,league:new Map,nation:new Map}
chemUniversal.clear()
for(let at=0;at<=FIELD_PLAYERS;at+=1){const isManager=at===FIELD_PLAYERS
if(isManager&&manager===null)break
const p=isManager?manager:players[at]
if(!isManager&&chemAlive[at]===0)continue
const inPosition=isManager?true:chemInPos[at]===1
const give=contributionsOf(p,{manager:isManager})
const club=isManager?normalizeClub(clubOf(p)):chemClub[at]
const league=isManager?leagueOf(p):chemLeague[at]
const nation=isManager?nationOf(p):chemNation[at]
if(club!==LEGENDS_CLUB_ID&&club!==LEAGUE_HERO_CLUB_ID)chemAdd(counters.club,club,give.club,inPosition)
if(league!==LEGENDS_LEAGUE_ID&&isId(league)){chemAdd(counters.league,league,give.league,inPosition)
if(!chemUniversal.has(league)){chemUniversal.add(league)
if(chemLeaguesInPos.has(league))chemAdd(counters.league,league,legendsInPos,true)
else chemAdd(counters.league,league,legendsInPos,false)
chemAdd(counters.league,league,legendsOut,false)}}
chemAdd(counters.nation,nation,give.nation,inPosition)}
const tableClub=pointsTableFor(thresholds?.club)
const tableLeague=pointsTableFor(thresholds?.league)
const tableNation=pointsTableFor(thresholds?.nation)
const slots=new Array(FIELD_PLAYERS)
let chemistry=0
for(let at=0;at<FIELD_PLAYERS;at+=1){const slot={points:0,missed:0,inPosition:false,club:0,league:0,nation:0}
slots[at]=slot
if(chemAlive[at]===0)continue
const p=players[at]
const inPosition=chemInPos[at]===1
slot.inPosition=inPosition
if(inPosition&&(chemLegend[at]===1||isLeagueHero(p)||isSuperChem(p)))slot.points=SLOT_MAX_CHEMISTRY
slot.club=chemParam(slot,counters.club,chemClub[at],tableClub,thresholds?.club,inPosition)
slot.league=chemParam(slot,counters.league,chemLeague[at],tableLeague,thresholds?.league,inPosition)
slot.nation=chemParam(slot,counters.nation,chemNation[at],tableNation,thresholds?.nation,inPosition)
if(slot.points>SLOT_MAX_CHEMISTRY){slot.points=SLOT_MAX_CHEMISTRY
slot.missed=0}else if(slot.points+slot.missed>SLOT_MAX_CHEMISTRY)slot.missed=SLOT_MAX_CHEMISTRY-slot.points
chemistry+=slot.points}
return{ok:true,chemistry,slots,counters,fallback}}
const arrangeFits=new WeakMap()
let arrangeRows=[]
let arrangeSlotOf=new Int32Array(0)
let arrangeSeen=new Int32Array(0)
let arrangePlaced=new Uint8Array(0)
let arrangeStamp=0
let arrangeCount=0
function arrangeRowOf(player,positions){const own=player?.possiblePositions
const row=new Uint8Array(positions.length)
if(Array.isArray(own))for(let slot=0;slot<positions.length;slot+=1){if(own.includes(positions[slot]))row[slot]=1}
return row}
function arrangePlace(i){const row=arrangeRows[i]
for(let slot=0;slot<arrangeCount;slot+=1){if(arrangeSeen[slot]===arrangeStamp||row[slot]===0)continue
arrangeSeen[slot]=arrangeStamp
if(arrangeSlotOf[slot]===-1||arrangePlace(arrangeSlotOf[slot])){arrangeSlotOf[slot]=i
return true}}
return false}
export function arrangeForFormation(players,formationPositions){const list=Array.isArray(players)?players:[]
const n=list.length
if(!Array.isArray(formationPositions)||formationPositions.length!==n)return list
let memo=arrangeFits.get(formationPositions)
if(memo!==undefined){const snapshot=memo.snapshot
if(snapshot.length!==n)memo=undefined
else for(let slot=0;slot<n;slot+=1){if(snapshot[slot]!==formationPositions[slot]){memo=undefined
break}}}
if(memo===undefined){memo={snapshot:formationPositions.slice(),rows:new WeakMap}
arrangeFits.set(formationPositions,memo)}
if(arrangeSlotOf.length<n){arrangeSlotOf=new Int32Array(n)
arrangeSeen=new Int32Array(n)
arrangePlaced=new Uint8Array(n)
arrangeRows=new Array(n)}
arrangeCount=n
arrangeStamp=0
for(let i=0;i<n;i+=1){const player=list[i]
if(player!==null&&typeof player==='object'){let row=memo.rows.get(player)
if(row===undefined){row=arrangeRowOf(player,formationPositions)
memo.rows.set(player,row)}
arrangeRows[i]=row}
else arrangeRows[i]=arrangeRowOf(player,formationPositions)
arrangeSlotOf[i]=-1
arrangeSeen[i]=0
arrangePlaced[i]=0}
for(let i=0;i<n;i+=1){arrangeStamp+=1
arrangePlace(i)}
for(let slot=0;slot<n;slot+=1){const taken=arrangeSlotOf[slot]
if(taken!==-1)arrangePlaced[taken]=1}
const out=new Array(n)
let spare=0
for(let slot=0;slot<n;slot+=1){const taken=arrangeSlotOf[slot]
if(taken!==-1){out[slot]=list[taken]
continue}
while(spare<n&&arrangePlaced[spare]===1)spare+=1
out[slot]=list[spare]
spare+=1}
return out}
