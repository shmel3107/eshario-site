import{classifyStatus} from '../adapter/error-codes.js'
const HARMLESS=Object.freeze(['gone','throttled','transient'])
const isCount=(value)=>Number.isSafeInteger(value)&&value>=0
export function createSession(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('session: нужны часы (правило 6 NIGHT_BRIEF)')}
const dryRun=deps.dryRun===true
const startedAt=clock.now()
let coins=deps.startingCoins===undefined?0:(isCount(deps.startingCoins)?deps.startingCoins:null)
let purchases=0
let wouldBuy=0
let searches=0
let policySkipped=0
let spent=0
let earned=0
let bids=0
let outbid=0
let actions=0
let moved=0
let rests=0
let unknownOutcomes=0
let listings=0
let listedValue=0
let quickSells=0
let relisted=0
let cleared=0
let captcha=false
let fatal=null
let lastFailure=null
const coinsNow=()=>coins
const failures={captcha:0,fatal:0,'out-of-coins':0,gone:0,throttled:0,transient:0,unknown:0}
return{
isDryRun:()=>dryRun,
recordSearch(){searches+=1
return searches},
recordPolicySkipped(count=1){if(Number.isSafeInteger(count)&&count>=0)policySkipped+=count
return policySkipped},
recordPurchase(price){
const value=isCount(price)?price:0
spent+=value
coins=isCount(coins)?Math.max(0,coins-value):null
if(dryRun){wouldBuy+=1
if(isCount(coins))coins+=value}else{purchases+=1}
return{executed:!dryRun,spent:value}},
recordBid(amount){bids+=1
const value=isCount(amount)?amount:0
if(!dryRun)coins=isCount(coins)?Math.max(0,coins-value):null
return{placed:!dryRun,amount:value}},
recordOutbid(){outbid+=1
return outbid},
recordAction(){actions+=1
return actions},
releaseAction(){if(actions>0)actions-=1
return actions},
recordListing(price){listings+=1
const value=isCount(price)?price:0
listedValue+=value
return{listed:!dryRun,price:value}},
recordQuickSell(coins){quickSells+=1
const value=isCount(coins)?coins:0
earned+=value
if(!dryRun)this.setCoins(isCount(coinsNow())?coinsNow()+value:null)
return{sold:!dryRun,coins:value}},
recordRelist(count=1){relisted+=isCount(count)?count:0
return relisted},
recordCleared(count=1){cleared+=isCount(count)?count:0
return cleared},
recordMove(count=1){moved+=isCount(count)?count:0
return moved},
recordRest(){rests+=1
return rests},
recordUnknown(amount,spend=true){unknownOutcomes+=1
const value=isCount(amount)?amount:0
if(spend!==false)spent+=value
if(!dryRun)coins=isCount(coins)?Math.max(0,coins-value):null
return{amount:value,spend:spend!==false}},
recordSale(price){const value=isCount(price)?price:0
earned+=value
if(!dryRun)coins=isCount(coins)&&isCount(coins+value)?coins+value:null
return earned},
recordFailure(status){const category=classifyStatus(status)
if(Object.hasOwn(failures,category))failures[category]+=1
else failures.unknown+=1
lastFailure={status:Number.isFinite(status)?status:null,category,at:clock.now()}
if(category==='captcha') captcha=true
if(category==='fatal') fatal=status
return{category,stop:!HARMLESS.includes(category)}},
setCoins(value){coins=isCount(value)?value:null
return coins},
snapshot(){return{coins,spent,
earned,
loss:Math.max(0,spent-earned),purchases,actions,searches,startedAt,captcha}},
stats(){return{...this.snapshot(),dryRun,earned,profit:earned-spent,wouldBuy,policySkipped,bids,outbid,actions,moved,rests,unknownOutcomes,listings,listedValue,quickSells,relisted,cleared,failures:{...failures},fatal,
lastFailure:lastFailure===null?null:{...lastFailure},elapsedMs:clock.now()-startedAt}}}}
