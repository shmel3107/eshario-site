import{SAFE_LIMIT_DEFAULTS,LIMIT_FIELDS} from '../automation/limits-input.js'
import{OPTION_FIELDS,AFTER_BUY_DEFAULT,SEARCH_REFRESH_DEFAULT,CONFIRM_EACH_RUN_DEFAULT,RATING_SEARCH_NOW_DEFAULT,defaultOptionInput} from '../automation/options-input.js'
import{DEFAULT_SEARCH_DELAY_MS,BUY_PAUSE_MS,SAFE_PAUSE_FLOOR_MS,BUY_PAUSE_FLOOR_MS,WORK_MS,BREAK_MS,MAX_PER_SEARCH_DEFAULT,MATCH_GUARD_DEFAULT} from '../automation/sniper.js'
import{SELLER_FIELDS,sanitizeSellerOptions} from '../features/seller-actions.js'
import{PACK_SHOW_DEFAULTS,SHOW_RATING_DEFAULT,PACK_SHOW_MODE_DEFAULT} from '../features/pack-show.js'
import{SOLVER_DEFAULTS} from '../features/solver-options.js'
import{THRESHOLD_DEFAULT as SNIPE_KEY_THRESHOLD_DEFAULT} from '../features/snipe-key.js'
import{RELIST_MODE_DEFAULT,RELIST_PERCENT_DEFAULT} from '../features/transfer-list.js'
import{VOLUME_DEFAULT} from '../features/sound.js'
import{PICK_PRESELECT_DEFAULT} from '../features/pick-prices.js'
import{defaultToggles} from './index.js'
export const REGISTRY_CONSTANTS=Object.freeze({SAFE_LIMIT_DEFAULTS,PACK_SHOW_DEFAULTS,SHOW_RATING_DEFAULT,SOLVER_DEFAULTS,FEATURE_DEFAULTS:defaultToggles(),DEFAULT_SEARCH_DELAY_MS,BUY_PAUSE_MS,SAFE_PAUSE_FLOOR_MS,BUY_PAUSE_FLOOR_MS,WORK_MS,BREAK_MS,MAX_PER_SEARCH_DEFAULT,MATCH_GUARD_DEFAULT,AFTER_BUY_DEFAULT,SEARCH_REFRESH_DEFAULT,CONFIRM_EACH_RUN_DEFAULT,RATING_SEARCH_NOW_DEFAULT,SNIPE_KEY_THRESHOLD_DEFAULT,RELIST_MODE_DEFAULT,RELIST_PERCENT_DEFAULT,VOLUME_DEFAULT,PICK_PRESELECT_DEFAULT,PACK_SHOW_MODE_DEFAULT})
const SCALES=new Map()
for(const field of LIMIT_FIELDS)SCALES.set(`limits.${field.key}`,field.scale)
for(const field of OPTION_FIELDS)SCALES.set(`options.${field.key}`,field.scale)
for(const field of SELLER_FIELDS)SCALES.set(`seller.${field.key}`,field.scale)
export const scaleOf=(store)=>SCALES.get(store)??1
export const STORE_FIELDS=Object.freeze({toggles:Object.freeze(Object.keys(defaultToggles())),limits:Object.freeze(LIMIT_FIELDS.map((field)=>field.key)),options:Object.freeze(Object.keys(defaultOptionInput())),seller:Object.freeze(Object.keys(sanitizeSellerOptions(null)))})
export const REGISTRY_SOURCES=Object.freeze({constants:REGISTRY_CONSTANTS,scaleOf})
