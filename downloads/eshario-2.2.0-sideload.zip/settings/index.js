import{FEATURES} from '../licensing/features.js'
export{SECTIONS,STORE_BUCKETS,LEVELS,KINDS,TIERS,MAIN_LIMIT,SHELL_KEYS,CHROME_KEYS,DATA_KEYS,MOVED_KEYS,allOrgans,shippedOrgans,organsOf,findOrgan,storePaths,defaultOf,floorOf,togglesInRegistry,COVERS_ALL_FEATURES} from './registry.js'
export const OFF_BY_DEFAULT=Object.freeze(['promoClose'])
export const labelKeyFor=(feature)=>`settings.feature.${feature}`
export function toggleRegistry(registry=FEATURES){const out={}
for(const id of Object.keys(registry)){out[id]=Object.freeze({default:!OFF_BY_DEFAULT.includes(id),labelKey:labelKeyFor(id)})}
return Object.freeze(out)}
export function defaultToggles(registry=FEATURES){const toggles=toggleRegistry(registry)
const out={}
for(const[id,meta]of Object.entries(toggles))out[id]=meta.default
return out}
export function sanitize(stored,registry=FEATURES){const result=defaultToggles(registry)
if(!stored||typeof stored!=='object'||Array.isArray(stored)) return result
for(const[id,value]of Object.entries(stored)){
if(Object.hasOwn(result,id)&&typeof value==='boolean') result[id]=value}
return result}
export function createMemoryProvider(initial={}){let state=sanitize(initial)
return{read:()=>({...state}),write(next){state=sanitize(next)}}}
export function createSettings(opts={}){const provider=opts.provider??createMemoryProvider()
const registry=opts.registry??FEATURES
const isEnabled=opts.isEnabled??(()=>true)
const toggles=toggleRegistry(registry)
function state(){try{return sanitize(provider.read(),registry)}catch{
return defaultToggles(registry)}}
const isKnown=(feature)=>typeof feature==='string'&&Object.hasOwn(toggles,feature)
return{
isOn(feature){if(!isKnown(feature))return false
return state()[feature]===true},
isActive(feature){if(!isKnown(feature))return false
return Boolean(isEnabled(feature))&&state()[feature]===true},
statusOf(feature){if(!isKnown(feature)) return 'unknown'
if(!isEnabled(feature)) return 'not-entitled'
return state()[feature]===true?'active':'switched-off'
},
set(feature,value){if(!isKnown(feature)) return{ok:false,reason:'unknown-feature'}
if(typeof value!=='boolean') return{ok:false,reason:'not-a-boolean'}
const next={...state(),[feature]:value}
try{provider.write(next)}catch(err){return{ok:false,reason:'write-failed',detail:String(err?.message??err)}}
return{ok:true,reason:null}},
reset(){try{provider.write(defaultToggles(registry))
return{ok:true,reason:null}}catch(err){return{ok:false,reason:'write-failed',detail:String(err?.message??err)}}},
all:()=>state(),
registry:()=>toggles,
isKnown}}
