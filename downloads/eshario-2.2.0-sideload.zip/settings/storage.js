import{defaultToggles,sanitize} from './index.js'
import{createCachedProvider} from '../core/storage-provider.js'
export const STORAGE_KEY='settings.toggles'
export const READ_METHOD='settings.read'
export const WRITE_METHOD='settings.write'
export function chromeStorageArea(win=globalThis){const area=win?.chrome?.storage?.local
if(!area||typeof area.get!=='function'||typeof area.set!=='function'){throw new Error('settings: chrome.storage.local недоступен')}
return area}
export function createStorageProvider(opts={}){const area=opts.area??chromeStorageArea()
return createCachedProvider({fetch:async()=>(await area.get(STORAGE_KEY))?.[STORAGE_KEY],push:(value)=>area.set({[STORAGE_KEY]:value}),sanitize,fallback:defaultToggles,onError:opts.onError})}
export function createBridgeProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function'){throw new Error('settings: мост недоступен')}
return createCachedProvider({fetch:()=>bridge.request(READ_METHOD),push:(value)=>bridge.request(WRITE_METHOD,value),sanitize,fallback:defaultToggles,onError:opts.onError})}
