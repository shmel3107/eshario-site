import{FEATURES} from '../licensing/features.js'
export const STORE_BUCKETS=Object.freeze({toggles:'settings.toggles',limits:'automation.limits',options:'automation.options',seller:'seller.options',ui:'ui.state',license:'license.key'})
export const LEVELS=Object.freeze(['main','fine'])
export const ZONES=Object.freeze([])
export const PLACES=Object.freeze(['window'])
export const inWindow=(organ)=>organ?.place==='window'
export const onScreen=(organ)=>organ?.place!=='window'
export function organsAt(sectionId,place,sections=SECTIONS){const found=sections.find((one)=>one.id===sectionId)
if(!found)return[]
const wants=place==='screen'?onScreen:inWindow
return found.organs.filter((item)=>item.shipped===true&&wants(item))}
export const KINDS=Object.freeze(['toggle','number','choice','action','link','text'])
export const TIERS=Object.freeze(['all','pro'])
export const MAIN_LIMIT=3
export const SHELL_KEYS=Object.freeze(['ui.collapsed','ui.position','ui.legacyOpen'])
export const CHROME_KEYS=Object.freeze(['ui.locale'])
export const DATA_KEYS=Object.freeze(['automation.ledger','automation.journal'])
export const MOVED_KEYS=Object.freeze({'filters.sets':'экран рынка, фича advancedFilters',
'limits.maxPurchases':'полоса бота на родном экране поиска, ряд «Этот запуск»',
'options.ratingSearchNow':'шапка окна «Дешевейшие по рейтингу» на родном экране поиска'})
const NO_STATUS=null
const organ=(value)=>Object.freeze({kind:'toggle',level:'fine',zone:null,place:'window',tier:'all',hintKey:null,default:null,defaultFrom:null,unit:null,store:null,floor:null,feature:null,danger:false,shipped:true,...value})
const section=(value)=>Object.freeze({tier:'all',icon:'',feature:null,status:NO_STATUS,...value,zones:Object.freeze((value.zones??[]).map((one)=>Object.freeze({...one}))),organs:Object.freeze((value.organs??[]).map(organ))})
const featureLabel=(id)=>`settings.feature.${id}`
const featureDefault=(id)=>`FEATURE_DEFAULTS.${id}`
const featureToggle=(id,extra={})=>({id:extra.id??id,kind:'toggle',labelKey:featureLabel(id),defaultFrom:featureDefault(id),store:`toggles.${id}`,feature:id,...extra})
export const SECTIONS=Object.freeze([
section({id:'features',order:1,tier:'all',icon:'view',status:'settings',
titleKey:'settings.section.features.title',hintKey:'settings.section.features.hint',organs:[
featureToggle('homeLayout',{id:'homeLayout',level:'main'}),
featureToggle('navCenter',{id:'navCenter',level:'main'}),
featureToggle('headBar',{id:'headBar',level:'main',hintKey:'settings.organ.features.headBar.hint'}),
featureToggle('cardGrid',{id:'cardGrid'}),
featureToggle('dimOwned',{id:'dimOwned',hintKey:'settings.organ.club.dimOwned.hint'}),
featureToggle('autologin',{id:'autologin',hintKey:'settings.organ.features.autologin.hint'}),
featureToggle('promoClose',{id:'promoClose',hintKey:'settings.organ.features.promoClose.hint'}),
{id:'improvements',kind:'toggle',default:true,
labelKey:'settings.organ.view.improvements.label',hintKey:'settings.organ.view.improvements.hint',
group:['enhancedTransferList','squadScreen','clubBar','dropdownSearch','enhancedClubList','enhancedObjectivesList','enhancedUnassignedList','unassignedTools','hubRewards']},
featureToggle('enhancedTransferList',{id:'enhancedTransferList',groupIn:'improvements',labelKey:'settings.organ.view.place.transferList'}),
featureToggle('squadScreen',{id:'squadScreen',groupIn:'improvements',labelKey:'settings.organ.view.place.squad'}),
featureToggle('clubBar',{id:'clubBar',groupIn:'improvements',labelKey:'settings.organ.view.place.clubBar'}),
featureToggle('dropdownSearch',{id:'dropdownSearch',groupIn:'improvements',labelKey:'settings.organ.view.place.dropdown'}),
featureToggle('enhancedClubList',{id:'enhancedClubList',groupIn:'improvements',labelKey:'settings.organ.view.place.club'}),
featureToggle('enhancedObjectivesList',{id:'enhancedObjectivesList',groupIn:'improvements',labelKey:'settings.organ.view.place.objectives'}),
featureToggle('enhancedUnassignedList',{id:'enhancedUnassignedList',groupIn:'improvements',labelKey:'settings.organ.view.place.unassigned'}),
featureToggle('unassignedTools',{id:'unassignedTools',groupIn:'improvements',labelKey:'settings.organ.view.place.unassignedTools'}),
featureToggle('hubRewards',{id:'hubRewards',groupIn:'improvements',labelKey:'settings.organ.view.place.rewards'})]}),
section({id:'market',order:2,tier:'all',icon:'prices',
titleKey:'settings.section.market.title',hintKey:'settings.section.market.hint',organs:[
{id:'priceTags',kind:'toggle',level:'main',default:true,
labelKey:'settings.organ.market.priceTags.label',hintKey:'settings.organ.market.priceTags.hint',
group:['priceBadges','priceSources']},
featureToggle('priceBadges',{id:'priceBadges',groupIn:'priceTags'}),
featureToggle('priceSources',{id:'priceSources',groupIn:'priceTags'}),
featureToggle('minBinSearch',{id:'minBinSearch',level:'main',hintKey:'settings.organ.market.minBinSearch.hint'}),
featureToggle('eaTax',{id:'eaTax',level:'main'}),
featureToggle('advancedFilters',{id:'quickSearch',shipped:false,hintKey:'settings.organ.market.quickSearch.hint'}),
{id:'listingMode',kind:'choice',
labelKey:'settings.organ.market.listingMode.label',hintKey:'settings.organ.market.listingMode.hint',
defaultFrom:'RELIST_MODE_DEFAULT',store:'ui.listing.mode',feature:'autoSeller',
sub:['listingDirection','listingPercent','listingSample']},
{id:'listingDirection',kind:'choice',subIn:'listingMode',
labelKey:'transfers.gear.direction',store:'ui.listing.direction',feature:'autoSeller'},
{id:'listingPercent',kind:'number',subIn:'listingMode',subMode:'percent',
labelKey:'transfers.gear.percent',unit:'seller.field.percent',
defaultFrom:'RELIST_PERCENT_DEFAULT',store:'ui.listing.percent',feature:'autoSeller'},
{id:'listingSample',kind:'text',subIn:'listingMode',sample:true,
labelKey:'settings.organ.market.sample.label',feature:'autoSeller'},
{id:'relistMode',kind:'choice',
labelKey:'settings.organ.market.relistMode.label',hintKey:'settings.organ.market.relistMode.hint',
defaultFrom:'RELIST_MODE_DEFAULT',store:'ui.relist.mode',feature:'enhancedTransferList',
sub:['relistDirection','relistPercent','relistSample']},
{id:'relistDirection',kind:'choice',subIn:'relistMode',
labelKey:'transfers.gear.direction',store:'ui.relist.direction',feature:'enhancedTransferList'},
{id:'relistPercent',kind:'number',subIn:'relistMode',subMode:'percent',
labelKey:'transfers.gear.percent',unit:'seller.field.percent',
defaultFrom:'RELIST_PERCENT_DEFAULT',store:'ui.relist.percent',feature:'enhancedTransferList'},
{id:'relistSample',kind:'text',subIn:'relistMode',sample:true,
labelKey:'settings.organ.market.sample.label',feature:'enhancedTransferList'}]}),
section({id:'snipe',order:3,tier:'all',icon:'snipe',feature:'autoBuyer',status:'automation',
titleKey:'settings.section.snipe.title',hintKey:'settings.section.snipe.hint',
organs:[
featureToggle('autoSnipe',{id:'enabled',level:'main',labelKey:'settings.organ.snipe.enabled.label',hintKey:'settings.organ.snipe.enabled.hint'}),
{id:'confirmEachRun',kind:'toggle',level:'main',labelKey:'settings.organ.snipe.confirmEachRun.label',defaultFrom:'CONFIRM_EACH_RUN_DEFAULT',store:'options.confirmEachRun'},
{id:'matchGuard',kind:'toggle',level:'main',labelKey:'settings.organ.snipe.matchGuard.label',hintKey:'settings.organ.snipe.matchGuard.hint',default:true,store:'options.matchGuard'},
{id:'allowUnassignedOverflow',kind:'toggle',shipped:false,labelKey:'automation.option.allowUnassignedOverflow',hintKey:'settings.organ.snipe.allowUnassignedOverflow.hint',default:false,store:'options.allowUnassignedOverflow'},
{id:'maxDurationMs',kind:'number',labelKey:'automation.limit.maxDuration',hintKey:'settings.organ.snipe.maxDurationMs.hint',defaultFrom:'SAFE_LIMIT_DEFAULTS.maxDurationMs',unit:'automation.limit.minutes',store:'limits.maxDurationMs'},
{id:'breakWorkMin',kind:'number',labelKey:'automation.option.breakWork',hintKey:'settings.organ.snipe.breakWorkMin.hint',defaultFrom:'WORK_MS',unit:'automation.limit.minutes',store:'options.breakWorkMin'},
{id:'breakRestMin',kind:'number',labelKey:'automation.option.breakRest',hintKey:'settings.organ.snipe.breakRestMin.hint',defaultFrom:'BREAK_MS',unit:'automation.limit.minutes',store:'options.breakRestMin'},
{id:'searchDelaySec',kind:'number',labelKey:'automation.option.searchDelay',hintKey:'settings.organ.snipe.searchDelaySec.hint',defaultFrom:'DEFAULT_SEARCH_DELAY_MS',unit:'automation.option.seconds',store:'options.searchDelaySec',
floor:{from:'SAFE_PAUSE_FLOOR_MS',danger:true,hard:true}},
{id:'buyDelaySec',kind:'number',labelKey:'automation.option.buyDelay',hintKey:'settings.organ.snipe.buyDelaySec.hint',defaultFrom:'BUY_PAUSE_MS',unit:'automation.option.seconds',store:'options.buyDelaySec',
floor:{from:'BUY_PAUSE_FLOOR_MS',danger:true,hard:true}},
featureToggle('notifications',{id:'buySound',after:'soundVolume'}),
{id:'soundVolume',kind:'choice',afterIn:'buySound',labelKey:'settings.organ.snipe.soundVolume.label',hintKey:'settings.organ.snipe.soundVolume.hint',defaultFrom:'VOLUME_DEFAULT',store:'ui.soundVolume'},
{id:'afterBuy',kind:'choice',labelKey:'snipe.settings.afterBuy',defaultFrom:'AFTER_BUY_DEFAULT',store:'options.afterBuy'},
featureToggle('autoBuyer',{id:'buys',shipped:false}),
{id:'spendCap',kind:'number',shipped:false,labelKey:'automation.limit.maxSpend',hintKey:'settings.organ.snipe.spendCap.hint',store:'limits.maxSpend'},
{id:'maxPrice',kind:'number',shipped:false,labelKey:'automation.option.maxPrice',hintKey:'settings.organ.snipe.maxPrice.hint',store:'options.maxPrice'},
{id:'minCoins',kind:'number',shipped:false,labelKey:'automation.limit.minCoins',hintKey:'settings.organ.snipe.minCoins.hint',store:'limits.minCoins'},
{id:'maxBid',kind:'number',shipped:false,labelKey:'automation.option.maxBid',hintKey:'settings.organ.snipe.maxBid.hint',store:'options.maxBid'},
{id:'resaleMarginPercent',kind:'number',shipped:false,labelKey:'automation.option.resaleMargin',hintKey:'settings.organ.snipe.resaleMarginPercent.hint',unit:'seller.field.percent',store:'options.resaleMarginPercent'},
{id:'resaleMinProfit',kind:'number',shipped:false,labelKey:'automation.option.resaleMinProfit',hintKey:'settings.organ.snipe.resaleMinProfit.hint',store:'options.resaleMinProfit'},
{id:'maxActions',kind:'number',shipped:false,labelKey:'automation.limit.maxActions',hintKey:'settings.organ.snipe.maxActions.hint',defaultFrom:'SAFE_LIMIT_DEFAULTS.maxActions',store:'limits.maxActions'},
{id:'maxSearches',kind:'number',shipped:false,labelKey:'automation.limit.maxSearches',hintKey:'settings.organ.snipe.maxSearches.hint',store:'limits.maxSearches'},
{id:'maxPerSearch',kind:'number',shipped:false,labelKey:'snipe.settings.maxPerSearch',hintKey:'settings.organ.snipe.maxPerSearch.hint',defaultFrom:'MAX_PER_SEARCH_DEFAULT',store:'options.maxPerSearch'},
{id:'searchRefresh',kind:'choice',shipped:false,labelKey:'marketBot.refresh',hintKey:'marketBot.refreshHint',defaultFrom:'SEARCH_REFRESH_DEFAULT',store:'options.searchRefresh'},
{id:'maxLossCoins',kind:'number',shipped:false,labelKey:'automation.limit.maxLossCoins',hintKey:'settings.organ.snipe.maxLossCoins.hint',store:'limits.maxLossCoins'},
]}),
section({id:'solver',order:5,tier:'all',icon:'solver',feature:'sbcSolver',status:'sbc',titleKey:'settings.section.solver.title',hintKey:'settings.section.solver.hint',organs:[
featureToggle('sbcSolver',{id:'enabled',level:'main'}),
{id:'buyFromMarket',kind:'toggle',level:'main',default:true,
labelKey:'settings.organ.solver.buyFromMarket.label',hintKey:'settings.organ.solver.buyFromMarket.hint',
group:['autoBuy','adviseBuy']},
{id:'keepActiveSquad',kind:'toggle',level:'main',labelKey:'settings.organ.solver.keepActiveSquad.label',hintKey:'settings.organ.solver.keepActiveSquad.hint',defaultFrom:'SOLVER_DEFAULTS.keepActiveSquad',store:'ui.solver.keepActiveSquad'},
featureToggle('sbcAutoBuy',{id:'autoBuy',groupIn:'buyFromMarket'}),
{id:'adviseBuy',kind:'toggle',groupIn:'buyFromMarket',labelKey:'settings.organ.solver.adviseBuy.label',defaultFrom:'SOLVER_DEFAULTS.adviseBuy',store:'ui.solver.adviseBuy'}]}),
section({id:'seller',order:4,tier:'all',icon:'seller',feature:'autoSeller',status:'seller',parked:true,titleKey:'settings.section.seller.title',hintKey:'settings.section.seller.hint',organs:[
{id:'marginPercent',kind:'number',level:'main',shipped:false,labelKey:'seller.field.margin',unit:'seller.field.percent',store:'seller.marginPercent'},
{id:'minProfit',kind:'number',level:'main',shipped:false,labelKey:'seller.field.minProfit',hintKey:'settings.organ.seller.minProfit.hint',store:'seller.minProfit'},
{id:'dryRun',kind:'toggle',level:'main',shipped:false,labelKey:'seller.dryRun',hintKey:'settings.organ.seller.dryRun.hint',default:true},
featureToggle('autoSeller',{id:'enabled',shipped:false}),
{id:'allowQuickSell',kind:'toggle',shipped:false,labelKey:'seller.allowQuickSell',hintKey:'settings.organ.seller.allowQuickSell.hint',default:false,store:'seller.allowQuickSell',danger:true},
{id:'quickSellBelow',kind:'number',shipped:false,labelKey:'seller.field.quickSellBelow',store:'seller.quickSellBelow'},
{id:'maxActions',kind:'number',shipped:false,labelKey:'seller.field.maxActions',store:'seller.maxActions'},
{id:'maxDurationMs',kind:'number',shipped:false,labelKey:'automation.limit.maxDuration',unit:'automation.limit.minutes',store:'seller.maxDurationMs'}]}),
section({id:'packs',order:6,tier:'all',icon:'packs',tariff:'members',status:'packShow',titleKey:'settings.section.packs.title',hintKey:'settings.section.packs.hint',organs:[
{id:'showAlways',kind:'toggle',shipped:false,labelKey:'packs.show.always',defaultFrom:'PACK_SHOW_DEFAULTS.always',store:'ui.packShow.always',feature:'packShow'},
{id:'showSpecial',kind:'toggle',shipped:false,labelKey:'packs.show.special',defaultFrom:'PACK_SHOW_DEFAULTS.special',store:'ui.packShow.special',feature:'packShow'},
{id:'showRating',kind:'toggle',shipped:false,labelKey:'packs.show.rating',defaultFrom:'PACK_SHOW_DEFAULTS.rating',store:'ui.packShow.rating',feature:'packShow'},
{id:'showRatingMin',kind:'number',labelKey:'packs.show.ratingMin',leadKey:'settings.organ.packs.showMode.line',defaultFrom:'SHOW_RATING_DEFAULT',store:'ui.packShow.ratingMin',subIn:'showMode',feature:'packShow'},
featureToggle('packShow',{id:'show',shipped:false}),
featureToggle('packGrid',{id:'grid',level:'main',hintKey:'settings.organ.packs.grid.hint'}),
featureToggle('packPeek',{id:'peek',level:'main'}),
{id:'pickMode',kind:'choice',level:'main',labelKey:'settings.organ.packs.pickMode.label',defaultFrom:'PICK_PRESELECT_DEFAULT',store:'ui.pickPreselect',feature:'pickByPrice'},
featureToggle('pickByPrice',{id:'pickByPrice',shipped:false}),
{id:'showMode',kind:'choice',labelKey:'settings.organ.packs.showMode.label',
defaultFrom:'PACK_SHOW_MODE_DEFAULT',feature:'packShow',sub:['showRatingMin'],subWhen:'valuable'},
]}),
section({id:'hotkeys',order:7,tier:'all',icon:'keys',feature:'hotkeyNav',status:'hotkeys',titleKey:'settings.section.hotkeys.title',hintKey:'settings.section.hotkeys.hint',organs:[
featureToggle('hotkeys',{id:'enabled',level:'main',labelKey:'settings.organ.hotkeys.enabled.label'}),
{id:'open',kind:'action',level:'main',labelKey:'hotkeys.open',feature:'hotkeys'},
featureToggle('hotkeyNav',{id:'nav',level:'main',hintKey:'settings.organ.hotkeys.nav.hint'})]}),
section({id:'ledger',order:8,tier:'all',icon:'ledger',status:'ledger',parked:true,titleKey:'settings.section.ledger.title',hintKey:'settings.section.ledger.hint',organs:[
{id:'scope',kind:'choice',level:'main',shipped:false,labelKey:'settings.organ.ledger.scope.label',default:'session'},
{id:'exportCsv',kind:'action',level:'main',shipped:false,labelKey:'ledger.csv'},
{id:'reset',kind:'action',level:'main',shipped:false,labelKey:'ledger.reset',hintKey:'settings.organ.ledger.reset.hint',danger:true},
{id:'recent',kind:'text',shipped:false,labelKey:'settings.organ.journal.recent.label'},
{id:'export',kind:'action',shipped:false,labelKey:'journal.export'},
{id:'analyze',kind:'action',shipped:false,labelKey:'club.analyze',hintKey:'settings.organ.club.analyze.hint',feature:'clubAnalysis'},
featureToggle('clubAnalysis',{id:'clubAnalysis',shipped:false})]}),
section({id:'premium',order:9,tier:'all',icon:'premium',status:'license',titleKey:'settings.section.premium.title',hintKey:'settings.section.premium.hint',organs:[
{id:'buy',kind:'link',level:'main',labelKey:'settings.organ.premium.buy.label',hintKey:'settings.organ.premium.buy.hint',showWhen:'unpaid'},
{id:'saveSettings',kind:'action',level:'main',labelKey:'settings.organ.premium.saveSettings.label',hintKey:'settings.organ.premium.saveSettings.hint',showWhen:'signedIn'},
{id:'loadSettings',kind:'action',level:'main',labelKey:'settings.organ.premium.loadSettings.label',hintKey:'settings.organ.premium.loadSettings.hint',showWhen:'signedIn'},
{id:'resetAll',kind:'action',labelKey:'settings.organ.premium.resetAll.label',hintKey:'settings.organ.premium.resetAll.hint'},
{id:'account',kind:'link',labelKey:'settings.organ.premium.account.signIn',hintKey:'settings.organ.premium.account.signInHint',
signedIn:{labelKey:'settings.organ.premium.account.manage',hintKey:'settings.organ.premium.account.manageHint'}},
{id:'report',kind:'action',labelKey:'settings.organ.premium.report.label',hintKey:'settings.organ.premium.report.hint'},
{id:'key',kind:'text',level:'main',shipped:false,labelKey:'license.key',hintKey:'settings.organ.premium.key.hint',store:'license.key'},
{id:'apply',kind:'action',level:'main',shipped:false,labelKey:'license.apply'},
{id:'clear',kind:'action',shipped:false,labelKey:'license.clear',danger:true},
{id:'sync',kind:'action',shipped:false,labelKey:'settings.organ.cloud.sync.label'},
{id:'saveFile',kind:'action',shipped:false,labelKey:'settings.organ.cloud.saveFile.label'},
{id:'loadFile',kind:'action',shipped:false,labelKey:'settings.organ.cloud.loadFile.label',hintKey:'settings.organ.cloud.loadFile.hint'},
{id:'takeCloud',kind:'action',shipped:false,labelKey:'settings.organ.cloud.takeCloud.label',hintKey:'settings.organ.cloud.takeCloud.hint'},
{id:'takeLocal',kind:'action',shipped:false,labelKey:'settings.organ.cloud.takeLocal.label',hintKey:'settings.organ.cloud.takeLocal.hint'}]}),
section({id:'diagnostics',order:10,tier:'all',icon:'diagnostics',shipped:false,titleKey:'settings.section.diagnostics.title',hintKey:'settings.section.diagnostics.hint',organs:[
{id:'dayXOff',kind:'toggle',level:'main',shipped:false,labelKey:'dayX.label',hintKey:'settings.organ.diagnostics.dayXOff.hint',default:false,store:'ui.dayXOff',danger:true},
{id:'errors',kind:'text',level:'main',shipped:false,labelKey:'settings.organ.diagnostics.errors.label'},
{id:'version',kind:'text',shipped:false,labelKey:'settings.organ.diagnostics.version.label'},
{id:'guide',kind:'action',shipped:false,labelKey:'onboarding.show',default:false,store:'ui.onboarded'}]})])
export function allOrgans(sections=SECTIONS){const out=[]
for(const one of sections)for(const item of one.organs)out.push({section:one.id,organ:item})
return out}
export function shippedOrgans(sections=SECTIONS){return allOrgans(sections).filter((row)=>row.organ.shipped===true)}
export function organsOf(sectionId,level=null,sections=SECTIONS){const found=sections.find((one)=>one.id===sectionId)
if(!found)return[]
return found.organs.filter((item)=>item.shipped===true&&(level===null||item.level===level))}
export function findOrgan(sectionId,organId,sections=SECTIONS){return sections.find((one)=>one.id===sectionId)?.organs.find((item)=>item.id===organId)??null}
export function storePaths(sections=SECTIONS){return allOrgans(sections).map((row)=>row.organ.store).filter((path)=>typeof path==='string')}
export function defaultOf(organ,sources={}){if(organ?.defaultFrom===null||organ?.defaultFrom===undefined)return organ?.default??null
const raw=readPath(sources.constants??{},organ.defaultFrom)
if(raw===undefined)return undefined
if(typeof raw!=='number')return raw
const scale=typeof sources.scaleOf==='function'&&typeof organ.store==='string'?sources.scaleOf(organ.store):1
return Number.isFinite(scale)&&scale>0?raw/scale:raw}
export function floorOf(organ,sources={}){const floor=organ?.floor
if(!floor)return null
if(typeof floor.value==='number')return{value:floor.value,danger:floor.danger===true,hard:floor.hard===true}
const raw=readPath(sources.constants??{},floor.from)
if(typeof raw!=='number')return undefined
const scale=typeof sources.scaleOf==='function'&&typeof organ.store==='string'?sources.scaleOf(organ.store):1
return{value:Number.isFinite(scale)&&scale>0?raw/scale:raw,danger:floor.danger===true,hard:floor.hard===true}}
function readPath(map,path){if(typeof path!=='string'||path==='')return undefined
let value=map
for(const part of path.split('.')){if(value===null||typeof value!=='object'||!Object.hasOwn(value,part))return undefined
value=value[part]}
return value}
export function togglesInRegistry(sections=SECTIONS){return allOrgans(sections)
.filter((row)=>typeof row.organ.store==='string'&&row.organ.store.startsWith('toggles.'))
.map((row)=>row.organ.store.slice('toggles.'.length))
.sort()}
export const COVERS_ALL_FEATURES=togglesInRegistry().length===Object.keys(FEATURES).length
