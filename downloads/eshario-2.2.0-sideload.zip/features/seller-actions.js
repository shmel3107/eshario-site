import{createSession} from '../automation/session.js'
import{createStopConditions} from '../automation/stop-conditions.js'
import{createSeller} from '../automation/seller.js'
import{parseLimitInput} from '../automation/limits-input.js'
import{createCachedProvider} from '../core/storage-provider.js'
export{STOP_REASON_KEYS,stopReasonKey} from '../automation/stop-reasons.js'
export const SELLER_FEATURE='autoSeller'
export const SELLER_KEY='seller.options'
export const SELLER_READ='seller.read'
export const SELLER_WRITE='seller.write'
export const SELLER_FIELDS=Object.freeze([{key:'marginPercent',labelKey:'seller.field.margin',unitKey:'seller.field.percent',scale:1},{key:'minProfit',labelKey:'seller.field.minProfit',unitKey:null,scale:1},{key:'quickSellBelow',labelKey:'seller.field.quickSellBelow',unitKey:null,scale:1},
{key:'maxActions',labelKey:'seller.field.maxActions',unitKey:null,scale:1},{key:'maxDurationMs',labelKey:'automation.limit.maxDuration',unitKey:'automation.limit.minutes',scale:60_000}].map(Object.freeze))
export const SELLER_SAFETY_FIELDS=Object.freeze(['maxActions','maxDurationMs'])
export function sanitizeSellerOptions(stored){const out={allowQuickSell:stored?.allowQuickSell===true}
for(const field of SELLER_FIELDS){const value=stored?.[field.key]
out[field.key]=typeof value==='string'?value:''
}
return out}
export function createBridgeSellerProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function') throw new Error('seller: мост недоступен')
return createCachedProvider({fetch:()=>bridge.request(SELLER_READ),push:(value)=>bridge.request(SELLER_WRITE,value),sanitize:sanitizeSellerOptions,fallback:()=>sanitizeSellerOptions(null),onError:opts.onError})}
export function parseSellerOptions(input={}){const options={allowQuickSell:input?.allowQuickSell===true}
const errors=[]
for(const field of SELLER_FIELDS){const parsed=parseLimitInput(input?.[field.key])
if(!parsed.ok){errors.push({key:field.key,reason:parsed.reason});continue}
if(parsed.value!==null)options[field.key]=parsed.value*field.scale}
return{options,errors}}
export function sellerSafetyProblems(options={}){return SELLER_SAFETY_FIELDS.filter((key)=>(typeof options[key]!=='number'
||!Number.isFinite(options[key])
||options[key]<=0))}
export function createSellerControl(deps={}){const{clock,market}=deps
if(!clock||typeof clock.sleep!=='function') throw new Error('seller: нужны часы')
if(typeof market!=='function') throw new Error('seller: нужен доступ к рынку')
const isEnabled=typeof deps.isEnabled==='function'?deps.isEnabled:()=>true
const onUpdate=typeof deps.onUpdate==='function'?deps.onUpdate:()=>{}
const provider=deps.optionsProvider??null
const isActive=typeof deps.isActive==='function'?deps.isActive:null
const switchedOff=()=>{if(isActive===null)return null
try{return isActive(SELLER_FEATURE)===true?null:'switched-off'}catch{return'switched-off-unreadable'}}
const budgetPort=()=>{const said=typeof deps.budget==='function'?deps.budget():deps.budget
return said&&typeof said.call==='function'?said:null}
const watchers=[deps.journal,deps.ledger,deps.sounds].filter((w)=>w&&typeof w.record==='function')
const remember=(event,payload)=>{for(const watcher of watchers){try{watcher.record(event,payload)}catch{
}}}
let dryRun=true
let seller=null
let session=null
let running=false
let lastReason=null
let lastDetail=null
let lastSkipped=0
let input=sanitizeSellerOptions(provider?provider.read():null)
const notify=()=>{try{onUpdate()}catch{
}}
const persist=()=>{if(!provider)return
try{provider.write(input)}catch{
}}
return{isDryRun:()=>dryRun,isRunning:()=>running,options:()=>({...input}),
setDryRun(value){if(running) return{ok:false,notice:{key:'automation.busy',params:{}}}
dryRun=value===true
notify()
return{ok:true,notice:null}},
setOption(key,value){if(running) return{ok:false,notice:{key:'automation.busy',params:{}}}
let redraw=false
if(key==='allowQuickSell'){
input={...input,allowQuickSell:value===true}
redraw=true}else if(SELLER_FIELDS.some((field)=>field.key===key)){input={...input,[key]:typeof value==='string'?value:''}}else{return{ok:false,notice:{key:'seller.badField',params:{field:String(key)}}}}
persist()
if(redraw)notify()
return{ok:true,notice:null}},
reloadOptions(){if(provider)input=sanitizeSellerOptions(provider.read())
return{...input}},
status(){return{running,dryRun,reason:lastReason,detail:lastDetail,skippedNoPrice:lastSkipped,stats:session?session.stats():null,options:{...input}}},
start(config={}){if(running) return{ok:false,notice:{key:'automation.alreadyRunning',params:{}}}
if(!isEnabled(SELLER_FEATURE)){return{ok:false,notice:{key:'license.premiumRequired',params:{}}}}
const off=switchedOff()
if(off!==null){return{ok:false,notice:{key:'settings.switchedOff',params:{}},reason:off}}
const parsed=parseSellerOptions(input)
if(parsed.errors.length>0){return{ok:false,notice:{key:'automation.badLimitFields',params:{fields:parsed.errors.map((e)=>e.key).join(', ')}}}}
const safetyProblems=dryRun?[]:sellerSafetyProblems(parsed.options)
if(safetyProblems.length>0){return{ok:false,notice:{key:'seller.safetyLimitsRequired',params:{fields:safetyProblems.join(', ')}}}}
let live
try{live=market()}catch(err){return{ok:false,notice:{key:'automation.noMarket',params:{reason:String(err?.message??err)}}}}
if(!live
||typeof live.requestTransferItems!=='function'
||typeof live.list!=='function'){return{ok:false,notice:{key:'automation.noMarket',params:{reason:'нет requestTransferItems/list'}}}}
let stop
try{const limits={...(config.limits??{})}
if(Object.hasOwn(parsed.options,'maxDurationMs')){limits.maxDurationMs=parsed.options.maxDurationMs}
stop=createStopConditions(limits,{clock})}catch(err){return{ok:false,notice:{key:'automation.badLimits',params:{reason:String(err?.message??err)}}}}
session=createSession({clock,dryRun,startingCoins:config.coins})
seller=createSeller({market:live,session,stop,clock,budget:budgetPort(),options:{...parsed.options,...(deps.runOptions??{})},onEvent:(event,payload)=>{remember(event,payload)
if(switchedOff()!==null)seller?.cancel?.()
notify()}})
running=true
lastReason=null
lastDetail=null
lastSkipped=0
notify()
seller.run().then((result)=>{running=false;lastReason=result.reason;lastDetail=result.detail??null;lastSkipped=Number.isSafeInteger(result.skippedNoPrice)?result.skippedNoPrice:0;notify()},()=>{running=false;lastReason='unknown';lastDetail=null;notify()})
return{ok:true,notice:{key:dryRun?'seller.startedDry':'seller.startedReal',params:{}}}},
stop(){if(!running||!seller) return{ok:false,notice:{key:'automation.notRunning',params:{}}}
seller.cancel()
return{ok:true,notice:{key:'automation.stopping',params:{}}}}}}
