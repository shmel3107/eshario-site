import{readClubItems,analyzeClub} from './club-analysis.js'
export const CLUB_FEATURE='clubAnalysis'
export{PRICE_FEATURE} from './price-source.js'
export const CLUB_READY_ATTEMPTS=21
export const CLUB_READY_DELAY_MS=250
export async function analyzeClubAction(deps={}){let items
try{const club=await resolveClub(deps)
if(!club) throw new Error('клуб: адаптер ещё недоступен')
items=await readClubItems(club,{createCriteria:deps.createCriteria})}catch(err){return fail('club.readFailed',{reason:reasonOf(err)})}
if(items.length===0){
return{ok:false,analysis:null,notice:{key:'club.empty',params:{}}}}
let analysis
try{analysis=await analyzeClub({items,priceOf:deps.priceOf,priceEvidenceOf:deps.priceEvidenceOf,keepPerDefinition:deps.keepPerDefinition,maxLookups:deps.maxLookups,now:deps.clock?.now})}catch(err){return fail('club.analysisFailed',{reason:reasonOf(err)})}
return{ok:true,analysis,notice:{key:'club.analyzed',params:{total:analysis.summary.total}}}}
async function resolveClub(deps){if(hasClubSearch(deps.club))return deps.club
if(typeof deps.getClub!=='function') return null
const attempts=positiveInteger(deps.readinessAttempts,CLUB_READY_ATTEMPTS)
const delayMs=nonNegativeNumber(deps.readinessDelayMs,CLUB_READY_DELAY_MS)
const sleep=typeof deps.clock?.sleep==='function'
?deps.clock.sleep.bind(deps.clock)
:null
let lastError=null
for(let attempt=0;attempt<attempts;attempt+=1){let club=null
try{club=deps.getClub()}catch(err){lastError=err}
if(hasClubSearch(club))return club
if(attempt+1<attempts&&sleep)await sleep(delayMs)
else if(attempt+1<attempts)break}
if(lastError)throw lastError
return null}
const hasClubSearch=(club)=>Boolean(club&&typeof club.search==='function')
const positiveInteger=(value,fallback)=>(Number.isInteger(value)&&value>0?value:fallback)
const nonNegativeNumber=(value,fallback)=>(Number.isFinite(value)&&value>=0?value:fallback)
export function valueNotice(value,total){if(!value||value.priced===0){return{key:'club.valueUnknown',params:{}}}
if(value.limitReached){return{key:'club.valuePartial',params:{coins:value.coins,priced:value.priced,total}}}
return{key:'club.value',params:{coins:value.coins,priced:value.priced,total}}}
export function cardLabel(item,id){let staticName
try{staticName=item?.getStaticData?.()?.name}catch{/* сущность EA бывает не дозревшей */}
for(const value of[staticName,item?.displayName,item?.name,item?.commonName]){if(typeof value==='string'&&/[\p{L}\p{N}]/u.test(value))return value.trim()}
return String(id)}
export function cardTag(item,id){const label=cardLabel(item,id)
if(label===String(id))return label
let rating
try{rating=Number(item?.rating)}catch{/* чужая сущность своего ответа не имеет */}
return Number.isSafeInteger(rating)&&rating>=1&&rating<=99?`${label} (${rating})`:label}
const fail=(key,params)=>({ok:false,analysis:null,notice:{key,params}})
const reasonOf=(err)=>String(err?.message??err)
