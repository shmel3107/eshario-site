import{homeGridOf,homeStripsIn} from '../adapter/home-grid.js'
import{ensureStylesheet} from '../ui/dom.js'
export const COLUMNS=4
export const COLUMNS_PROPERTY='--fut-home-columns'
export const HOME_GRID_MARK='data-fut-home-grid'
export const HOME_GRID_KEY='futHomeGrid'
export const STRIPS_MARK='data-fut-home-strips'
export const STRIPS_KEY='futHomeStrips'
export const STRIPS_MAX=6
export const ROW1_MAX_PROPERTY='--fut-home-row1-max'
export const ZOOM_PROPERTY='--fut-home-zoom'
export const ZOOM_FLOOR=0.85
const ZOOM_ROUND=100
export const AIR_PROPERTY='--fut-home-air'
export const FIT_PASSES_MAX=6
export const BLIND_RETRIES_MAX=24
const FRAME_TIMEOUT_MS=200
const HOME_GRID_STYLESHEET=new URL('../ui/home-grid.css',import.meta.url).href
const HOME_GRID_LINK_ID='fut-companion-home-grid'
export function createHomeGrid(deps={}){const doc=deps.doc
if(!doc||typeof doc.createElement!=='function'){throw new Error('home-grid: нужен документ')}
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let marked=null
let seer=null
let strips=0
let слепой=false
let писалПрошлый=false
const counts={marks:0,misses:0,drops:0,wakes:0,stripWrites:0,noObserver:0,zoomWrites:0,
fits:0,fitWrites:0,fitBlind:0,
airWrites:0,
sizeWakes:0,noRuler:0,
echoCapped:0}
function styles(){try{ensureStylesheet(doc,HOME_GRID_STYLESHEET,HOME_GRID_LINK_ID)}catch(err){onError(err)}}
function syncStrips(grid){try{const now=Math.min(STRIPS_MAX,homeStripsIn(grid))
const text=String(now)
if(grid?.dataset===undefined)return false
if(grid.dataset[STRIPS_KEY]===text)return false
grid.dataset[STRIPS_KEY]=text
strips=now
counts.stripWrites+=1
return true}catch(err){onError(err)
return false}}
function touched(records,grid){const list=records??[]
for(const one of list){if(one?.type==='childList'&&one.target===grid)return true
if(one?.type==='attributes'&&one.target?.parentNode===grid)return true}
return false}
function watch(grid){if(seer!==null)return true
const win=doc?.defaultView??null
const Observer=win?.MutationObserver
if(typeof Observer!=='function'){counts.noObserver+=1
return false}
try{seer=new Observer((records)=>{if(!touched(records,grid))return
counts.wakes+=1
fitPasses=0
syncStrips(grid)
scheduleFit()})
seer.observe(grid,{childList:true,attributes:true,attributeFilter:['style'],subtree:true})
return true}catch(err){onError(err)
seer=null
return false}}
let линейка=null
let мерянный=null
function watchSize(node){if(node===null||node===undefined)return false
const win=doc?.defaultView??null
const Ruler=win?.ResizeObserver
if(typeof Ruler!=='function'){counts.noRuler+=1
return false}
try{if(линейка===null){линейка=new Ruler(()=>{counts.sizeWakes+=1
if(!писалПрошлый){fitPasses=0
scheduleFit()
return}
if(fitPasses>=FIT_PASSES_MAX){counts.echoCapped+=1
return}
scheduleFit()})}
линейка.observe(node)
return true}catch(err){onError(err)
return false}}
function unwatchSize(){if(линейка===null)return
try{линейка.disconnect?.()}catch(err){onError(err)}
линейка=null
мерянный=null}
function boxOf(grid){try{const win=doc?.defaultView??null
if(win===null||typeof win.getComputedStyle!=='function')return null
const up=(one)=>(one?.parentElement??one?.parentNode??null)
let node=up(grid)
let шагов=0
while(node!==null&&шагов<12){if(typeof node.getBoundingClientRect!=='function')return null
const flow=win.getComputedStyle(node)?.overflowY
if(flow==='auto'||flow==='scroll'||flow==='overlay')return node
node=up(node)
шагов+=1}
return null}catch(err){onError(err)
return null}}
function raceFrame(run){let done=false
const once=()=>{if(done)return
done=true
try{run()}catch(err){onError(err)}}
const win=doc?.defaultView??null
let заказан=false
if(typeof win?.requestAnimationFrame==='function'){try{win.requestAnimationFrame(once)
заказан=true}catch(err){onError(err)}}
const later=typeof win?.setTimeout==='function'?win.setTimeout.bind(win):null
if(later!==null){try{later(once,FRAME_TIMEOUT_MS)
заказан=true}catch(err){onError(err)}}
if(!заказан)once()}
function zoomOf(grid){const text=grid?.style?.getPropertyValue?.(ZOOM_PROPERTY)||''
const value=Number.parseFloat(text)
return Number.isFinite(value)&&value>0?value:1}
function airOf(grid){const text=grid?.style?.getPropertyValue?.(AIR_PROPERTY)||''
const value=Number.parseFloat(text)
return Number.isFinite(value)&&value>0?value:0}
function fit(grid){counts.fits+=1
слепой=false
писалПрошлый=false
const нечем=()=>{counts.fitBlind+=1
слепой=true
return false}
try{const win=doc?.defaultView??null
if(win===null||typeof win.getComputedStyle!=='function')return нечем()
const box=boxOf(grid)
if(box===null)return нечем()
if(box!==мерянный){мерянный=box
watchSize(box)}
const tracks=String(win.getComputedStyle(grid).gridTemplateRows||'').trim().split(/\s+/)
.map((one)=>Number.parseFloat(one))
const ряд=tracks[strips]
if(!Number.isFinite(ряд))return нечем()
const сетка=grid.getBoundingClientRect?.()??null
const ящик=box.getBoundingClientRect?.()??null
if(сетка===null||ящик===null)return нечем()
const масштаб=zoomOf(grid)
const воздух=airOf(grid)
const высота=box.clientHeight
const сверху=(сетка.top-ящик.top)+(box.scrollTop||0)
const переполнен=box.scrollHeight>высота
const снизу=переполнен?Math.max(0,box.scrollHeight-(сверху+сетка.height)):0
const рядВЯщике=ряд*масштаб
const воздухВЯщике=воздух*масштаб
const свободно=высота-сверху-(сетка.height-воздухВЯщике)-снизу
const можно=Math.max(0,Math.round((свободно+рядВЯщике)/масштаб))
if(!Number.isFinite(можно))return нечем()
const просилиРаньше=Number.parseFloat(grid.style?.getPropertyValue?.(ROW1_MAX_PROPERTY)||'')
const рядУпёрся=Number.isFinite(просилиРаньше)&&ряд>просилиРаньше+1
const масштабВернулся=масштаб>=1
const проси=масштабВернулся?можно:Math.min(можно,Math.round(ряд))
const text=проси+'px'
const писалиРяд=grid.style?.getPropertyValue?.(ROW1_MAX_PROPERTY)!==text
if(писалиРяд){grid.style?.setProperty?.(ROW1_MAX_PROPERTY,text)
counts.fitWrites+=1}
let писали=писалиРяд
const недостача=Math.max(0,-свободно)
const запас=Math.max(0,свободно)
let хотим=масштаб
if(недостача>0&&рядУпёрся&&сетка.height>0){хотим=масштаб*Math.max(0,сетка.height-недостача)/сетка.height}
else if(недостача===0&&масштаб<1&&запас>0&&сетка.height>0){хотим=масштаб*(сетка.height+запас)/сетка.height}
хотим=Math.min(1,Math.max(ZOOM_FLOOR,Math.floor(хотим*ZOOM_ROUND)/ZOOM_ROUND))
if(хотим!==масштаб){grid.style?.setProperty?.(ZOOM_PROPERTY,String(хотим))
counts.zoomWrites+=1
писали=true}
const воздухХотим=хотим===масштаб?Math.max(0,Math.round((запас-сверху)/масштаб/2)):0
const воздухТекст=воздухХотим>0?воздухХотим+'px':''
if((grid.style?.getPropertyValue?.(AIR_PROPERTY)||'')!==воздухТекст){
if(воздухТекст==='')grid.style?.removeProperty?.(AIR_PROPERTY)
else grid.style?.setProperty?.(AIR_PROPERTY,воздухТекст)
counts.airWrites+=1
писали=true}
писалПрошлый=писали
return писали}catch(err){onError(err)
return false}}
let fitPending=false
let fitPasses=0
let слепыхПодряд=0
function scheduleFit(){if(fitPending)return
if(marked===null)return
fitPending=true
raceFrame(()=>{fitPending=false
if(marked===null)return
const писали=fit(marked)
if(слепой){слепыхПодряд+=1
if(слепыхПодряд>=BLIND_RETRIES_MAX)return
scheduleFit()
return}
слепыхПодряд=0
if(!писали)return
fitPasses+=1
if(fitPasses>=FIT_PASSES_MAX)return
scheduleFit()})}
let onResize=null
function listenResize(){if(onResize!==null)return
const win=doc?.defaultView??null
if(typeof win?.addEventListener!=='function')return
onResize=()=>{fitPasses=0
scheduleFit()}
try{win.addEventListener('resize',onResize,{passive:true})}catch(err){onError(err)
onResize=null}}
function unlistenResize(){if(onResize===null)return
const win=doc?.defaultView??null
try{win?.removeEventListener?.('resize',onResize)}catch(err){onError(err)}
onResize=null}
function unwatch(){if(seer===null)return
try{seer.disconnect?.()}catch(err){onError(err)}
seer=null}
function unmark(node){if(node===null)return
try{if(node.dataset&&node.dataset[HOME_GRID_KEY]!==undefined)delete node.dataset[HOME_GRID_KEY]
if(node.dataset&&node.dataset[STRIPS_KEY]!==undefined)delete node.dataset[STRIPS_KEY]
node.style?.removeProperty?.(COLUMNS_PROPERTY)
node.style?.removeProperty?.(ROW1_MAX_PROPERTY)
node.style?.removeProperty?.(ZOOM_PROPERTY)
node.style?.removeProperty?.(AIR_PROPERTY)
counts.drops+=1}catch(err){onError(err)}}
return{
apply(shown){try{const grid=homeGridOf(shown?.root??null)
if(grid===null||grid.dataset===undefined){counts.misses+=1
return{marked:false,reason:'no-grid'}}
styles()
if(marked!==null&&marked!==grid){unwatch()
unwatchSize()
unmark(marked)}
marked=grid
fitPasses=0
слепыхПодряд=0
let changed=false
if(grid.dataset[HOME_GRID_KEY]!=='1'){grid.dataset[HOME_GRID_KEY]='1'
changed=true}
const columns=String(COLUMNS)
if(grid.style?.getPropertyValue?.(COLUMNS_PROPERTY)!==columns){grid.style?.setProperty?.(COLUMNS_PROPERTY,columns)
changed=true}
if(syncStrips(grid))changed=true
const watching=watch(grid)
const measuring=watchSize(grid)
listenResize()
scheduleFit()
if(changed)counts.marks+=1
return{marked:true,reason:null,columns:COLUMNS,strips,watching,measuring}}catch(err){onError(err)
counts.misses+=1
return{marked:false,reason:'failed'}}},
state:()=>({attached:marked!==null,columns:COLUMNS,strips,watching:seer!==null,
measuring:линейка!==null,
mark:marked?.dataset?.[HOME_GRID_KEY]==='1',
stripMark:marked?.dataset?.[STRIPS_KEY]??null,
row1Max:marked?.style?.getPropertyValue?.(ROW1_MAX_PROPERTY)||null,
zoom:marked?.style?.getPropertyValue?.(ZOOM_PROPERTY)||null,
air:marked?.style?.getPropertyValue?.(AIR_PROPERTY)||null,
counts:{...counts}}),
dispose(){unwatch()
unwatchSize()
unlistenResize()
unmark(marked)
marked=null
strips=0
fitPending=false}}}
