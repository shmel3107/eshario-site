import{createCachedProvider,storageFailed} from '../core/storage-provider.js'
import{cardLockKey} from './card-locks.js'
export const MAX_CARD_FROZEN=500
export const cardFrozenKey=cardLockKey
export function sanitizeCardFrozen(raw){const source=Array.isArray(raw)?raw:(raw&&typeof raw==='object'?raw.ids:null)
if(!Array.isArray(source))return[]
const out=[]
for(const value of source){const id=Number(value)
if(!Number.isSafeInteger(id)||id<=0||out.includes(id))continue
out.push(id)
if(out.length>=MAX_CARD_FROZEN)break}
return out}
export function createBridgeCardFrozenProvider(opts){if(typeof opts?.bridge?.request!=='function')throw new Error('frozen: мост недоступен')
const provider=createCachedProvider({fetch:()=>opts.bridge.request('frozen.read'),
push:(value)=>opts.bridge.request('frozen.write',value),
sanitize:(raw)=>({ids:sanitizeCardFrozen(raw)}),
fallback:()=>({ids:[]}),onError:opts.onError})
publishCardFrozen(provider)
return provider}
let doorSource=null
export function publishCardFrozen(provider){doorSource=provider??null
return()=>{if(doorSource===provider)doorSource=null}}
export function cardFrozenNow(id){if(doorSource===null)return false
const card=Number(id)
if(!Number.isSafeInteger(card)||card<=0)return false
try{if(doorSource.isLoaded?.()===false&&!storageFailed(doorSource))return true}catch{return true}
try{return isCardFrozen(doorSource,card)}catch{return true}}
export function frozenReasonOf(id){if(!cardFrozenNow(id))return null
if(doorSource===null)return null
try{if(storageFailed(doorSource))return 'unreadable'
if(doorSource.isLoaded?.()===false)return 'unreadable'}catch{return 'unreadable'}
return 'hand'}
export function isCardFrozen(provider,id){const card=Number(id)
if(!Number.isSafeInteger(card)||card<=0)return false
if(storageFailed(provider))return true
return sanitizeCardFrozen(provider?.read?.()).includes(card)}
export function frozenIdsFor(provider,items){if(!storageFailed(provider))return sanitizeCardFrozen(provider?.read?.())
const out=[]
for(const one of Array.isArray(items)?items:[]){const id=cardFrozenKey(one)
if(id!==null&&!out.includes(id))out.push(id)}
return out}
export function setCardFrozen(provider,id,on,onSettled){const card=Number(id)
if(!Number.isSafeInteger(card)||card<=0||typeof provider?.write!=='function')return false
if(storageFailed(provider))return false
const next=sanitizeCardFrozen(provider.read()).filter((value)=>value!==card)
if(on===true)next.unshift(card)
settleWrite(provider.write({ids:next.slice(0,MAX_CARD_FROZEN)}),onSettled)
return true}
function settleWrite(promise,onSettled){if(typeof onSettled!=='function')return
if(!promise||typeof promise.then!=='function'){onSettled(true)
return}
promise.then((ok)=>onSettled(ok!==false),()=>onSettled(false))}
