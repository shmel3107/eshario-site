import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoLink} from '../ui/controls.js'
import{createCardViews,createPageGrid,cardViewButton,sanitizeCardView,
CARD_VIEW_DEFAULT,markScrollGutter,clearScrollGutter,SCROLL_MARK,
PAGE_COLUMNS,MARKET_COLUMNS,ROW_SELECTOR,inDetailColumn} from './card-views.js'
import{paintDealRows,clearDealMarks} from './deal-judge.js'
import{MARKET_RESULT_ID} from './market-search-quick.js'
import{SQUAD_PICK_KEY} from './squad-pick.js'
export const CARD_GRID_FEATURE='cardGrid'
const GRID_STYLESHEET=new URL('../ui/card-grid.css',import.meta.url).href
const GRID_LINK_ID='fut-companion-card-grid'
export const CARD_GRID_SCREENS=Object.freeze([
Object.freeze({id:'club',root:'.ut-club-search-results-view',host:'.paginated-item-list',list:null,sweeps:false,page:true,columns:PAGE_COLUMNS,money:false,detail:'pick'}),
Object.freeze({id:'market',root:'.SearchResults',host:'.paginated-item-list',list:null,sweeps:false,page:true,columns:MARKET_COLUMNS,money:true,detail:false}),
Object.freeze({id:'transfer',root:'.ut-transfer-list-view',host:'.ut-sectioned-item-list-view',list:'itemList',sweeps:true,page:false}),
Object.freeze({id:'targets',root:'.ut-watch-list-view',host:'.ut-sectioned-item-list-view',list:'itemList',sweeps:true,page:false})])
export const PAGE_SCREENS=Object.freeze(CARD_GRID_SCREENS.filter((one)=>one.page===true).map((one)=>one.id))
export const MONEY_SCREEN_ROOTS=Object.freeze(CARD_GRID_SCREENS.filter((one)=>one.money===true).map((one)=>one.root))
export function moneyScreenLive(doc){for(const selector of MONEY_SCREEN_ROOTS){try{if(doc?.querySelector?.(selector))return true}catch{/* следующий селектор */}}
return false}
const GRID_MARK='futCardGrid'
const GRID_SELECTOR='[data-fut-card-grid]'
const SCREEN_MARK='futCardScreen'
const BAR_SELECTOR='[data-fut-card-bar]'
const PINNED_MARK='futCardPinned'
const HEAD_MARK='futCardHead'
const HEAD_SELECTOR='[data-fut-card-head]'
const TOOL_MARK='futCardTool'
const TOOL_SELECTOR='[data-fut-card-tool]'
const WIDE_HOSTS=Object.freeze(['.ut-navigation-container-view','.ut-navigation-container-view--content',
'.ut-split-view','.ut-content'])
const CAP_HOST='.ut-content'
const CAP_MARK='futCardCap'
const CAP_SELECTOR='[data-fut-card-cap]'
const WIDE_STOP='.ut-root-view'
const WIDE_MARK='futCardWide'
const WIDE_SELECTOR='[data-fut-card-wide]'
const AIR_MARK='futCardAir'
const AIR_SELECTOR='[data-fut-card-air]'
export const CARD_PINNED_DEFAULT=true
export function defaultCardGridView(){return{pinned:CARD_PINNED_DEFAULT}}
export function sanitizeCardGridView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const out=defaultCardGridView()
if(typeof raw.pinned==='boolean')out.pinned=raw.pinned
return out}
export function createCardGrid(deps={}){const{doc}=deps
const t=typeof deps.t==='function'?deps.t:(key)=>key
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const readView=typeof deps.view==='function'?deps.view:()=>({})
const writeView=typeof deps.setView==='function'?deps.setView:null
const win=()=>doc?.defaultView??null
let passes=0
let marks=0
let paints=0
let framePending=false
let deals={seen:0,good:0,market:0,bad:0,silent:0,soon:0,writes:0}
const announceDeals=()=>{if(typeof deps.onDeals!=='function')return
try{deps.onDeals({...deals})}catch(err){onError(err)}}
const painted=new WeakMap()
const allowed=()=>{if(typeof deps.isActive!=='function')return false
try{return deps.isActive(CARD_GRID_FEATURE)===true}catch(err){onError(err)
return false}}
const pinnedNow=()=>{if(!writeView)return false
try{return sanitizeCardGridView(readView()).pinned}catch(err){onError(err)
return false}}
const readCardView=typeof deps.cardView==='function'?deps.cardView:null
const writeCardView=typeof deps.setCardView==='function'?deps.setCardView:null
const cardViewNow=()=>{if(!readCardView)return CARD_VIEW_DEFAULT
try{return sanitizeCardView(readCardView())}catch(err){onError(err)
return CARD_VIEW_DEFAULT}}
const views=createCardViews({doc,frame:deps.frame,onError})
const pages=createPageGrid({doc,frame:deps.frame,onError})
function nextFrame(){if(framePending)return false
const view=win()
const soon=typeof deps.soon==='function'?deps.soon:null
const raf=typeof view?.requestAnimationFrame==='function'?view.requestAnimationFrame:null
const timer=typeof view?.setTimeout==='function'?view.setTimeout:null
if(!soon&&!raf&&!timer)return false
framePending=true
let done=false
const go=()=>{if(done)return
done=true
framePending=false
try{pass()}catch(err){onError(err)}}
if(soon){try{soon(go)}catch{/* свой планировщик отказал — остаются кадр и таймер */}}
if(raf){try{raf.call(view,go)}catch{/* кадра не будет — остаётся таймер */}}
if(timer){try{timer.call(view,go,32)}catch{/* и таймера тоже: подождём прохода */}}
return true}
function keepsColumn(root,screen){if(screen.detail!=='pick')return false
return root?.dataset?.[SQUAD_PICK_KEY]!==undefined}
function rootsOf(screen){try{const all=Array.from(doc?.querySelectorAll?.(screen.root)??[])
if(screen.detail===false||screen.detail==='pick')return all.filter((root)=>!inDetailColumn(root)||keepsColumn(root,screen))
return all}catch(err){onError(err)
return[]}}
function detailRootsOf(screen){if(screen.detail!==false&&screen.detail!=='pick')return[]
try{return Array.from(doc?.querySelectorAll?.(screen.root)??[]).filter((root)=>inDetailColumn(root)&&!keepsColumn(root,screen))}catch(err){onError(err)
return[]}}
function listsOf(root,screen){const out=[]
try{for(const host of Array.from(root?.querySelectorAll?.(screen.host)??[])){
for(const child of Array.from(host?.children??[])){if(child?.tagName!=='UL')continue
if(screen.list&&!String(child.className??'').split(/\s+/).includes(screen.list))continue
out.push(child)}}}catch(err){onError(err)}
return out}
function markLists(root,screen){const lists=listsOf(root,screen)
const marked=[]
for(const list of lists){if(!list?.dataset)continue
if(list.dataset[GRID_MARK]!=='1')list.dataset[GRID_MARK]='1'
if(list.dataset[SCREEN_MARK]!==screen.id)list.dataset[SCREEN_MARK]=screen.id
marked.push(list)}
return marked}
function unmarkList(list){if(!list)return false
let touched=false
for(const mark of[GRID_MARK,SCREEN_MARK]){if(list.dataset&&list.dataset[mark]!==undefined){delete list.dataset[mark]
touched=true}}
if(views.unmark(list))touched=true
if(pages.unmark(list))touched=true
return touched}
function wideHostsOf(root){const found=[]
let node=root?.parentNode??null
for(let depth=0;node&&depth<10;depth+=1){let stop=false
try{stop=node.matches?.(WIDE_STOP)===true}catch{stop=false}
if(stop)break
let hit=false
try{hit=WIDE_HOSTS.some((selector)=>node.matches?.(selector)===true)}catch{hit=false}
if(hit)found.unshift(node)
node=node.parentNode??null}
return found}
let gutterHost=null
function markWide(root,screen){const hosts=wideHostsOf(root)
if(hosts.length===0)return 0
for(const host of hosts){if(!host?.dataset)continue
if(host.dataset[WIDE_MARK]!=='1')host.dataset[WIDE_MARK]='1'
if(host.dataset[AIR_MARK]!=='0')host.dataset[AIR_MARK]='0'
let cap=false
try{cap=host.matches?.(CAP_HOST)===true}catch{cap=false}
if(cap&&host.dataset[CAP_MARK]!=='1')host.dataset[CAP_MARK]='1'}
if(root?.dataset&&root.dataset[AIR_MARK]!=='1')root.dataset[AIR_MARK]='1'
if(screen?.page===true){if(clearScrollGutter(gutterHost))gutterHost=null
return hosts.length}
gutterHost=markScrollGutter(root,win())
return hosts.length}
function dealPass(root){let rows=[]
try{rows=Array.from(root?.querySelectorAll?.(ROW_SELECTOR)??[])}catch(err){onError(err)
return 0}
if(rows.length===0)return 0
const out=paintDealRows({doc,win:win(),rows,t,onError,
itemOf:typeof deps.itemOf==='function'?deps.itemOf:undefined,
priceOf:typeof deps.priceOf==='function'?deps.priceOf:undefined})
deals=out
announceDeals()
return out.writes}
function clearWide(){let gone=0
if(clearScrollGutter(gutterHost)){gutterHost=null
gone+=1}
const seen=new Set()
for(const selector of[WIDE_SELECTOR,AIR_SELECTOR,CAP_SELECTOR]){for(const node of Array.from(doc?.querySelectorAll?.(selector)??[])){if(seen.has(node))continue
seen.add(node)
if(node.dataset&&node.dataset[WIDE_MARK]!==undefined)delete node.dataset[WIDE_MARK]
if(node.dataset&&node.dataset[AIR_MARK]!==undefined)delete node.dataset[AIR_MARK]
if(node.dataset&&node.dataset[CAP_MARK]!==undefined)delete node.dataset[CAP_MARK]
gone+=1}}
return gone}
function clearHeads(){let gone=0
for(const head of Array.from(doc?.querySelectorAll?.(HEAD_SELECTOR)??[])){for(const tool of Array.from(head.querySelectorAll?.(TOOL_SELECTOR)??[]))tool.remove?.()
unstickHead(head)
painted.delete(head)
if(head.dataset){delete head.dataset[HEAD_MARK]
if(head.dataset[PINNED_MARK]!==undefined)delete head.dataset[PINNED_MARK]}
gone+=1}
return gone}
function clearAll(){let gone=0
for(const list of Array.from(doc?.querySelectorAll?.(GRID_SELECTOR)??[])){if(unmarkList(list))gone+=1}
views.forget()
pages.forget()
for(const bar of Array.from(doc?.querySelectorAll?.(BAR_SELECTOR)??[])){bar.remove?.()
gone+=1}
gone+=clearHeads()
gone+=clearWide()
gone+=clearDealMarks(doc)
deals={seen:0,good:0,market:0,bad:0,silent:0,soon:0,writes:0}
announceDeals()
return gone}
function mountBar(root){const existing=root.querySelector?.(BAR_SELECTOR)??null
if(existing&&existing.parentNode===root&&root.firstChild===existing)return existing
const node=existing??el(doc,'section',{class:'fx-card-bar',dataset:{futCardBar:'1'}})
painted.delete(node)
root.insertBefore(node,root.firstChild)
return node}
function headOf(root,screen){if(screen?.money!==true)return{node:mountBar(root),guest:false}
let guest=null
try{guest=root.querySelector?.(`.${MARKET_RESULT_ID}`)??null}catch{guest=null}
if(!guest)return{node:mountBar(root),guest:false}
const own=root.querySelector?.(BAR_SELECTOR)??null
if(own){painted.delete(own)
own.remove?.()}
if(guest.dataset&&guest.dataset[HEAD_MARK]!=='1')guest.dataset[HEAD_MARK]='1'
return{node:guest,guest:true}}
function unstickHead(node){for(const name of['position','top','z-index']){try{node.style?.removeProperty?.(name)}catch{/* нечего снимать */}}}
function signature(view,pinned,page,guest){return JSON.stringify([view,pinned,page,guest,t('cardView.stats'),t('cardView.compact')])}
function viewField(view,page){if(page||!writeCardView)return null
return cardViewButton(doc,{view,t,onError,
onPick:(next)=>{try{writeCardView(next)}catch(err){onError(err)}
try{pass()}catch(err){onError(err)}}})}
function pinButton(pinned,page){if(!writeView)return null
if(page)return null
const button=el(doc,'button',{class:'fx-card-pin',
dataset:{futCardPin:pinned?'1':'0'},
attrs:{type:'button','aria-pressed':pinned?'true':'false',title:t(pinned?'cardGrid.pinOn':'cardGrid.pinOff')},
text:'📌'})
button.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{writeView?.({pinned:!pinned})}catch(err){onError(err)}
try{pass()}catch(err){onError(err)}})
return button}
function paintBar(root,pinned,view,screen){if(!writeView)return false
const page=screen?.page===true
const{node,guest}=headOf(root,screen)
const flag=page?'0':(pinned?'1':'0')
if(node.dataset&&node.dataset[PINNED_MARK]!==flag)node.dataset[PINNED_MARK]=flag
if(guest)unstickHead(node)
const key=signature(view,pinned,page,guest)
const drawn=Boolean(node.querySelector?.(TOOL_SELECTOR))
if(painted.get(node)===key&&drawn)return false
painted.set(node,key)
paints+=1
for(const tool of Array.from(node.querySelectorAll?.(TOOL_SELECTOR)??[]))tool.remove?.()
const parts=[]
parts.push(logoLink(doc))
const toggle=viewField(view,page)
if(toggle)parts.push(toggle)
const pin=pinButton(pinned,page)
if(pin)parts.push(pin)
for(const one of parts){if(one.dataset)one.dataset[TOOL_MARK]='1'}
if(!guest){
const[mark,...rest]=parts
if(mark)node.insertBefore(mark,node.firstChild??null)
for(const one of rest)node.appendChild(one)
return true}
for(let at=parts.length-1;at>=0;at-=1){const one=parts[at]
if(one.dataset)one.dataset[TOOL_MARK]='1'
node.insertBefore(one,node.firstChild)}
inlineTools(parts[0],pin)
return true}
function inlineTools(mark,pin){const set=(node,name,value)=>{try{if(node?.style?.getPropertyValue?.(name)!==value)node?.style?.setProperty?.(name,value)}catch{/* раскладка — удобство, а не условие */}}
set(mark,'display','inline-flex')
set(mark,'vertical-align','middle')
set(mark,'margin-right','8px')
set(pin,'float','right')}
function pass(){if(!doc)return{ok:false,reason:'no-doc',screens:[]}
passes+=1
const on=allowed()
if(!on){const gone=clearAll()
return{ok:true,reason:'off',cleared:gone,screens:[]}}
ensureStylesheet(doc,GRID_STYLESHEET,GRID_LINK_ID)
views.ensure()
const pinned=pinnedNow()
const view=cardViewNow()
const seen=[]
let styled=false
let wide=false
let judged=0
for(const screen of CARD_GRID_SCREENS){const roots=rootsOf(screen)
if(roots.length===0)continue
if(!styled){ensureTheme(doc)
ensureControls(doc)
styled=true}
let marked=0
for(const root of roots){const lists=markLists(root,screen)
if(screen.page){pages.apply(lists,{columns:screen.columns,money:screen.money===true})
watchBox(lists)}
else views.apply(lists,view)
marked+=lists.length
if(!inDetailColumn(root)){markWide(root,screen)
wide=true}
if(screen.money===true)judged+=dealPass(root)
paintBar(root,pinned,view,screen)
if(screen.page)pages.refit(lists)}
marks+=marked
seen.push({screen:screen.id,roots:roots.length,lists:marked,page:screen.page===true})}
for(const screen of CARD_GRID_SCREENS){if(screen.detail!==false&&screen.detail!=='pick')continue
for(const root of detailRootsOf(screen)){for(const list of Array.from(root.querySelectorAll?.(GRID_SELECTOR)??[]))unmarkList(list)
for(const bar of Array.from(root.querySelectorAll?.(BAR_SELECTOR)??[])){painted.delete(bar)
bar.remove?.()}
let strip=null
try{strip=root.querySelector?.(`.${MARKET_RESULT_ID}`)??null}catch{strip=null}
if(!strip)continue
if(!styled){ensureTheme(doc)
ensureControls(doc)
styled=true}
paintBar(root,pinned,view,screen)}}
if(!wide)clearWide()
if(!seen.some((one)=>one.screen==='market')){clearDealMarks(doc)
if(deals.seen!==0||deals.good!==0||deals.bad!==0){deals={seen:0,good:0,market:0,bad:0,silent:0,soon:0,writes:0}
announceDeals()}}
for(const list of Array.from(doc?.querySelectorAll?.(GRID_SELECTOR)??[])){if(list.isConnected===false)unmarkList(list)}
return{ok:true,reason:null,screens:seen,view,pinned,judged}}
function report(){const view=win()
const out=[]
for(const screen of CARD_GRID_SCREENS){for(const root of rootsOf(screen)){const lists=listsOf(root,screen)
const list=lists[0]??null
let style=null
try{style=view?.getComputedStyle?.(list)??null}catch{style=null}
let row=null
try{row=list?.querySelector?.('li.listFUTItem')??null}catch{row=null}
out.push({screen:screen.id,
lists:lists.length,
marked:lists.filter((one)=>one?.dataset?.[GRID_MARK]==='1').length,
rows:list?.children?.length??null,
window:view?.innerWidth??null,
rootWidth:root?.clientWidth??null,listWidth:list?.clientWidth??null,rowWidth:row?.clientWidth??null,
columns:typeof style?.gridTemplateColumns==='string'?style.gridTemplateColumns:null,
tile:tileStage(row),
auctions:list?(list.querySelectorAll?.('li.listFUTItem.has-auction-data')?.length??null):null,
chain:chainOf(root),
bar:Boolean(root.querySelector?.(BAR_SELECTOR)),
head:Boolean(root.querySelector?.(HEAD_SELECTOR)),
tools:root.querySelectorAll?.(TOOL_SELECTOR)?.length??0,
listHeight:list?.clientHeight??null})}}
return{feature:CARD_GRID_FEATURE,allowed:allowed(),
view:cardViewNow(),pinned:pinnedNow(),
page:pages.state(),tile:views.state(),
detail:CARD_GRID_SCREENS.flatMap((screen)=>detailRootsOf(screen)).map((root)=>({
rows:root.querySelectorAll?.('li.listFUTItem')?.length??0,
marked:root.querySelectorAll?.(GRID_SELECTOR)?.length??0,
head:Boolean(root.querySelector?.(HEAD_SELECTOR))})),
deals:{...deals},
ports:{onDeals:typeof deps.onDeals==='function',
itemOf:typeof deps.itemOf==='function',
priceOf:typeof deps.priceOf==='function',
cardView:readCardView!==null,
setCardView:writeCardView!==null},
work:{passes,marks,paints},
styles:Boolean(doc?.getElementById?.(GRID_LINK_ID)),
screens:out}}
function tileStage(tile){if(!tile)return null
const view=win()
let style=null
try{style=view?.getComputedStyle?.(tile)??null}catch{style=null}
const pad=(value)=>{const number=Number.parseFloat(value??'')
return Number.isFinite(number)?number:0}
const width=tile.clientWidth??null
const content=width===null?null:Math.max(0,width-pad(style?.paddingLeft)-pad(style?.paddingRight))
let face=null
try{face=tile.querySelector?.('.entityContainer > :first-child')?.clientWidth??null}catch{face=null}
return{width,content,face,stats:statsFit(tile),
containerQueries:typeof view?.CSS?.supports==='function'?view.CSS.supports('container-type','inline-size'):null}}
function statsFit(tile){let box=null
try{box=tile.querySelector?.('.player-stats-data-component')??null}catch{box=null}
if(!box)return null
let cells=[]
try{cells=Array.from(box.querySelectorAll?.('ul > li')??[])}catch{cells=[]}
let need=0
let has=0
let clipped=0
for(const cell of cells){let label=null
try{label=cell.querySelector?.('.label')??null}catch{label=null}
if(!label)continue
const wants=label.scrollWidth??0
const got=label.clientWidth??0
if(wants>got+1)clipped+=1
if(wants-got>need-has){need=wants
has=got}}
return{width:box.clientWidth??null,cells:cells.length,clipped,need,has}}
function chainOf(root){const view=win()
const out=[]
let node=root
for(let depth=0;node&&depth<8;depth+=1){let style=null
try{style=view?.getComputedStyle?.(node)??null}catch{style=null}
out.push({tag:node.tagName,class:typeof node.className==='string'?node.className:'',
width:node.clientWidth??null,maxWidth:style?.maxWidth??null,
marginLeft:style?.marginLeft??null,paddingLeft:style?.paddingLeft??null,
overflowY:style?.overflowY??null,
bar:Math.max(0,(node.offsetWidth??0)-(node.clientWidth??0)),
scrolls:(node.scrollHeight??0)>(node.clientHeight??0)+1,
gutter:node.dataset?.[SCROLL_MARK]==='1'})
let stop=false
try{stop=node.matches?.('.ut-root-view')===true}catch{stop=false}
if(stop)break
node=node.parentNode??null}
return out}
function pageLists(){const lists=[]
for(const screen of CARD_GRID_SCREENS){if(screen.page!==true)continue
for(const root of rootsOf(screen))lists.push(...listsOf(root,screen))}
return lists}
function onResize(){try{const lists=pageLists()
if(lists.length>0)pages.remeasure(lists)}catch(err){onError(err)}}
try{win()?.addEventListener?.('resize',onResize)}catch(err){onError(err)}
let watcher=null
function watchBox(lists){const view=win()
const Observer=view?.ResizeObserver
if(typeof Observer!=='function')return false
if(!watcher){try{watcher=new Observer(()=>{try{pages.refit(pageLists())}catch(err){onError(err)}})}catch(err){onError(err)
return false}}
let seen=0
for(const list of Array.isArray(lists)?lists:[]){if(!list)continue
try{watcher.observe(list)
seen+=1}catch(err){onError(err)}}
return seen>0}
return{
refresh(){return nextFrame()},
apply(){return pass()},
relabel(){return pass()},
detach(){return clearAll()},
state:report,
dispose(){try{win()?.removeEventListener?.('resize',onResize)}catch(err){onError(err)}
try{watcher?.disconnect?.()
watcher=null}catch(err){onError(err)}
try{clearAll()}catch(err){onError(err)}}}}
