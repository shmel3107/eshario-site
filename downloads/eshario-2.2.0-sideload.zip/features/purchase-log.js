import{seasonOf,seasonFits} from '../adapter/season.js'
export const PURCHASE_LOG_SCHEMA=1
export const MAX_PURCHASES=1000
function coins(value){const n=Math.round(Number(value))
return Number.isSafeInteger(n)&&n>0?n:0}
export function purchaseKey(value){const n=typeof value==='string'&&/^\d+$/.test(value.trim())?Number(value.trim()):value
return Number.isSafeInteger(n)&&n>0?n:null}
export function encodeLog(entries,season=null){const ids=[]
const prices=[]
for(const[id,price]of entries??[]){const key=purchaseKey(id)
const paid=coins(price)
if(key===null||paid===0)continue
ids.push(key)
prices.push(paid)}
const out={v:PURCHASE_LOG_SCHEMA,i:ids,p:prices}
if(Number.isSafeInteger(season))out.s=season
return out}
export function decodeLog(raw,season=null){const out=[]
if(!raw||typeof raw!=='object'||raw.v!==PURCHASE_LOG_SCHEMA)return out
if(!seasonFits(raw.s,season))return out
const ids=Array.isArray(raw.i)?raw.i:null
const prices=Array.isArray(raw.p)?raw.p:null
if(ids===null||prices===null||ids.length!==prices.length)return out
for(let index=0;index<ids.length;index+=1){const key=purchaseKey(ids[index])
const paid=coins(prices[index])
if(key===null||paid===0)continue
out.push([key,paid])}
return out}
const paid=new Map()
const stats={noted:0,paidIn:0,seen:0,forgotten:0,evicted:0,writes:0,lastWriteAt:null,loaded:false}
let storage=null
let schedule=(fn)=>{fn()}
let clockNow=()=>0
let seasonNow=()=>seasonOf()
let onError=()=>{}
let dirty=false
let flushing=false
let loading=false
let sealed=false
function step(){if(!dirty){flushing=false
return}
dirty=false
try{const result=storage?.write?.(encodeLog(paid,seasonNow()))
stats.writes+=1
stats.lastWriteAt=clockNow()
if(result&&typeof result.catch==='function')result.catch(onError)}catch(err){onError(err)}
flushing=false}
function touch(){if(loading||storage===null)return
dirty=true
if(sealed||flushing)return
flushing=true
schedule(step)}
function evict(){let gone=0
while(paid.size>MAX_PURCHASES){const oldest=paid.keys().next()
if(oldest.done)break
paid.delete(oldest.value)
gone+=1}
stats.evicted+=gone
return gone}
function remember(key,price){if(key===null||price===0)return false
const known=paid.get(key)
if(known===price)return false
if(known===undefined)stats.noted+=1
paid.set(key,price)
evict()
touch()
return true}
function idOf(item){let raw=null
try{raw=item?.id??item?.itemId??null}catch{return null}
return purchaseKey(raw)}
export function boughtOf(item){const key=idOf(item)
if(key===null)return 0
stats.seen+=1
let live=0
try{live=coins(item?.lastSalePrice)}catch{live=0}
if(live>0)remember(key,live)
return paid.get(key)??0}
export function notePurchasedItem(item,purchasedPile){if(!Number.isSafeInteger(purchasedPile))return false
let pile=null
try{pile=item?.pile??null}catch{return false}
if(pile!==purchasedPile)return false
const key=idOf(item)
if(key===null)return false
let live=0
try{live=coins(item?.lastSalePrice)}catch{live=0}
return remember(key,live)}
export function notePaid(item,price){const key=idOf(item)
const sum=coins(price)
if(key===null||sum===0)return false
const fresh=remember(key,sum)
if(fresh)stats.paidIn+=1
return fresh}
export function forgetPurchases(ids){let gone=0
for(const id of Array.isArray(ids)?ids:[]){const key=purchaseKey(id)
if(key!==null&&paid.delete(key)){gone+=1
stats.forgotten+=1}}
if(gone>0)touch()
return gone}
export function purchaseLogState(){return{size:paid.size,cap:MAX_PURCHASES,...stats}}
export function installPurchaseLog(deps={}){storage=deps.storage??null
sealed=storage!==null
if(typeof deps.schedule==='function')schedule=deps.schedule
if(typeof deps.now==='function')clockNow=deps.now
if(typeof deps.season==='function')seasonNow=deps.season
if(typeof deps.onError==='function')onError=deps.onError
return{load:async()=>{if(storage===null)return 0
let raw=null
let failed=false
try{raw=await storage.read()}catch(err){onError(err)
failed=true}
const stored=failed?[]:decodeLog(raw,seasonNow())
loading=true
try{const live=[...paid.entries()]
paid.clear()
for(const[key,price]of stored)paid.set(key,price)
for(const[key,price]of live)paid.set(key,price)
evict()}finally{loading=false}
sealed=false
if(dirty&&!flushing){flushing=true
schedule(step)}
stats.loaded=failed===false
return stored.length},
state:purchaseLogState}}
export function resetPurchaseLog(){paid.clear()
storage=null
schedule=(fn)=>{fn()}
clockNow=()=>0
seasonNow=()=>seasonOf()
onError=()=>{}
dirty=false
flushing=false
loading=false
sealed=false
stats.noted=0
stats.paidIn=0
stats.seen=0
stats.forgotten=0
stats.evicted=0
stats.writes=0
stats.lastWriteAt=null
stats.loaded=false}
