import{createCachedProvider,storageFailed,STORAGE_LOADED} from '../core/storage-provider.js'
import{CHANNEL,FROM_CONTENT,KIND_EVENT} from '../bridge/protocol.js'
export const LOCKS_CHANGED='locks.changed'
export const MAX_CARD_LOCKS=500
const MAX_LOCK_NAME=48
function lockNames(raw,ids){const out={}
if(!raw||typeof raw!=='object'||Array.isArray(raw))return out
const source=raw.names
if(!source||typeof source!=='object'||Array.isArray(source))return out
for(const id of ids){const key=String(id)
if(!Object.hasOwn(source,key))continue
const value=source[key]
if(typeof value!=='string')continue
const text=value.trim().slice(0,MAX_LOCK_NAME)
if(text!=='')out[key]=text}
return out}
export function cardLockKey(source){const own=idOf(source)
if(own!==null)return own
try{return idOf(source?.item)}catch{return null}}
function idOf(source){try{const value=Number(source?.id)
return Number.isSafeInteger(value)&&value>0?value:null}catch{return null}}
function idList(raw){if(!Array.isArray(raw))return[]
const out=[]
for(const value of raw){const id=Number(value)
if(!Number.isSafeInteger(id)||id<=0||out.includes(id))continue
out.push(id)
if(out.length>=MAX_CARD_LOCKS)break}
return out}
export function sanitizeCardLocks(raw){if(Array.isArray(raw))return idList(raw)
return idList(raw&&typeof raw==='object'?raw.ids:null)}
export function sanitizeCardLockState(raw){const ids=sanitizeCardLocks(raw)
const marks=Array.isArray(raw)?[]:idList(raw&&typeof raw==='object'?raw.recreated:null)
return{ids,recreated:marks.filter((id)=>ids.includes(id)),names:lockNames(raw,ids)}}
export function applyCardLockDelta(raw,delta){const state=sanitizeCardLockState(raw)
let ids=state.ids
let marks=state.recreated
const names={...state.names}
for(const value of idList(delta?.off)){ids=ids.filter((one)=>one!==value)
marks=marks.filter((one)=>one!==value)
delete names[String(value)]}
for(const one of Array.isArray(delta?.on)?delta.on:[]){const card=Number(one?.id)
if(!Number.isSafeInteger(card)||card<=0)continue
ids=[card,...ids.filter((value)=>value!==card)]
marks=marks.filter((value)=>value!==card)
if(typeof one?.name==='string'&&one.name!=='')names[String(card)]=one.name}
for(const value of idList(delta?.mark)){if(!ids.includes(value)||marks.includes(value))continue
marks=[...marks,value]}
ids=ids.slice(0,MAX_CARD_LOCKS)
const kept={}
for(const value of ids){const name=names[String(value)]
if(typeof name==='string')kept[String(value)]=name}
return{ids,recreated:marks.filter((value)=>ids.includes(value)),names:kept}}
export function createBridgeCardLockProvider(opts){if(typeof opts?.bridge?.request!=='function')throw new Error('locks: мост недоступен')
const provider=createCachedProvider({fetch:()=>opts.bridge.request('locks.read'),
push:(value,delta)=>{if(!delta||typeof delta!=='object')throw new Error('locks: запись без операции')
return opts.bridge.request('locks.write',delta)},
sanitize:sanitizeCardLockState,fallback:()=>({ids:[],recreated:[],names:{}}),onError:opts.onError})
publishCardLocks(provider)
watchCardLocks(provider,opts)
return provider}
function watchCardLocks(provider,opts){const win=opts?.window??(typeof globalThis==='undefined'?null:globalThis.window??null)
if(!win||typeof win.addEventListener!=='function')return
let asking=false
win.addEventListener('message',(event)=>{if(event?.source!==undefined&&event.source!==win)return
const msg=event?.data
if(!msg||typeof msg!=='object')return
if(msg.channel!==CHANNEL||msg.from!==FROM_CONTENT||msg.kind!==KIND_EVENT||msg.name!==LOCKS_CHANGED)return
if(asking||provider.status?.()!==STORAGE_LOADED)return
asking=true
Promise.resolve(opts.bridge.request('locks.read')).then((raw)=>{provider.adopt?.(raw)},(err)=>{if(typeof opts.onError==='function')opts.onError('load',err)})
.then(()=>{asking=false},()=>{asking=false})},false)}
let doorSource=null
export function publishCardLocks(provider){doorSource=provider??null
return()=>{if(doorSource===provider)doorSource=null}}
export function cardLocksNow(){if(doorSource===null)return null
try{if(storageFailed(doorSource))return null
return sanitizeCardLocks(doorSource.read?.())}catch{return null}}
export function cardLockedNow(id){if(doorSource===null)return null
const card=Number(id)
if(!Number.isSafeInteger(card)||card<=0)return null
try{if(doorSource.isLoaded?.()===false&&!storageFailed(doorSource))return null}catch{return true}
try{return isCardLocked(doorSource,card)}catch{return true}}
export function isCardLocked(provider,id){const card=Number(id)
if(!Number.isSafeInteger(card)||card<=0)return false
if(storageFailed(provider))return true
return sanitizeCardLocks(provider?.read?.()).includes(card)}
export function lockedIdsFor(provider,players){if(!storageFailed(provider))return sanitizeCardLocks(provider?.read?.())
const out=[]
for(const one of Array.isArray(players)?players:[]){const id=cardLockKey(one)
if(id!==null&&!out.includes(id))out.push(id)}
return out}
export function setCardLock(provider,id,on,onSettled,label){const card=Number(id)
if(!Number.isSafeInteger(card)||card<=0||typeof provider?.write!=='function')return false
if(storageFailed(provider))return false
const text=typeof label==='string'?label.trim().slice(0,MAX_LOCK_NAME):''
const delta=on===true?{on:[{id:card,name:text===''?null:text}]}:{off:[card]}
settleWrite(provider.write(applyCardLockDelta(provider.read(),delta),delta),onSettled)
return true}
function settleWrite(promise,onSettled){if(typeof onSettled!=='function')return
if(!promise||typeof promise.then!=='function'){onSettled(true)
return}
promise.then((ok)=>onSettled(ok!==false),()=>onSettled(false))}
export function cardLockRecreated(provider){try{return cardLockRecreatedRows(provider).map((row)=>row.id)}catch{return[]}}
export function cardLockRecreatedRows(provider){const state=sanitizeCardLockState(provider?.read?.())
return state.recreated.map((id)=>({id,name:state.names[String(id)]??null}))}
export function noteCardsRecreated(provider,ids,onSettled){if(typeof provider?.write!=='function')return 0
if(storageFailed(provider))return 0
let state
try{state=sanitizeCardLockState(provider.read())}catch{return 0}
const fresh=[]
for(const value of Array.isArray(ids)?ids:[]){const card=Number(value)
if(!Number.isSafeInteger(card)||card<=0)continue
if(!state.ids.includes(card)||state.recreated.includes(card)||fresh.includes(card))continue
fresh.push(card)}
if(fresh.length===0)return 0
const delta={mark:fresh}
settleWrite(provider.write(applyCardLockDelta(state,delta),delta),onSettled)
return fresh.length}
