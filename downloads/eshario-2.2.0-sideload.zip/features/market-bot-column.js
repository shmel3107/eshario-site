import{el,clear,logoLink} from '../ui/dom.js'
import{modalBox,modalButtons} from '../ui/window.js'
import{stopReasonKey,DOOR_CAUSE_KEYS,CALM_STOPS} from '../automation/stop-reasons.js'
import{EPOCH_REASON} from '../adapter/session-epoch.js'
import{targetFromCriteria,lootRowModel,SNIPE_FEATURE} from './snipe-shared.js'
import{pluralKey} from '../i18n/index.js'
export const MARKET_COL_MARK='futMarketCol'
export const MARKET_COL_SELECTOR='[data-fut-market-col]'
export const COLUMN_MARK='futMarketColumn'
export const COLUMN_SELECTOR='[data-fut-market-column]'
export const PART_MARK='futMarketColPart'
export const COLUMN_BUILD='LASTCATCH-1'
const SAVE_WINDOW_MARK='futMarketColSave'
const SAVE_FIELD_MARK='futMarketColSaveField'
export const SET_ID_MARK='futMarketColSetId'
const SET_ID_SELECTOR='[data-fut-market-col-set-id]'
export const SET_CLASS_PREFIX='fx-mcol-tpl-'
const SAFE_SET_ID=/^[A-Za-z0-9_-]{1,40}$/
export function newestFirst(list){if(!Array.isArray(list))return list===null?null:[]
const age=(one)=>{const match=/^f(\d+)$/.exec(String(one?.id??''))
return match?Number(match[1]):-1}
return list.map((one,at)=>({one,at,age:age(one)}))
.sort((a,b)=>(b.age-a.age)||(a.at-b.at))
.map((row)=>row.one)}
const SHORT_FROM=1000
const SHORT_MILLION=1_000_000
export function shortCoins(value,num,say){const coins=Number(value)
if(!Number.isSafeInteger(coins)||coins<=0)return ''
if(coins<SHORT_FROM)return num(coins)
const million=coins>=SHORT_MILLION
const scale=million?SHORT_MILLION:SHORT_FROM
const cut=Math.floor((coins/scale)*10)/10
return `${num(cut)}${say(million?'marketBot.short.million':'marketBot.short.thousand')}`}
export function chipId(id){const said=String(id??'')
return SAFE_SET_ID.test(said)?said:null}
export function templateChipAt(node){let chip=null
try{chip=node?.closest?.(SET_ID_SELECTOR)??null}catch{return null}
if(chip===null)return null
try{if(chip.closest(COLUMN_SELECTOR)===null)return null}catch{return null}
return chipId(chip.dataset?.[SET_ID_MARK])}
export const JOURNAL_MAX=40
export const TONE=Object.freeze({PLAIN:'plain',GOOD:'good',WARN:'warn',BAD:'bad'})
export const LOUD_STOPS=Object.freeze(['captcha','throttled','fatal'])
export const TOO_MANY_MATCHES='too-many-matches'
export const FILTER_CHANGED='filter-changed'
export const FAIL_STAGE_KEYS=Object.freeze({search:'marketBot.fail.search',
bid:'marketBot.fail.bid',buy:'marketBot.fail.buy',move:'marketBot.fail.move',
'immediate-list':'marketBot.fail.list',unassigned:'marketBot.fail.pile',
other:'marketBot.fail.other'})
export function failStageKey(stage){return FAIL_STAGE_KEYS[stage]??FAIL_STAGE_KEYS.other}
export const FAIL_FIELD_KEYS=Object.freeze({coins:'marketBot.field.coins',
items:'marketBot.field.items','bid-result':'marketBot.field.receipt',
'action-slot':'marketBot.field.slot',pile:'marketBot.field.pile',
itemIds:'marketBot.field.moveReceipt'})
export function failFieldKey(field){return FAIL_FIELD_KEYS[field]??null}
export function stopTone(why){return CALM_STOPS.includes(why)?TONE.WARN:TONE.BAD}
export const JOURNAL_VIEW=Object.freeze({ALL:'all',BUYS:'buys',MISSES:'misses'})
export const JOURNAL_VIEWS=Object.freeze([JOURNAL_VIEW.ALL,JOURNAL_VIEW.BUYS,JOURNAL_VIEW.MISSES])
export const JOURNAL_VIEW_KEYS=Object.freeze({[JOURNAL_VIEW.ALL]:'marketBot.logView.all',
[JOURNAL_VIEW.BUYS]:'marketBot.logView.buys',[JOURNAL_VIEW.MISSES]:'marketBot.logView.misses'})
export const STOP_LINE_KEYS=Object.freeze(['marketBot.log.stopped',
'marketBot.log.stoppedWhere','marketBot.log.stoppedCode','marketBot.log.stoppedFail'])
export function logClassOf(one){const tone=TONE_CLASS[one.tone]??''
const wide=STOP_LINE_KEYS.includes(one?.key)||WIDE_LINE_KEYS.includes(one?.key)?' fx-mcol-log-wide':''
return `fx-mcol-log${tone}${wide}${one.memo===true?' fx-mcol-log-memo':''}${one.past===true?' fx-mcol-log-past':''}`}
const TONE_CLASS=Object.freeze({[TONE.GOOD]:' fx-mcol-ok',[TONE.WARN]:' fx-mcol-warn',
[TONE.BAD]:' fx-mcol-bad'})
export const LIVE_SEARCH_KEY='marketBot.log.searchLive'
export const LIVE_SEARCH_KEYS=Object.freeze([LIVE_SEARCH_KEY,'marketBot.log.searchLiveBlind'])
const WIDE_LINE_KEYS=Object.freeze([...LIVE_SEARCH_KEYS,'marketBot.log.startAim'])
export const LIVE_REDRAW_MS=0
export const LIVE_TIP_FIELDS=Object.freeze(['lots','fresh','bid','minBid','minBuy'])
const BUY_KEYS=Object.freeze(['marketBot.log.bought','marketBot.log.boughtBlind'])
const MISS_KEYS=Object.freeze(['marketBot.log.missed','marketBot.log.missedBlind',
'marketBot.log.missedMany','marketBot.log.missedManyBlind'])
const RACE_HOSTS=Object.freeze([...BUY_KEYS,...MISS_KEYS])
export function logViewKeeps(view,one){if(one?.memo===true)return true
const key=String(one?.key??'')
if(STOP_LINE_KEYS.includes(key))return true
if(view===JOURNAL_VIEW.BUYS)return BUY_KEYS.includes(key)
if(view===JOURNAL_VIEW.MISSES)return MISS_KEYS.includes(key)
return true}
export function journalViewOf(value){return JOURNAL_VIEWS.includes(value)?value:JOURNAL_VIEW.ALL}
export function defaultMarketBotView(){return{lastRun:null}}
export function sanitizeLastRun(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:null
if(raw===null)return null
const whole=(value)=>(Number.isSafeInteger(value)&&value>=0?value:null)
const at=Number.isSafeInteger(raw.at)&&raw.at>0?raw.at:null
const searches=whole(raw.searches)
const caught=whole(raw.caught)
if(at===null||searches===null||caught===null||typeof raw.dry!=='boolean')return null
return{at,reason:typeof raw.reason==='string'&&raw.reason!==''?raw.reason:null,
searches,caught,coins:whole(raw.coins),dry:raw.dry}}
export function sanitizeLogLine(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:null
if(raw===null)return null
const at=Number.isSafeInteger(raw.at)&&raw.at>0?raw.at:null
const key=typeof raw.key==='string'&&raw.key!==''?raw.key:null
if(at===null||key===null)return null
const tone=Object.values(TONE).includes(raw.tone)?raw.tone:TONE.PLAIN
const said=raw.params&&typeof raw.params==='object'&&!Array.isArray(raw.params)?raw.params:{}
const params={}
for(const[name,value]of Object.entries(said)){const kind=typeof value
if(value===null||kind==='string'||kind==='boolean'||(kind==='number'&&Number.isFinite(value)))params[name]=value}
return{at,key,params,tone}}
export function sanitizeMarketBotView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const memory=raw.lastRun&&typeof raw.lastRun==='object'&&!Array.isArray(raw.lastRun)?raw.lastRun:null
if(memory===null)return{lastRun:null}
const own=Object.hasOwn(memory,'run')?memory.run:memory
const run=sanitizeLastRun(own)
const rows=Array.isArray(memory.lines)?memory.lines:[]
const lines=rows.map(sanitizeLogLine).filter((one)=>one!==null).slice(-JOURNAL_MAX)
const view=journalViewOf(memory.view)
return{lastRun:{run,lines,view}}}
export function cardSourceOf(definitionId,attrs,rating=null){const id=Number(definitionId)
if(!Number.isSafeInteger(id)||id<=0)return null
const num=(value)=>(Number.isSafeInteger(value)&&value>0?value:null)
const own=num(rating)??num(attrs?.rating)
const source={definitionId:id,rating:own}
const rare=attrs?.rareflag
if(Number.isSafeInteger(rare)&&rare>=0)source.rareflag=rare
const box={}
for(const key of['leagueId','nationId','teamId']){const value=num(attrs?.[key])
if(value!==null)box[key]=value}
const positions=Array.isArray(attrs?.positions)
?attrs.positions.filter((code)=>Number.isSafeInteger(code)&&code>=0)
:[]
if(positions.length>0)box.possiblePositions=[...positions]
if(Object.keys(box).length>0)source.attrs=box
return source}
export function missOf(said){const raw=said&&typeof said==='object'&&!Array.isArray(said)?said:null
if(raw===null)return null
const price=Number.isSafeInteger(raw.price)&&raw.price>0?raw.price:null
if(price===null)return null
const row=lootRowModel({name:raw.name,rating:raw.rating},null)
return{name:row.name,rating:row.rating,price}}
export function driftOf(said){const raw=said&&typeof said==='object'&&!Array.isArray(said)?said:null
if(raw===null)return null
const want=Number.isSafeInteger(raw.want)&&raw.want>0?raw.want:null
if(want===null)return null
const got=Number.isSafeInteger(raw.got)&&raw.got>0?raw.got:null
if(got===want)return null
return{want,got}}
export function failOf(said){const raw=said&&typeof said==='object'&&!Array.isArray(said)?said:null
if(raw===null)return null
const stage=typeof raw.stage==='string'&&raw.stage!==''?raw.stage:null
if(stage===null)return null
return{stage,status:Number.isSafeInteger(raw.status)?raw.status:null,
search:Number.isSafeInteger(raw.search)&&raw.search>0?raw.search:0}}
export function linkOf(said){const raw=said&&typeof said==='object'&&!Array.isArray(said)?said:null
if(raw===null)return null
const stage=typeof raw.stage==='string'&&raw.stage!==''?raw.stage:null
if(stage===null)return null
return{stage,pile:Number.isSafeInteger(raw.pile)&&raw.pile>=0?raw.pile:0}}
export function cardWords(row){const name=typeof row?.name==='string'?row.name.trim():''
if(name==='')return null
const rating=Number.isSafeInteger(row?.rating)&&row.rating>0?row.rating:null
return rating===null?name:`${name} (${rating})`}
export const CATCH_MODE=Object.freeze({LIVE:'live',LAST:'last',NEVER:'never',WAIT:'wait'})
export const CATCH_TIP_ROWS=12
const START_KEYS=Object.freeze(['marketBot.log.start','marketBot.log.startAim'])
function catchCoinsOf(caught,coins){if(!(caught>0))return null
return Number.isSafeInteger(coins)&&coins>0?coins:null}
export function catchOf(said){const live=said?.live??null
if(live!==null&&typeof live==='object'&&live.running===true){const dry=live.dry!==false
const whole=(value)=>(Number.isSafeInteger(value)&&value>=0?value:0)
const caught=whole(dry?live.would:live.bought)
return{mode:CATCH_MODE.LIVE,caught,searches:whole(live.searches),coins:catchCoinsOf(caught,live.spent),
dry,at:null,reason:null}}
const kept=sanitizeLastRun(said?.kept??null)
if(kept!==null)return{mode:CATCH_MODE.LAST,caught:kept.caught,searches:kept.searches,
coins:catchCoinsOf(kept.caught,kept.coins),dry:kept.dry,at:kept.at,reason:kept.reason}
return{mode:said?.waiting===true?CATCH_MODE.WAIT:CATCH_MODE.NEVER,caught:0,searches:0,coins:null,
dry:false,at:null,reason:null}}
export function catchWords(model,t,num=(value)=>String(value)){const titleKey=model?.mode===CATCH_MODE.LIVE
?'marketBot.catch.titleLive'
:'marketBot.catch.title'
if(model?.mode===CATCH_MODE.WAIT)return{titleKey,card:'',fate:''}
if(model?.mode!==CATCH_MODE.LIVE&&model?.mode!==CATCH_MODE.LAST)return{titleKey,card:t('marketBot.catch.never'),fate:''}
let card=t('marketBot.catch.zero')
if(model.caught>0)card=model.coins===null
?t('marketBot.catch.caughtCount',{n:num(model.caught)})
:t('marketBot.catch.caught',{n:num(model.caught),coins:num(model.coins)})
if(model.dry===true)card=`${card} · ${t('marketBot.catch.demo')}`
const fate=t(pluralKey('marketBot.catch.searches',model.searches,t('marketBot.catch.lang')),{n:num(model.searches)})
return{titleKey,card,fate}}
export function runLinesOf(list){const all=Array.isArray(list)?list:[]
let from=0
for(let at=all.length-1;at>=0;at-=1){if(START_KEYS.includes(all[at]?.key)){from=at
break}}
return all.slice(from).filter((one)=>one?.memo!==true)}
export function raceOf(said){if(said===null||typeof said!=='object')return null
const seq=Number.isSafeInteger(said.seq)&&said.seq>0?said.seq:null
const ms=Number.isSafeInteger(said.toBid)&&said.toBid>=0?said.toBid:null
const outcome=typeof said.outcome==='string'&&said.outcome!==''?said.outcome:null
return seq===null||ms===null||outcome===null?null:{seq,ms,outcome}}
export function runSnapshot(status){const whole=(value)=>(Number.isSafeInteger(value)&&value>=0?value:0)
const stats=status?.stats??null
return{running:status?.running===true,
dry:status?.dryRun!==false,
searches:whole(stats?.searches),
hourLeft:Number.isSafeInteger(status?.summary?.hourAdvice?.left)?status.summary.hourAdvice.left:null,
hourOver:Number.isSafeInteger(status?.summary?.hourAdvice?.over)?status.summary.hourAdvice.over:null,
hourAdvice:typeof status?.summary?.hourAdvice?.advice==='string'?status.summary.hourAdvice.advice:null,
seen:whole(status?.filter?.seen),
bought:whole(stats?.purchases),
would:whole(stats?.wouldBuy),
spent:whole(stats?.spent),
priceLimit:typeof status?.options?.maxPrice==='string'&&status.options.maxPrice!==''
?status.options.maxPrice
:null,
overCap:whole(status?.filter?.overTargetCap),
overPrice:whole(status?.filter?.overMaxPrice),
lastLots:Number.isSafeInteger(status?.filter?.lastLots)?status.filter.lastLots:null,
lastCheap:Number.isSafeInteger(status?.filter?.lastAffordable)?status.filter.lastAffordable:null,
lastCeiling:Number.isSafeInteger(status?.filter?.lastCeiling)?status.filter.lastCeiling:null,
lastFresh:Number.isSafeInteger(status?.filter?.lastFresh)&&status.filter.lastFresh>=0
?status.filter.lastFresh
:null,
sentBid:Number.isSafeInteger(status?.filter?.lastBidSent)&&status.filter.lastBidSent>0
?status.filter.lastBidSent
:null,
sentMinBid:Number.isSafeInteger(status?.filter?.lastMinBidSent)&&status.filter.lastMinBidSent>0
?status.filter.lastMinBidSent
:null,
sentMinBuy:Number.isSafeInteger(status?.filter?.lastMinBuySent)&&status.filter.lastMinBuySent>0
?status.filter.lastMinBuySent
:null,
sentSeen:status?.filter?.lastSentSeen===true,
drift:driftOf(status?.filter?.lastBidDrift),
race:raceOf(status?.filter?.lastRace),
fail:failOf(status?.filter?.lastFail),
answers:Number.isSafeInteger(status?.filter?.answers)&&status.filter.answers>=0
?status.filter.answers
:null,
pageFull:status?.filter?.lastPageFull===true,
dryStreak:whole(status?.filter?.dryStreak),
emptyStreak:whole(status?.filter?.emptyStreak),
misses:whole(status?.filter?.misses),
linkLost:whole(status?.filter?.linkLost),
link:linkOf(status?.filter?.lastLink),
miss:missOf(status?.filter?.miss),
matched:Number.isSafeInteger(status?.detail?.matched)&&status.detail.matched>0?status.detail.matched:null,
where:typeof status?.detail?.stage==='string'&&status.detail.stage!==''?status.detail.stage:null,
field:typeof status?.detail?.field==='string'&&status.detail.field!==''?status.detail.field:null,
door:typeof status?.detail?.door==='string'&&status.detail.door!==''?status.detail.door:null,
phase:typeof status?.session?.phase==='string'?status.session.phase:null,
yielding:status?.session?.yielding===true,
reason:typeof status?.reason==='string'?status.reason:null}}
export const DRY_SAY_EVERY=20
export const NO_PENDING=Object.freeze({searches:0,lots:0})
export const NO_ONCE=Object.freeze({pageFull:false})
export const VOLUME_ADVICE_KEYS=Object.freeze({minute:'snipe.adviceMinute',buys:'snipe.adviceBuys'})
export const NO_LEVELS=Object.freeze({minute:null,buys:null})
function volumeOf(extra){const said=extra?.volume??null
const one=(value)=>{if(!value||typeof value!=='object')return null
const advice=typeof value.advice==='string'&&value.advice!==''?value.advice:null
const raw=Number.isSafeInteger(value.limit)&&value.limit>0?value.limit
:(Number.isSafeInteger(value.cap)&&value.cap>0?value.cap:null)
const over=Number.isSafeInteger(value.over)&&value.over>0?value.over:0
return advice===null||raw===null?null:{advice,over,cap:raw}}
return{minute:one(said?.minute),buys:one(said?.buys)}}
function aimWords(extra){const said=extra?.aim??null
if(said===null||typeof said!=='object')return null
const what=typeof said.what==='string'&&said.what!==''?said.what:null
const price=typeof said.price==='string'&&said.price!==''?said.price:null
return what===null||price===null?null:{what,price}}
function limitNumber(value){if(value===null||value===undefined)return null
const said=Number(String(value).replace(/[^0-9]/g,''))
return Number.isSafeInteger(said)&&said>0?said:null}
export function journalStep(prev,now,extra={}){const out=[]
const num=typeof extra?.num==='function'?extra.num:(value)=>String(value)
const held=extra?.pending??NO_PENDING
const saidOnce=extra?.once??NO_ONCE
let once={pageFull:saidOnce?.pageFull===true}
const saidLevels=extra?.levels??NO_LEVELS
let levels={minute:saidLevels?.minute??null,buys:saidLevels?.buys??null}
let pending={searches:Number.isSafeInteger(held.searches)&&held.searches>0?held.searches:0,
lots:Number.isSafeInteger(held.lots)&&held.lots>0?held.lots:0}
const started=now.running&&(prev===null||!prev.running)
if(started){
const aim=aimWords(extra)
out.push(aim===null
?{key:'marketBot.log.start',params:{},tone:TONE.WARN}
:{key:'marketBot.log.startAim',params:{what:aim.what,price:aim.price},tone:TONE.WARN})
if(now.hourAdvice!==null&&now.hourOver!==null&&now.hourOver>0){
out.push({key:'snipe.adviceOver',params:{n:num(now.hourOver)},tone:TONE.PLAIN})}
pending={searches:0,lots:0}
once={pageFull:false}
levels={minute:null,buys:null}}
if(prev===null)return{lines:out,pending,once,levels}
if(now.hourAdvice!==null&&prev.hourAdvice!==null&&now.hourAdvice!==prev.hourAdvice
&&now.hourAdvice!=='ok'&&now.hourOver!==null&&now.hourOver>0){
out.push({key:'snipe.adviceOver',params:{n:num(now.hourOver)},tone:TONE.PLAIN})}
const volume=volumeOf(extra)
for(const name of ['minute','buys']){const said=volume[name]
if(said===null){levels={...levels,[name]:null}
continue}
if(said.advice!=='ok'&&said.advice!==levels[name]&&said.over>0){
out.push({key:VOLUME_ADVICE_KEYS[name],params:{n:num(said.over),cap:num(said.cap)},tone:TONE.PLAIN})}
levels={...levels,[name]:said.advice}}
const grew=Math.max(0,now.searches-prev.searches)
const lots=Math.max(0,now.seen-prev.seen)
pending={searches:pending.searches+grew,lots:pending.lots+lots}
const answered=now.answers===null||prev.answers===null
?grew===0
:now.answers>prev.answers
const flush=pending.searches>0&&(answered||!now.running)
const counts=now.answers!==null&&prev.answers!==null
if(flush&&counts&&!answered){out.push(pending.searches===1
?{key:'marketBot.log.searchNoAnswer',params:{},tone:TONE.PLAIN}
:{key:'marketBot.log.searchNoAnswerMany',params:{n:pending.searches},tone:TONE.PLAIN})
pending={searches:0,lots:0}}
else if(flush){
const aim=aimWords(extra)
const tip={}
if(Number.isSafeInteger(now.lastLots)&&Number.isSafeInteger(now.lastFresh)){tip.lots=num(now.lastLots)
tip.fresh=num(now.lastFresh)}
if(now.sentBid!==null&&now.sentMinBid!==null&&now.sentMinBuy!==null){tip.bid=num(now.sentBid)
tip.minBid=num(now.sentMinBid)
tip.minBuy=num(now.sentMinBuy)}
out.push(aim===null
?{key:'marketBot.log.searchLiveBlind',params:{n:pending.searches,...tip},tone:TONE.PLAIN}
:{key:LIVE_SEARCH_KEY,params:{n:pending.searches,what:aim.what,price:aim.price,...tip},tone:TONE.PLAIN})
if(now.drift!==null&&(prev.drift===null
||prev.drift.want!==now.drift.want||prev.drift.got!==now.drift.got)){
out.push(now.drift.got===null
?{key:'marketBot.log.bidLost',params:{want:now.drift.want},tone:TONE.BAD}
:{key:'marketBot.log.bidDrift',params:{want:now.drift.want,got:now.drift.got},tone:TONE.BAD})}
pending={searches:0,lots:0}}
if(now.pageFull===true&&!once.pageFull){out.push({key:'marketBot.log.pageFull',params:{},tone:TONE.PLAIN})
once={...once,pageFull:true}}
const bought=now.bought-prev.bought
const name=typeof extra?.name==='string'&&extra.name!==''?extra.name:null
if(bought>0){const coins=Math.max(0,now.spent-prev.spent)
out.push(name===null
?{key:'marketBot.log.boughtBlind',params:{coins},tone:TONE.GOOD}
:{key:'marketBot.log.bought',params:{name,coins},tone:TONE.GOOD})}
const missed=Math.max(0,now.misses-prev.misses)
if(missed>0){const miss=now.miss
const coins=miss===null?0:miss.price
const said=cardWords(miss)
if(missed===1)out.push(said===null
?{key:'marketBot.log.missedBlind',params:{coins},tone:TONE.PLAIN}
:{key:'marketBot.log.missed',params:{name:said,coins},tone:TONE.PLAIN})
else out.push(said===null
?{key:'marketBot.log.missedManyBlind',params:{n:missed,coins},tone:TONE.PLAIN}
:{key:'marketBot.log.missedMany',params:{n:missed,name:said,coins},tone:TONE.PLAIN})}
const dropped=Math.max(0,now.linkLost-prev.linkLost)
if(dropped>0&&now.link!==null){out.push({key:'marketBot.log.linkLost',
params:{code:now.fail!==null&&now.fail.status!==null?num(now.fail.status):'?'},
tone:TONE.BAD})}
if(now.race!==null&&(prev.race===null||prev.race.seq!==now.race.seq)
&&(now.race.outcome==='bought'||now.race.outcome==='lost')){
const sec=num(Math.round(now.race.ms/10)/100)
for(let index=out.length-1;index>=0;index-=1){const one=out[index]
if(!RACE_HOSTS.includes(one.key))continue
out[index]={...one,params:{...one.params,sec}}
break}}
const overCap=Math.max(0,now.overCap-prev.overCap)
const overPrice=Math.max(0,now.overPrice-prev.overPrice)
const skipped=overCap+overPrice
if(skipped>0){const aimCap=Number.isSafeInteger(extra?.cap)&&extra.cap>0?extra.cap:null
const limit=limitNumber(now.priceLimit)
const cap=aimCap===null?limit:(limit===null?aimCap:Math.min(aimCap,limit))
out.push(cap===null
?{key:'marketBot.log.overPricedBlind',params:{n:skipped},tone:TONE.PLAIN}
:{key:'marketBot.log.overPriced',params:{n:skipped,cap},tone:TONE.PLAIN})}
if(now.phase==='break'&&prev.phase!=='break')out.push({key:'marketBot.log.rest',params:{},tone:TONE.PLAIN})
if(now.yielding&&!prev.yielding)out.push({key:'marketBot.log.yield',params:{},tone:TONE.PLAIN})
if(!now.running&&prev.running){const why=now.reason??prev.reason??null
const params={why}
if(now.door!==null)params.whyDoor=now.door
if(why===TOO_MANY_MATCHES&&now.matched!==null)params.whyN=now.matched
if(why===FILTER_CHANGED&&typeof extra?.stopWords==='string'&&extra.stopWords!=='')params.whyWords=extra.stopWords
const fail=LOUD_STOPS.includes(why)?now.fail:null
if(fail===null){
if(now.where!==null&&now.field!==null){out.push({key:'marketBot.log.stoppedWhere',
params:{...params,whatKey:failStageKey(now.where),fieldKey:failFieldKey(now.field),field:now.field},
tone:stopTone(why)})
return{lines:out,pending,once,levels}}
out.push({key:'marketBot.log.stopped',params,tone:stopTone(why)})
return{lines:out,pending,once,levels}}
out.push({key:fail.status===null?'marketBot.log.stoppedFail':'marketBot.log.stoppedCode',
params:{...params,code:fail.status,whatKey:failStageKey(fail.stage),n:fail.search},
tone:stopTone(why)})}
return{lines:out,pending,once,levels}}
export function stampOf(at){const time=Number(at)
if(!Number.isFinite(time)||time<=0)return '--:--:--'
const date=new Date(time)
const two=(value)=>String(value).padStart(2,'0')
return `${two(date.getHours())}:${two(date.getMinutes())}:${two(date.getSeconds())}`}
export function lineMark(one){let said=''
try{said=JSON.stringify(one?.params??{})}catch{
said='?'}
return `${one?.stamp??''}|${one?.key??''}|${said}|${one?.tone??''}|${one?.memo===true?'memo':''}|${one?.past===true?'past':''}`}
export function layoutRulesReady(row,add){if(row?.display!=='flex')return false
return add===null?true:add?.position==='absolute'}
export function createMarketBotColumn(deps={}){const{doc}=deps
const win=deps.win??doc?.defaultView??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const num=typeof deps.formatNumber==='function'?deps.formatNumber:(value)=>String(value)
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const now=typeof deps.clock?.now==='function'?()=>deps.clock.now():()=>Date.now()
const hunt=deps.hunt??null
const isActive=typeof deps.isActive==='function'?deps.isActive:null
const allowed=()=>{if(isActive===null)return true
try{return isActive(SNIPE_FEATURE)===true}catch(err){onError(err)
return false}}
const showMinBid=typeof deps.showMinBid==='function'?deps.showMinBid:null
const restoreMinBid=typeof deps.restoreMinBid==='function'?deps.restoreMinBid:null
const showPair=typeof deps.showPair==='function'?deps.showPair:null
const restorePair=typeof deps.restorePair==='function'?deps.restorePair:null
let minBidWas
let pairWas
let pairSeat=null
const readCriteria=typeof deps.criteria==='function'?deps.criteria:null
const readSets=typeof deps.filters==='function'?deps.filters:null
const applySet=typeof deps.applySet==='function'?deps.applySet:null
const saveSet=typeof deps.saveSet==='function'?deps.saveSet:null
const readLoot=typeof deps.loot==='function'?deps.loot:null
const readVolume=typeof deps.volume==='function'?deps.volume:null
const readAim=typeof deps.aim==='function'?deps.aim:null
const readStopWords=typeof deps.stopWords==='function'?deps.stopWords:null
const readRun=typeof deps.runMemory==='function'?deps.runMemory:null
const writeRun=typeof deps.setRunMemory==='function'?deps.setRunMemory:null
let box=null
let nameHost=null
const SETS_LINES=2
let parts=null
let fitted=null
let fitTries=0
let setsTries=0
let settleTries=0
let fitTimer=null
const drawn=new Map()
let lines=[]
let seq=0
let seen=null
let pending=NO_PENDING
let saidOnce=NO_ONCE
let saidLevels=NO_LEVELS
let liveAt=0
let notice=''
let view=JOURNAL_VIEW.ALL
let kept=null
let recalled=false
let recallTries=0
let recallTimer=null
let standRun=null
const partPaints={sets:0,catch:0,journal:0}
let passes=0,paints=0,sets=0,logged=0,fits=0,remembered=0,wakes=0
const statusNow=()=>{if(hunt===null||typeof hunt.status!=='function')return null
try{return hunt.status()}catch(err){onError(err)
return null}}
function targetNow(){if(readCriteria===null)return null
let said=null
try{said=readCriteria()}catch(err){onError(err)
return null}
const criteria=said?.criteria??null
if(criteria===null||criteria===undefined)return null
return targetFromCriteria(criteria)}
const setsNow=()=>{if(readSets===null)return null
let said=null
try{said=readSets()}catch(err){onError(err)
return null}
return Array.isArray(said)?said:null}
const lootNow=()=>{if(readLoot===null)return[]
let rows=[]
try{rows=readLoot()}catch(err){onError(err)
rows=[]}
if(!Array.isArray(rows))return[]
return rows.map((raw)=>lootRowModel(raw,null)).reverse()}
const lastCaughtName=()=>{const rows=lootNow()
return rows.length===0?null:cardWords(rows[0])}
function standCatch(said){const raw=said&&typeof said==='object'&&!Array.isArray(said)?said:null
const run=raw===null?null:sanitizeLastRun({at:now(),reason:null,searches:raw.searches,
caught:raw.caught,coins:raw.coins,dry:raw.dry===true})
standRun=run
paint()
return{ok:true,stand:run!==null}}
function hear(){if(recall())paint()
else askAgain()
const was=seen
const shot=runSnapshot(statusNow())
let cap=null
try{cap=targetNow()?.cap??null}catch(err){onError(err)
cap=null}
let aim=null
if(readAim!==null){try{aim=readAim()}catch(err){onError(err)
aim=null}}
let volume=null
if(readVolume!==null){try{volume=readVolume()}catch(err){onError(err)
volume=null}}
let stopWords=''
if(readStopWords!==null){try{const raw=readStopWords()
stopWords=typeof raw==='string'?raw:''}catch(err){onError(err)
stopWords=''}}
if(showPair!==null){const runs=shot.running===true
if(runs){if(shot.sentSeen===true){try{const said=showPair({minBid:shot.sentMinBid??null,minBuy:shot.sentMinBuy??null})
if(said&&said.ok===true&&(pairWas===undefined||said.seat!==pairSeat)){pairWas=said.was??null
pairSeat=said.seat??null}}catch(err){onError(err)}}}
else if(pairWas!==undefined){const mine=pairWas
const seat=pairSeat
pairWas=undefined
pairSeat=null
if(restorePair!==null){const back={minBid:mine?.minBid??null,minBuy:mine?.minBuy??null}
if(mine!==null&&typeof mine==='object'&&Object.hasOwn(mine,'maxBid'))back.maxBid=mine.maxBid??null
try{restorePair(back,seat)}catch(err){onError(err)}}}}
else if(showMinBid!==null){const runs=shot.running===true
if(runs){if(shot.sentSeen===true){try{const said=showMinBid(shot.sentMinBid??null)
if(minBidWas===undefined&&said&&said.ok===true)minBidWas=said.was??null}catch(err){onError(err)}}}
else if(minBidWas!==undefined){const mine=minBidWas
minBidWas=undefined
if(restoreMinBid!==null){try{restoreMinBid(mine)}catch(err){onError(err)}}}}
const said=journalStep(seen,shot,{name:lastCaughtName(),cap,pending,once:saidOnce,levels:saidLevels,volume,aim,stopWords,num})
seen=shot
pending=said.pending
saidOnce=said.once??NO_ONCE
saidLevels=said.levels??NO_LEVELS
let grew=0
if(said.lines.length>0){const at=now()
for(const one of said.lines){
const tail=lines.length>0?lines[lines.length-1]:null
const live=tail!==null&&LIVE_SEARCH_KEYS.includes(tail.key)&&tail.past!==true?tail:null
if(live!==null&&one.key===live.key){live.count+=Number(one.params?.n)||0
if(at-liveAt>=LIVE_REDRAW_MS){
const said={...live.params,n:live.count}
for(const field of LIVE_TIP_FIELDS){if(Object.hasOwn(one.params,field))said[field]=one.params[field]
else delete said[field]}
live.params=said
live.mark=lineMark(live)
liveAt=at
grew+=1}
continue}
if(live!==null&&live.count!==live.params?.n){live.params={...live.params,n:live.count}
live.mark=lineMark(live)}
seq+=1
const born={id:seq,at,stamp:stampOf(at),key:one.key,params:one.params,tone:one.tone}
born.mark=lineMark(born)
if(LIVE_SEARCH_KEYS.includes(one.key)){born.count=Number(one.params?.n)||0
liveAt=at}
lines.push(born)
grew+=1}
if(lines.length>JOURNAL_MAX)lines=lines.slice(lines.length-JOURNAL_MAX)
logged+=grew}
const stopped=was!==null&&was.running&&!shot.running
if(stopped||grew>0)remember(stopped||shot.running?shot:null)
return grew}
function recall(){if(recalled||readRun===null)return false
let said=null
try{said=readRun()}catch(err){onError(err)
return false}
if(said===null||said===undefined)return false
recalled=true
const one=sanitizeMarketBotView(said).lastRun
if(one===null)return false
view=one.view
kept=one.run
const before=[]
for(const row of one.lines){
if(typeof row.key==='string'&&t(row.key,row.params)===row.key)continue
seq+=1
const born={id:seq,at:row.at,stamp:stampOf(row.at),past:true,
key:row.key,params:row.params,tone:row.tone}
born.mark=lineMark(born)
before.push(born)}
if(one.run!==null){seq+=1
const born={id:seq,at:one.run.at,stamp:stampOf(one.run.at),memo:true,past:true,
key:'marketBot.log.lastRun',
params:{why:one.run.reason,n:one.run.searches,m:one.run.caught},tone:TONE.PLAIN}
born.mark=lineMark(born)
before.push(born)}
if(before.length===0)return false
lines=[...before,...lines]
if(lines.length>JOURNAL_MAX)lines=lines.slice(lines.length-JOURNAL_MAX)
return true}
const RECALL_TRIES=5
const RECALL_DELAY_MS=120
function askAgain(){if(recalled||readRun===null||recallTimer!==null)return false
if(recallTries>=RECALL_TRIES)return false
if(typeof win?.setTimeout!=='function')return false
const delay=RECALL_DELAY_MS*(2**recallTries)
recallTries+=1
recallTimer=win.setTimeout(()=>{recallTimer=null
try{
if(recall()){wakes+=1
paint()}
else askAgain()}catch(err){onError(err)}},delay)
return true}
function stopRecall(){if(recallTimer===null)return
try{win?.clearTimeout?.(recallTimer)}catch{
}
recallTimer=null}
function remember(shot=null){if(writeRun===null)return false
const rows=lines.filter((one)=>one.past!==true)
.map((one)=>({at:one.at,key:one.key,params:one.params,tone:one.tone}))
.slice(-JOURNAL_MAX)
const run=shot===null
?kept
:{at:now(),reason:shot.reason??null,searches:shot.searches,
caught:shot.dry?shot.would:shot.bought,coins:shot.spent,dry:shot.dry}
kept=run
try{writeRun({lastRun:{run,lines:rows,view}})}catch(err){onError(err)
return false}
remembered+=1
return true}
function forget(event=null){lines=[]
seq=0
seen=null
pending=NO_PENDING
notice=''
if(event?.reason!==EPOCH_REASON.SWITCHED){
recalled=false
recallTries=0
askAgain()
return true}
recalled=true
stopRecall()
kept=null
view=JOURNAL_VIEW.ALL
if(writeRun!==null){try{writeRun({lastRun:null})}catch(err){onError(err)}}
return true}
function head(key,slot=false,tail=null){return el(doc,'div',{class:'fx-mcol-head'},
[logoLink(doc),el(doc,'span',{text:t(key)}),
slot?el(doc,'span',{class:'fx-mcol-head-tail',dataset:{futMarketColSetsMore:'1'},attrs:{hidden:'hidden'}}):null,
tail].filter(Boolean))}
function viewTail(){const shown=shownLines().length
const all=lines.length
return shown<all?t('marketBot.logMore',{shown:num(shown),total:num(all)}):null}
function viewPick(){const pick=el(doc,'select',{class:'fx-mcol-pick',
attrs:{title:t('marketBot.logViewHint'),'aria-label':t('marketBot.logViewHint')},
dataset:{futMarketColLogView:view},
on:{change:(event)=>{event?.stopPropagation?.()
useView(pick.value)}}})
for(const name of JOURNAL_VIEWS){const option=el(doc,'option',{text:t(JOURNAL_VIEW_KEYS[name]),
attrs:{value:name}})
if(name===view)option.selected=true
pick.appendChild(option)}
return pick}
function useView(said){const next=journalViewOf(said)
if(next===view)return false
view=next
remember(null)
paint()
return true}
function block(name,titleKey,children){return el(doc,'section',
{class:'fx-mcol-block',dataset:{[PART_MARK]:name}},
[head(titleKey),...children.filter(Boolean)])}
function setsPart(){const all=newestFirst(setsNow())
if(all===null)return null
const list=all
const chips=list.map((set,at)=>{const cap=Number(set?.criteria?.maxBuy)
const capped=Number.isSafeInteger(cap)&&cap>0
const id=chipId(set?.id)
return el(doc,'button',{class:id===null?'fx-mcol-set':`fx-mcol-set ${SET_CLASS_PREFIX}${id}`,
attrs:{type:'button',title:capped?t('marketBot.setsHintCap',{coins:num(cap)}):t('marketBot.setsHint')},
dataset:id===null?{futMarketColSet:String(at)}:{futMarketColSet:String(at),[SET_ID_MARK]:id},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
useSet(set)}}},
[el(doc,'span',{class:'fx-mcol-set-name',text:String(set?.name??'')}),
capped?el(doc,'span',{class:'fx-mcol-set-cap',text:shortCoins(cap,num,t)}):null].filter(Boolean))})
const save=saveSet===null?null:el(doc,'button',{class:'fx-mcol-set fx-mcol-set-add',
attrs:{type:'button',title:t('marketBot.setsSaveHint')},dataset:{futMarketColSetAdd:'1'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
askName()}}},[el(doc,'span',{text:t('marketBot.setsSave')})])
if(chips.length===0&&save===null)return null
return el(doc,'section',{class:'fx-mcol-block',dataset:{[PART_MARK]:'sets'}},
[head('marketBot.setsTitle',true),
el(doc,'div',{class:chips.length===0?'fx-mcol-sets':'fx-mcol-sets fx-mcol-sets-rows',dataset:{futMarketColSets:`${list.length}/${all.length}`}},
[...chips,save].filter(Boolean))])}
function useSet(set){sets+=1
if(applySet===null){notice=t('marketBot.setsNoPort')
paint()
return false}
let said=null
try{said=applySet(String(set?.id??''))}catch(err){onError(err)
said=null}
const ok=said===true||said?.ok===true
notice=ok?'':(said?.notice?.key?t(said.notice.key,said.notice.params??{}):t('marketBot.setsRefused'))
paint()
return ok}
function askName(){if(saveSet===null)return null
closeName()
const field=el(doc,'input',{class:'fx-mcol-name',
attrs:{type:'text',spellcheck:'false',placeholder:t('marketBot.setsSavePlaceholder'),
'aria-label':t('marketBot.setsSaveTitle')},
dataset:{[SAVE_FIELD_MARK]:'1'},
on:{keydown:(event)=>{event?.stopPropagation?.()
if(event?.key==='Escape'){event.preventDefault?.()
closeName()
return}
if(event?.key==='Enter'){event.preventDefault?.()
void keepSet(field)}}}})
const buttons=modalButtons(doc,[{text:t('marketBot.setsSaveOk'),mark:'futMarketColSaveOk',kind:'primary',on:()=>{void keepSet(field)}},
{text:t('common.cancel'),mark:'futMarketColSaveCancel',on:closeName}])
nameHost=modalBox(doc,{mark:SAVE_WINDOW_MARK,title:t('marketBot.setsSaveTitle'),onBack:closeName},[field,buttons])
;(doc.body??doc.documentElement)?.appendChild?.(nameHost)
field.focus?.()
return nameHost}
function closeName(){if(nameHost===null)return false
try{nameHost.remove()}catch{
}
nameHost=null
return true}
async function keepSet(field){if(saveSet===null)return false
const name=String(field?.value??'').trim()
if(name===''){field?.focus?.()
return false}
closeName()
let said=null
try{said=await saveSet(name)}catch(err){onError(err)
said=null}
const ok=said===true||said?.ok===true
notice=ok||said?.cancelled===true
?''
:(said?.notice?.key?t(said.notice.key,said.notice.params??{}):t('marketBot.setsRefused'))
paint()
return ok}
function catchNow(){if(standRun!==null)return catchOf({kept:standRun})
return catchOf({live:seen,kept,
waiting:kept===null&&readRun!==null&&!recalled&&recallTries<RECALL_TRIES})}
function catchTip(model){if(model.mode===CATCH_MODE.WAIT)return ''
if(model.mode===CATCH_MODE.NEVER)return t('marketBot.catch.tipNever')
const rows=standRun===null?runLinesOf(lines):[]
const out=[model.mode===CATCH_MODE.LIVE
?t('marketBot.catch.tipLive')
:t('marketBot.catch.tipLast',{time:stampOf(model.at).slice(0,5)})]
if(model.dry){out.push(t('marketBot.catch.tipDemo',{n:num(model.caught)}))}
else if(model.caught===0){out.push(t('marketBot.catch.tipNone'))}
else{const bought=rows.filter((one)=>BUY_KEYS.includes(one.key)).slice(-CATCH_TIP_ROWS)
for(const one of bought)out.push(wordsOf(one))
const more=model.caught-bought.length
if(more>0)out.push(t('marketBot.catch.tipMore',{n:num(more)}))}
for(const one of rows.filter((row)=>MISS_KEYS.includes(row.key)).slice(-CATCH_TIP_ROWS))out.push(wordsOf(one))
out.push(t('marketBot.catch.tipSearches',{n:num(model.searches)}))
const start=rows.find((one)=>START_KEYS.includes(one.key))??null
if(start!==null&&start.key==='marketBot.log.startAim'){out.push(t('marketBot.catch.tipFilter',
{what:String(start.params?.what??''),price:String(start.params?.price??'')}))}
if(model.mode===CATCH_MODE.LAST){const stop=[...rows].reverse().find((one)=>STOP_LINE_KEYS.includes(one.key))??null
if(stop!==null)out.push(wordsOf(stop))
else if(model.reason!==null)out.push(wordsOf({key:'marketBot.log.stopped',params:{why:model.reason}}))}
return out.join('\n')}
function catchSaid(){const model=catchNow()
const said=catchWords(model,t,num)
return{mode:model.mode,title:t(said.titleKey),titleKey:said.titleKey,card:said.card,fate:said.fate,tip:catchTip(model)}}
function catchPart(){const said=catchSaid()
return el(doc,'section',{class:'fx-mcol-block fx-mcol-catch',
attrs:said.tip===''?{}:{title:said.tip},dataset:{[PART_MARK]:'catch'}},
[head(said.titleKey),
el(doc,'div',{class:'fx-mcol-loot fx-mcol-catch-line',dataset:{futMarketColCatch:said.mode}},
[el(doc,'span',{class:'fx-mcol-loot-card',text:said.card}),
el(doc,'span',{class:'fx-mcol-loot-fate',text:said.fate})])])}
const MONEY_MARK=String.fromCharCode(1)
function sayLine(one){const parts=wordsOf(one,MONEY_MARK).split(MONEY_MARK)
if(parts.length!==3||parts[1]==='')return{text:parts.join('')}
return{head:parts[0],money:parts[1],tail:parts[2]}}
function journalPart(){const shown=shownLines()
const rows=[]
let split=false
for(const one of[...shown].reverse()){
if(one.past===true&&!split){split=true
if(rows.length>0)rows.push(el(doc,'div',{class:'fx-mcol-log-split',
dataset:{futMarketColLogSplit:'1'},text:t('marketBot.logPast')}))}
const said=sayLine(one)
const money=Object.hasOwn(said,'money')&&MISS_KEYS.includes(one.key)
const parted=Object.hasOwn(said,'money')
const whole=parted?`${said.head}${said.money}${said.tail}`:said.text
const said2=one.params??{}
const raced=said2.sec
const more=[]
if(said2.lots!==undefined)more.push(t('marketBot.log.searchTip',{lots:said2.lots,fresh:said2.fresh}))
if(said2.bid!==undefined)more.push(t('marketBot.log.searchTipRing',
{minBid:said2.minBid,bid:said2.bid,minBuy:said2.minBuy}))
if(raced!==undefined&&raced!==null)more.push(t('marketBot.log.raceClock',{sec:raced}))
const tip=more.length===0?whole:`${whole} · ${more.join(' · ')}`
rows.push(el(doc,'div',{class:logClassOf(one),attrs:{title:tip},
dataset:{futMarketColLog:String(one.id)}},
[el(doc,'span',{class:'fx-mcol-log-at',text:one.stamp}),
money
?el(doc,'span',{class:'fx-mcol-log-words'},[el(doc,'span',{text:said.head}),
el(doc,'span',{class:'fx-mcol-money fx-mcol-money-warn',
dataset:{futMarketColMoney:'1'},text:said.money}),
el(doc,'span',{text:said.tail})])
:el(doc,'span',{class:'fx-mcol-log-words',text:whole})]))}
const empty=lines.length===0?'marketBot.logEmpty':'marketBot.logEmptyView'
return el(doc,'section',{class:'fx-mcol-block fx-mcol-journal',
attrs:{title:t('marketBot.logHint')},dataset:{[PART_MARK]:'journal'}},
[head('marketBot.logTitle',false,el(doc,'span',{class:'fx-mcol-head-pick'},
[viewTail()===null?null:el(doc,'span',{class:'fx-mcol-head-tail',
dataset:{futMarketColLogMore:'1'},text:viewTail()}),viewPick()].filter(Boolean))),
rows.length===0?el(doc,'div',{class:'fx-mcol-empty',text:t(empty)}):null,
el(doc,'div',{class:'fx-mcol-log-list'},rows)].filter(Boolean))}
function shownLines(){return lines.filter((one)=>logViewKeeps(view,one))}
function wordsOf(one,wrap=''){const params={...one.params}
if(Object.hasOwn(params,'why')){const why=params.why
const extra={}
if(Object.hasOwn(params,'whyN'))extra.n=num(params.whyN)
if(Object.hasOwn(params,'whyWords'))extra.words=params.whyWords
const door=typeof params.whyDoor==='string'&&params.whyDoor!==''?params.whyDoor:null
if(door!==null)extra.cause=Object.hasOwn(DOOR_CAUSE_KEYS,door)?t(DOOR_CAUSE_KEYS[door]):door
params.why=why===null||why===undefined
?t('automation.stop.unknown',{reason:'—'})
:t(stopReasonKey(why,door),{...extra,reason:String(why)})
delete params.whyN
delete params.whyWords
delete params.whyDoor}
if(Object.hasOwn(params,'whatKey')){params.what=t(params.whatKey)
delete params.whatKey}
if(Object.hasOwn(params,'fieldKey')){if(params.fieldKey!==null)params.field=t(params.fieldKey)
delete params.fieldKey}
for(const key of['n','lots','coins','cap','m','fresh','bid','want','got'])if(Object.hasOwn(params,key))params[key]=num(params[key])
if(wrap!==''&&Object.hasOwn(params,'coins'))params.coins=`${wrap}${params.coins}${wrap}`
if(Object.hasOwn(params,'limit')){const said=Number(String(params.limit).replace(/[^0-9]/g,''))
params.limit=Number.isSafeInteger(said)&&said>0?num(said):params.limit}
return t(one.key,params)}
function partKey(name){try{
if(name==='sets'){const all=newestFirst(setsNow())
return all===null?'none':JSON.stringify([saveSet!==null,t('marketBot.setsTitle'),
all.map((one)=>[one?.id,one?.name,one?.criteria?.maxBuy])])}
if(name==='journal')return [t('marketBot.logTitle'),view,t(JOURNAL_VIEW_KEYS[view]),
viewTail()??'',t('marketBot.logHint'),...shownLines().map((one)=>one.mark)].join('//')
if(name==='catch')return JSON.stringify(catchSaid())
return ''}catch(err){onError(err)
return 'error'}}
function buildPart(name){if(name==='sets')return setsPart()
if(name==='catch')return catchPart()
if(name==='journal')return journalPart()
return null}
const PARTS=Object.freeze(['sets','catch','journal'])
function paint(){if(box===null||parts===null)return false
let touched=0
for(const name of PARTS){const mark=partKey(name)
if(drawn.get(name)===mark)continue
drawn.set(name,mark)
const built=buildPart(name)
const slot=parts.get(name)
clear(slot)
if(built!==null)slot.appendChild(built)
partPaints[name]=(partPaints[name]??0)+1
touched+=1}
if(drawn.get('notice')!==notice){drawn.set('notice',notice)
parts.get('notice').textContent=notice
parts.get('notice').hidden=notice===''
touched+=1}
if(touched>0)paints+=1
return touched>0}
const FIT_TRIES=40
const FIT_DELAY_MS=120
const SETTLE_TRIES=5
function fitSets(){if(box===null)return 0
const row=box.querySelector?.('[data-fut-market-col-sets]')??null
if(row===null)return 0
const chips=Array.from(row.querySelectorAll?.('[data-fut-market-col-set]')??[])
if(chips.length===0)return 0
const add=row.querySelector?.('[data-fut-market-col-set-add]')??null
const show=(node)=>{if(node.hidden===true)node.hidden=false}
const hide=(node)=>{if(node.hidden!==true)node.hidden=true}
const linesOf=(list)=>{const tops=new Set()
for(const one of list){const box=one.getBoundingClientRect?.()
if(box)tops.add(Math.round(box.top))}
return tops.size}
let gone=0
try{for(const chip of chips)show(chip)
const first=chips[0].getBoundingClientRect?.()
if(!first||!(first.height>0)||!rulesReady(row,add)){if(setsTries<FIT_TRIES){setsTries+=1
laterFit(doc?.querySelector?.(MARKET_COL_SELECTOR)??null)}
tellFit(row,add,chips.length,0)
return 0}
for(let guard=chips.length;guard>=0;guard-=1){const seen=chips.filter((one)=>one.hidden!==true)
if(seen.length===0)break
const last=seen[seen.length-1].getBoundingClientRect?.()
const corner=add?add.getBoundingClientRect?.():null
if(!last)break
const tall=linesOf(seen)>SETS_LINES
const clash=corner!==null&&corner.width>0&&last.bottom>corner.top+1&&last.right>corner.left-1
if(!tall&&!clash)break
hide(seen[seen.length-1])
gone+=1}}catch(err){onError(err)
return 0}
tellFit(row,add,chips.length,gone)
return gone}
function rulesReady(row,add){if(typeof win?.getComputedStyle!=='function')return false
try{return layoutRulesReady(win.getComputedStyle(row),add===null?null:win.getComputedStyle(add))}catch(err){onError(err)
return false}}
function tellFit(row,add,total,gone){const shown=total-gone
const tail=gone>0?t('marketBot.setsMore',{shown:num(shown),total:num(total)}):null
const said=box?.querySelector?.('[data-fut-market-col-sets-more]')??null
if(said!==null){const text=tail===null?'':tail
if(said.textContent!==text)said.textContent=text
if(tail===null){if(said.hidden!==true)said.hidden=true}
else if(said.hidden===true)said.hidden=false}
const mark=`${shown}/${total}`
if(row.dataset.futMarketColSets!==mark)row.dataset.futMarketColSets=mark
return shown}
function fitHeight(root){if(box===null)return null
const host=root?.querySelector?.('.ut-content-container > .ut-content')??null
if(host===null)return null
let wanted=null
try{const last=host.children?.[host.children.length-1]??null
if(last===null)return null
const top=host.getBoundingClientRect?.()?.top
const bottom=last.getBoundingClientRect?.()?.bottom
const own=host.clientHeight
if(!Number.isFinite(top)||!Number.isFinite(bottom)||!Number.isFinite(own))return null
const content=Math.round(bottom-top)
if(content<=0||own<=0){
if(fitTries<FIT_TRIES){fitTries+=1
laterFit(root)}
return null}
wanted=Math.min(own,content)}catch(err){onError(err)
return null}
if(fitted!==null&&Math.abs(fitted-wanted)<=1)return fitted
fitted=wanted
try{box.style.maxHeight=`${wanted}px`}catch(err){onError(err)}
fits+=1
if(settleTries<SETTLE_TRIES){laterFit(root,FIT_DELAY_MS*(2**settleTries))
settleTries+=1}
return wanted}
function laterFit(root,delay=FIT_DELAY_MS){if(fitTimer!==null||typeof win?.setTimeout!=='function')return
fitTimer=win.setTimeout(()=>{fitTimer=null
try{fitSets()
fitHeight(root)}catch(err){onError(err)}},delay)}
function stopFit(){if(fitTimer===null)return
try{win?.clearTimeout?.(fitTimer)}catch{
}
fitTimer=null}
function containerOf(root){try{return root?.querySelector?.('.ut-content-container')??null}catch(err){onError(err)
return null}}
function mount(root){const host=containerOf(root)
if(host===null)return null
let existing=null
for(const kid of Array.from(host.children??[])){let ours=false
try{ours=kid?.matches?.(COLUMN_SELECTOR)===true}catch{ours=false}
if(ours){existing=kid
break}}
if(existing!==null&&existing===box)return box
if(existing!==null){try{existing.remove()}catch{
}}
const slots=new Map()
const kids=[]
for(const name of PARTS){const slot=el(doc,'div',{class:`fx-mcol-slot fx-mcol-slot-${name}`})
slots.set(name,slot)
kids.push(slot)}
const noticeNode=el(doc,'div',{class:'fx-mcol-notice',attrs:{hidden:'hidden'}})
slots.set('notice',noticeNode)
kids.push(noticeNode)
box=el(doc,'aside',{class:'fx-mcol',dataset:{[COLUMN_MARK]:'1'}},kids)
parts=slots
drawn.clear()
fitted=null
fitTries=0
setsTries=0
settleTries=0
host.appendChild(box)
return box}
function clearAll(){let gone=0
closeName()
stopFit()
standRun=null
fitted=null
fitTries=0
setsTries=0
settleTries=0
for(const node of Array.from(doc?.querySelectorAll?.(COLUMN_SELECTOR)??[])){try{node.remove()
gone+=1}catch{
}}
for(const node of Array.from(doc?.querySelectorAll?.(MARKET_COL_SELECTOR)??[])){try{delete node.dataset[MARKET_COL_MARK]
gone+=1}catch{
}}
box=null
parts=null
drawn.clear()
return gone}
function refresh(root){passes+=1
if(!root||!allowed()){if(box!==null)clearAll()
return false}
const node=mount(root)
if(node===null){
if(root.dataset&&root.dataset[MARKET_COL_MARK]==='1')delete root.dataset[MARKET_COL_MARK]
return false}
if(root.dataset&&root.dataset[MARKET_COL_MARK]!=='1')root.dataset[MARKET_COL_MARK]='1'
paint()
fitSets()
fitHeight(root)
return true}
function relabel(){drawn.clear()
return paint()}
return{refresh,relabel,hear,forget,clearAll,
useSet,useView,standCatch,
state(){const caught=catchSaid()
return{build:COLUMN_BUILD,
column:doc?.querySelectorAll?.(COLUMN_SELECTOR)?.length??0,
setIds:Array.from(doc?.querySelectorAll?.(SET_ID_SELECTOR)??[])
.map((one)=>one.dataset?.[SET_ID_MARK]).join(' · '),
marked:doc?.querySelectorAll?.(MARKET_COL_SELECTOR)?.length??0,
parts:box===null?'':Array.from(box.querySelectorAll?.('[data-fut-market-col-part]')??[])
.map((one)=>one.dataset.futMarketColPart).join(' · '),
sets:box===null?null:(box.querySelector('[data-fut-market-col-sets]')?.dataset?.futMarketColSets??null),
lootAll:lootNow().length,
catchMode:caught.mode,
catchTitle:caught.title,
catchLine:caught.fate===''?caught.card:`${caught.card} · ${caught.fate}`,
catchTip:caught.tip,
catchStand:standRun!==null,
catchDrawn:box===null?0:(box.querySelectorAll?.('[data-fut-market-col-catch]')?.length??0),
standCatch,
log:lines.length,
logView:view,
logShown:shownLines().length,
logPast:lines.filter((one)=>one.past===true).length,
fit:fitted,
setsWait:setsTries,
settle:settleTries,
logLast:lines.length===0?'':wordsOf(lines[lines.length-1]),
logOldest:lines.length===0?'':wordsOf(lines[0]),
notice,
wakes,
work:{passes,paints,sets,logged,fits,remembered,wakes,parts:{...partPaints}}}},
dispose(){stopRecall()
clearAll()}}}
