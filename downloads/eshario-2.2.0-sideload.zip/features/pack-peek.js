import{el,clear,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoLink} from '../ui/controls.js'
import{enhancePriceBadges,priceBadgePeek,priceBadgeCoins,onPriceBadgeMeasured} from './price-badges.js'
import{installPackRevealCapture,peekItemFacts} from '../adapter/pack-peek.js'
import{peekSums,peekVerdictWords} from './pack-value.js'
export{peekSums} from './pack-value.js'
export const PACK_PEEK_FEATURE='packPeek'
export const PACK_PEEK_MARK='data-fut-pack-peek'
export const PACK_PEEK_SURFACE=Object.freeze({id:'pack-peek',rootClass:'ut-store-reveal-modal-list-view'})
const STYLESHEET=new URL('../ui/pack-peek.css',import.meta.url).href
const LINK_ID='fut-companion-pack-peek'
export function createPackPeek(deps={}){const{doc,t}=deps
const win=deps.win??doc?.defaultView??null
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const priceOf=typeof deps.priceOf==='function'?deps.priceOf:null
const formatCoins=typeof deps.formatCoins==='function'?deps.formatCoins:(value)=>String(Math.round(value))
const install=typeof deps.install==='function'?deps.install:installPackRevealCapture
const badges=typeof deps.badges==='function'?deps.badges:enhancePriceBadges
const onMeasured=typeof deps.onMeasured==='function'?deps.onMeasured:onPriceBadgeMeasured
const warm=typeof deps.warm==='function'?deps.warm:priceBadgeCoins
const peekPrice=typeof deps.peek==='function'?deps.peek:priceBadgePeek
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let capture={ok:false,reason:'not-run',dispose(){}}
let last=null
let lastResult={ok:false,reason:'not-run'}
let shows=0
function priceOfItem(item){const def=peekItemFacts(item).def
if(def===null)return null
const peek=peekPrice(def)
if(peek!==null)return peek
if(priceOf===null)return null
const value=priceOf(item)
return typeof value==='number'&&Number.isFinite(value)&&value>0?value:null}
function tryInstall(){if(capture.ok)return true
try{capture=install(win,(shown)=>{try{show(shown)}catch(err){onError(err)}})}catch(err){onError(err)
capture={ok:false,reason:'failed',dispose(){}}}
if(capture.ok)stopWaiting()
return capture.ok}
const onTap=()=>{tryInstall()}
let waiting=false
function startWaiting(){if(waiting||!doc?.addEventListener)return
waiting=true
doc.addEventListener('pointerdown',onTap,true)}
function stopWaiting(){if(!waiting)return
waiting=false
doc.removeEventListener?.('pointerdown',onTap,true)}
const offMeasured=onMeasured(()=>{if(last&&last.root?.isConnected!==false)try{paint(last)}catch(err){onError(err)}})
function show(shown){shows+=1
if(!shown?.root){lastResult={ok:false,reason:'no-window'}
return}
if(!isActive(PACK_PEEK_FEATURE)){drop(shown.root)
last=null
lastResult={ok:false,reason:'inactive'}
return}
last=shown
paint(shown)
const options={doc,t,isActive,itemOf:itemOfRow(shown),priceOf:priceOf??undefined,surfaces:[PACK_PEEK_SURFACE]}
const asks=[]
for(const row of shown.rows){try{asks.push(warm(row.item))}catch(err){onError(err)}}
Promise.allSettled(asks).then(()=>{if(last!==shown||shown.root?.isConnected===false)return
paint(shown)
badges(options)}).catch(onError)}
function itemOfRow(shown){const map=new Map(shown.rows.map((one)=>[one.root,one.item]))
return(row)=>map.get(row)??null}
function paint(shown){const sums=peekSums(shown.rows,{priceOf:priceOfItem,packTradable:shown.pack?.tradable??null,coins:shown.pack?.coins??null})
if(sums.cards===0){drop(shown.root)
lastResult={ok:false,reason:'empty',sums}
return}
ensureControls(doc)
ensureStylesheet(doc,STYLESHEET,LINK_ID)
const block=ensureBlock(shown)
if(!block){lastResult={ok:false,reason:'no-place',sums}
return}
render(block,sums,shown.pack)
lastResult={ok:true,reason:null,sums}}
function ensureBlock(shown){const{root,list}=shown
const existing=root.querySelector?.(`[${PACK_PEEK_MARK}]`)??null
if(existing){if(existing.nextSibling!==list&&list?.parentNode)list.parentNode.insertBefore(existing,list)
return existing}
if(!list?.parentNode)return null
const block=el(doc,'div',{class:'fx-bar fut-peek',dataset:{futPackPeek:'1'}})
list.parentNode.insertBefore(block,list)
return block}
function render(block,sums,pack){
const said=peekVerdictWords(sums,t,formatCoins)
const tone=said.tone
const word=said.word
const approx=said.approx
const stamp=[pack?.id,tone,word,approx,sums.coins,sums.market,sums.net,sums.quick,sums.unpriced,sums.untradeable,sums.priced].join('|')
writeDiagnostics(block,sums,pack)
if(block.dataset?.futPeekStamp===stamp)return
if(block.dataset)block.dataset.futPeekStamp=stamp
clear(block)
const verdict=el(doc,'span',{class:'fut-peek-verdict',dataset:{futPeekTone:tone},text:approx?`${t('packPeek.approx')} ${word}`:word})
if(said.title!=='')verdict.setAttribute('title',said.title)
const price=sums.coins===null?null:el(doc,'span',{class:'fut-peek-price'},[el(doc,'span',{class:'fut-peek-k',text:t('packPeek.price')}),el(doc,'b',{class:'fut-peek-coins',text:formatCoins(sums.coins)})])
block.appendChild(el(doc,'div',{class:'fut-peek-row1'},[logoLink(doc,'fut-peek-logo'),verdict,price]))
const cells=[]
if(sums.priced>0){cells.push(cell('packPeek.market',sums.market))
cells.push(cell('packPeek.net',sums.net))}
cells.push(cell('packPeek.quick',sums.quick))
if(sums.unpriced>0)cells.push(chip(t('packPeek.noPrice',{count:sums.unpriced}),t('packPeek.noPrice.title',{count:sums.unpriced})))
if(sums.untradeable>0)cells.push(chip(t('packPeek.untradeable',{count:sums.untradeable}),t('packPeek.untradeable.title',{count:sums.untradeable})))
block.appendChild(el(doc,'div',{class:'fut-peek-row2'},cells))}
function cell(key,value){return el(doc,'span',{class:'fut-peek-cell'},[el(doc,'span',{class:'fut-peek-k',text:t(key)}),el(doc,'b',{class:'fut-peek-coins',text:formatCoins(value)})])}
function chip(text,title){return el(doc,'span',{class:'fut-peek-chip',text,attrs:{title}})}
function writeDiagnostics(block,sums,pack){if(!block?.dataset)return
const put={futPeekPack:pack?.id??'',futPeekCards:sums.cards,futPeekMarket:sums.market,futPeekNet:sums.net,futPeekQuick:sums.quick,
futPeekWorth:sums.worth,futPeekCoins:sums.coins??'',futPeekVerdict:sums.verdict??'',futPeekUnpriced:sums.unpriced,
futPeekUntradeable:sums.untradeable,futPeekApprox:sums.approx?'1':'0'}
for(const[key,value]of Object.entries(put)){const text=String(value)
if(block.dataset[key]!==text)block.dataset[key]=text}}
function drop(root){root?.querySelector?.(`[${PACK_PEEK_MARK}]`)?.remove?.()}
if(!tryInstall())startWaiting()
return{PACK_PEEK_FEATURE,
state:()=>({active:isActive(PACK_PEEK_FEATURE),capture:capture.ok,reason:capture.reason,shows,lastResult,
open:Boolean(last&&last.root?.isConnected!==false)}),
dispose(){stopWaiting()
offMeasured()
if(last)drop(last.root)
last=null
capture.dispose()
capture={ok:false,reason:'disposed',dispose(){}}}}}
