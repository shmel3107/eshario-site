import{netAfterTax} from './tax.js'
import{peekItemFacts} from '../adapter/pack-peek.js'
export function peekSums(rows,opts={}){const priceOf=typeof opts.priceOf==='function'?opts.priceOf:()=>null
const packTradable=typeof opts.packTradable==='boolean'?opts.packTradable:null
const coins=Number.isFinite(opts.coins)&&opts.coins>0?opts.coins:null
const out={cards:0,market:0,net:0,quick:0,worth:0,coins,verdict:null,approx:false,priced:0,unpriced:0,untradeable:0,quickMissing:0}
for(const row of Array.isArray(rows)?rows:[]){const item=row?.item
if(!item)continue
const facts=peekItemFacts(item)
out.cards+=1
const quick=facts.quick
if(quick===null)out.quickMissing+=1
else out.quick+=quick
const sellable=(facts.tradable??packTradable)===true
if(!sellable){out.untradeable+=1
out.worth+=quick??0
continue}
let price=null
try{price=priceOf(item)}catch{price=null}
if(!Number.isFinite(price)||price<=0){out.unpriced+=1
out.worth+=quick??0
continue}
const net=netAfterTax(price)
out.priced+=1
out.market+=Math.round(price)
out.net+=net
out.worth+=Math.max(net,quick??0)}
out.approx=out.unpriced>0||out.quickMissing>0
out.verdict=coins===null||out.cards===0?null:Math.round(out.worth-coins)
return out}
export const PREVIEW_RISK_SHARE=0.2
export function verdictKind(sums){const verdict=sums?.verdict
const coins=sums?.coins
if(!Number.isFinite(verdict)||!Number.isFinite(coins)||coins<=0)return null
if(verdict>=0)return'buy'
return-verdict<=coins*PREVIEW_RISK_SHARE?'risk':'skip'}
export function overpayPercent(sums){const verdict=sums?.verdict
const coins=sums?.coins
if(!Number.isFinite(verdict)||!Number.isFinite(coins)||coins<=0||verdict>=0)return 0
return Math.round(-verdict/coins*100)}
const VERDICT_KEYS=Object.freeze({buy:'packPeek.verdict.buy',risk:'packPeek.verdict.risk',skip:'packPeek.verdict.skip'})
export function peekVerdictWords(sums,t,formatCoins){const kind=verdictKind(sums)
if(kind===null)return{kind,tone:'none',word:t('packPeek.noCoins'),approx:false,title:''}
const tone=kind==='buy'?'good':kind==='risk'?'risk':'bad'
const value=(sums.verdict>=0?'+':'−')+formatCoins(Math.abs(sums.verdict))
const word=t(VERDICT_KEYS[kind],{value})
const percent=overpayPercent(sums)
const why=kind==='buy'?t('packPeek.verdict.buy.title',{value:formatCoins(sums.verdict)})
:kind==='risk'?t('packPeek.verdict.risk.title',{value:formatCoins(-sums.verdict),price:formatCoins(sums.coins),percent,limit:Math.round(PREVIEW_RISK_SHARE*100)})
:t('packPeek.verdict.skip.title',{value:formatCoins(-sums.verdict),percent})
const approx=sums.approx===true
return{kind,tone,word,approx,title:approx?why+'. '+t('packPeek.approx.title'):why}}
