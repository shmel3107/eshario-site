import{cardLockedNow} from './card-locks.js'
const arr=Array.isArray
const int=Number.isSafeInteger
const dirs=['club','transfer','storage']
const bad=(reason)=>({ok:false,reason})
const stale=(s)=>s?.loaded!==true||!arr(s.items)
export function invalidateUnassignedRecovery(s){if(!s||typeof s!=='object'||arr(s))return false
Object.assign(s,{count:0,keep:0,club:0,transfer:0,storage:0,review:null,discardPreview:null,loaded:false,items:[]})
return true}
export function allowedUnassignedDispositions(item){const r=['keep']
if(item?.movable===true)r.push('club')
if(item?.tradeableDuplicate===true)r.push('transfer')
if(item?.storable===true&&item?.untradeableDuplicate===true)r.push('storage')
return r}
export function parseDiscardAllowlist(raw){if(typeof raw!=='string')return null
if(raw==='')return[]
const parts=raw.split(',').map((x)=>x.trim())
if(parts.some((x)=>!x||!/^[1-9]\d*$/.test(x)))return null
const ids=parts.map(Number)
return ids.every(int)&&new Set(ids).size===ids.length?ids:null}
export function previewUnassignedDiscard(s,raw){if(s&&typeof s==='object')s.discardPreview=null
if(stale(s))return bad('stale')
const allow=parseDiscardAllowlist(raw)
if(!allow)return bad('invalid')
if(!allow.length)return bad('policy-disabled')
const picked=s.items.filter((x)=>allow.includes(x.definitionId)
&&x.discardable===true&&x.duplicateLoan===false)
const items=picked.filter((x)=>cardLockedNow(x.id)===false).map((x)=>Object.freeze({index:x.index,id:x.id,definitionId:x.definitionId,discardValue:x.discardValue}))
const preview=Object.freeze({ok:true,reason:null,count:items.length,value:items.reduce((n,x)=>n+x.discardValue,0),locked:picked.length-items.length,allowlist:Object.freeze(allow),items:Object.freeze(items)})
s.discardPreview=preview
return preview}
function recount(s){s.keep=s.club=s.transfer=s.storage=0
for(const item of s.items)s[item.disposition]+=1}
export function setUnassignedDisposition(s,index,disposition){if(stale(s))return bad('stale')
if(!int(index)||index<0||typeof disposition!=='string'){return bad('invalid')}
const matches=s.items.filter((item)=>item?.index===index)
if(matches.length!==1)return bad('invalid')
if(!allowedUnassignedDispositions(matches[0]).includes(disposition)){return bad('incompatible')}
matches[0].disposition=disposition
recount(s)
s.review=null
return{ok:true,reason:null}}
export function resetUnassignedDispositions(s){if(stale(s))return bad('stale')
for(const item of s.items)item.disposition='keep'
recount(s)
s.review=null
return{ok:true,reason:null}}
export function recoveryPolicy(s){if(stale(s))return bad('stale')
for(const i of s.items){const d=i?.duplicate,t=i?.tradeableDuplicate,u=i?.untradeableDuplicate
i.disposition=d===true&&t===true&&u===false?'transfer'
:d===true&&t===false&&u===true&&i.storable===true?'storage'
:d===false&&t===false&&u===false&&i.movable===true?'club':'keep'
}
recount(s)
s.review=null
return{ok:true,reason:null}}
export function reviewUnassignedRecovery(adapter,s){if(stale(s))return bad('stale')
const plan={club:[],transfer:[],storage:[]}
for(const item of s.items){if(item?.disposition==='keep')continue
if(!plan[item?.disposition])return bad('incompatible')
plan[item.disposition].push(item.index)}
s.review=typeof adapter?.reviewUnassignedPlan==='function'
?adapter.reviewUnassignedPlan(plan):bad('guard-unavailable')
return s.review}
export async function runRecoveryStep({adapter:a,state:s,destination:d,confirmed}={}){if(confirmed!==true)return bad('not-confirmed')
if(s?.review?.ok!==true||!arr(s.items))return bad('not-reviewed')
if(!dirs.includes(d))return bad('invalid')
if(typeof a?.moveUnassigned!=='function')return bad('guard-unavailable')
const e=s.items.filter((i)=>i?.disposition===d).map((i)=>[i.index,i.id])
if(!e.length)return bad('invalid')
let sent=false
try{const read=await refreshUnassignedRecovery(a,s)
if(!read.ok)return read
for(const[i,id]of e){if(s.items[i]?.id!==id||!setUnassignedDisposition(s,i,d).ok)return bad('stale')}
const review=reviewUnassignedRecovery(a,s)
if(!review.ok)return review
sent=true
const result=await a.moveUnassigned(d,e.map(([i])=>i))
if(!result.ok){if(result.reason==='uncertain')invalidateUnassignedRecovery(s)
return result}
try{await refreshUnassignedRecovery(a,s)
if(s.count>0){recoveryPolicy(s)
reviewUnassignedRecovery(a,s)}}catch{invalidateUnassignedRecovery(s)}
return result}catch{const result=bad(sent?'uncertain':'unknown-state')
invalidateUnassignedRecovery(s)
return result}}
export async function runDiscardStep({adapter:a,state:s,confirmed}={}){if(confirmed!==true)return bad('not-confirmed')
const p=s?.discardPreview
if(p?.ok!==true||!Object.isFrozen(p)||!arr(p.items)||!p.items.length
||p.count!==p.items.length||!arr(p.allowlist)||!Object.isFrozen(p.items)
||!Object.isFrozen(p.allowlist)||p.items.some((x)=>!Object.isFrozen(x))){return bad('not-reviewed')}
s.discardPreview=null
if(typeof a?.discardUnassigned!=='function')return bad('guard-unavailable')
let sent=false
try{const read=await refreshUnassignedRecovery(a,s)
if(!read.ok)return read
sent=true
const result=await a.discardUnassigned(p.items,p.allowlist)
if(!result.ok||result.count!==p.count){invalidateUnassignedRecovery(s)
return result.ok?bad('uncertain'):result}
const post=await refreshUnassignedRecovery(a,s)
if(!post.ok||p.items.some((x)=>s.items.some((y)=>y.id===x.id))){invalidateUnassignedRecovery(s)
return bad('uncertain')}
return{...result,value:p.value}}catch{invalidateUnassignedRecovery(s)
return bad(sent?'uncertain':'unknown-state')}}
export async function refreshUnassignedRecovery(adapter,s){if(!invalidateUnassignedRecovery(s))return bad('invalid')
if(typeof adapter?.unassigned!=='function'){return bad('guard-unavailable')}
const result=await adapter.unassigned()
if(!int(result?.count)||result.count<0
||!arr(result.items)||result.items.length!==result.count
||result.items.some((item)=>!int(item?.index)||item.index<0)
||new Set(result.items.map((item)=>item.index)).size!==result.items.length){throw new Error('unassigned recovery: unknown adapter shape')}
s.items=result.items.map((item)=>({...item,disposition:'keep'}))
s.count=result.count
recount(s)
s.loaded=true
return{ok:true,count:result.count,keep:result.count}}
