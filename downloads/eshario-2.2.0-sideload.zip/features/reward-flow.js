import{SBC_FEATURE} from './sbc-actions.js'
export const REWARD_FLOW_FEATURE=SBC_FEATURE
export const REWARD_PRESS_FRAMES=2
export const REWARD_STALE_MS=1500
export function rewardLine(facts,t){const say=typeof t==='function'?t:(key)=>key
if(!facts||typeof facts!=='object')return say('rewardFlow.unknown')
const parts=[]
const coins=num(facts.coins)
const packs=num(facts.packs)
const cards=num(facts.cards)
if(coins>0)parts.push(say('rewardFlow.coins',{coins}))
if(packs>0)parts.push(say('rewardFlow.packs',{count:packs}))
if(cards===1&&typeof facts.names?.[0]==='string'&&facts.names[0]!=='')parts.push(say('rewardFlow.card',{name:facts.names[0]}))
else if(cards>0)parts.push(say('rewardFlow.cards',{count:cards}))
if(num(facts.xp)>0)parts.push(say('rewardFlow.xp'))
if(num(facts.other)>0)parts.push(say('rewardFlow.other',{count:num(facts.other)}))
if(num(facts.unreadable)>0)parts.push(say('rewardFlow.unreadable',{count:num(facts.unreadable)}))
return parts.length===0?say('rewardFlow.unknown'):parts.join(' · ')}
function num(value){const n=Number(value)
return Number.isFinite(n)&&n>0?n:0}
export function createRewardFlow(deps={}){const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const t=typeof deps.t==='function'?deps.t:(key)=>key
const frame=typeof deps.frame==='function'?deps.frame:null
const now=typeof deps.now==='function'?deps.now:null
const say=typeof deps.say==='function'?deps.say:()=>{}
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const counts={seen:0,locked:0,notShown:0,noFrame:0,byHand:0,stale:0,closed:0,failed:0}
let last=null
const activeNow=()=>{try{return isActive(REWARD_FLOW_FEATURE)===true}catch(err){onError(err)
return null}}
function appeared(shown){counts.seen+=1
if(activeNow()!==true){counts.locked+=1
return{ok:false,reason:'locked'}}
if(shown?.ready!==true){counts.notShown+=1
return{ok:false,reason:'not-shown'}}
if(frame===null){counts.noFrame+=1
return{ok:false,reason:'no-frame'}}
const shownAt=now===null?null:safeNow()
let waited=0
const step=()=>{try{waited+=1
if(waited<REWARD_PRESS_FRAMES){frame(step)
return}
if(shown.closed()===true){counts.byHand+=1
last={ok:false,reason:'by-hand',source:shown.source,rewards:shown.rewards}
return}
if(shownAt!==null&&safeNow()-shownAt>REWARD_STALE_MS){counts.stale+=1
last={ok:false,reason:'stale',source:shown.source,rewards:shown.rewards}
return}
const result=shown.press()
if(result?.ok!==true){counts.failed+=1
last={ok:false,reason:result?.reason??'failed',source:shown.source,rewards:shown.rewards}
return}
counts.closed+=1
last={ok:true,reason:null,source:shown.source,rewards:shown.rewards}
say('rewardFlow.claimed',{parts:rewardLine(shown.rewards,t)})}catch(err){onError(err)
counts.failed+=1
last={ok:false,reason:'failed',source:shown?.source??null,rewards:shown?.rewards??null}}}
frame(step)
return{ok:true,reason:null}}
function safeNow(){try{const value=now()
return Number.isFinite(value)?value:0}catch(err){onError(err)
return 0}}
return{appeared,
state:()=>({active:activeNow(),rule:{frames:REWARD_PRESS_FRAMES,staleMs:REWARD_STALE_MS,feature:REWARD_FLOW_FEATURE},
counts:{...counts},last:last===null?null:{...last,rewards:last.rewards===null?null:{...last.rewards}}}),
dispose(){last=null}}}
