import{createCachedProvider} from '../core/storage-provider.js'
export const PREVIEW_MEMORY_KEY='preview.packs'
export const PREVIEW_MEMORY_MAX_PACKS=24
export const PREVIEW_MEMORY_MAX_ITEMS=60
const whole=(value)=>Number.isSafeInteger(value)&&value>0
export function previewStamp(preview){const expires=preview?.expiresAt
const cover=preview?.best?.definitionId
if(!whole(expires)||!whole(cover))return null
return{expires,cover}}
function packItem(row){if(!Array.isArray(row)||row.length!==3)return null
const[def,quick,tradable]=row
if(!whole(def))return null
if(!(Number.isSafeInteger(quick)&&quick>=0)&&quick!==-1)return null
if(tradable!==1&&tradable!==0&&tradable!==-1)return null
return[def,quick,tradable]}
export function sanitizePreviewMemory(stored){const out={packs:{}}
const packs=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored.packs:null
if(!packs||typeof packs!=='object'||Array.isArray(packs))return out
let kept=0
for(const[key,entry]of Object.entries(packs)){if(kept>=PREVIEW_MEMORY_MAX_PACKS)break
if(!/^\d{1,12}$/.test(key)||!entry||typeof entry!=='object')continue
if(!whole(entry.expires)||!whole(entry.cover)||!Array.isArray(entry.items))continue
if(entry.items.length===0||entry.items.length>PREVIEW_MEMORY_MAX_ITEMS)continue
const items=entry.items.map(packItem)
if(items.some((one)=>one===null))continue
out.packs[key]={expires:entry.expires,cover:entry.cover,items}
kept+=1}
return out}
export function recallPreview(memory,packId,preview,nowSec){const stamp=previewStamp(preview)
if(stamp===null||!Number.isFinite(nowSec)||nowSec>=stamp.expires)return null
const entry=memory?.packs?.[String(packId)]
if(!entry||entry.expires!==stamp.expires||entry.cover!==stamp.cover)return null
if(!entry.items.some((row)=>row[0]===stamp.cover))return null
return entry.items.map(([def,quick,tradable])=>{const item={definitionId:def}
if(quick>=0)item.discardValue=quick
if(tradable!==-1)item.tradable=tradable===1
return item})}
export function rememberPreview(memory,packId,preview,nowSec,defOf){const base=sanitizePreviewMemory(memory)
const stamp=previewStamp(preview)
const items=Array.isArray(preview?.items)?preview.items:[]
if(stamp===null||!Number.isSafeInteger(packId)||packId<0||items.length===0||items.length>PREVIEW_MEMORY_MAX_ITEMS||!Number.isFinite(nowSec)||nowSec>=stamp.expires)return{memory:base,changed:false}
const rows=[]
for(const item of items){const def=defOf(item)
if(!whole(def))return{memory:base,changed:false}
const quick=Number(item?.discardValue)
rows.push([def,Number.isFinite(quick)&&quick>=0?Math.round(quick):-1,item?.tradable===true?1:item?.tradable===false?0:-1])}
const key=String(packId)
const next={packs:{}}
let changed=false
for(const[one,entry]of Object.entries(base.packs)){if(one===key)continue
if(entry.expires<=nowSec){changed=true
continue}
next.packs[one]=entry}
const had=base.packs[key]
const entry={expires:stamp.expires,cover:stamp.cover,items:rows}
if(!had||JSON.stringify(had)!==JSON.stringify(entry))changed=true
next.packs[key]=entry
const keys=Object.keys(next.packs)
if(keys.length>PREVIEW_MEMORY_MAX_PACKS){keys.sort((a,b)=>next.packs[a].expires-next.packs[b].expires)
for(const one of keys.slice(0,keys.length-PREVIEW_MEMORY_MAX_PACKS)){if(one!==key){delete next.packs[one]
changed=true}}}
return{memory:next,changed}}
export function createPreviewMemory(deps={}){const storage=deps.storage??null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const provider=createCachedProvider({fetch:()=>storage?.read?.()??null,push:(value)=>storage?.write?.(value),
sanitize:sanitizePreviewMemory,fallback:()=>({packs:{}}),onError:(stage,err)=>onError(err??stage)})
let loaded=false
return{
load:()=>provider.load().then(()=>{loaded=provider.isLoaded()
return loaded},(err)=>{onError(err)
return false}),
recall:(packId,preview,nowSec)=>loaded?recallPreview(provider.read(),packId,preview,nowSec):null,
remember:(packId,preview,nowSec,defOf)=>{if(!loaded)return false
const{memory,changed}=rememberPreview(provider.read(),packId,preview,nowSec,defOf)
if(changed)void provider.write(memory)
return changed},
state:()=>({loaded,packs:Object.keys(provider.read().packs).length})}}
