import{normalizePrice} from './price-source.js'
import{seasonOf} from '../adapter/season.js'
export const FUTGG_CDN='https://r2.fut.gg'
export const DEFAULT_GAME=27
export function currentGame(){return seasonOf()??DEFAULT_GAME}
export const PLATFORMS=Object.freeze(['ps5','pc'])
export const MANIFEST_TTL_MS=60_000
export const REFRESH_BACKOFF_MS=30_000
export const CARD_SOURCE=Object.freeze({MARKET:0,SBC:1,OBJECTIVE:2})
export const UNTRADABLE_SOURCES=Object.freeze([CARD_SOURCE.OBJECTIVE,3])
export function isUntradableSource(value){return UNTRADABLE_SOURCES.includes(value)}
const TOKEN_RE=/^[A-Za-z0-9_-]+$/
const KEY_RE=/^futgg:(\d+):(ps5|pc):(\d+)$/
export function manifestUrl(game){return `${FUTGG_CDN}/${normalizeGame(game)}/manifest.json`
}
export function priceIndexUrl(manifest,game){return blobUrl(manifest,'player-prices-index',game)}
export function futggBlobUrl(manifest,name,game){return typeof name==='string'?blobUrl(manifest,name,game):null}
export function priceBlobUrl(manifest,platform,game){const normalized=normalizePlatform(platform)
return normalized
?blobUrl(manifest,`player-prices-${normalized}-dyn`,game)
:null}
export function priceFullBlobUrl(manifest,platform,game){const normalized=normalizePlatform(platform)
return normalized
?blobUrl(manifest,`player-prices-${normalized}`,game)
:null}
export function priceCacheKey(eaId,options={}){const id=normalizeEaId(eaId)
const platform=normalizePlatform(options.platform)
if(id===null||platform===null)return null
return `futgg:${normalizeGame(options.game)}:${platform}:${id}`
}
export function eaIdFromKey(key){if(typeof key==='number') return normalizeEaId(key)
const match=typeof key==='string'?KEY_RE.exec(key.trim()):null
return match?normalizeEaId(match[3]):null}
export function createFutggSource(options={}){const fetchImpl=options.fetch
if(typeof fetchImpl!=='function') throw new Error('futgg: нужен fetch')
const ttl=Number.isFinite(options.manifestTtlMs)&&options.manifestTtlMs>0
?options.manifestTtlMs
:MANIFEST_TTL_MS
const bundles=new Map()
const inFlight=new Map()
const backoffUntil=new Map()
const bundleFor=async(game,platform)=>{const key=`${game}:${platform}`
const now=typeof options.clock?.now==='function'?options.clock.now():null
const cached=bundles.get(key)
if(cached&&(now===null||now-cached.at<ttl))return cached.data
if(cached){
if(now===null||now>=(backoffUntil.get(key)??0))load(key,game,platform,now,cached).catch(()=>{})
return cached.data}
return load(key,game,platform,now,null)}
const load=(key,game,platform,now,cached)=>{const running=inFlight.get(key)
if(running)return running
const work=(async()=>{const manifest=(await requestJson(fetchImpl,manifestUrl(game))).data;
const fullUrl=priceFullBlobUrl(manifest,platform,game);
const indexUrl=fullUrl?null:priceIndexUrl(manifest,game);
const pricesUrl=fullUrl??priceBlobUrl(manifest,platform,game);
if(!pricesUrl||(!fullUrl&&!indexUrl)) throw failure('bad-manifest');
if(cached&&cached.indexUrl===indexUrl&&cached.pricesUrl===pricesUrl){bundles.set(key,{...cached,at:now??0});
return cached.data}
let index,prices;
if(fullUrl){prices=await requestJson(fetchImpl,fullUrl);
index=prices}
else[index,prices]=await Promise.all([requestJson(fetchImpl,indexUrl),requestJson(fetchImpl,pricesUrl)]);
const data=buildBundle(index.data,prices.data);
bundles.set(key,{at:now??0,data,indexUrl,pricesUrl,publishedAt:prices.modified});
return data})()
const guarded=work.then((data)=>{backoffUntil.delete(key)
if(inFlight.get(key)===guarded)inFlight.delete(key)
return data},(err)=>{if(now!==null)backoffUntil.set(key,now+REFRESH_BACKOFF_MS)
if(inFlight.get(key)===guarded)inFlight.delete(key)
throw err})
inFlight.set(key,guarded)
return guarded}
const sourceOf=(key)=>{const parsed=parseSourceKey(key,options)
if(!parsed)return null
const cached=bundles.get(`${parsed.game}:${parsed.platform}`)
const slot=cached?.data?.index?.get(parsed.id)
if(slot===undefined)return null
const value=cached.data.sources?.[slot]
return Number.isSafeInteger(value)?value:null}
const publishedAt=()=>{const rawPlatform=typeof options.platform==='function'?options.platform():options.platform
const platform=normalizePlatform(rawPlatform)
if(platform===null)return null
const cached=bundles.get(`${normalizeGame(options.game)}:${platform}`)
const at=cached?.publishedAt
if(!Number.isFinite(at))return null
const now=typeof options.clock?.now==='function'?options.clock.now():null
return{at,ageMs:now===null?null:now-at}}
const rawWindow=(key,radius=4)=>{const parsed=parseSourceKey(key,options)
if(!parsed)return null
const entry=bundles.get(`${parsed.game}:${parsed.platform}`)
const data=entry?.data
if(!data||!Array.isArray(data.deltas))return null
const slot=data.index.get(parsed.id)
if(slot===undefined)return null
const span=Number.isSafeInteger(radius)&&radius>=0?radius:4
const lo=Math.max(0,slot-span)
const hi=Math.min(data.prices.length-1,slot+span)
const rows=[]
let id=data.id0
for(let i=0;i<=hi;i+=1){if(i>0)id+=data.deltas[i-1]
if(i>=lo)rows.push({slot:i,id,p:data.prices[i]??null,s:data.sources[i]??null})}
const now=typeof options.clock?.now==='function'?options.clock.now():null
const at=Number.isFinite(entry.publishedAt)?entry.publishedAt:null
return{id:parsed.id,slot,window:rows,
lengths:{ids:data.deltas.length+1,prices:data.prices.length,sources:data.sources.length},
file:{prices:entry.pricesUrl,index:entry.indexUrl,at,ageMs:at===null||now===null?null:now-at}}}
const crossCheck=async(key)=>{const parsed=parseSourceKey(key,options)
if(!parsed)return{ok:false,price:null,reason:'bad-key'}
try{const manifest=(await requestJson(fetchImpl,manifestUrl(parsed.game))).data
const indexUrl=priceIndexUrl(manifest,parsed.game)
const dynUrl=priceBlobUrl(manifest,parsed.platform,parsed.game)
if(!indexUrl||!dynUrl)return{ok:false,price:null,reason:'bad-manifest'}
const[index,prices]=await Promise.all([requestJson(fetchImpl,indexUrl),requestJson(fetchImpl,dynUrl)])
const pair=buildBundle(index.data,prices.data)
const slot=pair.index.get(parsed.id)
return{ok:true,id:parsed.id,url:dynUrl,at:prices.modified,
slot:slot===undefined?null:slot,
price:slot===undefined?null:(pair.prices[slot]??null),
s:slot===undefined?null:(pair.sources[slot]??null),
lengths:{ids:pair.deltas.length+1,prices:pair.prices.length},
reason:slot===undefined?'no-slot':null}}catch(err){return{ok:false,price:null,reason:err?.sourceReason??'network'}}}
return Object.assign(async function futggSource(key){const parsed=parseSourceKey(key,options)
if(!parsed) return fail('bad-key')
try{const bundle=await bundleFor(parsed.game,parsed.platform)
const slot=bundle.index.get(parsed.id)
if(slot===undefined)return noPrice()
const raw=bundle.prices[slot]
if(raw===null||raw===0)return noPrice()
const price=normalizePrice(raw)
return price===null?fail('bad-price'):found(price)}catch(err){return fail(err?.sourceReason??'network')}},{sourceOf,publishedAt,rawWindow,crossCheck})}
export function normalizeEaId(value){const n=typeof value==='string'&&/^\d+$/.test(value.trim())
?Number(value.trim())
:value
return Number.isSafeInteger(n)&&n>0?n:null}
export function normalizePlatform(value){if(typeof value!=='string') return null
const platform=value.trim().toLowerCase()
return PLATFORMS.includes(platform)?platform:null}
function normalizeGame(value){return normalizeStrictPositiveInteger(value)??currentGame()}
function normalizeStrictPositiveInteger(value){const n=typeof value==='string'&&/^\d+$/.test(value.trim())
?Number(value.trim())
:value
return Number.isSafeInteger(n)&&n>0?n:null}
function modifiedMs(value){if(typeof value!=='string')return null
const at=Date.parse(value)
return Number.isFinite(at)&&at>0?at:null}
function blobUrl(manifest,name,game){if(!plainObject(manifest))return null
const version=manifest._version
const hash=manifest[name]
if(!Number.isSafeInteger(version)||version<=0)return null
if(typeof hash!=='string'||!TOKEN_RE.test(hash)) return null
return `${FUTGG_CDN}/${normalizeGame(game)}/${name}.v${version}.${hash}.json`
}
function parseSourceKey(key,options){if(typeof key==='string'){const match=KEY_RE.exec(key.trim())
if(match){const game=normalizeStrictPositiveInteger(match[1])
const id=normalizeEaId(match[3])
if(game===null||id===null)return null
return{game,platform:match[2],id}}}
const id=normalizeEaId(key)
const rawPlatform=typeof options.platform==='function'
?options.platform()
:options.platform
const platform=normalizePlatform(rawPlatform)
return id===null||platform===null
?null
:{game:normalizeGame(options.game),platform,id}}
function buildBundle(index,prices){if(!plainObject(index)
||!Number.isSafeInteger(index.id0)
||index.id0<=0
||!Array.isArray(index.d)
||!index.d.every((delta)=>Number.isSafeInteger(delta)&&delta>0)) throw failure('bad-index')
if(!plainObject(prices)
||!Array.isArray(prices.p)
||!Array.isArray(prices.s)
||prices.p.length!==index.d.length+1
||prices.s.length!==prices.p.length) throw failure('bad-prices')
const slots=new Map([[index.id0,0]])
let id=index.id0
for(let i=0;i<index.d.length;i+=1){id+=index.d[i]
slots.set(id,i+1)}
return{index:slots,prices:prices.p,sources:prices.s,id0:index.id0,deltas:index.d}}
async function requestJson(fetchImpl,url){let response
try{response=await fetchImpl(url)}catch{throw failure('network')}
if(!response||typeof response.status!=='number') throw failure('bad-response')
if(response.status===403) throw failure('blocked')
if(response.status<200||response.status>=300){throw failure(`http-${response.status}`)}
const modified=modifiedMs(response.modified)
let data
try{data=await response.json()}catch{throw failure('bad-json')}
return{data,modified}}
function failure(reason){const error=new Error(reason)
error.sourceReason=reason
return error}
const plainObject=(value)=>Boolean(value&&typeof value==='object'&&!Array.isArray(value))
const found=(price)=>({ok:true,price,reason:null})
const noPrice=()=>({ok:true,price:null,reason:'no-price'})
const fail=(reason)=>({ok:false,price:null,reason})
