export const MARKET_RESULT_ID='fut-companion-market-result-summary'
export const MARKET_QUICK_MAX_PAGE=1000
export const BASE_DEFINITION_MAX=0xFFFFFF
export function baseNumberOf(value){const text=String(value??'').trim()
if(text===''||!/^[0-9]+$/.test(text))return null
const number=Number(text)
return Number.isSafeInteger(number)&&number>0&&number<=BASE_DEFINITION_MAX?number:null}
const integer=(value,min,max)=>{const text=String(value??'').trim()
if(text===''||!/^[0-9]+$/.test(text))return null
const number=Number(text)
return Number.isSafeInteger(number)&&number>=min&&number<=max?number:null}
export function parseMarketQuick(values={},dirty={}){const criteria={},invalid=[]
const read=(key,min,max,empty)=>{if(dirty[key]!==true)return undefined
const text=String(values[key]??'').trim()
if(text==='')return empty
const value=integer(text,min,max)
if(value===null)invalid.push(key)
return value}
const definitionId=read('definitionId',1,Number.MAX_SAFE_INTEGER,0)
const rarityId=read('rarityId',1,Number.MAX_SAFE_INTEGER,0)
const playStyle=read('playStyle',0,Number.MAX_SAFE_INTEGER,-1)
const page=read('page',1,MARKET_QUICK_MAX_PAGE,1)
if(definitionId!==undefined&&definitionId!==null)criteria.defId=definitionId===0?[]:[definitionId]
if(rarityId!==undefined&&rarityId!==null)criteria.rarities=rarityId===0?[]:[rarityId]
if(playStyle!==undefined&&playStyle!==null)criteria.playStyle=playStyle
return{ok:invalid.length===0,criteria,page:page??1,invalid}}
const FIELD_LABELS=Object.freeze({ovrMin:'marketField.rating',ovrMax:'marketField.rating',sort:'marketField.sort',sortBy:'marketField.sort',preferredPositionOnly:'marketField.position',excludeDefIds:'marketField.exclude',untradeables:'marketField.untradeable',
defId:'marketField.cards',zone:'marketField.zone'})
const capital=(text)=>text?text.charAt(0).toUpperCase()+text.slice(1):text
const labelList=(fields,t)=>{const out=[]
for(const field of fields??[]){const key=Object.hasOwn(FIELD_LABELS,field)?FIELD_LABELS[field]:'marketField.other'
const text=t(key)
if(!out.includes(text))out.push(text)}
return out.join(', ')}
export function mountMarketResultSummary({doc,root,t}){if(!doc||!root||typeof root.appendChild!=='function')return null
const existing=root.querySelector?.(`.${MARKET_RESULT_ID}`)
if(existing?.__esharioApi)return existing.__esharioApi
const node=doc.createElement('div');node.className=MARKET_RESULT_ID;node.hidden=true
Object.assign(node.style,{padding:'7px 10px',color:'var(--fx-ink)',background:'var(--fx-surface)'})
const summary=doc.createElement('span');summary.dataset.role='summary';node.appendChild(summary)
const dealsLine=doc.createElement('span');dealsLine.dataset.role='deals';dealsLine.hidden=true
const dealsGood=doc.createElement('span');dealsGood.dataset.role='dealsGood'
Object.assign(dealsGood.style,{color:'var(--fx-ok)'})
const dealsSep=doc.createElement('span');dealsSep.textContent=' · '
Object.assign(dealsSep.style,{color:'var(--fx-dim)'})
const dealsBad=doc.createElement('span');dealsBad.dataset.role='dealsBad'
Object.assign(dealsBad.style,{color:'var(--fx-danger)'})
const dealsLead=doc.createElement('span');dealsLead.textContent=' · '
Object.assign(dealsLead.style,{color:'var(--fx-dim)'})
dealsLine.appendChild(dealsLead);dealsLine.appendChild(dealsGood)
dealsLine.appendChild(dealsSep);dealsLine.appendChild(dealsBad)
node.appendChild(dealsLine)
const honest=doc.createElement('span');honest.dataset.role='honest';honest.hidden=true
Object.assign(honest.style,{display:'block',marginTop:'4px',color:'var(--fx-accent)'})
node.appendChild(honest)
if(typeof root.prepend==='function')root.prepend(node);else root.appendChild(node)
const money=(value)=>Number.isSafeInteger(value)&&value>0?String(value):t('marketResult.unknown')
let shown=null
let dealsShown=null
const renderDeals=()=>{const value=dealsShown
const seen=Number(value?.seen)
if(!value||!Number.isFinite(seen)||seen<=0){if(!dealsLine.hidden){dealsLine.hidden=true
node.dataset.dealsGood='';node.dataset.dealsBad=''}
return false}
const good=Number(value.good)||0,bad=Number(value.bad)||0
const goodText=t('deal.good',{count:good}),badText=t('deal.bad',{count:bad})
if(dealsGood.textContent!==goodText)dealsGood.textContent=goodText
if(dealsBad.textContent!==badText)dealsBad.textContent=badText
if(dealsLine.hidden)dealsLine.hidden=false
node.dataset.dealsGood=String(good);node.dataset.dealsBad=String(bad)
return true}
const api={update(value){if(!value||!Number.isSafeInteger(value.count)||!Number.isSafeInteger(value.page))return false
shown=value
summary.textContent=t('marketResult.summary',{count:value.count,min:money(value.minBuy),max:money(value.maxBuy),page:value.page})
const lines=[]
const local=value.honest?.local??[]
const dead=value.honest?.dead??[]
if(local.length>0)lines.push(capital(t('marketResult.checked',{fields:labelList(local,t),kept:value.honest.kept,seen:value.honest.seen})))
if(dead.length>0)lines.push(t('marketResult.ignored',{fields:labelList(dead,t)}))
honest.textContent=lines.join(' ')
honest.title=local.length>0?t('marketResult.checkedTip'):''
honest.hidden=lines.length===0
node.hidden=false
node.dataset.count=String(value.count);node.dataset.page=String(value.page)
node.dataset.localKept=local.length>0?String(value.honest.kept):''
return true},
deals(counts){dealsShown=counts&&typeof counts==='object'?{seen:Number(counts.seen)||0,good:Number(counts.good)||0,bad:Number(counts.bad)||0}:null
return renderDeals()},
relabel(){const done=shown===null?false:api.update(shown)
return renderDeals()||done},destroy(){node.remove?.()}}
node.__esharioApi=api
return api}
export function showMarketDeals({doc,counts}={}){let node=null
try{node=doc?.querySelector?.(`.${MARKET_RESULT_ID}`)??null}catch{node=null}
const api=node?.__esharioApi??null
if(typeof api?.deals!=='function')return false
try{api.deals(counts)}catch{return false}
return true}
