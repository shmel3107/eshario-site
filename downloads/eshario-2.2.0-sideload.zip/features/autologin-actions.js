import{runAutologin,createLandingTally,pressLanding,EMPTY_LANDING} from './autologin.js'
const AUTOLOGIN_FEATURE='autologin'
const IDLE_LANDING=EMPTY_LANDING
export function createLandingWatch(deps){const door=deps?.door??null
const isActive=deps?.isActive
const tally=createLandingTally()
let watching=true
const armed=()=>watching&&!tally.pressed()
const tick=()=>{if(!armed()||door===null)return null
if(typeof isActive!=='function'||!isActive(AUTOLOGIN_FEATURE))return null
const step=pressLanding(door)
tally.note(step)
if(step.pressed===true){try{door.remember?.(tally.report())}catch{/* памяти нет — числа просто не доедут */}}
return step}
return{tick,armed,
disarm(){watching=false},
report(){let previous=null
try{previous=door?.recall?.()??null}catch{previous=null}
return{...tally.report(),previous,armed:armed()}}}}
export async function startAutologin(deps){const{personas,clock,isActive,preferredId=null,landing=null}=deps
const seenSoFar=()=>landing===null?IDLE_LANDING:landing.report()
if(typeof isActive!=='function'||!isActive(AUTOLOGIN_FEATURE)){return{ok:false,reason:'switched-off',landing:seenSoFar()}}
if(!personas||typeof personas.listPersonas!=='function'){return{ok:false,reason:'no-adapter',landing:seenSoFar()}}
if(preferredId===null||preferredId===undefined){let selected=null
try{selected=personas.selectedPersona?.()??null} catch{/* нет — значит выбирать есть что */}
if(selected) return{ok:false,reason:'already-selected',persona:selected,landing:seenSoFar()}}
return runAutologin({listPersonas:()=>personas.listPersonas(),selectPersona:(persona)=>personas.selectPersona(persona),selectedPersona:()=>personas.selectedPersona?.()??null,clock,preferredId,attempts:deps.attempts,baseMs:deps.baseMs,maxMs:deps.maxMs,landing})}
