import{setFactsOf} from '../adapter/sbc-hub.js'
import{awaitLadderWarm} from './sbc-ladder-warm.js'
export const BACKGROUND_TIME_MS=15000
export const WARM_QUEUE_LIMIT=8
export function warmTargetsFrom(capture,opts={}){const has=typeof opts.has==='function'?opts.has:()=>false
const skipUnfinished=typeof opts.skip==='function'?opts.skip:()=>false
const limit=Number.isSafeInteger(opts.limit)&&opts.limit>0?opts.limit:WARM_QUEUE_LIMIT
const targets=[]
const skipped={notFavourite:0,noChallenges:0,noSquad:0,done:0,frozen:0,unfinished:0}
for(const tile of Array.isArray(capture?.tiles)?capture.tiles:[]){const set=tile?.set??null
if(!set)continue
let facts=null
try{facts=setFactsOf(set)}catch{facts=null}
if(facts?.favourite!==true){skipped.notFavourite+=1
continue}
let list=null
try{list=typeof set.getChallenges==='function'?set.getChallenges():null}catch{list=null}
if(!Array.isArray(list)||list.length===0){skipped.noChallenges+=1
continue}
for(const challenge of list){if(targets.length>=limit)break
let skip=null
try{if(challenge?.isCompleted?.()===true)skip='done'
else if(challenge?.isBrickChallenge?.()===true)skip='done'}catch{skip=null}
if(skip==='done'){skipped.done+=1
continue}
const squad=challenge?.squad??null
if(!squad||typeof squad!=='object'){skipped.noSquad+=1
continue}
const id=Number.isFinite(Number(challenge?.id))?String(Number(challenge.id)):null
if(id===null){skipped.noSquad+=1
continue}
if(has(id)){skipped.frozen+=1
continue}
if(skipUnfinished(id)){skipped.unfinished+=1
continue}
targets.push({setId:facts.id,setName:facts.name,challenge,challengeId:id,set})}
if(targets.length>=limit)break}
return{targets,skipped}}
export function createSbcWarm(deps={}){const frozen=deps.frozen??null
const solve=typeof deps.solve==='function'?deps.solve:null
const ladderWarm=deps.ladderWarm??null
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const win=deps.win??null
const doc=deps.doc??null
const limit=Number.isSafeInteger(deps.limit)&&deps.limit>0?deps.limit:WARM_QUEUE_LIMIT
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let queue=[]
let ticket=0
let running=false
const stats={done:0,failed:0,stopped:0,rounds:0,hides:0,hidesHot:0,skipped:{notFavourite:0,noChallenges:0,noSquad:0,done:0,frozen:0,unfinished:0},unfinished:0,unfinishedForgotten:0,stale:0,last:null,stoppedBy:null}
const unfinishedSkip=new Set
const epochNow=()=>{try{return typeof frozen?.epoch==='function'?Number(frozen.epoch()):0}catch{return 0}}
let skipEpoch=epochNow()
function forgetSkipsIfNewEpoch(){const now=epochNow()
if(now===skipEpoch)return false
skipEpoch=now
if(unfinishedSkip.size===0)return false
stats.unfinishedForgotten+=unfinishedSkip.size
unfinishedSkip.clear()
return true}
const visible=()=>{try{return doc?.hidden!==true}catch{return true}}
const pauseFor=(mine)=>{const frame=win?.requestAnimationFrame
if(typeof frame!=='function')return null
return()=>new Promise((resolve,reject)=>{if(mine!==ticket){reject(new Error('warm-stopped'))
return}
frame.call(win,()=>{if(mine===ticket&&visible())resolve()
else reject(new Error('warm-stopped'))})})}
function apply(capture){if(!solve||!frozen||!isActive())return false
forgetSkipsIfNewEpoch()
let built
try{built={targets:[],skipped:stats.skipped,...warmTargetsFrom(capture,{has:(id)=>frozen.has?.(id)===true,skip:(id)=>unfinishedSkip.has(String(id)),limit})}}catch(err){onError(err)
return false}
stats.skipped=built.skipped
queue=built.targets
stats.rounds+=1
if(queue.length===0)return false
start()
return true}
function start(){if(running||!visible())return false
running=true
ticket+=1
const mine=ticket
Promise.resolve(awaitLadderWarm(ladderWarm)).then(()=>step(mine)).catch((err)=>{running=false
onError(err)})
return true}
async function step(mine){while(mine===ticket&&queue.length>0){if(!isActive()||!visible()){stats.stoppedBy=visible()?'inactive':'hidden'
break}
const one=queue.shift()
if(!one)break
const born=epochNow()
try{const result=await solve(one.challenge,one.set,pauseFor(mine))
if(mine!==ticket)break
if(epochNow()!==born){stats.stale+=1
stats.last={challenge:one.challengeId,set:one.setName,ok:false,stale:true}
continue}
if(result?.search?.unfinished===true){unfinishedSkip.add(String(one.challengeId))
stats.unfinished+=1
stats.last={challenge:one.challengeId,set:one.setName,ok:false,unfinished:true}}
else if(result?.search){frozen.put(one.challengeId,{result,warn:null,squad:one.challenge?.squad??null,
mark:JSON.stringify([[],false,'club']),from:'warm'})
stats.done+=1
stats.last={challenge:one.challengeId,set:one.setName,ok:result?.ok===true}}
else{stats.failed+=1
stats.last={challenge:one.challengeId,set:one.setName,ok:false}}}
catch(err){if(mine!==ticket)break
stats.failed+=1
if(String(err?.message??'')!=='warm-stopped')onError(err)}}
if(mine===ticket)running=false}
function stopNow(why){if(queue.length===0&&!running)return false
ticket+=1
queue=[]
running=false
stats.stopped+=1
stats.stoppedBy=String(why)
return true}
const onVisibility=()=>{if(visible())return
stats.hides+=1
if(running)stats.hidesHot+=1
stopNow('hidden')}
if(typeof doc?.addEventListener==='function')doc.addEventListener('visibilitychange',onVisibility)
return{apply,
stop(why='human'){return stopNow(why)},
state(){return{queue:queue.length,done:stats.done,running,failed:stats.failed,stopped:stats.stopped,
rounds:stats.rounds,skipped:{...stats.skipped},last:stats.last,stoppedBy:stats.stoppedBy,
unfinished:stats.unfinished,unfinishedKept:unfinishedSkip.size,unfinishedForgotten:stats.unfinishedForgotten,stale:stats.stale,epoch:skipEpoch,
visible:visible(),hides:stats.hides,hidesHot:stats.hidesHot,budgetMs:BACKGROUND_TIME_MS}},
dispose(){if(typeof doc?.removeEventListener==='function')doc.removeEventListener('visibilitychange',onVisibility)
ticket+=1
queue=[]
running=false}}}
