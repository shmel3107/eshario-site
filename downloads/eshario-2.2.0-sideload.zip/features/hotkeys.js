export const NEED_ROW_X='list-row-x'
export const NEED_ENTER='list-enter'
export const NEED_TARGET='press-target'
export const NEED_NO_POPUP='no-popup'
const MODIFIER_ORDER=['ctrl','alt','shift','meta']
const MODIFIER_ALIASES=new Map([['ctrl','ctrl'],['control','ctrl'],['ctl','ctrl'],['alt','alt'],['option','alt'],['opt','alt'],['shift','shift'],['meta','meta'],['cmd','meta'],['command','meta'],['win','meta'],['super','meta']])
const KEY_ALIASES=new Map([['esc','escape'],['escape','escape'],['del','delete'],['delete','delete'],['ins','insert'],['insert','insert'],['space','space'],[' ','space'],['spacebar','space'],['enter','enter'],['return','enter'],['up','arrowup'],['down','arrowdown'],['left','arrowleft'],['right','arrowright'],['plus','+'],['minus','-']])
export const BROWSER_RESERVED=Object.freeze(['ctrl+t','ctrl+n','ctrl+w','ctrl+shift+t','ctrl+shift+n','ctrl+shift+w','ctrl+r','ctrl+shift+r','f5','ctrl+f5','ctrl+l','ctrl+d','ctrl+shift+d','ctrl+p','ctrl+j','ctrl+shift+j','ctrl+h','ctrl+shift+delete','ctrl+tab','ctrl+shift+tab','alt+f4','f11','f12','ctrl+shift+i','ctrl+shift+c','ctrl++','ctrl+-','ctrl+0'
])
export const BROWSER_TAKEN=Object.freeze({'ctrl+shift+a':'поиск по вкладкам','ctrl+shift+b':'панель закладок','ctrl+shift+g':'найти предыдущее','ctrl+shift+m':'переключение профиля','ctrl+shift+o':'диспетчер закладок','ctrl+shift+p':'ПЕЧАТЬ через системный диалог','ctrl+shift+u':'ввод символа по коду (IBus: Linux и ChromeOS)','ctrl+shift+v':'вставить без форматирования','ctrl+shift+q':'выход (macOS)'})
export const TAKEN_ACCEPTED=Object.freeze({})
export const FUSED_ROWS=Object.freeze([Object.freeze(['goBack','goBackEsc'])])
export const GROUPS=Object.freeze(['nav','card','unassigned','market','sbc','mine'])
export const groupOf=(meta)=>typeof meta?.group==='string'&&GROUPS.includes(meta.group)?meta.group:null
const GROUP_OF_LAYER=Object.freeze({market:'market',marketAny:'market',transferList:'market',targets:'market',unassigned:'unassigned',sbc:'sbc',challenge:'sbc'})
export const groupOfLayer=(layer)=>GROUP_OF_LAYER[layer]??'mine'
export const LAYERS=Object.freeze({global:'',market:'.ut-market-search-filters-view',transferList:'.ut-transfer-list-view',targets:'.ut-watch-list-view',unassigned:'.ut-unassigned-view',club:'.ut-club-hub-view',sbc:'.ut-sbc-hub-view,.ut-sbc-challenges-view,.ut-sbc-challenge-details-view,.SBCSquadPanel',challenge:'.SBCSquadPanel,.ut-sbc-challenge-details-view',store:'.ut-store-hub-view',
marketAny:'.ut-market-search-filters-view,.SearchResults'})
const SUBMIT_DOORS_SELECTOR='.sbc-button-container button.call-to-action, button.ut-squad-tab-button-control.actionTab.right'
export const ITEM_ROW_BUTTONS='.DetailPanel>.ut-button-group>button'
export const ITEM_REDEEM_BUTTON=`${ITEM_ROW_BUTTONS}:nth-child(3):nth-last-child(11)`
const BACK_BUTTON='.ut-navigation-bar-view button.ut-navigation-button-control'
const priceStep=(block,row,side)=>`.search-prices>.ut-market-search-filters-view--criteria-container:nth-child(${block})>.price-filter:nth-child(${row}) .${side}-value`
export const HOTKEY_NAV_FEATURE='hotkeyNav'
export const HOTKEY_NAV_ACTIONS=Object.freeze(['nextCard','prevCard','cardLeft','cardRight',
'pagePrev','pageNext','goBack','goBackEsc','openSbc'])
export const HOTKEY_ACTIONS=Object.freeze({
findMinBin:{labelKey:'hotkeys.action.findMinBin',group:'card',feature:'minBinSearch',defaultCombo:'v'},
lockCard:{labelKey:'hotkeys.action.lockCard',group:'card',feature:'sbcSolver',defaultCombo:'l',requireVisible:true,press:'[data-fut-card-lock]'},
freezeCard:{labelKey:'hotkeys.action.freezeCard',group:'card',feature:'enhancedTransferList',defaultCombo:'k'},
listForTransfer:{labelKey:'hotkeys.action.listForTransfer',group:'card',feature:'hotkeys',defaultCombo:'space',needs:NEED_TARGET,shadows:'listAtMin',pressScope:'document',requireVisible:true,press:'.ut-quick-list-panel-view .panelActions>.btn-standard.primary'},
listAtMin:{labelKey:'hotkeys.action.listAtMin',group:'card',feature:'autoSeller',defaultCombo:'',retired:true,},// СТРЕЛКИ ВВЕРХ-ВНИЗ — БЕСПЛАТНЫЕ (кирпич FREE-1). Они только ВОДЯТ метку
nextCard:{labelKey:'hotkeys.action.nextCard',group:'nav',feature:HOTKEY_NAV_FEATURE,defaultCombo:'arrowdown'},prevCard:{labelKey:'hotkeys.action.prevCard',group:'nav',feature:HOTKEY_NAV_FEATURE,defaultCombo:'arrowup'},
rowEnter:{labelKey:'hotkeys.action.rowEnter',group:'nav',feature:'hotkeys',defaultCombo:'enter',needs:NEED_ENTER},repeatSearch:{labelKey:'hotkeys.action.repeatSearch',group:'market',feature:'hotkeys',defaultCombo:'',retired:true,},// СЛОЙ ПО СМЫСЛУ: `3` ВНУТРИ ОТКРЫТОГО ИСПЫТАНИЯ ПОКАЗЫВАЕТ СОСТАВ НА ПОЛЕ.
showOnPitch:{labelKey:'hotkeys.action.showOnPitch',group:'sbc',feature:'sbcSolver',defaultCombo:'3',layer:'challenge',shadows:'openSbc',needs:NEED_TARGET,press:'[data-fut-sbc-show]'},
openSbc:{labelKey:'hotkeys.action.openSbc',group:'nav',feature:HOTKEY_NAV_FEATURE,defaultCombo:'',retired:true,},relistAll:{labelKey:'hotkeys.action.relistAll',group:'market',feature:'hotkeys',defaultCombo:'',retired:true,writes:true},
showKeys:{labelKey:'hotkeys.action.showKeys',group:'nav',feature:'hotkeys',defaultCombo:'',retired:true,},
minBidDown:{labelKey:'hotkeys.action.minBidDown',group:'market',feature:'hotkeys',defaultCombo:'z',layer:'market',press:priceStep(2,1,'decrement')},minBidUp:{labelKey:'hotkeys.action.minBidUp',group:'market',feature:'hotkeys',defaultCombo:'x',layer:'market',press:priceStep(2,1,'increment')},maxBidDown:{labelKey:'hotkeys.action.maxBidDown',group:'market',feature:'hotkeys',defaultCombo:'a',layer:'market',press:priceStep(2,2,'decrement')},maxBidUp:{labelKey:'hotkeys.action.maxBidUp',group:'market',feature:'hotkeys',defaultCombo:'s',layer:'market',press:priceStep(2,2,'increment')},minBuyDown:{labelKey:'hotkeys.action.minBuyDown',group:'market',feature:'hotkeys',defaultCombo:'q',layer:'market',press:priceStep(4,1,'decrement')},minBuyUp:{labelKey:'hotkeys.action.minBuyUp',group:'market',feature:'hotkeys',defaultCombo:'w',layer:'market',press:priceStep(4,1,'increment')},maxBuyDown:{labelKey:'hotkeys.action.maxBuyDown',group:'market',feature:'hotkeys',defaultCombo:'1',layer:'market',press:priceStep(4,2,'decrement')},maxBuyUp:{labelKey:'hotkeys.action.maxBuyUp',group:'market',feature:'hotkeys',defaultCombo:'2',layer:'market',press:priceStep(4,2,'increment')},
marketSearch:{labelKey:'hotkeys.action.marketSearch',group:'market',feature:'hotkeys',defaultCombo:'p',layer:'market',press:'.button-container .btn-standard.primary'},
cardLeft:{labelKey:'hotkeys.action.cardLeft',group:'nav',feature:HOTKEY_NAV_FEATURE,defaultCombo:'arrowleft',needs:NEED_ROW_X},cardRight:{labelKey:'hotkeys.action.cardRight',group:'nav',feature:HOTKEY_NAV_FEATURE,defaultCombo:'arrowright',needs:NEED_ROW_X},
pagePrev:{labelKey:'hotkeys.action.pagePrev',group:'nav',feature:HOTKEY_NAV_FEATURE,defaultCombo:'ctrl+arrowleft',requireVisible:true,press:'.pagingContainer .pagination.prev'},pageNext:{labelKey:'hotkeys.action.pageNext',group:'nav',feature:HOTKEY_NAV_FEATURE,defaultCombo:'ctrl+arrowright',requireVisible:true,press:'.pagingContainer .pagination.next'},// НАЗАД НЕ ЖМЁТ СПРЯТАННУЮ КНОПКУ (живой случай, шаг 18 2026-08-11: клавиша
goBack:{labelKey:'hotkeys.action.goBack',group:'nav',feature:HOTKEY_NAV_FEATURE,defaultCombo:'backspace',requireVisible:true,press:BACK_BUTTON},
goBackEsc:{labelKey:'hotkeys.action.goBackEsc',group:'nav',feature:HOTKEY_NAV_FEATURE,defaultCombo:'escape',needs:NEED_NO_POPUP,requireVisible:true,press:BACK_BUTTON},
stopPackBulk:{labelKey:'hotkeys.action.stopPackBulk',group:'unassigned',feature:'hotkeys',defaultCombo:'m',requireVisible:true,press:'[data-fut-bulk-stop]'},
sendToClub:{labelKey:'hotkeys.action.sendToClub',group:'card',feature:'hotkeys',defaultCombo:'y',press:ITEM_ROW_BUTTONS,deed:'club',requireVisible:true},sendToTransfer:{labelKey:'hotkeys.action.sendToTransfer',group:'card',feature:'hotkeys',defaultCombo:'t',press:ITEM_ROW_BUTTONS,deed:'transfer',requireVisible:true},// БУКВА `G` ОСВОБОЖДЕНА ДЛЯ ОПТОВОГО ДЕЙСТВИЯ (слово владельца 2026-08-11:
sendToStorage:{labelKey:'hotkeys.action.sendToStorage',group:'card',feature:'hotkeys',defaultCombo:'',handOnly:'hotkeys.reason.letterTaken',press:ITEM_ROW_BUTTONS,deed:'storage',requireVisible:true},
discardItem:{labelKey:'hotkeys.action.discardItem',group:'card',feature:'hotkeys',defaultCombo:'h',danger:true,dangerKind:'quicksell',press:ITEM_ROW_BUTTONS,deed:'quickSell',requireVisible:true,
confirmTitle:'infopanel.label.discard',confirmNotTitle:['infopanel.label.discardall']},
sortPack:{labelKey:'hotkeys.action.sortPack',group:'unassigned',feature:'hotkeys',defaultCombo:'i',layer:'unassigned',danger:true,dangerKind:'quicksell',requireVisible:true,press:'[data-fut-unassigned-go]'},
bulkToClub:{labelKey:'hotkeys.action.bulkToClub',group:'unassigned',feature:'hotkeys',defaultCombo:'u',layer:'unassigned',door:'unassigned-bulk'},
bulkToStorage:{labelKey:'hotkeys.action.bulkToStorage',group:'unassigned',feature:'hotkeys',defaultCombo:'g',layer:'unassigned',door:'unassigned-bulk'},
bulkQuickSellItems:{labelKey:'hotkeys.action.bulkQuickSellItems',group:'unassigned',feature:'hotkeys',defaultCombo:'j',layer:'unassigned',danger:true,dangerKind:'quicksell',door:'unassigned-bulk',
confirmTitle:'infopanel.label.discardall',confirmNotTitle:['infopanel.label.discard'],confirmTitleOne:'infopanel.label.discard'},
bulkQuickSell:{labelKey:'hotkeys.action.bulkQuickSell',group:'unassigned',feature:'hotkeys',defaultCombo:'b',layer:'unassigned',danger:true,dangerKind:'quicksell',door:'unassigned-bulk',
confirmTitle:'infopanel.label.discardall',confirmNotTitle:['infopanel.label.discard'],confirmTitleOne:'infopanel.label.discard'},
buyNow:{labelKey:'hotkeys.action.buyNow',group:'market',feature:'hotkeys',defaultCombo:'d',danger:true,dangerKind:'market',press:'.bidOptions .buyButton',
confirmTitle:'popup.buyNowConfirmationTitle',confirmNotTitle:['popup.bidConfirmationTitle']},placeBid:{labelKey:'hotkeys.action.placeBid',group:'market',feature:'hotkeys',defaultCombo:'f',danger:true,dangerKind:'market',press:'.bidOptions .bidButton'},
snipeChain:{labelKey:'hotkeys.action.snipeChain',group:'market',feature:'autoSnipe',defaultCombo:'o',layer:'marketAny',danger:true,dangerKind:'market',door:'snipe-key'},
clearSquad:{labelKey:'hotkeys.action.clearSquad',group:'sbc',feature:'hotkeys',defaultCombo:'c',deed:'clearSquad',deedIn:'.sbc-button-container,.ut-squad-actions-view',press:'button',requireVisible:true,
autoConfirmIn:'.sbc-button-container',confirmTitle:'clearSquad.title',confirmNotTitle:['sbc.overlay.btn.submitChallenge']},
submitChallenge:{labelKey:'hotkeys.action.submitChallenge',group:'sbc',feature:'hotkeys',defaultCombo:'e',layer:'sbc',danger:true,dangerKind:'submit',press:SUBMIT_DOORS_SELECTOR},
buyAndConfirm:{labelKey:'hotkeys.action.buyAndConfirm',group:'market',feature:'hotkeys',defaultCombo:'',reserved:'hotkeys.reason.later',plannedCombo:'5',danger:true,dangerKind:'buy'},autoBuyConcept:{labelKey:'hotkeys.action.autoBuyConcept',group:'sbc',feature:'hotkeys',defaultCombo:'',reserved:'hotkeys.reason.inWindow',plannedCombo:'4',danger:true,dangerKind:'buy'},openMyPack1:{labelKey:'hotkeys.action.openMyPack1',group:'unassigned',feature:'hotkeys',defaultCombo:'',reserved:'hotkeys.reason.later',plannedCombo:'6'},clickerStart:{labelKey:'hotkeys.action.clickerStart',group:'nav',feature:'hotkeys',defaultCombo:'',reserved:'hotkeys.reason.later',plannedCombo:'7'},clickerStop:{labelKey:'hotkeys.action.clickerStop',group:'nav',feature:'hotkeys',defaultCombo:'',reserved:'hotkeys.reason.later',plannedCombo:'8'}})
export function dangerousActions(registry=HOTKEY_ACTIONS){return Object.entries(registry).filter(([,meta])=>meta?.danger===true).map(([action])=>action)}
const LATIN_KEY=/^[a-z0-9]$/
const NAMED_KEYS=new Set(['escape','delete','insert','space','enter','tab','backspace','home','end','pageup','pagedown','arrowup','arrowdown','arrowleft','arrowright','capslock','contextmenu','printscreen','pause'])
function knownKey(key){return key.length===1||NAMED_KEYS.has(key)||/^f([1-9]|1\d|2[0-4])$/.test(key)}
const PUNCT_CODES=Object.freeze({Minus:'-',Equal:'=',BracketLeft:'[',BracketRight:']',Semicolon:';',Comma:',',Period:'.',Slash:'/',
Quote:String.fromCharCode(39),Backslash:String.fromCharCode(92),Backquote:String.fromCharCode(96)})
export function keyFromCode(code){if(typeof code!=='string')return ''
if(/^Key[A-Z]$/.test(code))return code.slice(3).toLowerCase()
if(/^Digit[0-9]$/.test(code))return code.slice(5)
return PUNCT_CODES[code]??''}
const ASCII_KEY=/^[\x20-\x7e]+$/
export function keyOfEvent(event){const typed=normalizeKey(event?.key)
if(LATIN_KEY.test(typed))return typed
const physical=keyFromCode(event?.code)
if(physical!=='')return physical
return ASCII_KEY.test(typed)?typed:''}
export function parseCombo(input){if(typeof input!=='string') return null
let normalized=input.toLowerCase().trim()
if(normalized==='+') normalized='plus'
else if(normalized.endsWith('++')) normalized=`${normalized.slice(0,-1)}plus`
const parts=normalized.split('+').map((p)=>p.trim()).filter((p)=>p!=='')
if(parts.length===0)return null
const combo={ctrl:false,alt:false,shift:false,meta:false,key:''}
for(const[i,part]of parts.entries()){const modifier=MODIFIER_ALIASES.get(part)
if(modifier&&i<parts.length-1){combo[modifier]=true
continue}
if(combo.key!=='') return null;// две клавиши в одном сочетании
combo.key=normalizeKey(part)}
if(combo.key===''||MODIFIER_ALIASES.has(combo.key)||!knownKey(combo.key)) return null
return combo}
export function formatCombo(combo){if(!combo||typeof combo.key!=='string'||combo.key==='') return ''
const parts=MODIFIER_ORDER.filter((mod)=>combo[mod]===true)
parts.push(combo.key)
return parts.join('+')}
export function canonicalCombo(input){return formatCombo(parseCombo(input))}
export function matchesCombo(event,combo){const wanted=typeof combo==='string'?parseCombo(combo):combo
if(!wanted||!event)return false
if(Boolean(event.ctrlKey)!==wanted.ctrl)return false
if(Boolean(event.altKey)!==wanted.alt)return false
if(Boolean(event.shiftKey)!==wanted.shift)return false
if(Boolean(event.metaKey)!==wanted.meta)return false
return keyOfEvent(event)===wanted.key}
export function detectConflicts(bindings,registry=HOTKEY_ACTIONS){const problems=[]
const taken=new Map()
for(const[action,raw]of Object.entries(bindings??{})){if(!Object.hasOwn(registry,action)){problems.push({action,combo:String(raw),reason:'unknown-action'})
continue}
if(raw==='')continue
const canon=canonicalCombo(raw)
if(canon===''){problems.push({action,combo:String(raw),reason:'unparsable'})
continue}
if(BROWSER_RESERVED.includes(canon)){problems.push({action,combo:canon,reason:'browser-reserved'})
continue}
const layer=layerOf(registry[action])
const others=taken.get(canon)??[]
const clash=others.find((one)=>layersClash(one.layer,layer)&&!stacked(registry,one.action,action))
if(clash){problems.push({action,combo:canon,reason:'duplicate',conflictsWith:clash.action,layer})
continue}
others.push({action,layer})
taken.set(canon,others)}
return{ok:problems.length===0,problems}}
export function layerOf(meta){const named=meta?.layer
return typeof named==='string'&&Object.hasOwn(LAYERS,named)?named:'global'}
export const DANGER_KINDS=Object.freeze(['market','buy','quicksell','submit'])
export const DANGER_KIND_KEYS=Object.freeze({market:'hotkeys.danger.kind.market',
buy:'hotkeys.danger.kind.buy',
quicksell:'hotkeys.danger.kind.quicksell',
submit:'hotkeys.danger.kind.submit'})
export function dangerKindOf(action){const meta=HOTKEY_ACTIONS[action]
if(meta?.danger!==true)return null
const kind=meta?.dangerKind
return typeof kind==='string'&&DANGER_KINDS.includes(kind)?kind:null}
export function dangerKindsOf(actions){const seen=new Set()
for(const action of Array.isArray(actions)?actions:[]){const kind=dangerKindOf(action)
if(kind!==null)seen.add(kind)}
return DANGER_KINDS.filter((one)=>seen.has(one))}
export function layersClash(a,b){if(a===b||a==='global'||b==='global')return true
const here=screensOf(a)
const there=screensOf(b)
return here.some((one)=>there.includes(one))}
function screensOf(layer){const said=LAYERS[layer]
return typeof said==='string'&&said!==''?said.split(',').map((one)=>one.trim()).filter((one)=>one!==''):[]}
export function shadowsAction(meta,action){return typeof meta?.shadows==='string'&&meta.shadows===action}
function stacked(registry,a,b){return shadowsAction(registry?.[a],b)||shadowsAction(registry?.[b],a)}
export function defaultBindings(registry=HOTKEY_ACTIONS){return Object.fromEntries(Object.entries(registry).map(([action,meta])=>[action,meta.defaultCombo]))}
export function comboFromEvent(event){
const key=keyOfEvent(event)
if(key===''||MODIFIER_ALIASES.has(key))return ''
const parts=MODIFIER_ORDER.filter((mod)=>Boolean(event?.[`${mod}Key`]))
parts.push(key)
return parts.join('+')}
export function sanitizeBindings(stored,registry=HOTKEY_ACTIONS){const source=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const out={}
const taken=new Map()
const free=(canon,layer,action)=>!(taken.get(canon)??[]).some((one)=>layersClash(one.layer,layer)&&!stacked(registry,one.action,action))
const hold=(canon,layer,action)=>{const list=taken.get(canon)??[]
list.push({action,layer})
taken.set(canon,list)}
for(const action of Object.keys(registry)){const canon=canonicalCombo(source[action])
const layer=layerOf(registry[action])
if(canon===''||BROWSER_RESERVED.includes(canon)||!free(canon,layer,action))continue
out[action]=canon
hold(canon,layer,action)}
for(const[action,meta]of Object.entries(registry)){if(out[action]!==undefined)continue
const fallback=meta.defaultCombo
const layer=layerOf(meta)
out[action]=fallback&&free(fallback,layer,action)?fallback:''
if(out[action]!=='')hold(fallback,layer,action)}
return Object.fromEntries(Object.keys(registry).map((action)=>[action,out[action]]))}
export function actionForEvent(event,bindings,isEnabled=()=>true,options={}){const{registry=HOTKEY_ACTIONS,onScreen=null,onNeeds=null}=options
for(const[action,combo]of Object.entries(bindings??{})){const meta=registry[action]
if(!meta)continue
if(meta.reserved)continue
if(!matchesCombo(event,combo))continue
if(onScreen&&!onScreen(layerOf(meta)))continue
if(typeof meta.needs==='string'&&!(onNeeds&&onNeeds(meta.needs,meta)))continue
return isEnabled(meta.feature)?action:null}
return null}
function normalizeKey(key){if(typeof key!=='string') return ''
const lower=key.toLowerCase()
if(KEY_ALIASES.has(lower))return KEY_ALIASES.get(lower)
const trimmed=lower.trim()
if(trimmed==='') return ''
return KEY_ALIASES.get(trimmed)??trimmed}
