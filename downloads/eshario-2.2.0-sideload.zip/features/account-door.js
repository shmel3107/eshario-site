import{createBridgeClient} from '../bridge/page-client.js'
import{CHANNEL,FROM_CONTENT,KIND_EVENT} from '../bridge/protocol.js'
import{ACCOUNT_OPEN} from '../licensing/account.js'
export const ACCOUNT_OPEN_FAILED='account.open.failed'
export const ACCOUNT_BRIDGE_PREFIX='acc'
const REASON_RE=/^[a-z][a-z-]{0,39}$/
const rooms=new WeakMap()
function roomOf(win){let room=rooms.get(win)
if(room===undefined){room={client:null,watching:false,opens:0,failures:0,last:null}
rooms.set(win,room)
attachInstrument(win)}
return room}
function record(win,room,reason){room.failures+=1
room.last=reason
try{const box=win.__eshario
if(box&&Array.isArray(box.errors))box.errors.push(`account door: страница аккаунта не открылась (${reason})`)}catch{/* прибор молчит, счёт в комнате остался */}}
export function watchAccountDoor(win){if(!win||typeof win.addEventListener!=='function')return false
const room=roomOf(win)
if(room.watching)return true
room.watching=true
win.addEventListener('message',(event)=>{if(event?.source!==undefined&&event.source!==win)return
const msg=event?.data
if(!msg||msg.channel!==CHANNEL||msg.from!==FROM_CONTENT||msg.kind!==KIND_EVENT||msg.name!==ACCOUNT_OPEN_FAILED)return
const said=msg.payload?.reason
record(win,room,typeof said==='string'&&REASON_RE.test(said)?said:'open-failed')})
return true}
export async function openAccountDoor(win){if(!win)return{ok:false,reason:'no-window'}
const room=roomOf(win)
watchAccountDoor(win)
room.opens+=1
try{if(room.client===null)room.client=createBridgeClient(win,{prefix:ACCOUNT_BRIDGE_PREFIX})
const value=await room.client.request(ACCOUNT_OPEN)
if(value&&value.ok===true)return{ok:true,reason:null}
return{ok:false,reason:typeof value?.reason==='string'?value.reason:'no-response'}}catch{
record(win,room,'bridge')
return{ok:false,reason:'bridge'}}}
export function accountDoorState(win){const room=win?rooms.get(win):undefined
return{opens:room?.opens??0,failures:room?.failures??0,last:room?.last??null,watching:room?.watching===true}}
function attachInstrument(win){try{const box=win.__eshario
if(box&&typeof box==='object'&&typeof box.accountDoor!=='function')box.accountDoor=()=>accountDoorState(win)}catch{/* ручки не будет, дверь всё равно живёт */}}
