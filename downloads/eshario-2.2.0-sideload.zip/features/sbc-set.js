import{rewardSaleOf,setFactsOf} from '../adapter/sbc-hub.js'
import{CHALLENGE_CONTENT_SELECTOR,SET_INFO_SELECTOR,SET_STATUS_SELECTOR,SET_EXPIRY_SELECTOR,challengeFactsOf,requirementPairsOf} from '../adapter/sbc-set.js'
import{chipsOf,packChips} from './sbc-chips.js'
import{expiresSoon} from './sbc-tab.js'
import{el,clear,ensureTheme,ensureStylesheet,logoLink} from '../ui/dom.js'
import{ensureControls} from '../ui/controls.js'
export const SBC_SET_FEATURE='sbcSolver'
export const COLUMNS=4
export const COLUMNS_NARROW=2
export const DENSITY=Object.freeze({
midUpTo:12,
midUpToNarrow:6,
midColumns:3,
centerUpTo:3,
midMaxPx:523,
midMinPx:150,
tileMinPx:112,
compactUpTo4:16,
compactUpTo5:20,
compactColumnsMax:5,
tileMinWidthPx:276,
chipRowPx:18,
chipGapPx:4,
chipRowsMid:2,
chipRowsCompact:1})
export function tierOf(left,narrow=false){const count=Number.isFinite(Number(left))?Number(left):0
if(count<=0)return 'compact'
return count<=(narrow===true?DENSITY.midUpToNarrow:DENSITY.midUpTo)?'mid':'compact'}
export function columnsOf(tier,left,narrow=false,total=left){const count=Math.max(1,Number.isFinite(Number(left))?Number(left):1)
const all=Math.max(count,Number.isFinite(Number(total))?Number(total):count)
if(narrow===true)return Math.max(1,Math.min(all,COLUMNS_NARROW))
if(tier==='mid')return all<=DENSITY.centerUpTo?all:DENSITY.midColumns
if(count<=DENSITY.compactUpTo4)return COLUMNS
if(count<=DENSITY.compactUpTo5)return COLUMNS+1
return DENSITY.compactColumnsMax}
export function centeredOf(tier,left,total=left){const all=Number.isFinite(Number(total))?Number(total):0
return tier==='mid'&&all>0&&all<=DENSITY.centerUpTo}
export function chipRowsOf(shape){return shape==='mid'?DENSITY.chipRowsMid:DENSITY.chipRowsCompact}
export const GRID_MARK='data-fut-sbc-set-grid'
export const GRID_KEY='futSbcSetGrid'
export const DENSITY_MARK='data-fut-sbc-set-density'
export const DENSITY_KEY='futSbcSetDensity'
export const DENSITY_NARROW_MARK='data-fut-sbc-set-density-narrow'
export const DENSITY_NARROW_KEY='futSbcSetDensityNarrow'
export const CENTER_MARK='data-fut-sbc-set-center'
export const CENTER_KEY='futSbcSetCenter'
export const TILE_MARK='data-fut-sbc-tile'
export const TOP_MARK='data-fut-sbc-set-top'
export const TOP_KEY='futSbcSetTop'
export const REST_MARK='data-fut-sbc-set-rest'
export const REST_KEY='futSbcSetRest'
export const MORE_MARK='data-fut-sbc-set-more'
export const MORE_KEY='futSbcSetMore'
export const SIGN_MARK='data-fut-sbc-set-sign'
export const SIGN_KEY='futSbcSetSign'
export const WHEN_MARK='data-fut-sbc-set-when'
export const WHEN_KEY='futSbcSetWhen'
export const PIN_MARK='data-fut-sbc-set-pinned'
export const PIN_KEY='futSbcSetPinned'
export const BAR_CLASS='fx-bar'
export const GRID_SELECTOR=`[${GRID_MARK}]`
export const DENSITY_SELECTOR=`[${DENSITY_MARK}]`
export const DENSITY_NARROW_SELECTOR=`[${DENSITY_NARROW_MARK}]`
export const CENTER_SELECTOR=`[${CENTER_MARK}]`
export const CHIPS_CLASS='fut-sbc-tile-chips'
export const CHIP_CLASS='fut-sbc-tile-chip'
export const CHIP_MORE_CLASS='fut-sbc-tile-chip-more'
export const CHIP_OFF_MARK='data-fut-sbc-chip-off'
export const CHIP_OFF_KEY='futSbcChipOff'
export const TILE_SELECTOR=`[${TILE_MARK}]`
export const TOP_SELECTOR=`[${TOP_MARK}]`
export const REST_SELECTOR=`[${REST_MARK}]`
export const MORE_SELECTOR=`[${MORE_MARK}]`
export const SIGN_SELECTOR=`[${SIGN_MARK}]`
export const WHEN_SELECTOR=`[${WHEN_MARK}]`
export const PIN_SELECTOR='.fut-sbc-set-pin'
export const PROGRESS_WIDTH_PX=420
export const CARD_BOX=Object.freeze({w:86,h:120})
export const CARD_SCALE=1.05
const WIDE_HOSTS=Object.freeze(['.ut-split-view','.ut-content'])
const WIDE_STOP='.ut-root-view'
export const WIDE_MARK='data-fut-sbc-set-wide'
export const WIDE_KEY='futSbcSetWide'
export const WIDE_SELECTOR=`[${WIDE_MARK}]`
const CAP_HOST='.ut-content'
export const CAP_MARK='data-fut-sbc-set-cap'
export const CAP_KEY='futSbcSetCap'
export const CAP_SELECTOR=`[${CAP_MARK}]`
const SBC_SET_STYLESHEET=new URL('../ui/sbc-set.css',import.meta.url).href
const SBC_SET_LINK_ID='fut-companion-sbc-set'
export function tileOrder(rows){const list=Array.isArray(rows)?rows:[]
const seats=list.map((row,index)=>({index,
done:row?.done===true,
coins:Number.isFinite(Number(row?.coins))&&Number(row?.coins)>0?Number(row.coins):null}))
seats.sort((a,b)=>{if(a.done!==b.done)return a.done?1:-1
if(a.coins===null&&b.coins===null)return a.index-b.index
if(a.coins===null)return 1
if(b.coins===null)return-1
if(a.coins!==b.coins)return a.coins-b.coins
return a.index-b.index})
const places=new Array(list.length).fill(0)
seats.forEach((seat,place)=>{places[seat.index]=place+1})
return places}
export function restOfSet(rows){let coins=0
let priced=0
let left=0
let blind=0
for(const row of Array.isArray(rows)?rows:[]){if(row?.done===true)continue
left+=1
const value=Number(row?.coins)
if(Number.isFinite(value)&&value>0){coins+=value
priced+=1}
else blind+=1}
if(left===0||priced===0)return{coins:null,partial:blind>0,left}
return{coins,partial:blind>0,left}}
export function costLabel(coins,t,formatCoins){return Number.isFinite(Number(coins))&&Number(coins)>0
?t('sbcSet.cost',{coins:formatCoins(Number(coins))})
:t('sbcSet.cost.none')}
const tileKey=(place,coins,reward,sale,epoch)=>`${place}|${coins??''}|${reward??''}|${sale??''}|${epoch}`
export function createSbcSet(deps={}){const{doc,t}=deps
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>true
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const formatCoins=typeof deps.formatCoins==='function'?deps.formatCoins:(coins)=>String(Math.round(coins))
const coinsOf=typeof deps.challengeCoinsOf==='function'?deps.challengeCoinsOf:null
const readView=typeof deps.view==='function'?deps.view:null
const writeView=typeof deps.setView==='function'?deps.setView:null
let pinned=true
const rewardTextOf=typeof deps.rewardTextOf==='function'?deps.rewardTextOf:null
const reqPairsOf=typeof deps.requirementPairsOf==='function'?deps.requirementPairsOf:requirementPairsOf
const frame=typeof deps.frame==='function'?deps.frame:(fn)=>{fn()}
let last=null
let mark=''
let epoch=0
let waiting=false
let fitting=false
let boxWatch=null
let wideHosts=[]
const stats={captures:0,paints:0,skipped:0,rows:0,priced:0,reqs:0,noSource:0,unknown:0,noSolution:0,more:0,noTop:0,noStatus:0,fits:0,chipsHidden:0}
if(readView!==null){try{const saved=readView()
if(typeof saved?.pinned==='boolean')pinned=saved.pinned}catch(err){onError(err)}}
const connected=(node)=>{try{return node?.isConnected!==false}catch{return false}}
function wideHostsOf(root){const found=[]
let node=root?.parentNode??null
for(let depth=0;node&&depth<10;depth+=1){let stop=false
try{stop=node.matches?.(WIDE_STOP)===true}catch{stop=false}
if(stop)break
let hit=false
try{hit=WIDE_HOSTS.some((selector)=>node.matches?.(selector)===true)}catch{hit=false}
if(hit)found.unshift(node)
node=node.parentNode??null}
return found}
function priceOf(id){if(coinsOf===null){stats.noSource+=1
return null}
if(!Number.isFinite(Number(id))){stats.unknown+=1
return null}
let answer=null
try{answer=coinsOf(Number(id))}catch(err){onError(err)
answer=null}
if(answer===null||answer===undefined){stats.unknown+=1
return null}
const coins=Number(answer?.coins)
if(!Number.isFinite(coins)||coins<=0){stats.noSolution+=1
return null}
return coins}
function chipsFor(challenge){if(challenge===null||challenge===undefined)return[]
try{const pairs=reqPairsOf(challenge)
return chipsOf(Array.isArray(pairs)?pairs:[],t)}catch(err){onError(err)
return[]}}
function rewardOf(award){if(award===null||award===undefined||rewardTextOf===null)return null
try{const text=rewardTextOf(award)
return typeof text==='string'&&text.trim()!==''?text.trim():null}catch(err){onError(err)
return null}}
function markWide(root){const hosts=wideHostsOf(root)
if(hosts.length===0)return 0
wideHosts=hosts
for(const host of hosts){try{if(host?.dataset&&host.dataset[WIDE_KEY]!=='1')host.dataset[WIDE_KEY]='1'}catch(err){onError(err)}}
for(const host of hosts){let cap=false
try{cap=host?.matches?.(CAP_HOST)===true}catch{cap=false}
if(!cap)continue
try{if(host?.dataset&&host.dataset[CAP_KEY]!=='1')host.dataset[CAP_KEY]='1'}catch(err){onError(err)}}
return hosts.length}
function clearWide(){let gone=0
for(const host of wideHosts){try{if(host?.dataset&&host.dataset[WIDE_KEY]!==undefined){delete host.dataset[WIDE_KEY]
host.removeAttribute?.(WIDE_MARK)
gone+=1}
if(host?.dataset&&host.dataset[CAP_KEY]!==undefined){delete host.dataset[CAP_KEY]
host.removeAttribute?.(CAP_MARK)}}catch{/* один предок не роняет остальных */}}
wideHosts=[]
return gone}
function activeSafe(){try{return isActive(SBC_SET_FEATURE)===true}catch{return false}}
function schedulePaint(){if(waiting)return
waiting=true
frame(()=>{waiting=false
try{paintNow()}catch(err){onError(err)}})}
function paintNow(){const painted=paint()
if(painted)scheduleFit()
return painted}
function scheduleFit(){if(fitting)return
fitting=true
frame(()=>{fitting=false
try{fitChips()}catch(err){onError(err)}})}
function paint(){if(last===null)return false
if(!activeSafe()){dropWatch()
dropAll(doc)
last=null
return false}
if(!connected(last.root)||!connected(last.host)){dropWatch()
clearWide()
last=null
return false}
const rows=last.rows.filter((row)=>connected(row.root))
for(const row of rows)measure(row)
measureTop()
const places=tileOrder(rows)
const rest=restOfSet(rows)
const tier=tierOf(rest.left,false)
const tierNarrow=tierOf(rest.left,true)
const soon=expiresSoonNow()
const fingerprint=`${epoch}|${pinned?'pin':'free'}|${tier}|${tierNarrow}|${rows.length}|${last.sale??''}|${last.more??''}|${rest.coins??''}|${rest.partial?'+':''}|${soon?'soon':''}|${rows.map((row,at)=>`${places[at]}:${row.coins??''}:${row.done?'d':''}`).join(',')}`
if(fingerprint===mark){stats.skipped+=1
return false}
mark=fingerprint
stats.paints+=1
stats.rows=rows.length
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,SBC_SET_STYLESHEET,SBC_SET_LINK_ID)
try{last.host.dataset[GRID_KEY]=String(columnsOf(tier,rest.left,false,rows.length))
last.host.dataset[DENSITY_KEY]=tier
last.host.dataset[DENSITY_NARROW_KEY]=tierNarrow
last.host.style?.setProperty?.('--fut-sbc-set-columns',String(columnsOf(tier,rest.left,false,rows.length)))
last.host.style?.setProperty?.('--fut-sbc-set-columns-narrow',String(columnsOf(tierNarrow,rest.left,true,rows.length)))
last.host.style?.setProperty?.('--fut-sbc-set-tile-min',`${DENSITY.tileMinPx}px`)
last.host.style?.setProperty?.('--fut-sbc-set-tile-min-w',`${DENSITY.tileMinWidthPx}px`)
last.host.style?.setProperty?.('--fut-sbc-set-mid-min',`${DENSITY.midMinPx}px`)
last.host.style?.setProperty?.('--fut-sbc-set-mid-max',`${DENSITY.midMaxPx}px`)
last.host.style?.setProperty?.('--fut-sbc-set-chip-row',`${DENSITY.chipRowPx}px`)
last.host.style?.setProperty?.('--fut-sbc-set-chip-gap',`${DENSITY.chipGapPx}px`)
last.host.dataset[CENTER_KEY]=centeredOf(tier,rest.left,rows.length)?'1':'0'}catch(err){onError(err)}
markWide(last.root)
for(let at=0;at<rows.length;at+=1){const row=rows[at]
paintRow(row,places[at],tier)}
paintTop(rest,soon)
return true}
function measure(row){if(row.coins!==undefined)return
row.coins=priceOf(row.id)
if(row.coins!==null)stats.priced+=1
row.reward=rewardOf(row.award)
row.chips=chipsFor(row.challenge)
if(row.chips.length>0)stats.reqs+=1
row.sale=rewardSaleOf(row.award)}
function paintRow(row,place,tier){const shape=row.done===true?'compact':tier
const key=`${tileKey(place,row.coins,row.reward,row.sale,epoch)}|${shape}`
if(row.key===key&&connected(row.node))return
row.key=key
try{row.root.style?.setProperty?.('order',String(place))}catch(err){onError(err)}
const host=row.root.querySelector?.(CHALLENGE_CONTENT_SELECTOR)??row.root
let node=row.node
if(node===null||!connected(node)){node=el(doc,'div',{class:'fut-sbc-tile',dataset:{futSbcTile:'1'}})
host.appendChild(node)
row.node=node}
clear(node)
try{node.dataset.futSbcTileShape=shape}catch(err){onError(err)}
if(row.done!==true)paintChips(node,row)
const priced=Number.isFinite(Number(row.coins))&&Number(row.coins)>0
const cost=el(doc,'span',{class:'fut-sbc-tile-cost',
text:costLabel(row.coins,t,formatCoins),
attrs:{title:priced?t('sbcSet.cost.hint'):t('sbcSet.cost.none.hint')},
dataset:{futSbcTileCost:priced?'have':'none'}})
const reward=row.reward===null?null:el(doc,'span',{class:'fut-sbc-tile-reward',
text:row.reward,dataset:{futSbcTileReward:row.sale??'none'}})
if(shape!=='mid'){if(reward!==null)node.appendChild(reward)
node.appendChild(cost)
return}
const foot=el(doc,'div',{class:'fut-sbc-tile-foot'})
if(reward!==null)foot.appendChild(reward)
foot.appendChild(cost)
node.appendChild(foot)}
function paintChips(node,row){const chips=Array.isArray(row.chips)?row.chips:[]
const box=el(doc,'div',{class:CHIPS_CLASS})
for(const chip of chips){box.appendChild(el(doc,'span',{class:CHIP_CLASS,text:chip.text,
attrs:{title:chip.hint??chip.text}}))}
if(chips.length>1){box.appendChild(el(doc,'span',{class:`${CHIP_CLASS} ${CHIP_MORE_CLASS}`,
text:t('sbcSet.chip.more',{count:String(chips.length-1)})}))}
node.appendChild(box)}
function fitChips(){if(last===null)return 0
const jobs=[]
for(const row of last.rows){if(!connected(row.node))continue
let box=null
try{box=row.node.querySelector?.(`.${CHIPS_CLASS}`)??null}catch{box=null}
if(box===null)continue
const chips=[]
let more=null
for(const one of Array.from(box.children??[])){let isMore=false
try{isMore=one?.classList?.contains?.(CHIP_MORE_CLASS)===true}catch{isMore=false}
if(isMore){more=one
continue}
chips.push(one)}
if(chips.length===0)continue
for(const one of chips)showChip(one)
if(more!==null)showChip(more)
jobs.push({box,chips,more})}
if(jobs.length===0)return 0
const plans=[]
for(const job of jobs){const widths=job.chips.map((one)=>sizeOf(one))
const rows=rowsOf(job.box)
plans.push({job,plan:packChips(widths,{box:innerOf(job.box),rows,gap:DENSITY.chipGapPx,
more:job.more===null?0:sizeOf(job.more)})})}
let done=0
for(const one of plans){const{job,plan}=one
const спрятаны=[]
for(let at=plan.shown;at<job.chips.length;at+=1){hideChip(job.chips[at])
try{const said=job.chips[at].getAttribute?.('title')
if(typeof said==='string'&&said!=='')спрятаны.push(said)}catch{/* один чип не роняет остальные */}}
if(job.more!==null){if(plan.hidden>0){try{job.more.textContent=t('sbcSet.chip.more',{count:String(plan.hidden)})
job.more.setAttribute?.('title',спрятаны.length>0
?t('sbcSet.chip.more.hint',{list:спрятаны.join(' · ')})
:t('sbcSet.chip.more',{count:String(plan.hidden)}))}catch(err){onError(err)}}
else hideChip(job.more)}
stats.chipsHidden+=plan.hidden
done+=1}
stats.fits+=1
watchBox()
return done}
function showChip(node){try{delete node.dataset?.[CHIP_OFF_KEY]
node.removeAttribute?.(CHIP_OFF_MARK)}catch{/* один чип не роняет остальные */}}
function hideChip(node){try{node.dataset[CHIP_OFF_KEY]='1'}catch{/* один чип не роняет остальные */}}
function sizeOf(node){try{const box=node?.getBoundingClientRect?.()
const width=Number(box?.width)
return Number.isFinite(width)?width:0}catch{return 0}}
function innerOf(node){try{const width=Number(node?.clientWidth)
return Number.isFinite(width)?width:0}catch{return 0}}
function rowsOf(node){const height=(()=>{try{const value=Number(node?.clientHeight)
return Number.isFinite(value)?value:0}catch{return 0}})()
if(height<=0)return DENSITY.chipRowsMid
const step=DENSITY.chipRowPx+DENSITY.chipGapPx
return Math.max(1,Math.round((height+DENSITY.chipGapPx)/step))}
function watchBox(){if(boxWatch!==null||last===null)return false
const view=(()=>{try{return doc?.defaultView??null}catch{return null}})()
const Observer=view?.ResizeObserver
if(typeof Observer!=='function')return false
try{boxWatch=new Observer(()=>{try{scheduleFit()}catch(err){onError(err)}})
boxWatch.observe(last.host)
return true}catch(err){onError(err)
boxWatch=null
return false}}
function dropWatch(){if(boxWatch===null)return
try{boxWatch.disconnect?.()}catch{/* наблюдатель не роняет уборку */}
boxWatch=null}
function measureTop(){if(last.more!==undefined)return
const list=[]
for(let at=1;at<last.awards.length;at+=1){const text=rewardOf(last.awards[at])
if(text!==null)list.push(text)}
stats.more=list.length
last.more=list.length===0?null:list.join(' · ')}
function expiresSoonNow(){try{return expiresSoon(setFactsOf(last?.set))===true}catch(err){onError(err)
return false}}
function firstKid(node){try{const kids=node?.children
return kids&&kids.length>0?kids[0]:null}catch{return null}}
function lastKid(node){try{const kids=node?.children
return kids&&kids.length>0?kids[kids.length-1]:null}catch{return null}}
function paintTop(rest,soon){const info=last.root.querySelector?.(SET_INFO_SELECTOR)??null
if(info===null||!connected(info)){stats.noTop+=1
return}
try{info.dataset[PIN_KEY]=pinned?'1':'0'
info.dataset[TOP_KEY]=last.sale??'none'
info.style?.setProperty?.('--fut-sbc-set-progress',`${PROGRESS_WIDTH_PX}px`)
info.style?.setProperty?.('--fut-sbc-set-card-w',`${CARD_BOX.w}px`)
info.style?.setProperty?.('--fut-sbc-set-card-h',`${CARD_BOX.h}px`)
info.style?.setProperty?.('--fut-sbc-set-card-scale',String(CARD_SCALE))}catch(err){onError(err)}
paintSign(info)
paintPin(info)
paintWhen(info,soon)
paintRest(info,rest)
paintMore(info)}
function paintSign(info){const box=info.querySelector?.(SET_STATUS_SELECTOR)??null
if(box===null){stats.noStatus+=1
for(const node of info.querySelectorAll?.(SIGN_SELECTOR)??[])node.remove?.()
return}
try{box.classList?.add?.(BAR_CLASS)}catch(err){onError(err)}
let node=info.querySelector?.(SIGN_SELECTOR)??null
if(node===null||!connected(node)||node.parentNode!==box||firstKid(box)!==node){node?.remove?.()
node=el(doc,'span',{class:'fut-sbc-set-sign',dataset:{[SIGN_KEY]:'1'}},[logoLink(doc)])
const first=firstKid(box)
if(first)box.insertBefore?.(node,first)
else box.appendChild(node)}}
function paintPin(info){const box=info.querySelector?.(SET_STATUS_SELECTOR)??null
if(box===null)return
let node=box.querySelector?.(PIN_SELECTOR)??null
if(writeView===null){node?.remove?.()
return}
if(node===null||!connected(node)||node.parentNode!==box){node?.remove?.()
node=el(doc,'button',{class:'fx-action fx-action-square fut-sbc-set-pin',text:'📌',
attrs:{type:'button'},dataset:{on:pinned?'1':'0'}})
for(const type of['pointerdown','mousedown','mouseup','click']){node.addEventListener(type,(event)=>{try{event.stopPropagation()}catch{/* чужое событие не роняет кнопку */}
if(type!=='click')return
pinned=pinned!==true
try{writeView({pinned})}catch(err){onError(err)}
schedulePaint()})}
box.appendChild(node)}
try{node.dataset.on=pinned?'1':'0'
node.setAttribute('aria-pressed',pinned?'true':'false')
const title=t(pinned?'sbcSet.pinOn':'sbcSet.pinOff')
node.setAttribute('title',title)
node.setAttribute('aria-label',title)}catch(err){onError(err)}}
function paintWhen(info,soon){const box=info.querySelector?.(SET_STATUS_SELECTOR)??null
const live=box===null?null:(box.querySelector?.(SET_EXPIRY_SELECTOR)??null)
for(const node of info.querySelectorAll?.(WHEN_SELECTOR)??[]){if(node===live&&soon)continue
try{delete node.dataset?.[WHEN_KEY]
node.removeAttribute?.(WHEN_MARK)}catch{/* один узел не роняет остальные */}}
if(live===null||!soon)return
try{live.dataset[WHEN_KEY]='soon'}catch(err){onError(err)}}
function paintRest(info,rest){let node=info.querySelector?.(REST_SELECTOR)??null
if(rest.coins===null){node?.remove?.()
return}
const box=info.querySelector?.(SET_STATUS_SELECTOR)??null
if(box===null){stats.noStatus+=1
node?.remove?.()
return}
const sign=box.querySelector?.(SIGN_SELECTOR)??null
const onPlace=node!==null&&connected(node)&&node.parentNode===box
&&(sign===null?firstKid(box)===node:node.previousElementSibling===sign)
if(!onPlace){const at=sign===null?firstKid(box):sign.nextSibling
node?.remove?.()
node=el(doc,'span',{class:'fut-sbc-set-rest',dataset:{[REST_KEY]:'1'}})
if(at)box.insertBefore?.(node,at)
else box.appendChild(node)}
clear(node)
try{node.setAttribute?.('title',rest.partial?t('sbcSet.rest.partial.hint'):t('sbcSet.rest.hint'))}catch(err){onError(err)}
node.appendChild(el(doc,'span',{class:'fut-sbc-set-rest-text',
text:rest.partial
?t('sbcSet.rest.partial',{coins:formatCoins(rest.coins)})
:t('sbcSet.rest',{coins:formatCoins(rest.coins)})}))}
function paintMore(info){let node=info.querySelector?.(MORE_SELECTOR)??null
if(last.more===null){node?.remove?.()
return}
if(node===null||!connected(node)||node.parentNode!==info){node?.remove?.()
node=el(doc,'div',{class:'fut-sbc-set-more',dataset:{[MORE_KEY]:'1'}})
info.appendChild(node)}
node.textContent=t('sbcSet.more',{list:last.more})}
return{
apply(capture){if(!capture?.host||!capture?.root)return false
stats.captures+=1
if(!activeSafe()){dropAll(doc)
last=null
return false}
if(last!==null&&last.root!==capture.root){dropWatch()
clearWide()}
stats.noSource=0
stats.unknown=0
stats.noSolution=0
stats.priced=0
stats.reqs=0
stats.chipsHidden=0
stats.more=0
stats.noTop=0
stats.noStatus=0
const facts=setFactsOf(capture.set)
const award=Array.isArray(facts?.awards)&&facts.awards.length>0?facts.awards[0]:null
const rows=[]
for(const pair of Array.isArray(capture.rows)?capture.rows:[]){if(!pair?.root)continue
const one=challengeFactsOf(pair.challenge)
rows.push({root:pair.root,id:one.id,done:one.done,started:one.started,award:one.award,
challenge:pair.challenge,
coins:undefined,reward:undefined,chips:undefined,sale:null,node:null,key:''})}
last={root:capture.root,host:capture.host,rows,
setId:facts?.id??null,
set:capture.set,
awards:rawAwards(capture.set),more:undefined,
sale:award?.sale??null}
mark=''
schedulePaint()
return true},
refresh(){if(last===null)return false
if(!connected(last.root)){
dropWatch()
clearWide()
last=null
mark=''
return false}
try{return paintNow()}catch(err){onError(err)
return false}},
relabel(){epoch+=1
mark=''
return this.refresh()},
state(){const left=last===null?0:restOfSet(last.rows).left
const tier=tierOf(left,false)
const tierNarrow=tierOf(left,true)
return{pinned,screen:last===null?null:{set:last.setId,rows:last.rows.length,
left,tier,tierNarrow,centered:centeredOf(tier,left,last.rows.length),
columns:columnsOf(tier,left,false,last.rows.length),
columnsNarrow:columnsOf(tierNarrow,left,true,last.rows.length),wide:wideHosts.length,
sale:last.sale,awards:last.awards.length},
wideNames:wideHosts.map((one)=>{try{return String(one?.className??'?').split(/\s+/)[0]}catch{return '?'}}),
epoch,mark:mark===''?null:mark.length,...stats}},
dispose(){last=null
mark=''
dropWatch()
clearWide()
dropAll(doc)}}}
function rawAwards(set){try{const list=set?.awards
return Array.isArray(list)?list:[]}catch{return[]}}
export function dropAll(doc){let count=0
for(const node of doc?.querySelectorAll?.(TILE_SELECTOR)??[]){node.remove?.()
count+=1}
for(const node of doc?.querySelectorAll?.(REST_SELECTOR)??[]){node.remove?.()
count+=1}
for(const node of doc?.querySelectorAll?.(MORE_SELECTOR)??[]){node.remove?.()
count+=1}
for(const node of doc?.querySelectorAll?.(SIGN_SELECTOR)??[]){node.remove?.()
count+=1}
for(const node of doc?.querySelectorAll?.(PIN_SELECTOR)??[]){node.remove?.()
count+=1}
for(const node of doc?.querySelectorAll?.(`${SET_STATUS_SELECTOR}.${BAR_CLASS}`)??[]){try{node.classList?.remove?.(BAR_CLASS)
count+=1}catch{/* один узел не роняет остальные */}}
for(const node of doc?.querySelectorAll?.(WHEN_SELECTOR)??[]){try{delete node.dataset?.[WHEN_KEY]
node.removeAttribute?.(WHEN_MARK)
count+=1}catch{/* одна метка не роняет остальные */}}
for(const host of doc?.querySelectorAll?.(TOP_SELECTOR)??[]){try{delete host.dataset?.[TOP_KEY]
host.removeAttribute?.(TOP_MARK)
delete host.dataset?.[PIN_KEY]
host.removeAttribute?.(PIN_MARK)
host.style?.removeProperty?.('--fut-sbc-set-progress')
host.style?.removeProperty?.('--fut-sbc-set-card-w')
host.style?.removeProperty?.('--fut-sbc-set-card-h')
host.style?.removeProperty?.('--fut-sbc-set-card-scale')
count+=1}catch{/* одна сводка не роняет остальные */}}
for(const host of doc?.querySelectorAll?.(WIDE_SELECTOR)??[]){try{delete host.dataset?.[WIDE_KEY]
host.removeAttribute?.(WIDE_MARK)
count+=1}catch{/* один предок не роняет остальных */}}
for(const host of doc?.querySelectorAll?.(CAP_SELECTOR)??[]){try{delete host.dataset?.[CAP_KEY]
host.removeAttribute?.(CAP_MARK)
count+=1}catch{/* один предок не роняет остальных */}}
for(const host of doc?.querySelectorAll?.(GRID_SELECTOR)??[]){try{delete host.dataset?.[GRID_KEY]
host.removeAttribute?.(GRID_MARK)
delete host.dataset?.[DENSITY_KEY]
host.removeAttribute?.(DENSITY_MARK)
delete host.dataset?.[DENSITY_NARROW_KEY]
host.removeAttribute?.(DENSITY_NARROW_MARK)
delete host.dataset?.[CENTER_KEY]
host.removeAttribute?.(CENTER_MARK)
host.style?.removeProperty?.('--fut-sbc-set-columns')
host.style?.removeProperty?.('--fut-sbc-set-columns-narrow')
host.style?.removeProperty?.('--fut-sbc-set-tile-min')
host.style?.removeProperty?.('--fut-sbc-set-tile-min-w')
host.style?.removeProperty?.('--fut-sbc-set-mid-min')
host.style?.removeProperty?.('--fut-sbc-set-mid-max')
host.style?.removeProperty?.('--fut-sbc-set-chip-row')
host.style?.removeProperty?.('--fut-sbc-set-chip-gap')
for(const row of Array.from(host.children??[])){row.style?.removeProperty?.('order')}
count+=1}catch{/* один ящик не роняет остальные */}}
return count}
