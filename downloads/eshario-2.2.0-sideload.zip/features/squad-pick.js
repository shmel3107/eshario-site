import{el,ensureSquadStyles} from '../ui/dom.js'
import{ensureControls,logoLink} from '../ui/controls.js'
import{PAGE_SIZE,PAGE_MARK} from './card-views.js'
import{SQUAD_FEATURE} from './squad-bar.js'
import{pickPanelOf,pickListOf,pickRowsOf,pickPinnedOf,
pickChemTagOf,pickRelayout,pickShow,pickPageItems,
clubSearchAll,clubHasAllItems,itemWords,itemRatingOf,
pickCriteriaOf} from '../adapter/squad-screen.js'
export const SQUAD_PICK_MARK='data-fut-squad-pick'
export const SQUAD_PICK_KEY='futSquadPick'
export const TOOK_CHEM='chem'
export const TOOK_FILTER='filter'
export const TOOK_TILE='tile'
export const TOOK_HEAD='head'
export const TOOK_FOUND='found'
const TOOLS_CLASS='fx-pick-tools'
const SEARCH_CLASS='fx-pick-search'
const SORTS_CLASS='fx-pick-sorts'
const COUNT_CLASS='fx-pick-count'
const CHEM_CLASS='fx-pick-chem'
const BEST_CLASS='fx-pick-best'
const COLS_VAR='--fut-pick-cols'
export const PICK_COLUMNS=4
export const SQUAD_FRAME_MARK='data-fut-squad-frame'
export const SQUAD_FRAME_KEY='futSquadFrame'
const FACE_VAR='--fut-pick-face'
const FACE_H_VAR='--fut-pick-face-h'
const FACE_PAD=8
const FACE_FLOOR=40
export const PICK_SORTS=Object.freeze(['chem','rating','price'])
const SORT_LABEL=Object.freeze({chem:'squadPick.sort.chem',
rating:'squadPick.sort.rating',price:'squadPick.sort.price'})
export const PICK_SORT_DEFAULT='chem'
export const PICK_QUERY_MIN=2
export const SQUAD_PICK_BUILD='SWAPGRID2-2'
export function pickChemModel(input={}){const delta=Number.isFinite(input.delta)?input.delta:null
if(delta===null)return{ok:false,reason:'no-number',text:'',tone:''}
const text=delta>0?`+${delta}`:delta<0?`−${Math.abs(delta)}`:'0'
const tone=delta>0?'ok':delta<0?'danger':'dim'
return{ok:true,reason:null,text,tone}}
export function pickBestModel(input={}){const deltas=Array.isArray(input.deltas)?input.deltas:[]
let best=null
for(const one of deltas){if(!Number.isFinite(one))continue
if(best===null||one>best)best=one}
if(best===null||best<=0)return[]
const out=[]
deltas.forEach((one,at)=>{if(one===best)out.push(at)})
return out}
const normalize=(value)=>String(value??'').normalize('NFD').replace(/[̀-ͯ]/g,'')
.toLowerCase().trim()
export function pickSearchModel(input={}){const rows=Array.isArray(input.rows)?input.rows:[]
const needle=normalize(input.query)
if(needle.length<PICK_QUERY_MIN)return{ok:false,reason:'short',needle,hits:[]}
const hits=[]
for(const row of rows){const words=Array.isArray(row?.words)?row.words:[]
let hit=false
for(const word of words){const text=normalize(word)
if(text===''){continue}
if(text.startsWith(needle)){hit=true
break}
for(const part of text.split(/[\s\-']+/)){if(part.startsWith(needle)){hit=true
break}}
if(hit)break}
if(hit&&Number.isSafeInteger(row.index))hits.push(row.index)}
return{ok:true,reason:null,needle,hits}}
export function pickOrderModel(input={}){const rows=Array.isArray(input.rows)?input.rows:[]
const key=PICK_SORTS.includes(input.key)?input.key:PICK_SORT_DEFAULT
const value=(row)=>{if(key==='rating')return Number.isFinite(row?.rating)?row.rating:null
if(key==='price')return Number.isFinite(row?.price)&&row.price>0?row.price:null
return Number.isFinite(row?.delta)?row.delta:null}
const sorted=rows.map((row,at)=>({at,index:Number.isSafeInteger(row?.index)?row.index:at,value:value(row)}))
sorted.sort((a,b)=>{if(a.value===null&&b.value===null)return a.at-b.at
if(a.value===null)return 1
if(b.value===null)return-1
if(a.value!==b.value)return b.value-a.value
return a.at-b.at})
const out=new Array(rows.length).fill(0)
sorted.forEach((one,place)=>{out[one.at]=place})
return out}
export function pickCountModel(input={}){const t=typeof input.t==='function'?input.t:(key)=>key
const found=Number.isSafeInteger(input.found)&&input.found>=0?input.found:0
const total=Number.isSafeInteger(input.total)&&input.total>=0?input.total:0
const shown=Number.isSafeInteger(input.shown)&&input.shown>=0?input.shown:0
if(input.ready===false)return{text:t('squadPick.reading'),title:t('squadPick.readingTitle'),tone:'dim'}
if(input.searching!==true)return{text:'',title:'',tone:'dim'}
if(found===0)return{text:t('squadPick.none'),title:t('squadPick.noneTitle'),tone:'dim'}
if(shown<found)return{text:t('squadPick.countMore',{shown,found}),title:t('squadPick.countTitle',{total}),tone:'ok'}
return{text:t('squadPick.count',{found,total}),title:t('squadPick.countTitle',{total}),tone:'ok'}}
export function pickGridModel(input={}){const boxW=Number.isFinite(input.box?.width)&&input.box.width>0?input.box.width:null
const boxH=Number.isFinite(input.box?.height)&&input.box.height>0?input.box.height:null
const faceW=Number.isFinite(input.face?.width)&&input.face.width>0?input.face.width:null
const faceH=Number.isFinite(input.face?.height)&&input.face.height>0?input.face.height:null
const tail=Number.isFinite(input.tail)&&input.tail>=0?input.tail:null
const page=Number.isSafeInteger(input.page)&&input.page>0?input.page:PAGE_SIZE
const gapX=Number.isFinite(input.gap?.x)&&input.gap.x>=0?input.gap.x:0
const gapY=Number.isFinite(input.gap?.y)&&input.gap.y>=0?input.gap.y:0
if(boxW===null||boxH===null||faceW===null||faceH===null||tail===null){
return{ok:false,reason:'no-measure',columns:0,rows:0,face:0,height:0,need:0,tried:[]}}
const columns=PICK_COLUMNS
const tile=Math.floor((boxW-gapX*(columns-1))/columns)
const rows=Math.ceil(page/columns)
const byWidth=Math.min(faceW,tile-FACE_PAD)
const perRow=Math.floor((boxH-gapY*(rows-1))/rows-tail)
const byHeight=Math.floor(perRow*(faceW/faceH))
const face=Math.max(Math.min(FACE_FLOOR,byWidth),Math.min(byWidth,byHeight))
const height=Math.round(face*(faceH/faceW))
const need=rows*(height+tail)+gapY*(rows-1)
const fits=need<=boxH
const tried=[{columns,tile,face,height,rows,need,fits,byWidth,byHeight}]
return{ok:true,reason:fits?null:'no-fit',columns,rows,face,height,need,tried}}
export function createSquadPick(deps={}){const doc=deps.doc??null
const win=deps.win??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const isActiveOf=typeof deps.isActive==='function'?deps.isActive:()=>true
const isActive=()=>isActiveOf(SQUAD_FEATURE)===true
const priceOf=typeof deps.priceOf==='function'?deps.priceOf:()=>null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let live=null
let last=null
let query=''
let sort=PICK_SORT_DEFAULT
let searching=false
let clubCache=null
let clubReady=null
let print=null
let facePrint=null
let topPrint=null
let reason=null
const stats={applies:0,paints:0,skips:0,holds:0,searches:0,shows:0,orders:0}
function стили(){ensureControls(doc)
ensureSquadStyles(doc)}
function rowsOf(capture){const items=Array.isArray(capture?.items)?capture.items:[]
const said=capture?.numbers??null
const deltas=Array.isArray(said?.delta)?said.delta:[]
const aligned=said!==null&&deltas.length===items.length&&Array.isArray(said.items)
&&said.items.length===items.length
const out=[]
items.forEach((item,at)=>{let price=null
try{price=priceOf(item)}catch{price=null}
out.push({index:at,item,
delta:aligned&&Number.isFinite(deltas[at])?deltas[at]:null,
rating:itemRatingOf(item),
price:Number.isFinite(price)&&price>0?price:null,
words:itemWords(win,item)})})
return{rows:out,aligned}}
function ensureTools(){if(live===null)return false
const pinned=pickPinnedOf(live.root)
if(pinned===null){if(live.tools!==null){live.tools.node.remove()
live.tools=null}
return false}
if(live.tools!==null&&live.tools.node.parentElement===pinned)return true
if(live.tools!==null)live.tools.node.remove()
live.tools=buildTools(pinned)
return true}
function buildTools(root){const stop=(event)=>event?.stopPropagation?.()
const label=t('squadPick.search')
const input=el(doc,'input',{class:`fx-search ${SEARCH_CLASS}`,
attrs:{type:'search',placeholder:label,'aria-label':label,title:t('squadPick.searchTitle')},
dataset:{futPickSearch:'1'},
on:{input:()=>{try{onQuery(input.value)}catch(err){onError(err)}}}})
const sorts=el(doc,'div',{class:SORTS_CLASS},PICK_SORTS.map((key)=>el(doc,'button',
{class:'fx-pick-sort',attrs:{type:'button',title:t('squadPick.sortTitle')},
dataset:{futPickSort:key},text:t(SORT_LABEL[key]),
on:{click:()=>{try{onSort(key)}catch(err){onError(err)}}}})))
const count=el(doc,'div',{class:COUNT_CLASS})
const tools=el(doc,'div',{class:TOOLS_CLASS,dataset:{futPickTools:'1'},
on:{mousedown:stop,touchstart:stop,click:stop}},
[el(doc,'div',{class:'fx-pick-line'},[logoLink(doc),input]),sorts,count])
root.appendChild(tools)
return{node:tools,input,sorts,count}}
function paintTools(model){if(live===null||live.tools===null)return
const{tools}=live
for(const button of tools.sorts.children){const on=button.dataset?.futPickSort===sort
if((button.getAttribute('aria-pressed')==='true')!==on)button.setAttribute('aria-pressed',on?'true':'false')}
if(tools.count.textContent!==model.text)tools.count.textContent=model.text
if(tools.count.getAttribute('title')!==model.title)tools.count.setAttribute('title',model.title)
if(tools.count.dataset.futPickTone!==model.tone)tools.count.dataset.futPickTone=model.tone}
function clearRow(row){const ours=row.querySelector?.(`.${CHEM_CLASS}`)
if(ours)ours.remove()
if(row.classList?.contains?.(BEST_CLASS)===true){row.classList.remove(BEST_CLASS)
row.removeAttribute?.('title')}
if(row.style?.order!=='')row.style.order=''}
function paintRows(rows,best){const nodes=pickRowsOf(live.root)
if(nodes.length!==rows.length)return{ok:false,reason:'rows-moved',painted:0}
const order=pickOrderModel({rows,key:sort})
let painted=0
nodes.forEach((node,at)=>{const model=pickChemModel({delta:rows[at]?.delta??null})
const tag=pickChemTagOf(node)
let ours=node.querySelector(`.${CHEM_CLASS}`)
if(!model.ok){if(ours)ours.remove()
node.classList.remove(BEST_CLASS)
return}
const host=tag?.parentElement??node.querySelector('.rowContent')??node
if(ours===null){ours=el(doc,'div',{class:CHEM_CLASS,attrs:{title:t('squadPick.chemTitle')}})
host.appendChild(ours)}
if(ours.textContent!==model.text)ours.textContent=model.text
if(ours.dataset.futPickTone!==model.tone)ours.dataset.futPickTone=model.tone
const isBest=best.includes(at)
if(node.classList.contains(BEST_CLASS)!==isBest){if(isBest){node.classList.add(BEST_CLASS)
node.setAttribute('title',t('squadPick.bestTitle'))}
else{node.classList.remove(BEST_CLASS)
node.removeAttribute('title')}}
painted+=1})
nodes.forEach((node,at)=>{const value=String(order[at]??0)
if(node.style.order!==value){node.style.order=value
stats.orders+=1}})
return{ok:painted>0,reason:painted>0?null:'no-numbers',painted}}
function fitTiles(){const list=pickListOf(live.root)
const nodes=pickRowsOf(live.root)
if(list===null||nodes.length===0)return
if(list.dataset?.[PAGE_MARK]!=='1')return
const boxW=Math.round(list.clientWidth)
const host=list.parentElement??list.parentNode??null
let boxH=Math.round(list.clientHeight)
const hostH=Math.round(Number(host?.clientHeight)||0)
if(hostH>0){let others=0
for(const kid of Array.from(host.children??[])){if(kid!==list)others+=Math.round(Number(kid?.offsetHeight)||0)}
boxH=Math.max(0,hostH-others)}
const stamp=`${boxW}x${boxH}|${nodes.length}|${live.root?.dataset?.[SQUAD_PICK_KEY]??''}`
if(stamp===facePrint)return
facePrint=stamp
const first=nodes[0]
const box=first?.querySelector?.('.entityContainer')??null
const card=box?.children?.[0]??null
if(!card)return
if(live.native===null){const w=Math.round(card.offsetWidth)
const h=Math.round(card.offsetHeight)
if(w>0&&h>0)live.native={face:w,height:h,tail:null}}
if(live.native===null)return
const tailNow=()=>{let tile=0
try{tile=Math.round(first.getBoundingClientRect?.()?.height??0)}catch{tile=0}
return Math.max(0,tile-Math.round(card.offsetHeight))}
let gapX=0
let gapY=0
try{const style=doc.defaultView?.getComputedStyle?.(list)??null
gapX=Number.parseFloat(style?.columnGap??'0')||0
gapY=Number.parseFloat(style?.rowGap??'0')||0}catch{gapX=0
gapY=0}
let tail=tailNow()
live.native.tail=tail
let model=null
let extra=0
for(let tries=0;tries<3;tries+=1){model=pickGridModel({box:{width:boxW,height:boxH},gap:{x:gapX,y:gapY},
face:{width:live.native.face,height:live.native.height},tail:tail+extra,page:PAGE_SIZE})
if(!model.ok)break
list.style.setProperty(COLS_VAR,String(model.columns))
list.style.setProperty(FACE_VAR,`${model.face}px`)
list.style.setProperty(FACE_H_VAR,`${model.height}px`)
let over=null
try{const said=[list.scrollHeight-list.clientHeight]
if(hostH>0)said.push(host.scrollHeight-host.clientHeight)
const known=said.filter((one)=>Number.isFinite(one))
over=known.length>0?Math.max(0,Math.round(Math.max(...known))):null}catch{over=null}
model.over=over
if(over===null||over===0)break
if(model.face<=FACE_FLOOR)break
extra+=Math.ceil(over/model.rows)}
live.grid=model===null?{ok:false,reason:'no-measure',columns:0,rows:0,face:0,height:0,need:0,tried:[]}:{...model,tail,extra}
live.face=model!==null&&model.ok?{ok:true,reason:model.reason,
face:model.face,height:model.height}:{ok:false,reason:model?.reason??'no-measure',face:0,height:0}
if(model===null||!model.ok){list.style.removeProperty(COLS_VAR)
list.style.removeProperty(FACE_VAR)
list.style.removeProperty(FACE_H_VAR)}}
function clubOf(){if(clubCache!==null)return clubCache
const criteria=pickCriteriaOf(live?.controller)
if(criteria===null)return null
clubReady=clubHasAllItems(win,criteria)
const found=clubSearchAll(win,criteria)
if(found===null)return null
clubCache=found.map((item,at)=>({index:at,item,words:itemWords(win,item)}))
return clubCache}
function onQuery(value){query=String(value??'')
const club=clubOf()
const model=pickSearchModel({rows:club??[],query})
if(!model.ok){
restorePage()
return}
if(club===null){reason='no-club'
return}
if(model.hits.length===0&&clubReady===false){reason='club-reading'
restorePage()
return}
stats.searches+=1
const items=model.hits.slice(0,PAGE_SIZE).map((at)=>club[at]?.item).filter((one)=>one!==undefined)
live.found={total:club.length,hits:model.hits.length}
searching=true
if(pickShow(live.controller,items))stats.shows+=1}
function giveBackPage(){searching=false
live.found=null
const page=pickPageItems(live.controller)
if(page===null)return false
if(pickShow(live.controller,page))stats.shows+=1
return true}
function restorePage(){if(live===null)return
if(!searching){paint()
return}
if(!giveBackPage())paint()}
function onSort(key){if(!PICK_SORTS.includes(key))return
sort=key
paint()}
function marksOf(state){const words=[]
if(state.chem)words.push(TOOK_CHEM)
if(state.filter)words.push(TOOK_FILTER)
if(state.tile)words.push(TOOK_TILE)
if(state.head)words.push(TOOK_HEAD)
if(state.found)words.push(TOOK_FOUND)
return words.join(' ')}
function emptyHeadOf(){const bar=live?.root?.querySelector?.('[data-fut-card-bar], .fx-card-bar')??null
if(bar===null)return false
const kids=Array.from(bar.children??[])
if(kids.length===0)return true
return kids.every((one)=>one?.classList?.contains?.('fx-mark-link')===true)}
function unmount(){if(live===null)return
try{for(const row of pickRowsOf(live.root))clearRow(row)}catch{/* панель уже чужая */}
try{live.tools?.node?.remove?.()}catch{/* узел уже снят */}
try{const list=pickListOf(live.root)
if(list!==null){list.style.removeProperty(COLS_VAR)
list.style.removeProperty(FACE_VAR)
list.style.removeProperty(FACE_H_VAR)}}catch{/* списка уже нет */}
try{delete live.root.dataset[SQUAD_PICK_KEY]}catch{/* узел уже чужой */}
try{pickRelayout(live.view)}catch{/* вид уже снят */}
live=null
print=null
facePrint=null
topPrint=null}
function leave(){if(live===null)return
if(searching&&live.root?.isConnected===true)giveBackPage()
unmount()}
function apply(capture){if(!doc||!capture)return
stats.applies+=1
try{
if(!isActive()){unmount()
reason='off'
return}
const root=pickPanelOf(capture.root)
if(root===null){
if(live!==null&&live.root?.isConnected===true){stats.holds+=1
reason='panel-held'}
else{unmount()
reason='no-panel'}
return}
if(live!==null&&live.root!==root)unmount()
if(live===null){стили()
live={root,view:capture.view,controller:capture.controller,tools:null,
native:null,face:null,grid:null,found:null}
query=''
sort=PICK_SORT_DEFAULT
searching=false
clubCache=null
clubReady=null}
live.view=capture.view
live.controller=capture.controller
last=capture
paint(capture)}
catch(err){onError(err)}}
function paint(capture=last){if(live===null||capture===null)return
const said=rowsOf(capture)
const best=pickBestModel({deltas:said.rows.map((one)=>one.delta)})
const tools=ensureTools()
fitTiles()
const numbers=paintRows(said.rows,best)
const count=pickCountModel({t,found:live.found?.hits??0,total:live.found?.total??0,
shown:said.rows.length,ready:clubReady,searching})
paintTools(count)
const state={chem:numbers.ok,filter:tools,tile:live.face?.ok===true,
head:emptyHeadOf(),found:searching}
const words=marksOf(state)
const stamp=[words,numbers.painted,count.text,sort,live.face?.face??0,
live.grid?.columns??0].join('|')
if(stamp===print){stats.skips+=1
return}
if(live.root.dataset[SQUAD_PICK_KEY]!==words)live.root.dataset[SQUAD_PICK_KEY]=words
print=stamp
reason=numbers.reason
stats.paints+=1
const pinned=pickPinnedOf(live.root)
let height=0
try{height=Math.round(pinned?.getBoundingClientRect?.()?.height??0)}catch{height=0}
const topStamp=`${words}|${height}`
if(topStamp!==topPrint){topPrint=topStamp
pickRelayout(live.view)}}
function wake(){if(last===null||!isActive())return
const capture=last
last=null
if(pickPanelOf(capture.root)===null)return
const page=pickPageItems(capture.controller)
if(page===null)return
if(pickShow(capture.controller,page))stats.shows+=1}
function frame(){const html=doc?.documentElement??null
if(!html?.dataset)return false
const on=isActive()
if(on){if(html.dataset[SQUAD_FRAME_KEY]!=='1'){ensureSquadStyles(doc)
html.dataset[SQUAD_FRAME_KEY]='1'}
return true}
if(html.dataset[SQUAD_FRAME_KEY]!==undefined)delete html.dataset[SQUAD_FRAME_KEY]
return false}
function refresh(){try{frame()}catch(err){onError(err)}
try{if(live===null){wake()
return}
if(!isActive()){leave()
reason='off'
return}
if(live.root?.isConnected===false){unmount()
reason='panel-gone'
return}
if(last!==null)paint()}catch(err){onError(err)}}
function dispose(){leave()
try{const html=doc?.documentElement??null
if(html?.dataset&&html.dataset[SQUAD_FRAME_KEY]!==undefined)delete html.dataset[SQUAD_FRAME_KEY]}catch(err){onError(err)}
last=null
clubCache=null
clubReady=null}
function state(){return{build:SQUAD_PICK_BUILD,ok:live!==null,reason,mark:SQUAD_PICK_MARK,
frame:doc?.documentElement?.dataset?.[SQUAD_FRAME_KEY]==='1',
print,query,sort,searching,ready:clubReady,
club:clubCache===null?null:clubCache.length,
found:live?.found??null,face:live?.face??null,grid:live?.grid??null,
native:live?.native??null,
applies:stats.applies,paints:stats.paints,skips:stats.skips,holds:stats.holds,
searches:stats.searches,shows:stats.shows,orders:stats.orders}}
return{apply,refresh,dispose,state}}
