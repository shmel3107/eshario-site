export const BULK_PAUSE_MIN_MS=1200
export const BULK_PAUSE_SPREAD_MS=1300
export const BULK_ANSWER_TIMEOUT_MS=20_000
export const BULK_HOLD_POLL_MS=250
export const BULK_HOLD_MAX_MS=10*60_000
export const BULK_HOLD_LAST='last'
const BULK_BUILD='STORFIX-1'
export const BULK_REASON_SERVER='server'
export const BULK_HOLD_RETRY='retry'
export const BULK_SERVER_RETRIES=1
export const BULK_DROP_RATING_MIN=86
const CODE_UNASSIGNED=471
const CODE_CAPTCHA=458
const CODE_RATE_LIMIT=429
const CODES_CRITICAL=Object.freeze([401,468,474,20_000,20_004])
const CODE_SERVER_MIN=500
const CODE_SERVER_MAX=599
export function bulkStopReason(code){if(code===CODE_UNASSIGNED)return 'unassigned'
if(code===CODE_CAPTCHA)return 'captcha'
if(code===CODE_RATE_LIMIT)return 'rate-limit'
if(CODES_CRITICAL.includes(code))return 'critical'
if(Number.isInteger(code)&&code>=CODE_SERVER_MIN&&code<=CODE_SERVER_MAX)return BULK_REASON_SERVER
return 'ea-error'}
export function bulkDoorReason(reason){if(reason==='unassigned')return{hold:true,park:false,name:'unassigned'}
if(reason==='locked')return{hold:false,park:false,name:'locked'}
if(reason==='not-found')return{hold:false,park:false,name:'gone'}
if(reason==='pending-picks'||reason==='player-pick-unsupported')return{hold:false,park:false,name:'pick'}
if(reason==='day-budget')return{hold:false,park:true,name:'budget'}
if(reason==='counter-unavailable')return{hold:false,park:true,name:'counter'}
return{hold:false,park:true,name:'door'}}
export function bulkPauseMs(random){const value=typeof random==='number'&&Number.isFinite(random)&&random>=0&&random<1?random:0.5
return BULK_PAUSE_MIN_MS+Math.round(value*BULK_PAUSE_SPREAD_MS)}
export function bulkDrop(cards,ratingMin=BULK_DROP_RATING_MIN){const list=Array.isArray(cards)?cards:[]
const min=Number.isFinite(ratingMin)?ratingMin:BULK_DROP_RATING_MIN
let best=null
for(const card of list){if(card?.player!==true)continue
const rating=typeof card.rating==='number'&&Number.isFinite(card.rating)?card.rating:null
const special=card.special===true
if(!special&&!(rating!==null&&rating>=min))continue
const one={name:typeof card.name==='string'?card.name:'',rating,special}
if(best===null){best=one
continue}
if((one.rating??-1)>(best.rating??-1))best=one}
return best}
export function createPackBulk(deps={}){const open=typeof deps.open==='function'?deps.open:null
const readRating=typeof deps.ratingMin==='function'?deps.ratingMin:()=>BULK_DROP_RATING_MIN
const ratingNow=()=>{try{const value=readRating()
return Number.isFinite(value)?value:BULK_DROP_RATING_MIN}catch{return BULK_DROP_RATING_MIN}}
const pileCount=typeof deps.pileCount==='function'?deps.pileCount:null
const pileFresh=typeof deps.pileFresh==='function'?deps.pileFresh:()=>true
const warm=typeof deps.warm==='function'?deps.warm:null
const locked=typeof deps.locked==='function'?deps.locked:()=>false
const delay=typeof deps.delay==='function'?deps.delay:null
const cancel=typeof deps.cancel==='function'?deps.cancel:()=>{}
const elapsed=typeof deps.elapsed==='function'?deps.elapsed:()=>0
const random=typeof deps.random==='function'?deps.random:Math.random
const onChange=typeof deps.onChange==='function'?deps.onChange:()=>{}
const onDone=typeof deps.onDone==='function'?deps.onDone:()=>{}
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let run=null
let last=null
let timer=null
let warms=0
const changed=()=>{try{onChange()}catch(err){onError(err)}}
function clearTimer(){if(timer===null)return
try{cancel(timer)}catch(err){onError(err)}
timer=null}
const shot=(reason,running,parked=false)=>({key:run.key,total:run.total,opened:run.opened,reason,running,
parked,
hold:running?run.hold??null:null,
code:run.code??null,
retries:run.retries??0,
poured:run.poured??null,
drop:run.drop?{...run.drop}:null})
function finish(reason,parked=false){if(!run)return null
clearTimer()
last=shot(reason,false,parked)
run=null
changed()
try{onDone(reason)}catch(err){onError(err)}
return last}
function hold(reason){if(!run)return null
if(elapsedNow()>=BULK_HOLD_MAX_MS)return finish('idle')
const was=run.hold
run.hold=reason
run.waiting=false
if(was!==reason)changed()
timer=delay===null?null:delay(BULK_HOLD_POLL_MS,()=>{timer=null
try{step()}catch(err){onError(err)
finish('failed')}})
if(timer===null)return finish('failed')
return null}
function pauseThenStep(){timer=delay===null?null:delay(bulkPauseMs(random()),()=>{timer=null
try{step()}catch(err){onError(err)
finish('failed')}})
if(timer===null)finish('failed')}
function elapsedNow(){try{const value=elapsed()
return Number.isFinite(value)&&value>=0?value:0}catch(err){onError(err)
return 0}}
function step(){if(!run)return
clearTimer()
if(run.opened>=run.total)return settleLast()
let stopped=false
try{if(locked(run.key)===true)stopped=true}catch(err){onError(err)
stopped=true}
if(stopped)return finish('locked')
let fresh=null
try{fresh=pileFresh()}catch(err){onError(err)
fresh=null}
if(fresh===false&&run.opened>0)return hold('unassigned')
const pile=pileCount===null?null:pileCount()
if(pile===null)return finish('unknown')
if(pile>0)return hold('unassigned')
run.poured=null
run.drop=null
fire()}
function settleLast(){let fresh=null
try{fresh=pileFresh()}catch(err){onError(err)
fresh=null}
if(fresh===false)return hold(BULK_HOLD_LAST)
const pile=pileCount===null?null:pileCount()
if(pile===null)return finish('unknown')
if(pile>0)return hold(BULK_HOLD_LAST)
return finish('done')}
function fire(){const token=run.token
run.hold=null
run.waiting=true
changed()
timer=delay===null?null:delay(BULK_ANSWER_TIMEOUT_MS,()=>{timer=null
if(run?.waiting===true)finish('timeout')})
if(timer===null){finish('failed')
return}
let answer=null
try{answer=open(run.key)}catch(err){onError(err)
answer={ok:false,reason:'failed'}}
Promise.resolve(answer).then((value)=>settleDoor(token,value),(err)=>{onError(err)
settleDoor(token,{ok:false,reason:'failed'})})}
function settleDoor(token,answer){if(!run||run.token!==token||run.waiting!==true)return
if(answer?.ok===true)return
clearTimer()
run.waiting=false
const code=Number.isInteger(answer?.code)?answer.code:null
if(code!==null){run.code=code
const word=bulkStopReason(code)
finish(word,word===BULK_REASON_SERVER||word==='rate-limit')
return}
const{hold:wait,park,name}=bulkDoorReason(answer?.reason)
if(wait)hold(name)
else finish(name,park===true)}
function note(answer){if(run?.waiting!==true){
if(run===null&&last!==null&&answer?.ok===true){last=null
changed()}
return false}
clearTimer()
run.waiting=false
run.token+=1
if(answer?.ok!==true){const code=Number.isInteger(answer?.code)?answer.code:null
run.code=code
const reason=bulkStopReason(code)
if(reason==='unassigned'){hold('unassigned')
return true}
if(reason===BULK_REASON_SERVER&&run.serverStreak<BULK_SERVER_RETRIES){run.serverStreak+=1
run.retries+=1
run.hold=BULK_HOLD_RETRY
changed()
pauseThenStep()
return true}
finish(reason)
return true}
run.opened+=1
run.code=null
run.serverStreak=0
run.poured=Array.isArray(answer?.cards)?answer.cards.length:null
const drop=bulkDrop(Array.isArray(answer?.drops)?answer.drops:null,ratingNow())
if(drop)run.drop=drop
changed()
if(run.opened>=run.total){hold(BULK_HOLD_LAST)
return true}
if(warm!==null){warms+=1
try{warm()}catch(err){onError(err)}}
pauseThenStep()
return true}
function start(key,total){if(typeof key!=='string'||key===''||!Number.isSafeInteger(total)||total<2)return false
if(run){if(run.key===key){finish('stopped')
return true}
return false}
if(open===null||pileCount===null||delay===null)return false
last=null
run={key,total,opened:0,waiting:false,hold:null,poured:null,drop:null,token:1,code:null,retries:0,serverStreak:0}
changed()
try{step()}catch(err){onError(err)
finish('failed')}
return true}
function stop(reason='stopped'){if(!run)return false
finish(reason)
return true}
const resumable=(one)=>one!==null&&one!==undefined&&(one.reason==='stopped'||one.parked===true)
function resume(){if(run)return false
if(!resumable(last))return false
if(open===null||pileCount===null||delay===null)return false
run={key:last.key,total:last.total,opened:last.opened,waiting:false,hold:null,poured:null,drop:null,token:1,code:null,retries:0,serverStreak:0}
last=null
changed()
try{step()}catch(err){onError(err)
finish('failed')}
return true}
return{start,stop,note,resume,
isRunning:(key)=>run!==null&&(key===undefined||run.key===key),
canResume:(key)=>run===null&&resumable(last)&&(key===undefined||last.key===key),
parked:(key)=>(run===null&&last?.parked===true&&(key===undefined||last.key===key)?{...last}:null),
statusOf:(key)=>{if(run?.key===key)return shot(null,true)
if(last?.key===key)return{...last}
return null},
current:()=>(run?shot(null,true):(last?{...last}:null)),
state:()=>({build:BULK_BUILD,running:run?{...run}:null,last:last?{...last}:null,waitedMs:run?elapsedNow():0,
warms,
door:'adapter',
rule:{pauseMinMs:BULK_PAUSE_MIN_MS,pauseSpreadMs:BULK_PAUSE_SPREAD_MS,answerTimeoutMs:BULK_ANSWER_TIMEOUT_MS,
holdPollMs:BULK_HOLD_POLL_MS,holdMaxMs:BULK_HOLD_MAX_MS,dropRatingMin:ratingNow(),
serverRetries:BULK_SERVER_RETRIES}}),
dispose(){clearTimer()
run=null
last=null}}}
