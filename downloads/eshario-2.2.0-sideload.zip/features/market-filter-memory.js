import{FIELD_NAMES,FILTER_FIELDS,isValidValue} from './filters.js'
import{EPOCH_REASON} from '../adapter/session-epoch.js'
export const MARKET_MEMORY_BUILD='M2TPL'
export const SKIP_FIELDS=Object.freeze(['count','offset','sort','sortBy'])
export const RESTORE_TRIES=5
export function defaultMarketFilterView(){return{criteria:null}}
function sameValue(a,b){if(Array.isArray(a)||Array.isArray(b)){if(!Array.isArray(a)||!Array.isArray(b))return false
if(a.length!==b.length)return false
return a.every((one,at)=>one===b[at])}
return a===b}
export function changedAgainst(criteria,defaults=null){const out={}
if(!criteria||typeof criteria!=='object'||Array.isArray(criteria))return out
const base=defaults&&typeof defaults==='object'&&!Array.isArray(defaults)?defaults:null
for(const name of FIELD_NAMES){if(SKIP_FIELDS.includes(name))continue
if(!Object.hasOwn(criteria,name))continue
const value=criteria[name]
if(!isValidValue(name,value))continue
const empty=base!==null&&Object.hasOwn(base,name)?base[name]:FILTER_FIELDS[name].default
if(sameValue(value,empty))continue
out[name]=Array.isArray(value)?[...value]:value}
return out}
export function sanitizeStoredCriteria(stored){if(!stored||typeof stored!=='object'||Array.isArray(stored))return null
const out={}
for(const name of FIELD_NAMES){if(SKIP_FIELDS.includes(name))continue
if(!Object.hasOwn(stored,name))continue
const value=stored[name]
if(!isValidValue(name,value))continue
out[name]=Array.isArray(value)?[...value]:value}
return Object.keys(out).length===0?null:out}
export function sanitizeMarketFilterView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
return{criteria:sanitizeStoredCriteria(raw.criteria)}}
export function printCriteria(criteria){if(criteria===null||criteria===undefined)return ''
const names=Object.keys(criteria).sort()
return names.map((name)=>`${name}=${JSON.stringify(criteria[name])}`).join(' · ')}
export function createMarketFilterMemory(deps={}){const{doc}=deps
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const screenOf=typeof deps.screen==='function'?deps.screen:null
const readLive=typeof deps.live==='function'?deps.live:null
const readDefaults=typeof deps.defaults==='function'?deps.defaults:null
const restoreTo=typeof deps.restore==='function'?deps.restore:null
const readMemory=typeof deps.memory==='function'?deps.memory:null
const writeMemory=typeof deps.setMemory==='function'?deps.setMemory:null
const readSearched=typeof deps.searched==='function'?deps.searched:null
let root=null
let tries=0
let printed=null
let listening=null,onChange=null,onPress=null
let notice=''
let restored=false
let ourStamp=null
let seenName=null
let seenStamp=null
let seenRest=null
let storeSeen=null
let passes=0,mounts=0,restores=0,samples=0,writes=0,refusals=0,overrides=0,names=0
const liveNow=()=>{if(readLive===null)return null
try{return readLive()??null}catch(err){onError(err)
return null}}
const defaultsNow=()=>{if(readDefaults===null)return null
try{return readDefaults()??null}catch(err){onError(err)
return null}}
function searchStamp(){if(readSearched===null)return null
let said=null
try{said=readSearched()}catch(err){onError(err)
return null}
if(said===null||said===undefined)return null
const set=sanitizeStoredCriteria(said)
return set===null?null:printCriteria(set)}
function ourTurn(){if(ourStamp===null)return false
const now=searchStamp()
if(now===null)return false
if(now===ourStamp)return true
ourStamp=null
return false}
function nameToRefill(want,held){if(want===null||want===undefined)return null
if(!Number.isSafeInteger(seenName)||seenName<=0)return null
const onForm=held?.maskedDefId
if(onForm!==undefined&&onForm!==0)return null
const mineNoName={...want}
const hersNoName={...held}
delete mineNoName.maskedDefId
delete hersNoName.maskedDefId
const rest=printCriteria(hersNoName)
if(printCriteria(mineNoName)!==rest)return null
if(rest!==seenRest)return null
return seenName}
function typing(node){try{const active=doc?.activeElement??null
if(active===null||active===undefined||node===null||active===node)return false
for(let at=active;at!==null&&at!==undefined;at=at.parentNode??null){if(at===node)return true}
return false}catch{return false}}
function take(node){if(readMemory===null)return true
let said=null
try{said=readMemory()}catch(err){onError(err)
return true}
if(said===null||said===undefined)return false
const want=sanitizeStoredCriteria(said.criteria)
if(want===null){restored=false
notice=''
printed=printCriteria(null)
return true}
if(typing(node))return false
const held=changedAgainst(liveNow()?.criteria??null,defaultsNow()?.criteria??null)
const busy=Object.keys(held).length>0
const mine=busy?ourTurn():false
const refill=busy&&!mine?nameToRefill(want,held):null
if(busy&&!mine&&refill===null){restored=false
notice='live-form'
return true}
if(restoreTo===null)return true
const target=refill===null?want:{...want,maskedDefId:refill}
let res=null
try{res=restoreTo(target)}catch(err){onError(err)
res={ok:false,reason:String(err?.message??err)}}
restores+=1
if(res?.ok===true){restored=true
if(mine)overrides+=1
if(refill!==null)names+=1
notice=''
printed=printCriteria(target)
return true}
restored=false
notice=String(res?.reason??'no-screen')
tries+=1
return tries>=RESTORE_TRIES}
function sample(){const said=liveNow()
const criteria=said?.criteria??null
if(criteria===null)return false
samples+=1
const changed=changedAgainst(criteria,defaultsNow()?.criteria??null)
const sawName=changed.maskedDefId
const restNow=(()=>{const rest={...changed}
delete rest.maskedDefId
return printCriteria(rest)})()
if(Number.isSafeInteger(sawName)&&sawName>0){seenName=sawName
seenStamp=searchStamp()
seenRest=restNow}
else if(seenName!==null&&restNow!==seenRest){
seenName=null
seenStamp=null
seenRest=null}
else if(seenName!==null){
const now=searchStamp()
const wiped=now!==null&&seenStamp!==null&&now!==seenStamp
if(!wiped){seenName=null
seenStamp=null
seenRest=null}}
const value=Object.keys(changed).length===0?null:changed
const print=printCriteria(value)
if(printed!==null&&print===printed)return false
if(writeMemory===null){printed=print
markOurs()
return true}
let res=null
try{res=writeMemory({criteria:value})}catch(err){onError(err)
res={ok:false,reason:String(err?.message??err)}}
if(res?.ok!==true){refusals+=1
notice=String(res?.reason??'refused')
return false}
writes+=1
printed=print
markOurs()
return true}
function markOurs(){const now=searchStamp()
if(now===null){ourStamp=null
return}
if(storeSeen!==null&&now!==storeSeen){storeSeen=now
ourStamp=null
return}
storeSeen=now
ourStamp=now}
function listen(node){unlisten()
if(typeof node?.addEventListener!=='function')return
onChange=()=>{try{sample()}catch(err){onError(err)}}
onPress=()=>{try{sample()}catch(err){onError(err)}}
node.addEventListener('change',onChange,false)
node.addEventListener('mousedown',onPress,true)
node.addEventListener('click',onPress,false)
listening=node}
function unlisten(){if(listening!==null){if(onChange!==null){try{listening.removeEventListener('change',onChange,false)}catch{
}}
if(onPress!==null){try{listening.removeEventListener('mousedown',onPress,true)}catch{/* узел уехал */}
try{listening.removeEventListener('click',onPress,false)}catch{/* узел уехал */}}}
listening=null
onChange=null
onPress=null}
function refresh(){if(!doc||screenOf===null)return false
passes+=1
let node=null
try{node=screenOf(doc)??null}catch(err){onError(err)
node=null}
if(node===null){if(root!==null){unlisten()
root=null
tries=0}
return false}
if(node!==root){if(root!==null||listening!==null)unlisten()
if(!take(node))return false
root=node
tries=0
mounts+=1
listen(node)}
sample()
return true}
function forget(event=null){if(event?.reason!==EPOCH_REASON.SWITCHED)return false
restored=false
notice=''
printed=''
ourStamp=null
storeSeen=null
seenName=null
seenRest=null
if(writeMemory===null)return true
try{const res=writeMemory({criteria:null})
if(res?.ok!==true){refusals+=1
notice=String(res?.reason??'refused')
printed=null}}catch(err){onError(err)
printed=null}
return true}
return{refresh,forget,
noteWrite(){let wrote=false
try{wrote=sample()}catch(err){onError(err)}
markOurs()
return wrote},
state(){let node=null
try{node=screenOf===null?null:screenOf(doc)??null}catch{node=null}
let said=null
try{said=readMemory===null?null:readMemory()}catch{said=null}
return{build:MARKET_MEMORY_BUILD,
screen:node!==null,
held:root!==null&&root===node,
restored,
notice,
loaded:said!==null&&said!==undefined,
memory:printCriteria(said===null||said===undefined?null:sanitizeStoredCriteria(said.criteria)),
print:printed,
live:printCriteria(changedAgainst(liveNow()?.criteria??null,defaultsNow()?.criteria??null)),
stampOurs:ourStamp,stampNow:searchStamp(),
seenName,
work:{passes,mounts,restores,samples,writes,refusals,overrides,names}}},
dispose(){unlisten()
root=null
tries=0
printed=null
ourStamp=null
storeSeen=null
seenName=null
seenRest=null}}}
