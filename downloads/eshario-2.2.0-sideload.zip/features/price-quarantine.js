import{stepFrom} from './price-ladder.js'
export const QUARANTINE_FACTOR=2
export const QUARANTINE_KEEP=2000
const LADDER_FAMILIES=['rarityLadders','leagueLadders','nationLadders','clubLadders']
const countOf=(step)=>Number.isFinite(step?.count)?step.count:(Array.isArray(step?.picks)?step.picks.length:0)
const isPrice=(value)=>typeof value==='number'&&Number.isFinite(value)&&value>0
const idOrNull=(value)=>Number.isSafeInteger(value)&&value>0?value:null
export function quarantineScopes(prices){const out=new Set()
if(!prices||typeof prices!=='object')return out
if(Array.isArray(prices.ladder))out.add('ladder')
if(prices.byRarity&&typeof prices.byRarity==='object')out.add('byRarity')
for(const family of LADDER_FAMILIES){const ladders=prices[family]
if(!ladders||typeof ladders!=='object')continue
for(const key of Object.keys(ladders))out.add(`${family}:${key}`)}
return out}
export function createPriceQuarantine(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function')throw new Error('price-quarantine: нужны часы (правило 6 NIGHT_BRIEF)')
const liveOf=typeof deps.liveOf==='function'?deps.liveOf:null
const factor=Number.isFinite(deps.factor)&&deps.factor>1?deps.factor:QUARANTINE_FACTOR
const keep=Number.isSafeInteger(deps.keep)&&deps.keep>0?deps.keep:QUARANTINE_KEEP
const memo=new Map()
const stats={holds:0,confirmed:0,live:0,dropped:0}
const remember=(key,entry)=>{memo.delete(key)
memo.set(key,entry)
while(memo.size>keep)memo.delete(memo.keys().next().value)}
const liveFor=(id)=>{if(liveOf===null||id===null)return null
try{const price=liveOf(id)
return isPrice(price)?price:null}catch{return null}}
const rule=(key,price,id,body)=>{if(!isPrice(price))return null
const now=clock.now()
const known=memo.get(key)
if(known===undefined||!isPrice(known.price)||price*factor>=known.price){remember(key,{price,id,body,at:now,pending:null})
return null}
if(liveFor(id)!==null){stats.live+=1
remember(key,{price,id,body,at:now,pending:null})
return null}
if(known.pending!==null){stats.confirmed+=1
remember(key,{price,id,body,at:now,pending:null})
return null}
stats.holds+=1
const held={...known,pending:{price,id,since:now}}
remember(key,held)
return held}
const guardStep=(scope,step)=>{const rating=step?.rating
if(!Number.isFinite(rating))return step
const key=`${scope}#${rating}`
const held=rule(key,step?.price,idOrNull(step?.id),step)
if(held===null)return step
const floor=held.price/factor
const picks=Array.isArray(step?.picks)?step.picks:[]
const rest=picks.filter((one)=>!(isPrice(one?.price)&&one.price<floor))
const dropped=picks.length-rest.length
stats.dropped+=dropped
const fresh=dropped===0?null:stepFrom(rating,rest,countOf(step)-dropped)
const mark={held:held.price,suspect:held.pending.price,suspectId:held.pending.id,since:held.pending.since,dropped}
if(fresh!==null)return{...step,...fresh,quarantine:mark}
return{...held.body,quarantine:{...mark,kept:true}}}
const guardSteps=(scope,steps)=>{if(!Array.isArray(steps))return steps
let changed=false
const out=[]
for(const step of steps){const next=guardStep(scope,step)
if(next!==step)changed=true
out.push(next)}
return changed?out:steps}
return{guardSteps,
guardLadders(family,ladders){if(!ladders||typeof ladders!=='object')return ladders
let changed=false
const out={}
for(const key of Object.keys(ladders)){const next=guardSteps(`${family}:${key}`,ladders[key])
if(next!==ladders[key])changed=true
out[key]=next}
return changed?out:ladders},
guardPrices(scope,map){if(!map||typeof map!=='object')return map
let changed=false
const out={}
for(const key of Object.keys(map)){const held=rule(`${scope}#${key}`,map[key],null,map[key])
out[key]=held===null?map[key]:held.price
if(out[key]!==map[key])changed=true}
return changed?out:map},
suspects(prices){const scopes=prices===undefined||prices===null?null:quarantineScopes(prices)
const out=[]
for(const[key,entry]of memo){if(entry.pending===null||entry.pending.id===null)continue
const cut=key.lastIndexOf('#')
const scope=key.slice(0,cut)
if(scopes!==null&&!scopes.has(scope))continue
out.push({id:entry.pending.id,rating:Number(key.slice(cut+1)),prior:entry.price,scope})}
out.sort((a,b)=>b.prior-a.prior)
return out},
list(){const out=[]
for(const[key,entry]of memo){if(entry.pending===null)continue
const cut=key.lastIndexOf('#')
out.push({scope:key.slice(0,cut),step:Number(key.slice(cut+1)),
held:entry.price,suspect:entry.pending.price,suspectId:entry.pending.id,since:entry.pending.since})}
return out},
state(){let now=0
for(const[,entry]of memo){if(entry.pending!==null)now+=1}
return{factor,keep,keys:memo.size,now,...stats}}}}
