const arr=Array.isArray
const int=Number.isSafeInteger
const bad=(reason)=>({ok:false,reason})
function valid(s){if(!arr(s?.items)||!int(s.availablePicks)
||s.availablePicks<1||s.availablePicks>s.items.length)return null
const ids=s.items.map((item)=>item?.index)
if(ids.some((index)=>!int(index)||index<0)
||new Set(ids).size!==ids.length)return null
return new Set(ids)}
export function setPlayerPickSelection(s,i,on){const ids=valid(s)
if(!ids?.has(i)||typeof on!=='boolean'||!arr(s.selected))return false
const sel=[...s.selected]
if(sel.some((value)=>!ids.has(value))
||new Set(sel).size!==sel.length||sel.length>s.availablePicks)return false
const at=sel.indexOf(i)
if(on&&at<0){if(sel.length>=s.availablePicks)return false
sel.push(i)}else if(!on&&at>=0)sel.splice(at,1)
s.selected=sel
return true}
export function reviewPlayerPickSelection(s){const ids=valid(s)
if(!ids||!arr(s.selected))return bad('invalid')
if(s.selected.length!==s.availablePicks)return bad('incomplete')
if(new Set(s.selected).size!==s.selected.length
||s.selected.some((i)=>!ids.has(i)))return bad('invalid')
const by=new Map(s.items.map((item)=>[item.index,item]))
return{ok:true,reason:null,items:s.selected.map((i)=>by.get(i))}}
export function pickPolicy(s){if(!valid(s)||s.items.some((item)=>!int(item?.rating)||item.rating<0)){return bad('invalid')}
s.selected=[...s.items].sort((a,b)=>b.rating-a.rating||a.index-b.index)
.slice(0,s.availablePicks).map((i)=>i.index)
return reviewPlayerPickSelection(s)}
export async function pricePickPolicy(s,priceOf){if(!valid(s)||typeof priceOf!=='function'
||s.items.some((x)=>!int(x?.definitionId)||x.definitionId<1
||!int(x.rating)||x.rating<0||typeof x.tradable!=='boolean'))return bad('invalid')
const n=s.availablePicks
const snap=s.items.map(({index,definitionId,rating,tradable})=>({index,definitionId,rating,tradable}))
let prices
try{prices=await Promise.all(snap.map(priceOf))}catch{return bad('price-unavailable')}
if(s.availablePicks!==n||!valid(s)||s.items.length!==snap.length
||snap.some((x,i)=>Object.entries(x).some(([k,v])=>s.items[i]?.[k]!==v)))
return bad('stale')
const ranked=snap.map((x,i)=>({...x,price:prices[i]}))
.filter((x)=>int(x.price)&&x.price>0)
if(ranked.length<n)return bad('price-unavailable')
s.selected=ranked.sort((a,b)=>b.price-a.price||b.rating-a.rating||a.index-b.index)
.slice(0,n).map((x)=>x.index)
return reviewPlayerPickSelection(s)}
export async function runPickStep({adapter:a,state:s,confirmed}={}){if(confirmed!==true)return bad('not-confirmed')
const review=reviewPlayerPickSelection(s)
if(!review.ok)return review
if(typeof a?.pendingPicks!=='function'||typeof a?.reviewPicks!=='function'
||typeof a?.confirmPicks!=='function')return bad('guard-unavailable')
const n=s.availablePicks
const ids=[...s.selected]
Object.assign(s,{items:[],availablePicks:0,selected:[],review:null,loaded:false})
let sent=false
try{const r=await a.pendingPicks()
Object.assign(s,{items:r?.items,availablePicks:r?.availablePicks,selected:ids,loaded:true})
s.review=a.reviewPicks(ids)
if(s.availablePicks!==n||!s.review?.ok||review.items.some((x,j)=>{const y=s.review.items[j];
return x.index!==y?.index||x.definitionId!==y.definitionId
||x.rating!==y.rating||x.tradable!==y.tradable})){s.selected=[]
s.review=bad('stale')
return s.review}
sent=true
const result=await a.confirmPicks(s.selected)
if(!result.ok)s.review=result
return result}catch{const result=bad(sent?'uncertain':'unknown-state')
s.review=result
return result}}
