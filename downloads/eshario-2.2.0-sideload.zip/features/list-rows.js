export const PICK_SCREEN='.ut-player-picks-view,[data-fut-picks-grid]'
import{ITEM_REDEEM_BUTTON} from './hotkeys.js'
import{popupOpen} from '../adapter/popup-door.js'
export const SQUAD_OPEN_BUTTON='.ut-squad-actions-view--panel>button:nth-child(2)'
export const CURSOR_ATTR='data-fut-list-cursor'
export const CURSOR_KEY='futListCursor'
export const ENTER_ATTR='data-fut-list-enter'
export const ENTER_KEY='futListEnter'
export const MARK_ATTR='data-fut-list-mark'
export const MARK_KEY='futListMark'
export const STALE_ATTR='data-fut-list-stale'
export const STALE_KEY='futListStale'
export const AXIS_X='x'
export const AXIS_Y='y'
export const MODE_PRESS='press'
export const MODE_CURSOR='cursor'
export const MODE_SAY='say'
export const ENTER_NONE='none'
export const ENTER_PRIMARY='primary'
export const ENTER_ROW='row'
export const ENTER_SAY='say'
export const ENTER_ZONE='zone'
export const LIST_ROWS=Object.freeze([
Object.freeze({key:'items',selector:'.listFUTItem',current:'.selected',press:'.ut-item-view',mode:MODE_PRESS,primary:ITEM_REDEEM_BUTTON}),
Object.freeze({key:'sbcSets',selector:'.ut-sbc-set-tile-view',mode:MODE_CURSOR,primary:null}),
Object.freeze({key:'sbcChallenges',selector:'.ut-sbc-challenge-table-row-view',current:'.selected',mode:MODE_PRESS,primary:'.ut-sbc-requirements-view button.btn-standard.primary'}),
Object.freeze({key:'packStorage',selector:'[data-fut-store-card]',mode:MODE_CURSOR,primary:'[data-fut-store-open]',primaryScope:'row'}),
Object.freeze({key:'squads',selector:'.ut-squad-table-cell-view',current:'.selected',mode:MODE_CURSOR,follow:SQUAD_OPEN_BUTTON,primary:null}),
Object.freeze({key:'objectives',selector:'.ut-objective-group-view',mode:MODE_CURSOR,primary:null}),
Object.freeze({key:'squadSlots',selector:'.ut-squad-pitch-view .ut-squad-slot-view,.ut-squad-slot-dock-view .ut-squad-slot-view,.ut-squad-tab-button-control.dockTab',zone:'.ut-squad-tab-button-control.dockTab',panel:'.ut-squad-slot-dock-view',start:'far',mode:MODE_PRESS,mark:'own',hold:false,primary:null})])
function inClosedDock(node){let dock=null
try{dock=node?.closest?.('.ut-squad-slot-dock-view')??null}catch{return false}
if(!dock)return false
return dockClosed(dock)}
function dockClosed(dock){return String(dock?.style?.bottom??'')===''}
export function groupsOf(rows,kind){if(typeof kind?.panel!=='string')return null
return(rows??[]).map((row)=>{try{return row?.closest?.(kind.panel)??null}catch{return null}})}
function veilsOf(doc,kind){if(typeof kind?.panel!=='string')return[]
let found
try{found=doc?.querySelectorAll?.(kind.panel)}catch{return[]}
const lids=[]
for(const one of found??[]){if(dockClosed(one))continue
let box=null
try{box=one.getBoundingClientRect?.()??null}catch{box=null}
if(box&&Number(box.height)>0)lids.push({box})}
return lids}
function underVeil(row,kind,lids){let own=null
try{own=row?.closest?.(kind.panel)??null}catch{own=null}
if(own)return false
for(const lid of lids){let box=null
try{box=row?.getBoundingClientRect?.()??null}catch{box=null}
if(!box)continue
const middle=Number(box.top)+(Number(box.height)/2)
if(!(middle>=Number(lid.box.top)))continue
const left=Number(box.left)
const lidLeft=Number(lid.box.left)
if(left<lidLeft+Number(lid.box.width)&&left+Number(box.width)>lidLeft)return true}
return false}
export function zoneOf(kind,row){if(typeof kind?.zone!=='string')return null
try{return row?.matches?.(kind.zone)===true?kind.zone:null}catch{return null}}
export function marksRow(kind){return kind?.mode!==MODE_PRESS||kind?.mark==='own'}
export function holdAllowed(doc){const list=listNow(doc)
return list?list.kind?.hold!==false:true}
export function enterMarkOf(kind,row=null){if(row&&zoneOf(kind,row))return ENTER_ZONE
if(kind?.mode===MODE_SAY)return ENTER_SAY
if(typeof kind?.primary==='string')return ENTER_PRIMARY
if(kind?.mode===MODE_CURSOR)return ENTER_ROW
return ENTER_NONE}
function lineTolerance(box){const height=Number(box?.height)
return Number.isFinite(height)&&height>0?Math.max(2,height/2):2}
export function axisOf(rects){const first=rects?.[0]
const second=rects?.[1]
if(!first||!second)return AXIS_Y
const line=lineTolerance(first)
const sameLine=Math.abs(Number(second.top)-Number(first.top))<line
return sameLine&&Number(second.left)>Number(first.left)?AXIS_X:AXIS_Y}
function screenOrder(rects){const total=rects?.length??0
const keys=[]
let carry={top:0,left:0}
for(let at=0;at<total;at+=1){const box=rects[at]
const top=Number(box?.top)
if(box&&Number.isFinite(top)){carry={top,left:Number(box.left)||0}}
keys.push(carry)}
const order=[]
for(let at=0;at<total;at+=1)order.push(at)
order.sort((a,b)=>{const up=keys[a].top-keys[b].top
if(up!==0)return up
const side=keys[a].left-keys[b].left
return side!==0?side:a-b})
return order}
export function linesOf(rects,groups=null){const lines=[]
let head=null
let pack=null
const packOf=(at)=>(Array.isArray(groups)?groups[at]??null:null)
for(const at of screenOrder(rects)){const box=rects[at]
const mine=packOf(at)
if(!box){if(head===null){lines.push([at])
pack=mine
continue}
lines[lines.length-1].push(at)
continue}
if(head===null||mine!==pack||!(Math.abs(Number(box.top)-Number(head.top))<lineTolerance(head))){lines.push([at])
head=box
pack=mine
continue}
lines[lines.length-1].push(at)}
for(const line of lines)line.sort((a,b)=>{const side=Number(rects[a]?.left??0)-Number(rects[b]?.left??0)
return Number.isFinite(side)&&side!==0?side:a-b})
return lines}
function centerOf(box){return Number(box?.left??0)+(Number(box?.width??0)/2)}
export function stepIndex(rects,from,delta,asked,groups=null){const total=rects?.length??0
if(total===0)return-1
if(!(from>=0&&from<total))return delta>0?0:total-1
const lines=linesOf(rects,groups)
const lineAt=lines.findIndex((line)=>line.includes(from))
if(lineAt<0)return-1
if(asked===AXIS_X){const line=lines[lineAt]
const place=line.indexOf(from)+delta
if(place>=0&&place<line.length)return line[place]
const near=lines[lineAt+delta]
if(!near||near.length===0)return-1
return delta>0?near[0]:near[near.length-1]}
const nextLine=lines[lineAt+delta]
if(!nextLine)return-1
const want=centerOf(rects[from])
let best=nextLine[0]
let gap=Math.abs(centerOf(rects[best])-want)
for(const one of nextLine){const step=Math.abs(centerOf(rects[one])-want)
if(step<gap){gap=step
best=one}}
return best}
export function startIndex(rects,rows,kind,delta){const total=rects?.length??0
if(total===0)return-1
const open=(at)=>zoneOf(kind,rows?.[at])===null
const lines=linesOf(rects,groupsOf(rows,kind))
const far=kind?.start==='far'
const order=(far?(delta>0):(delta<=0))?[...lines].reverse():lines
for(const line of order){const walk=(far||delta>0)?line:[...line].reverse()
for(const at of walk){if(open(at))return at}}
return-1}
export function rowKindOf(node){if(typeof node?.matches!=='function')return null
for(const kind of LIST_ROWS){try{if(node.matches(kind.selector))return kind}catch{return null}}
return null}
export function isVisible(node){if(!node||typeof node!=='object')return false
if(node.isConnected===false)return false
if(node.hidden===true)return false
const box=typeof node.getBoundingClientRect==='function'?node.getBoundingClientRect():null
if(box&&!(Number(box.width)>0&&Number(box.height)>0))return false
const view=node.ownerDocument?.defaultView??null
if(typeof view?.getComputedStyle==='function'){let style=null
try{style=view.getComputedStyle(node)}catch{style=null}
if(style&&(style.display==='none'||style.visibility==='hidden'))return false
return true}
const inline=node.style??null
return!(inline?.display==='none'||inline?.visibility==='hidden')}
export function rowsOf(doc,kind){let found
try{found=doc?.querySelectorAll?.(kind.selector)}catch{return[]}
const rows=Array.from(found??[]).filter((row)=>isVisible(row)&&!inClosedDock(row))
const lids=veilsOf(doc,kind)
return lids.length===0?rows:rows.filter((row)=>!underVeil(row,kind,lids))}
export function markedRow(doc){try{return doc?.querySelector?.(`[${CURSOR_ATTR}]`)??null}catch{return null}}
export function pickOnScreen(doc){let found
try{found=doc?.querySelectorAll?.(PICK_SCREEN)}catch{return false}
return Array.from(found??[]).some(isVisible)}
export function listNow(doc){if(pickOnScreen(doc))return null
const at=markedRow(doc)
const mine=at?rowKindOf(at):null
if(mine){const rows=rowsOf(doc,mine)
if(rows.length>0)return{kind:mine,rows}}
let first=null
for(const kind of LIST_ROWS){const rows=rowsOf(doc,kind)
if(rows.length===0)continue
if(first===null)first={kind,rows}
if(currentIn(kind,rows).length>0)return{kind,rows}}
return first}
function currentIn(kind,rows){if(typeof kind?.current!=='string')return[]
const found=[]
for(let at=0;at<rows.length;at+=1){try{if(rows[at]?.matches?.(kind.current)===true)found.push(at)}catch{return[]}}
return found}
export function indexIn(list,sole=false){if(!list)return-1
const{kind,rows}=list
const native=currentIn(kind,rows)
const marked=rows.findIndex((row)=>row?.dataset?.[CURSOR_KEY]!==undefined)
if(kind.mode===MODE_PRESS){if(native.length>0)return sole&&native.length>1?-1:native[0]
return marked}
if(marked>=0)return marked
if(native.length===0)return-1
return sole&&native.length>1?-1:native[0]}
export function drawsMark(kind,row){if(!marksRow(kind))return false
if(typeof kind?.current!=='string')return true
try{return row?.matches?.(kind.current)!==true}catch{return true}}
export function axisNow(doc){const list=listNow(doc)
if(!list)return null
const rects=rectsOf(list.rows)
const at=indexIn(list)
const lines=linesOf(rects,groupsOf(list.rows,list.kind))
const line=at>=0?(lines.find((one)=>one.includes(at))??lines[0]):lines[0]
return(line?.length??0)>1?AXIS_X:AXIS_Y}
export function rectsOf(rows){return(rows??[]).map((row)=>{try{return row?.getBoundingClientRect?.()??null}catch{return null}})}
export function enterTargets(doc){if(pickOnScreen(doc))return[]
if(popupOpen(doc?.defaultView??null)!==false)return[]
const found=[]
for(const kind of LIST_ROWS){const rows=rowsOf(doc,kind)
if(rows.length===0)continue
const at=indexIn({kind,rows},true)
if(at<0)continue
found.push({kind,rows,at,row:rows[at]})}
return found}
export function enterKindNow(doc){const targets=enterTargets(doc)
if(targets.length!==1)return null
const{kind,row}=targets[0]
if(zoneOf(kind,row))return kind
if(typeof kind.primary==='string')return primaryButton(doc,kind,row)?kind:null
return kind.mode===MODE_PRESS?null:kind}
export function followButton(doc,kind){if(typeof kind?.follow!=='string')return null
let found=null
try{found=Array.from(doc?.querySelectorAll?.(kind.follow)??[]).find(isVisible)??null}catch{return null}
if(!found)return null
let primary=false
try{primary=found.matches?.('.primary')===true}catch{primary=false}
return primary?null:found}
export function primaryButton(doc,kind,row=null){if(typeof kind?.primary!=='string')return null
const host=kind.primaryScope==='row'?row:doc
if(!host)return null
let found=null
try{found=Array.from(host.querySelectorAll?.(kind.primary)??[]).find(isVisible)??null}catch{return null}
return found??null}
