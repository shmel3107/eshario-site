import{createSession} from '../automation/session.js'
import{createStopConditions} from '../automation/stop-conditions.js'
import{createSniper,overflowSafetyProblems,pileOrNull,priceCapMissing} from '../automation/sniper.js'
import{stopReasonKey} from '../automation/stop-reasons.js'
import{parseLimits,limitsToInput,LIMIT_FIELDS} from '../automation/limits-input.js'
import{parseOptions,sanitizeOptionInput,OPTION_FIELDS,BOOLEAN_OPTION_KEYS,POLICY_FIELDS,ADVANCED_OPTION_FIELDS,AFTER_BUY_KEY,afterBuyOf,CHOICE_OPTIONS} from '../automation/options-input.js'
import{createCachedProvider} from '../core/storage-provider.js'
export const LIMITS_KEY='automation.limits'
export const LIMITS_READ='limits.read'
export const LIMITS_WRITE='limits.write'
export const OPTIONS_KEY='automation.options'
export const OPTIONS_READ='options.read'
export const OPTIONS_WRITE='options.write'
export const LIMIT_INPUT_DEFAULTS=Object.freeze({maxPurchases:'1'})
export function sanitizeLimitInput(stored){const out={}
const saved=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:null
for(const field of LIMIT_FIELDS){if(saved===null||!Object.hasOwn(saved,field.key)){
out[field.key]=LIMIT_INPUT_DEFAULTS[field.key]??''
continue}
const value=saved[field.key]
out[field.key]=typeof value==='string'?value:''
}
return out}
export function createBridgeLimitsProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function') throw new Error('limits: мост недоступен')
return createCachedProvider({fetch:()=>bridge.request(LIMITS_READ),push:(value)=>bridge.request(LIMITS_WRITE,value),sanitize:sanitizeLimitInput,fallback:()=>sanitizeLimitInput(null),onError:opts.onError})}
export function createBridgeOptionsProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function') throw new Error('options: мост недоступен')
return createCachedProvider({fetch:()=>bridge.request(OPTIONS_READ),push:(value)=>bridge.request(OPTIONS_WRITE,value),sanitize:sanitizeOptionInput,fallback:()=>sanitizeOptionInput(null),onError:opts.onError})}
export const CONSENT_REQUIRED='consent-required'
export function consentFingerprint(text){if(typeof text!=='string')return null
const clean=text.replace(/\s+/gu,' ').trim()
if(clean==='')return null
let hash=2166136261
for(let i=0;i<clean.length;i+=1){hash^=clean.charCodeAt(i)
hash=Math.imul(hash,16777619)}
return `v1:${clean.length}:${(hash>>>0).toString(16).padStart(8,'0')}`}
export const AUTOMATION_FEATURE='autoBuyer'
export const BUYER_SAFETY_FIELDS=Object.freeze(['maxActions','maxDurationMs'])
export const BUYER_RUN_CAPS=Object.freeze(['maxPurchases','maxSpend'])
export function buyerRunCapMissing(limits={}){return BUYER_RUN_CAPS.every((key)=>(typeof limits[key]!=='number'
||!Number.isFinite(limits[key])
||limits[key]<=0))}
export function buyerSafetyProblems(limits={}){return BUYER_SAFETY_FIELDS.filter((key)=>(typeof limits[key]!=='number'
||!Number.isFinite(limits[key])
||limits[key]<=0))}
export{STOP_REASON_KEYS,stopReasonKey} from '../automation/stop-reasons.js'
export function createAutomation(deps={}){const{clock,market}=deps
if(!clock||typeof clock.sleep!=='function') throw new Error('automation: нужны часы')
if(typeof market!=='function') throw new Error('automation: нужен доступ к рынку')
const isEnabled=typeof deps.isEnabled==='function'?deps.isEnabled:()=>true
const onUpdate=typeof deps.onUpdate==='function'?deps.onUpdate:()=>{}
const coinBalance=typeof deps.coinBalance==='function'?deps.coinBalance:null
const isActive=typeof deps.isActive==='function'?deps.isActive:null
const switchedOff=()=>{if(isActive===null)return null
try{return isActive(AUTOMATION_FEATURE)===true?null:'switched-off'}catch{return'switched-off-unreadable'}}
const budgetPort=()=>{const said=typeof deps.budget==='function'?deps.budget():deps.budget
return said&&typeof said.search==='function'?said:null}
const purchaseLog=deps.purchaseLog&&typeof deps.purchaseLog.notePaid==='function'?deps.purchaseLog:null
let wire=null
const wireOff=()=>{const said=wire
wire=null
if(said===null)return false
try{said.dispose?.()}catch{
}
return true}
const wireOn=()=>{wireOff()
if(typeof deps.wire!=='function')return null
try{wire=deps.wire()??null}catch{wire=null}
if(wire!==null&&(typeof wire.calls!=='function'||typeof wire.lastSent!=='function'))wire=null
return wire}
const consent=deps.consent
&&typeof deps.consent.text==='function'
&&typeof deps.consent.granted==='function'
?deps.consent
:null
const consentState=()=>{if(consent===null)return{ok:false,reason:'no-port',fingerprint:null}
let want=null
let said=null
try{want=consentFingerprint(consent.text())
said=consent.granted()}catch{return{ok:false,reason:'unreadable',fingerprint:null}}
if(want===null)return{ok:false,reason:'no-text',fingerprint:null}
return typeof said==='string'&&said===want
?{ok:true,reason:null,fingerprint:want}
:{ok:false,reason:said?'stale':'not-given',fingerprint:want}}
const watchers=[deps.journal,deps.ledger,deps.sounds].filter((w)=>w&&typeof w.record==='function')
const remember=(event,payload)=>{
if(purchaseLog!==null&&event==='bought'){try{purchaseLog.notePaid(payload?.item,payload?.price)}catch{
}}
for(const watcher of watchers){try{watcher.record(event,payload)}catch{
}}}
let dryRun=true
let sniper=null
let session=null
let running=false
let lastReason=null
let lastDetail=null
const limitsProvider=deps.limitsProvider??null
let limitInput=sanitizeLimitInput(limitsProvider?limitsProvider.read():null)
const optionsProvider=deps.optionsProvider??null
let optionInput=sanitizeOptionInput(optionsProvider?optionsProvider.read():null)
const notify=()=>{try{onUpdate()}catch{
}}
return{isDryRun:()=>dryRun,isRunning:()=>running,
setDryRun(value){if(running) return{ok:false,notice:{key:'automation.busy',params:{}}}
dryRun=value===true
notify()
return{ok:true,notice:null}},
limitInput:()=>({...limitInput}),
setLimit(key,text){if(running) return{ok:false,notice:{key:'automation.busy',params:{}}}
if(!LIMIT_FIELDS.some((field)=>field.key===key)){return{ok:false,notice:{key:'automation.badLimits',params:{reason:key}}}}
limitInput={...limitInput,[key]:typeof text==='string'?text:''}
if(limitsProvider){try{limitsProvider.write(limitInput)}catch{
}}
return{ok:true,notice:null}},
reloadLimits(){if(limitsProvider)limitInput=sanitizeLimitInput(limitsProvider.read())
return{...limitInput}},
optionInput:()=>({...optionInput}),
setOption(key,value){if(running) return{ok:false,notice:{key:'automation.busy',params:{}}}
const isField=[...OPTION_FIELDS,...POLICY_FIELDS,...ADVANCED_OPTION_FIELDS].some((field)=>field.key===key)
const isChoice=Object.hasOwn(CHOICE_OPTIONS,key)
const isBoolean=BOOLEAN_OPTION_KEYS.includes(key)
if(!isField&&!isChoice&&!isBoolean){return{ok:false,notice:{key:'automation.badOption',params:{field:String(key)}}}}
optionInput={...optionInput,[key]:isChoice
?CHOICE_OPTIONS[key](value)
:(isField?(typeof value==='string'?value:''):value===true)}
if(optionsProvider){try{optionsProvider.write(optionInput)}catch{
}}
return{ok:true,notice:null,redraw:!isField}},
reloadOptions(){if(optionsProvider)optionInput=sanitizeOptionInput(optionsProvider.read())
return{...optionInput}},
status(){return{running,dryRun,reason:lastReason,detail:lastDetail,stats:session?session.stats():null,
filter:sniper&&typeof sniper.filterState==='function'?sniper.filterState():null,
session:sniper&&typeof sniper.sessionState==='function'?sniper.sessionState():null,
summary:sniper&&typeof sniper.summaryState==='function'?sniper.summaryState():null,
rotation:sniper&&typeof sniper.rotationState==='function'?sniper.rotationState():null,
consent:consentState(),
limits:{...limitInput},options:{...optionInput}}},
raceTimes(){return sniper&&typeof sniper.raceState==='function'?sniper.raceState():[]},
acceptDisclaimer(){if(consent===null||typeof consent.grant!=='function'){return{ok:false,notice:{key:stopReasonKey(CONSENT_REQUIRED),params:{}},reason:'no-port'}}
let want=null
try{want=consentFingerprint(consent.text())}catch{want=null}
if(want===null)return{ok:false,notice:{key:stopReasonKey(CONSENT_REQUIRED),params:{}},reason:'no-text'}
try{consent.grant(want)}catch{return{ok:false,notice:{key:stopReasonKey(CONSENT_REQUIRED),params:{}},reason:'write-failed'}}
notify()
return{ok:true,notice:null,fingerprint:want}},
start(config={}){if(running) return{ok:false,notice:{key:'automation.alreadyRunning',params:{}}}
if(!isEnabled(AUTOMATION_FEATURE)){return{ok:false,notice:{key:'license.premiumRequired',params:{}}}}
const off=switchedOff()
if(off!==null){return{ok:false,notice:{key:'settings.switchedOff',params:{}},reason:off}}
if(!dryRun){const gate=consentState()
if(!gate.ok){return{ok:false,notice:{key:stopReasonKey(CONSENT_REQUIRED),params:{}},reason:CONSENT_REQUIRED,detail:gate.reason}}}
const filters=Array.isArray(config.filters)?config.filters.filter(Boolean):[]
if(filters.length===0){return{ok:false,notice:{key:'automation.noFilters',params:{}}}}
let live
try{live=market()}catch(err){return{ok:false,notice:{key:'automation.noMarket',params:{reason:String(err?.message??err)}}}}
if(!live
||typeof live.searchTransferMarket!=='function'
||typeof live.bid!=='function'){return{ok:false,notice:{key:'automation.noMarket',params:{reason:'нет searchTransferMarket/bid'}}}}
let limits=config.limits
if(!limits){const parsed=parseLimits(limitInput)
if(parsed.errors.length>0){
return{ok:false,notice:{key:'automation.badLimitFields',params:{fields:parsed.errors.map((e)=>e.key).join(', ')}},errors:parsed.errors}}
limits=parsed.limits}
const parsedOptions=parseOptions(optionInput)
if(parsedOptions.errors.length>0){return{ok:false,notice:{key:'automation.badOptionFields',params:{fields:parsedOptions.errors.map((e)=>e.key).join(', ')}},errors:parsedOptions.errors}}
let startingCoins=config.coins
if(startingCoins===undefined&&coinBalance!==null){try{startingCoins=coinBalance()}catch{startingCoins=null}
if(typeof startingCoins!=='number'
||!Number.isFinite(startingCoins)
||startingCoins<0){return{ok:false,notice:{key:'automation.noCoinBalance',params:{}}}}}
let stop
try{
stop=createStopConditions(limits,{clock})}catch(err){return{ok:false,notice:{key:'automation.badLimits',params:{reason:String(err?.message??err)}}}}
const safetyProblems=dryRun?[]:buyerSafetyProblems(stop.limits())
if(safetyProblems.length>0){return{ok:false,notice:{key:'automation.safetyLimitsRequired',params:{fields:safetyProblems.join(', ')}}}}
if(!dryRun&&buyerRunCapMissing(stop.limits())){return{ok:false,notice:{key:'automation.runCapRequired',params:{fields:BUYER_RUN_CAPS.join(', ')}},reason:'run-cap-required'}}
const engineOptions=deps.options??parsedOptions.options
if(!dryRun&&priceCapMissing(filters,engineOptions.maxPrice)){return{ok:false,notice:{key:'automation.priceCapRequired',params:{}},reason:'price-cap-required'}}
if(engineOptions.immediateList?.enabled===true
&&(typeof live.requestMarketData!=='function'
||typeof live.list!=='function')){return{ok:false,notice:{key:'automation.noMarket',params:{reason:'нет requestMarketData/list'}}}}
if(pileOrNull(engineOptions.moveTo)!==null
&&typeof live.move!=='function'){return{ok:false,notice:{key:'automation.noMarket',params:{reason:'нет move'}}}}
const maxBid=engineOptions.maxBid
const needsUnassigned=!dryRun
&&(engineOptions.allowUnassignedOverflow!==true
||(Number.isFinite(maxBid)&&maxBid>0))
if(needsUnassigned
&&typeof live.requestUnassignedItems!=='function'){return{ok:false,notice:{key:'automation.noMarket',params:{reason:'нет requestUnassignedItems'}}}}
const overflowProblems=overflowSafetyProblems(engineOptions,stop)
if(overflowProblems.length>0){return{ok:false,notice:{key:'automation.overflowNeedsLimits',params:{fields:overflowProblems.join(', ')}}}}
session=createSession({clock,dryRun,startingCoins})
sniper=createSniper({market:live,session,stop,clock,filters,coinBalance,budget:budgetPort(),
wire:wireOn(),
widePage:deps.widePage,
pileFeed:deps.pileFeed,
pageViews:deps.pageViews,
buyRate:deps.buyRate,
handOnScreen:deps.handOnScreen,
options:engineOptions,onEvent:(event,payload)=>{remember(event,payload)
if(switchedOff()!==null)sniper?.cancel?.()
notify()}})
running=true
lastReason=null
lastDetail=null
notify()
sniper.run().then((result)=>{running=false;wireOff();lastReason=result.reason;lastDetail=result.detail??null;notify()},(err)=>{running=false;wireOff();lastReason='unknown';lastDetail=null;notify();return err})
return{ok:true,notice:{key:dryRun?'automation.startedDry':'automation.startedReal',params:{}}}},
stop(){if(!running||!sniper) return{ok:false,notice:{key:'automation.notRunning',params:{}}}
sniper.cancel()
return{ok:true,notice:{key:'automation.stopping',params:{}}}}}}
