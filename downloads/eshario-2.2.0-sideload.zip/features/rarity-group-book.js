import{seasonOf,seasonFits} from '../adapter/season.js'
export const GROUP_BOOK_SCHEMA=1
export function groupsOfItem(item){let raw=null
try{raw=item?.groups}catch{return null}
if(!Array.isArray(raw))return null
const out=[]
for(const value of raw){if(Number.isSafeInteger(value)&&value>0&&!out.includes(value))out.push(value)}
return out.length>0?out.sort((a,b)=>a-b):null}
function rarityOfItem(item){let raw=null
try{raw=item?.rareflag}catch{return null}
return Number.isSafeInteger(raw)&&raw>=0?raw:null}
export function encodeBook(pairs,dropped,season=null){const groups={}
for(const[rarity,list]of pairs??[])groups[rarity]=[...list]
const out={v:GROUP_BOOK_SCHEMA,g:groups,d:[...(dropped??[])]}
if(Number.isSafeInteger(season))out.s=season
return out}
export function decodeBook(raw,season=null){const out={pairs:[],dropped:[]}
if(!raw||typeof raw!=='object'||raw.v!==GROUP_BOOK_SCHEMA)return out
if(!seasonFits(raw.s,season))return out
const groups=raw.g
if(groups&&typeof groups==='object'){for(const key of Object.keys(groups)){const rarity=Number(key)
const list=groups[key]
if(!Number.isSafeInteger(rarity)||rarity<0||!Array.isArray(list))continue
const clean=list.filter((one)=>Number.isSafeInteger(one)&&one>0)
if(clean.length>0)out.pairs.push([rarity,clean])}}
for(const one of Array.isArray(raw.d)?raw.d:[]){if(Number.isSafeInteger(one)&&one>=0)out.dropped.push(one)}
return out}
export function createRarityGroupBook(deps={}){const book=new Map()
const dropped=new Set()
const stats={seen:0,noted:0,narrowed:0}
const by=new Map()
const tally=(source,field)=>{const key=typeof source==='string'&&source!==''?source:'other'
let row=by.get(key)
if(row===undefined){row={seen:0,noted:0}
by.set(key,row)}
row[field]+=1}
const storage=deps.storage??null
const schedule=typeof deps.schedule==='function'?deps.schedule:(fn)=>{fn()}
const now=typeof deps.now==='function'?deps.now:()=>0
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const seasonNow=typeof deps.season==='function'?deps.season:()=>seasonOf()
let loaded=false
let loading=false
let dirty=false
let flushing=false
let writes=0
let lastWriteAt=null
const touch=()=>{if(loading||storage===null)return
dirty=true
if(flushing)return
flushing=true
schedule(step)}
function step(){if(!dirty){flushing=false
return}
dirty=false
try{const result=storage?.write?.(encodeBook(book,dropped,seasonNow()))
writes+=1
lastWriteAt=now()
if(result&&typeof result.catch==='function')result.catch(onError)}catch(err){onError(err)}
flushing=false}
const put=(rarity,groups)=>{if(dropped.has(rarity))return false
const known=book.get(rarity)
if(known===undefined){book.set(rarity,groups)
stats.noted+=1
touch()
return true}
const next=known.filter((group)=>groups.includes(group))
if(next.length===known.length)return false
stats.narrowed+=1
if(next.length===0){book.delete(rarity)
dropped.add(rarity)
touch()
return true}
book.set(rarity,next)
touch()
return true}
return{
note(item,source){stats.seen+=1
tally(source,'seen')
const rarity=rarityOfItem(item)
const groups=groupsOfItem(item)
if(rarity===null||groups===null)return false
const fresh=!book.has(rarity)&&!dropped.has(rarity)
const changed=put(rarity,groups)
if(changed&&fresh)tally(source,'noted')
return changed},
noteAll(items,source){let added=0
for(const item of Array.isArray(items)?items:[]){if(this.note(item,source))added+=1}
return added},
seedGroups(dictionary,source='base'){if(!dictionary||typeof dictionary!=='object'||Array.isArray(dictionary))return 0
let added=0
for(const key of Object.keys(dictionary)){const rarity=Number(key)
if(!Number.isSafeInteger(rarity)||rarity<0)continue
const list=dictionary[key]
if(!Array.isArray(list))continue
const groups=[]
for(const value of list){if(Number.isSafeInteger(value)&&value>0&&!groups.includes(value))groups.push(value)}
if(groups.length===0)continue
stats.seen+=1
tally(source,'seen')
const fresh=!book.has(rarity)&&!dropped.has(rarity)
if(put(rarity,groups.sort((a,b)=>a-b))){added+=1
if(fresh)tally(source,'noted')}}
return added},
dictionary(){if(book.size===0)return null
const out={}
for(const[rarity,groups]of book)out[rarity]=[...groups]
return out},
async load(){if(storage===null){loaded=true
return 0}
loading=true
try{const stored=decodeBook(await storage.read?.(),seasonNow())
for(const rarity of stored.dropped){book.delete(rarity)
dropped.add(rarity)}
for(const[rarity,groups]of stored.pairs)put(rarity,groups)}catch(err){onError(err)}finally{loading=false}
loaded=true
return book.size},
state(){let pairs=0
for(const groups of book.values())pairs+=groups.length
const sources={}
for(const[name,row]of by)sources[name]={...row}
return{schema:GROUP_BOOK_SCHEMA,season:seasonNow(),rarities:book.size,pairs,dropped:dropped.size,loaded,writes,lastWriteAt,pending:dirty,...stats,by:sources}}}}
