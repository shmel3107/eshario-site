import{createCachedProvider,storageFailed} from '../core/storage-provider.js'
const arr=Array.isArray
const bad=(reason)=>({ok:false,reason})
const valid=(key)=>{const m=/^(\d+):[01]$/.exec(key)
return Boolean(m&&Number.isSafeInteger(Number(m[1])))}
const HIDDEN_PREFIX='h:'
const hiddenKey=(key)=>(typeof key==='string'&&valid(key)?HIDDEN_PREFIX+key:null)
export function sanitizePackLocks(raw){return arr(raw)?[...new Set(raw.filter((key)=>typeof key==='string'
&&(valid(key)||(key.startsWith(HIDDEN_PREFIX)&&valid(key.slice(HIDDEN_PREFIX.length))))))]:[]}
export function packLockKey(id,tradable){if(!Number.isSafeInteger(id)||id<0||typeof tradable!=='boolean')return null
return `${id}:${tradable?1:0}`}
export function isPackLocked(provider,key){if(typeof key!=='string'||!valid(key))return false
if(storageFailed(provider))return true
return sanitizePackLocks(provider?.read?.()).includes(key)}
export function createBridgePackLockProvider(opts){if(typeof opts?.bridge?.request!=='function')throw new Error('packs: мост недоступен')
return createCachedProvider({fetch:()=>opts.bridge.request('packs.read'),push:(value)=>opts.bridge.request('packs.write',value),sanitize:sanitizePackLocks,fallback:()=>[],onError:opts.onError})}
export function setPackLock(provider,key,on){if(!valid(key)||storageFailed(provider))return false
const next=new Set(sanitizePackLocks(provider.read()))
if(on===true)next.add(key);else next.delete(key)
provider.write([...next])
return true}
export function isPackHidden(provider,key){const mark=hiddenKey(key)
if(mark===null)return false
return sanitizePackLocks(provider?.read?.()).includes(mark)}
export function setPackHidden(provider,key,on){const mark=hiddenKey(key)
if(mark===null||storageFailed(provider))return false
const next=new Set(sanitizePackLocks(provider.read()))
if(on===true)next.add(mark);else next.delete(mark)
provider.write([...next])
return true}
export async function openOwnedPack({adapter,provider,key,confirmed}){if(confirmed!==true)return bad('not-confirmed')
if(isPackLocked(provider,key))return bad('locked')
if(typeof adapter?.open!=='function')return bad('guard-unavailable')
return adapter.open(key)}
