import{burnCostOf,bucketPlanOf,BUCKET_KEYS,classCoversCard,classPrice,demandClasses,explainBurnOf,searchBurnOf,virtualBuysFrom} from '../automation/card-value.js'
import{COMPARE,needOf,parseRequirements,REQUIREMENT_KEY} from '../automation/sbc-requirements.js'
import{isSbcPlayer} from '../automation/sbc-solver.js'
import{identityOf,tradabilityOf} from './club-analysis.js'
import{unionClasses,unionRatings} from './demand-memory.js'
import{cheapestPicks,stepAttrs,stepFrom} from './price-ladder.js'
import{poolPriceWatch} from './sbc-pool.js'
export function duplicateIds(items){const groups=new Map()
for(const item of Array.isArray(items)?items:[]){const identity=identityOf(item)
const id=item?.id
if(identity===null||id===undefined||id===null)continue
const known=groups.get(identity)
if(known)known.add(String(id))
else groups.set(identity,new Set([String(id)]))}
const extra=new Set()
for(const ids of groups.values()){if(ids.size<2)continue
const sorted=[...ids].sort()
for(let i=1;i<sorted.length;i+=1)extra.add(sorted[i])}
return extra}
export function repeatedIdCount(items){const seen=new Set()
let repeated=0
for(const item of Array.isArray(items)?items:[]){const id=item?.id
if(id===undefined||id===null)continue
const key=String(id)
if(seen.has(key))repeated+=1
else seen.add(key)}
return repeated}
export function uniqueById(items){const seen=new Set()
const out=[]
for(const item of Array.isArray(items)?items:[]){const id=item?.id
if(id===undefined||id===null){out.push(item)
continue}
const key=String(id)
if(seen.has(key))continue
seen.add(key)
out.push(item)}
return out}
export function mergePool(...reads){const items=[]
for(const read of reads)for(const item of Array.isArray(read)?read:[])items.push(item)
return{items:uniqueById(items),repeated:repeatedIdCount(items)}}
export function poolReport(items,repeated,priceOf,eye){const list=Array.isArray(items)?items:[]
let priced=null
if(typeof priceOf==='function'){priced=0
for(const item of list){const price=priceOf(item)
if(Number.isFinite(price)&&price>0)priced+=1}}
const out={size:list.length,repeated:Number.isFinite(repeated)?repeated:repeatedIdCount(list),duplicates:duplicateIds(list).size,priced}
return{...out,cover:poolPriceWatch(out,{by:eye?.by??null})}}
export function valuationFrom(input={}){const ladder=Array.isArray(input.prices?.ladder)?input.prices.ladder:null
if(ladder===null||ladder.length===0)return null
const byRarity=input.prices.byRarity&&typeof input.prices.byRarity==='object'?input.prices.byRarity:{}
const rarityLadders=plainLadders(input.prices.rarityLadders)
const extra=duplicateIds(input.club)
const prices={ladder,byRarity}
if(rarityLadders!==null)prices.rarityLadders=rarityLadders
for(const prop of IDENTITY_LADDER_PROPS){const steps=plainLadders(input.prices[prop])
if(steps!==null)prices[prop]=steps}
const groups=plainGroups(input.prices.rarityGroups)
if(groups!==null)prices.rarityGroups=groups
const classes=withSupply(unionClasses(liveClassesFrom(input.requirements,input.openChallenges),input.remembered),input.available,prices)
return{prices,classes,
futureRatings:unionRatings(liveRatingsFrom(input.requirements,input.openChallenges),input.rememberedRatings),
isDuplicate:(card)=>extra.has(String(card?.id))}}
export function withSupply(classes,available,prices){const cards=Array.isArray(available)?available:null
if(cards===null)return classes
return classes.map((cls)=>{let supply=0
for(const card of cards){if(card?.virtual!==true&&classCoversCard(card,cls,prices))supply+=1}
return{...cls,supply}})}
export function ctxOf(valuation){return{classes:valuation?.classes,isDuplicate:valuation?.isDuplicate,futureRatings:valuation?.futureRatings}}
const IDENTITY_LADDER_PROPS=['leagueLadders','nationLadders','clubLadders']
export function liveClassesFrom(requirements,openChallenges){return demandClasses(allRequirements(requirements,openChallenges))}
export function liveRatingsFrom(requirements,openChallenges){const out=[]
for(const req of allRequirements(requirements,openChallenges)){if(req?.key!==REQUIREMENT_KEY.TEAM_RATING)continue
if(req.compare===COMPARE.LOWER)continue
const value=needOf(req)
if(Number.isFinite(value))out.push(value)}
return out}
function allRequirements(own,others){const out=[...parseRequirements(own).requirements]
for(const challenge of Array.isArray(others)?others:[]){try{out.push(...parseRequirements(challenge?.requirements).requirements)}catch{/* одно испытание не роняет остальные */}}
return out}
export function identityWantsFrom(requirements,classes){const out={league:new Set(),nation:new Set(),team:new Set()}
const take=(field,values)=>{for(const value of Array.isArray(values)?values:[]){if(Number.isSafeInteger(value)&&value>0)out[field].add(value)}}
const scan=(entry)=>{const field=IDENTITY_FIELD[entry?.key]
if(field===undefined)return
take(field,entry.values)}
for(const req of parseRequirements(requirements).requirements){scan(req)
for(const entry of Array.isArray(req?.combined)?req.combined:[])scan(entry)}
for(const cls of Array.isArray(classes)?classes:[]){if(!cls||typeof cls!=='object')continue
for(const[prop,field]of IDENTITY_CLASS_FIELD)take(field,cls[prop])}
const sorted=(list)=>[...list].sort((a,b)=>a-b)
return{league:sorted(out.league),nation:sorted(out.nation),team:sorted(out.team)}}
const IDENTITY_CLASS_FIELD=[['leagues','league'],['nations','nation'],['clubs','team']]
const IDENTITY_FIELD={[REQUIREMENT_KEY.LEAGUE_ID]:'league',[REQUIREMENT_KEY.NATION_ID]:'nation',[REQUIREMENT_KEY.CLUB_ID]:'team'}
export async function laddersFrom(byRarity,priceOf,attrsOf,opts={}){if(!(byRarity instanceof Map)||typeof priceOf!=='function')return null
const lookup=typeof attrsOf==='function'?attrsOf:null
const yield_=sliceYield(opts)
const out={}
for(const[rarity,cards]of byRarity){const found=new Map()
for(const[id,rating]of Array.isArray(cards)?cards:[]){
if(yield_!==null&&!(await yield_()))return undefined
let price=null
try{price=await priceOf(id)}catch{price=null}
if(!Number.isFinite(price)||price<=0)continue
const known=found.get(rating)
if(known===undefined)found.set(rating,[{id,price}])
else known.push({id,price})}
if(found.size===0)continue
out[rarity]=[...found].map(([rating,cardsOfStep])=>stepFrom(rating,cheapestPicks(cardsOfStep,lookup),cardsOfStep.length))}
return Object.keys(out).length===0?null:out}
export async function bucketsFrom(byRarity,priceOf,attrsOf,opts={}){if(!(byRarity instanceof Map)||typeof priceOf!=='function')return null
const lookup=typeof attrsOf==='function'?attrsOf:null
if(lookup===null)return null
const yield_=sliceYield(opts)
const found=new Map()
for(const[rareflag,cards]of byRarity){if(!Number.isSafeInteger(rareflag)||rareflag<0)continue
for(const[id,rating]of Array.isArray(cards)?cards:[]){if(yield_!==null&&!(await yield_()))return undefined
if(!Number.isSafeInteger(rating)||rating<=0)continue
let record=null
try{record=lookup(id)}catch{record=null}
const leagueId=positiveOf(record?.leagueId)
const nationId=positiveOf(record?.nationId)
const teamId=positiveOf(record?.teamId)
if(leagueId===null||nationId===null||teamId===null)continue
let price=null
try{price=await priceOf(id)}catch{price=null}
if(!Number.isFinite(price)||price<=0)continue
const key=`${leagueId}|${nationId}|${teamId}|${rating}|${rareflag}`
const known=found.get(key)
const pick={id,price,attrs:chemistryAttrs(record)}
if(known===undefined)found.set(key,{leagueId,nationId,teamId,rating,rareflag,picks:[pick]})
else known.picks.push(pick)}}
if(found.size===0)return null
const out=[...found.values()]
for(const bucket of out){bucket.picks.sort((a,b)=>a.price!==b.price?a.price-b.price:a.id-b.id)
if(bucket.picks.length>BUCKET_PICKS)bucket.picks.length=BUCKET_PICKS}
out.sort((a,b)=>a.leagueId-b.leagueId||a.nationId-b.nationId||a.teamId-b.teamId||a.rating-b.rating||a.rareflag-b.rareflag)
return out}
function sliceYield(opts){const pause=typeof opts?.pause==='function'?opts.pause:null
if(pause===null)return null
const clock=typeof opts.now==='function'?opts.now:nowMs
const sliceMs=Number.isFinite(opts.sliceMs)&&opts.sliceMs>0?opts.sliceMs:BLOB_SLICE_MS
let since=clock()
return async()=>{if(clock()-since<sliceMs)return true
try{await pause()}catch{return false}
since=clock()
return true}}
export const BUCKET_PICKS=11
const positiveOf=(value)=>Number.isSafeInteger(value)&&value>0?value:null
function chemistryAttrs(record){let attrs=null
try{attrs=stepAttrs(record)}catch{attrs=null}
if(attrs===null)return null
const out={}
if(Array.isArray(attrs.possiblePositions)&&attrs.possiblePositions.length>0)out.possiblePositions=[...attrs.possiblePositions]
if(attrs.positionsEstimate===true)out.positionsEstimate=true
return Object.keys(out).length>0?out:null}
export function bucketsWanted(requirements){for(const req of parseRequirements(requirements).requirements){if(BUCKET_KEYS.has(req?.key))return true
for(const entry of Array.isArray(req?.combined)?req.combined:[])if(BUCKET_KEYS.has(entry?.key))return true}
return false}
export function bucketTokenOf(id){const parts=String(id??'').split(':')
if(parts.length<3||parts[0]!=='buy')return null
return BUCKET_TOKEN.test(parts[1])?parts[1]:null}
const BUCKET_TOKEN=/^g\d+\.\d+\.\d+\.\d+\.\d+$/
export function bucketIndexOf(prices){if(!prices||typeof prices!=='object')return EMPTY_BUCKETS
const known=BUCKET_INDEX.get(prices)
if(known!==undefined)return known
const index=new Map()
for(const one of Array.isArray(prices.buckets)?prices.buckets:[]){if(!one||typeof one!=='object')continue
index.set(`g${one.leagueId}.${one.nationId}.${one.teamId}.${one.rating}.${one.rareflag}`,one)}
BUCKET_INDEX.set(prices,index)
return index}
const BUCKET_INDEX=new WeakMap()
const EMPTY_BUCKETS=new Map()
export const nowMs=()=>{try{return typeof performance?.now==='function'?performance.now():Date.now()}catch{return Date.now()}}
export const BLOB_SLICE_MS=8
export function stampOf(parts){if(parts===null||typeof parts!=='object')return null
const names=Object.keys(parts).sort()
if(names.length===0)return null
const bits=[]
for(const name of names){const one=parts[name]
if(one===null||one===undefined)return null
if(typeof one==='number'&&!Number.isFinite(one))return null
if(typeof one==='object')return null
bits.push(`${name}=${String(one)}`)}
return bits.join('|')}
export function createLadderLedger(){const families=new Map()
const warm={rounds:0,done:0,shared:0,aborted:0,stoppedBy:null,last:null,noFrames:0,hidden:0,noPool:0,noTargets:0,noTargetsOn:null,inactive:0,
hides:0,hidesHot:0}
let seq=0
const row=(one)=>({from:one.from,ms:one.ms,age:one.age,key:one.key})
return{
note(name,one){if(typeof name!=='string'||name===''||!one||typeof one!=='object')return 0
seq+=1
families.set(name,{from:typeof one.from==='string'?one.from:'?',
ms:Number.isFinite(one.ms)?Math.round(one.ms):null,
age:Number.isFinite(one.age)?Math.round(one.age):null,
key:one.key===undefined?null:one.key,seq})
return seq},
noteWarm(patch){if(!patch||typeof patch!=='object')return false
for(const[name,value]of Object.entries(patch))if(name in warm)warm[name]=value
return true},
seq(){return seq},
since(mark){const out={}
const after=Number.isFinite(mark)?mark:0
for(const[name,one]of families)if(one.seq>after)out[name]=row(one)
return out},
state(){const out={}
for(const[name,one]of families)out[name]=row(one)
return{warm:{...warm},families:out}}}}
export const IDENTITY_MEMO_KEEP=8
export const LADDER_FROM_WARM='прогрев'
export function ladderFromOf(built,builder){const name=typeof builder==='string'&&builder!==''?builder:null
return built===true?(name??'счёт'):(name??'кэш')}
export const ladderLedger=createLadderLedger()
export function createAgedMemo(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function')throw new Error('sbc-valuation: нужны часы (правило 6 NIGHT_BRIEF)')
const maxAgeMs=Number.isFinite(deps.maxAgeMs)&&deps.maxAgeMs>0?deps.maxAgeMs:null
const keep=Number.isSafeInteger(deps.keep)&&deps.keep>0?deps.keep:1
const name=typeof deps.name==='string'&&deps.name!==''?deps.name:null
const ledger=deps.ledger===null?null:(deps.ledger??ladderLedger)
const stamp=typeof deps.stamp==='function'?deps.stamp:null
const held=new Map()
const flight=new Map()
const seen={hits:0,misses:0,shared:0,aborted:0,moved:0,blind:0}
const say=(from,startedAt,age,key)=>{if(name===null||ledger===null)return
ledger.note(name,{from,ms:clock.now()-startedAt,age,key})}
const keyOf=(raw)=>{if(stamp===null)return String(raw)
let parts=null
try{parts=stamp()}catch{return null}
const tail=stampOf(parts)
return tail===null?null:`${raw}|${tail}`}
const remember=(key,value,at,from)=>{held.delete(key)
held.set(key,{value,at,from})
while(held.size>keep){const oldest=held.keys().next()
if(oldest.done)break
held.delete(oldest.value)}}
const memo=async(raw,build,as)=>{const startedAt=clock.now()
const from=typeof as==='string'&&as!==''?as:null
const key=keyOf(raw)
if(key===null){seen.blind+=1
const value=await build()
say(ladderFromOf(true,from),startedAt,null,null)
return value}
const known=held.get(key)
if(known!==undefined&&(maxAgeMs===null||clock.now()-known.at<maxAgeMs)){seen.hits+=1
say(ladderFromOf(false,known.from),startedAt,clock.now()-known.at,key)
return known.value}
const running=flight.get(key)
if(running!==undefined){const shared=await running
if(shared!==undefined){seen.shared+=1
say('общий',startedAt,0,key)
return shared}
seen.aborted+=1}
seen.misses+=1
const promise=Promise.resolve().then(()=>build())
flight.set(key,promise)
let built
try{built=await promise}finally{if(flight.get(key)===promise)flight.delete(key)}
if(built===undefined)return undefined
if(keyOf(raw)===key)remember(key,built,clock.now(),from)
else{held.delete(key)
seen.moved+=1}
say(ladderFromOf(true,from),startedAt,0,key)
return built}
memo.state=()=>({keys:held.size,...seen})
return memo}
function plainLadders(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw))return null
const out={}
for(const key of Object.keys(raw)){const rarity=Number(key)
const steps=Array.isArray(raw[key])
?raw[key].filter((step)=>Number.isFinite(step?.rating)&&Number.isFinite(step?.price)&&step.price>0)
:[]
if(!Number.isSafeInteger(rarity)||rarity<0||steps.length===0)continue
out[rarity]=steps}
return Object.keys(out).length===0?null:out}
function plainGroups(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw))return null
const out={}
for(const key of Object.keys(raw)){const rarity=Number(key)
const groups=Array.isArray(raw[key])?raw[key].filter((one)=>Number.isSafeInteger(one)&&one>=0):[]
if(!Number.isSafeInteger(rarity)||rarity<0||groups.length===0)continue
out[rarity]=groups}
return Object.keys(out).length===0?null:out}
export function priceTotalOf(players,priceOf){if(typeof priceOf!=='function')return null
let total=0
let unknown=0
let priced=0
for(const player of Array.isArray(players)?players:[]){const price=priceOf(player)
if(!Number.isFinite(price)||price<=0){unknown+=1
continue}
total+=price
priced+=1}
return{total,unknown,priced}}
export function burnTotalOf(players,valuation,priceOf,mine){if(!valuation)return null
const ctx={...ctxOf(valuation),priceOf:typeof priceOf==='function'?priceOf:undefined}
const own=mine instanceof Set?mine:new Set((Array.isArray(mine)?mine:[]).map(String))
let cost=0
let unknown=0
let priced=0
let skipped=0
for(const player of Array.isArray(players)?players:[]){if(own.has(String(player?.id??''))){skipped+=1
continue}
const value=burnCostOf(player,valuation.prices,ctx)
if(!Number.isFinite(value)){unknown+=1
continue}
cost+=value
priced+=1}
return{cost,unknown,priced,mine:skipped}}
export function explainSolve(input={}){const answer=input.answer&&typeof input.answer==='object'?input.answer:null
if(answer===null)return{ok:false,reason:'no-solve',hint:'зайди на испытание и дождись подбора'}
const prices=input.prices&&typeof input.prices==='object'?input.prices:null
const requirements=Array.isArray(input.requirements)?input.requirements:[]
return{ok:answer.ok===true,
reason:answer.ok===true?null:(answer.notice?.params?.reason??answer.notice?.key??'unknown'),
challenge:input.challenge??null,at:Number.isFinite(input.at)?input.at:null,
mode:input.mode??null,
cards:cardRows(answer,input),
buys:buyRows(answer,prices,input),
pool:poolRows(prices,requirements,answer),
buckets:bucketRow(prices,requirements),
clusters:answer?.search?.clusters??null,
demand:demandRows(input.openChallenges,requirements,input.valuation),
verdict:verdictRow(answer)}}
function bucketRow(prices,requirements){if(!Array.isArray(prices?.buckets)||prices.buckets.length===0)return null
try{return{rows:prices.buckets.length,...bucketPlanOf(prices,requirements)}}catch{return null}}
function cardRows(answer,input){const selection=Array.isArray(answer?.prepared?.selection)?answer.prepared.selection:[]
const mine=new Set((Array.isArray(answer?.mine)?answer.mine:[]).map(String))
const valuation=input.valuation&&typeof input.valuation==='object'?input.valuation:null
const ctx=valuation===null?null:{...ctxOf(valuation),
priceOf:typeof input.priceOf==='function'?input.priceOf:undefined}
return selection.map((card)=>{const id=String(card?.id??'')
const row={id,def:card?.definitionId??card?.defId??null,
rating:Number.isFinite(card?.rating)?card.rating:null,
role:card?.virtual===true?'buy':(mine.has(id)?'mine':'club')}
if(row.role!=='club'||ctx===null)return row
let told=null
let seek=null
try{told=explainBurnOf(card,valuation.prices,ctx)
seek=searchBurnOf(card,valuation.prices,ctx)}catch{told=null}
return told===null?{...row,cost:null,search:null,path:'error'}
:{...row,cost:Number.isFinite(told.cost)?told.cost:null,search:Number.isFinite(seek)?seek:null,path:told.path,...(told.of?{of:told.of}:{})}})}
export function clubWorth(input={}){const valuation=input.valuation&&typeof input.valuation==='object'?input.valuation:null
if(valuation===null)return{ok:false,reason:'no-prices',hint:'лестница цен не собралась — считать нечем'}
const want=new Set((Array.isArray(input.ratings)?input.ratings:[input.ratings]).map(Number).filter(Number.isFinite))
const ctx={...ctxOf(valuation),
priceOf:typeof input.priceOf==='function'?input.priceOf:undefined}
const isLocked=typeof input.isLocked==='function'?input.isLocked:()=>false
const active=new Set((Array.isArray(input.activeIds)?input.activeIds:[]).map(String))
const used=new Set((Array.isArray(input.answer?.prepared?.selection)?input.answer.prepared.selection:[]).map((one)=>String(one?.id??'')))
const club=Array.isArray(input.club)?input.club:[]
const nameOf=typeof input.nameOf==='function'?(card)=>{try{return String(input.nameOf(card))}catch{return null}}:null
const keyOf=typeof input.keyOf==='function'?(card)=>{try{return input.keyOf(card)??null}catch{return null}}:null
const kept=input.keptIds===undefined||input.keptIds===null||keyOf===null
?null
:new Set([...input.keptIds].map(String))
const winner=new Map()
if(kept!==null){for(const card of club){if(!kept.has(String(card?.id??'')))continue
const key=keyOf(card)
if(key!==null&&!winner.has(key))winner.set(key,card)}}
const rows=[]
for(const card of club){if(!want.has(Number(card?.rating)))continue
const id=String(card?.id??'')
let told=null
let seek=null
try{told=explainBurnOf(card,valuation.prices,ctx)
seek=searchBurnOf(card,valuation.prices,ctx)}catch{told=null}
rows.push({id,def:card?.definitionId??card?.defId??null,rating:Number(card?.rating),
...(nameOf===null?{}:{name:nameOf(card)}),
cost:told&&Number.isFinite(told.cost)?told.cost:null,
search:Number.isFinite(seek)?seek:null,
path:told===null?'error':told.path,...(told?.of?{of:told.of}:{}),
locked:isLocked(card?.id)===true,active:active.has(id),used:used.has(id),
dup:(()=>{try{return valuation.isDuplicate(card)===true}catch{return false}})(),
...(kept===null||kept.has(id)?{}:{cut:cutBy(winner.get(keyOf(card))??null,nameOf)})})}
rows.sort((a,b)=>(a.search??Number.POSITIVE_INFINITY)-(b.search??Number.POSITIVE_INFINITY))
const count=Number.isFinite(input.count)&&input.count>0?input.count:12
return{ok:true,ratings:[...want],found:rows.length,
...(kept===null?{}:{cut:rows.filter((one)=>one.cut!==undefined).length}),
rows:rows.slice(0,count)}}
function cutBy(winner,nameOf){return winner===null
?{by:null,rating:null,def:null,name:null,why:'mine'}
:{by:String(winner.id??''),rating:Number(winner.rating),
def:winner.definitionId??winner.defId??null,
name:nameOf===null?null:nameOf(winner),why:'copy'}}
function buyRows(answer,prices,input){const liveOf=typeof input.liveOf==='function'?input.liveOf:null
const ageMs=Number.isFinite(input.blobAgeMs)?input.blobAgeMs:null
return(Array.isArray(answer?.buys)?answer.buys:[]).map((buy)=>{const parts=String(buy?.id??'').split(':')
const bucketToken=bucketTokenOf(buy?.id)
const bucket=bucketToken===null?null:bucketIndexOf(prices).get(bucketToken)??null
const token=parts.length>3?parts[1]:null
const family=bucketToken!==null?null:(token===null?null:/^([rlnc])(\d+)$/.exec(token))
const def=Number.isSafeInteger(buy?.definitionId)?buy.definitionId:null
const live=def===null||liveOf===null?null:liveOf(def)
const steps=bucketToken!==null?(Array.isArray(bucket?.picks)?bucket.picks:[]):familySteps(prices,family)
const step=steps.find((one)=>one.rating===buy?.rating)
return{id:String(buy?.id??''),family:bucketToken!==null?'g':(family===null?'base':family[1]),
key:bucketToken!==null?bucketToken:(family===null?String(parts[1]??''):`${family[1]}${family[2]}:${parts[2]??''}`),
copy:Number(parts[parts.length-1]),def,
rating:Number.isFinite(buy?.rating)?buy.rating:null,
price:Number.isFinite(buy?.price)?buy.price:null,
src:Number.isFinite(live)&&live>0?'live':'blob',
ageSec:Number.isFinite(live)&&live>0?0:(ageMs===null?null:Math.round(ageMs/1000)),
...(step?.quarantine?{quarantine:step.quarantine}:{}),
...(buy?.posEstimate===true?{pos:'estimate'}:{}),
steps:steps.length}})}
function familySteps(prices,family){const steps=family===null?prices?.ladder:prices?.[FAMILY_PROP[family[1]]]?.[Number(family[2])]
return Array.isArray(steps)?steps:[]}
const FAMILY_PROP={r:'rarityLadders',l:'leagueLadders',n:'nationLadders',c:'clubLadders'}
const FAMILY_OF=(id)=>{if(bucketTokenOf(id)!==null)return'g'
const parts=String(id??'').split(':')
const token=parts.length>3?parts[1]:null
const family=token===null?null:/^([rlnc])\d+$/.exec(token)
return family===null?'base':family[1]}
function poolRows(prices,requirements,answer){const out={base:row(),r:row(),l:row(),n:row(),c:row(),g:row()}
if(prices===null)return out
out.base.steps=Array.isArray(prices.ladder)?prices.ladder.length:0
out.base.held=heldSteps(prices.ladder)
out.g.keys=Array.isArray(prices.buckets)?prices.buckets.length:0
for(const one of Array.isArray(prices.buckets)?prices.buckets:[]){const picks=Array.isArray(one?.picks)?one.picks.length:0
if(picks>0)out.g.steps+=1}
for(const[tag,prop]of Object.entries(FAMILY_PROP)){const ladders=prices[prop]
if(!ladders||typeof ladders!=='object')continue
for(const key of Object.keys(ladders)){out[tag].keys+=1
out[tag].steps+=Array.isArray(ladders[key])?ladders[key].length:0
out[tag].held+=heldSteps(ladders[key])}}
let pool=[]
try{pool=virtualBuysFrom(prices,{requirements})}catch{pool=[]}
for(const one of pool){const tag=FAMILY_OF(one?.id)
if(out[tag])out[tag].pool+=1}
for(const buy of Array.isArray(answer?.buys)?answer.buys:[]){const tag=FAMILY_OF(buy?.id)
if(out[tag])out[tag].chosen+=1}
return out}
const row=()=>({keys:0,steps:0,held:0,pool:0,chosen:0})
function heldSteps(steps){let held=0
for(const step of Array.isArray(steps)?steps:[]){if(step?.quarantine)held+=1}
return held}
function demandRows(openChallenges,requirements,valuation){const list=Array.isArray(openChallenges)?openChallenges:[]
const keys={}
let parsed=0
let skipped=0
const count=(reqs)=>{const read=parseRequirements(reqs)
skipped+=read.skipped
for(const req of read.requirements){parsed+=1
for(const key of [req.key,...(Array.isArray(req.combined)?req.combined.map((one)=>one.key):[])]){const name=KEY_NAME[key]??`key-${key}`
keys[name]=(keys[name]??0)+1}}}
for(const challenge of list)count(challenge?.requirements??challenge?.eligibilityRequirements)
const rows=classRows(valuation)
return{challenges:list.length,requirements:parsed,skipped,keys,
open:requirements.length,
classes:(()=>{try{return demandClasses(requirements).length}catch{return null}})(),
live:rows===null?null:rows.length,
priced:rows===null?null:rows.filter((one)=>one.price!==null).length,
futureRatings:Array.isArray(valuation?.futureRatings)?[...valuation.futureRatings]:null,
rows:rows===null?[]:rows}}
function classRows(valuation){const classes=Array.isArray(valuation?.classes)?valuation.classes:null
if(classes===null)return null
const rows=classes.map((cls)=>{let price=null
try{price=classPrice(cls,valuation.prices)}catch{price=null}
return{...cls,price:Number.isFinite(price)?price:null}})
rows.sort((a,b)=>(b.price??-1)-(a.price??-1))
return rows}
const KEY_NAME=Object.fromEntries(Object.entries(REQUIREMENT_KEY).map(([name,value])=>[value,name]))
function verdictRow(answer){return{stop:answer?.notice?.params?.reason??answer?.notice?.key??null,search:answer?.search??null,
shaping:answer?.search?.shaping??null,exhausted:answer?.search?.exhausted===true,
panic:answer?.search?.panic??null,
chemOrder:answer?.search?.chemOrder??null,
unmet:Number.isFinite(answer?.search?.unmet)?answer.search.unmet:null,
lack:Number.isFinite(answer?.search?.lack)?answer.search.lack:null,
spend:answer?.spend??null,shop:answer?.shop??null,
counterweight:answer?.counterweight??null,
specGate:answer?.specGate??null,
clubGate:answer?.clubGate??null,
marketBlind:Array.isArray(answer?.marketBlind)?[...answer.marketBlind]:[],
failed:Array.isArray(answer?.failed)?[...answer.failed]:[],
burn:answer?.burn??null,pool:answer?.pool??null}}
export function dumpSolve(input={}){const prices=input.prices&&typeof input.prices==='object'?input.prices:null
const valuation=input.valuation&&typeof input.valuation==='object'?input.valuation:null
const requirements=Array.isArray(input.requirements)?input.requirements:[]
const club=Array.isArray(input.club)?input.club:[]
const cap=Number.isFinite(input.limit)&&input.limit>0?Math.floor(input.limit):DUMP_LIMIT
const rows=club.map((card)=>dumpCard(card,valuation,prices,input.priceOf))
const at=Number.isFinite(input.at)?input.at:null
const atDump=Number.isFinite(input.atDump)?input.atDump:null
const dump={ok:true,at,atDump,
ageMs:at===null||atDump===null?null:atDump-at,
challenge:challengeRow(input.challenge,requirements),
run:{mode:input.mode??null,maxSpend:null,...(input.run&&typeof input.run==='object'?input.run:{})},
version:DUMP_VERSION,
live:liveRow(input,valuation,rows),
phases:input.phases&&typeof input.phases==='object'?input.phases:null,
data:dataCensus(club,prices),
worth:worthCensus(rows,valuation),
pool:{count:club.length,cards:rows,...readerRow(rows,input),
sources:input.sources&&typeof input.sources==='object'?{...input.sources}:null,
refused:input.refused&&typeof input.refused==='object'?{...input.refused}:null},
prices:pricesDump(prices,input.priceAges),
limit:{cap,bytes:0,cut:[]}}
const cut=dump.limit.cut
let text=safeJson(dump)
if(text.length>cap&&Array.isArray(dump.prices?.buckets)){const of=dump.prices.buckets.length
const keep=Math.max(0,Math.floor(of*cap/text.length))
dump.prices.buckets=dump.prices.buckets.slice(0,keep)
cut.push({what:'prices.buckets',kept:keep,of})
text=safeJson(dump)}
if(text.length>cap&&Array.isArray(dump.prices?.ladder)){let of=0
for(const step of dump.prices.ladder){if(!Array.isArray(step?.picks))continue
of+=step.picks.length
delete step.picks}
if(of>0){cut.push({what:'prices.ladder.picks',kept:0,of})
text=safeJson(dump)}}
if(text.length>cap){const of=dump.pool.cards.length
dump.pool.cards.sort((a,b)=>(a.search??Number.POSITIVE_INFINITY)-(b.search??Number.POSITIVE_INFINITY))
const keep=Math.max(0,Math.floor(of*cap/text.length))
dump.pool.cards=dump.pool.cards.slice(0,keep)
cut.push({what:'pool.cards',kept:keep,of})
text=safeJson(dump)}
dump.limit.bytes=text.length
return{...dump,json:text}}
const DUMP_LIMIT=4000000
export const DUMP_VERSION=2
function liveRow(input,valuation,rows){const list=(value)=>(Array.isArray(value)?value:[])
const told=input.answer&&typeof input.answer==='object'?input.answer:null
const seek=told?.search&&typeof told.search==='object'?told.search:null
const was=seek?.live&&typeof seek.live==='object'?seek.live:null
const of=(name)=>input[name]??was?.[name]??null
return{protectedIds:list(of('protectedIds')).map((id)=>String(id)),
fixed:list(of('fixed')).map((one)=>({id:String(one?.player?.id??one?.id??''),
slot:Number.isFinite(one?.slot)?one.slot:null})).filter((one)=>one.id!==''),
manager:(()=>{const boss=of('manager')
if(boss&&typeof boss==='object')return{league:boss.leagueId??boss.league??null,nation:boss.nationId??boss.nation??null,club:boss.teamId??boss.club??null}
return(input.manager!==undefined||(was!==null&&'manager' in was))?null:'not-asked'})(),
linkedTeam:(input.linkedTeam??was?.linkedTeam)===true,
linkedTeams:(()=>{const pairs=input.linkedTeams??was?.linkedTeams
return(Array.isArray(pairs)?pairs:[]).filter((one)=>Array.isArray(one)&&Number.isFinite(one[0])&&Number.isFinite(one[1]))
.map((one)=>[one[0],one[1]])})(),
floatRating:(()=>{const float=of('floatRating')
return typeof float==='boolean'?float:null})(),
bricks:list(of('bricks')).filter((one)=>Number.isInteger(one?.at)&&Number.isFinite(one?.position))
.map((one)=>({at:one.at,position:one.position,club:one.club??null,league:one.league??null,nation:one.nation??null,positions:list(one.positions)})),
classes:list(valuation?.classes),
futureRatings:list(valuation?.futureRatings),
answer:told===null?null:(()=>{const say=(name)=>told[name]??seek?.[name]??null
return{ok:told.ok===true,reason:told.reason??told.notice?.params?.reason??null,
failed:list(told.failed).map((one)=>({name:one?.name??null,need:one?.need??null,have:one?.have??null})),
shaping:say('shaping'),starts:say('starts'),
circles:say('circles'),
budget:told.budget??seek?.solverBudget??null,
unfinished:(told.unfinished??seek?.unfinished)===true,
panic:told.panic??seek?.panic??null,
chemOrder:told.chemOrder??seek?.chemOrder??null,
exhausted:(told.exhausted??seek?.exhausted)===true,evaluations:say('evaluations'),
unmet:say('unmet'),lack:say('lack'),
phase:seek?.phase&&typeof seek.phase==='object'?seek.phase:null}})(),
shown:shownRow(told,input.shownTotal,rows),
ladder:input.ladder&&typeof input.ladder==='object'?input.ladder:null,
buy:input.buy&&typeof input.buy==='object'?input.buy:null,
rebuilds:Number.isFinite(input.rebuilds)?input.rebuilds:null}}
function shownRow(told,total,rows){if(told===null||typeof told!=='object')return null
const list=(value)=>(Array.isArray(value)?value:[])
const burn=told.burn&&typeof told.burn==='object'?told.burn:null
const cost=new Map(list(rows).map((one)=>[one.id,one.cost]))
return{burn:burn===null?null:{cost:Number.isFinite(burn.cost)?burn.cost:null,
unknown:Number.isFinite(burn.unknown)?burn.unknown:null},
spend:Number.isFinite(told.spend)?told.spend:null,
total:Number.isFinite(total)?total:null,
buys:list(told.buys).map((one)=>({definitionId:one?.definitionId??null,
rating:Number.isFinite(one?.rating)?one.rating:null,
price:Number.isFinite(one?.price)?one.price:null,
path:one?.id??null,affiliation:one?.affiliation??null,
alts:list(one?.alts).map((alt)=>({id:alt?.id??null,price:Number.isFinite(alt?.price)?alt.price:null}))})),
selection:list(told.prepared?.selection).map((one)=>{const id=String(one?.id??'')
const virtual=one?.virtual===true
return{id,cost:virtual?(Number.isFinite(one?.buyPrice)?one.buyPrice:null):(cost.get(id)??null),virtual}})}}
function safeJson(value){try{return JSON.stringify(value)??''}catch{return ''}}
function challengeRow(challenge,requirements){const{requirements:parsed,skipped}=parseRequirements(requirements)
const squad=challenge?.squad
let slots=[]
try{slots=typeof squad?.getSBCSlots==='function'?squad.getSBCSlots():(Array.isArray(squad?.slots)?squad.slots:[])}catch{slots=[]}
return{id:challenge?.id??null,name:challenge?.name??null,set:challenge?.setId??challenge?.setid??null,
operation:challenge?.eligibilityOperation??null,
size:(()=>{try{return typeof squad?.getNumOfRequiredPlayers==='function'?squad.getNumOfRequiredPlayers():slots.length}catch{return slots.length}})(),
positions:slots.map((slot)=>slot?.position?.typeId??null),
skipped,requirements:parsed.map((req)=>({key:req.key,name:req.name,compare:req.compare,value:req.value,
values:Array.isArray(req.values)?[...req.values]:[],count:req.count,need:needOf(req),
...(Array.isArray(req.combined)?{combined:req.combined.map((one)=>({key:one.key,name:one.name,values:one.values}))}:{})}))}}
function readerRow(rows,input){const priced=rows.filter((one)=>Number.isFinite(one?.price)&&one.price>0).length
const brain=input?.run?.pool?.priced
const known=Number.isFinite(brain)&&brain>=0
return{priced,brainPriced:known?brain:null,reader:known?(priced===brain?'один':'второй'):null}}
function dumpCard(card,valuation,prices,priceOf){const ctx=valuation===null?null:{...ctxOf(valuation),priceOf:typeof priceOf==='function'?priceOf:undefined}
let told=null
let seek=null
if(ctx!==null){try{told=explainBurnOf(card,prices,ctx)
seek=searchBurnOf(card,prices,ctx)}catch{told=null}}
let price=null
try{price=typeof priceOf==='function'?priceOf(card):null}catch{price=null}
return{id:String(card?.id??''),def:card?.definitionId??card?.defId??null,
rating:Number.isFinite(card?.rating)?card.rating:null,rare:card?.rareflag??card?.rarity??null,
groups:Array.isArray(card?.groups)?[...card.groups]:null,
league:card?.leagueId??null,nation:card?.nationId??null,club:card?.teamId??null,
pos:Array.isArray(card?.possiblePositions)?[...card.possiblePositions]:null,
trade:tradabilityOf(card),concept:card?.concept===true,
dup:(()=>{try{return valuation?.isDuplicate?.(card)===true}catch{return false}})(),
price:Number.isFinite(price)?price:null,
cost:told&&Number.isFinite(told.cost)?told.cost:null,
search:Number.isFinite(seek)?seek:null,
future:told&&Number.isFinite(told.future)?told.future:null,
path:told===null?null:told.path,...(told?.of?{of:told.of}:{}),
...(isSbcPlayer(card)?{}:{player:false,type:typeof card?.type==='string'?card.type:null})}}
function pricesDump(prices,ages){if(prices===null)return null
const out={ladder:Array.isArray(prices.ladder)?prices.ladder.map((step)=>({...step,...(Array.isArray(step?.picks)?{picks:step.picks.map((one)=>({...one}))}:{})})):null,
byRarity:prices.byRarity??null,rarityGroups:prices.rarityGroups??null,
buckets:Array.isArray(prices.buckets)?prices.buckets.map((row)=>({...row})):null}
for(const prop of['rarityLadders',...IDENTITY_LADDER_PROPS])out[prop]=prices[prop]??null
out.at=ages&&typeof ages==='object'
?Object.fromEntries(Object.entries(ages).map(([name,row])=>[name,row&&typeof row==='object'?{...row}:row]))
:null
out.ageMs=(()=>{if(!ages||typeof ages!=='object')return null
let oldest=null
for(const row of Object.values(ages)){const age=row?.age
if(!Number.isFinite(age))continue
if(oldest===null||age>oldest)oldest=age}
return oldest})()
return out}
function worthCensus(rows,valuation){const paths={}
const under={}
let unknown=0
for(const one of rows){
if(!Number.isFinite(one?.cost))unknown+=1
const path=one?.path
if(path===null||path===undefined)continue
paths[path]=(paths[path]??0)+1
if(one.of)under[one.of]=(under[one.of]??0)+1}
const classes=Array.isArray(valuation?.classes)?valuation.classes:null
return{cards:rows.length,paths,under,unknown,
classes:classes===null?null:classes.length,
priced:classes===null?null:classes.filter((cls)=>{let price=null
try{price=classPrice(cls,valuation.prices)}catch{price=null}
return Number.isFinite(price)}).length}}
function dataCensus(club,prices){let groups=0
let rare=0
for(const card of club){if(Array.isArray(card?.groups)&&card.groups.length>0)groups+=1
if(Number.isFinite(card?.rareflag??card?.rarity))rare+=1}
return{cards:club.length,groups,rare,
book:prices?.rarityGroups&&typeof prices.rarityGroups==='object'?Object.keys(prices.rarityGroups).length:0}}
