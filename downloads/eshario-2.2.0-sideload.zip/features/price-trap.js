export const COLLAPSE_FACTOR=2
export const TRAP_GAP_MS=60_000
export const TRAP_KEEP=8
export const RAW_RADIUS=4
const SAME_PRICE_PART=0.1
export function collapsedSteps(prev,next,factor=COLLAPSE_FACTOR){const k=Number.isFinite(factor)&&factor>1?factor:COLLAPSE_FACTOR
const was=new Map()
for(const step of Array.isArray(prev)?prev:[]){if(isPrice(step?.price)&&Number.isFinite(step?.rating))was.set(step.rating,step)}
const out=[]
for(const step of Array.isArray(next)?next:[]){const old=was.get(step?.rating)
if(old===undefined||!isPrice(step?.price))continue
if(step.price*k>=old.price)continue
out.push({rating:step.rating,was:old.price,now:step.price,
wasId:idOrNull(old.id),nowId:idOrNull(step.id),
drop:Math.round(old.price/step.price*100)/100})}
out.sort((a,b)=>b.drop-a.drop)
return out}
export function createPriceTrap(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function')throw new Error('price-trap: нужны часы (правило 6 NIGHT_BRIEF)')
const rawOf=typeof deps.rawOf==='function'?deps.rawOf:null
const crossOf=typeof deps.crossOf==='function'?deps.crossOf:null
const shout=typeof deps.shout==='function'?deps.shout:()=>{}
const factor=Number.isFinite(deps.factor)&&deps.factor>1?deps.factor:COLLAPSE_FACTOR
const gapMs=Number.isFinite(deps.gapMs)&&deps.gapMs>=0?deps.gapMs:TRAP_GAP_MS
const keep=Number.isSafeInteger(deps.keep)&&deps.keep>0?deps.keep:TRAP_KEEP
const journal=[]
let firedAt=null
let fires=0
let skipped=0
return{
watch(prev,next){const steps=collapsedSteps(prev,next,factor)
if(steps.length===0)return null
if(firedAt!==null&&clock.now()-firedAt<gapMs){skipped+=1
return null}
firedAt=clock.now()
fires+=1
const worst=steps[0]
let raw=null
if(rawOf!==null&&worst.nowId!==null){try{raw=rawOf(worst.nowId,RAW_RADIUS)}catch{raw=null}}
const record={at:firedAt,...worst,
s:slotSourceOf(raw,worst.nowId),
slot:raw?.slot??null,window:raw?.window??[],lengths:raw?.lengths??null,file:raw?.file??null,
also:steps.slice(1).map((one)=>({rating:one.rating,was:one.was,now:one.now,drop:one.drop})),
cross:null,verdict:'no-cross'}
journal.push(record)
while(journal.length>keep)journal.shift()
shout('дно ступени обвалилось',{rating:record.rating,was:record.was,now:record.now,drop:record.drop,id:record.nowId,slot:record.slot})
if(crossOf!==null&&worst.nowId!==null){Promise.resolve()
.then(()=>crossOf(worst.nowId))
.then((cross)=>{record.cross=cross??null
record.verdict=verdictOf(record.now,cross,factor,record.file?.at??null)
shout('кросс-чек пары индекс+dyn',{rating:record.rating,ours:record.now,pair:cross?.price??null,verdict:record.verdict})})
.catch((err)=>{record.cross={ok:false,price:null,reason:String(err?.message??err)}
record.verdict='no-cross'})}
return record},
log:()=>journal.map((one)=>({...one})),
state:()=>({fires,skipped,firedAt,kept:journal.length,factor,gapMs})}}
function verdictOf(now,cross,factor,fileAt){if(!cross||cross.ok!==true||!isPrice(cross.price))return 'no-cross'
if(cross.price>=now*factor){return Number.isFinite(fileAt)&&Number.isFinite(cross.at)&&cross.at<fileAt?'pair-older':'full-file'}
return Math.abs(cross.price-now)<=now*SAME_PRICE_PART?'source':'unclear'}
function slotSourceOf(raw,id){for(const row of Array.isArray(raw?.window)?raw.window:[]){if(row?.id===id)return row.s??null}
return null}
const isPrice=(value)=>typeof value==='number'&&Number.isFinite(value)&&value>0
const idOrNull=(value)=>Number.isSafeInteger(value)&&value>0?value:null
