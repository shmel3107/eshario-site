const CLUB='CLUB'
const SBC_STORAGE='STORAGE'
function isConsumable(item){try{if(item?.isConsumable?.()===true)return true}catch{/* спросим полем */}
const type=typeof item?.type==='string'?item.type:''
return type==='training'||type==='health'}
export function applyItemEvent(pool,event,lookup=null){if(!pool||!event||typeof event!=='object')return 'noted'
const ids=Array.isArray(event.ids)?event.ids:[]
const leave=()=>{pool.gone(ids)
return 'gone'}
const wait=(reason)=>{pool.markStale(reason)
return 'stale'}
const arrive=(fromEa,none,unknownReason)=>{if(fromEa===null||typeof pool.add!=='function')return wait(none)
const found=[]
let unknown=0
let foreign=0
for(const id of ids){let item=null
try{item=fromEa(id)}catch{item=null}
if((item===null||item===undefined)&&typeof pool.recall==='function')item=pool.recall(id)
if(item!==null&&item!==undefined&&isConsumable(item)){foreign+=1
continue}
if(item===null||item===undefined)unknown+=1
else found.push(item)}
if(found.length>0)pool.add(found)
if(foreign>0&&typeof pool.foreign==='function')pool.foreign(foreign)
if(unknown>0)return wait(unknownReason)
if(ids.length===0)return wait('empty-move')
if(found.length===0&&foreign>0)return 'noted'
return 'added'}
switch(event.name){
case 'ITEM_MOVE':
if(event.from===CLUB&&event.to!==CLUB)return leave()
if(event.to===CLUB)return arrive(typeof lookup==='function'?lookup:null,'no-lookup','unknown-arrival')
if(event.to===SBC_STORAGE)return arrive(typeof pool.fromStorage==='function'?(id)=>pool.fromStorage(id):null,
'storage-arrival','storage-arrival')
if(event.from===null&&event.to===null)return wait('no-pile')
pool.noted()
return 'noted'
case 'ITEM_LIST':
case 'ITEM_DISCARD':
case 'ITEM_CLEARSOLD':
if(ids.length>0)return leave()
pool.noted()
return 'noted'
case 'UNASSIGNED_ITEM_ADDED':
if(typeof pool.remember==='function')pool.remember(event.items)
pool.noted()
return 'noted'
default:
pool.noted()
return 'noted'}}
export class PoolFeedError extends Error{constructor(reason,meta={}){super(`пул: клуб не прочитан (${reason})`)
this.name='PoolFeedError'
this.reason=typeof reason==='string'&&reason!==''?reason:'read-failed'
this.got=Number.isFinite(meta.got)?meta.got:0
this.expected=Number.isFinite(meta.expected)?meta.expected:0}}
const POOL_MIN_SHARE=0.5
export const POOL_JOURNAL_MAX=100
export const POOL_HALL_MAX=300
export function poolHunger(pool={},mirror={}){const size=Number.isFinite(pool?.size)?pool.size:0
const rows=Number.isFinite(mirror?.mirrorRows)?mirror.mirrorRows:0
const refusal=pool?.refusal
if(refusal&&typeof refusal==='object'){const got=Number.isFinite(refusal.got)&&refusal.got>0?refusal.got:size
const expected=Number.isFinite(refusal.expected)&&refusal.expected>0?refusal.expected:rows
return{ok:false,reason:typeof refusal.reason==='string'&&refusal.reason!==''?refusal.reason:'read-failed',got,expected}}
if(pool?.loaded!==true)return{ok:true,reason:null,got:size,expected:rows}
if(rows>0&&size<Math.floor(rows*POOL_MIN_SHARE))return{ok:false,reason:'short',got:size,expected:rows}
return{ok:true,reason:null,got:size,expected:rows}}
export const POOL_PRICE_FLOOR=0.25
export function poolPriceWatch(pool={},deps={}){const size=Number.isFinite(pool?.size)&&pool.size>0?pool.size:0
const priced=Number.isFinite(pool?.priced)&&pool.priced>=0?pool.priced:null
const floor=Number.isFinite(deps?.floor)&&deps.floor>0&&deps.floor<=1?deps.floor:POOL_PRICE_FLOOR
const by=deps?.by&&typeof deps.by==='object'?deps.by:null
const out=(ok,reason,share)=>({ok,reason,share,floor,by:ok?null:by})
if(priced===null)return out(true,null,null)
if(size===0)return out(true,'empty-pool',null)
const share=priced/size
return share<floor?out(false,'price-blind',share):out(true,null,share)}
export function createPoolPriceEye(){let last=null
const seen={builds:0,empty:0}
return{
note(who,what={}){const name=typeof who==='string'&&who!==''?who:'неизвестно'
const built=Number.isFinite(what?.built)&&what.built>=0?what.built:null
const of=Number.isFinite(what?.of)&&what.of>=0?what.of:null
seen.builds+=1
if(built===0)seen.empty+=1
last={who:name,built,of,from:typeof what?.from==='string'&&what.from!==''?what.from:null}
return last},
last:()=>(last===null?null:{...last}),
state:()=>({...seen,last:last===null?null:{...last}})}}
export function createPoolCache(deps={}){const read=typeof deps.read==='function'?deps.read:null
const now=typeof deps.now==='function'?deps.now:()=>Date.now()
const accept=typeof deps.accept==='function'?deps.accept:()=>true
const storageItem=typeof deps.storageItem==='function'?deps.storageItem:null
let items=null
let repeated=0
let sources={club:0,storage:0}
let refused=0
let readAt=null
let changedAt=null
const touched=()=>{changedAt=now()}
let inflight=null
let reads=0
let hits=0
let invalidations=0
let forgotten=0
const readsBy={}
let staleBy=null
function noteRead(cause){const name=typeof cause==='string'&&cause!==''?cause:'unknown'
readsBy[name]=(readsBy[name]??0)+1
staleBy=null
return name}
let arrived=0
let refusals=0
let refusal=null
let stale=false
const events={applied:0,staled:0,ignored:0,missing:[],ok:false,stale:{}}
const hall=new Map()
let recalled=0
let storageFound=0
let foreignItems=0
let generation=0
let journal=null
let journalRuns=0
let journalAdded=0
let journalRemoved=0
let journalOverflows=0
function openJournal(){journal={rows:new Map(),stale:false,count:0,overflow:false}}
function noteInJournal(op,id,card){if(journal===null)return
if(journal.count>=POOL_JOURNAL_MAX){journal.overflow=true
return}
journal.count+=1
journal.rows.set(String(id),op==='add'?{op,card}:{op})}
function replayJournal(){const box=journal
journal=null
if(box===null||items===null)return
if(box.overflow){journalOverflows+=1
stale=true
return}
const drops=new Set()
const adds=[]
for(const[id,entry]of box.rows){if(entry.op==='drop')drops.add(id)
else adds.push(entry.card)}
let removed=0
if(drops.size>0){const before=items.length
items=items.filter((one)=>!drops.has(String(one?.id)))
removed=before-items.length}
let added=0
if(adds.length>0){const known=new Set(items.map((one)=>String(one?.id)))
for(const card of adds){const id=String(card?.id??card?.itemId??'')
if(id===''||known.has(id))continue
known.add(id)
items.push(card)
added+=1}}
if(box.stale)stale=true
if(box.rows.size>0||box.stale){journalRuns+=1
journalAdded+=added
journalRemoved+=removed
if(added>0||removed>0)touched()
generation+=1}}
function load(){if(!read)return Promise.reject(new Error('пул: чтение не передано'))
if(inflight)return inflight
openJournal()
inflight=Promise.resolve()
.then(()=>read())
.then((result)=>{const list=Array.isArray(result?.items)?result.items:[]
items=list
repeated=Number.isFinite(result?.repeated)?result.repeated:0
refused=Number.isFinite(result?.refused)?result.refused:0
sources={club:Number.isFinite(result?.sources?.club)?result.sources.club:0,
storage:Number.isFinite(result?.sources?.storage)?result.sources.storage:0}
readAt=now()
touched()
reads+=1
refusal=null
stale=false
generation+=1
replayJournal()
inflight=null
return snapshot(false)})
.catch((err)=>{inflight=null
journal=null
refusals+=1
refusal={reason:typeof err?.reason==='string'&&err.reason!==''?err.reason:'read-failed',
got:Number.isFinite(err?.got)?err.got:0,expected:Number.isFinite(err?.expected)?err.expected:0,
at:now(),message:String(err?.message??err)}
throw err})
return inflight}
function snapshot(fromCache){return{items:items??[],repeated,refused,readAt,fromCache,sources:{...sources}}}
return{
read(){
if(stale&&inflight===null){invalidations+=1
noteRead(staleBy??'stale')
return load().catch((err)=>{if(items===null)throw err
return snapshot(true)})}
if(items!==null){hits+=1
return Promise.resolve(snapshot(true))}
if(inflight){hits+=1
return inflight.then(()=>snapshot(true))}
noteRead('first')
return load()},
gone(ids){const removed=this.forget(ids)
if(removed>0)events.applied+=1
else events.ignored+=1
return removed},
markStale(reason){events.staled+=1
const name=typeof reason==='string'&&reason!==''?reason:'no-reason'
events.stale[name]=(events.stale[name]??0)+1
if(staleBy===null)staleBy=name
if(journal!==null)journal.stale=true
if(stale)return false
stale=true
generation+=1
return true},
remember(items){for(const item of Array.isArray(items)?items:[]){if(!item||typeof item!=='object')continue
const id=String(item?.id??item?.itemId??'')
if(id==='')continue
if(hall.size>=POOL_HALL_MAX&&!hall.has(id)){const oldest=hall.keys().next()
if(!oldest.done)hall.delete(oldest.value)}
hall.set(id,item)}
return hall.size},
recall(id){const key=String(id)
if(!hall.has(key))return null
const item=hall.get(key)
hall.delete(key)
recalled+=1
return item},
fromStorage(id){if(storageItem===null)return null
let item=null
try{item=storageItem(id)}catch{item=null}
if(item===null||item===undefined)return null
storageFound+=1
return item},
foreign(count){const n=Number.isSafeInteger(count)&&count>0?count:0
foreignItems+=n
if(n>0)events.ignored+=1
return foreignItems},
add(cards){const list=Array.isArray(cards)?cards:[]
if(list.length===0)return 0
if(items===null&&journal===null)return 0
const known=new Set((items??[]).map((item)=>String(item?.id)))
let added=0
let noted=0
for(const card of list){if(!card||typeof card!=='object')continue
const id=String(card?.id??card?.itemId??'')
if(id===''||known.has(id))continue
if(!accept(card)){refused+=1
continue}
known.add(id)
noteInJournal('add',id,card)
noted+=1
if(items===null)continue
items.push(card)
added+=1}
if(added>0){arrived+=added
touched()
generation+=1}
if(added>0||noted>0)events.applied+=1
else events.ignored+=1
return added},
noted(){events.ignored+=1
return false},
subscribed(ok,missing){events.ok=ok===true
events.missing=Array.isArray(missing)?[...missing]:[]
return events.ok},
generation(){return generation},
peek(){return{players:items,generation}},
refresh(){invalidations+=1
stale=false
generation+=1
noteRead('refresh')
return load().catch((err)=>{if(items===null)throw err
return snapshot(true)})},
forget(ids){const gone=new Set((Array.isArray(ids)?ids:[]).map((id)=>String(id)))
if(gone.size===0)return 0
for(const id of gone)noteInJournal('drop',id,null)
if(items===null)return 0
const before=items.length
items=items.filter((item)=>!gone.has(String(item?.id)))
const removed=before-items.length
if(removed>0){forgotten+=removed
invalidations+=1
touched()
generation+=1}
return removed},
state(){return{size:items===null?0:items.length,readAt,
changedAt,repeated,refused,hits,reads,invalidations,forgotten,arrived,loaded:items!==null,
readsBy:{...readsBy},staleBy,
refusals,refusal:refusal===null?null:{...refusal},sources:{...sources},
stale,events:{...events,missing:[...events.missing],stale:{...events.stale}},generation,
arrivals:{hall:hall.size,foreign:foreignItems,recalled,storage:storageFound,storageDoor:storageItem!==null},
journal:{open:journal!==null,size:journal===null?0:journal.rows.size,
runs:journalRuns,added:journalAdded,removed:journalRemoved,overflows:journalOverflows}}}}}
export function createActiveSquadCache(deps={}){const read=typeof deps.read==='function'?deps.read:null
const now=typeof deps.now==='function'?deps.now:()=>Date.now()
let ids=null
let readAt=null
let inflight=null
let reads=0
let hits=0
let generation=0
let trip=0
function load(){if(!read)return Promise.reject(new Error('активный состав: чтение не передано'))
if(inflight)return inflight
const mine=trip
inflight=Promise.resolve()
.then(()=>read())
.then((list)=>{
if(mine!==trip)throw new Error('активный состав: ответ прошлой сессии отброшен')
ids=Array.isArray(list)?[...list]:[]
readAt=now()
reads+=1
generation+=1
inflight=null
return[...ids]})
.catch((err)=>{if(mine===trip)inflight=null
throw err})
return inflight}
return{
read(){if(ids!==null){hits+=1
return Promise.resolve([...ids])}
if(inflight){hits+=1
return inflight.then(()=>[...(ids??[])])}
return load()},
peek(){return ids===null?null:[...ids]},
stamp(){return ids===null?null:[...ids].map(String).sort().join(',')},
refresh(){ids=null
readAt=null
generation+=1
return load()},
forget(){const had=ids!==null||inflight!==null
trip+=1
ids=null
readAt=null
inflight=null
generation+=1
return had},
state(){return{size:ids===null?0:ids.length,readAt,hits,reads,generation,loaded:ids!==null,inflight:inflight!==null}}}}
