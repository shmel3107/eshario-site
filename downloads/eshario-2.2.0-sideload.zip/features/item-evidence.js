import{netAfterTax} from './tax.js'
import{installItemCellCapture} from '../adapter/item-cell.js'
const rows=new WeakMap()
export function buildItemEvidence(item,priceEvidence=null,options={}){const now=finite(options.now)?options.now:Date.now()
const id=positive(item?.id??item?.itemId)
const definitionId=positive(item?.definitionId??item?.defId)
const bought=money(item?.lastSalePrice,true)
const parsed=priceOf(priceEvidence)
const price=parsed.money
const afterTax=price.state==='known'?known(netAfterTax(price.coins)):unknown(price.state)
const profit=price.state==='known'&&bought.state==='known'?known(afterTax.coins-bought.coins):unknown(price.state==='unavailable'?'unavailable':'unknown')
const observedAt=finite(priceEvidence?.observedAt)?priceEvidence.observedAt:null
const providerObservedAt=finite(priceEvidence?.providerObservedAt)?priceEvidence.providerObservedAt:null
return Object.freeze({identity:Object.freeze({id,definitionId}),name:nameOf(item,definitionId??id),rating:finite(item?.rating)?item.rating:null,
money:Object.freeze({bought,price,afterTax,profit}),
provenance:Object.freeze({from:text(priceEvidence?.from)||'none',source:text(priceEvidence?.source)||null,reason:parsed.reason,observedAt,providerObservedAt,
ageMs:observedAt===null?null:Math.max(0,now-observedAt),freshness:providerObservedAt===null?'observation-only':'provider-timestamp'})})}
export function itemForEvidenceRow(row){return rows.get(row)??null}
export function installItemEvidenceCapture(win,onCapture=()=>{}){return installItemCellCapture(win,(row,item)=>{rows.set(row,item)
Promise.resolve().then(()=>{try{onCapture(row,item)}catch{}})})}
function priceOf(value){if(value&&typeof value==='object'&&value.ok===false)return{money:unknown('unavailable'),reason:text(value.reason)||'source-unavailable'}
const coins=money(value?.price,false)
return coins.state==='known'?{money:coins,reason:null}:{money:unknown('unknown'),reason:text(value?.reason)||null}}
function money(value,allowZero){return typeof value==='number'&&Number.isFinite(value)&&(allowZero?value>=0:value>0)?known(Math.round(value)):unknown('unknown')}
function known(coins){return Object.freeze({state:'known',coins})}
function unknown(state){return Object.freeze({state,coins:null})}
function positive(value){const n=typeof value==='string'&&/^\d+$/.test(value.trim())?Number(value):value
return Number.isSafeInteger(n)&&n>0?n:null}
function nameOf(item,fallback){let data=null
try{data=item?.getStaticData?.()}catch{}
for(const value of[data?.name,item?.displayName,item?.name,item?.commonName]){if(text(value))return text(value)}
return fallback===null?'':String(fallback)}
function finite(value){return typeof value==='number'&&Number.isFinite(value)}
function text(value){return typeof value==='string'?value.trim():''}
