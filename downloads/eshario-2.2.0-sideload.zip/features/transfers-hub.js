import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{pileRoom} from '../adapter/action-door.js'
import{ensureControls,logoMark} from '../ui/controls.js'
import{TRANSFERS_HUB_ROOT,TRANSFERS_HUB_GRID,TRANSFER_LIST_TILE,TRANSFER_TARGETS_TILE,
TILE_CONTENT_SELECTOR,TILE_BIG_VALUE,
tradePileNow,watchPileNow,auctionSecondsLeft,auctionWonNow,auctionWinningNow,auctionOutbidNow} from '../adapter/market-screen.js'
import{lotMoney,summarizeLots,coinsText,cardsUnitKey} from './transfer-list.js'
import{priceBadgePeek} from './price-badges.js'
import{boughtOf} from './purchase-log.js'
import{cardFrozenNow,cardFrozenKey} from './card-frozen.js'
import{searchScreenRoot,SNIPE_FEATURE} from './snipe-shared.js'
export{SNIPE_FEATURE}
export const HUB_BUILD='SNRETIRE-4'
const HUB_STYLESHEET=new URL('../ui/transfers-hub.css',import.meta.url).href
const HUB_LINK_ID='fut-companion-transfers-hub'
export const TILES_MARK='futSnipeTiles'
export const TILES_SELECTOR='[data-fut-snipe-tiles]'
export const DESK_MARK='futHubDesk'
export const DESK_SELECTOR='[data-fut-hub-desk]'
export const DESK_TARGETS='targets'
export const CAP_MARK='futHubCap'
export const CAP_SELECTOR='[data-fut-hub-cap]'
export const UNSOLD_MARK='futHubUnsold'
export const UNSOLD_SELECTOR='[data-fut-hub-unsold]'
export const WON_SELECTOR="[data-fut-hub-live='won']"
export const LIVE_MARK='futHubLive'
export const LIVE_SELECTOR='[data-fut-hub-live]'
export const STALE_MARK='futHubStale'
export const STALE_SELECTOR='[data-fut-hub-stale]'
export const TARGET_CELLS=Object.freeze([
Object.freeze({id:'won',key:'transfers.hub.wonLabel',tone:'fx-hub-won'}),
Object.freeze({id:'winning',key:'transfers.hub.winningLabel',tone:''}),
Object.freeze({id:'outbid',key:'transfers.hub.outbidLabel',tone:'fx-hub-outbid'})])
export const TONE_MARK='futHubTone'
export const TONE_SELECTOR='[data-fut-hub-tone]'
export const TONE_OK='ok'
export const TONE_WARN='warn'
export const TICK_FAR_MS=30_000
export const TICK_NEAR_MS=10_000
export const TICK_EDGE_MS=5_000
export function pileLots(items){const out=[]
for(const item of Array.isArray(items)?items:[]){let money=null
try{money=lotMoney(item,priceBadgePeek(item?.definitionId??item?.defId),boughtOf(item))}catch{money=null}
if(money===null)continue
out.push({money,quick:item?.discardValue,frozen:frozenOfItem(item)})}
return out}
function frozenOfItem(item){try{return cardFrozenNow(cardFrozenKey(item))===true}catch{return false}}
const countOf=(value)=>(Number.isSafeInteger(value)&&value>0?value:0)
export function nearestEndSeconds(items){let best=null
for(const one of Array.isArray(items)?items:[]){const left=auctionSecondsLeft(one)
if(left===null)continue
if(best===null||left<best)best=left}
return best}
export function wonCount(items){let seen=0
for(const one of Array.isArray(items)?items:[]){if(auctionWonNow(one)===true)seen+=1}
return seen}
export function targetsTally(items){const out={won:0,winning:0,outbid:0}
for(const one of Array.isArray(items)?items:[]){
if(auctionWonNow(one)===true){out.won+=1
continue}
if(auctionSecondsLeft(one)===null)continue
if(auctionWinningNow(one)===true){out.winning+=1
continue}
if(auctionOutbidNow(one)===true)out.outbid+=1}
return out}
export const EDGE_STEP_SECONDS=5
export function endWords(seconds,t){if(!Number.isFinite(seconds)||seconds<0)return null
if(seconds>=120)return t('transfers.hub.endsIn',{minutes:Math.floor(seconds/60)})
if(seconds>=60)return t('transfers.hub.endsIn',{minutes:1})
if(seconds>EDGE_STEP_SECONDS)
return t('transfers.hub.endsSec',{seconds:Math.floor(seconds/EDGE_STEP_SECONDS)*EDGE_STEP_SECONDS})
return t('transfers.hub.endsNow')}
export function tickStepMs(seconds){if(!Number.isFinite(seconds)||seconds<0)return TICK_FAR_MS
if(seconds<=60)return TICK_EDGE_MS
if(seconds<=120)return TICK_NEAR_MS
return TICK_FAR_MS}
export function stateLine(answer){
const yes=(value)=>(value===true?'да':'нет')
const parts=[`сборка ${answer?.build??'—'}`,
`хаб ${yes(answer?.hub)}`,
`раскладка ${answer?.laidOut??0}`,
`рядов ${answer?.rows??'—'}`,
`пайл ${answer?.pile?.known===true?`есть ${answer.pile.items}`:'не прочитан'}`,
`мест ${answer?.pile?.room??'—'}`,
`вставка цели ${answer?.desks?.targets??0}`,
`потолки ${answer?.caps===undefined||answer?.caps===''?'нет':answer.caps}`,
`не продано ${answer?.unsold===null||answer?.unsold===undefined?'нет':answer.unsold}`,
`победил ${answer?.won===null||answer?.won===undefined?'нет':answer.won}`,
`подвал целей ${answer?.foot===null||answer?.foot===undefined?'её собственный':answer.foot}`,
`цвета ${answer?.tones===undefined||answer?.tones===''?'нет':answer.tones}`,
`цели ${answer?.watch?.known===true?`есть ${answer.watch.items}`:'не прочитаны'}`,
`ближайший торг ${answer?.watch?.soonest===null||answer?.watch?.soonest===undefined?'—':`${answer.watch.soonest} с`}`,
`часы ${answer?.clock===true?`идут раз в ${Math.round((answer.step??0)/1000)} с`:'стоят'}`,
`проходов ${answer?.work?.passes??0}`]
return parts.join(' · ')}
export function createTransfersHub(deps={}){const{doc}=deps
const win=deps.win??doc?.defaultView??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const num=typeof deps.formatNumber==='function'?deps.formatNumber:(value)=>String(value)
const allowed=()=>{if(typeof deps.isActive!=='function')return true
try{return deps.isActive(SNIPE_FEATURE)===true}catch(err){onError(err)
return false}}
let passes=0
let paints=0
const painted=new WeakMap()
const native=new WeakMap()
function rootOf(){try{return doc?.querySelector?.(TRANSFERS_HUB_ROOT)??null}catch(err){onError(err)
return null}}
const deskCount=(kind)=>{try{return doc?.querySelectorAll?.(`[data-fut-hub-desk="${kind}"]`)?.length??0}catch{return 0}}
function gridOf(root){try{return root?.querySelector?.(TRANSFERS_HUB_GRID)??null}catch(err){onError(err)
return null}}
function readPile(){const pile=tradePileNow(win)
if(pile.known!==true)return null
try{return{boxes:summarizeLots(pileLots(pile.items)),room:pile.room}}catch(err){onError(err)
return null}}
let tick=null
let tickStep=null
function startTick(step){const want=Number.isSafeInteger(step)&&step>0?step:TICK_FAR_MS
if(tick!==null&&tickStep===want)return false
if(win===null||win===undefined||typeof win.setInterval!=='function')return false
stopTick()
try{tick=win.setInterval(()=>{try{refresh()}catch(err){onError(err)}},want)}catch(err){onError(err)
tick=null
return false}
tickStep=want
return true}
function stopTick(){if(tick===null)return false
try{win?.clearInterval?.(tick)}catch(err){onError(err)}
tick=null
tickStep=null
return true}
function deskNode(kind,chips,lines,soon=null){const rows=[]
if(Array.isArray(chips)&&chips.length>0){rows.push(el(doc,'div',{class:'fx-tile-chips'},
chips.map((one)=>el(doc,'span',{class:`fx-tile-chip ${one.tone??''}`.trim(),text:one.text,
attrs:one.title?{title:one.title}:{}}))))}
if(Array.isArray(lines)&&lines.length>0){for(const line of lines){
rows.push(el(doc,'div',{class:'fx-tile-line'},
[el(doc,'span',{class:'fx-tile-line-key',text:line.key}),
el(doc,'span',{class:'fx-tile-line-value',text:line.text})]))}}
if(soon!==null&&soon!==undefined){rows.push(el(doc,'div',{class:'fx-hub-soon'},
[el(doc,'div',{class:'fx-hub-soon-row'},
[el(doc,'span',{class:'fx-hub-clock',attrs:{'aria-hidden':'true'}}),
el(doc,'span',{class:'fx-hub-soon-value',text:soon.value})]),
el(doc,'span',{class:'fx-hub-soon-key',text:soon.key})]))}
return el(doc,'div',{class:'fx-tile-desk',dataset:{[DESK_MARK]:kind}},rows)}
function paintDesk(tile,kind,chips,lines,soon=null){if(!tile)return null
let content=null
try{content=tile.querySelector?.(TILE_CONTENT_SELECTOR)??null}catch(err){onError(err)
return null}
if(content===null)return null
let node=null
try{node=content.querySelector?.(`[data-fut-hub-desk="${kind}"]`)??null}catch(err){onError(err)
node=null}
const key=JSON.stringify([kind,chips,lines,soon])
if(node!==null&&painted.get(node)===key)return node
const fresh=deskNode(kind,chips,lines,soon)
painted.set(fresh,key)
paints+=1
let column=null
try{column=content.querySelector?.('.total-transfers-data')??null}catch{column=null}
let anchor=null
if(column===null){try{const rows=content.querySelectorAll?.('.transfer-row')??[]
anchor=rows.length>0?rows[rows.length-1]:null}catch{anchor=null}}
try{if(node!==null)node.remove()
if(column!==null)column.appendChild(fresh)
else if(anchor===null)content.appendChild(fresh)
else content.insertBefore(fresh,anchor)}catch(err){onError(err)
return null}
return fresh}
function dropDesks(kind=null){let gone=0
const where=kind===null?DESK_SELECTOR:`[data-fut-hub-desk="${kind}"]`
for(const one of Array.from(doc?.querySelectorAll?.(where)??[])){try{one.remove()
gone+=1}catch{
}}
return gone}
function paintCap(tile,room){let value=null
try{value=tile?.querySelector?.(TILE_BIG_VALUE)??null}catch(err){onError(err)
return null}
if(value===null)return null
let node=null
try{node=value.querySelector?.(CAP_SELECTOR)??null}catch{node=null}
if(room===null){if(node!==null){try{node.remove()}catch{
}}
return null}
const mine=t('transfers.hub.cap',{size:num(room.size)})
if(node!==null){if(String(node.textContent??'')===mine)return node
try{node.textContent=mine}catch(err){onError(err)
return null}
paints+=1
return node}
const fresh=el(doc,'span',{class:'fx-hub-cap',text:mine,dataset:{[CAP_MARK]:'1'}})
try{value.appendChild(fresh)}catch(err){onError(err)
return null}
paints+=1
return fresh}
function nativeCell(content,where){let all=[]
try{all=Array.from(content?.querySelectorAll?.(where)??[])}catch{return null}
for(const one of all){const marks=one?.dataset??{}
if(marks[UNSOLD_MARK]===undefined&&marks[LIVE_MARK]===undefined)return one}
return null}
function paintUnsold(tile,count){let content=null
try{content=tile?.querySelector?.(TILE_CONTENT_SELECTOR)??null}catch(err){onError(err)
return null}
if(content===null)return null
let node=null
try{node=content.querySelector?.(UNSOLD_SELECTOR)??null}catch{node=null}
if(count===null||!Number.isSafeInteger(count)||count<=0){if(node!==null){try{node.remove()}catch{
}}
return null}
const said=num(count)
if(node!==null){const shown=node.querySelector?.('.value')??null
if(shown!==null&&String(shown.textContent??'')===said)return node
try{if(shown!==null)shown.textContent=said}catch(err){onError(err)
return null}
paints+=1
return node}
const anchor=nativeCell(content,'.finished-transfers')
if(anchor===null)return null
const fresh=el(doc,'div',{class:'active-transfers',dataset:{[UNSOLD_MARK]:'1'}},
[el(doc,'span',{class:'label',text:t('transfers.hub.unsoldLabel')}),
el(doc,'span',{class:'value fx-hub-unsold',text:said})])
try{anchor.parentNode.insertBefore(fresh,anchor)}catch(err){onError(err)
return null}
paints+=1
return fresh}
function paintTargetsFoot(tile,tally){let content=null
try{content=tile?.querySelector?.(TILE_CONTENT_SELECTOR)??null}catch(err){onError(err)
return null}
if(content===null)return null
if(tally===null){dropTargetsFoot(content)
return null}
const anchor=nativeCell(content,'.active-transfers')
if(anchor===null)return null
for(const one of [anchor,nativeCell(content,'.finished-transfers')]){
if(one===null||!one.dataset)continue
try{if(one.dataset[STALE_MARK]!=='1'){one.dataset[STALE_MARK]='1'
paints+=1}}catch(err){onError(err)}}
let made=0
for(const cell of TARGET_CELLS){made+=paintTargetCell(content,anchor,cell,tally[cell.id])===null?0:1}
return made}
function paintTargetCell(content,anchor,cell,count){const said=num(Number.isSafeInteger(count)&&count>0?count:0)
let node=null
try{node=content.querySelector?.(`[data-fut-hub-live='${cell.id}']`)??null}catch{node=null}
if(node!==null){const shown=node.querySelector?.('.value')??null
if(shown!==null&&String(shown.textContent??'')===said)return node
try{if(shown!==null)shown.textContent=said}catch(err){onError(err)
return null}
paints+=1
return node}
const fresh=el(doc,'div',{class:'active-transfers',dataset:{[LIVE_MARK]:cell.id}},
[el(doc,'span',{class:'label',text:t(cell.key)}),
el(doc,'span',{class:`value ${cell.tone}`.trim(),text:said})])
try{anchor.parentNode.insertBefore(fresh,anchor)}catch(err){onError(err)
return null}
paints+=1
return fresh}
function dropTargetsFoot(content){let gone=0
for(const one of Array.from(content?.querySelectorAll?.(LIVE_SELECTOR)??[])){try{one.remove()
gone+=1}catch{
}}
for(const one of Array.from(content?.querySelectorAll?.(STALE_SELECTOR)??[])){try{delete one.dataset[STALE_MARK]
gone+=1}catch{
}}
return gone}
function paintTones(tile,spec){let content=null
try{content=tile?.querySelector?.(TILE_CONTENT_SELECTOR)??null}catch(err){onError(err)
return 0}
if(content===null)return 0
let done=0
for(const one of spec){const cell=nativeCell(content,one.where)
if(cell===null||!cell.dataset)continue
let text=''
try{text=String(cell.querySelector?.('.value')?.textContent??'')}catch{text=''}
const digits=text.replace(/[^0-9]/g,'')
const live=digits!==''&&Number(digits)>0
try{if(live){if(cell.dataset[TONE_MARK]!==one.tone){cell.dataset[TONE_MARK]=one.tone
paints+=1}
done+=1}
else if(cell.dataset[TONE_MARK]!==undefined){delete cell.dataset[TONE_MARK]
paints+=1}}catch(err){onError(err)}}
return done}
function dropNative(){let gone=0
for(const one of Array.from(doc?.querySelectorAll?.(`${CAP_SELECTOR},${UNSOLD_SELECTOR},${LIVE_SELECTOR}`)??[])){try{one.remove()
gone+=1}catch{
}}
for(const one of Array.from(doc?.querySelectorAll?.(TONE_SELECTOR)??[])){try{delete one.dataset[TONE_MARK]
gone+=1}catch{
}}
for(const one of Array.from(doc?.querySelectorAll?.(STALE_SELECTOR)??[])){try{delete one.dataset[STALE_MARK]
gone+=1}catch{
}}
return gone}
function mountListTile(root,ready){let tile=null
try{tile=root?.querySelector?.(TRANSFER_LIST_TILE)??null}catch(err){onError(err)
return null}
if(tile===null)return null
paintCap(tile,ready===null?null:ready.room)
paintTones(tile,LIST_TONES)
return paintUnsold(tile,ready===null?null:countOf(ready.boxes?.UNSOLD?.count))}
const LIST_TONES=Object.freeze([Object.freeze({where:'.finished-transfers',tone:TONE_OK})])
function mountTargetsTile(root){let tile=null
try{tile=root?.querySelector?.(TRANSFER_TARGETS_TILE)??null}catch(err){onError(err)
return null}
if(tile===null)return null
paintCap(tile,pileRoom(win,'INBOX'))
const watch=watchPileNow(win)
paintTargetsFoot(tile,watch.known===true?targetsTally(watch.items):null)
const seconds=watch.known===true?nearestEndSeconds(watch.items):null
const words=seconds===null?null:endWords(seconds,t)
if(words===null){dropDesks(DESK_TARGETS)
return null}
paintDesk(tile,DESK_TARGETS,[],null,{value:words,key:t('transfers.hub.endsKey')})
return seconds}
function markTiles(grid){if(!grid?.dataset)return false
if(grid.dataset[TILES_MARK]!=='1')grid.dataset[TILES_MARK]='1'
return true}
function clearAll(){let gone=0
gone+=dropNative()
gone+=dropDesks()
stopTick()
for(const grid of Array.from(doc?.querySelectorAll?.(TILES_SELECTOR)??[])){try{
delete grid.dataset[TILES_MARK]}catch{
}}
return gone}
function refresh(){if(!doc)return false
passes+=1
if(!allowed()){clearAll()
return false}
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,HUB_STYLESHEET,HUB_LINK_ID)
const root=rootOf()
if(root!==null){
const ready=readPile()
mountListTile(root,ready)
const осталось=mountTargetsTile(root)
if(осталось===null)stopTick()
else startTick(tickStepMs(осталось))
const grid=gridOf(root)
if(grid!==null)markTiles(grid)}
else stopTick()
return true}
function relabel(){if(!doc)return false
for(const node of Array.from(doc.querySelectorAll?.(DESK_SELECTOR)??[]))painted.delete(node)
dropNative()
return refresh()}
return{refresh,relabel,
state(){const root=rootOf()
const grid=root===null?null:gridOf(root)
const pile=tradePileNow(win)
const answer={hub:root!==null,
build:HUB_BUILD,
laidOut:doc?.querySelectorAll?.(TILES_SELECTOR)?.length??0,
pile:{known:pile.known,items:pile.items.length,
room:pile.room===null?null:`${pile.room.used}/${pile.room.size}`},
desks:{targets:deskCount(DESK_TARGETS)},
watch:(()=>{const said=watchPileNow(win)
if(said.known!==true)return{known:false,items:0,soonest:null}
return{known:true,items:said.items.length,soonest:nearestEndSeconds(said.items)}})(),
caps:(()=>{const out=[]
for(const one of Array.from(doc?.querySelectorAll?.(CAP_SELECTOR)??[])){
out.push(String(one.textContent??'').trim())}
return out.join(' · ')})(),
tones:(()=>{const out=[]
for(const one of Array.from(doc?.querySelectorAll?.(TONE_SELECTOR)??[])){
const word=String(one.querySelector?.('.label')?.textContent??'').trim()
out.push(`${word===''?'?':word} ${one.dataset?.[TONE_MARK]??'?'}`)}
return out.join(' · ')})(),
unsold:(()=>{let node=null
try{node=doc?.querySelector?.(UNSOLD_SELECTOR)??null}catch{node=null}
return node===null?null:String(node.textContent??'').replace(/\s+/g,' ').trim()})(),
won:(()=>{let node=null
try{node=doc?.querySelector?.(WON_SELECTOR)??null}catch{node=null}
if(node===null)return null
let at=0
try{at=Array.from(node.parentNode?.children??[]).indexOf(node)+1}catch{at=0}
return `${String(node.textContent??'').replace(/\s+/g,' ').trim()} (место ${at})`})(),
foot:(()=>{const out=[]
for(const one of Array.from(doc?.querySelectorAll?.(LIVE_SELECTOR)??[])){
out.push(String(one.textContent??'').replace(/\s+/g,' ').trim())}
let hidden=0
try{hidden=doc?.querySelectorAll?.(STALE_SELECTOR)?.length??0}catch{hidden=0}
return out.length===0?null:`${out.join(' · ')} (её спрятано ${hidden})`})(),
clock:tick!==null,
step:tickStep,
work:{passes,paints}}
return{...answer,line:stateLine(answer)}},
dispose(){try{clearAll()}catch(err){onError(err)}}}}
