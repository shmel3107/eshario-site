import{ensureStylesheet,ensureTheme} from '../ui/dom.js'
import{pressNode} from './hotkey-bind.js'
import{LIST_ROWS,CURSOR_ATTR,CURSOR_KEY,ENTER_KEY,MARK_KEY,STALE_ATTR,STALE_KEY,MODE_PRESS,MODE_SAY,axisOf,rowKindOf,rowsOf,rectsOf,listNow,indexIn,markedRow,enterMarkOf,marksRow,drawsMark,enterTargets,primaryButton,followButton,stepIndex,startIndex,groupsOf,zoneOf} from './list-rows.js'
const CURSOR_STYLESHEET=new URL('../ui/list-cursor.css',import.meta.url).href
const CURSOR_LINK_ID='fut-companion-list-cursor'
export function createListCursor({doc,win=null,onError=()=>{}}){
const boxOf=(node)=>{try{return node?.getBoundingClientRect?.()??null}catch(err){onError(err)
return null}}
const clear=()=>{let all
try{all=doc?.querySelectorAll?.(`[${CURSOR_ATTR}]`)}catch{all=null}
for(const one of all??[]){if(!one?.dataset)continue
delete one.dataset[CURSOR_KEY]
delete one.dataset[ENTER_KEY]
delete one.dataset[MARK_KEY]}
let cold
try{cold=doc?.querySelectorAll?.(`[${STALE_ATTR}]`)}catch{cold=null}
for(const one of cold??[]){if(one?.dataset)delete one.dataset[STALE_KEY]}}
const cool=(row,kind)=>{if(typeof kind?.current!=='string'||kind.mode===MODE_PRESS)return
for(const one of rowsOf(doc,kind)){if(one===row||!one?.dataset)continue
let same=false
try{same=one.matches?.(kind.current)===true}catch{same=false}
if(same)one.dataset[STALE_KEY]='1'}}
const mark=(row,kind,axis)=>{ensureTheme(doc)
ensureStylesheet(doc,CURSOR_STYLESHEET,CURSOR_LINK_ID)
clear()
if(!row?.dataset)return false
row.dataset[CURSOR_KEY]=axis
row.dataset[ENTER_KEY]=enterMarkOf(kind,row)
if(drawsMark(kind,row))row.dataset[MARK_KEY]='1'
cool(row,kind)
reveal(row)
return true}
const scrollerOf=(node)=>{for(let up=node?.parentElement;up;up=up.parentElement){const box=up.getBoundingClientRect?.()
if(!box)continue
if(Number(up.scrollHeight)>Number(up.clientHeight)+1)return up}
return null}
const reveal=(row)=>{
try{row.scrollIntoView?.({block:'nearest',inline:'nearest'})}catch(err){onError(err)}
if(typeof doc?.elementFromPoint!=='function')return
for(let guard=0;guard<3;guard+=1){const box=row.getBoundingClientRect?.()
if(!box)return
const probeX=Number(box.left)+Math.min(8,Number(box.width)/2)
const probeY=Number(box.top)+2
let over=null
try{over=doc.elementFromPoint(probeX,probeY)}catch{return}
if(!over||over===row||row.contains?.(over)||over.contains?.(row))return
const lid=over.getBoundingClientRect?.()
if(!lid||!(Number(lid.bottom)>Number(box.top)))return
const lift=Number(lid.bottom)-Number(box.top)+4
const scroller=scrollerOf(row)
if(scroller)scroller.scrollTop=Number(scroller.scrollTop)-lift
else if(typeof win?.scrollBy==='function')win.scrollBy(0,-lift)
else return}}
const pressRow=(row,kind)=>{let target=row
if(typeof kind.press==='string'){try{target=row.querySelector?.(kind.press)??row}catch{target=row}}
return pressNode(target,win,onError)}
const step=(delta,asked)=>{const list=listNow(doc)
if(!list)return{ok:false,reason:'no-list'}
const{kind,rows}=list
const rects=rectsOf(rows)
const index=indexIn(list)
const next=index<0?startIndex(rects,rows,kind,delta):stepIndex(rects,index,delta,asked,groupsOf(rows,kind))
if(next<0)return{ok:false,reason:'edge'}
const axis=axisOf(rects)
const row=rows[next]
const zone=zoneOf(kind,row)!==null
const taps=kind.mode===MODE_PRESS&&!zone
if(taps){if(!marksRow(kind)){reveal(row)
clear()}
if(!pressRow(row,kind))return{ok:false,reason:'no-list'}}
if(marksRow(kind)){if(!mark(row,kind,axis))return{ok:false,reason:'no-list'}}
else if(row?.dataset){row.dataset[CURSOR_KEY]=axis
row.dataset[ENTER_KEY]=enterMarkOf(kind,row)}
return{ok:true,reason:null,index:next+1,total:rows.length,axis,pressed:taps}}
const enter=()=>{
const targets=enterTargets(doc)
if(targets.length!==1)return{ok:false,reason:'no-cursor'}
const{kind,row}=targets[0]
if(zoneOf(kind,row)){if(!pressRow(row,kind))return{ok:false,reason:'no-target',kind:kind.key}
return{ok:true,reason:null,kind:kind.key,primary:false,zone:true}}
if(kind.mode===MODE_SAY)return{ok:false,reason:'by-hand',kind:kind.key}
if(typeof kind.primary==='string'){const button=primaryButton(doc,kind,row)
if(!button||!pressNode(button,win,onError))return{ok:false,reason:'no-target',kind:kind.key}
return{ok:true,reason:null,kind:kind.key,primary:true}}
if(kind.mode===MODE_PRESS)return{ok:false,reason:'no-target',kind:kind.key}
if(!pressRow(row,kind))return{ok:false,reason:'no-cursor'}
const next=followButton(doc,kind)
if(next)return{ok:true,reason:null,kind:kind.key,primary:false,followed:pressNode(next,win,onError)}
return{ok:true,reason:null,kind:kind.key,primary:false}}
const state=()=>{const list=listNow(doc)
return{list:list?.kind?.key??null,mode:list?.kind?.mode??null,rows:list?.rows.length??0,
axis:list?axisOf(list.rows.map(boxOf)):null,at:list?indexIn(list)+1:0,marked:Boolean(markedRow(doc))}}
return{step,enter,state,clear}}
export{LIST_ROWS,rowKindOf,rowsOf}
