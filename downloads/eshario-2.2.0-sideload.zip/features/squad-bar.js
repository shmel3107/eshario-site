import{el,logoMark,ensureSquadStyles,ensureSbcStripStyles} from '../ui/dom.js'
import{ensureControls} from '../ui/controls.js'
import{chipNode,chipMarkNode} from './sbc-strip.js'
import{squadRatingExact} from '../automation/squad-rating.js'
import{squadBannerOf,bannerLeftOf,actionsGroupOf,squadFieldSlots,slotItemOf,
slotItemIdOf,slotPositionNameOf,squadFieldRatings,squadChemistryNow,
squadChemistryMax,squadFormationName,itemTradeable} from '../adapter/squad-screen.js'
export const SQUAD_BAR_MARK='data-fut-squad-bar'
export const SQUAD_BAR_KEY='futSquadBar'
export const SQUAD_LOCK_MARK='data-fut-squad-lock'
export const SQUAD_LOCK_KEY='futSquadLock'
const BAR_CLASS='fx-squad-bar'
const LOCK_CLASS='fx-squad-lock'
const HIDE_FORMATION='formation'
const HIDE_RATING='rating'
const HIDE_CHEMISTRY='chemistry'
export const SQUAD_FEATURE='squadScreen'
export const SQUAD_BUILD='SQHEAD1-2'
export function squadBarModel(input={}){const t=typeof input.t==='function'?input.t:(key)=>key
const coins=typeof input.coins==='function'?input.coins:(value)=>String(value)
const cards=Array.isArray(input.cards)?input.cards:[]
const exact=Number.isFinite(input.exact)?input.exact:null
const live=Number.isFinite(input.chemistry)?input.chemistry:null
const max=Number.isSafeInteger(input.maxChemistry)&&input.maxChemistry>0?input.maxChemistry:null
const formationName=typeof input.formation==='string'&&input.formation!==''?input.formation:null
const hides=[]
const rating=exact===null?null:{label:t('squadBar.rating'),value:exact.toFixed(2),
title:t('squadBar.ratingTitle',{whole:Math.floor(exact)})}
if(rating!==null)hides.push(HIDE_RATING)
const chemistry=live===null||max===null?null:{label:t('squadBar.chemistry'),
value:t('squadBar.pair',{have:live,need:max}),
title:t('squadBar.chemistryTitle',{need:max})}
if(chemistry!==null)hides.push(HIDE_CHEMISTRY)
const cost=costChip({t,coins,cards})
const formation=formationName===null?null:{label:t('squadBar.formation'),
value:formationName,title:t('squadBar.formationTitle')}
if(formation!==null)hides.push(HIDE_FORMATION)
const ok=rating!==null||chemistry!==null||cost!==null||formation!==null
return{ok,reason:ok?null:'no-numbers',hides:hides.join(' '),rating,chemistry,cost,formation}}
function costChip(input){const{t,coins,cards}=input
let total=0
let tradeable=0
let priced=0
const unpriced=[]
for(const card of cards){const price=Number.isFinite(card?.price)&&card.price>0?card.price:null
if(price===null){unpriced.push(typeof card?.position==='string'&&card.position!==''?card.position:'–')
continue}
priced+=1
total+=price
if(card?.tradeable===true)tradeable+=price}
const missing=unpriced.length>0
?t('squadBar.costUnpriced',{count:unpriced.length,list:unpriced.join(', ')})
:null
if(priced===0)return{label:t('squadBar.cost'),value:t('squadBar.none'),muted:true,
title:missing===null?t('squadBar.costTitle'):t('squadBar.costTitle')+' '+missing}
return{label:t('squadBar.cost'),value:coins(total),paren:t('squadBar.costParen',{value:coins(tradeable)}),
muted:false,title:missing===null?t('squadBar.costTitle'):t('squadBar.costTitle')+' '+missing}}
export function squadLockModel(input={}){const t=typeof input.t==='function'?input.t:(key)=>key
const ids=Array.isArray(input.ids)?input.ids.filter((one)=>Number.isSafeInteger(one)&&one>0):[]
const isLocked=typeof input.isLocked==='function'?input.isLocked:()=>false
const blank={ok:false,reason:null,total:0,locked:0,all:false,label:'',count:'',title:'',ids:[]}
if(input.canLock!==true)return{...blank,reason:'no-provider'}
if(ids.length===0)return{...blank,reason:'no-cards'}
let locked=0
for(const id of ids){let on=false
try{on=isLocked(id)===true}catch{on=false}
if(on)locked+=1}
const all=locked===ids.length
return{ok:true,reason:null,total:ids.length,locked,all,
label:t(all?'squadLock.unlock':'squadLock.lock'),
count:t('squadLock.count',{count:locked}),
title:t('squadLock.title'),ids}}
export function createSquadBar(deps={}){const doc=deps.doc??null
const win=deps.win??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const coins=typeof deps.coins==='function'?deps.coins:(value)=>String(value)
const isActiveOf=typeof deps.isActive==='function'?deps.isActive:()=>true
const isActive=()=>isActiveOf(SQUAD_FEATURE)===true
const priceOf=typeof deps.priceOf==='function'?deps.priceOf:()=>null
const isLocked=typeof deps.isLocked==='function'?deps.isLocked:()=>false
const setLock=typeof deps.setLock==='function'?deps.setLock:null
const canLockOf=typeof deps.canLock==='function'?deps.canLock:()=>false
const floatRating=typeof deps.floatRating==='boolean'?deps.floatRating:null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let bar=null
let row=null
let lastScreen=null
let lastActions=null
let squad=null
let barPrint=null
let rowPrint=null
let reason=null
let rowReason=null
let rowRefusal=null
const stats={applies:0,paints:0,skips:0,holds:0,rows:0,rowSkips:0,locks:0,unlocks:0,stale:0}
function стили(){ensureControls(doc)
ensureSbcStripStyles(doc)
ensureSquadStyles(doc)}
function unmountBar(){if(bar===null)return
try{delete bar.node.dataset[SQUAD_BAR_KEY]}catch{/* узел уже чужой */}
try{bar.strip.remove()}catch{/* узел уже снят */}
bar=null
barPrint=null}
function cardsOf(entity){const out=[]
for(const slot of squadFieldSlots(entity)){const item=slotItemOf(slot)
if(item===null)continue
let price=null
try{price=priceOf(item)}catch{price=null}
out.push({price:Number.isFinite(price)&&price>0?price:null,
tradeable:itemTradeable(item),
position:slotPositionNameOf(slot)})}
return out}
function readBarModel(entity){const ratings=squadFieldRatings(entity)
const exact=squadRatingExact({field:ratings,float:floatRating})
return squadBarModel({t,coins,cards:cardsOf(entity),
exact:Number.isFinite(exact)?exact:null,
chemistry:squadChemistryNow(entity),
maxChemistry:squadChemistryMax(win),
formation:squadFormationName(entity)})}
function barFingerprint(model){return[model.hides,model.rating?.value,
model.chemistry?.value,model.cost?.value,model.cost?.paren,model.cost?.muted,
model.formation?.value].join('|')}
function barNode(model){const chips=[['rating',model.rating],['chemistry',model.chemistry],
['cost',model.cost],['formation',model.formation]]
.filter((pair)=>pair[1]!==null&&pair[1]!==undefined)
.map((pair)=>chipNode(doc,pair[0],pair[1]))
const kids=[chipMarkNode(doc,'fx-squad-bar-mark')]
for(const chip of chips)kids.push(chip)
return el(doc,'div',{class:BAR_CLASS},kids)}
function paintBar(model,summary,left){const print=barFingerprint(model)
if(bar!==null&&bar.node===summary&&print===barPrint){stats.skips+=1
return}
const node=barNode(model)
if(bar!==null&&bar.node===summary){bar.strip.replaceWith(node)
bar.strip=node}
else{unmountBar()
left.insertBefore(node,left.firstChild)
bar={node:summary,left,strip:node}}
summary.dataset[SQUAD_BAR_KEY]=model.hides
barPrint=print
stats.paints+=1}
function unmountRow(){if(row===null)return
try{delete row.panel.dataset[SQUAD_LOCK_KEY]}catch{/* узел уже чужой */}
try{row.node.remove()}catch{/* узел уже снят */}
row=null
rowPrint=null}
function rowNode(model){const button=el(doc,'button',{class:LOCK_CLASS,attrs:{type:'button',title:model.title}},
[logoMark(doc,'fx-squad-lock-mark'),
el(doc,'span',{class:'btn-text',text:model.label}),
el(doc,'span',{class:'btn-subtext',text:model.count})])
button.addEventListener('click',()=>{try{toggleLocks()}catch(err){onError(err)}})
return button}
function fieldIdsNow(){const ids=[]
for(const slot of squadFieldSlots(squad)){const id=slotItemIdOf(slot)
if(id!==null&&!ids.includes(id))ids.push(id)}
return ids}
function sameSet(a,b){if(a.length!==b.length)return false
for(const one of a)if(!b.includes(one))return false
return true}
function toggleLocks(){if(setLock===null)return
const shown=row?.model??null
if(shown===null||shown.ok!==true)return
let canLock=false
try{canLock=canLockOf()===true&&setLock!==null}catch{canLock=false}
const now=squadLockModel({t,ids:fieldIdsNow(),isLocked,canLock})
if(!now.ok||!sameSet(now.ids,shown.ids)){stats.stale+=1
rowRefusal='stale-field'
refresh()
return}
rowRefusal=null
const on=now.all!==true
let done=0
for(const id of now.ids){let ok=false
try{ok=setLock(id,on)===true}catch{ok=false}
if(ok)done+=1}
if(on)stats.locks+=done
else stats.unlocks+=done
refresh()}
function paintRow(model,panel,group){const print=[model.label,model.count,model.total,model.locked].join('|')
if(row!==null&&row.panel===panel)row.model=model
if(row!==null&&row.panel===panel&&print===rowPrint){stats.rowSkips+=1
return}
const node=rowNode(model)
if(row!==null&&row.panel===panel){row.node.replaceWith(node)
row.node=node
row.model=model}
else{unmountRow()
group.appendChild(node)
row={panel,group,node,model}}
panel.dataset[SQUAD_LOCK_KEY]='1'
rowPrint=print
stats.rows+=1}
function apply(capture){if(!doc||!capture)return
stats.applies+=1
try{
if(!isActive()){unmount()
reason='off'
return}
lastScreen=capture
if(capture.squad!==null&&capture.squad!==undefined)squad=capture.squad
const summary=squadBannerOf(capture.root)
if(summary===null){
if(bar!==null&&bar.node?.isConnected===true){stats.holds+=1
reason='bar-held'}
else{unmountBar()
reason='no-bar'}
return}
const left=bannerLeftOf(summary)
if(left===null){unmountBar()
reason='no-left'
return}
const model=readBarModel(squad)
reason=model.reason
if(!model.ok){unmountBar()
return}
стили()
paintBar(model,summary,left)}
catch(err){onError(err)}
try{applyRow()}catch(err){onError(err)}}
function applyActions(capture){if(!doc||!capture)return
try{
if(!isActive()){unmountRow()
rowReason='off'
return}
lastActions=capture
if(capture.squad!==null&&capture.squad!==undefined)squad=capture.squad
applyRow()}
catch(err){onError(err)}}
function applyRow(){if(lastActions===null)return
if(!isActive()){unmountRow()
rowReason='off'
return}
const group=actionsGroupOf(lastActions.root)
if(group===null){
if(row!==null&&row.node?.isConnected===true){rowReason='row-held'
return}
unmountRow()
rowReason='no-group'
return}
const ids=[]
for(const slot of squadFieldSlots(squad)){const id=slotItemIdOf(slot)
if(id!==null&&!ids.includes(id))ids.push(id)}
let canLock=false
try{canLock=canLockOf()===true&&setLock!==null}catch{canLock=false}
const model=squadLockModel({t,ids,isLocked,canLock})
rowReason=model.reason
if(!model.ok){unmountRow()
return}
стили()
paintRow(model,lastActions.root,group)}
function refresh(){try{if(lastScreen!==null)apply(lastScreen)
else if(lastActions!==null)applyActions(lastActions)}catch(err){onError(err)}}
function unmount(){unmountBar()
unmountRow()}
function dispose(){unmount()
lastScreen=null
lastActions=null
squad=null}
function state(){return{build:SQUAD_BUILD,ok:bar!==null,reason,mark:SQUAD_BAR_MARK,print:barPrint,
applies:stats.applies,paints:stats.paints,skips:stats.skips,holds:stats.holds,
lock:{ok:row!==null,reason:rowReason,mark:SQUAD_LOCK_MARK,print:rowPrint,
rows:stats.rows,skips:stats.rowSkips,locks:stats.locks,unlocks:stats.unlocks,
stale:stats.stale,refusal:rowRefusal}}}
return{apply,applyActions,refresh,dispose,state}}
