let liveSource=null
export function publishLiveCriteria(door){liveSource=typeof door==='function'?{read:door}
:(door&&typeof door.read==='function'?door:null)
const mine=liveSource
return()=>{if(liveSource===mine)liveSource=null}}
export function liveCriteriaNow(){if(liveSource===null)return null
let said=null
try{said=liveSource.read()}catch{return null}
return said&&typeof said==='object'&&!Array.isArray(said)?said:null}
export function liveApplyNow(criteria){const apply=liveSource?.apply
if(typeof apply!=='function')return null
let said=null
try{said=apply(criteria)}catch{return null}
if(!said||typeof said!=='object')return null
if(said.ok!==true&&said.reason==='no-screen')return null
return said}
export const REASON_KEYS=Object.freeze({'name-taken':'filters.nameTaken','name-required':'filters.nameRequired','too-many':'filters.tooMany','too-large':'filters.tooLarge','not-found':'filters.notFound','no-screen':'filters.noScreen','no-navigation':'filters.noScreen','not-json':'filters.notJson','no-sets':'filters.notJson',empty:'filters.notJson'
})
export function noticeForReason(reason,params={}){const key=Object.hasOwn(REASON_KEYS,reason)?REASON_KEYS[reason]:'filters.failed'
return{key,params:key==='filters.failed'?{reason,...params}:params}}
export function applyFilter(id,deps){const{store,criteria,screen}=deps
const set=store.get(id)
if(!set) return{ok:false,notice:noticeForReason('not-found')}
const live=liveApplyNow(set.criteria)
if(live!==null){if(live.ok!==true)return{ok:false,notice:noticeForReason(live.reason)}
const lost=Array.isArray(live.rejected)?live.rejected:[]
if(lost.length>0){return{ok:true,partial:true,live:true,notice:{key:'filters.partial',params:{fields:lost.map((one)=>one.field).join(', ')}}}}
return{ok:true,live:true,notice:{key:'filters.applied',params:{name:set.name}}}}
let built
try{built=criteria.create(set.criteria)}catch(err){return{ok:false,notice:noticeForReason('failed',{reason:String(err?.message??err)})}}
const opened=screen.open(built.dto)
if(!opened.ok)return{ok:false,notice:noticeForReason(opened.reason)}
if(built.rejected.length>0){return{ok:true,partial:true,notice:{key:'filters.partial',params:{fields:built.rejected.map((r)=>r.field).join(', ')}}}}
return{ok:true,notice:{key:'filters.applied',params:{name:set.name}}}}
export function saveCurrentFilter(name,deps){const{store,criteria}=deps
let current=liveCriteriaNow()
const live=current!==null
if(current===null){if(typeof criteria?.read!=='function')return{ok:false,notice:noticeForReason('no-screen')}
try{current=criteria.read()}catch(err){return{ok:false,notice:noticeForReason('failed',{reason:String(err?.message??err)})}}}
if(!current) return{ok:false,notice:noticeForReason('no-screen')}
const res=store.save({name,criteria:current})
if(!res.ok)return{ok:false,live,notice:noticeForReason(res.reason,{limit:res.limit})}
return{ok:true,live,notice:{key:'filters.saved',params:{name:res.set.name}}}}
export function renameFilter(id,name,deps){const res=deps.store.rename(id,name)
if(!res.ok)return{ok:false,notice:noticeForReason(res.reason)}
return{ok:true,notice:{key:'filters.renamed',params:{name:String(name).trim()}}}}
export function exportFilters(deps){const count=deps.store.count()
if(count===0) return{ok:false,notice:{key:'filters.empty',params:{}}}
return{ok:true,text:deps.store.exportSets(),notice:{key:'filters.exported',params:{count}}}}
export function importFilters(text,mode,deps){const res=deps.store.importSets(text,{mode})
if(!res.ok)return{ok:false,notice:noticeForReason(res.reason,{limit:res.limit})}
if(res.skipped>0||res.renamed>0){return{ok:true,partial:true,notice:{key:'filters.importedPartly',params:{count:res.imported,skipped:res.skipped,renamed:res.renamed}}}}
return{ok:true,notice:{key:'filters.imported',params:{count:res.imported}}}}
export function removeFilter(id,deps){const set=deps.store.get(id)
const res=deps.store.remove(id)
if(!res.ok)return{ok:false,notice:noticeForReason(res.reason)}
return{ok:true,notice:{key:'filters.removed',params:{name:set?.name??''}}}}
