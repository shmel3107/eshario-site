export const PROMO_CLOSE_FEATURE='promoClose'
export const PROMO_PRESS_FRAMES=2
export const PROMO_STALE_MS=1500
export const PROMO_ROUNDS=6
export function promoLine(closed,t){const say=typeof t==='function'?t:(key)=>key
const rows=Array.isArray(closed)?closed:[]
if(rows.length===0)return say('promoClose.untitled')
return rows.map((one)=>{const title=typeof one?.title==='string'?one.title.trim():''
if(title!=='')return title
const counter=typeof one?.counter==='string'?one.counter.trim():''
return counter===''?say('promoClose.untitled'):counter}).join(' · ')}
export function createPromoClose(deps={}){const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const t=typeof deps.t==='function'?deps.t:(key)=>key
const frame=typeof deps.frame==='function'?deps.frame:null
const now=typeof deps.now==='function'?deps.now:null
const say=typeof deps.say==='function'?deps.say:()=>{}
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const counts={seen:0,locked:0,notPromo:0,noFrame:0,byHand:0,stale:0,notArmed:0,pressed:0,closed:0,rounds:0,failed:0}
let last=null
const activeNow=()=>{try{return isActive(PROMO_CLOSE_FEATURE)===true}catch(err){onError(err)
return null}}
const safeNow=()=>{try{const value=now()
return Number.isFinite(value)?value:0}catch(err){onError(err)
return 0}}
function appeared(shown){counts.seen+=1
if(activeNow()!==true){counts.locked+=1
return{ok:false,reason:'locked'}}
if(shown?.promo!==true){counts.notPromo+=1
return{ok:false,reason:'not-promo'}}
if(frame===null){counts.noFrame+=1
return{ok:false,reason:'no-frame'}}
let round=0
let waited=0
let roundAt=now===null?null:safeNow()
let armMs=armOf(shown.armMs)
let waitedArm=false
const closedRows=[]
const finish=(reason)=>{last={ok:closedRows.length>0,reason,
closed:closedRows.length,rows:closedRows.map((one)=>({...one}))}
if(closedRows.length>0)say('promoClose.closed',{what:promoLine(closedRows,t)})}
const step=()=>{try{waited+=1
if(shown.closed()===true){if(closedRows.length===0)counts.byHand+=1
finish(closedRows.length===0?'by-hand':'done')
return}
if(roundAt!==null&&safeNow()-roundAt>armMs+PROMO_STALE_MS){counts.stale+=1
finish('stale')
return}
if(waited<PROMO_PRESS_FRAMES){frame(step)
return}
if(shown.ready()!==true){if(!waitedArm){waitedArm=true
counts.notArmed+=1}
frame(step)
return}
if(round>=PROMO_ROUNDS){counts.rounds+=1
finish('rounds')
return}
const current=shown.read()
const result=shown.press()
if(result?.ok!==true){counts.failed+=1
finish(result?.reason??'failed')
return}
round+=1
counts.pressed+=1
counts.closed+=1
closedRows.push({title:typeof current?.title==='string'?current.title:'',
counter:typeof current?.counter==='string'?current.counter:''})
waited=0
waitedArm=false
roundAt=now===null?null:safeNow()
armMs=armOf(shown.read().armMs)
frame(step)}catch(err){onError(err)
counts.failed+=1
finish('failed')}}
frame(step)
return{ok:true,reason:null}}
return{appeared,
state:()=>({active:activeNow(),
rule:{frames:PROMO_PRESS_FRAMES,staleMs:PROMO_STALE_MS,rounds:PROMO_ROUNDS,feature:PROMO_CLOSE_FEATURE},
counts:{...counts},
last:last===null?null:{...last,rows:last.rows.map((one)=>({...one}))}}),
dispose(){last=null}}}
function armOf(value){const n=Number(value)
return Number.isFinite(n)&&n>0?n:0}
