import{el,clear,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoLink} from '../ui/controls.js'
import{packLockKey,openOwnedPack} from './pack-locks.js'
import{printMark} from './store-catalog.js'
import{createPackBulk,bulkDoorReason,BULK_HOLD_LAST,BULK_HOLD_RETRY,BULK_REASON_SERVER} from './pack-bulk.js'
import{restMarketAfterThrottle,askDayBudget,COUNTER_UNAVAILABLE} from './day-budget.js'
import{createPackFlowLine,packFlowText} from './unassigned-strip.js'
import{createPackAdapter} from '../adapter/ea.js'
import{unassignedInCache,unassignedCacheFresh,notePackOpened,goToUnassigned,backFromUnassigned,readPackContents,pickShowItem,showPackAnimation,packNoticePlan,backPlan,JUMP_CALLS,HUB_CALLS} from '../adapter/store-packs.js'
import{installUnassignedScreenCapture} from '../adapter/unassigned-screen.js'
export const STORE_GRID_FEATURE='packGrid'
const STORE_GRID_STYLESHEET=new URL('../ui/store-grid.css',import.meta.url).href
const STORE_GRID_LINK_ID='fut-companion-store-grid'
const OURS_SELECTOR='[data-fut-store-grid]'
const HOST_FLAG='futStoreGridHost'
const FLAT_FLAG='futStoreFlat'
const DISCLAIMER_SELECTOR='.ut-store-hub-view--disclaimer'
const PACK_SELECTOR='[data-fut-store-pack]'
export const TRADE_FILTERS=Object.freeze(['all','tradeable','untradeable'])
const TRADE_LABELS=Object.freeze({all:'storeGrid.filter.all',tradeable:'storeGrid.filter.tradeable',untradeable:'storeGrid.filter.untradeable'})
export const BULK_WHY=Object.freeze({done:'storeGrid.bulk.why.done',unassigned:'storeGrid.bulk.why.unassigned',captcha:'storeGrid.bulk.why.captcha','rate-limit':'storeGrid.bulk.why.rate-limit',critical:'storeGrid.bulk.why.critical',[BULK_REASON_SERVER]:'storeGrid.bulk.why.server','ea-error':'storeGrid.bulk.why.ea-error',locked:'storeGrid.bulk.why.locked',gone:'storeGrid.bulk.why.gone',pick:'storeGrid.bulk.why.pick',door:'storeGrid.bulk.why.door',budget:'storeGrid.bulk.why.budget',counter:'storeGrid.bulk.why.counter',unknown:'storeGrid.bulk.why.unknown',timeout:'storeGrid.bulk.why.timeout',stopped:'storeGrid.bulk.why.stopped',idle:'storeGrid.bulk.why.idle',failed:'storeGrid.bulk.why.failed'})
export const BULK_HOLD_WHY=Object.freeze({[BULK_HOLD_LAST]:'storeGrid.bulk.hold.last',[BULK_HOLD_RETRY]:'storeGrid.bulk.hold.retry'})
export function packMatches(card,view={}){if(card?.hidden===true&&view.showHidden!==true)return false
const trade=TRADE_FILTERS.includes(view.trade)?view.trade:'all'
if(trade==='tradeable'&&card?.tradable!==true)return false
if(trade==='untradeable'&&card?.tradable!==false)return false
const query=typeof view.query==='string'?view.query.trim().toLowerCase():''
if(query==='')return true
const name=typeof card?.name==='string'?card.name.toLowerCase():''
return name.includes(query)}
export function groupPacks(tiles){const groups=[]
const byKey=new Map()
for(const tile of Array.isArray(tiles)?tiles:[]){const key=packLockKey(tile?.id,tile?.tradable)
if(key===null||!tile?.root)continue
const found=byKey.get(key)
if(found){found.count+=1
continue}
const group={key,id:tile.id,tradable:tile.tradable,count:1,root:tile.root,odds:Array.isArray(tile.odds)?tile.odds:[],
asset:tile.assetId??null,players:Number.isSafeInteger(tile.players)&&tile.players>0?tile.players:null}
byKey.set(key,group)
groups.push(group)}
return groups}
export function readPackFacts(root){const clean=(value)=>(typeof value==='string'?value.trim().replace(/\s+/g,' '):'')
const text=(selector)=>clean(root?.querySelector?.(selector)?.textContent)
const number=(cell)=>{const value=Number.parseInt(clean(root?.querySelector?.(cell)?.querySelector?.('.value')?.textContent),10)
return Number.isFinite(value)&&value>=0?value:null}
const source=root?.querySelector?.('.ut-pack-graphic-view--background')?.getAttribute?.('src')
return{name:text('.ut-store-pack-details-view--title'),items:number('.total'),art:typeof source==='string'?source:''}}
export function createStoreGrid(deps={}){const{doc,t}=deps
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const isLocked=typeof deps.isLocked==='function'?deps.isLocked:null
const setLock=typeof deps.setLock==='function'?deps.setLock:null
const isHidden=typeof deps.isHidden==='function'?deps.isHidden:null
const setHidden=typeof deps.setHidden==='function'?deps.setHidden:null
const goHub=typeof deps.goHub==='function'?deps.goHub:null
const budget=deps.budget??null
const noteCall=(count=1)=>askDayBudget(budget,count)
const PACK_STEP_CALLS=5
const warmStep=async()=>{if(budget===null||typeof budget.warm!=='function')return null
try{return await budget.warm(PACK_STEP_CALLS)??null}catch(err){onError(err)
return COUNTER_UNAVAILABLE}}
const hiddenPlan=(win)=>{let notice=null
try{notice=packNoticePlan(win)}catch(err){onError(err)
notice={refresh:true,announce:true}}
return{notice,count:1+(notice.refresh?1:0)+(notice.announce?1:0)}}
const readView=typeof deps.view==='function'?deps.view:null
const writeView=typeof deps.setView==='function'?deps.setView:null
const showFor=typeof deps.show==='function'?deps.show:null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let last=null
let scheduled=false
let lastResult={ok:false,reason:'not-run'}
let settles=0
let renders=0
let renderMs=0
let storeOn=false
let parkedResumes=0
let lastJump=null
const view={query:'',trade:'all',showHidden:false}
let pinned=true
const oddsOpen=new Set()
const winOf=()=>doc?.defaultView??null
const packs=createPackAdapter(winOf()??{})
let warming=null
let warmsRaised=0
let warmsUsed=0
let warmsRefused=0
function warmPacks(){if(warming!==null)return false
warmsRaised+=1
warming=noteCall(1).then((word)=>{if(word!==null){warmsRefused+=1
return false}
return packs.list().then(()=>true)}).then((ok)=>ok===true,(err)=>{onError(err)
return false})
return true}
function takeWarm(){const one=warming
warming=null
return one}
function dropWarm(){warming=null}
const lockView=(key)=>({read:()=>(lockedOf(key)?[key]:[])})
function eaCodeOf(err){const raw=err?.response?.error?.code??err?.response?.status??err?.status
return Number.isInteger(raw)?raw:null}
async function openViaAdapter(key){
const before=bulk.current()
const lastCopy=Number.isSafeInteger(before?.opened)&&Number.isSafeInteger(before?.total)&&before.opened+1>=before.total
const handCopy=!Number.isSafeInteger(before?.opened)||before.opened===0
const spend=async(count=1)=>{const word=await noteCall(count)
return handCopy?null:word}
if(showBusy)return{ok:false,reason:'unassigned'}
const warmWord=await warmStep()
if(warmWord!==null&&!handCopy)return{ok:false,reason:warmWord}
const warm=takeWarm()
let ready=false
if(warm!==null){try{ready=await warm===true}catch(err){onError(err)
ready=false}
if(ready)warmsUsed+=1}
if(!ready){const listWord=await spend(1)
if(listWord!==null)return{ok:false,reason:listWord}
try{await packs.list()}catch(err){onError(err)
return{ok:false,reason:'guard-unavailable',code:eaCodeOf(err)}}}
let result=null
const openWord=await spend(1)
if(openWord!==null)return{ok:false,reason:openWord}
try{result=await openOwnedPack({adapter:packs,provider:lockView(key),key,confirmed:true})}catch(err){onError(err)
return{ok:false,reason:'failed'}}
if(result?.ok!==true)return{ok:false,reason:typeof result?.reason==='string'?result.reason:'failed'}
const {notice,count:hidden}=hiddenPlan(winOf())
const hiddenWord=hidden>0?await noteCall(hidden):null
if(hiddenWord!==null)hiddenMissed+=hidden
try{bulkNote=notePackOpened(winOf(),result.items,{net:hiddenWord===null,notice})}catch(err){onError(err)
bulkNote=null}
const fired=Number.isSafeInteger(bulkNote?.sent)?bulkNote.sent:0
if(hidden>fired)hiddenExtra+=hidden-fired
if(!raiseShow(key,result.items,()=>{void settleAfterPack(lastCopy)}))await settleAfterPack(lastCopy)
return{ok:true,reason:null}}
async function settleAfterPack(lastCopy){if(bulkMoved&&!lastCopy)return
bulkMoved=true
let jump=null
if(await noteCall(JUMP_CALLS)!==null){bulkJump={ok:false,reason:'budget'}
return}
try{jump=goToUnassigned(winOf())}catch(err){onError(err)
jump=null}
if(jump?.reason!=='already')bulkJump=jump}
function raiseShow(key,items,onEnd){if(showFor===null)return false
let cards=null
try{cards=readPackContents({items})}catch(err){onError(err)
cards=null}
let want=null
try{want=showFor(cards)}catch(err){onError(err)
want=null}
showLast=want?{...want}:null
if(want?.show!==true)return false
const win=winOf()
let item=null
try{item=pickShowItem(win,items)}catch(err){onError(err)
item=null}
if(!item)return false
let started=null
try{started=showPackAnimation(win,{item,tier:assetOf(key),frame,
alive:()=>bulk.isRunning(key),
onEnd:(reason)=>{showBusy=false
showEnd=reason
try{onEnd()}catch(err){onError(err)}
try{flow.refresh()}catch(err){onError(err)}
settlePendingBack()}})}catch(err){onError(err)
started=null}
showResult=started?{...started}:null
if(started?.ok!==true)return false
showBusy=true
showsRaised+=1
return true}
function assetOf(key){try{return groupPacks(last?.tiles??[]).find((one)=>one.key===key)?.asset??null}catch(err){onError(err)
return null}}
function settlePendingBack(){if(!backPending)return
backPending=false
void backToStore()}
async function backToStore(){
if(backing)return
backing=true
try{const stop=await noteCall(backPlan(winOf()).calls)
if(stop!==null){bulkJump={ok:false,reason:bulkDoorReason(stop).name}
return}
try{bulkJump=backFromUnassigned(winOf())}catch(err){onError(err)
bulkJump=null}}
catch(err){onError(err)}
finally{backing=false}}
const bulk=createPackBulk({open:(key)=>openViaAdapter(key),
ratingMin:typeof deps.ratingMin==='function'?deps.ratingMin:undefined,
pileCount:()=>unassignedInCache(winOf()),
pileFresh:()=>unassignedCacheFresh(winOf()),
warm:()=>warmPacks(),
locked:(key)=>lockedOf(key),
delay:(ms,run)=>winOf()?.setTimeout?.(run,ms)??null,
cancel:(handle)=>{if(handle!==null&&handle!==undefined)winOf()?.clearTimeout?.(handle)},
elapsed:()=>{const now=winOf()?.performance?.now?.()
return typeof now==='number'&&bulkStartedAt!==null?now-bulkStartedAt:0},
onChange:()=>{repaintBulk()
flow.refresh()},
onDone:(reason)=>{
dropWarm()
if(reason==='captcha'||reason==='rate-limit'){restMarketAfterThrottle(budget)
eaLimits+=1}
if(reason!=='done'&&reason!=='gone')return
if(bulkJump?.ok!==true||bulkJump.reason!==null)return
if(showBusy){backPending=true
return}
void backToStore()},
onError})
let bulkStartedAt=null
let bulkNote=null
let bulkMoved=false
let hiddenMissed=0
let eaLimits=0
let hiddenExtra=0
let bulkJump=null
let jumping=false
let backing=false
let hubbing=false
let hubSaid=null
let showBusy=false
let backPending=false
let showsRaised=0
let showLast=null
let showResult=null
let showEnd=null
const frame=typeof deps.frame==='function'?deps.frame
:(run)=>{const raf=winOf()?.requestAnimationFrame
if(typeof raf==='function')raf.call(winOf(),run)
else run()}
const flowWord=(key,params)=>{if(key!=='packFlow.wait'&&key!=='packFlow.waitAny')return t(key,params)
const waiting=bulk.current()?.hold??null
if(waiting===BULK_HOLD_LAST)return t('packFlow.waitLast')
if(waiting===BULK_HOLD_RETRY)return t('packFlow.waitRetry')
return t(key,params)}
const flow=createPackFlowLine({doc,t:flowWord,status:()=>bulk.current(),
why:(reason)=>t(BULK_WHY[reason]??BULK_WHY.failed),
onToggle:()=>toggleBulk(),
onError})
let screenSeam=null
let flowScheduled=false
function scheduleFlow(){if(flowScheduled)return
flowScheduled=true
Promise.resolve().then(()=>{flowScheduled=false
try{flow.refresh()}catch(err){onError(err)}})}
function ensureScreenSeam(){if(screenSeam?.ok===true)return true
const win=winOf()
if(!win)return false
try{screenSeam=installUnassignedScreenCapture(win,scheduleFlow)}catch(err){onError(err)
screenSeam=null}
return screenSeam?.ok===true}
function parkWord(){try{return packFlowText(()=>'',{running:false,opened:1,total:2,reason:'door',parked:true},()=>'')?.action??null}catch(err){onError(err)
return null}}
function toggleBulk(){if(bulk.isRunning())return bulk.stop('stopped')
if(!bulk.canResume())return false
const now=winOf()?.performance?.now?.()
bulkStartedAt=typeof now==='number'?now:null
bulkMoved=false
return bulk.resume()}
const record=(result)=>{lastResult=result
return result}
function apply(capture){if(!doc||!capture?.box)return record({ok:false,reason:'no-capture'})
last=capture
schedule()
return record({ok:true,reason:'pending'})}
function schedule(){if(scheduled)return
scheduled=true
Promise.resolve().then(()=>{scheduled=false
try{settle()}catch(err){onError(err)}})}
function settle(){settles+=1
if(!last)return record({ok:false,reason:'no-capture'})
const{box,tiles,myPacks}=last
if(!isActive(STORE_GRID_FEATURE)){drop(box)
return away('locked')}
if(myPacks!==true){drop(box)
return away('not-my-packs')}
if(!setLock||!isLocked){drop(box)
return away('no-storage')}
if(box.isConnected===false){drop(box)
return away('detached')}
const groups=groupPacks(tiles)
if(groups.length===0){drop(box)
return away('empty')}
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,STORE_GRID_STYLESHEET,STORE_GRID_LINK_ID)
for(const group of groups){if(group.root.dataset&&group.root.dataset.futStorePack!==group.key)group.root.dataset.futStorePack=group.key}
if(box.dataset&&box.dataset[HOST_FLAG]!=='1')box.dataset[HOST_FLAG]='1'
flatten(box)
const clock=doc?.defaultView?.performance
const startedAt=typeof clock?.now==='function'?clock.now():null
render(mount(box),groups)
renders+=1
if(startedAt!==null)renderMs=Math.max(renderMs,Math.round((clock.now()-startedAt)*100)/100)
if(!storeOn){storeOn=true
resumeParked(groups)}
return record({ok:true,reason:null,groups:groups.length,packs:tiles.length})}
function away(reason){storeOn=false
return record({ok:false,reason})}
function resumeParked(groups){const shot=bulk.parked?.()??null
if(shot===null)return false
if(!groups.some((one)=>one.key===shot.key))return false
if(lockedOf(shot.key))return false
const now=winOf()?.performance?.now?.()
bulkStartedAt=typeof now==='number'?now:null
bulkMoved=false
parkedResumes+=1
const back=bulk.resume()
repaintBulk()
return back}
function refresh(){
ensureScreenSeam()
if(bulk.current()!==null)flow.refresh()
if(!last)return false
return settle().ok===true}
function relabel(){flow.relabel()
if(!last)return false
return settle().ok===true}
function mount(box){const existing=box.querySelector?.(OURS_SELECTOR)??null
if(existing)return existing
const node=el(doc,'div',{class:'fut-store-grid',dataset:{futStoreGrid:'1'}})
box.appendChild(node)
return node}
function render(host,groups){// Шапка и строка «ничего не нашлось» заводятся ПЕРВЫМИ: узел, созданный
const head=ensureHead(host)
const note=ensureNote(host)
const cards=groups.map((group)=>({group,facts:readPackFacts(group.root),hidden:hiddenOf(group.key)}))
const known=new Set()
let shown=0
for(const card of cards){known.add(card.group.key)
const node=ensureCard(host,card.group.key)
const on=packMatches({name:card.facts.name,tradable:card.group.tradable,hidden:card.hidden},view)
if(on)shown+=1
if(node.dataset&&node.dataset.futStoreOff!==(on?'0':'1'))node.dataset.futStoreOff=on?'0':'1'
renderCard(node,card)}
for(const node of host.querySelectorAll?.('[data-fut-store-card]')??[]){if(!known.has(String(node.dataset?.futStoreCard??'')))node.remove?.()}
renderHead(head,cards,shown)
write(note,cards.length>0&&shown===0?t('storeGrid.none'):'')}
function pinButton(){const on=pinned!==false
const button=el(doc,'button',{class:'fx-action fx-action-square fut-store-pin',
dataset:{futStorePin:on?'1':'0'},
attrs:{type:'button','aria-pressed':on?'true':'false',title:t(on?'storeGrid.pinOn':'storeGrid.pinOff')},
text:'📌'})
button.addEventListener?.('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
pinned=pinned===false
try{writeView?.({pinned})}catch(err){onError(err)}
const head=button.closest?.('[data-fut-store-head]')??doc?.querySelector?.('[data-fut-store-head]')
if(head)paintPin(head)})
return button}
function paintPin(head){if(!head?.dataset)return false
if(readView){const stored=readView()
if(stored&&typeof stored==='object'&&typeof stored.pinned==='boolean')pinned=stored.pinned}
const on=pinned!==false
if(head.dataset.futStorePinned!==(on?'1':'0'))head.dataset.futStorePinned=on?'1':'0'
const button=head.querySelector?.('[data-fut-store-pin]')
if(button){if(button.dataset.futStorePin!==(on?'1':'0'))button.dataset.futStorePin=on?'1':'0'
button.setAttribute?.('aria-pressed',on?'true':'false')
button.setAttribute?.('title',t(on?'storeGrid.pinOn':'storeGrid.pinOff'))}
return true}
function ensureHead(host){const existing=host.querySelector?.('[data-fut-store-head]')??null
if(existing)return existing
const search=el(doc,'input',{class:'fx-search fut-store-search',attrs:{type:'search'},dataset:{futStoreSearch:'1'}})
search.addEventListener?.('input',()=>{view.query=String(search.value??'')
refreshView()})
const trades=TRADE_FILTERS.map((name)=>el(doc,'button',{class:'fut-store-trade',attrs:{type:'button'},dataset:{futStoreTrade:name},on:{click:(event)=>{event?.preventDefault?.()
view.trade=name
refreshView()}}},[el(doc,'span',{class:'fut-store-trade-text',dataset:{futStoreTradeText:'1'}})]))
const menu=[search,el(doc,'div',{class:'fut-store-trades',dataset:{futStoreTrades:'1'}},trades)]
if(isHidden&&setHidden){const box=el(doc,'input',{attrs:{type:'checkbox'},dataset:{futStoreShowHidden:'1'}})
box.addEventListener?.('change',()=>{view.showHidden=box.checked===true
refreshView()})
menu.push(el(doc,'label',{class:'fut-store-check'},[box,el(doc,'span',{dataset:{futStoreShowHiddenText:'1'}})]))}
const hub=goHub?el(doc,'button',{class:'fx-action fut-store-hub',attrs:{type:'button'},dataset:{futStoreHub:'1'},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
void pressHub()}}},[el(doc,'span',{class:'fut-store-hub-text',dataset:{futStoreHubText:'1'}})]):null
const node=el(doc,'div',{class:'fx-bar fut-store-head',dataset:{futStoreHead:'1'}},[logoLink(doc),
el(doc,'div',{class:'fut-store-menu',dataset:{futStoreMenu:'1'}},menu),
el(doc,'span',{class:'fut-store-sum',dataset:{futStoreSum:'1'}}),
hub,pinButton()].filter(Boolean))
paintPin(node)
host.appendChild(node)
return node}
function renderHead(head,cards,shown){const packs=cards.reduce((sum,card)=>sum+card.group.count,0)
write(head.querySelector?.('[data-fut-store-sum]'),shown===cards.length
?t('storeGrid.summary',{packs,kinds:cards.length})
:t('storeGrid.shown',{shown,kinds:cards.length}))
const search=head.querySelector?.('[data-fut-store-search]')
if(search){nameNode(search,t('storeGrid.search'),'placeholder')
if(search.value!==view.query)search.value=view.query}
for(const button of head.querySelectorAll?.('[data-fut-store-trade]')??[]){const name=String(button.dataset?.futStoreTrade??'')
write(button.querySelector?.('[data-fut-store-trade-text]'),t(TRADE_LABELS[name]))
const on=view.trade===name?'1':'0'
if(button.dataset&&button.dataset.futStoreTradeOn!==on)button.dataset.futStoreTradeOn=on}
const check=head.querySelector?.('[data-fut-store-show-hidden]')
if(check&&check.checked!==view.showHidden)check.checked=view.showHidden
write(head.querySelector?.('[data-fut-store-show-hidden-text]'),t('storeGrid.showHidden'))
write(head.querySelector?.('[data-fut-store-hub-text]'),hubSaid??t('storeGrid.hub'))
paintPin(head)}
function ensureNote(host){const existing=host.querySelector?.('[data-fut-store-note]')??null
if(existing)return existing
const node=el(doc,'div',{class:'fut-store-note',dataset:{futStoreNote:'1'}})
host.appendChild(node)
return node}
function refreshView(){if(!last)return false
try{return settle().ok===true}catch(err){onError(err)
return false}}
function ensureCard(host,key){const existing=host.querySelector?.(`[data-fut-store-card="${key}"]`)??null
if(existing)return existing
const node=el(doc,'div',{class:'fut-store-card',dataset:{futStoreCard:key}},[
el(doc,'button',{class:'fut-store-lock',attrs:{type:'button'},dataset:{futStoreLock:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{toggleLock(key)}catch(err){onError(err)}}}}),
isHidden&&setHidden?el(doc,'button',{class:'fut-store-hide',attrs:{type:'button'},dataset:{futStoreHide:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{toggleHidden(key)}catch(err){onError(err)}}}}):null,
el(doc,'div',{class:'fut-store-art',dataset:{futStoreArt:'1'}},[el(doc,'span',{class:'fut-store-shot',dataset:{futStoreShot:'1',futStoreEmpty:'1'}},[el(doc,'span',{class:'fut-store-count',dataset:{futStoreCount:'1'}}),el(doc,'span',{class:'fut-store-mark',dataset:{futStoreMark:'1'}})])]),
el(doc,'div',{class:'fut-store-name',dataset:{futStoreName:'1'}}),
el(doc,'div',{class:'fut-store-facts',dataset:{futStoreFacts:'1'}}),
el(doc,'div',{class:'fut-store-odds',dataset:{futStoreOdds:key,futStoreOddsHas:'0',futStoreOddsOpen:'0'}},[
el(doc,'button',{class:'fut-store-odds-head',attrs:{type:'button'},dataset:{futStoreOddsToggle:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{toggleOdds(key)}catch(err){onError(err)}}}},[el(doc,'span',{class:'fut-store-odds-label',dataset:{futStoreOddsLabel:'1'}}),el(doc,'span',{class:'fut-store-odds-peek',dataset:{futStoreOddsPeek:'1'}}),el(doc,'span',{class:'fut-store-odds-value',dataset:{futStoreOddsPeekValue:'1'}})]),
el(doc,'div',{class:'fut-store-odds-list',dataset:{futStoreOddsList:'1'}}),
]),
el(doc,'div',{class:'fut-store-slot',attrs:{'aria-hidden':'true'},dataset:{futStoreSlot:'value'}}),
el(doc,'div',{class:'fut-store-bulk',dataset:{futStoreBulk:key,futStoreBulkHas:'0'}},[
el(doc,'button',{class:'fut-store-bulk-run',attrs:{type:'button'},dataset:{futStoreBulkRun:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{pressBulk(key)}catch(err){onError(err)}}}},[el(doc,'span',{class:'fut-store-bulk-text',dataset:{futStoreBulkText:'1'}})]),
el(doc,'div',{class:'fut-store-bulk-note',dataset:{futStoreBulkNote:'1'}}),
]),
el(doc,'button',{class:'fut-store-open',attrs:{type:'button'},dataset:{futStoreOpen:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{openPack(key)}catch(err){onError(err)}}}},[el(doc,'span',{class:'fut-store-open-text',dataset:{futStoreOpenText:'1'}}),el(doc,'span',{class:'fut-store-open-hint',dataset:{futStoreOpenHint:'1'}})]),
])
host.appendChild(node)
return node}
function renderCard(node,card){const{group,facts}=card
write(node.querySelector?.('[data-fut-store-count]'),group.count>1?t('storeGrid.count',{count:group.count}):'')
const mark=node.querySelector?.('[data-fut-store-mark]')
if(mark){drawTradeMark(mark,group.tradable)
nameNode(mark,group.tradable?t('storeGrid.tradeable'):t('storeGrid.untradeable'))}
setArt(node.querySelector?.('[data-fut-store-shot]'),facts.art)
write(node.querySelector?.('[data-fut-store-name]'),facts.name)
write(node.querySelector?.('[data-fut-store-facts]'),factsLine(facts,group.players))
renderOdds(node,group)
renderBulk(node,group)
paintLock(node,group.key)
paintHidden(node,group.key,card.hidden)}
function renderBulk(node,group){const box=node.querySelector?.('[data-fut-store-bulk]')
if(!box)return
const many=group.count>1
if(box.dataset&&box.dataset.futStoreBulkHas!==(many?'1':'0'))box.dataset.futStoreBulkHas=many?'1':'0'
if(!many)return
const button=box.querySelector?.('[data-fut-store-bulk-run]')
const note=box.querySelector?.('[data-fut-store-bulk-note]')
const status=bulk.statusOf(group.key)
const running=status?.running===true
const resumable=bulk.canResume(group.key)
const parked=!running&&status?.parked===true
const left=parked&&Number.isSafeInteger(status.total)&&Number.isSafeInteger(status.opened)
?Math.max(0,status.total-status.opened):0
const blocked=running&&status.hold==='unassigned'
write(button?.querySelector?.('[data-fut-store-bulk-text]'),running
?(blocked?blockedWord()
:(BULK_HOLD_WHY[status.hold]?t('storeGrid.bulk.hold',{opened:status.opened,total:status.total,why:t(BULK_HOLD_WHY[status.hold])})
:t('storeGrid.bulk.busy',{opened:status.opened,total:status.total})))
:(parked?t('storeGrid.bulk.parked',{left,total:status.total})
:(resumable?t('storeGrid.bulk.resume',{opened:status.opened,total:status.total})
:t('storeGrid.bulk.run',{count:group.count}))))
setTitle(button,blocked?t('storeGrid.bulk.goHint'):(running?t('storeGrid.bulk.stopHint'):''))
if(button?.dataset&&button.dataset.futStoreBulkOn!==(running?'1':'0'))button.dataset.futStoreBulkOn=running?'1':'0'
const loud=blocked||parked?'1':'0'
if(button?.dataset&&button.dataset.futStoreBulkWhy!==loud)button.dataset.futStoreBulkWhy=loud
if(node.dataset&&node.dataset.futStoreSay!==loud)node.dataset.futStoreSay=loud
const keyed=running||resumable
if(button?.dataset){if(keyed&&button.dataset.futBulkStop!=='1')button.dataset.futBulkStop='1'
if(!keyed&&button.dataset.futBulkStop!==undefined)delete button.dataset.futBulkStop}
const off=lockedOf(group.key)&&!running
if(button&&button.disabled!==off)button.disabled=off
write(note,parked
?t('storeGrid.bulk.parkedNote',{why:t(BULK_WHY[status.reason]??BULK_WHY.failed),left})
:(said!==null&&said.key===group.key?said.text
:(status&&!running&&!resumable
?t('storeGrid.bulk.result',{opened:status.opened,total:status.total,why:t(BULK_WHY[status.reason]??BULK_WHY.failed)})
:'')))}
function blockedWord(){const pile=unassignedInCache(winOf())
return Number.isSafeInteger(pile)&&pile>0
?t('storeGrid.bulk.blocked',{count:pile})
:t('storeGrid.bulk.blockedAny')}
let said=null
function say(key,text){said=text===''?null:{key,text}}
function setTitle(node,text){if(!node)return
if(text===''){if(node.getAttribute?.('title')!==null)node.removeAttribute?.('title')
return}
if(node.getAttribute?.('title')!==text)node.setAttribute?.('title',text)}
function pressBulk(key){const status=bulk.statusOf(key)
if(status?.running===true&&status.hold==='unassigned'){said=null
if(jumping)return false
jumping=true
void jumpToUnassigned(key)
return true}
return runBulk(key)}
async function jumpToUnassigned(key){try{const stop=await noteCall(JUMP_CALLS)
if(stop!==null){say(key,t(BULK_WHY[bulkDoorReason(stop).name]??BULK_WHY.failed))
repaintBulk()
return}
let jump=null
try{jump=goToUnassigned(winOf())}catch(err){onError(err)
jump=null}
bulkJump=jump?.reason==='already'?bulkJump:jump
if(jump?.ok!==true)say(key,t('storeGrid.bulk.noWay'))
repaintBulk()}
catch(err){onError(err)}
finally{jumping=false}}
async function pressHub(){
if(hubbing)return
hubbing=true
hubSaid=null
try{const stop=await noteCall(HUB_CALLS)
if(stop!==null){hubSaid=t(BULK_WHY[bulkDoorReason(stop).name]??BULK_WHY.failed)
refreshView()
return}
try{goHub()}catch(err){onError(err)}}
catch(err){onError(err)}
finally{hubbing=false}}
function runBulk(key){
said=null
if(bulk.canResume(key)){const then=winOf()?.performance?.now?.()
bulkStartedAt=typeof then==='number'?then:null
bulkMoved=false
const back=bulk.resume()
repaintBulk()
return back}
const group=groupPacks(last?.tiles??[]).find((one)=>one.key===key)??null
if(!group||group.count<2){say(key,t('storeGrid.bulk.why.gone'))
repaintBulk()
return false}
const now=winOf()?.performance?.now?.()
bulkStartedAt=typeof now==='number'?now:null
bulkMoved=false
const done=bulk.start(key,group.count)
if(!done)say(key,t('storeGrid.bulk.why.failed'))
repaintBulk()
return done}
function repaintBulk(){const host=last?.box?.querySelector?.(OURS_SELECTOR)??null
if(!host)return
for(const group of groupPacks(last?.tiles??[])){const node=host.querySelector?.(`[data-fut-store-card="${group.key}"]`)
if(node)renderBulk(node,group)}}
function renderOdds(node,group){const box=node.querySelector?.('[data-fut-store-odds]')
if(!box)return
const rows=Array.isArray(group.odds)?group.odds:[]
if(box.dataset)box.dataset.futStoreOddsHas=rows.length>0?'1':'0'
if(rows.length===0)return
write(box.querySelector?.('[data-fut-store-odds-label]'),t('storeGrid.odds'))
write(box.querySelector?.('[data-fut-store-odds-peek]'),rows[0].text)
write(box.querySelector?.('[data-fut-store-odds-peek-value]'),rows[0].odds)
const open=oddsOpen.has(group.key)?'1':'0'
if(box.dataset&&box.dataset.futStoreOddsOpen!==open)box.dataset.futStoreOddsOpen=open
const list=box.querySelector?.('[data-fut-store-odds-list]')
if(!list)return
const size=printMark(rows.flatMap((row)=>[row.text,row.odds]))
if(list.dataset?.futStoreOddsSize===size)return
if(list.dataset)list.dataset.futStoreOddsSize=size
clear(list)
for(const row of rows){list.appendChild(el(doc,'div',{class:'fut-store-odds-row'},[el(doc,'span',{class:'fut-store-odds-name',text:row.text}),el(doc,'span',{class:'fut-store-odds-value',text:row.odds})]))}}
function paintHidden(node,key,hidden){const on=hidden===true
if(node.dataset&&node.dataset.futStoreHidden!==(on?'1':'0'))node.dataset.futStoreHidden=on?'1':'0'
const button=node.querySelector?.('[data-fut-store-hide]')
if(!button)return
if(button.dataset&&button.dataset.futStoreHideOn!==(on?'1':'0'))button.dataset.futStoreHideOn=on?'1':'0'
drawEye(button,on)
nameNode(button,on?t('storeGrid.hide.on'):t('storeGrid.hide.off'))}
function factsLine(facts,players){if(facts.items===null)return ''
if(!Number.isSafeInteger(players)||players<=0)return t('storeGrid.facts',{items:facts.items})
return t('storeGrid.factsPlayers',{items:facts.items,players})}
function setArt(host,src){if(!host)return
const existing=host.querySelector?.('[data-fut-store-img]')??null
if(host.dataset)host.dataset.futStoreEmpty=src===''?'1':'0'
if(src===''){existing?.remove?.()
return}
if(existing){if(existing.getAttribute?.('src')!==src)existing.setAttribute?.('src',src)
return}
const node=el(doc,'img',{class:'fut-store-img',attrs:{src,alt:''},dataset:{futStoreImg:'1'}})
if(typeof host.insertBefore==='function'&&host.firstChild)host.insertBefore(node,host.firstChild)
else host.appendChild(node)}
function paintLock(node,key){const on=lockedOf(key)
node.dataset.futStoreLocked=on?'1':'0'
const lock=node.querySelector?.('[data-fut-store-lock]')
if(lock){lock.dataset.futStoreLockOn=on?'1':'0'
nameNode(lock,on?t('storeGrid.lock.on'):t('storeGrid.lock.off'))}
const open=node.querySelector?.('[data-fut-store-open]')
if(!open)return
write(open.querySelector?.('[data-fut-store-open-text]'),t('storeGrid.open'))
write(open.querySelector?.('[data-fut-store-open-hint]'),on?t('storeGrid.lockedHint'):'')
if(open.disabled!==on)open.disabled=on
if(on&&open.getAttribute?.('disabled')===null)open.setAttribute?.('disabled','disabled')
if(!on&&open.getAttribute?.('disabled')!==null)open.removeAttribute?.('disabled')}
const SVG_NS='http://www.w3.org/2000/svg'
function drawTradeMark(host,tradable){if(!host)return false
const was=host.dataset?.futStoreTradable
const now=tradable?'1':'0'
if(was===now&&host.firstChild)return false
if(host.dataset)host.dataset.futStoreTradable=now
if(typeof doc?.createElementNS!=='function')return false
const shape=(tag,attrs)=>{const node=doc.createElementNS(SVG_NS,tag)
for(const[name,value]of Object.entries(attrs))node.setAttribute(name,String(value))
return node}
const box=shape('svg',{viewBox:'0 0 20 20',fill:'none','aria-hidden':'true'})
box.appendChild(shape('path',{d:'M10 2.9V17.1',stroke:'currentColor','stroke-width':1.7,'stroke-linecap':'round'}))
box.appendChild(shape('path',{d:'M13.7 7.1C13.7 5.4 12 4.5 10 4.5C8 4.5 6.5 5.4 6.5 7C6.5 8.6 8.1 9.3 10 9.7C11.9 10.1 13.7 10.9 13.7 12.7C13.7 14.4 12 15.4 10 15.4C8 15.4 6.3 14.5 6.3 12.7',stroke:'currentColor','stroke-width':1.7,'stroke-linecap':'round','stroke-linejoin':'round'}))
if(!tradable){box.appendChild(shape('path',{d:'M4.2 15.8L15.8 4.2',stroke:'var(--fx-surface)','stroke-width':4,'stroke-linecap':'round'}))
box.appendChild(shape('path',{d:'M4.2 15.8L15.8 4.2',stroke:'currentColor','stroke-width':1.8,'stroke-linecap':'round'}))}
clear(host)
host.appendChild(box)
return true}
function drawEye(host,hidden){if(!host)return false
const was=host.dataset?.futStoreEye
const now=hidden?'1':'0'
if(was===now&&host.firstChild)return false
if(host.dataset)host.dataset.futStoreEye=now
if(typeof doc?.createElementNS!=='function')return false
const shape=(tag,attrs)=>{const node=doc.createElementNS(SVG_NS,tag)
for(const[name,value]of Object.entries(attrs))node.setAttribute(name,String(value))
return node}
const box=shape('svg',{viewBox:'0 0 20 20',fill:'none','aria-hidden':'true'})
box.appendChild(shape('path',{d:'M1.8 10C3.6 6.4 6.6 4.6 10 4.6C13.4 4.6 16.4 6.4 18.2 10C16.4 13.6 13.4 15.4 10 15.4C6.6 15.4 3.6 13.6 1.8 10Z',stroke:'currentColor','stroke-width':1.5,'stroke-linejoin':'round'}))
box.appendChild(shape('circle',{cx:10,cy:10,r:2.4,stroke:'currentColor','stroke-width':1.5}))
if(hidden){box.appendChild(shape('path',{d:'M4 16L16 4',stroke:'var(--fx-surface)','stroke-width':4,'stroke-linecap':'round'}))
box.appendChild(shape('path',{d:'M4 16L16 4',stroke:'currentColor','stroke-width':1.8,'stroke-linecap':'round'}))}
clear(host)
host.appendChild(box)
return true}
function nameNode(node,title,attr=null){if(attr!==null){if(node?.getAttribute?.(attr)!==title)node?.setAttribute?.(attr,title)
return}
if(node?.getAttribute?.('title')===title)return
node?.setAttribute?.('title',title)
node?.setAttribute?.('aria-label',title)}
function write(node,text){if(node&&node.textContent!==text)node.textContent=text}
function lockedOf(key){try{return isLocked(key)===true}catch(err){onError(err)
return true}}
function toggleLock(key){if(!setLock)return false
const done=setLock(key,!lockedOf(key))
repaint()
return done}
function hiddenOf(key){if(!isHidden)return false
try{return isHidden(key)===true}catch(err){onError(err)
return false}}
function toggleHidden(key){if(!setHidden)return false
const done=setHidden(key,!hiddenOf(key))
refreshView()
return done}
function toggleOdds(key){if(oddsOpen.has(key))oddsOpen.delete(key)
else oddsOpen.add(key)
refreshView()
return oddsOpen.has(key)}
function repaint(){const host=last?.box?.querySelector?.(OURS_SELECTOR)??null
for(const node of host?.querySelectorAll?.('[data-fut-store-card]')??[])paintLock(node,String(node.dataset?.futStoreCard??''))
repaintBulk()}
function openPack(key){if(lockedOf(key))return false
const box=last?.box??null
const tile=box?.querySelector?.(`[data-fut-store-pack="${key}"]`)??null
const button=tile?.querySelector?.('.primary')??null
if(!button?.dispatchEvent)return false
const win=doc?.defaultView??null
const send=(type,ctor)=>{const Ctor=win?.[ctor]??win?.MouseEvent
if(typeof Ctor!=='function')return
try{button.dispatchEvent(new Ctor(type,{bubbles:true,cancelable:true,composed:true}))}catch(err){onError(err)}}
send('pointerdown','PointerEvent')
send('mousedown','MouseEvent')
send('mouseup','MouseEvent')
send('click','MouseEvent')
return true}
function flatten(box){const note=box?.querySelector?.(DISCLAIMER_SELECTOR)??null
const empty=note!==null&&String(note.textContent??'').trim()===''
if(!box?.dataset)return false
if(empty){if(box.dataset[FLAT_FLAG]!=='1')box.dataset[FLAT_FLAG]='1'}
else if(box.dataset[FLAT_FLAG]==='1')delete box.dataset[FLAT_FLAG]
return empty}
function drop(box){if(!box)return
box.querySelector?.(OURS_SELECTOR)?.remove?.()
if(box.dataset&&box.dataset[HOST_FLAG]==='1')delete box.dataset[HOST_FLAG]
if(box.dataset&&box.dataset[FLAT_FLAG]==='1')delete box.dataset[FLAT_FLAG]
for(const node of box.querySelectorAll?.(PACK_SELECTOR)??[]){if(node.dataset)delete node.dataset.futStorePack}}
return{apply,refresh,relabel,
wantsMyPacks:()=>isActive(STORE_GRID_FEATURE)===true,
noteJump:(result)=>{lastJump=result??null},
noteOpen:(answer)=>{try{bulk.note(answer)}catch(err){onError(err)}},
state:()=>({active:isActive(STORE_GRID_FEATURE),lastResult,captured:Boolean(last),myPacks:last?.myPacks??null,packs:last?.tiles?.length??0,
odds:{raw:(last?.tiles??[]).reduce((sum,tile)=>sum+Math.max(0,tile?.oddsRaw??0),0),mine:(last?.tiles??[]).reduce((sum,tile)=>sum+(tile?.odds?.length??0),0),noField:(last?.tiles??[]).filter((tile)=>(tile?.oddsRaw??-1)<0).length},
work:{settles,renders,slowestRenderMs:renderMs},pinned,
flat:last?.box?.dataset?.[FLAT_FLAG]==='1',groups:groupPacks(last?.tiles??[]).map((group)=>({key:group.key,count:group.count,locked:lockedOf(group.key),hidden:hiddenOf(group.key),odds:group.odds.length})),storage:Boolean(setLock&&isLocked),hiddenStorage:Boolean(setHidden&&isHidden),view:{...view},jump:lastJump,cards:doc?.querySelectorAll?.('[data-fut-store-card]')?.length??0,styles:Boolean(doc?.getElementById?.(STORE_GRID_LINK_ID)),
bulk:{...bulk.state(),pile:unassignedInCache(winOf()),pileFresh:unassignedCacheFresh(winOf()),note:bulkNote?{...bulkNote}:null,
jump:bulkJump?{...bulkJump}:null,canResume:bulk.canResume(),flow:flow.state(),parkWord:parkWord(),
parked:bulk.parked?.()??null,storeOn,parkedResumes,
warm:{raised:warmsRaised,used:warmsUsed,refused:warmsRefused,pending:warming!==null},
budget:{build:'W22D',step:PACK_STEP_CALLS,hiddenMissed,hiddenExtra,eaLimits},
seam:screenSeam?.ok===true},
show:{judge:showFor!==null,raised:showsRaised,busy:showBusy,backPending,
last:showLast?{...showLast}:null,door:showResult?{...showResult}:null,end:showEnd}}),
dispose(){bulk.dispose()
dropWarm()
flow.dispose()
try{screenSeam?.dispose?.()}catch(err){onError(err)}
screenSeam=null
drop(last?.box??null)
last=null}}}
