import{netAfterTax} from './tax.js'
import{changedFields}from './filters.js'
import{SEARCH_SCREEN_ROOT}from '../adapter/market-screen.js'
import{stopReasonKey}from '../automation/stop-reasons.js'
import{consentFingerprint}from './automation-actions.js'
import{LOOT_PILE_CLUB} from './hunt-loot.js'
import{WORK_MS,BREAK_MS,SESSION_MS,DEFAULT_SEARCH_DELAY_MS,STANDARD_UNASSIGNED_LIMIT,BID_REFRESH_TOP}from '../automation/sniper.js'
import{CHECK_ORDER}from '../automation/stop-conditions.js'
import{parseLimits,limitsToInput}from '../automation/limits-input.js'
import{ALLOW_UNASSIGNED_OVERFLOW,AFTER_BUY_SHOWN,SEARCH_REFRESH,SEARCH_REFRESH_KEY,searchRefreshOf}from '../automation/options-input.js'
export const SNIPE_FEATURE='autoSnipe'
export const DISCLAIMER_TEXT_KEY='snipe.disclaimer'
export const TARGET_NO_CAP='no-cap'
const TARGET_NO_CRITERIA='no-criteria'
const TARGET_OK='ok'
export function targetFromCriteria(criteria){if(!criteria||typeof criteria!=='object'||Array.isArray(criteria)){
return{ok:false,reason:TARGET_NO_CRITERIA,criteria:null,cap:0}}
const cap=Number(criteria.maxBuy)
if(!Number.isSafeInteger(cap)||cap<=0)return{ok:false,reason:TARGET_NO_CAP,criteria:null,cap:0}
return{ok:true,reason:TARGET_OK,criteria:{...criteria},cap}}
export function cardIdOf(criteria){const list=criteria?.defId
if(Array.isArray(list)&&list.length===1&&Number.isSafeInteger(list[0])&&list[0]>0)return list[0]
const masked=Number(criteria?.maskedDefId)
return Number.isSafeInteger(masked)&&masked>0?masked:null}
const TARGET_SAID_FIELDS=Object.freeze(['defId','maskedDefId','maxBuy','type',
'minBid','maxBid','minBuy'])
export function narrowWords(criteria,t,names=null,named=false){return narrowParts(criteria,t,names,named).join(' · ')}
export function narrowParts(criteria,t,names=null,named=false){if(!criteria||typeof criteria!=='object')return []
const out=[]
const say=(value)=>{const said=String(value??'').trim()
if(said!=='')out.push(said)}
say(rarityWords(criteria,t,names))
if(named===true)return out
const position=changedOne(criteria,'position')
if(position!==undefined)say(valueWords(position,'position',t))
else say(nameOf(criteria,names,'zone'))
say(nameOf(criteria,names,'club')??nameOf(criteria,names,'league'))
return out}
function rarityWords(criteria,t,names=null){
const flags=rarityFlags(criteria)
if(flags.length>0){const ask=typeof names?.rarity==='function'?names.rarity:null
const said=[]
for(const one of flags){let word=null
if(ask!==null){try{const got=ask(one)
word=typeof got==='string'&&got.trim()!==''?got.trim():null}catch{word=null}}
if(isSpecialFlag(one)&&(word===null||shortCode(word)))word=t('snipe.value.special')
if(word!==null&&!said.includes(word))said.push(word)}
if(said.length>0)return said.join(', ')}
for(const name of ['level','type']){const value=changedOne(criteria,name)
if(value===undefined)continue
if(name==='type'&&String(value)==='player')continue
const said=valueWords(value,name,t)
if(said!=='')return said}
return ''}
function rarityFlags(criteria){const raw=changedOne(criteria,'rarities')
if(raw===undefined)return []
const list=Array.isArray(raw)?raw:[raw]
const out=[]
for(const one of list){const n=Number(one)
if(Number.isSafeInteger(n)&&n>=0&&!out.includes(n))out.push(n)}
return out}
export const RARITY_NONE=0
export const RARITY_RARE=1
export function isSpecialFlag(flag){const n=Number(flag)
return Number.isSafeInteger(n)&&n!==RARITY_NONE&&n!==RARITY_RARE}
export function huntsSpecial(criteria){if(!criteria||typeof criteria!=='object')return false
if(isSpecialLevel(changedOne(criteria,'level')))return true
return rarityFlags(criteria).some(isSpecialFlag)}
function shortCode(word){const said=String(word??'').trim()
return said.length>0&&said.length<4&&said===said.toUpperCase()&&/[A-Z]/.test(said)}
function changedOne(criteria,name){if(QUIET_FIELDS.includes(name))return undefined
let changed={}
try{changed=changedFields(criteria)}catch{return undefined}
return Object.hasOwn(changed,name)?changed[name]:undefined}
function nameOf(criteria,names,field){const value=changedOne(criteria,field)
if(value===undefined)return null
const ask=typeof names?.[field]==='function'?names[field]:null
if(ask===null)return null
try{const got=ask(value)
return typeof got==='string'&&got.trim()!==''?got.trim():null}catch{return null}}
export function sessionSearchCap(){const cycleMs=WORK_MS+BREAK_MS
if(!(cycleMs>0)||!(SESSION_MS>0)||!(DEFAULT_SEARCH_DELAY_MS>0))return 0
const whole=Math.floor(SESSION_MS/cycleMs)
const tail=SESSION_MS-whole*cycleMs
const workMs=whole*WORK_MS+Math.min(tail,WORK_MS)
return Math.floor(workMs/DEFAULT_SEARCH_DELAY_MS)}
function searchLimitWarning(limits,cap=sessionSearchCap()){const raw=limits?.maxSearches
const said=String(raw??'').trim()
if(said==='')return null
const value=Number(said)
if(!Number.isSafeInteger(value)||value<=0)return null
return cap>0&&value<cap?value:null}
export function stopLadder(limits,sessionMs=SESSION_MS){let parsed=null
try{parsed=parseLimits(limits&&typeof limits==='object'?limits:{},{random:()=>0.5})}catch{parsed=null}
if(parsed===null)return []
let shown={}
try{shown=limitsToInput(parsed.limits)}catch{shown={}}
const out=[]
for(const key of CHECK_ORDER){
if(key==='maxDurationMs'&&Number.isFinite(sessionMs)&&sessionMs>0){out.push({key:'session',value:Math.round(sessionMs/60_000)})}
const said=shown?.[key]
if(typeof said!=='string'||said==='')continue
const value=Number(said)
if(!Number.isFinite(value)||value<0)continue
out.push({key,value})}
return out}
function searchesToMs(count,pauseMs){if(!Number.isFinite(count)||count<=0)return null
if(!Number.isFinite(pauseMs)||pauseMs<=0)return null
if(!(WORK_MS>0))return count*pauseMs
const work=count*pauseMs
const breaks=Math.max(0,Math.ceil(work/WORK_MS)-1)
return work+breaks*BREAK_MS}
const PREDICTABLE=Object.freeze(['maxSearches','session','maxDurationMs'])
function stopPromise(limits,options,sessionMs=SESSION_MS){const rungs=stopLadder(limits,sessionMs)
if(rungs.length===0)return null
const byKey=new Map(rungs.map((one)=>[one.key,one.value]))
let pauseMs=DEFAULT_SEARCH_DELAY_MS
try{const said=parseOptions(options&&typeof options==='object'?options:{})?.options
const value=Number(said?.searchDelayMs)
if(Number.isFinite(value)&&value>0)pauseMs=value}catch{pauseMs=DEFAULT_SEARCH_DELAY_MS}
let best=null
for(const key of PREDICTABLE){if(!byKey.has(key))continue
const value=byKey.get(key)
const ms=key==='maxSearches'?searchesToMs(value,pauseMs):value*60_000
if(ms===null||!Number.isFinite(ms)||ms<=0)continue
if(best===null||ms<best.ms)best={key,value,ms}}
if(best===null)return null
const searchBound=byKey.has('maxSearches')?byKey.get('maxSearches'):sessionSearchCap()
const buys=byKey.has('maxPurchases')?byKey.get('maxPurchases'):null
return{key:best.key,value:best.value,
buys:buys!==null&&Number.isFinite(searchBound)&&searchBound>0&&buys<searchBound?buys:null}}
const QUIET_FIELDS=Object.freeze(['count','offset','maskedDefId','sort','sortBy','isExactSearch'])
const ID_FIELDS=Object.freeze(['club','league','nation'])
function describeCriteria(criteria,t,names=null){if(!criteria||typeof criteria!=='object')return ''
let changed={}
try{changed=changedFields(criteria)}catch{changed={}}
const parts=[]
for(const name of Object.keys(changed).sort()){if(QUIET_FIELDS.includes(name))continue
const value=changed[name]
if(ID_FIELDS.includes(name)){const ask=typeof names?.[name]==='function'?names[name]:null
let named=null
if(ask!==null){try{const got=ask(value)
named=typeof got==='string'&&got.trim()!==''?got.trim():null}catch{named=null}}
if(named!==null)parts.push(named)
continue}
const said=valueWords(value,name,t)
if(BARE_FIELDS.includes(name)&&said!==''){parts.push(said)
continue}
const key=`snipe.field.${name}`
const label=t(key)
const shown=label===key?name:label
parts.push(`${shown} ${said}`.trim())}
return parts.join(' · ')}
export const PLAIN_LEVELS=Object.freeze(['any','bronze','silver','gold'])
export const SPECIAL_LEVEL='SP'
export function isSpecialLevel(value){if(value===null||value===undefined)return false
const said=String(value).trim()
if(said==='')return false
return !PLAIN_LEVELS.includes(said.toLowerCase())}
const VALUE_KEYS=Object.freeze({level:Object.freeze({gold:'snipe.value.gold',
silver:'snipe.value.silver',bronze:'snipe.value.bronze',
[SPECIAL_LEVEL]:'snipe.value.special'})})
const BARE_FIELDS=Object.freeze(['level'])
function valueWords(value,name='',t=null){const said=VALUE_KEYS[name]?.[String(value)]
if(said!==undefined&&typeof t==='function'){const word=t(said)
if(word!==said)return word}
if(Array.isArray(value))return value.join(', ')
if(typeof value==='boolean')return ''
return String(value)}
const LOOT_NAME_MAX=48
export function lootRowModel(raw,market){const paidRaw=Number(raw?.price)
const paid=Number.isSafeInteger(paidRaw)&&paidRaw>0?paidRaw:0
const value=Number.isSafeInteger(market)&&market>0?market:null
const rating=Number(raw?.rating)
const id=Number(raw?.id)
const definitionId=Number(raw?.definitionId)
return{id:Number.isSafeInteger(id)&&id>0?id:null,
definitionId:Number.isSafeInteger(definitionId)&&definitionId>0?definitionId:null,
name:typeof raw?.name==='string'?raw.name.trim().slice(0,LOOT_NAME_MAX):'',
rating:Number.isSafeInteger(rating)&&rating>0?rating:null,
paid,market:value,
profit:value===null?null:netAfterTax(value)-paid,
listed:raw?.listed===true,
pile:raw?.pile===LOOT_PILE_CLUB?LOOT_PILE_CLUB:null}}
export function consentLabelKey(consent){if(consent?.ok===true)return 'snipe.disclaimerOk'
if(consent?.reason===CONSENT_TEXT_MISMATCH)return 'snipe.disclaimerMismatch'
if(consent?.reason==='stale')return 'snipe.disclaimerStale'
if(consent?.reason==='no-port'||consent?.reason==='no-text'||consent?.reason==='unreadable'){return 'snipe.disclaimerNoPort'}
return 'snipe.disclaimerNo'}
export const CONSENT_TEXT_MISMATCH='text-mismatch'
export function consentTextDiffers(consent,shown){const said=consent?.fingerprint
if(typeof said!=='string'||said==='')return false
const mine=consentFingerprint(shown)
return mine!==null&&mine!==said}
export function clockWords(ms){const total=Number(ms)
if(!Number.isFinite(total)||total<0)return '00:00'
const seconds=Math.floor(total/1000)
const mm=Math.floor(seconds/60)
const ss=seconds%60
return `${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`}
export function controlModel(status,target,budget,unassigned=null){const running=status?.running===true
const stats=status?.stats??null
const hasTarget=target?.ok===true
const dry=status?.dryRun!==false
const paid=Number.isSafeInteger(stats?.spent)?stats.spent:0
const ladder=stopLadder(status?.limits)
const promise=stopPromise(status?.limits,status?.options)
return{running,hasTarget,
dry,
canStart:hasTarget&&!running,
elapsedMs:Number.isFinite(stats?.elapsedMs)?stats.elapsedMs:0,
searches:Number.isSafeInteger(stats?.searches)?stats.searches:0,
wouldBuy:Number.isSafeInteger(stats?.wouldBuy)?stats.wouldBuy:0,
seen:Number.isSafeInteger(status?.filter?.seen)?status.filter.seen:null,
overTargetCap:Number.isSafeInteger(status?.filter?.overTargetCap)?status.filter.overTargetCap:null,
overMaxPrice:Number.isSafeInteger(status?.filter?.overMaxPrice)?status.filter.overMaxPrice:null,
phase:typeof status?.session?.phase==='string'?status.session.phase:null,
bought:Number.isSafeInteger(stats?.purchases)?stats.purchases:0,
spent:dry?0:paid,
wouldSpend:dry?paid:null,
searchesLeft:budget?.available===false?null:(Number.isSafeInteger(budget?.left)?budget.left:null),
searchesCap:Number.isSafeInteger(budget?.cap)?budget.cap:null,
searchesUsed:budget?.available===false?null:(Number.isSafeInteger(budget?.used)?budget.used:null),
searchesAdvice:typeof budget?.advice==='string'?budget.advice:null,
limitSearches:searchLimitWarning(status?.limits),
stopAt:ladder,
promise,
unassignedCount:Number.isSafeInteger(unassigned?.count)&&unassigned.count>=0?unassigned.count:null,
unassignedLimit:STANDARD_UNASSIGNED_LIMIT,
unassignedFull:status?.options?.[ALLOW_UNASSIGNED_OVERFLOW]!==true
&&Number.isSafeInteger(unassigned?.count)
&&unassigned.count>=STANDARD_UNASSIGNED_LIMIT,
bid:searchBidOf(status),
reason:typeof status?.reason==='string'?status.reason:null}}
export function searchBidOf(status){const how=status?.options?.[SEARCH_REFRESH_KEY]
const ring=searchRefreshOf(how)!==SEARCH_REFRESH.OFF
if(!ring)return{show:false,top:BID_REFRESH_TOP,coins:null}
const sent=status?.filter?.lastBidSent
const live=status?.running===true&&Number.isSafeInteger(sent)&&sent>0
return{show:true,top:BID_REFRESH_TOP,coins:live?sent:null}}
export const AFTER_BUY_CHOICES=AFTER_BUY_SHOWN
export function digitsOf(text){const raw=String(text??'').replace(/[^0-9]/g,'')
if(raw==='')return 0
const value=Number(raw)
return Number.isSafeInteger(value)?value:0}
export function searchScreenRoot(doc){try{return doc?.querySelector?.(SEARCH_SCREEN_ROOT)??null}catch{return null}}
