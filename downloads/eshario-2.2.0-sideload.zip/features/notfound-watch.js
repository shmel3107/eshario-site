import{installShellWatch,shellFacts,shellLabel,screenTitle,eaBuild,askShell,shellSlot}from'../adapter/card-shell.js'
import{eaRequestState}from'../adapter/observable.js'
import{VIEW_SELECTOR}from'./card-views.js'
import{CARD_GRID_FEATURE}from'./card-grid.js'
export const NOTFOUND_BUILD='NF2'
export const CASE_CAP=100
export const TRANSITION_CAP=8
export const RESOURCE_CAP=300
export const BATCH_GAP_MS=400
export const RETRY_DELAY_MS=3000
export const RETRY_CAP=20
export const RETRY_SETTLE_MS=15000
export const LATE_MS=6000
export const CURE_URL_CAP=300
export const CURE_VIEW_CAP=60
const rooms=new WeakMap()
function nowOf(win){try{const v=win?.performance?.now?.()
return typeof v==='number'?v:0}catch{return 0}}
function ourRequests(){try{const n=eaRequestState()?.passed
return Number.isFinite(n)?n:null}catch{return null}}
function inGrid(view){try{const root=typeof view?.getRootElement==='function'?view.getRootElement():null
if(!root||typeof root.closest!=='function')return null
if(root.isConnected===false)return null
return root.closest(VIEW_SELECTOR)!==null}catch{return null}}
function createRoom(win,doc,deps){return{win,doc,startedAt:nowOf(win),
capture:{ok:false,reason:'unavailable',dispose(){}},observer:null,observerWhy:null,
cards:0,cdn:0,cdnLarge:0,local:0,notFound:0,orphan:0,
pending:new WeakMap(),
batches:0,lastShellAt:-Infinity,batch:null,closed:{grid:0,bare:0,unknown:0,bad:{grid:0,bare:0,unknown:0}},
screen:null,screenAt:0,transitions:[],cases:[],resources:new Map(),rarityFile:[],
own:false,
cure:{isActive:typeof deps.isActive==='function'?deps.isActive:()=>false,
timer:typeof deps.setTimeout==='function'?deps.setTimeout:(fn,ms)=>win.setTimeout(fn,ms),
recs:new Map(),retries:0,retryUrls:0,healedRetry:0,healedMemory:0,deadUrls:0,deadViews:0,capped:0,late:0,
viewRec:new WeakMap()}}}
function closeBatch(room){const b=room.batch
if(b===null)return
room.batch=null
const g=b.grid??inGrid(b.first)
const key=g===true?'grid':g===false?'bare':'unknown'
room.closed[key]++
if(b.bad>0)room.closed.bad[key]++}
function onShell(room,view,url,kind,item,type){if(kind==='loaded'){onLoaded(room,view,url)
return}
if(kind==='stub-loaded'){onStubLoaded(room,view)
return}
if(room.own)return
const t=nowOf(room.win)
if(t-room.lastShellAt>BATCH_GAP_MS){closeBatch(room)
room.batches++
const title=screenTitle(room.doc)
if(title!==room.screen){if(room.transitions.length>=TRANSITION_CAP)room.transitions.shift()
room.transitions.push({at:t,from:room.screen,to:title})
room.screen=title
room.screenAt=t}
room.batch={first:view,bad:0,index:room.batches,grid:null}}
room.lastShellAt=t
if(kind==='fallback'){onFallback(room,view,url,item,t)
return}
room.cards++
if(kind==='local'){room.local++
return}
if(kind==='cdn-large')room.cdnLarge++
else room.cdn++
room.pending.set(view,{url,at:t,ours:ourRequests(),batch:room.batches,type})}
function onFallback(room,view,url,item,t){room.notFound++
if(room.batch!==null)room.batch.bad++
const asked=room.pending.get(view)??null
if(asked===null)room.orphan++
else room.pending.delete(view)
const ours=ourRequests()
const facts=shellFacts(room.win,item)
if(room.cases.length>=CASE_CAP)room.cases.shift()
room.cases.push({at:t,url:asked?.url??null,askedAt:asked?.at??null,
oursDuring:asked!==null&&asked.ours!==null&&ours!==null?ours-asked.ours:null,ours,
screen:room.screen,screenAt:room.screenAt,from:room.transitions.length>0?room.transitions[room.transitions.length-1].from:null,
grid:inGrid(view),facts,batch:room.batches})
if(asked!==null)cureStub(room,view,item,asked,facts,t)}
function cureOn(room){try{return room.cure.isActive(CARD_GRID_FEATURE)===true}catch{return false}}
function codeFor(room,url,since){const slot=room.resources.get(url)
if(!slot)return null
const entry=slot.find((one)=>one.start>=since-50)??null
return entry===null?null:entry.status}
function gone(code){return Number.isFinite(code)&&code>=400&&code<500}
function liveViews(rec){const out=[]
for(const[view,info]of rec.views){if(shellSlot(view,info.type)===info.slot)out.push([view,info])
else rec.views.delete(view)}
return out}
function shown(view){try{return view?.getRootElement?.()?.isConnected!==false}catch{return false}}
function ownAsk(room,view,url,type,item,onFail){room.own=true
try{return askShell(view,url,type,item,onFail)}finally{room.own=false}}
function recOf(room,url){let rec=room.cure.recs.get(url)
if(rec===undefined){if(room.cure.recs.size>=CURE_URL_CAP)return null
rec={url,state:'fresh',why:null,retries:0,failAt:0,views:new Map()}
room.cure.recs.set(url,rec)}
return rec}
function cureStub(room,view,item,asked,facts,t){if(!cureOn(room))return
const rec=recOf(room,asked.url)
if(rec===null)return
if(rec.views.size<CURE_VIEW_CAP){rec.views.set(view,{slot:shellSlot(view,asked.type),item,type:asked.type,at:t,stub:false,looked:false})
room.cure.viewRec.set(view,rec)}
if(rec.state==='dead')return
if(rec.state==='waiting'||rec.state==='retrying'||rec.state==='capped')return
if(facts.known===false){markDead(room,rec,'редкость незнакома')
return}
const code=codeFor(room,rec.url,asked.at)
if(gone(code)){markDead(room,rec,'код '+code)
return}
rec.state='waiting'
rec.failAt=t
rec.askedAt=asked.at
room.cure.timer(()=>{try{decide(room,rec)}catch{/* тишина */}},RETRY_DELAY_MS)}
function decide(room,rec){if(rec.state!=='waiting')return
const code=codeFor(room,rec.url,rec.askedAt??0)
if(gone(code)){markDead(room,rec,'код '+code)
return}
const live=liveViews(rec).filter(([view])=>shown(view))
if(live.length===0){rec.state='fresh'
return}
if(room.cure.retries>=RETRY_CAP){rec.state='capped'
room.cure.capped++
return}
room.cure.retries++
if(rec.retries===0)room.cure.retryUrls++
rec.retries++
rec.state='retrying'
const[view,info]=live[0]
const asked=ownAsk(room,view,rec.url,info.type,info.item,()=>{if(rec.state==='retrying')markDead(room,rec,'повтор не помог')})
if(!asked){markDead(room,rec,'повтор не ушёл')
return}
room.cure.timer(()=>{if(rec.state==='retrying')rec.state='fresh'},RETRY_SETTLE_MS)}
function onStubLoaded(room,view){const rec=room.cure.viewRec.get(view)
if(rec===undefined)return
const info=rec.views.get(view)
if(info===undefined)return
if(shellSlot(view,info.type)!==info.slot)return
info.stub=true
if(rec.state==='dead')countDead(room,info)
else if(rec.state==='alive'){rec.views.delete(view)
ownAsk(room,view,rec.url,info.type,info.item,()=>{})}}
function onLoaded(room,view,url){const rec=room.cure.recs.get(url)
if(rec===undefined)return
if(rec.state==='alive'&&rec.views.size===0)return
const byRetry=rec.state==='retrying'
if(rec.state==='dead')room.cure.deadUrls=Math.max(0,room.cure.deadUrls-1)
rec.state='alive'
rec.why=null
const t=nowOf(room.win)
const list=liveViews(rec)
rec.views.clear()
for(const[one,info]of list){// Заглушка ещё едет: шаблон вернёт `onStubLoaded`, иначе она перебьёт его.
if(!info.stub&&one!==view){rec.views.set(one,info)
continue}
if(t-info.at>LATE_MS)room.cure.late++
if(byRetry)room.cure.healedRetry++
else room.cure.healedMemory++
if(one===view)continue
ownAsk(room,one,url,info.type,info.item,()=>{})}}
function markDead(room,rec,why){if(rec.state!=='dead')room.cure.deadUrls++
rec.state='dead'
rec.why=why
for(const[,info]of liveViews(rec)){if(info.stub)countDead(room,info)}}
function countDead(room,info){if(!info||info.looked)return
info.looked=true
room.cure.deadViews++}
function onEntries(room,list){for(const e of list){const name=e?.name
if(typeof name!=='string')continue
if(name.indexOf('cards_bg_e_')>=0){let slot=room.resources.get(name)
if(slot===undefined){if(room.resources.size>=RESOURCE_CAP)continue
slot=[]
room.resources.set(name,slot)}
if(slot.length>=3)slot.shift()
slot.push(entryOf(e))}
else if(name.indexOf('raritytunables')>=0){if(room.rarityFile.length>=5)room.rarityFile.shift()
room.rarityFile.push(entryOf(e))}}
if(room.batch!==null&&room.batch.grid===null)room.batch.grid=inGrid(room.batch.first)}
function entryOf(e){return{start:Number(e.startTime)||0,dur:Math.round(Number(e.duration)||0),
status:Number.isFinite(e.responseStatus)?e.responseStatus:null,
bytes:Number.isFinite(e.encodedBodySize)?e.encodedBodySize:null,
wire:Number.isFinite(e.transferSize)?e.transferSize:null,
cache:typeof e.deliveryType==='string'?e.deliveryType:null}}
function startObserver(room){const Ctor=room.win?.PerformanceObserver
if(typeof Ctor!=='function'){room.observerWhy='no-observer'
return}
try{const obs=new Ctor((batch)=>{try{onEntries(room,batch.getEntries())}catch{/* молчит */}})
obs.observe({type:'resource',buffered:true})
room.observer=obs}catch{room.observerWhy='observe-failed'}}
function answerFor(room,c){if(c.url===null)return{says:'адрес не пойман',entry:null}
const slot=room.resources.get(c.url)
if(!slot||slot.length===0)return{says:'записи нет (ответа не было)',entry:null}
const from=(c.askedAt??0)-50
const entry=slot.find((one)=>one.start>=from)??null
if(entry===null)return{says:'записи этого заказа нет (ответа не было)',entry:null}
const code=entry.status===null||entry.status===0?'код 0':'код '+entry.status
return{says:code+' за '+entry.dur+' мс, '+(entry.bytes??'?')+' Б',entry}}
function minutes(ms){return Math.round(ms/6000)/10}
function sec(ms){return Math.round(ms/100)/10}
function cureCounts(room){const c=room.cure
const t=nowOf(room.win)
let lateNow=0
let lateDead=0
const dead=[]
for(const rec of c.recs.values()){for(const info of rec.views.values()){if(t-info.at>LATE_MS){lateNow++
if(rec.state==='dead')lateDead++}}
if(rec.state==='dead')dead.push(shellLabel(rec.url)+' ('+rec.why+')')}
return{on:cureOn(room),stubs:room.notFound,healedRetry:c.healedRetry,healedMemory:c.healedMemory,
deadUrls:c.deadUrls,deadViews:c.deadViews,late:c.late+lateNow,lateNotDead:c.late+lateNow-lateDead,
retries:c.retries,retryUrls:c.retryUrls,cap:RETRY_CAP,capped:c.capped,dead:dead.slice(0,12)}}
function report(room){closeBatch(room)
const t=nowOf(room.win)
const statuses={}
for(const slot of room.resources.values()){for(const one of slot){const k=one.status===null?'нет':String(one.status)
statuses[k]=(statuses[k]??0)+1}}
const cases=room.cases.map((c,i)=>{const a=answerFor(room,c)
const f=c.facts
return{n:i+1,min:minutes(c.at),shell:shellLabel(c.url),server:a.says,
waitedMs:c.askedAt===null?null:Math.round(c.at-c.askedAt),
screen:c.screen,from:c.from,onScreenS:sec(c.at-c.screenAt),grid:c.grid,
rarity:f.rareflag,tier:f.tier,concept:f.concept,rarityKnown:f.known,rarities:f.count,
oursDuring:c.oursDuring,ours:c.ours}})
const pct=(bad,all)=>all>0?Math.round(bad*1000/all)/10:null
const perScreens={all:pct(room.closed.bad.grid+room.closed.bad.bare+room.closed.bad.unknown,room.batches),
grid:pct(room.closed.bad.grid,room.closed.grid),bare:pct(room.closed.bad.bare,room.closed.bare)}
const cure=cureCounts(room)
const lines=[]
lines.push(NOTFOUND_BUILD+' · EA '+(eaBuild(room.doc)??'?')+' · '+minutes(t-room.startedAt)+' мин · прибор '+(room.capture.ok?'встал':'НЕ встал: '+room.capture.reason))
lines.push('карт '+room.cards+' · NOT FOUND '+room.notFound+(room.orphan>0?' (без адреса '+room.orphan+')':'')+' · пачек '+room.batches+' (сетка '+room.closed.grid+', без '+room.closed.bare+', ? '+room.closed.unknown+')')
lines.push('пачек с бедой: сетка '+room.closed.bad.grid+', без '+room.closed.bad.bare+', ? '+room.closed.bad.unknown+' · на 100 пачек '+(perScreens.all??'-'))
lines.push('шаблонов с guid '+room.cdn+', без guid '+room.cdnLarge+', своих '+room.local+' · ответы сервера '+Object.entries(statuses).map(([k,v])=>k+'×'+v).join(' ')+(room.observer===null?' (записей нет: '+(room.observerWhy??'?')+')':''))
lines.push('файл редкостей: '+(room.rarityFile.length===0?'записи нет':room.rarityFile.map((e)=>'код '+(e.status??'?')+' '+e.dur+' мс').join(', ')))
lines.push('лечение '+(cure.on?'вкл':'выкл')+' · заглушек '+cure.stubs+' · вылечено повтором '+cure.healedRetry+', из памяти '+cure.healedMemory+' · не завезли: адресов '+cure.deadUrls+', карт '+cure.deadViews+' · дольше 3 с '+cure.late+' (без «не завезли» '+cure.lateNotDead+') · повторов '+cure.retries+' из '+cure.cap+(cure.capped>0?', упёрлись '+cure.capped:''))
if(cure.dead.length>0)lines.push('не завезли: '+cure.dead.join(', '))
for(const c of cases){lines.push('#'+c.n+' '+c.min+' мин · '+(c.shell??'?')+' · '+c.server+' · ждала '+(c.waitedMs??'?')+' мс · экран '+(c.screen??'?')+' после '+(c.from??'?')+' ('+c.onScreenS+' с) · сетка '+(c.grid===null?'?':c.grid?'да':'нет')+' · редкость '+(c.rarity??'?')+'/'+(c.tier??'?')+(c.rarityKnown===false?' НЕ ЗНАЕТ':'')+' из '+(c.rarities??'?')+' · наших запросов в ожидании '+(c.oursDuring??'?'))}
return{build:NOTFOUND_BUILD,ea:eaBuild(room.doc),minutes:minutes(t-room.startedAt),watching:room.capture.ok,
cards:room.cards,notFound:room.notFound,orphan:room.orphan,batches:room.batches,
batchesByGrid:{grid:room.closed.grid,bare:room.closed.bare,unknown:room.closed.unknown},
badBatches:{...room.closed.bad},per100:perScreens,cdnStatuses:statuses,
shells:{cdn:room.cdn,cdnLarge:room.cdnLarge,local:room.local},
transitions:room.transitions.map((one)=>({min:minutes(one.at),from:one.from,to:one.to})),
cure,cases,text:lines.join('\n')}}
export function ensureNotFoundWatch(win,doc=win?.document,deps={}){if(!win)return{ok:false,reason:'no-window'}
let room=rooms.get(win)
if(room===undefined){room=createRoom(win,doc,deps??{})
rooms.set(win,room)
startObserver(room)
const own=room
try{const box=win.__eshario
if(box&&typeof box==='object'&&typeof box.notfound!=='function')box.notfound=()=>report(own)}catch{/* ручки не будет, прибор всё равно считает */}}
if(!room.capture.ok){const own=room
room.capture=installShellWatch(win,(view,url,kind,item,type)=>onShell(own,view,url,kind,item,type))}
return{ok:room.capture.ok,reason:room.capture.reason}}
export function notFoundReport(win){const room=rooms.get(win)
return room===undefined?null:report(room)}
