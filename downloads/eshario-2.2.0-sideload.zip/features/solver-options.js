export const SOLVER_DEFAULTS=Object.freeze({keepActiveSquad:true,adviseBuy:true})
export const SOLVER_FIELDS=Object.freeze(Object.keys(SOLVER_DEFAULTS))
export function sanitizeSolverOptions(stored){const out={...SOLVER_DEFAULTS}
if(!stored||typeof stored!=='object'||Array.isArray(stored))return out
for(const field of SOLVER_FIELDS){if(typeof stored[field]==='boolean')out[field]=stored[field]}
return out}
