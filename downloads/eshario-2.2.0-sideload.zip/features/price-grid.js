export const AUCTION_MAX_BID=15_000_000
export const MIN_PRICE=150
export const PRICE_TIERS=Object.freeze([Object.freeze({min:100_000,inc:1000}),Object.freeze({min:50_000,inc:500}),Object.freeze({min:10_000,inc:250}),Object.freeze({min:1000,inc:100}),Object.freeze({min:150,inc:50}),Object.freeze({min:0,inc:150})])
export function tierForStepUp(price){return PRICE_TIERS.find((tier)=>price>=tier.min)??PRICE_TIERS.at(-1)}
export function tierForStepDown(price){return PRICE_TIERS.find((tier)=>price>tier.min)??PRICE_TIERS.at(-1)}
export function nextPrice(price){const value=toNumber(price)
if(value>=AUCTION_MAX_BID)return AUCTION_MAX_BID
const{inc}=tierForStepUp(value)
if(!(value+inc<AUCTION_MAX_BID))return AUCTION_MAX_BID
return Math.round((value+inc) / inc) * inc;
}
export function prevPrice(price){const value=toNumber(price);
if(value<=0)return 0;
const{inc}=tierForStepDown(value);
if(!(0<value-inc))return 0;
return Math.round((value-inc) / inc) * inc;
}
export function isValidPrice(price){
if(typeof price!=='number'||!Number.isInteger(price)) return false;
const value=price;
if(value<MIN_PRICE||value>AUCTION_MAX_BID)return false;
return value%tierForStepUp(value).inc===0}
export function floorToValidPrice(price){const value=toNumber(price);
if(value<MIN_PRICE)return MIN_PRICE;
if(value>=AUCTION_MAX_BID)return AUCTION_MAX_BID;
const{inc}=tierForStepUp(value);
const floored=Math.floor(value / inc) * inc;
return floored<MIN_PRICE?MIN_PRICE:floored}
export function midpointPrice(low,high){const from=floorToValidPrice(low);
const to=floorToValidPrice(high);
if(to<=from)return null;
const mid=floorToValidPrice(from+(to-from) / 2);
if(mid<=from||mid>=to)return null;
return mid}
function toNumber(value){const num=Number(value);
return Number.isFinite(num)?num:0}
