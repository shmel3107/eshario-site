import{el,ensureTheme,ensureStylesheet,logoMark} from '../ui/dom.js'
import{modalBox} from '../ui/window.js'
import{SNIPE_FEATURE} from './snipe-shared.js'
const RATING_STYLESHEET=new URL('../ui/market-rating.css',import.meta.url).href
const RATING_LINK_ID='fut-companion-market-rating'
export const RATING_DOOR_MARK='futMarketRatingDoor'
export const RATING_DOOR_SELECTOR='[data-fut-market-rating-door]'
export const RATING_WINDOW_MARK='futMarketRatingWindow'
export const RATING_WINDOW_SELECTOR='[data-fut-market-rating-window]'
export const RATING_ROW_MARK='futMarketRatingRow'
export const RATING_CARD_MARK='futMarketRatingCard'
export const RATING_NOW_MARK='futMarketRatingNow'
export const RATING_NOW_SELECTOR='[data-fut-market-rating-now]'
export const TABS_ROW='.ea-filter-bar-view'
export const TABS_BOX='.menu-container'
export const NATIVE_TAB_CLASS='ea-filter-bar-item-view'
export const RATING_MIN=82
export const RATING_MAX=92
export const CARDS_PER_ROW=5
export function ratingRows(ladder,opts={}){const min=whole(opts.min)??RATING_MIN
const max=whole(opts.max)??RATING_MAX
const many=whole(opts.cards)??CARDS_PER_ROW
const out=[]
for(const step of Array.isArray(ladder)?ladder:[]){const rating=whole(step?.rating)
if(rating===null||rating<min||rating>max)continue
const kept=[]
for(const one of Array.isArray(step?.picks)?step.picks:[]){const id=whole(one?.id)
const price=whole(one?.price)
if(id===null||price===null)continue
kept.push({id,price})}
if(kept.length===0)continue
kept.sort((a,b)=>a.price-b.price)
const cards=kept.slice(0,many)
out.push({rating,from:cards[0].price,cards})}
out.sort((a,b)=>a.rating-b.rating)
return out}
function whole(value){const n=Number(value)
return Number.isSafeInteger(n)&&n>0?n:null}
export function bookTimeWords(builtAt){const at=Number(builtAt)
if(!Number.isFinite(at)||at<=0)return null
let hours=null
let minutes=null
try{const said=new Date(at)
hours=said.getHours()
minutes=said.getMinutes()}catch{return null}
if(!Number.isFinite(hours)||!Number.isFinite(minutes))return null
return `${String(hours).padStart(2,'0')}:${String(minutes).padStart(2,'0')}`}
export function createRatingSearch(deps={}){const{doc}=deps
const t=typeof deps.t==='function'?deps.t:(key)=>key
const num=typeof deps.formatNumber==='function'?deps.formatNumber:(value)=>String(value)
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const isActive=typeof deps.isActive==='function'?deps.isActive:null
const doorOpen=deps.doorOpen===true
const allowed=()=>{if(isActive===null)return true
try{return isActive(SNIPE_FEATURE)===true}catch(err){onError(err)
return false}}
const readBook=typeof deps.book==='function'?deps.book:null
const playerOf=typeof deps.playerOf==='function'?deps.playerOf:null
const pick=typeof deps.pick==='function'?deps.pick:null
const readSearchNow=typeof deps.searchNow==='function'?deps.searchNow:null
const searchNow=()=>{if(readSearchNow===null)return true
try{return readSearchNow()!==false}catch(err){onError(err)
return true}}
const writeSearchNow=typeof deps.setSearchNow==='function'?deps.setSearchNow:null
let door=null
let host=null
let notice=''
let printed=null
let passes=0,mounts=0,opens=0,closes=0,picks=0,searches=0,refusals=0,strays=0,switches=0
function bookNow(){if(readBook===null)return{rows:[],at:null,has:false}
let said=null
try{said=readBook()}catch(err){onError(err)
return{rows:[],at:null,has:false}}
if(said===null||said===undefined)return{rows:[],at:null,has:false}
return{rows:ratingRows(said.ladder),at:bookTimeWords(said.builtAt),has:true}}
function nameOf(definitionId){if(playerOf===null)return null
let said=null
try{said=playerOf(definitionId)}catch(err){onError(err)
return null}
const name=typeof said?.name==='string'?said.name.trim():''
return name===''?null:name}
function cardButton(rating,card,now){const name=nameOf(card.id)
return el(doc,'button',{class:'fx-mrat-card',
attrs:{type:'button',title:t(now?'marketRating.cardHint':'marketRating.cardHintOnly',{coins:num(card.price)})},
dataset:{[RATING_CARD_MARK]:String(card.id)},
on:{click:(event)=>{event?.preventDefault?.()
choose(card)}}},
[el(doc,'span',{class:'fx-mrat-card-name',text:name===null?t('marketRating.cardBlind',{id:num(card.id)}):name}),
el(doc,'span',{class:'fx-mrat-card-coins',text:num(card.price)})])}
function ratingRow(row,now){return el(doc,'div',{class:'fx-mrat-row',
dataset:{[RATING_ROW_MARK]:String(row.rating)}},
[el(doc,'span',{class:'fx-mrat-rating',text:num(row.rating)}),
el(doc,'span',{class:'fx-mrat-from',text:t('marketRating.from',{coins:num(row.from)})}),
el(doc,'div',{class:'fx-mrat-cards'},row.cards.map((one)=>cardButton(row.rating,one,now)))])}
function windowBody(said,now){if(!said.has||said.rows.length===0){
return[el(doc,'p',{class:'fx-mrat-empty',dataset:{futMarketRatingEmpty:'1'},
text:t('marketRating.noBook')})]}
return[el(doc,'div',{class:'fx-mrat-list'},said.rows.map((row)=>ratingRow(row,now)))]}
function searchNowToggle(now){if(writeSearchNow===null)return null
return el(doc,'button',{class:now?'fx-mrat-now fx-mrat-now-on':'fx-mrat-now',
attrs:{type:'button','aria-pressed':now?'true':'false',title:t('marketRating.nowHint')},
dataset:{[RATING_NOW_MARK]:now?'on':'off'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
switches+=1
let said=null
try{said=writeSearchNow(!now)}catch(err){onError(err)
said=null}
notice=said?.ok===false
?(said?.notice?.key?t(said.notice.key,said.notice.params??{}):t('marketRating.nowRefused'))
:''
repaintWindow()}}},
[el(doc,'i',{class:'fx-mrat-now-knob'}),
el(doc,'span',{class:'fx-mrat-now-text',text:t('marketRating.now')})])}
function buildWindow(){const said=bookNow()
const now=searchNow()
return modalBox(doc,{mark:RATING_WINDOW_MARK,box:'fx-hk-capture-box fx-mrat-box',
title:t('marketRating.title'),closeLabel:t('common.close'),
tools:[searchNowToggle(now)].filter(Boolean),onBack:closeWindow},
[
el(doc,'p',{class:'fx-mrat-basics',dataset:{futMarketRatingBasics:'1'},
text:t('marketRating.basics')}),
el(doc,'p',{class:'fx-mrat-when',dataset:{futMarketRatingWhen:'1'},
text:said.at===null?t('marketRating.whenNone'):t('marketRating.when',{at:said.at})}),
el(doc,'p',{class:'fx-mrat-warn',dataset:{futMarketRatingWarn:now?'1':'only'},
text:t(now?'marketRating.replaces':'marketRating.replacesOnly')}),
...windowBody(said,now),
notice===''?null:el(doc,'div',{class:'fx-mrat-notice',
dataset:{futMarketRatingNotice:'1'},text:notice})].filter(Boolean))}
function openWindow(){if(!doc)return false
if(host!==null)return true
notice=''
host=buildWindow()
;(doc.body??doc.documentElement)?.appendChild?.(host)
opens+=1
return true}
function closeWindow(){if(host===null)return false
try{host.remove()}catch(err){onError(err)}
host=null
notice=''
closes+=1
return true}
function repaintWindow(){if(host===null)return false
const next=buildWindow()
const home=host.parentNode??null
if(home!==null&&home!==undefined){home.insertBefore(next,host)
host.remove?.()}
else host.remove?.()
host=next
return true}
function choose(card){if(pick===null){notice=t('marketRating.noDoor')
repaintWindow()
refusals+=1
return false}
const now=searchNow()
let said=null
try{said=pick(card.id,card.price,{search:now})}catch(err){onError(err)
said=null}
if(said?.ok!==true){notice=said?.reason===undefined||said?.reason===null||said.reason===''
?t('marketRating.refused')
:t('marketRating.refusedWhy',{why:String(said.reason)})
repaintWindow()
refusals+=1
return false}
picks+=1
if(said.searched===true)searches+=1
closeWindow()
return true}
function mountDoor(root){let box=null
try{box=root.querySelector?.(`${TABS_ROW} > ${TABS_BOX}`)??root.querySelector?.(TABS_ROW)??null}catch(err){onError(err)
box=null}
if(box===null||box===undefined)return null
if(door===null||door.parentNode!==box){door=el(doc,'button',
{class:`${NATIVE_TAB_CLASS} fx-mrat-tab`,
attrs:{type:'button',title:t('marketRating.doorHint')},
dataset:{[RATING_DOOR_MARK]:'1'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
openWindow()}}},
[el(doc,'span',{class:'fx-mrat-door-text'},
[logoMark(doc),el(doc,'span',{class:'fx-mrat-word',text:t('marketRating.door')})])])
mounts+=1}
const kids=Array.from(box.children??[]).filter((one)=>one!==door)
const anchor=kids.length>1?kids[1]:null
if(anchor===null){if(door.parentNode!==box)box.appendChild(door)}
else if(door.nextSibling!==anchor||door.parentNode!==box)box.insertBefore(door,anchor)
sweep()
return door}
function sweep(){let gone=0
for(const node of Array.from(doc?.querySelectorAll?.(RATING_DOOR_SELECTOR)??[])){if(node===door)continue
try{node.remove()
gone+=1}catch{
}}
strays+=gone
return gone}
function paintDoor(){if(door===null)return false
const mark=t('marketRating.door')
if(printed===mark)return false
printed=mark
const label=door.querySelector?.('.fx-mrat-word')??null
if(label!==null&&label.textContent!==mark)label.textContent=mark
door.setAttribute('title',t('marketRating.doorHint'))
return true}
function clearAll(){let gone=0
for(const node of Array.from(doc?.querySelectorAll?.(RATING_DOOR_SELECTOR)??[])){try{node.remove()
gone+=1}catch{
}}
if(closeWindow())gone+=1
door=null
printed=null
return gone}
function refresh(root){if(!doc)return false
passes+=1
if(!doorOpen){clearAll()
return false}
if(!allowed()||root===null||root===undefined){clearAll()
return false}
ensureTheme(doc)
ensureStylesheet(doc,RATING_STYLESHEET,RATING_LINK_ID)
if(mountDoor(root)===null){
clearAll()
return false}
paintDoor()
return true}
function relabel(){printed=null
paintDoor()
if(host!==null)repaintWindow()
return true}
return{refresh,relabel,clearAll,
open:openWindow,close:closeWindow,
state(){const said=bookNow()
return{door:doc?.querySelectorAll?.(RATING_DOOR_SELECTOR)?.length??0,
window:doc?.querySelectorAll?.(RATING_WINDOW_SELECTOR)?.length??0,
rows:said.rows.length,
ratings:said.rows.map((one)=>one.rating).join(' · '),
cards:said.rows.reduce((sum,one)=>sum+one.cards.length,0),
book:said.has,
bookAt:said.at,
searchNow:searchNow(),
notice,
strays,
work:{passes,mounts,opens,closes,picks,searches,refusals,strays,switches}}},
dispose(){clearAll()}}}
