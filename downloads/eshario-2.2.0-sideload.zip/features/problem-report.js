import { sanitizeSyncNamespaces } from '../sync/settings-schema.js';
export const REPORT_SCHEMA = 1;
export const REPORT_MAX_BYTES = 24 * 1024;
export const REPORT_WORDS_MAX = 2000;
export const REPORT_CONTACT_MAX = 64;
export const SUPPORT_URL = 'https://t.me/eshaboost';
export const REPORT_BANS = Object.freeze(['email', 'license', 'token', 'secret-field']);
const SECRET_FIELDS = Object.freeze([
'account.session', 'session', 'sessiontoken', 'password', 'email', 'hint',
'entitlement', 'license.key', 'licensekey', 'accountid', 'account', 'token',
]);
const EMAIL_RE = /[^\s"'<>()@]*@[^\s"'<>()@]+\.[^\s"'<>()@]+/g;
const LICENSE_RE = /\bfutc\d+\.[A-Za-z0-9_.-]+/g;
const TOKEN_RE = /[A-Za-z0-9_-]{32,}/g;
export function scrubText(value, max = 4000) {
return String(value ?? '')
.slice(0, max)
.replace(EMAIL_RE, '[email]')
.replace(LICENSE_RE, '[key]')
.replace(TOKEN_RE, '[key]')
.replace(/@/g, ' ');
}
export function scrubValue(value, depth = 0) {
if (depth > 12) return null;
if (typeof value === 'string') return scrubText(value);
if (typeof value === 'number') return Number.isFinite(value) ? value : null;
if (typeof value === 'boolean' || value === null) return value;
if (Array.isArray(value)) return value.slice(0, 500).map((one) => scrubValue(one, depth + 1));
if (typeof value !== 'object') return null;
const out = {};
for (const [key, raw] of Object.entries(value)) {
if (SECRET_FIELDS.includes(String(key).toLowerCase())) continue;
out[scrubText(key, 120)] = scrubValue(raw, depth + 1);
}
return out;
}
export function reportBans(text) {
const found = [];
const body = String(text ?? '');
if (/@/.test(body)) found.push('email');
if (/\bfutc\d+\./.test(body)) found.push('license');
if (/[A-Za-z0-9_-]{32,}/.test(body)) found.push('token');
const keys = SECRET_FIELDS.map((name) => name.replace(/\./g, '\\.')).join('|');
if (new RegExp(`"(?:${keys})"\\s*:`, 'i').test(body)) found.push('secret-field');
return found;
}
export function cleanContact(value) {
const raw = String(value ?? '').trim().slice(0, REPORT_CONTACT_MAX * 2);
const handle = /^(?:https?:\/\/)?(?:t\.me\/|@)?([A-Za-z0-9_]{3,32})$/.exec(raw)?.[1];
if (handle) return `t.me/${handle}`;
return scrubText(raw, REPORT_CONTACT_MAX).trim();
}
export function cleanWords(value) {
return scrubText(String(value ?? '').trim(), REPORT_WORDS_MAX).trim();
}
const bytes = (value) => new TextEncoder().encode(JSON.stringify(value)).length;
const tail = (list, n) => (Array.isArray(list) ? list.slice(-n) : []);
function browserOf(ua) {
const text = String(ua ?? '');
const edge = /Edg\/(\d+)/.exec(text);
const chrome = /Chrome\/(\d+)/.exec(text);
const name = edge ? 'Edge' : (chrome ? 'Chrome' : 'other');
const version = (edge ?? chrome)?.[1] ?? null;
const system = /Windows NT 10/.test(text) ? 'Windows 10/11'
: /Windows/.test(text) ? 'Windows'
: /CrOS/.test(text) ? 'ChromeOS'
: /Mac OS X/.test(text) ? 'macOS'
: /Linux/.test(text) ? 'Linux' : 'other';
return { name, version, system };
}
function planOf(license, now) {
const exp = Number.isFinite(license?.exp) ? license.exp : null;
const unlocked = license?.unlocked === true;
return {
signedIn: license?.authenticated === true,
tier: unlocked ? 'premium' : 'free',
daysLeft: unlocked && exp !== null && Number.isFinite(now) ? Math.max(0, Math.ceil((exp - now) / 86_400_000)) : null,
};
}
export function collectProblemReport(source = {}) {
const now = Number.isFinite(source.now) ? source.now : Date.now();
const browser = browserOf(source.userAgent);
const evidence = source.evidence && typeof source.evidence === 'object' ? source.evidence : null;
const events = [
...tail(evidence?.events, 20).map((one) => ({ at: one?.at ?? null, kind: one?.kind ?? null, ok: one?.ok ?? null, reason: one?.reason ?? null })),
...tail(source.journal?.entries, 20).map((one) => ({ at: one?.at ?? null, kind: `${one?.source ?? ''}.${one?.event ?? ''}`, ok: null, reason: null })),
];
const draft = {
schema: REPORT_SCHEMA,
at: now,
version: source.version ?? null,
browser: { name: browser.name, version: browser.version, ua: source.userAgent ?? null },
system: browser.system,
window: {
width: source.window?.width ?? null,
height: source.window?.height ?? null,
dpr: source.window?.dpr ?? null,
},
language: { extension: source.locale ?? null, browser: tail(source.languages, 3) },
screen: { ea: source.screen ?? null, ours: evidence?.page ?? null },
errors: tail(source.errors, 20).map((one) => String(one ?? '')),
events,
settings: source.settings && typeof source.settings === 'object' ? sanitizeSyncNamespaces(source.settings) : null,
plan: planOf(source.license, now),
};
let report = scrubValue(draft);
if (bytes(report) > REPORT_MAX_BYTES && report.settings && Array.isArray(report.settings.filters)) {
report = { ...report, settings: { ...report.settings, filters: `[${report.settings.filters.length} sets omitted]` } };
}
if (bytes(report) > REPORT_MAX_BYTES) report = { ...report, settings: 'omitted: too big' };
if (bytes(report) > REPORT_MAX_BYTES) report = { ...report, events: report.events.slice(-5), errors: report.errors.slice(-5) };
if (bytes(report) > REPORT_MAX_BYTES) report = { ...report, screen: { ea: report.screen?.ea ?? null, ours: null } };
return report;
}
export function reportText(report, extra = {}) {
const words = cleanWords(extra.words);
const contact = cleanContact(extra.contact);
const plan = report?.plan ?? {};
const lines = [
'ESHArio: problem report',
`version: ${report?.version ?? '?'}`,
`browser: ${report?.browser?.name ?? '?'} ${report?.browser?.version ?? ''} · ${report?.system ?? '?'}`,
`window: ${report?.window?.width ?? '?'}x${report?.window?.height ?? '?'} dpr ${report?.window?.dpr ?? '?'}`,
`language: ${report?.language?.extension ?? '?'} (browser ${(report?.language?.browser ?? []).join(', ')})`,
`screen: ${report?.screen?.ea ?? '?'}`,
`plan: ${plan.tier ?? '?'}${plan.daysLeft === null || plan.daysLeft === undefined ? '' : `, days ${plan.daysLeft}`}${plan.signedIn ? ', signed in' : ''}`,
`words: ${words === '' ? '(empty)' : words}`,
...(contact === '' ? [] : [`telegram: ${contact}`]),
`errors: ${(report?.errors ?? []).length}`,
'',
JSON.stringify(report),
];
const text = lines.join('\n');
const bans = reportBans(text);
return bans.length === 0 ? { ok: true, text } : { ok: false, bans };
}
export const REPORT_PORT_REASONS = Object.freeze(['cancel', 'no-dialog']);
export const REPORT_METHOD = 'report.send';
const SEND_WORDS = Object.freeze({
offline: 'report.offline',
'too-many': 'report.tooMany',
'too-big': 'report.tooBig',
'no-port': 'report.noPort',
server: 'report.server',
});
export function createProblemReport(deps = {}) {
const onError = typeof deps.onError === 'function' ? deps.onError : () => {};
const build = (input) => {
const report = collectProblemReport(deps.source?.() ?? {});
return { report, said: reportText(report, { words: input.text, contact: input.contact }) };
};
async function copy(input) {
const { said } = build(input);
if (!said.ok) {
onError(`report: сторож не пустил отчёт (${said.bans.join(', ')})`);
return { key: 'report.copyFailed' };
}
try {
await deps.clipboard.writeText(said.text);
return { key: 'report.copied', ok: true };
} catch {
return { key: 'report.copyFailed' };
}
}
const openUrl = typeof deps.openUrl === 'function'
? deps.openUrl
: (url) => { deps.openTab.open(url, '_blank', 'noopener,noreferrer'); };
function support() {
try {
openUrl(SUPPORT_URL);
return { key: 'report.opened', ok: true };
} catch {
return { key: 'report.server' };
}
}
async function send(input) {
const { report, said } = build(input);
if (!said.ok) {
onError(`report: сторож не пустил отчёт (${said.bans.join(', ')})`);
return { key: 'report.server' };
}
if (!deps.bridge || typeof deps.bridge.request !== 'function') return { key: 'report.noPort' };
let answer;
try {
answer = await deps.bridge.request(REPORT_METHOD, {
report, words: cleanWords(input.text), contact: deps.signedIn?.() ? '' : cleanContact(input.contact),
}, { timeoutMs: 20_000 });
} catch {
return { key: 'report.noPort' };
}
if (answer?.ok === true && Number.isSafeInteger(answer.number)) {
return { key: 'report.sent', params: { number: answer.number }, lock: true, ok: true };
}
return { key: SEND_WORDS[answer?.reason] ?? 'report.server' };
}
return {
async open() {
if (!deps.dialogs || typeof deps.dialogs.report !== 'function') return { ok: false, reason: 'no-dialog' };
const closed = await deps.dialogs.report({
titleKey: 'report.title',
messageKey: 'report.lead',
placeholderKey: 'report.placeholder',
contactKey: deps.signedIn?.() ? null : 'report.contact',
actions: [
{ id: 'copy', labelKey: 'report.copy' },
{ id: 'support', labelKey: 'report.support' },
{ id: 'send', labelKey: 'report.send', kind: 'primary' },
],
onAction: (id, input) => (id === 'copy' ? copy(input) : id === 'support' ? support() : send(input)),
});
return closed?.done?.length > 0 ? { ok: true } : { ok: false, reason: 'cancel' };
},
};
}
