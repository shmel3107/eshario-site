import{nextPrice,prevPrice,floorToValidPrice,isValidPrice,AUCTION_MAX_BID,MIN_PRICE} from './price-grid.js'
export const MIN_STARTING_BID=150
export const MIN_BUY_NOW=200
export const LIST_DURATIONS=Object.freeze([3600,10800,21600,43200,86400,259200])
export const DEFAULT_DURATION=3600
export const LIST_FEATURE='autoSeller'
export function readPriceLimits(limits){if(!limits||typeof limits!=='object')return null
const minimum=Number(limits.minimum)
const maximum=Number(limits.maximum)
if(!Number.isSafeInteger(minimum)||!Number.isSafeInteger(maximum))return null
if(minimum<1||maximum<minimum)return null
return{minimum,maximum}}
export function smartListPrice(input={}){const raw=Number(input.reference)
if(!Number.isFinite(raw)||raw<=0)return{ok:false,reason:'no-reference'}
const band=readPriceLimits(input.limits)
const banded=band!==null
const bounds=listingBounds(input.limits,input.eaSaysNone===true)
const want=bounds.banded!==false?prevPrice(floorToValidPrice(Math.min(raw,bounds.buyMax))):raw
const price=pricePair(want,bounds)
if(price.ok!==true)return price
const cutByCeiling=bounds.banded!==false&&Number.isSafeInteger(bounds.buyMax)&&raw>bounds.buyMax
return{ok:true,startingBid:price.startingBid,buyNow:price.buyNow,
clamped:price.clamped??(cutByCeiling?'max':null),reference:Math.round(raw),banded}}
function ceilToValidPrice(price){const value=Number(price)
const floored=floorToValidPrice(Number.isFinite(value)?value:MIN_PRICE)
return floored>=value?floored:nextPrice(floored)}
export function listingBounds(limits,eaSaysNone=false){const band=readPriceLimits(limits)
if(!band&&eaSaysNone===true)return{bidMin:MIN_STARTING_BID,bidMax:floorToValidPrice(prevPrice(AUCTION_MAX_BID)),buyMin:MIN_BUY_NOW,buyMax:AUCTION_MAX_BID,banded:'ea-none'}
if(!band)return{bidMin:null,bidMax:null,buyMin:null,buyMax:null,banded:false}
const buyMax=floorToValidPrice(Math.min(band.maximum,AUCTION_MAX_BID))
return{bidMin:ceilToValidPrice(Math.max(band.minimum,MIN_STARTING_BID)),
bidMax:Math.max(floorToValidPrice(prevPrice(buyMax)),MIN_STARTING_BID),
buyMin:ceilToValidPrice(Math.max(nextPrice(band.minimum),MIN_BUY_NOW)),buyMax,banded:true}}
export function nudgeListPrice(input={}){const current=Number(input.buyNow)
const factor=Number(input.factor)
if(!Number.isFinite(current)||current<=0)return{ok:false,reason:'no-reference'}
if(!Number.isFinite(factor)||factor<=0)return{ok:false,reason:'no-reference'}
const bounds=listingBounds(input.limits,input.eaSaysNone===true)
let buyNow=floorToValidPrice(current*factor)
if(buyNow===floorToValidPrice(current)){buyNow=factor>1?nextPrice(current):prevPrice(current)}
return pricePair(buyNow,bounds)}
function pricePair(want,bounds){
if(bounds.banded!==true&&bounds.banded!=='ea-none')return{ok:false,reason:'no-band'}
let buyNow=want
let clamped=null
if(buyNow>bounds.buyMax){buyNow=floorToValidPrice(bounds.buyMax)
clamped='max'}
if(buyNow<bounds.buyMin){buyNow=bounds.buyMin
clamped='min'}
let startingBid=prevPrice(buyNow)
if(startingBid<bounds.bidMin)startingBid=bounds.bidMin
if(startingBid>bounds.bidMax)startingBid=bounds.bidMax
if(!(buyNow>startingBid)){const lifted=nextPrice(startingBid)
if(lifted>bounds.buyMax)return{ok:false,reason:'band-too-narrow'}
buyNow=lifted}
if(!isValidPrice(startingBid)||!isValidPrice(buyNow))return{ok:false,reason:'below-minimum'}
if(buyNow>bounds.buyMax||startingBid<MIN_STARTING_BID||buyNow<MIN_BUY_NOW)return{ok:false,reason:'band-too-narrow'}
return{ok:true,startingBid,buyNow,clamped}}
export function atListPrice(input={}){const raw=Number(input.reference)
if(!Number.isFinite(raw)||raw<=0)return{ok:false,reason:'no-reference'}
return pricePair(floorToValidPrice(raw),listingBounds(input.limits,input.eaSaysNone===true))}
export function withinListingBand(input={}){const raw=Number(input.buyNow)
if(!Number.isFinite(raw)||raw<=0)return{ok:false,reason:'no-reference'}
const bounds=listingBounds(input.limits,input.eaSaysNone===true)
const pair=pricePair(floorToValidPrice(raw),bounds)
if(pair.ok!==true)return pair
const asked=Number(input.startingBid)
if(!Number.isFinite(asked)||asked<=0)return pair
const bid=floorToValidPrice(asked)
if(bid<bounds.bidMin||bid>bounds.bidMax||!(pair.buyNow>bid)||!isValidPrice(bid))return pair
return{ok:true,startingBid:bid,buyNow:pair.buyNow,clamped:pair.clamped}}
export function normalizeDuration(value){const seconds=Number(value)
return LIST_DURATIONS.includes(seconds)?seconds:DEFAULT_DURATION}
