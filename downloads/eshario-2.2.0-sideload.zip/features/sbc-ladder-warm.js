import{unionClasses} from './demand-memory.js'
import{bucketsWanted,identityWantsFrom,LADDER_FROM_WARM,ladderLedger,liveClassesFrom} from './sbc-valuation.js'
export const LADDER_WARM_QUEUE_LIMIT=8
export const LADDER_WARM_START_FRAMES=2
export const LADDER_FAMILY=Object.freeze({general:'general',buckets:'buckets',rarity:'rarity',identity:'identity'})
export function warmFamiliesFor(buckets){return buckets===true
?[LADDER_FAMILY.general,LADDER_FAMILY.buckets,LADDER_FAMILY.rarity,LADDER_FAMILY.identity]
:[LADDER_FAMILY.general,LADDER_FAMILY.rarity,LADDER_FAMILY.identity]}
export function setWarmTargetsFrom(capture,opts={}){const limit=limitOf(opts.limit)
const skipped={brick:0,noRequirements:0}
const ready=[]
const late=[]
for(const row of Array.isArray(capture?.rows)?capture.rows:[]){const challenge=row?.challenge??null
if(!challenge)continue
let brick=false
try{brick=challenge.isBrickChallenge?.()===true}catch{brick=false}
if(brick){skipped.brick+=1
continue}
const requirements=challenge.eligibilityRequirements
if(!Array.isArray(requirements)||requirements.length===0){skipped.noRequirements+=1
continue}
let completed=false
try{completed=challenge.isCompleted?.()===true}catch{completed=false}
const id=idOf(challenge?.id)
const one={key:`set:${id===null?ready.length+late.length:id}`,done:completed,challenges:[{id,requirements}]}
if(completed)late.push(one)
else ready.push(one)}
return{targets:[...ready,...late].slice(0,limit),skipped}}
export function hubWarmTargetsFrom(challenges){const skipped={noRequirements:0}
const list=[]
for(const one of Array.isArray(challenges)?challenges:[]){const requirements=one?.requirements
if(!Array.isArray(requirements)||requirements.length===0){skipped.noRequirements+=1
continue}
list.push({id:idOf(one?.id),requirements})}
return{targets:list.length===0?[]:[{key:'hub',done:false,challenges:list}],skipped}}
export function awaitLadderWarm(warm){if(typeof warm?.settle!=='function')return null
try{const wait=warm.settle()
return typeof wait?.then==='function'?wait:null}catch{return null}}
const idOf=(raw)=>Number.isFinite(Number(raw))?String(Number(raw)):null
const limitOf=(raw)=>Number.isSafeInteger(raw)&&raw>0?raw:LADDER_WARM_QUEUE_LIMIT
export function createSbcLadderWarm(deps={}){const ladders=typeof deps.ladders==='function'?deps.ladders:null
const openChallenges=typeof deps.openChallenges==='function'?deps.openChallenges:()=>[]
const demand=deps.demand??null
const pool=deps.pool??null
const clubPrices=typeof deps.clubPrices==='function'?deps.clubPrices:null
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const win=deps.win??null
const doc=deps.doc??null
const ledger=deps.ledger===null?null:(deps.ledger??ladderLedger)
const limit=limitOf(deps.limit)
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let queue=[]
let ticket=0
let running=false
let urgent=false
let settling=null
let settled=null
const stats={rounds:0,done:0,shared:0,aborted:0,stoppedBy:null,last:null,
noFrames:0,hidden:0,noPool:0,noTargets:0,noTargetsOn:null,inactive:0,
hides:0,hidesHot:0}
const visible=()=>{try{return doc?.hidden!==true}catch{return true}}
const publish=()=>{if(ledger===null)return
try{ledger.noteWarm({...stats})}catch{/* приборы не имеют права ронять прогрев */}}
const pauseFor=(mine)=>{const frame=win?.requestAnimationFrame
if(typeof frame!=='function')return null
return()=>new Promise((resolve,reject)=>{if(mine!==ticket||!visible()){reject(new Error('ladder-warm-stopped'))
return}
if(urgent){resolve()
return}
frame.call(win,()=>{if(mine===ticket&&visible())resolve()
else reject(new Error('ladder-warm-stopped'))})})}
const sortedOf=(box)=>[...box].sort((a,b)=>a-b)
const readWants=(requirements,classes)=>{try{return identityWantsFrom(requirements,classes)}catch{return null}}
const classesFor=(requirements)=>{let live=[]
try{live=liveClassesFrom(requirements,openChallenges())}catch{live=[]}
let remembered=[]
try{remembered=demand?.classes?.()??[]}catch{remembered=[]}
try{return unionClasses(live,remembered)}catch{return live}}
const jobOf=(target)=>{const list=Array.isArray(target?.challenges)?target.challenges:[]
const own=list.length===1?list[0].requirements:null
const wants={league:new Set(),nation:new Set(),team:new Set()}
const take=(part)=>{for(const[field,values]of Object.entries(part??{})){const box=wants[field]
if(box===undefined)continue
for(const value of Array.isArray(values)?values:[])box.add(value)}}
take(readWants(own,classesFor(own)))
let buckets=false
for(const one of list){take(readWants(one.requirements,null))
if(!buckets)try{buckets=bucketsWanted(one.requirements)===true}catch{buckets=false}}
return{wants:{league:sortedOf(wants.league),nation:sortedOf(wants.nation),team:sortedOf(wants.team)},
buckets,families:warmFamiliesFor(buckets),
as:LADDER_FROM_WARM}}
const load=(targets,why)=>{if(ladders===null||!isActive()){stats.inactive+=1
stats.stoppedBy='inactive'
publish()
return false}
if(!visible()){stats.hidden+=1
stats.stoppedBy='hidden'
publish()
return false}
if(targets.length===0){stats.noTargets+=1
stats.noTargetsOn=why
publish()
return false}
queue=targets
stats.rounds+=1
publish()
if(running)return true
return schedule(why)}
function applyHub(){let known=[]
try{known=openChallenges()}catch(err){onError(err)
known=[]}
return load(hubWarmTargetsFrom(known).targets,'hub')}
function applySet(capture){let built
try{built=setWarmTargetsFrom(capture,{limit})}catch(err){onError(err)
return false}
return load(built.targets,'set')}
function schedule(why){const frame=win?.requestAnimationFrame
if(typeof frame!=='function'){stats.noFrames+=1
stats.stoppedBy='no-frames'
publish()
return false}
ticket+=1
urgent=false
const mine=ticket
running=true
settled=new Promise((resolve)=>{settling=resolve})
let left=LADDER_WARM_START_FRAMES
const tick=()=>{
if(mine!==ticket)return
if(!visible()){stats.hidden+=1
stats.stoppedBy='hidden'
finish(mine)
return}
left-=1
if(left>0){frame.call(win,tick)
return}
round(mine,why).catch((err)=>{onError(err)
finish(mine)})}
frame.call(win,tick)
return true}
function finish(mine){if(mine!==ticket)return
running=false
queue=[]
const done=settling
settling=null
publish()
if(done!==null)done()}
async function round(mine,why){while(mine===ticket&&queue.length>0){if(!isActive()){stats.inactive+=1
stats.stoppedBy='inactive'
break}
if(!visible()){stats.hidden+=1
stats.stoppedBy='hidden'
break}
const target=queue.shift()
if(!target)break
const job=jobOf(target)
const mark=ledger===null?0:ledger.seq()
let answer
try{answer=await ladders({wants:job.wants,buckets:job.buckets,families:job.families,as:job.as,pause:pauseFor(mine)})}
catch(err){if(mine!==ticket)break
stats.aborted+=1
stats.last={screen:why,target:target.key,ok:false}
if(String(err?.message??'')!=='ladder-warm-stopped')onError(err)
break}
if(mine!==ticket)break
countShared(mark)
if(answer===undefined){stats.aborted+=1
stats.last={screen:why,target:target.key,ok:false}
break}
stats.done+=1
stats.last={screen:why,target:target.key,ok:true,families:job.families.length}
publish()}
if(mine===ticket)await warmClubPrices(mine)
finish(mine)}
async function warmClubPrices(mine){if(clubPrices===null)return
let held=null
try{held=pool?.peek?.()??null}catch{held=null}
if(!held||!Array.isArray(held.players)||held.players.length===0){stats.noPool+=1
publish()
return}
try{const got=await clubPrices({pause:pauseFor(mine),club:held.players})
if(mine!==ticket)return
if(got===null||got===undefined)stats.aborted+=1}
catch(err){if(mine!==ticket)return
stats.aborted+=1
if(String(err?.message??'')!=='ladder-warm-stopped')onError(err)}}
function countShared(mark){if(ledger===null)return
let rows=null
try{rows=ledger.since(mark)}catch{rows=null}
for(const one of Object.values(rows??{}))if(one?.from==='общий')stats.shared+=1}
function stopNow(why){if(!running&&queue.length===0)return false
ticket+=1
urgent=false
queue=[]
running=false
stats.stoppedBy=String(why)
const done=settling
settling=null
publish()
if(done!==null)done()
return true}
const onVisibility=()=>{if(visible())return
stats.hides+=1
if(running)stats.hidesHot+=1
stopNow('hidden')
publish()}
if(typeof doc?.addEventListener==='function')doc.addEventListener('visibilitychange',onVisibility)
return{applyHub,applySet,
rush(why='challenge'){if(!running)return false
urgent=true
queue=[]
stats.stoppedBy=String(why)
publish()
return true},
stop(why='left'){return stopNow(why)},
settle(){return settling===null||settled===null?null:settled},
state(){return{...stats,queue:queue.length,running,urgent,visible:visible()}},
dispose(){if(typeof doc?.removeEventListener==='function')doc.removeEventListener('visibilitychange',onVisibility)
ticket+=1
queue=[]
running=false
urgent=false
const done=settling
settling=null
if(done!==null)done()}}}
