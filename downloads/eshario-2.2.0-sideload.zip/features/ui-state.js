import{createCachedProvider} from '../core/storage-provider.js'
import{sanitizeSbcPolicy} from '../automation/sbc-solver.js'
import{sanitizeBindings} from './hotkeys.js'
import{sanitizePackShowPolicy,sanitizeShowRating,PACK_SHOW_DEFAULTS} from './pack-show.js'
import{sanitizeSolverOptions,SOLVER_DEFAULTS} from './solver-options.js'
import{sanitizeExpensiveFrom,EXPENSIVE_FROM_DEFAULT} from './unassigned-strip.js'
import{sanitizeUnassignedRules,defaultUnassignedRules} from './unassigned-brain.js'
import{sanitizeCardGridView,defaultCardGridView} from './card-grid.js'
import{sanitizeClubBarView,defaultClubBarView} from './club-bar.js'
import{sanitizeCardView,CARD_VIEWS,CARD_VIEW_DEFAULT} from './card-views.js'
import{sanitizeVolume,VOLUME_LEVELS,VOLUME_DEFAULT} from './sound.js'
import{sanitizeRelistPricing,relistPricingAfter,RELIST_MODES,RELIST_DIRS,RELIST_PERCENT_MIN,RELIST_PERCENT_MAX} from './transfer-list.js'
import{sanitizeHeadView,defaultHeadView} from './head-bar.js'
import{sanitizeCatalogSort,CATALOG_SORT_DEFAULT} from './store-catalog.js'
import{sanitizeMarketBotView,defaultMarketBotView} from './market-bot-column.js'
import{sanitizeMarketFilterView,defaultMarketFilterView} from './market-filter-memory.js'
import{sanitizePickPreselect,PICK_PRESELECT} from './pick-prices.js'
import{SUPPORTED_LOCALES} from '../i18n/index.js'
export const UI_STATE_KEY='ui.state'
export const UI_READ='ui.read'
export const UI_WRITE='ui.write'
export const MAX_SELECTED_FILTERS=20
export const MAX_HIDDEN_SETS=200
export const MAX_RAIL_PACKS=200
export function sanitizeRailPacks(stored){if(!Array.isArray(stored))return[]
const out=[]
const seen=new Set()
for(const one of stored){const id=one?.id
if(!Number.isSafeInteger(id)||seen.has(id))continue
if(typeof one?.tradable!=='boolean')continue
seen.add(id)
if(out.length>=MAX_RAIL_PACKS)break
out.push({id,tradable:one.tradable})}
return out}
export const SBC_COLUMNS_MIN=2
export const SBC_COLUMNS_MAX=8
export const SBC_COLUMNS_DEFAULT=4
export const SBC_SORTS=Object.freeze(['ea','soonest','liked'])
export const SBC_PINNED_DEFAULT=true
export const UNASSIGNED_COLUMNS_MIN=1
export const UNASSIGNED_COLUMNS_MAX=14
export const UNASSIGNED_COLUMNS_AUTO='auto'
export const UNASSIGNED_COLUMNS_DEFAULT=UNASSIGNED_COLUMNS_AUTO
export const UNASSIGNED_PINNED_DEFAULT=true
export function defaultUnassignedView(){return{columns:UNASSIGNED_COLUMNS_DEFAULT,pinned:UNASSIGNED_PINNED_DEFAULT,
rules:defaultUnassignedRules()}}
export function sanitizeUnassignedView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const out=defaultUnassignedView()
if(typeof raw.pinned==='boolean')out.pinned=raw.pinned
out.rules=sanitizeUnassignedRules(raw.rules)
if(raw.columns===UNASSIGNED_COLUMNS_AUTO)return out
const columns=Number(raw.columns)
if(Number.isSafeInteger(columns)&&columns>=UNASSIGNED_COLUMNS_MIN&&columns<=UNASSIGNED_COLUMNS_MAX)out.columns=columns
return out}
export const SBC_SET_PINNED_DEFAULT=true
export function defaultSbcSetView(){return{pinned:SBC_SET_PINNED_DEFAULT}}
export function sanitizeSbcSetView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const out=defaultSbcSetView()
if(typeof raw.pinned==='boolean')out.pinned=raw.pinned
return out}
export const STORE_CATALOG_PINNED_DEFAULT=true
export function defaultStoreCatalogView(){return{pinned:STORE_CATALOG_PINNED_DEFAULT,
sort:CATALOG_SORT_DEFAULT.by,desc:CATALOG_SORT_DEFAULT.desc}}
export function sanitizeStoreCatalogView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const out=defaultStoreCatalogView()
if(typeof raw.pinned==='boolean')out.pinned=raw.pinned
const sort=sanitizeCatalogSort({by:raw.sort,desc:raw.desc})
out.sort=sort.by
out.desc=sort.desc
return out}
export function defaultPanelView(){return{section:null,fine:false,advanced:false}}
export function sanitizePanelView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const out=defaultPanelView()
if(typeof raw.section==='string'&&raw.section!=='')out.section=raw.section
if(typeof raw.fine==='boolean')out.fine=raw.fine
if(typeof raw.advanced==='boolean')out.advanced=raw.advanced
return out}
export function defaultSbcView(){return{sort:'ea',columns:SBC_COLUMNS_DEFAULT,pinned:SBC_PINNED_DEFAULT}}
export function sanitizeSbcView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const out=defaultSbcView()
if(SBC_SORTS.includes(raw.sort))out.sort=raw.sort
const columns=Number(raw.columns)
if(Number.isSafeInteger(columns)&&columns>=SBC_COLUMNS_MIN&&columns<=SBC_COLUMNS_MAX)out.columns=columns
if(typeof raw.pinned==='boolean')out.pinned=raw.pinned
return out}
export function defaultUiState(){return{collapsed:false,legacyOpen:true,onboarded:false,dayXOff:false,filters:[],position:null,locale:null,sbcPolicy:sanitizeSbcPolicy(),hotkeys:sanitizeHotkeyProfile(null),packShow:sanitizePackShowPolicy(null),solver:sanitizeSolverOptions(null),unassignedThreshold:EXPENSIVE_FROM_DEFAULT,sbcHidden:[],sbcView:defaultSbcView(),sbcSetView:defaultSbcSetView(),storeCatalogView:defaultStoreCatalogView(),panelView:defaultPanelView(),unassignedView:defaultUnassignedView(),cardGrid:defaultCardGridView(),clubBar:defaultClubBarView(),cardView:CARD_VIEW_DEFAULT,soundVolume:VOLUME_DEFAULT,relist:sanitizeRelistPricing(null),listing:sanitizeRelistPricing(null),headView:defaultHeadView(),snipeConsent:null,railPacks:[],marketBot:defaultMarketBotView(),marketFilter:defaultMarketFilterView(),pickPreselect:null}}
export function sanitizeHotkeyProfile(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const bindings={}
const source=raw.bindings&&typeof raw.bindings==='object'&&!Array.isArray(raw.bindings)?raw.bindings:{}
for(const[action,combo]of Object.entries(source)){if(action!==''&&typeof combo==='string')bindings[action]=combo}
const custom={}
const saved=raw.custom&&typeof raw.custom==='object'&&!Array.isArray(raw.custom)?raw.custom:{}
for(const[key,entry]of Object.entries(saved)){if(key===''||!entry||typeof entry!=='object')continue
const one={label:typeof entry.label==='string'?entry.label:key,danger:entry.danger===true}
if(entry.road===null)one.road=null
else if(typeof entry.road==='string'&&entry.road!=='')one.road=entry.road
custom[key]=one}
const dangerSeen=(Array.isArray(raw.dangerSeen)?raw.dangerSeen:[]).filter((one)=>typeof one==='string'&&one!=='')
return{bindings,custom,badges:raw.badges!==false,dangerSeen}}
export function sanitizeLocale(value){return SUPPORTED_LOCALES.includes(value)?value:null}
export const MIN_VISIBLE_PX=32
export function clampPosition(position,box={}){if(!position||!Number.isFinite(position.x)||!Number.isFinite(position.y))return null
const num=(value,fallback)=>(Number.isFinite(value)&&value>0?value:fallback)
const viewWidth=num(box.viewWidth,0)
const viewHeight=num(box.viewHeight,0)
if(viewWidth===0||viewHeight===0){return{x:Math.max(0,position.x),y:Math.max(0,position.y)}}
const panelWidth=num(box.panelWidth,0)
const maxX=Math.max(0,viewWidth-panelWidth)
const maxY=Math.max(0,viewHeight-MIN_VISIBLE_PX)
return{x:Math.min(Math.max(0,position.x),maxX),y:Math.min(Math.max(0,position.y),maxY)}}
export function sanitizeUiState(stored){const result=defaultUiState()
if(!stored||typeof stored!=='object'||Array.isArray(stored)) return result
if(typeof stored.collapsed==='boolean') result.collapsed=stored.collapsed
if(typeof stored.legacyOpen==='boolean') result.legacyOpen=stored.legacyOpen
if(typeof stored.onboarded==='boolean') result.onboarded=stored.onboarded
if(typeof stored.dayXOff==='boolean') result.dayXOff=stored.dayXOff
result.locale=sanitizeLocale(stored.locale)
const raw=stored.position
if(raw&&typeof raw==='object'&&!Array.isArray(raw)
&&Number.isFinite(raw.x)&&Number.isFinite(raw.y)){result.position={x:raw.x,y:raw.y}}
if(Array.isArray(stored.filters)){const seen=new Set()
for(const id of stored.filters){if(typeof id!=='string'||id===''||seen.has(id)) continue
seen.add(id)
if(seen.size>MAX_SELECTED_FILTERS)break
result.filters.push(id)}}
result.sbcPolicy=sanitizeSbcPolicy(stored.sbcPolicy)
result.hotkeys=sanitizeHotkeyProfile(stored.hotkeys)
result.packShow=sanitizePackShowPolicy(stored.packShow)
result.solver=sanitizeSolverOptions(stored.solver)
result.unassignedThreshold=sanitizeExpensiveFrom(stored.unassignedThreshold)
if(Array.isArray(stored.sbcHidden)){const seen=new Set()
for(const raw of stored.sbcHidden){const id=typeof raw==='number'&&Number.isFinite(raw)?String(raw):raw
if(typeof id!=='string'||id===''||seen.has(id))continue
seen.add(id)
if(seen.size>MAX_HIDDEN_SETS)break
result.sbcHidden.push(id)}}
result.sbcView=sanitizeSbcView(stored.sbcView)
result.sbcSetView=sanitizeSbcSetView(stored.sbcSetView)
result.storeCatalogView=sanitizeStoreCatalogView(stored.storeCatalogView)
result.panelView=sanitizePanelView(stored.panelView)
result.unassignedView=sanitizeUnassignedView(stored.unassignedView)
result.cardGrid=sanitizeCardGridView(stored.cardGrid)
result.clubBar=sanitizeClubBarView(stored.clubBar)
result.cardView=sanitizeCardView(stored.cardView)
result.soundVolume=sanitizeVolume(stored.soundVolume)
result.relist=sanitizeRelistPricing(stored.relist)
result.listing=sanitizeRelistPricing(stored.listing)
result.headView=sanitizeHeadView(stored.headView)
if(typeof stored.snipeConsent==='string'&&stored.snipeConsent!=='')result.snipeConsent=stored.snipeConsent
result.railPacks=sanitizeRailPacks(stored.railPacks)
result.marketBot=sanitizeMarketBotView(stored.marketBot)
result.marketFilter=sanitizeMarketFilterView(stored.marketFilter)
result.pickPreselect=sanitizePickPreselect(stored.pickPreselect)
return result}
export function pickPreselectFromToggles(storedToggles){return storedToggles&&typeof storedToggles==='object'&&!Array.isArray(storedToggles)&&storedToggles.pickByPrice===true
?PICK_PRESELECT.PRICE:PICK_PRESELECT.RATING}
export function createBridgeUiProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function') throw new Error('ui-state: мост недоступен')
return createCachedProvider({fetch:()=>bridge.request(UI_READ),push:(value)=>bridge.request(UI_WRITE,value),sanitize:sanitizeUiState,fallback:defaultUiState,onError:opts.onError})}
function pricingPatch(current,patch){if(patch===null||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const next={...current}
if(Object.hasOwn(patch,'mode')){if(!RELIST_MODES.includes(patch.mode))return{ok:false,reason:'bad-mode'}
next.mode=patch.mode}
if(Object.hasOwn(patch,'direction')){if(!RELIST_DIRS.includes(patch.direction))return{ok:false,reason:'bad-direction'}
next.direction=patch.direction}
if(Object.hasOwn(patch,'percent')){const raw=Number(patch.percent)
if(!Number.isFinite(raw)||raw<RELIST_PERCENT_MIN||raw>RELIST_PERCENT_MAX)return{ok:false,reason:'bad-percent'}
next.percent=Math.round(raw)}
const change={}
for(const field of ['mode','direction','percent'])if(Object.hasOwn(patch,field))change[field]=next[field]
return{ok:true,value:relistPricingAfter(current,change)}}
export function createUiState(opts={}){const provider=opts.provider??memoryProvider()
const state=()=>{try{return sanitizeUiState(provider.read())}catch{
return defaultUiState()}}
const write=(patch,current=state())=>{try{provider.write({...current,...patch})
return{ok:true,reason:null}}catch(err){return{ok:false,reason:'write-failed',detail:String(err?.message??err)}}}
return{isCollapsed:()=>state().collapsed===true,isLegacyOpen:()=>state().legacyOpen===true,isOnboarded:()=>state().onboarded===true,
setCollapsed(value){if(typeof value!=='boolean') return{ok:false,reason:'not-a-boolean'}
return write({collapsed:value})},
setLegacyOpen(value){if(typeof value!=='boolean') return{ok:false,reason:'not-a-boolean'}
const current=state()
if(current.legacyOpen===value) return{ok:true,reason:null}
return write({legacyOpen:value},current)},
setOnboarded(value){if(typeof value!=='boolean') return{ok:false,reason:'not-a-boolean'}
return write({onboarded:value})},
isDayXOff:()=>state().dayXOff===true,
setDayXOff(value){if(typeof value!=='boolean') return{ok:false,reason:'not-a-boolean'}
const current=state()
if(current.dayXOff===value) return{ok:true,reason:null}
return write({dayXOff:value},current)},
locale:()=>state().locale,
setLocale(value){if(value!==null&&!SUPPORTED_LOCALES.includes(value)) return{ok:false,reason:'bad-locale'}
return write({locale:value})},
hotkeyState:()=>{const{bindings,custom,badges,dangerSeen}=state().hotkeys
return{bindings:{...bindings},custom:{...custom},badges,dangerSeen:[...dangerSeen]}},
setHotkeyState(next){return write({hotkeys:sanitizeHotkeyProfile(next)})},
hotkeys:()=>sanitizeBindings(state().hotkeys.bindings),
railPacks:()=>sanitizeRailPacks(state().railPacks),
setRailPacks(list){if(!Array.isArray(list))return{ok:false,reason:'not-a-list'}
return write({railPacks:sanitizeRailPacks(list)})},
packShow:()=>({...state().packShow}),
solver:()=>({...state().solver}),
setSolver(field,value){if(!Object.hasOwn(SOLVER_DEFAULTS,field))return{ok:false,reason:'unknown-field'}
if(typeof value!=='boolean')return{ok:false,reason:'not-a-boolean'}
const current=state()
return write({solver:sanitizeSolverOptions({...current.solver,[field]:value})},current)},
setPackShow(field,value){if(!Object.hasOwn(PACK_SHOW_DEFAULTS,field))return{ok:false,reason:'unknown-field'}
if(field==='ratingMin'){if(value!==null&&sanitizeShowRating(value)===null)return{ok:false,reason:'not-a-rating'}}
else if(typeof value!=='boolean')return{ok:false,reason:'not-a-boolean'}
const current=state()
return write({packShow:sanitizePackShowPolicy({...current.packShow,[field]:value})},current)},
unassignedThreshold:()=>state().unassignedThreshold,
setUnassignedThreshold(value){const text=typeof value==='string'?value.trim():value
const number=typeof text==='string'&&/^\d{1,9}$/.test(text)?Number(text):text
if(!Number.isSafeInteger(number)||number<0)return{ok:false,reason:'not-a-number'}
if(sanitizeExpensiveFrom(number)!==number)return{ok:false,reason:'out-of-range'}
return write({unassignedThreshold:number},state())},
sbcHidden:()=>[...state().sbcHidden],
sbcView:()=>({...state().sbcView}),
setSbcView(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.sbcView}
if(Object.hasOwn(patch,'sort')){if(!SBC_SORTS.includes(patch.sort))return{ok:false,reason:'bad-sort'}
next.sort=patch.sort}
if(Object.hasOwn(patch,'columns')){const columns=Number(patch.columns)
if(!Number.isSafeInteger(columns)||columns<SBC_COLUMNS_MIN||columns>SBC_COLUMNS_MAX)return{ok:false,reason:'bad-columns'}
next.columns=columns}
if(Object.hasOwn(patch,'pinned')){if(typeof patch.pinned!=='boolean')return{ok:false,reason:'bad-pinned'}
next.pinned=patch.pinned}
return write({sbcView:next},current)},
sbcSetView:()=>({...state().sbcSetView}),
setSbcSetView(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.sbcSetView}
if(Object.hasOwn(patch,'pinned')){if(typeof patch.pinned!=='boolean')return{ok:false,reason:'bad-pinned'}
next.pinned=patch.pinned}
return write({sbcSetView:next},current)},
storeCatalogView:()=>({...state().storeCatalogView}),
setStoreCatalogView(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.storeCatalogView}
if(Object.hasOwn(patch,'pinned')){if(typeof patch.pinned!=='boolean')return{ok:false,reason:'bad-pinned'}
next.pinned=patch.pinned}
if(Object.hasOwn(patch,'sort')){if(sanitizeCatalogSort({by:patch.sort}).by!==patch.sort)return{ok:false,reason:'bad-sort'}
next.sort=patch.sort}
if(Object.hasOwn(patch,'desc')){if(typeof patch.desc!=='boolean')return{ok:false,reason:'bad-desc'}
next.desc=patch.desc}
return write({storeCatalogView:next},current)},
panelView:()=>({...state().panelView}),
setPanelView(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.panelView}
if(Object.hasOwn(patch,'section')){if(patch.section!==null&&(typeof patch.section!=='string'||patch.section===''))return{ok:false,reason:'bad-section'}
next.section=patch.section}
if(Object.hasOwn(patch,'fine')){if(typeof patch.fine!=='boolean')return{ok:false,reason:'bad-fine'}
next.fine=patch.fine}
if(Object.hasOwn(patch,'advanced')){if(typeof patch.advanced!=='boolean')return{ok:false,reason:'bad-advanced'}
next.advanced=patch.advanced}
if(next.section===current.panelView.section&&next.fine===current.panelView.fine
&&next.advanced===current.panelView.advanced)return{ok:true,reason:null}
return write({panelView:next},current)},
unassignedView:()=>({...state().unassignedView}),
setUnassignedView(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.unassignedView}
if(Object.hasOwn(patch,'rules')){if(!patch.rules||typeof patch.rules!=='object'||Array.isArray(patch.rules))return{ok:false,reason:'bad-rules'}
next.rules=sanitizeUnassignedRules(patch.rules)}
if(Object.hasOwn(patch,'columns')){if(patch.columns===UNASSIGNED_COLUMNS_AUTO)next.columns=UNASSIGNED_COLUMNS_AUTO
else{const columns=Number(patch.columns)
if(!Number.isSafeInteger(columns)||columns<UNASSIGNED_COLUMNS_MIN||columns>UNASSIGNED_COLUMNS_MAX)return{ok:false,reason:'bad-columns'}
next.columns=columns}}
if(Object.hasOwn(patch,'pinned')){if(typeof patch.pinned!=='boolean')return{ok:false,reason:'bad-pinned'}
next.pinned=patch.pinned}
return write({unassignedView:next},current)},
cardGrid:()=>({...state().cardGrid}),
setCardGrid(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.cardGrid}
if(Object.hasOwn(patch,'pinned')){if(typeof patch.pinned!=='boolean')return{ok:false,reason:'bad-pinned'}
next.pinned=patch.pinned}
return write({cardGrid:next},current)},
clubBar:()=>({...state().clubBar}),
setClubBar(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.clubBar}
if(Object.hasOwn(patch,'pinned')){if(typeof patch.pinned!=='boolean')return{ok:false,reason:'bad-pinned'}
next.pinned=patch.pinned}
if(Object.hasOwn(patch,'sort')){if(typeof patch.sort!=='string'||patch.sort==='')return{ok:false,reason:'bad-sort'}
next.sort=patch.sort}
return write({clubBar:next},current)},
snipeConsent:()=>state().snipeConsent,
setSnipeConsent(fingerprint){if(fingerprint!==null&&(typeof fingerprint!=='string'||fingerprint===''))return{ok:false,reason:'bad-consent'}
return write({snipeConsent:fingerprint})},
marketBot:()=>({...state().marketBot}),
setMarketBot(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.marketBot}
if(Object.hasOwn(patch,'lastRun')){const value=patch.lastRun
if(value!==null&&(typeof value!=='object'||Array.isArray(value)))return{ok:false,reason:'bad-run'}
const clean=sanitizeMarketBotView({lastRun:value}).lastRun
if(value!==null&&clean===null)return{ok:false,reason:'bad-run'}
next.lastRun=clean}
return write({marketBot:next},current)},
marketFilter:()=>({...state().marketFilter}),
setMarketFilter(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.marketFilter}
if(Object.hasOwn(patch,'criteria')){const value=patch.criteria
if(value!==null&&(typeof value!=='object'||Array.isArray(value)))return{ok:false,reason:'bad-criteria'}
const clean=sanitizeMarketFilterView({criteria:value}).criteria
if(value!==null&&clean===null)return{ok:false,reason:'bad-criteria'}
next.criteria=clean}
return write({marketFilter:next},current)},
cardView:()=>state().cardView,
setCardView(value){if(!CARD_VIEWS.includes(value))return{ok:false,reason:'bad-view'}
return write({cardView:value})},
pickPreselect:()=>state().pickPreselect,
setPickPreselect(value){if(sanitizePickPreselect(value)===null)return{ok:false,reason:'bad-preselect'}
return write({pickPreselect:value})},
soundVolume:()=>state().soundVolume,
setSoundVolume(value){if(!VOLUME_LEVELS.includes(value))return{ok:false,reason:'bad-volume'}
return write({soundVolume:value})},
relist:()=>({...state().relist}),
setRelist(patch){const next=pricingPatch(state().relist,patch)
if(next.ok===false)return next
return write({relist:sanitizeRelistPricing(next.value)})},
listing:()=>({...state().listing}),
setListing(patch){const next=pricingPatch(state().listing,patch)
if(next.ok===false)return next
return write({listing:sanitizeRelistPricing(next.value)})},
headView:()=>({...state().headView}),
setHeadView(patch){if(!patch||typeof patch!=='object'||Array.isArray(patch))return{ok:false,reason:'bad-patch'}
const current=state()
const next={...current.headView}
for(const field of['division','club']){if(!Object.hasOwn(patch,field))continue
if(typeof patch[field]!=='boolean')return{ok:false,reason:`bad-${field}`}
next[field]=patch[field]}
return write({headView:next},current)},
setSbcHidden(id,on){const key=typeof id==='number'&&Number.isFinite(id)?String(id):id
if(typeof key!=='string'||key==='')return{ok:false,reason:'bad-id'}
const current=state()
const sbcHidden=current.sbcHidden.filter((one)=>one!==key)
if(on===true){if(sbcHidden.length>=MAX_HIDDEN_SETS)return{ok:false,reason:'too-many'}
sbcHidden.push(key)}
return write({sbcHidden},current)},
selectedFilters:()=>[...state().filters],
selectFilter(id,on){if(typeof id!=='string'||id==='') return{ok:false,reason:'bad-id'}
const current=state()
const filters=current.filters.filter((value)=>value!==id)
if(on===true){if(filters.length>=MAX_SELECTED_FILTERS) return{ok:false,reason:'too-many'}
filters.push(id)}
return write({filters},current)},
chosenFilters(sets){const list=Array.isArray(sets)?sets:[]
const ids=state().filters
if(ids.length===0)return[...list]
const byId=new Map(list.map((set)=>[String(set?.id),set]))
return ids.map((id)=>byId.get(id)).filter(Boolean)},
position:(box)=>clampPosition(state().position,box??{}),
setPosition(x,y,box){const clamped=clampPosition({x,y},box??{})
if(clamped===null) return{ok:false,reason:'bad-position'}
return write({position:clamped})},
resetPosition(){return write({position:null})},
all:()=>state()}}
export function memoryProvider(initial={}){let value=sanitizeUiState(initial)
return{read:()=>({...value}),write(next){value=sanitizeUiState(next)}}}
