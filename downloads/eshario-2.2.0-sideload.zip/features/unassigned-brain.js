export const DESTINATIONS=Object.freeze(['transfer','club','quicksell'])
export const TIER_NONE=0
export const TIER_BRONZE=1
export const TIER_SILVER=2
export const TIER_GOLD=3
export const EXPENSIVE_RATING_DEFAULT=86
export const EXPENSIVE_PRICE_DEFAULT=10000
export const LOAN_RATING_DEFAULT=84
export const GOLD_BELOW_DEFAULT=80
export const DUPE_PRICE_DEFAULT=1000
export const DUPE_ABOVE_DESTS=Object.freeze(['transfer','storage','quicksell'])
export const DUPE_BELOW_DESTS=Object.freeze(['quicksell','storage','keep'])
export const DUPE_NONE_DESTS=Object.freeze(['transfer','keep','quicksell'])
export const DUPE_NONE_DEFAULT='transfer'
export const STYLE_DEFAULT_NAMES=Object.freeze(['hunter','shadow','anchor','охотник','тень','якорь'])
export const NATION_DEFAULT_NAMES=Object.freeze(['france','brazil','франция','бразилия'])
export const LEAGUE_DEFAULT_IDS=Object.freeze([
13, // PREMIER_LEAGUE — АПЛ
53, // LALIGA_SPORTS — испанская мужская
2222, // LIGA_F — испанская женская
])
const int=(value)=>(Number.isSafeInteger(value)?value:null)
const bool=(value,fallback)=>(typeof value==='boolean'?value:fallback)
const idList=(value,max)=>{const out=[]
if(!Array.isArray(value))return out
for(const one of value){const id=int(one)
if(id!==null&&id>=0&&!out.includes(id))out.push(id)
if(out.length>=max)break}
return out}
export const KINDS_MAX=200
export const NATIONS_MAX=200
export function defaultUnassignedRules(){return{expensive:{rating:EXPENSIVE_RATING_DEFAULT,price:EXPENSIVE_PRICE_DEFAULT,special:true},
dest:{expensive:'transfer',players:'club',styles:'transfer',coaches:'transfer',
leagues:'transfer',items:'quicksell'},
styles:[],nations:[],leagues:[...LEAGUE_DEFAULT_IDS],adopted:false,leaguesAdopted:false,
quality:{bronze:true,silver:true,gold:false,goldBelow:GOLD_BELOW_DEFAULT},
dupe:{price:DUPE_PRICE_DEFAULT,above:'transfer',below:'quicksell',none:DUPE_NONE_DEFAULT},
loan:{rating:LOAN_RATING_DEFAULT,special:true,keep:'club',rest:'quicksell'},
redeem:true,warned:false}}
const destOf=(value,fallback)=>(DESTINATIONS.includes(value)?value:fallback)
export function sanitizeUnassignedRules(stored){const out=defaultUnassignedRules()
const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const exp=raw.expensive&&typeof raw.expensive==='object'?raw.expensive:{}
const rating=int(exp.rating)
if(rating!==null&&rating>=0&&rating<=99)out.expensive.rating=rating
const price=int(exp.price)
if(price!==null&&price>=0&&price<=100000000)out.expensive.price=price
out.expensive.special=bool(exp.special,out.expensive.special)
const dest=raw.dest&&typeof raw.dest==='object'?raw.dest:{}
for(const key of Object.keys(out.dest))out.dest[key]=destOf(dest[key],out.dest[key])
out.styles=idList(raw.styles,KINDS_MAX)
out.nations=idList(raw.nations,NATIONS_MAX)
out.adopted=bool(raw.adopted,false)
out.leaguesAdopted=bool(raw.leaguesAdopted,false)
out.leagues=out.leaguesAdopted?idList(raw.leagues,NATIONS_MAX):[...LEAGUE_DEFAULT_IDS]
const quality=raw.quality&&typeof raw.quality==='object'?raw.quality:{}
for(const key of['bronze','silver','gold'])out.quality[key]=bool(quality[key],out.quality[key])
const goldBelow=int(quality.goldBelow)
if(goldBelow!==null&&goldBelow>=0&&goldBelow<=99)out.quality.goldBelow=goldBelow
const dupe=raw.dupe&&typeof raw.dupe==='object'?raw.dupe:{}
const dupePrice=int(dupe.price)
if(dupePrice!==null&&dupePrice>=0&&dupePrice<=100000000)out.dupe.price=dupePrice
if(DUPE_ABOVE_DESTS.includes(dupe.above))out.dupe.above=dupe.above
if(DUPE_BELOW_DESTS.includes(dupe.below))out.dupe.below=dupe.below
if(DUPE_NONE_DESTS.includes(dupe.none))out.dupe.none=dupe.none
const loan=raw.loan&&typeof raw.loan==='object'?raw.loan:{}
const loanRating=int(loan.rating)
if(loanRating!==null&&loanRating>=0&&loanRating<=99)out.loan.rating=loanRating
out.loan.special=bool(loan.special,out.loan.special)
const keep=destOf(loan.keep,out.loan.keep)
out.loan.keep=keep==='transfer'?'club':keep
const rest=destOf(loan.rest,out.loan.rest)
out.loan.rest=rest==='transfer'?'quicksell':rest
out.redeem=bool(raw.redeem,out.redeem)
out.warned=bool(raw.warned,out.warned)
return out}
export function rulesForStore(rules){const raw=rules&&typeof rules==='object'&&!Array.isArray(rules)?rules:{}
return sanitizeUnassignedRules({...raw,leaguesAdopted:true})}
export function adoptDefaults(rules,catalog={}){const out=sanitizeUnassignedRules(rules)
if(out.adopted===true)return{changed:false,rules:out}
const styles=Array.isArray(catalog.styles)?catalog.styles:[]
const nations=Array.isArray(catalog.nations)?catalog.nations:[]
if(styles.length===0&&nations.length===0)return{changed:false,rules:out}
const flat=(text)=>String(text??'').toLowerCase().replace(/\s+/g,'')
const pick=(list,names)=>{const want=names.map(flat)
const got=[]
for(const one of list){const id=int(one?.id)
if(id===null||got.includes(id))continue
if(want.includes(flat(one?.name)))got.push(id)}
return got}
out.styles=pick(styles,STYLE_DEFAULT_NAMES)
out.nations=pick(nations,NATION_DEFAULT_NAMES)
out.adopted=true
return{changed:true,rules:out}}
export const KNOWN_TYPES=Object.freeze(['player','manager','kit','badge','stadium','ball','misc','vanity','training','health'])
const isConsumable=(card)=>card?.type==='training'||card?.type==='health'
export function isExpensive(card,price,rules){const want=rules?.expensive??{}
const rating=int(card?.rating)
if(rating!==null&&int(want.rating)!==null&&rating>=want.rating)return true
const coins=int(price)
if(coins!==null&&int(want.price)!==null&&coins>=want.price)return true
return want.special===true&&card?.special===true}
const qualityCuts=(tier,rules,rating)=>{const q=rules?.quality??{}
if(tier===TIER_BRONZE)return q.bronze===true
if(tier===TIER_SILVER)return q.silver===true
if(tier===TIER_GOLD){if(q.gold!==true)return false
const below=int(q.goldBelow)
const own=int(rating)
return below!==null&&own!==null&&own<below}
return false}
function dupePlace(dest,why,card,tier,storageOn){
if(dest==='transfer'||dest==='quicksell')return{to:dest,why}
if(dest==='storage')return tier===TIER_GOLD&&storageOn&&card?.storable===true
?{to:'storage',why}
:{to:'keep',why:'dupe-storage-full'}
return{to:'keep',why:'dupe-cheap-kept'}}
function dupeUnpriced(dest){return dest==='transfer'||dest==='quicksell'
?{to:dest,why:'dupe-unpriced'}
:{to:'keep',why:'dupe-unpriced'}}
function unknownKind(card){return card?.movable===true
?{to:'club',why:'unknown-kind'}
:{to:'stop',why:'unknown-kind'}}
export function judgeCard(card,rules,ctx={}){const readPrice=typeof ctx.price==='function'?ctx.price:()=>null
let price=null
try{const value=readPrice(card)
price=int(value)!==null&&value>=0?value:null}catch{price=null}
const tier=int(card?.tier)??TIER_NONE
const storageOn=ctx.storage===true
if(card?.redeemable===true)return rules?.redeem===true?{to:'redeem',why:'redeem'}:{to:'keep',why:'redeem-off'}
if(card?.pick===true)return{to:'keep',why:'pick'}
if(!KNOWN_TYPES.includes(String(card?.type)))return unknownKind(card)
if(card?.limitedUse===true){const rating=int(card?.rating)
const keep=(rating!==null&&int(rules?.loan?.rating)!==null&&rating>=rules.loan.rating)
||(rules?.loan?.special===true&&card?.special===true)
return keep?{to:rules?.loan?.keep??'club',why:'loan-keep'}:{to:rules?.loan?.rest??'quicksell',why:'loan-burn'}}
if(card?.duplicate===true){
if(card?.tradable!==true){
if(card?.player===true&&card?.dupClub==='tradable'
&&isExpensive(card,price,rules)&&rules?.dest?.expensive==='transfer')return{to:'swap',why:'swap'}
if(card?.player!==true)return{to:'quicksell',why:'dupe-item'}
if(tier===TIER_GOLD&&storageOn&&card?.storable===true)return{to:'storage',why:'dupe-gold'}
if(qualityCuts(tier,rules,card?.rating))return{to:'quicksell',why:'dupe-quality'}
return{to:'keep',why:'dupe-kept'}}
if(isExpensive(card,price,rules))return{to:'transfer',why:'dupe-expensive'}
if(card?.player!==true)return{to:'quicksell',why:'dupe-item'}
const bar=int(rules?.dupe?.price)
if(bar===null)return{to:'keep',why:'dupe-no-bar'}
if(price===null)return dupeUnpriced(rules?.dupe?.none)
return price>=bar
?dupePlace(rules?.dupe?.above,'dupe-price',card,tier,storageOn)
:dupePlace(rules?.dupe?.below,'dupe-cheap',card,tier,storageOn)}
if(card?.tradable!==true)return{to:'club',why:'new'}
if(card?.player===true){if(isExpensive(card,price,rules))return{to:rules?.dest?.expensive??'transfer',why:'expensive'}
return{to:rules?.dest?.players??'club',why:'player'}}
if(isConsumable(card)){const styles=Array.isArray(rules?.styles)?rules.styles:[]
if(styles.includes(int(card?.subtype)))return{to:rules?.dest?.styles??'transfer',why:'style'}
return{to:rules?.dest?.items??'club',why:'item'}}
if(card?.type==='manager'){const nations=Array.isArray(rules?.nations)?rules.nations:[]
if(nations.includes(int(card?.nationId)))return{to:rules?.dest?.coaches??'transfer',why:'coach'}
const leagues=Array.isArray(rules?.leagues)?rules.leagues:[]
if(leagues.includes(int(card?.leagueId)))return{to:rules?.dest?.leagues??'transfer',why:'coach-league'}
return{to:rules?.dest?.items??'club',why:'item'}}
return{to:rules?.dest?.items??'club',why:'item'}}
export const MOVE_KINDS=Object.freeze(['redeem','club-out','club','transfer','storage','discard'])
const STEP_ORDER=Object.freeze(['redeem','club-out','transfer','storage','club','discard'])
function fitStorage(ids,rating,room){const list=Array.isArray(ids)?ids:[]
const take=int(room)
if(take===null||take>=list.length)return{take:list,left:[]}
if(take<=0)return{take:[],left:[...list]}
const order=list.map((id,seat)=>({id,seat,rating:rating.get(id)??null}))
order.sort((a,b)=>{if(a.rating===b.rating)return a.seat-b.seat
if(a.rating===null)return 1
if(b.rating===null)return -1
return b.rating-a.rating})
const chosen=new Set(order.slice(0,take).map((one)=>one.id))
return{take:list.filter((id)=>chosen.has(id)),left:list.filter((id)=>!chosen.has(id))}}
export function planByRules(cards,rules,ctx={}){const safe=sanitizeUnassignedRules(rules)
const list=Array.isArray(cards)?cards.filter((card)=>card&&typeof card==='object'&&int(card.id)!==null):[]
const isLocked=typeof ctx.locked==='function'?ctx.locked:()=>false
const verdicts=[]
const by=new Map(MOVE_KINDS.map((kind)=>[kind,[]]))
const expect=new Map()
const soft=[]
const at=new Map()
const rate=new Map()
let locked=0
let keep=0
let coins=0
let stop=null
for(const card of list){
let shut=false
try{shut=isLocked(card.id)===true}catch{shut=true}
if(shut){locked+=1
verdicts.push({id:card.id,to:'keep',why:'locked'})
continue}
const verdict=judgeCard(card,safe,ctx)
at.set(card.id,verdicts.length)
rate.set(card.id,int(card.rating))
verdicts.push({id:card.id,...verdict})
if(verdict.to==='stop'){if(stop===null)stop={reason:verdict.why,id:card.id,type:card.type??null,subtype:int(card.subtype)}
continue}
if(verdict.to==='keep'){keep+=1
continue}
if(verdict.to==='swap'){
const out=int(card.dupClubId)
const definition=int(card.definitionId)
if(out===null||definition===null){verdicts[verdicts.length-1]={id:card.id,to:'keep',why:'swap-no-id'}
keep+=1
continue}
by.get('club-out').push(out)
expect.set(out,definition)
by.get('club').push(card.id)
continue}
if(verdict.to==='quicksell'){by.get('discard').push(card.id)
coins+=Math.max(0,int(card.discardValue)??0)
continue}
if(verdict.to==='transfer'&&verdict.why==='dupe-unpriced')soft.push(card.id)
by.get(verdict.to)?.push(card.id)}
if(stop!==null)return{ok:false,reason:stop.reason,stop,verdicts,steps:[],cards:0,coins:0,locked,keep,need:{},scenario:'rules',left:{},stays:keep}
const need={transfer:by.get('transfer').length+by.get('club-out').length,storage:by.get('storage').length}
const room=(name)=>{const pile=ctx.capacity?.[name]
const used=int(pile?.used)
const size=int(pile?.size)
return used!==null&&size!==null&&size>=used?size-used:null}
const noRoom=(name,want,free)=>({ok:false,reason:`no-room-${name}`,stop:{reason:`no-room-${name}`,need:want,free},
verdicts,steps:[],cards:0,coins:0,locked,keep,need,scenario:'rules',left:{},stays:keep})
const freeList=room('transfer')
if(freeList!==null&&need.transfer>freeList){const hard=need.transfer-soft.length
if(hard>freeList)return noRoom('transfer',hard,freeList)
const drop=new Set(soft.slice(freeList-hard))
by.set('transfer',by.get('transfer').filter((id)=>!drop.has(id)))
for(const id of drop){const seat=at.get(id)
if(seat!==undefined)verdicts[seat]={id,to:'keep',why:'dupe-unpriced-no-room'}
keep+=1}
need.transfer=freeList}
const freeStore=room('storage')
if(freeStore!==null&&need.storage>freeStore){const fit=fitStorage(by.get('storage'),rate,freeStore)
by.set('storage',fit.take)
for(const id of fit.left){const seat=at.get(id)
if(seat!==undefined)verdicts[seat]={id,to:'keep',why:'storage-no-room'}
keep+=1}
need.storage=fit.take.length}
const steps=[]
for(const kind of STEP_ORDER){const ids=by.get(kind)
if(ids.length===0)continue
const step={kind,ids:[...ids],cards:ids.length}
if(kind==='club-out')step.expect=Object.fromEntries([...expect].filter(([id])=>step.ids.includes(id)))
steps.push(step)}
const count=steps.reduce((sum,step)=>sum+step.cards,0)
if(count===0)return{ok:false,reason:'nothing-to-do',stop:null,verdicts,steps:[],cards:0,coins:0,locked,keep,need,scenario:'rules',left:{},stays:keep}
return{ok:true,reason:null,stop:null,verdicts,steps,cards:count,coins,locked,keep,need,
scenario:'rules',left:{},stays:keep}}
export function planCounts(plan){const moves={}
for(const step of Array.isArray(plan?.steps)?plan.steps:[])moves[step.kind]=step.cards
const why={}
const keepers=[]
for(const verdict of Array.isArray(plan?.verdicts)?plan.verdicts:[]){why[verdict.why]=(why[verdict.why]??0)+1
if(verdict.to==='keep')keepers.push({id:verdict.id,why:verdict.why})}
return{moves,why,keepers,cards:int(plan?.cards)??0,coins:int(plan?.coins)??0,
locked:int(plan?.locked)??0,keep:int(plan?.keep)??0}}
