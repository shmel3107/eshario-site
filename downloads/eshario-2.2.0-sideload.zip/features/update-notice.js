import{createBridgeClient} from '../bridge/page-client.js'
import{createI18n} from '../i18n/index.js'
import{el} from '../ui/dom.js'
export const UPDATE_METHOD='update.check'
export const UPDATE_RELOAD_METHOD='update.reload'
export const UPDATE_BACK_FLOOR_MS=10_000
export const UPDATE_BRIDGE_PREFIX='upd'
export const UPDATE_TICK_MS=3_600_000
export const UPDATE_SITE_ORIGIN='https://eshario.com'
const LINE_SELECTOR='[data-fut-update-line="1"]'
const LINES_CAP=32
const rooms=new WeakMap()
const translators=new Map()
function translatorFor(locale){const key=typeof locale==='string'?locale:''
let t=translators.get(key)
if(t===undefined){t=createI18n({locale:key}).t
translators.set(key,t)}
return t}
function siteHref(value){if(typeof value!=='string')return null
let url
try{url=new URL(value)}catch{return null}
if(url.protocol!=='https:'||url.origin!==UPDATE_SITE_ORIGIN||url.username!==''||url.password!=='')return null
return url}
function zipHref(value,latest){const url=siteHref(value)
if(url===null||url.search!==''||url.hash!=='')return null
const name=url.pathname.split('/').pop()??''
return name.endsWith('.zip')&&name.slice(0,-4).split('-').includes(latest)?url.href:null}
export function viewOf(answer){if(!answer||answer.ok!==true||answer.show!==true)return null
if(typeof answer.latest!=='string'||!/^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(answer.latest))return null
const url=siteHref(answer.download)
if(url===null)return null
const disk=typeof answer.disk==='string'&&/^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(answer.disk)?answer.disk:null
return{latest:answer.latest,download:url.href,zip:zipHref(answer.zip,answer.latest),
ready:answer.ready===true&&disk!==null,disk:disk}}
function partsOf(view,t,stage){if(stage==='reloading')return[{text:t('update.refresh')}]
if(stage==='same')return[{text:t('update.same')}]
if(view.ready)return[{text:t('update.unpacked',{version:view.disk})},{text:' '},
{text:t('update.reload'),act:'reload',title:t('update.reloadHint')}]
if(view.zip===null)return[{text:t('update.line',{version:view.latest}),href:view.download}]
return[{text:t('update.lead',{version:view.latest})},{text:' '},{text:t('update.zip'),href:view.zip},
{text:' · '},{text:t('update.how'),href:view.download}]}
function roomOf(win,deps){let room=rooms.get(win)
if(room!==undefined)return room
room={win,ask:typeof deps.ask==='function'?deps.ask:null,
reload:typeof deps.reload==='function'?deps.reload:null,answer:null,asks:0,error:null,started:false,
stage:null,reloading:false,lastAsk:0,timer:null,lines:new Set(),places:new Map(),seen:new WeakSet(),t:new WeakMap(),
setInterval:typeof deps.setInterval==='function'?deps.setInterval:win.setInterval?.bind(win)}
rooms.set(win,room)
return room}
export function ensureUpdateNotice(win,deps={}){if(!win)return null
const room=roomOf(win,deps??{})
if(room.started)return room
room.started=true
if(room.ask===null||room.reload===null){try{const client=createBridgeClient(win,{prefix:UPDATE_BRIDGE_PREFIX})
if(room.ask===null)room.ask=(params)=>client.request(UPDATE_METHOD,params)
if(room.reload===null)room.reload=()=>client.request(UPDATE_RELOAD_METHOD,{})}catch(err){room.error=String(err?.message??err)
if(room.ask===null)return room}}
attachInstrument(room)
watchReturn(room)
void check(room,false)
try{if(typeof room.setInterval==='function'){room.timer=room.setInterval(()=>{void check(room,false)},UPDATE_TICK_MS)
room.timer?.unref?.()}}catch(err){room.error=String(err?.message??err)}
return room}
function watchReturn(room){const again=()=>{const now=Date.now()
if(now-room.lastAsk<UPDATE_BACK_FLOOR_MS)return
void check(room,false)}
try{const doc=room.win.document
if(doc&&typeof doc.addEventListener==='function'){doc.addEventListener('visibilitychange',()=>{if(doc.visibilityState==='hidden')return
again()})}
if(typeof room.win.addEventListener==='function')room.win.addEventListener('focus',again)}catch(err){room.error=String(err?.message??err)}}
async function check(room,force){room.asks+=1
room.lastAsk=Date.now()
try{const answer=await room.ask(force?{force:true}:{})
room.answer=answer&&typeof answer==='object'?answer:null
room.error=null}catch(err){
room.error=String(err?.message??err)}
paintAll(room)
return report(room)}
function paintLine(room,node){const view=viewOf(room?.answer)
if(view===null){if(node.hidden!==true)node.hidden=true
return}
const t=room.t.get(node)??translatorFor('')
const parts=partsOf(view,t,room.stage)
const key=JSON.stringify(parts)
if(node.dataset.futUpdateKey!==key){const doc=node.ownerDocument
node.textContent=''
for(const part of parts){node.appendChild(partNode(doc,part,room))}
node.dataset.futUpdateKey=key}
if(node.hidden!==false)node.hidden=false}
function paintAll(room){for(const node of[...room.lines]){if(node.isConnected===true)room.seen.add(node)
else if(room.seen.has(node)){room.lines.delete(node)
continue}
paintLine(room,node)}
while(room.lines.size>LINES_CAP)room.lines.delete(room.lines.values().next().value)
for(const[root,opts]of[...room.places]){if(root.isConnected===true)room.seen.add(root)
else if(room.seen.has(root)){room.places.delete(root)
continue}
syncPlace(room,root,opts)}
while(room.places.size>LINES_CAP)room.places.delete(room.places.keys().next().value)}
const stop=(event)=>{event?.stopPropagation?.()}
function partNode(doc,part,room){if(part.href!==undefined)return el(doc,'a',{text:part.text,
attrs:{href:part.href,target:'_blank',rel:'noopener noreferrer'}})
if(part.act==='reload')return el(doc,'button',{class:'fx-update-act',text:part.text,
attrs:{type:'button',title:part.title??''},on:{click:()=>{void askReload(room)}}})
return el(doc,'span',{text:part.text})}
async function askReload(room){if(room.reloading)return null
if(typeof room.reload!=='function'){room.error='нет руки перезагрузки'
return null}
room.reloading=true
try{const answer=await room.reload()
room.stage=answer&&answer.ok===true&&answer.reloading===true?'reloading'
:answer&&answer.reason==='same-version'?'same':room.stage
room.error=null}catch(err){room.error=String(err?.message??err)}finally{room.reloading=false}
paintAll(room)
return room.stage}
const lineNode=(doc)=>el(doc,'span',{class:'fx-update-line',dataset:{futUpdateLine:'1'},
on:{pointerdown:stop,mousedown:stop,click:stop}})
export function updateLine(doc,opts={}){const node=lineNode(doc)
node.hidden=true
const room=bind(node,doc,opts)
if(room!==null)paintLine(room,node)
return node}
function bind(node,doc,opts){const win=opts?.win??doc?.defaultView??null
if(!win)return null
const room=ensureUpdateNotice(win,opts?.deps??{})
if(room===null)return null
room.t.set(node,typeof opts?.t==='function'?opts.t:translatorFor(opts?.locale))
room.lines.add(node)
return room}
export function placeUpdateLine(root,opts){if(!root||typeof root.appendChild!=='function')return null
const win=opts?.win??opts?.doc?.defaultView??null
if(!win)return null
const room=ensureUpdateNotice(win,opts?.deps??{})
if(room===null)return null
room.places.set(root,opts)
return syncPlace(room,root,opts)}
function syncPlace(room,root,opts){const found=root.querySelector?.(LINE_SELECTOR)??null
if(viewOf(room.answer)===null){if(found!==null)found.remove?.()
return null}
const t=typeof opts?.t==='function'?opts.t:translatorFor(opts?.locale)
if(found!==null){room.t.set(found,t)
paintLine(room,found)
return found}
if(typeof opts?.onShow==='function')opts.onShow()
const node=lineNode(opts.doc)
room.t.set(node,t)
paintLine(room,node)
root.appendChild(node)
return node}
function report(room){const view=viewOf(room.answer)
const answer=room.answer??{}
return{asks:room.asks,show:view!==null,latest:typeof answer.latest==='string'?answer.latest:null,
own:typeof answer.own==='string'?answer.own:null,sideload:answer.sideload===true,
download:view?.download??null,zip:view?.zip??null,disk:view?.disk??null,ready:view?.ready===true,
stage:room.stage,state:answer.state??null,
lines:[...room.lines].filter((node)=>node.isConnected===true).length,
places:[...room.places.keys()].filter((root)=>root.isConnected===true).length,error:room.error}}
function attachInstrument(room){try{const box=room.win.__eshario
if(box&&typeof box==='object'&&typeof box.update!=='function'){box.update=(what)=>(what==='check'?check(room,true):report(room))}}catch{/* ручки не будет, строка всё равно живёт */}}
