export const EA_TAX_RATE=0.05
export function taxFor(price){const value=toCoins(price)
if(value<=0)return 0
return Math.round(value*EA_TAX_RATE)}
export function netAfterTax(price){const value=toCoins(price)
if(value<=0)return 0
return value-taxFor(value)}
export function priceForNet(net){const target=toCoins(net)
if(target<=0)return 0
let price=Math.ceil(target / (1 - EA_TAX_RATE));
while(price>1&&netAfterTax(price-1)>=target)price-=1;
while(netAfterTax(price)<target)price+=1;
return price}
function toCoins(value){const num=Number(value);
if(!Number.isFinite(num))return 0;
return Math.max(0,Math.round(num))}
