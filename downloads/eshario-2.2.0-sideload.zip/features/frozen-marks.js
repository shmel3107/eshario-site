import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{TRANSFER_LIST_FEATURE,TRANSFER_LIST_SELECTOR,repaintTransferMoney} from './transfer-list.js'
import{cardFrozenKey} from './card-frozen.js'
import{detailsCardOf} from '../adapter/item-details.js'
const BADGE_SELECTOR='[data-fut-frozen]'
export const FROZEN_FEATURE=TRANSFER_LIST_FEATURE
const ROW_CLASS='listFUTItem'
const SURFACE_SELECTOR=TRANSFER_LIST_SELECTOR
const CARD_SELECTOR='.item'
const FROZEN_STYLESHEET=new URL('../ui/frozen-marks.css',import.meta.url).href
const FROZEN_LINK_ID='fut-companion-frozen-marks'
export const MAX_FROZEN_DRAWS_PER_PASS=40
export function createFrozenMarks(deps={}){const{doc,win=null,t}=deps
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const itemOf=typeof deps.itemOf==='function'?deps.itemOf:()=>null
const frozenIds=typeof deps.frozenIds==='function'?deps.frozenIds:null
const isFrozen=typeof deps.isFrozen==='function'?deps.isFrozen:null
const setFrozen=typeof deps.setFrozen==='function'?deps.setFrozen:null
const onNotice=typeof deps.onNotice==='function'?deps.onNotice:()=>{}
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const painted=new WeakMap()
let epoch=0
let framePending=false
let told=false
let last=null
let scheduled=false
let stats={screens:[],anchors:0,drawn:0,removed:0,missed:0,frozen:0,capped:false,reason:'not-run'}
function apply(capture){if(!doc||!capture?.root)return record({reason:'no-capture'})
last={root:capture.root,item:capture.item}
if(scheduled)return record({reason:'pending'})
scheduled=true
Promise.resolve().then(()=>{scheduled=false
try{refresh()}catch(err){onError(err)}})
return record({reason:'pending'})}
function refresh(){if(!doc?.querySelectorAll)return record({reason:'no-doc'})
if(!safeActive()){const removed=dropAll()
return record({reason:'off',removed})}
if(!frozenIds||!isFrozen||!setFrozen)return record({reason:'no-storage'})
const records=[]
const screens=[]
const seen=new Set()
let anchors=0
let roots=0
let rows=0
for(const root of doc.querySelectorAll(SURFACE_SELECTOR)??[]){roots+=1
for(const row of root.querySelectorAll?.(`.${ROW_CLASS}`)??[]){if(seen.has(row))continue
seen.add(row)
rows+=1
records.push({host:row,item:safeItem(row),cardSelector:CARD_SELECTOR})}}
anchors+=roots
screens.push({id:'transfer',roots,rows})
const panelCard=roots>0&&last?.root?detailsCardOf(last.root):null
if(panelCard&&!seen.has(panelCard)){seen.add(panelCard)
anchors+=1
records.push({host:panelCard,item:last.item,cardSelector:null})}
screens.push({id:'details',roots:panelCard?1:0,rows:panelCard?1:0})
const items=[]
for(const one of records){if(one.item&&typeof one.item==='object')items.push(one.item)}
const frozen=new Set(safeFrozen(items))
let drawn=0
let removed=0
let missed=0
let capped=false
for(const one of records){const{host,item,cardSelector}=one
const id=item&&typeof item==='object'?safeKey(item):null
const on=id!==null&&frozen.has(id)
const current=painted.get(host)
if(current&&current.item===item&&current.on===on&&current.epoch===epoch&&alive(current.node))continue
if(id===null){if(drop(host,cardSelector))removed+=1
painted.set(host,{item,on,node:null,epoch})
continue}
if(drawn>=MAX_FROZEN_DRAWS_PER_PASS){capped=true
break}
const card=cardSelector===null?host:(host.querySelector?.(cardSelector)??null)
if(!card){painted.delete(host)
missed+=1
continue}
const node=mount(card,id,on)
if(!node){painted.delete(host)
missed+=1
continue}
painted.set(host,{item,on,node,epoch})
drawn+=1}
if(capped)nextFrame()
return record({reason:null,screens,anchors,drawn,removed,missed,frozen:frozen.size,capped})}
function mount(card,id,on){if(typeof card.appendChild!=='function')return null
ensureStyles()
host(card)
let node=card.querySelector?.(BADGE_SELECTOR)??null
if(!node){node=el(doc,'button',{class:'fut-frozen-badge',attrs:{type:'button'},dataset:{futFrozen:'1'},
on:{click:(event)=>{
event?.preventDefault?.()
event?.stopPropagation?.()
try{toggle(node)}catch(err){onError(err)}}}},[el(doc,'i',{class:'fut-frozen-ray'})])
card.appendChild(node)}
if(node.dataset)node.dataset.futFrozenId=String(id)
paint(node,on)
return node}
function keyOf(node){const value=Number(node?.dataset?.futFrozenId)
return Number.isSafeInteger(value)&&value>0?value:null}
function frozenById(id){if(id===null||!isFrozen)return false
try{return isFrozen(id)===true}catch(err){onError(err)
return false}}
function wordOf(on){if(!on)return 'frozen.notice.off'
if(told)return 'frozen.notice.on'
told=true
return 'frozen.notice.first'}
function flip(id){if(id===null||!setFrozen)return{ok:false,reason:'no-storage',id,on:frozenById(id)}
const on=!frozenById(id)
const done=setFrozen(id,on)
if(done){try{onNotice({key:wordOf(on),params:{}})}catch(err){onError(err)}
try{repaintTransferMoney()}catch(err){onError(err)}}
paintAll()
return{ok:done,reason:done?null:'refused',id,on:done?on:frozenById(id)}}
function toggle(node){return flip(keyOf(node)).ok}
function paint(node,on){const state=on?'1':'0'
if(node.dataset&&node.dataset.futFrozenOn!==state)node.dataset.futFrozenOn=state
if(typeof node.setAttribute!=='function'||typeof t!=='function')return
let title=''
try{title=t(on?'frozen.badge.on':'frozen.badge.off')}catch{return}
if(node.getAttribute('title')===title)return
node.setAttribute('title',title)
node.setAttribute('aria-label',title)}
function paintAll(){let count=0
for(const node of doc?.querySelectorAll?.(BADGE_SELECTOR)??[]){paint(node,frozenById(keyOf(node)))
count+=1}
return count}
function host(card){if(card.dataset?.futFrozenHost==='1')return
let position=''
try{position=doc?.defaultView?.getComputedStyle?.(card)?.position??''}catch{position=''}
if(position!=='static'||!card.style)return
card.dataset.futFrozenHost='1'
card.dataset.futFrozenPosition=card.style.position??''
card.style.position='relative'}
function drop(hostNode,cardSelector=CARD_SELECTOR){const mark=painted.get(hostNode)
const node=hostNode.querySelector?.(BADGE_SELECTOR)??null
if(!node&&!mark?.node)return false
node?.remove?.()
mark?.node?.remove?.()
restore(cardSelector===null?hostNode:(hostNode.querySelector?.(cardSelector)??null))
return true}
function dropAll(){let count=0
for(const node of doc?.querySelectorAll?.(BADGE_SELECTOR)??[]){restore(node.parentNode)
node.remove?.()
count+=1}
return count}
function restore(card){if(card?.dataset?.futFrozenHost!=='1')return
if(card.style)card.style.position=card.dataset.futFrozenPosition??''
delete card.dataset.futFrozenHost
delete card.dataset.futFrozenPosition}
function nextFrame(){if(framePending)return
const raf=typeof win?.requestAnimationFrame==='function'?win.requestAnimationFrame:null
const timer=typeof win?.setTimeout==='function'?win.setTimeout:null
if(!raf&&!timer)return
framePending=true
let done=false
const go=()=>{if(done)return
done=true
framePending=false
try{refresh()}catch(err){onError(err)}}
if(raf){try{raf.call(win,go)}catch{/* кадра не будет — остаётся таймер */}}
if(timer){try{timer.call(win,go,32)}catch{/* и таймера тоже: подождём прохода */}}}
function ensureStyles(){ensureTheme(doc)
ensureStylesheet(doc,FROZEN_STYLESHEET,FROZEN_LINK_ID)}
function alive(node){return node===null||node===undefined?true:node.isConnected!==false}
function safeActive(){try{return isActive(FROZEN_FEATURE)===true}catch(err){onError(err)
return false}}
function safeItem(row){try{return itemOf(row)??null}catch(err){onError(err)
return null}}
function safeKey(item){try{return cardFrozenKey(item)}catch(err){onError(err)
return null}}
function safeFrozen(items){try{const answer=frozenIds(items)
return Array.isArray(answer)?answer:[]}catch(err){onError(err)
return[]}}
function record(next){stats={screens:[],anchors:0,drawn:0,removed:0,missed:0,frozen:0,capped:false,...next}
return stats}
function relabel(){epoch+=1
refresh()
return true}
return{apply,refresh,relabel,
state:()=>({active:safeActive(),reason:stats.reason,screens:stats.screens,anchors:stats.anchors,
drawn:doc?.querySelectorAll?.(BADGE_SELECTOR)?.length??0,
drawnLastPass:stats.drawn,removed:stats.removed,missed:stats.missed,frozen:stats.frozen,capped:stats.capped,
available:Boolean(frozenIds&&isFrozen&&setFrozen),
shown:Array.from(doc?.querySelectorAll?.(BADGE_SELECTOR)??[],(node)=>({id:keyOf(node),on:node.dataset?.futFrozenOn==='1'}))}),
toggleShown(){const id=last?.item?safeKey(last.item):null
if(id===null)return{ok:false,reason:'no-card',id:null,on:false}
return flip(id)},
dispose(){dropAll()
last=null}}}
