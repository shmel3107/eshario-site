export const FROZEN_KEEP=16
const keyOf=(challenge)=>{if(challenge===null||challenge===undefined)return null
const text=String(challenge)
return text===''?null:text}
const slotOf=(challenge,mark)=>{const key=keyOf(challenge)
return key===null?null:`${key}|${String(mark??'')}`}
const idOf=(value)=>{const text=String(value??'')
return text===''?null:text}
export function solutionIds(result){const ids=new Set()
const push=(value)=>{const id=idOf(value)
if(id!==null)ids.add(id)}
for(const row of Array.isArray(result?.lineup)?result.lineup:[])push(row?.id)
for(const one of Array.isArray(result?.mine)?result.mine:[])push(typeof one==='object'&&one!==null?one.id:one)
for(const item of Array.isArray(result?.prepared?.selection)?result.prepared.selection:[])push(item?.id)
return ids}
export function createFrozenStore(deps={}){const keep=Number.isSafeInteger(deps.keep)&&deps.keep>0?deps.keep:FROZEN_KEEP
const now=typeof deps.now==='function'?deps.now:()=>Date.now()
const signatureOf=typeof deps.signatureOf==='function'?deps.signatureOf:()=>''
const box=new Map()
const stats={hits:0,misses:0,puts:0,drops:0,invalidations:0,finds:0,findMisses:0}
let invalidatedBy=null
let lastSolvedAt=null
let epoch=0
const fits=(entry,squad)=>squad===undefined||entry.squad===squad
return{
get(challenge,mark,squad){const slot=slotOf(challenge,mark)
if(slot===null)return null
const entry=box.get(slot)??null
if(entry===null||!fits(entry,squad)){stats.misses+=1
if(entry!==null)box.delete(slot)
return null}
stats.hits+=1
return entry},
find(challenge,squad){const key=keyOf(challenge)
if(key===null)return null
let best=null
for(const entry of box.values()){if(entry.challenge!==key)continue
if(!fits(entry,squad))continue
if(best===null||entry.solvedAt>=best.solvedAt)best=entry}
stats.finds+=1
if(best===null)stats.findMisses+=1
return best},
put(challenge,entry){const key=keyOf(challenge)
if(key===null||!entry||typeof entry!=='object')return false
const mark=String(entry.mark??'')
const slot=slotOf(key,mark)
if(!box.has(slot)&&box.size>=keep){const oldest=box.keys().next().value
if(oldest!==undefined)box.delete(oldest)}
const at=now()
lastSolvedAt=at
let signature=''
try{signature=String(signatureOf(entry.squad??null)?.signature??'')}catch{signature=''}
box.set(slot,{challenge:key,result:entry.result??null,warn:entry.warn??null,solvedAt:Number.isFinite(entry.solvedAt)?entry.solvedAt:at,
ids:entry.ids instanceof Set?entry.ids:solutionIds(entry.result),mark,squad:entry.squad??null,signature,
from:typeof entry.from==='string'?entry.from:'live'})
stats.puts+=1
return true},
invalidate(ids,why='items-gone'){const gone=new Set()
for(const id of Array.isArray(ids)?ids:[]){const one=idOf(id)
if(one!==null)gone.add(one)}
if(gone.size===0)return[]
const dropped=new Set()
for(const[slot,entry]of box){let touched=false
for(const id of gone){if(entry.ids.has(id)){touched=true
break}}
if(!touched)continue
box.delete(slot)
dropped.add(entry.challenge)}
if(dropped.size>0){stats.invalidations+=1
stats.drops+=dropped.size
invalidatedBy={why:String(why),ids:[...gone].slice(0,12),challenges:[...dropped],at:now()}}
return[...dropped]},
drop(challenge,why='dropped'){const key=keyOf(challenge)
if(key===null)return false
let count=0
for(const[slot,entry]of box){if(entry.challenge!==key)continue
box.delete(slot)
count+=1}
if(count===0)return false
stats.drops+=count
invalidatedBy={why:String(why),ids:[],challenges:[key],at:now()}
return true},
dropAll(why='dropped-all'){epoch+=1
const count=box.size
if(count===0)return 0
const challenges=[...new Set([...box.values()].map((entry)=>entry.challenge))]
box.clear()
stats.drops+=count
invalidatedBy={why:String(why),ids:[],challenges,at:now()}
return count},
epoch(){return epoch},
has(challenge){const key=keyOf(challenge)
if(key===null)return false
for(const entry of box.values())if(entry.challenge===key)return true
return false},
clear(){box.clear()
epoch+=1
invalidatedBy=null
lastSolvedAt=null},
state(){return{size:box.size,keep,epoch,solvedAt:lastSolvedAt,invalidatedBy:invalidatedBy===null?null:{...invalidatedBy},
...stats,
challenges:[...box.values()].map((entry)=>({challenge:entry.challenge,cards:entry.ids.size,at:entry.solvedAt,from:entry.from,
field:entry.signature===''?'нет подписи':'есть'}))}}}}
