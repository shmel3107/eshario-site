import{taxFor,netAfterTax,priceForNet,EA_TAX_RATE} from './tax.js'
import{parseLimitInput} from '../automation/limits-input.js'
export const TAX_FEATURE='eaTax'
export const TAX_RATE_PERCENT=Math.round(EA_TAX_RATE*1000) / 10;
export const UNVERIFIED_NOTICE=Object.freeze({key:'tax.unverified',params:{}})
export function taxRows(text){const parsed=parseLimitInput(text)
if(!parsed.ok) return empty([{key:'tax.badInput',params:{}}])
if(parsed.value===null)return empty([])
const price=parsed.value
const tax=taxFor(price)
const net=netAfterTax(price)
return{ok:true,price,tax,net,rows:[{key:'tax.taken',params:{coins:tax}},{key:'tax.net',params:{coins:net}},UNVERIFIED_NOTICE]}}
export function listingRows(text){const parsed=parseLimitInput(text)
if(!parsed.ok) return{ok:false,net:null,price:null,rows:[{key:'tax.badInput',params:{}}]}
if(parsed.value===null)return{ok:true,net:null,price:null,rows:[]}
const net=parsed.value
const price=priceForNet(net)
return{ok:true,net,price,rows:[{key:'tax.listAt',params:{coins:price}},UNVERIFIED_NOTICE]}}
export function netLine(price){const value=Number(price)
if(!Number.isFinite(value)||value<=0)return null
return{key:'tax.net',params:{coins:netAfterTax(value)}}}
export function profitOf(price,boughtFor){const value=Number(price)
if(!Number.isFinite(value)||value<=0)return null
const net=netAfterTax(value)
if(net<=0)return null
const spent=Number(boughtFor)
const paid=Number.isFinite(spent)&&spent>0?Math.round(spent):0
const coins=net-paid
return{coins,net,positive:coins>=0,percent:Math.round((coins/net)*100)}}
function empty(rows){return{ok:rows.length===0,price:null,tax:null,net:null,rows}}
