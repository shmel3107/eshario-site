import{ensureControls,logoLink} from '../ui/controls.js'
import{ensureStylesheet} from '../ui/dom.js'
import{pressNode} from './hotkey-bind.js'
export const DROPDOWN_SEARCH_BUILD='DROP1-1'
export const DROPDOWN_SEARCH_FEATURE='dropdownSearch'
export const ORGAN_CLASS='inline-list-select'
export const OPEN_CLASS='is-open'
export const OPEN_SELECTOR='.inline-list-select.is-open'
export const BOX_SELECTOR='.inline-container'
export const LIST_SELECTOR='ul.inline-list'
export const HOST_MARK='data-fut-dd-host'
export const HOST_KEY='futDdHost'
export const OFF_MARK='data-fut-dd-off'
export const OFF_KEY='futDdOff'
export const CURSOR_MARK='data-fut-dd-cursor'
export const CURSOR_KEY='futDdCursor'
export const EMPTY_MARK='data-fut-dd-empty'
export const EMPTY_KEY='futDdEmpty'
export const FIELD_CLASS='fx-dd'
export const INPUT_CLASS='fx-dd-input'
export const EMPTY_CLASS='fx-dd-empty'
export const GUARDED_GESTURE=Object.freeze(['pointerdown','pointerup','mousedown','mouseup','click','touchstart','touchend'])
const STYLESHEET=new URL('../ui/dropdown-search.css',import.meta.url).href
const LINK_ID='fut-companion-dropdown-search'
export function fold(value){const text=String(value??'')
let flat=text
try{flat=text.normalize('NFD').replace(/\p{Diacritic}/gu,'')}catch{flat=text}
return flat.toLowerCase().trim()}
export function rowMatches(text,query){const need=fold(query)
if(need==='')return true
return fold(text).includes(need)}
export function createDropdownSearch(deps={}){const doc=deps.doc
if(!doc||typeof doc.createElement!=='function'){throw new Error('dropdown-search: нужен документ')}
const win=deps.win??doc.defaultView??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const hosts=new Map()
let seer=null
let styled=false
const counts={passes:0,wakes:0,attachments:0,removals:0,noObserver:0}
const allowed=()=>{if(typeof deps.isActive!=='function')return false
try{return deps.isActive(DROPDOWN_SEARCH_FEATURE)===true}catch(err){onError(err)
return false}}
const styles=()=>{if(styled)return
try{ensureControls(doc)
ensureStylesheet(doc,STYLESHEET,LINK_ID)
styled=true}catch(err){onError(err)}}
const listOf=(organ)=>{try{return organ?.querySelector?.(LIST_SELECTOR)??null}catch(err){onError(err)
return null}}
const rowsOf=(list)=>{const kids=list?.children
if(!kids)return[]
return Array.prototype.slice.call(kids)}
const markOff=(row,on)=>{if(on)row.dataset[OFF_KEY]='1'
else delete row.dataset[OFF_KEY]}
const cursorOf=(list)=>rowsOf(list).find((row)=>row?.dataset?.[CURSOR_KEY]==='1')??null
const setCursor=(list,row)=>{for(const one of rowsOf(list)){if(one===row)one.dataset[CURSOR_KEY]='1'
else delete one.dataset[CURSOR_KEY]}
if(!row)return
const top=Number(row.offsetTop)
if(Number.isFinite(top)&&list)list.scrollTop=top}
const shownRows=(list)=>rowsOf(list).filter((row)=>row?.dataset?.[OFF_KEY]!=='1')
function filter(host){const list=listOf(host.organ)
if(!list)return
const rows=rowsOf(list)
let first=null
let shown=0
for(const row of rows){const hit=rowMatches(row.textContent,host.input.value)
markOff(row,!hit)
if(hit){shown+=1
if(first===null)first=row}
else if(row.dataset[CURSOR_KEY]==='1')delete row.dataset[CURSOR_KEY]}
if(shown===0)host.field.dataset[EMPTY_KEY]='1'
else delete host.field.dataset[EMPTY_KEY]
if(cursorOf(list)===null)setCursor(list,first)
host.shown=shown}
function onKeyDown(host,event){const key=String(event?.key??'')
const list=listOf(host.organ)
if(!list)return
if(key==='ArrowDown'||key==='ArrowUp'){const rows=shownRows(list)
if(rows.length===0)return
event.preventDefault?.()
const at=rows.indexOf(cursorOf(list))
const step=key==='ArrowDown'?1:-1
const next=at<0?(step>0?0:rows.length-1):Math.min(rows.length-1,Math.max(0,at+step))
setCursor(list,rows[next])
return}
if(key==='Enter'){const rows=shownRows(list)
const row=cursorOf(list)??rows[0]??null
if(!row)return
event.preventDefault?.()
pressNode(row,win,onError)
return}
if(key==='Escape'){event.preventDefault?.()
event.stopPropagation?.()
if(String(host.input.value??'')!==''){host.input.value=''
filter(host)
return}
closeByClickAway()}}
function closeByClickAway(){const Ctor=win?.MouseEvent
const body=doc.body??doc.documentElement
if(typeof Ctor!=='function'||!body?.dispatchEvent)return
try{body.dispatchEvent(new Ctor('click',{bubbles:true,cancelable:true,composed:true}))}catch(err){onError(err)}}
function buildField(host){const wrap=doc.createElement('div')
wrap.className=FIELD_CLASS
try{wrap.appendChild(logoLink(doc,'fx-dd-mark'))}catch(err){onError(err)}
const input=doc.createElement('input')
input.setAttribute('type','search')
input.className=`fx-search ${INPUT_CLASS}`
input.setAttribute('placeholder',t('dropdownSearch.placeholder'))
input.setAttribute('aria-label',t('dropdownSearch.placeholder'))
input.setAttribute('title',t('dropdownSearch.hint'))
input.setAttribute('autocomplete','off')
input.setAttribute('spellcheck','false')
wrap.appendChild(input)
const empty=doc.createElement('div')
empty.className=EMPTY_CLASS
empty.textContent=t('dropdownSearch.empty')
wrap.appendChild(empty)
host.field=wrap
host.input=input
host.empty=empty
return wrap}
function guard(host){const hold=(node,type,handler)=>{node.addEventListener(type,handler)
host.guards.push([node,type,handler])}
const stop=(event)=>{event?.stopPropagation?.()}
for(const type of GUARDED_GESTURE)hold(host.field,type,stop)
hold(host.input,'keyup',(event)=>{event?.stopPropagation?.()})
hold(host.input,'keydown',(event)=>{try{onKeyDown(host,event)}catch(err){onError(err)}})
const typed=()=>{try{filter(host)}catch(err){onError(err)}}
hold(host.input,'input',typed)
hold(host.input,'search',typed)}
function unguard(host){for(const[node,type,handler]of host.guards)node?.removeEventListener?.(type,handler)
host.guards.length=0}
function attach(organ){const box=organ?.querySelector?.(BOX_SELECTOR)??null
const list=listOf(organ)
if(!box||!list)return false
styles()
const host={organ,box,list,field:null,input:null,empty:null,guards:[],shown:0}
buildField(host)
try{box.insertBefore(host.field,list)}catch(err){onError(err)
return false}
guard(host)
organ.dataset[HOST_KEY]='1'
hosts.set(organ,host)
counts.attachments+=1
filter(host)
try{host.input.focus({preventScroll:true})}catch{try{host.input.focus?.()}catch(err){onError(err)}}
return true}
function drop(organ){const host=hosts.get(organ)
if(!host)return false
unguard(host)
const lists=new Set()
const now=listOf(organ)
if(now)lists.add(now)
if(host.list)lists.add(host.list)
for(const list of lists)for(const row of rowsOf(list)){delete row.dataset[OFF_KEY]
delete row.dataset[CURSOR_KEY]}
try{host.field?.remove?.()}catch(err){onError(err)}
delete organ.dataset[HOST_KEY]
hosts.delete(organ)
counts.removals+=1
return true}
function dropAll(){for(const organ of Array.from(hosts.keys()))drop(organ)}
function pass(){counts.passes+=1
if(!allowed()){dropAll()
return}
for(const organ of Array.from(hosts.keys())){const gone=organ.isConnected===false||organ.classList?.contains?.(OPEN_CLASS)!==true
if(gone)drop(organ)}
let open=[]
try{open=Array.from(doc.querySelectorAll?.(OPEN_SELECTOR)??[])}catch(err){onError(err)
return}
for(const organ of open){if(hosts.has(organ))continue
try{attach(organ)}catch(err){onError(err)}}}
function watch(){if(seer!==null)return true
const Observer=win?.MutationObserver
if(typeof Observer!=='function'){counts.noObserver+=1
return false}
try{seer=new Observer((records)=>{let ours=false
for(const record of records??[]){const target=record?.target
if(target?.classList?.contains?.(ORGAN_CLASS)===true){ours=true
break}}
if(!ours&&hosts.size===0)return
counts.wakes+=1
try{pass()}catch(err){onError(err)}})
const root=doc.body??doc.documentElement
seer.observe(root,{attributes:true,attributeFilter:['class'],subtree:true})
return true}catch(err){onError(err)
seer=null
return false}}
return{
mount(){watch()
pass()
return true},
refresh(){pass()},
dispose(){try{seer?.disconnect?.()}catch(err){onError(err)}
seer=null
dropAll()},
state(){const organs=Array.from(hosts.values()).map((host)=>({query:String(host.input?.value??''),shown:host.shown}))
return{build:DROPDOWN_SEARCH_BUILD,feature:DROPDOWN_SEARCH_FEATURE,allowed:allowed(),attached:hosts.size,
watching:seer!==null,styled,organs,...counts}}}}
