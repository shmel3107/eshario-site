import{classifyStatus} from '../adapter/error-codes.js'
export const CHOICE=Object.freeze({SINGLE:'single',PREFERRED:'preferred',AMBIGUOUS:'ambiguous',NOT_FOUND:'not-found',NONE:'none'
})
export const LANDING=Object.freeze({
CREDENTIALS:'credentials',
NO_BUTTON:'no-button',
HIDDEN:'hidden',
BUSY:'busy',
SPENT:'already-pressed',
RUNNING:'login-running',
SESSION:'session-live',
UNKNOWN:'login-unknown',
PRESS:'press',
PRESSED:'pressed',
FAILED:'press-failed',
NO_DOOR:'no-door'})
export function landingVerdict(state){if(!state||typeof state!=='object')return LANDING.NO_DOOR
if(state.credentials===true)return LANDING.CREDENTIALS
if(state.button!==true)return LANDING.NO_BUTTON
if(state.visible!==true)return LANDING.HIDDEN
if(state.disabled===true)return LANDING.BUSY
if(state.spent===true)return LANDING.SPENT
return LANDING.PRESS}
export function loginVerdict(answer){if(!answer||typeof answer!=='object')return LANDING.UNKNOWN
if(answer.running===true)return LANDING.RUNNING
if(answer.session===true)return LANDING.SESSION
if(answer.running!==false||answer.session!==false)return LANDING.UNKNOWN
return LANDING.PRESS}
export function pressLanding(door){let state=null
try{state=door?.read?.()??null}catch{state=null}
const verdict=landingVerdict(state)
const at=Number.isFinite(state?.at)?Math.round(state.at):null
const seen=state?.button===true&&state?.visible===true
if(verdict!==LANDING.PRESS)return{verdict,pressed:false,at,seen}
let answer
try{answer=door?.askLogin?.()}catch{answer=null}
const second=answer===undefined?LANDING.UNKNOWN:loginVerdict(answer)
const asked=answer===undefined?undefined:{running:answer?.running??null,session:answer?.session??null}
if(second!==LANDING.PRESS)return{verdict:second,pressed:false,at,seen,asked}
let ok=false
try{ok=door.press()===true}catch{ok=false}
return{verdict:ok?LANDING.PRESSED:LANDING.FAILED,pressed:ok,at,seen,asked}}
export function createLandingTally(){const seen=Object.create(null)
let last=null
let pressed=false
let lookedAt=null
let seenAt=null
let pressedAt=null
let asked=0
let login=null
let session=null
return{note(step){const verdict=typeof step==='string'?step:step?.verdict
if(typeof verdict!=='string'||verdict==='')return
last=verdict
seen[verdict]=(seen[verdict]??0)+1
if(verdict===LANDING.PRESSED)pressed=true
const at=Number.isFinite(step?.at)?Math.round(step.at):null
if(at!==null&&lookedAt===null)lookedAt=at
if(at!==null&&seenAt===null&&step?.seen===true)seenAt=at
if(at!==null&&pressedAt===null&&verdict===LANDING.PRESSED)pressedAt=at
if(step!==null&&typeof step==='object'&&step.asked!==undefined&&step.asked!==null){asked+=1
login=typeof step.asked.running==='boolean'?step.asked.running:null
session=typeof step.asked.session==='boolean'?step.asked.session:null}},
pressed(){return pressed},
report(){return{last,pressed,seen:{...seen},lookedAt,seenAt,pressedAt,asked,login,session}}}}
export const EMPTY_LANDING=Object.freeze({last:null,pressed:false,seen:Object.freeze({}),lookedAt:null,seenAt:null,pressedAt:null,asked:0,login:null,session:null,previous:null,armed:null})
export function personaId(persona){if(!persona||typeof persona!=='object') return null
const raw=persona.id??null
return raw===null||raw===undefined?null:String(raw)}
export function samePersona(selected,requested){const selectedId=personaId(selected)
const requestedId=personaId(requested)
if(selectedId===null||requestedId===null||selectedId!==requestedId)return false
const requestedSku=requested?.sku
if(requestedSku===undefined||requestedSku===null||requestedSku==='') return true
const selectedSku=selected?.sku
return selectedSku!==undefined
&&selectedSku!==null
&&String(selectedSku)===String(requestedSku)}
export function choosePersona(personas,opts={}){const list=Array.isArray(personas)
?personas.filter((p)=>{const sku=p?.sku;
return personaId(p)!==null&&sku!==undefined&&sku!==null&&sku!==''
})
:[]
if(list.length===0)return{persona:null,reason:CHOICE.NONE}
const preferred=opts.preferredId===undefined||opts.preferredId===null
?null
:String(opts.preferredId)
if(preferred!==null){const match=list.find((p)=>personaId(p)===preferred)
if(match)return{persona:match,reason:CHOICE.PREFERRED}
return{persona:null,reason:CHOICE.NOT_FOUND}}
if(list.length===1)return{persona:list[0],reason:CHOICE.SINGLE}
return{persona:null,reason:CHOICE.AMBIGUOUS}}
export function planRetryDelays(opts={}){
const attempts=Math.max(1,Math.trunc(Number(opts.attempts??8))||1)
const baseMs=Math.max(0,Number(opts.baseMs??500)||0)
const maxMs=Math.max(baseMs,Number(opts.maxMs??8000)||0)
const factor=Math.max(1,Number(opts.factor??2)||1)
const delays=[]
let delay=baseMs
for(let i=1;i<attempts;i++){delays.push(Math.min(Math.round(delay),maxMs))
delay*=factor}
return delays}
export async function runAutologin(options){const{listPersonas,selectPersona,selectedPersona,clock,preferredId,landing=null}=options
if(typeof listPersonas!=='function'
||typeof selectPersona!=='function'
||typeof selectedPersona!=='function'
){throw new Error('autologin: нужны listPersonas, selectPersona и selectedPersona')}
if(!clock||typeof clock.sleep!=='function'){throw new Error('autologin: нужны часы с sleep (правило 6 NIGHT_BRIEF)')}
const delays=planRetryDelays(options)
const totalAttempts=delays.length+1
let lastReason=CHOICE.NONE
const watch=landing
for(let attempt=1;attempt<=totalAttempts;attempt++){if(attempt>1)await clock.sleep(delays[attempt-2])
if(watch!==null)watch.tick()
let personas
try{personas=await listPersonas()}catch(err){if(mustAbort(err)) return fail(err,'aborted',attempt)
lastReason='list-failed'
continue}
const{persona,reason}=choosePersona(personas,{preferredId})
lastReason=reason
if(reason===CHOICE.AMBIGUOUS||reason===CHOICE.NOT_FOUND){return{ok:false,persona:null,reason,attempts:attempt,error:null,landing:watch===null?EMPTY_LANDING:watch.report()}}
if(!persona) continue;// персон ещё нет — приложение не догрузилось
try{await selectPersona(persona)}catch(err){if(mustAbort(err)) return fail(err,'aborted',attempt)
lastReason='select-failed'
continue}
const confirmation=await confirmSelection(persona,selectedPersona,clock,delays)
if(confirmation.ok){return{ok:true,persona,reason,attempts:attempt+confirmation.attempts-1,error:null,landing:watch===null?EMPTY_LANDING:watch.report()}}
return{ok:false,persona:null,reason:'select-unconfirmed',attempts:attempt+confirmation.attempts-1,error:confirmation.error,landing:watch===null?EMPTY_LANDING:watch.report()}}
return{ok:false,persona:null,reason:lastReason,attempts:totalAttempts,error:null,landing:watch===null?EMPTY_LANDING:watch.report()}
function fail(error,reason,attempts){return{ok:false,persona:null,reason,attempts,error,landing:watch===null?EMPTY_LANDING:watch.report()}}}
async function confirmSelection(requested,selectedPersona,clock,delays){let lastError=null
const totalAttempts=delays.length+1
for(let attempt=1;attempt<=totalAttempts;attempt+=1){if(attempt>1)await clock.sleep(delays[attempt-2])
try{const selected=await selectedPersona()
if(samePersona(selected,requested)){return{ok:true,attempts:attempt,error:null}}}catch(err){lastError=err}}
return{ok:false,attempts:totalAttempts,error:lastError}}
function mustAbort(err){const kind=classifyStatus(err?.status)
return kind==='captcha'||kind==='fatal'
}
