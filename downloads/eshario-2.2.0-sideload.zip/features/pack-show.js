export const PACK_SHOW_FEATURE='packShow'
export const SHOW_RATING_DEFAULT=86
export const SHOW_RATING_FLOOR=40
export const SHOW_RATING_CEIL=99
export const PACK_SHOW_DEFAULTS=Object.freeze({always:false,special:true,rating:true,ratingMin:null})
export function sanitizeShowRating(value){return Number.isSafeInteger(value)&&value>=SHOW_RATING_FLOOR&&value<=SHOW_RATING_CEIL?value:null}
export function showRatingOf(policy){return sanitizeShowRating(policy?.ratingMin)??SHOW_RATING_DEFAULT}
export function sanitizePackShowPolicy(stored){const out={...PACK_SHOW_DEFAULTS}
if(!stored||typeof stored!=='object'||Array.isArray(stored))return out
for(const key of ['always','special','rating']){if(typeof stored[key]==='boolean')out[key]=stored[key]}
out.ratingMin=sanitizeShowRating(stored.ratingMin)
return out}
export const PACK_SHOW_MODE=Object.freeze({ALWAYS:'always',VALUABLE:'valuable',NEVER:'never'})
export const PACK_SHOW_MODES=Object.freeze([PACK_SHOW_MODE.ALWAYS,PACK_SHOW_MODE.VALUABLE,PACK_SHOW_MODE.NEVER])
const MODE_PATCH=Object.freeze({
[PACK_SHOW_MODE.ALWAYS]:Object.freeze({always:true,special:true,rating:true}),
[PACK_SHOW_MODE.VALUABLE]:Object.freeze({always:false,special:true,rating:true}),
[PACK_SHOW_MODE.NEVER]:Object.freeze({always:false,special:false,rating:false})})
export function packShowModeOf(stored){const show=sanitizePackShowPolicy(stored)
if(show.always)return PACK_SHOW_MODE.ALWAYS
return show.special||show.rating?PACK_SHOW_MODE.VALUABLE:PACK_SHOW_MODE.NEVER}
export function packShowPatchOf(mode){return typeof mode==='string'&&Object.hasOwn(MODE_PATCH,mode)?{...MODE_PATCH[mode]}:null}
export const PACK_SHOW_MODE_DEFAULT=packShowModeOf(PACK_SHOW_DEFAULTS)
export function packShowVerdict(cards,policy){const rules=sanitizePackShowPolicy(policy)
const ratingMin=showRatingOf(rules)
const list=Array.isArray(cards)?cards:[]
if(rules.always===true)return{show:true,reason:'always',best:null,specials:0,cards:list.length}
if(rules.special!==true&&rules.rating!==true)return{show:false,reason:'off',best:null,specials:0,cards:list.length}
if(list.length===0)return{show:true,reason:'unknown',best:null,specials:0,cards:0}
let best=null
let specials=0
let unknown=false
let rating=false
for(const card of list){const player=card?.player
const value=typeof card?.rating==='number'&&Number.isFinite(card.rating)?card.rating:null
const special=card?.special
if(player!==true&&player!==false){unknown=true
continue}
if(special!==true&&special!==false){unknown=true
continue}
if(player!==true)continue
if(value===null){unknown=true
continue}
if(best===null||value>best)best=value
if(value>=ratingMin)rating=true
if(special===true)specials+=1}
if(rating&&rules.rating===true)return{show:true,reason:'rating',best,specials,cards:list.length}
if(specials>0&&rules.special===true)return{show:true,reason:'special',best,specials,cards:list.length}
if(unknown)return{show:true,reason:'unknown',best,specials,cards:list.length}
return{show:false,reason:'plain',best,specials,cards:list.length}}
export function createPackShow(deps={}){const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const readPolicy=typeof deps.policy==='function'?deps.policy:()=>PACK_SHOW_DEFAULTS
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let contents=null
let lastVerdict=null
const counts={asked:0,shows:0,skips:0,byContents:0,byPresented:0,captured:0,mismatched:0,locked:0}
const queue={asked:0,shows:0,skips:0}
let lastQueue=null
const activeNow=()=>{try{return isActive(PACK_SHOW_FEATURE)===true}catch(err){onError(err)
return null}}
const policyNow=()=>{try{return sanitizePackShowPolicy(readPolicy())}catch(err){onError(err)
return{...PACK_SHOW_DEFAULTS}}}
function noteContents(capture){try{const cards=Array.isArray(capture?.cards)?capture.cards:null
if(!cards)return false
counts.captured+=1
contents={cards,packId:capture?.packId??null,myPack:capture?.myPack??null}
return true}catch(err){onError(err)
return false}}
function decide(context){try{counts.asked+=1
const active=activeNow()
if(active!==true){counts.locked+=1
counts.shows+=1
contents=null
lastVerdict={show:true,reason:active===false?'locked':'failed',source:'none',best:null,specials:0,cards:0}
return{show:true}}
const facts=context?.facts??null
const known=contents?.cards??null
const matched=Array.isArray(known)&&facts?.id!==null&&facts?.id!==undefined
&&known.some((card)=>card?.id!==null&&card?.id===facts.id)
const cards=matched?known:(facts?[facts]:null)
if(matched)counts.byContents+=1
else{counts.byPresented+=1
if(known)counts.mismatched+=1}
contents=null
const verdict=packShowVerdict(cards,policyNow())
if(verdict.show)counts.shows+=1
else counts.skips+=1
lastVerdict={...verdict,source:matched?'contents':'presented'}
return{show:verdict.show}}catch(err){onError(err)
counts.shows+=1
lastVerdict={show:true,reason:'failed',source:'none',best:null,specials:0,cards:0}
return{show:true}}}
function verdict(cards){try{queue.asked+=1
const active=activeNow()
if(active===false){queue.skips+=1
lastQueue={show:false,reason:'locked',best:null,specials:0,cards:Array.isArray(cards)?cards.length:0}
return{show:false,reason:'locked'}}
const answer=packShowVerdict(Array.isArray(cards)?cards:null,policyNow())
if(answer.show)queue.shows+=1
else queue.skips+=1
lastQueue={...answer}
return{show:answer.show===true,reason:answer.reason}}catch(err){onError(err)
queue.shows+=1
lastQueue={show:true,reason:'failed',best:null,specials:0,cards:0}
return{show:true,reason:'failed'}}}
return{noteContents,decide,verdict,
ratingMin:()=>showRatingOf(policyNow()),
state:()=>({active:activeNow(),rule:{ratingMin:showRatingOf(policyNow()),special:'isSpecial() EA'},policy:policyNow(),
pending:contents?{cards:contents.cards.length,packId:contents.packId,myPack:contents.myPack}:null,
last:lastVerdict?{...lastVerdict}:null,counts:{...counts},
queue:{counts:{...queue},last:lastQueue?{...lastQueue}:null}}),
dispose(){contents=null}}}
