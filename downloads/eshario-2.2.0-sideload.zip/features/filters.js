export const TYPES=Object.freeze({NUMBER:'number',STRING:'string',BOOLEAN:'boolean',ARRAY:'array'
})
export const FILTER_FIELDS=Object.freeze({
type:{type:TYPES.STRING,default:'any'},category:{type:TYPES.STRING,default:'any'},subtypes:{type:TYPES.ARRAY,default:[]},authenticity:{type:TYPES.STRING,default:'any'},level:{type:TYPES.STRING,default:'any'},rarities:{type:TYPES.ARRAY,default:[]},evolutionStatus:{type:TYPES.STRING,default:'any'},icontraits:{type:TYPES.STRING,default:'any'},playStyle:{type:TYPES.NUMBER,default:-1},
defId:{type:TYPES.ARRAY,default:[]},excludeDefIds:{type:TYPES.ARRAY,default:[]},maskedDefId:{type:TYPES.NUMBER,default:0},position:{type:TYPES.STRING,default:'any'},preferredPositionOnly:{type:TYPES.BOOLEAN,default:false},zone:{type:TYPES.NUMBER,default:-1},nation:{type:TYPES.NUMBER,default:-1},league:{type:TYPES.NUMBER,default:-1},club:{type:TYPES.NUMBER,default:-1},ovrMin:{type:TYPES.NUMBER,default:45},ovrMax:{type:TYPES.NUMBER,default:99},
minBid:{type:TYPES.NUMBER,default:0},maxBid:{type:TYPES.NUMBER,default:0},minBuy:{type:TYPES.NUMBER,default:0},maxBuy:{type:TYPES.NUMBER,default:0},
primaryColor:{type:TYPES.NUMBER,default:0},secondaryColor:{type:TYPES.NUMBER,default:0},academyOnly:{type:TYPES.BOOLEAN,default:false},academySlotId:{type:TYPES.NUMBER,default:-1},excludeLimitedUse:{type:TYPES.BOOLEAN,default:false},excludeTimeEvo:{type:TYPES.BOOLEAN,default:false},untradeables:{type:TYPES.STRING,default:''},
sortBy:{type:TYPES.STRING,default:'value'},sort:{type:TYPES.STRING,default:'desc'},count:{type:TYPES.NUMBER,default:20},offset:{type:TYPES.NUMBER,default:0},isExactSearch:{type:TYPES.BOOLEAN,default:false}})
export const FIELD_NAMES=Object.freeze(Object.keys(FILTER_FIELDS).sort())
export const REACH=Object.freeze({SERVER:'server',SERVER_VIA:'server-via',SERVER_PART:'server-part',LOCAL:'local',NONE:'none'})
export const ZONES=Object.freeze({DEFENDERS:130,MIDFIELDERS:131,ATTACKERS:132,OUTFIELD:133})
export const ZONE_NONE=-1
export const FIELD_VALUES=Object.freeze({zone:Object.freeze([ZONE_NONE,...Object.values(ZONES)])})
export const FIELD_REACH=Object.freeze({
authenticity:REACH.SERVER,category:REACH.SERVER,club:REACH.SERVER,count:REACH.SERVER,icontraits:REACH.SERVER,league:REACH.SERVER,level:REACH.SERVER,maskedDefId:REACH.SERVER,maxBid:REACH.SERVER,maxBuy:REACH.SERVER,minBid:REACH.SERVER,minBuy:REACH.SERVER,nation:REACH.SERVER,offset:REACH.SERVER,playStyle:REACH.SERVER,position:REACH.SERVER,primaryColor:REACH.SERVER,rarities:REACH.SERVER,secondaryColor:REACH.SERVER,type:REACH.SERVER,
defId:REACH.SERVER_PART,zone:REACH.SERVER_PART,
subtypes:REACH.SERVER_VIA,
excludeDefIds:REACH.LOCAL,ovrMax:REACH.LOCAL,ovrMin:REACH.LOCAL,preferredPositionOnly:REACH.LOCAL,
academyOnly:REACH.NONE,academySlotId:REACH.NONE,evolutionStatus:REACH.NONE,excludeLimitedUse:REACH.NONE,excludeTimeEvo:REACH.NONE,isExactSearch:REACH.NONE,sort:REACH.NONE,sortBy:REACH.NONE,untradeables:REACH.NONE})
export function reachOf(field){return Object.hasOwn(FIELD_REACH,field)?FIELD_REACH[field]:null}
export const FORMAT_VERSION=1
export function isValidValue(field,value){const meta=Object.hasOwn(FILTER_FIELDS,field)?FILTER_FIELDS[field]:null
if(!meta)return false
if(Object.hasOwn(FIELD_VALUES,field))return FIELD_VALUES[field].includes(value)
switch(meta.type){case TYPES.NUMBER:return typeof value==='number'&&Number.isFinite(value)
case TYPES.STRING:return typeof value==='string'
case TYPES.BOOLEAN:return typeof value==='boolean'
case TYPES.ARRAY:return Array.isArray(value)
default:return false}}
export function defaultCriteria(){const out={}
for(const name of FIELD_NAMES){const value=FILTER_FIELDS[name].default
out[name]=Array.isArray(value)?[...value]:value}
return out}
export function sanitizeCriteria(values){const criteria=defaultCriteria()
const unknownFields=[]
const invalid=[]
if(!values||typeof values!=='object'||Array.isArray(values)){return{criteria,unknown:unknownFields,invalid}}
for(const[name,value]of Object.entries(values)){if(!Object.hasOwn(FILTER_FIELDS,name)){unknownFields.push(name);continue}
if(!isValidValue(name,value)){invalid.push(name);continue}
criteria[name]=Array.isArray(value)?[...value]:value}
return{criteria,unknown:unknownFields.sort(),invalid:invalid.sort()}}
export function isDefault(field,value){if(!Object.hasOwn(FILTER_FIELDS,field))return false
const fallback=FILTER_FIELDS[field].default
if(Array.isArray(fallback)){return Array.isArray(value)&&value.length===fallback.length
&&value.every((item,i)=>item===fallback[i])}
return value===fallback}
export function changedFields(criteria){const out={}
for(const name of FIELD_NAMES){if(!Object.hasOwn(criteria??{},name))continue
if(!isDefault(name,criteria[name]))out[name]=criteria[name]}
return out}
export function splitCriteria(criteria){const values=criteria??{}
const server={},local={},dead=[]
const copy=(value)=>Array.isArray(value)?[...value]:value
for(const name of FIELD_NAMES){if(!Object.hasOwn(values,name))continue
const value=values[name]
const reach=FIELD_REACH[name]
if(Object.hasOwn(FIELD_VALUES,name)&&!FIELD_VALUES[name].includes(value)){dead.push(name)
continue}
if(reach===REACH.SERVER||reach===REACH.SERVER_VIA){server[name]=copy(value)
continue}
if(reach===REACH.SERVER_PART){server[name]=copy(value)
if(!isDefault(name,value))local[name]=copy(value)
continue}
if(isDefault(name,value))continue
if(reach===REACH.LOCAL){local[name]=copy(value)
continue}
dead.push(name)}
return{server,local,dead}}
export function createFilterSet(input={}){const{criteria,unknown:unknownFields,invalid}=sanitizeCriteria(input.criteria)
return{id:typeof input.id==='string'?input.id.trim():'',name:typeof input.name==='string'?input.name.trim():'',criteria,unknown:unknownFields,invalid}}
export function serializeFilterSet(set){const normalized=createFilterSet(set)
const changed=changedFields(normalized.criteria)
const payload={v:FORMAT_VERSION,id:normalized.id,name:normalized.name,criteria:sortKeys(changed)}
return JSON.stringify(payload)}
export function parseFilterSet(json){if(typeof json!=='string'||json===''){return{ok:false,reason:'empty',set:null,unknown:[],invalid:[]}}
let payload
try{payload=JSON.parse(json)}catch{return{ok:false,reason:'not-json',set:null,unknown:[],invalid:[]}}
if(!payload||typeof payload!=='object'||Array.isArray(payload)){return{ok:false,reason:'not-an-object',set:null,unknown:[],invalid:[]}}
const set=createFilterSet({id:payload.id,name:payload.name,criteria:payload.criteria})
return{ok:true,reason:null,set,unknown:set.unknown,invalid:set.invalid,version:Number.isInteger(payload.v)?payload.v:null}}
function sortKeys(obj){const out={}
for(const key of Object.keys(obj).sort())out[key]=obj[key]
return out}
