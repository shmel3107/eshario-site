import{ensureStylesheet} from '../ui/dom.js'
import{identityOf,ITEM_PILE} from './club-analysis.js'
import{inDetailColumn} from './card-views.js'
import{SCREEN_SELECTOR as STORAGE_SCREEN} from '../adapter/storage-screen.js'
import{PRICE_BADGE_SURFACES} from './price-badges.js'
import{PACK_PEEK_SURFACE} from './pack-peek.js'
export const DIM_OWNED_FEATURE='dimOwned'
export const DIM_OWNED_SURFACES=Object.freeze([...PRICE_BADGE_SURFACES,PACK_PEEK_SURFACE])
export const DIM_OWNED_MARK='futDimOwned'
export const DIM_OWNED_SELECTOR='[data-fut-dim-owned]'
export const DIM_OWNED_STRENGTH=0.62
const ROW_CLASS='listFUTItem'
const STYLESHEET=new URL('../ui/dim-owned.css',import.meta.url).href
const LINK_ID='fut-companion-dim-owned'
export function pileOf(item){if(!item||typeof item!=='object')return null
let value=null
try{value=item.pile}catch{value=null}
if(!Number.isFinite(value)){try{value=item.utasPile}catch{value=null}}
return Number.isFinite(value)?value:null}
export function ownedIdsFrom(items,clubPile=ITEM_PILE.CLUB){const ids=new Set()
if(!Array.isArray(items))return ids
for(const item of items){if(pileOf(item)!==clubPile)continue
const id=identityOf(item)
if(id!==null)ids.add(id)}
return ids}
let owned=new Set()
let ownedGeneration=null
let ownedBuilds=0
export function noteClubPool(peek,clubPile=ITEM_PILE.CLUB){const players=Array.isArray(peek?.players)?peek.players:null
if(players===null){owned=new Set()
ownedGeneration=null
return owned}
const generation=Number.isFinite(peek?.generation)?peek.generation:null
if(generation!==null&&generation===ownedGeneration)return owned
owned=ownedIdsFrom(players,clubPile)
ownedGeneration=generation
ownedBuilds+=1
return owned}
export function dimOwnedPeek(){return{ids:owned.size,generation:ownedGeneration,builds:ownedBuilds}}
export function forgetClubPool(){owned=new Set()
ownedGeneration=null
ownedBuilds=0}
function dropRow(row){if(row?.dataset?.[DIM_OWNED_MARK]===undefined)return false
try{delete row.dataset[DIM_OWNED_MARK]}catch{return false}
return true}
export function dropAllDimMarks(doc){let removed=0
for(const row of doc?.querySelectorAll?.(DIM_OWNED_SELECTOR)??[])if(dropRow(row))removed+=1
return removed}
const singleRoots=new Set()
const singleItems=new WeakMap()
export function noteDimOwnedCard(root,item){if(!root||typeof root!=='object')return false
if(!item||typeof item!=='object'){singleItems.delete(root)
singleRoots.delete(root)
dropRow(root)
return false}
singleItems.set(root,item)
singleRoots.add(root)
return true}
export function forgetDimOwnedCards(){singleRoots.clear()}
export function detailScreenAllowed(root,surfaces){const split=splitViewOf(root)
if(split===null)return false
for(const surface of surfaces){for(const screen of split.querySelectorAll?.(`.${surface.rootClass}`)??[]){
if(surface.rootClass==='ut-club-search-results-view'&&!isStorageScreen(screen))continue
return true}}
return false}
function splitViewOf(node){for(let at=node?.parentNode??null;at;at=at.parentNode??null){
if(String(at.className??'').split(/\s+/).includes('ut-split-view'))return at}
return null}
export function dimOwnedRows(options={}){const{doc,itemOf}=options
const done={dimmed:0,cleared:0,rows:0}
if(!doc||typeof itemOf!=='function'||!Array.isArray(options.surfaces))return done
if(!safeActive(options.isActive))return{...done,cleared:dropAllDimMarks(doc)}
const ids=options.owned instanceof Set?options.owned:owned
let dimmed=0
let cleared=0
let rows=0
const seen=new Set()
for(const surface of options.surfaces){for(const root of doc.querySelectorAll?.(`.${surface.rootClass}`)??[]){
const forbidden=(surface.rootClass==='ut-club-search-results-view'&&!isStorageScreen(root))
||(surface.detail==='pinned'&&inDetailColumn(root))
for(const row of root.querySelectorAll?.(`.${ROW_CLASS}`)??[]){if(seen.has(row))continue
seen.add(row)
rows+=1
if(forbidden){if(dropRow(row))cleared+=1
continue}
const item=itemOf(row)
const id=item&&typeof item==='object'?identityOf(item):null
if(id===null||!ids.has(id)){if(dropRow(row))cleared+=1
continue}
if(row.dataset?.[DIM_OWNED_MARK]==='1'){dimmed+=1
continue}
ensureStylesheet(doc,STYLESHEET,LINK_ID)
try{row.dataset[DIM_OWNED_MARK]='1'
dimmed+=1}catch{/* чужой узел без dataset: метка просто не встанет */}}}}
for(const root of[...singleRoots]){
if(root?.isConnected===false){singleRoots.delete(root)
singleItems.delete(root)
continue}
const item=singleItems.get(root)??null
const id=item&&typeof item==='object'?identityOf(item):null
if(id===null||!ids.has(id)||!detailScreenAllowed(root,options.surfaces)){if(dropRow(root))cleared+=1
continue}
if(root.dataset?.[DIM_OWNED_MARK]==='1'){dimmed+=1
continue}
ensureStylesheet(doc,STYLESHEET,LINK_ID)
try{root.dataset[DIM_OWNED_MARK]='1'
dimmed+=1}catch{/* чужой узел без dataset: метка просто не встанет */}}
return{dimmed,cleared,rows}}
function isStorageScreen(root){try{return root?.matches?.(STORAGE_SCREEN)===true}catch{return false}}
function safeActive(isActive){if(typeof isActive!=='function')return false
try{return isActive(DIM_OWNED_FEATURE)===true}catch{return false}}
export function createDimOwned(deps={}){const doc=deps.doc??null
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const itemOf=typeof deps.itemOf==='function'?deps.itemOf:()=>null
const surfaces=Array.isArray(deps.surfaces)?deps.surfaces:DIM_OWNED_SURFACES
const pool=deps.pool??null
const clubPile=Number.isFinite(deps.clubPile)?deps.clubPile:ITEM_PILE.CLUB
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let last={dimmed:0,cleared:0,rows:0}
return{DIM_OWNED_FEATURE,
note(root,item){try{return noteDimOwnedCard(root,item)}catch(err){onError(err)
return false}},
refresh(){try{
if(pool!==null&&typeof pool.peek==='function')noteClubPool(pool.peek(),clubPile)
last=dimOwnedRows({doc,isActive,itemOf,surfaces})
return last}catch(err){onError(err)
return last}},
state:()=>({active:safeActive(isActive),...last,...dimOwnedPeek()}),
dispose(){try{dropAllDimMarks(doc)}catch(err){onError(err)}}}}
