import { seasonOf, seasonFits } from '../adapter/season.js'
export const DEMAND_MEMORY_SCHEMA = 1
export const DEMAND_WINDOW_MS = 14 * 24 * 60 * 60 * 1000
export const DEMAND_TOUCH_MS = 60 * 60 * 1000
const SERVICE_FIELDS = ['slots', 'supply']
export function classKey(cls) {
if (!cls || typeof cls !== 'object' || Array.isArray(cls)) return null
const entries = Object.entries(cls).filter(([field, value]) => value !== undefined && !SERVICE_FIELDS.includes(field))
if (entries.length === 0) return null
entries.sort(([a], [b]) => (a < b ? -1 : 1))
return JSON.stringify(entries)
}
const serviceMark = (cls) => SERVICE_FIELDS.map((field) => `${field}=${cls?.[field] ?? ''}`).join(';')
const ratingKey = (value) => {
const rating = Math.round(Number(value))
return Number.isSafeInteger(rating) && rating >= 1 && rating <= 99 ? rating : null
}
export function unionClasses(live, remembered) {
const seen = new Set()
const out = []
for (const list of [live, remembered]) {
for (const cls of Array.isArray(list) ? list : []) {
const key = classKey(cls)
if (key === null || seen.has(key)) continue
seen.add(key)
out.push(cls)
}
}
return out
}
export function unionRatings(live, remembered) {
const out = new Set()
for (const list of [live, remembered]) {
for (const value of Array.isArray(list) ? list : []) {
const rating = ratingKey(value)
if (rating !== null) out.add(rating)
}
}
return [...out].sort((a, b) => a - b)
}
export function encodeMemory(seen, ratings, season = null) {
const rows = []
for (const [, entry] of seen ?? []) rows.push([entry.at, entry.cls])
const marks = []
for (const [rating, entry] of ratings ?? []) marks.push([entry.at, rating])
const out = { v: DEMAND_MEMORY_SCHEMA, c: rows, r: marks }
if (Number.isSafeInteger(season)) out.s = season
return out
}
export function decodeMemory(raw, season = null) {
const out = { classes: [], ratings: [] }
if (!raw || typeof raw !== 'object' || raw.v !== DEMAND_MEMORY_SCHEMA) return out
if (!seasonFits(raw.s, season)) return out
for (const row of Array.isArray(raw.c) ? raw.c : []) {
if (!Array.isArray(row) || row.length < 2) continue
const [at, cls] = row
if (!Number.isFinite(at) || at < 0) continue
if (classKey(cls) === null) continue
out.classes.push({ at, cls })
}
for (const row of Array.isArray(raw.r) ? raw.r : []) {
if (!Array.isArray(row) || row.length < 2) continue
const [at, value] = row
const rating = ratingKey(value)
if (!Number.isFinite(at) || at < 0 || rating === null) continue
out.ratings.push({ at, rating })
}
return out
}
export function createDemandMemory(deps = {}) {
const seen = new Map()
const marks = new Map()
const storage = deps.storage ?? null
const schedule = typeof deps.schedule === 'function' ? deps.schedule : (fn) => { fn() }
const now = typeof deps.now === 'function' ? deps.now : () => 0
const onError = typeof deps.onError === 'function' ? deps.onError : () => {}
const windowMs = Number.isFinite(deps.windowMs) && deps.windowMs > 0 ? deps.windowMs : DEMAND_WINDOW_MS
const seasonNow = typeof deps.season === 'function' ? deps.season : () => seasonOf()
const stats = { noted: 0, refreshed: 0, dropped: 0 }
let loaded = false
let loading = false
let dirty = false
let flushing = false
let writes = 0
let lastWriteAt = null
const touch = () => {
if (loading || storage === null) return
dirty = true
if (flushing) return
flushing = true
schedule(step)
}
function step() {
if (!dirty) { flushing = false; return }
dirty = false
try {
const result = storage?.write?.(encodeMemory(seen, marks, seasonNow()))
writes += 1
lastWriteAt = now()
if (result && typeof result.catch === 'function') result.catch(onError)
} catch (err) { onError(err) }
flushing = false
}
const prune = (at) => {
let dropped = 0
for (const book of [seen, marks]) {
for (const [key, entry] of book) {
if (at - entry.at < windowMs) continue
book.delete(key)
dropped += 1
}
}
if (dropped === 0) return false
stats.dropped += dropped
return true
}
return {
note(classes, ratings) {
const at = now()
let fresh = 0
let changed = prune(at)
for (const cls of Array.isArray(classes) ? classes : []) {
const key = classKey(cls)
if (key === null) continue
const known = seen.get(key)
if (known === undefined) {
seen.set(key, { at, cls, written: at })
stats.noted += 1
fresh += 1
changed = true
continue
}
known.at = at
stats.refreshed += 1
const moved = serviceMark(known.cls) !== serviceMark(cls)
if (moved) known.cls = cls
if (moved || at - known.written >= DEMAND_TOUCH_MS) {
known.written = at
changed = true
}
}
for (const value of Array.isArray(ratings) ? ratings : []) {
const rating = ratingKey(value)
if (rating === null) continue
const known = marks.get(rating)
if (known === undefined) {
marks.set(rating, { at, written: at })
stats.noted += 1
changed = true
continue
}
known.at = at
stats.refreshed += 1
if (at - known.written >= DEMAND_TOUCH_MS) {
known.written = at
changed = true
}
}
if (changed) touch()
return fresh
},
classes() {
if (prune(now())) touch()
return [...seen.values()].map((entry) => entry.cls)
},
ratings() {
if (prune(now())) touch()
return [...marks.keys()].sort((a, b) => a - b)
},
async load() {
if (storage === null) { loaded = true; return 0 }
loading = true
try {
const at = now()
const stored = decodeMemory(await storage.read?.(), seasonNow())
for (const entry of stored.classes) {
if (at - entry.at >= windowMs) { stats.dropped += 1; continue }
const key = classKey(entry.cls)
const known = seen.get(key)
if (known === undefined) seen.set(key, { at: entry.at, cls: entry.cls, written: entry.at })
else if (entry.at > known.at) { known.at = entry.at; known.cls = entry.cls }
}
for (const entry of stored.ratings) {
if (at - entry.at >= windowMs) { stats.dropped += 1; continue }
const known = marks.get(entry.rating)
if (known === undefined) marks.set(entry.rating, { at: entry.at, written: entry.at })
else if (entry.at > known.at) known.at = entry.at
}
} catch (err) { onError(err) } finally { loading = false }
loaded = true
return seen.size
},
state() {
const at = now()
let oldest = null
for (const book of [seen, marks]) {
for (const entry of book.values()) {
const age = at - entry.at
if (oldest === null || age > oldest) oldest = age
}
}
return {
schema: DEMAND_MEMORY_SCHEMA, season: seasonNow(),
classes: seen.size, ratings: marks.size, oldestAgeMs: oldest, windowMs,
loaded, writes, lastWriteAt, pending: dirty, ...stats,
}
},
}
}
