import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{isSellable} from './club-analysis.js'
import{ladderPriceAt} from '../automation/card-value.js'
import{LADDER_MIN_RATING} from './price-ladder.js'
import{createLockedWindow,lockRowOutcome,sanitizeLockSort,SORT_DEFAULT} from './club-locked.js'
import{ensureControls,logoLink,logoMark} from '../ui/controls.js'
import{STORAGE_LOADED} from '../core/storage-provider.js'
import{shortCoins} from './price-badges.js'
export const CLUB_BAR_FEATURE='clubBar'
export const CLUB_HUB_ROOT='.ut-club-hub-view'
export const HUB_GRID='.grid.layout-hub'
export const CONSUMABLES_TILE='.consumables-tile'
export const TILE_CONTENT='.tileContent'
const BAR_STYLESHEET=new URL('../ui/club-bar.css',import.meta.url).href
const BAR_LINK_ID='fut-companion-club-bar'
const BADGE_STYLESHEET=new URL('../ui/sbc-storage.css',import.meta.url).href
const BADGE_LINK_ID='fut-companion-sbc-storage'
const BAR_SELECTOR='[data-fut-club-bar]'
const PINNED_MARK='futClubPinned'
const TILE_SELECTOR='[data-fut-club-tile]'
const TILES_MARK='futClubTiles'
const WIDE_HOSTS=Object.freeze(['.ut-navigation-container-view--content','.ut-split-view','.ut-content'])
const WIDE_STOP='.ut-root-view'
const WIDE_MARK='futClubWide'
const WIDE_SELECTOR='[data-fut-club-wide]'
const SCREEN_MARK='futClubScreen'
const SCREEN_SELECTOR='[data-fut-club-screen]'
export const CLUB_BAR_PINNED_DEFAULT=true
export function defaultClubBarView(){return{pinned:CLUB_BAR_PINNED_DEFAULT,sort:SORT_DEFAULT}}
export function sanitizeClubBarView(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const out=defaultClubBarView()
if(typeof raw.pinned==='boolean')out.pinned=raw.pinned
out.sort=sanitizeLockSort(raw.sort)
return out}
export const PLAYER_TYPE='player'
const int=(value)=>(Number.isSafeInteger(value)?value:null)
export function valueOfRow(rating,definitionId,priceOf,steps){if(priceOf!==null){let own=null
try{const value=priceOf(definitionId)
own=Number.isFinite(value)&&value>0?Math.round(value):null}catch{own=null}
if(own!==null)return{price:own,exact:true}}
if(steps===null||rating<LADDER_MIN_RATING)return null
let step=null
try{step=ladderPriceAt(steps,rating)}catch{step=null}
return Number.isFinite(step)&&step>0?{price:Math.round(step),exact:false}:null}
function ladderStepsOf(read){if(typeof read!=='function')return null
let steps=null
try{steps=read()}catch{steps=null}
return Array.isArray(steps)&&steps.length>0?steps:null}
function lockStatusOf(read){if(typeof read!=='function')return ''
try{return String(read()??'')}catch{return ''}}
export function summarizeClubRows(rows,deps={}){const list=Array.isArray(rows)?rows:[]
const priceOf=typeof deps.priceOf==='function'?deps.priceOf:null
const itemById=typeof deps.itemById==='function'?deps.itemById:null
const steps=ladderStepsOf(deps.ladder)
const status=lockStatusOf(deps.locksStatus)
const out={players:0,sellable:0,locked:0,orphans:0,locks:0,value:0,priced:0,estimated:0,unpriced:0,
cards:list.length,locksStatus:status,locksReady:status===STORAGE_LOADED,lockRows:[]}
const probe={tradable:undefined,untradeable:undefined,state:'',loans:-1,limitedUseType:0}
const byId=new Map()
for(const row of list){if(!row||typeof row!=='object')continue
const id=int(row.i)
if(id!==null&&id>0)byId.set(id,int(row.r)??0)
if(typeof row.t!=='string'||row.t!==PLAYER_TYPE)continue
out.players+=1
probe.tradable=row.u===1?true:row.u===0?false:undefined
probe.state=typeof row.s==='string'?row.s:''
probe.loans=int(row.o)??-1
probe.limitedUseType=int(row.x)??0
if(isSellable(probe))out.sellable+=1
const found=valueOfRow(int(row.r)??0,int(row.d)??0,priceOf,steps)
if(found===null){out.unpriced+=1
continue}
out.value+=found.price
if(found.exact)out.priced+=1
else out.estimated+=1}
if(out.locksReady&&typeof deps.lockedIds==='function'){let locks=[]
try{locks=deps.lockedIds([])}catch{locks=[]}
let marks=[]
try{marks=typeof deps.recreatedIds==='function'?deps.recreatedIds():[]}catch{marks=[]}
const marked=new Set(Array.isArray(marks)?marks:[])
for(const value of Array.isArray(locks)?locks:[]){const id=int(Number(value))
if(id===null||id<=0)continue
out.locks+=1
const rating=byId.get(id)
let item=null
if(itemById!==null){try{item=itemById(id)??null}catch{item=null}}
const made=lockRowOutcome(id,rating===undefined?null:{rating},item,marked.has(id))
out.lockRows.push(made)
if(made.inClub)out.locked+=1
else out.orphans+=1}}
return out}
export function readTileCount(node){if(!node)return null
let box=null
try{box=node.matches?.(TILE_CONTENT)===true?node:(node.querySelector?.(TILE_CONTENT)??null)}catch{box=null}
if(!box)return null
let text=''
try{text=String(box.textContent??'')}catch{return null}
const found=/\d+/.exec(text)
if(found===null)return null
const value=Number(found[0])
return Number.isSafeInteger(value)&&value>=0?value:null}
export function createClubBar(deps={}){const{doc}=deps
const t=typeof deps.t==='function'?deps.t:(key)=>key
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const num=typeof deps.formatNumber==='function'?deps.formatNumber:(value)=>String(value)
const readRows=typeof deps.rows==='function'?deps.rows:()=>[]
const readStamp=typeof deps.stamp==='function'?deps.stamp:()=>''
const readView=typeof deps.view==='function'?deps.view:()=>({})
const writeView=typeof deps.setView==='function'?deps.setView:null
const win=()=>doc?.defaultView??null
const lockedWindow=createLockedWindow({doc,t,formatNumber:num,
facts:()=>{const facts=recount()
return{rows:facts?.lockRows??[],status:facts?.locksStatus??''}},
itemById:deps.itemById,
sort:()=>sanitizeLockSort(readView()?.sort),
setSort:(value)=>{if(writeView===null)return false
try{writeView({sort:sanitizeLockSort(value)})
return true}catch(err){onError(err)
return false}},
setLock:deps.setLock,onError})
const allowed=()=>{if(typeof deps.isActive!=='function')return false
try{return deps.isActive(CLUB_BAR_FEATURE)===true}catch(err){onError(err)
return false}}
const windowReady=typeof deps.itemById==='function'||typeof deps.setLock==='function'
const hasDoor=(view)=>windowReady&&(view.locks>0||view.locksReady!==true)
let passes=0
let counts=0
let paints=0
let opens=0
let framePending=false
let summary=null
let stamped=null
let stampedLocks=null
const painted=new WeakMap()
const pinnedNow=()=>{if(!writeView)return false
try{return sanitizeClubBarView(readView()).pinned}catch(err){onError(err)
return false}}
function nextFrame(){if(framePending)return false
const view=win()
const soon=typeof deps.soon==='function'?deps.soon:null
const raf=typeof view?.requestAnimationFrame==='function'?view.requestAnimationFrame:null
const timer=typeof view?.setTimeout==='function'?view.setTimeout:null
if(!soon&&!raf&&!timer)return false
framePending=true
let done=false
const go=()=>{if(done)return
done=true
framePending=false
try{pass()}catch(err){onError(err)}}
if(soon){try{soon(go)}catch{/* свой планировщик отказал — остаются кадр и таймер */}}
if(raf){try{raf.call(view,go)}catch{/* кадра не будет — остаётся таймер */}}
if(timer){try{timer.call(view,go,32)}catch{/* и таймера тоже: подождём прохода */}}
return true}
function rootOf(){try{return doc?.querySelector?.(CLUB_HUB_ROOT)??null}catch(err){onError(err)
return null}}
function consumablesOf(root){try{return readTileCount(root?.querySelector?.(CONSUMABLES_TILE)??null)}catch(err){onError(err)
return null}}
function locksNow(){if(typeof deps.lockedIds!=='function')return null
let ids
try{ids=deps.lockedIds([])}catch(err){onError(err)
return 'err'}
return Array.isArray(ids)?ids:null}
function sameLocks(before,now){if(before===null||now===null||before==='err'||now==='err')return before===now
if(before.length!==now.length)return false
for(let at=0;at<before.length;at+=1){if(before[at]!==now[at])return false}
return true}
const LOCKS_BUILD='W22B'
function recount(){let stamp=''
try{stamp=String(readStamp())}catch(err){onError(err)
stamp=''}
stamp+=`/${lockStatusOf(deps.locksStatus)}`
const locks=locksNow()
if(summary!==null&&stamp===stamped&&sameLocks(stampedLocks,locks))return summary
let rows=[]
try{rows=readRows()}catch(err){onError(err)
rows=[]}
try{summary=summarizeClubRows(rows,{lockedIds:deps.lockedIds,recreatedIds:deps.recreatedIds,locksStatus:deps.locksStatus,
itemById:deps.itemById,priceOf:deps.priceOf,ladder:deps.ladder})}catch(err){onError(err)
summary=null}
stamped=stamp
stampedLocks=Array.isArray(locks)?locks.slice():locks
counts+=1
return summary}
function mountBar(root){const existing=root.querySelector?.(BAR_SELECTOR)??null
if(existing&&existing.parentNode===root&&root.firstChild===existing)return existing
const node=existing??el(doc,'section',{class:'fx-bar fx-club-bar',dataset:{futClubBar:'1'}})
painted.delete(node)
root.insertBefore(node,root.firstChild)
return node}
function mountTile(root,view){let grid=null
try{grid=root.querySelector?.(HUB_GRID)??null}catch(err){onError(err)
grid=null}
if(!grid)return null
if(grid.dataset&&grid.dataset[TILES_MARK]!=='1')grid.dataset[TILES_MARK]='1'
markWide(root)
const existing=grid.querySelector?.(TILE_SELECTOR)??null
if(!hasDoor(view)){existing?.remove?.()
return null}
const node=existing??el(doc,'div',{
class:'tile col-1-2 fx-club-tile',
dataset:{futClubTile:'1'},
attrs:{role:'button',tabindex:'0',title:t('clubBar.tileHint')},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
openLocked()}}})
if(node.parentNode!==grid){painted.delete(node)
grid.appendChild(node)}
const key=`${view.locked}/${view.locksReady}/${t('clubBar.tileTitle')}`
if(painted.get(node)===key)return node
painted.set(node,key)
while(node.firstChild)node.removeChild(node.firstChild)
node.appendChild(el(doc,'header',{},[el(doc,'h1',{class:'tileHeader',text:t('clubBar.tileTitle')})]))
node.appendChild(el(doc,'div',{class:'tileContent'},[
view.locksReady?null
:el(doc,'span',{class:'fx-club-tile-gone',text:t('clubBar.tileUnknown')})].filter(Boolean)))
node.appendChild(el(doc,'span',{class:'fx-club-tile-badge',dataset:{futClubTileBadge:'1'},
attrs:{'aria-hidden':'false',title:t('clubBar.tileHint')}},[
logoMark(doc,'fx-club-badge-mark'),
el(doc,'span',{class:'fx-club-tile-badge-value',text:view.locksReady?num(view.locked):'–'})]))
node.appendChild(el(doc,'span',{class:'fx-club-tile-lock',dataset:{futClubTileLock:'1'},
attrs:{'aria-hidden':'true'}}))
return node}
function openLocked(){try{if(lockedWindow.open())opens+=1}catch(err){onError(err)}}
function wideHostsOf(root){const found=[]
let node=root?.parentNode??null
for(let depth=0;node&&depth<10;depth+=1){let stop=false
try{stop=node.matches?.(WIDE_STOP)===true}catch{stop=false}
if(stop)break
let hit=false
try{hit=WIDE_HOSTS.some((selector)=>node.matches?.(selector)===true)}catch{hit=false}
if(hit)found.unshift(node)
node=node.parentNode??null}
return found}
function markWide(root){const hosts=wideHostsOf(root)
for(const host of hosts){if(!host?.dataset)continue
if(host.dataset[WIDE_MARK]!=='1')host.dataset[WIDE_MARK]='1'}
if(root?.dataset&&root.dataset[SCREEN_MARK]!=='1')root.dataset[SCREEN_MARK]='1'
return hosts.length}
function clearWide(){let gone=0
const seen=new Set()
for(const selector of[WIDE_SELECTOR,SCREEN_SELECTOR]){for(const node of Array.from(doc?.querySelectorAll?.(selector)??[])){if(seen.has(node))continue
seen.add(node)
if(node.dataset&&node.dataset[WIDE_MARK]!==undefined)delete node.dataset[WIDE_MARK]
if(node.dataset&&node.dataset[SCREEN_MARK]!==undefined)delete node.dataset[SCREEN_MARK]
gone+=1}}
return gone}
function signature(view){return JSON.stringify([view.players,view.sellable,view.locked,view.value,
view.priced,view.estimated,view.unpriced,view.consumables,view.pinned,
view.locks,view.locksReady,
t('clubBar.players',{count:''}),t('clubBar.showLocked')])}
function statNode(key,text,title,zero){const box=el(doc,'span',{class:'fx-club-stat'})
box.appendChild(el(doc,'span',{class:'fx-club-stat-value',text}))
if(title&&typeof box.setAttribute==='function'){try{box.setAttribute('title',title)}catch{/* подпись не важнее числа */}}
if(key&&box.dataset)box.dataset.futClubStat=key
if(zero===true&&box.dataset)box.dataset.futClubZero='1'
return box}
function lockedButton(view){if(!hasDoor(view))return null
return el(doc,'button',{class:'fx-action fx-club-locked',
dataset:{futClubLocked:'1'},
attrs:{type:'button',title:t('clubBar.showLockedHint')},
text:t('clubBar.showLocked'),
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
openLocked()}}})}
function pinButton(pinned){if(!writeView)return null
const button=el(doc,'button',{class:'fx-action fx-action-square fx-club-pin',
dataset:{futClubPin:pinned?'1':'0'},
attrs:{type:'button','aria-pressed':pinned?'true':'false',title:t(pinned?'clubBar.pinOn':'clubBar.pinOff')},
text:'📌'})
button.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{writeView?.({pinned:!pinned})}catch(err){onError(err)}
try{pass()}catch(err){onError(err)}})
return button}
function valueParts(view){const parts=[]
if(view.priced>0)parts.push(t('clubBar.valueExact',{count:num(view.priced)}))
if(view.estimated>0)parts.push(t('clubBar.valueLadder',{count:num(view.estimated)}))
if(view.unpriced>0)parts.push(t('clubBar.valueRest',{count:num(view.unpriced)}))
return parts.join(' · ')}
function valueNode(view){const short=shortCoins(view.value)
const counted=view.priced+view.estimated
if(short===null||counted<=0)return statNode('value',t('clubBar.valueNone'),t('clubBar.valueNoneHint'))
const parts=valueParts(view)
const node=statNode('value',t('clubBar.value',{value:short}),
t('clubBar.valueTitle',{value:num(view.value),parts,total:num(view.players)}))
node.appendChild(el(doc,'span',{class:'fx-club-hint',
text:`${t('clubBar.valueEstimate')} · ${parts}`}))
return node}
function paintBar(root,view){const node=mountBar(root)
const flag=view.pinned?'1':'0'
if(node.dataset&&node.dataset[PINNED_MARK]!==flag)node.dataset[PINNED_MARK]=flag
const key=signature(view)
if(painted.get(node)===key&&node.firstChild)return false
painted.set(node,key)
paints+=1
while(node.firstChild)node.removeChild(node.firstChild)
node.appendChild(logoLink(doc))
if(view.players<=0&&view.cards<=0){node.appendChild(el(doc,'span',{class:'fx-club-empty',text:t('clubBar.empty')}))
node.appendChild(el(doc,'span',{class:'fx-club-tail'},[pinButton(view.pinned)]))
return true}
node.appendChild(statNode('players',t('clubBar.players',{count:num(view.players)})))
node.appendChild(statNode('sellable',t('clubBar.sellable',{count:num(view.sellable)}),t('clubBar.sellableHint'),view.sellable<=0))
node.appendChild(view.locksReady
?statNode('locked',t('clubBar.locked',{count:num(view.locked)}),t('clubBar.lockedHint'),view.locked<=0)
:statNode('locked',t('clubBar.lockedUnknown'),t('clubBar.lockedUnknownHint')))
node.appendChild(valueNode(view))
node.appendChild(statNode('consumables',view.consumables===null
?t('clubBar.consumablesUnknown'):t('clubBar.consumables',{count:num(view.consumables)}),
t('clubBar.consumablesHint')))
node.appendChild(el(doc,'span',{class:'fx-club-tail'},[lockedButton(view),pinButton(view.pinned)]))
return true}
function clearAll(){let gone=0
for(const one of Array.from(doc?.querySelectorAll?.(`${BAR_SELECTOR},${TILE_SELECTOR}`)??[])){one.remove?.()
gone+=1}
for(const grid of Array.from(doc?.querySelectorAll?.(`[data-fut-club-tiles]`)??[])){try{delete grid.dataset[TILES_MARK]}catch{/* чужой узел уже ушёл со страницы */}}
clearWide()
try{lockedWindow.close()}catch(err){onError(err)}
return gone}
function viewNow(root){const facts=recount()??{players:0,sellable:0,locked:0,orphans:0,locks:0,value:0,
priced:0,estimated:0,unpriced:0,cards:0,locksStatus:'',locksReady:false,lockRows:[]}
return{...facts,consumables:consumablesOf(root),pinned:pinnedNow()}}
function pass(){if(!doc)return{ok:false,reason:'no-doc'}
passes+=1
if(!allowed()){const gone=clearAll()
return{ok:true,reason:'off',cleared:gone}}
const root=rootOf()
if(!root){const gone=clearAll()
return{ok:true,reason:'away',cleared:gone}}
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,BAR_STYLESHEET,BAR_LINK_ID)
ensureStylesheet(doc,BADGE_STYLESHEET,BADGE_LINK_ID)
const view=viewNow(root)
const drawn=paintBar(root,view)
mountTile(root,view)
try{lockedWindow.refresh()}catch(err){onError(err)}
return{ok:true,reason:null,drawn,players:view.players,locked:view.locked}}
function report(){const root=rootOf()
const view=root===null?null:viewNow(root)
let stamp=''
try{stamp=String(readStamp())}catch{stamp=''}
return{here:root!==null,feature:CLUB_BAR_FEATURE,allowed:allowed(),
locksBuild:LOCKS_BUILD,
stamp,counted:stamped,
locksStatus:view?.locksStatus??lockStatusOf(deps.locksStatus),
locksReady:view?.locksReady??false,
players:view?.players??null,sellable:view?.sellable??null,
locked:view?.locked??null,locks:view?.locks??null,orphans:view?.orphans??null,
value:view?.value??null,valueShort:view===null?null:shortCoins(view.value),
priced:view?.priced??null,estimated:view?.estimated??null,unpriced:view?.unpriced??null,
ladder:ladderStepsOf(deps.ladder)?.length??null,
consumables:view?.consumables??null,cards:view?.cards??null,
pinned:pinnedNow(),
tile:Boolean(root?.querySelector?.(TILE_SELECTOR)),
tiles:root?.querySelector?.(HUB_GRID)?.dataset?.[TILES_MARK]==='1',
wide:Array.from(doc?.querySelectorAll?.(WIDE_SELECTOR)??[]).length,
windowReady,
window:lockedWindow.state(),
work:{passes,counts,paints,opens},
bar:Boolean(root?.querySelector?.(BAR_SELECTOR)),
styles:Boolean(doc?.getElementById?.(BAR_LINK_ID))}}
return{
refresh(){return nextFrame()},
apply(){return pass()},
relabel(){try{lockedWindow.relabel()}catch(err){onError(err)}
return pass()},
openLocked(){if(!allowed())return false
openLocked()
return lockedWindow.isOpen()},
detach(){return clearAll()},
state:report,
dispose(){try{clearAll()}catch(err){onError(err)}}}}
