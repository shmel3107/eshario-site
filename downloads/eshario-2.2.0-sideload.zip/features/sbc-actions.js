import{solveSquadPaced,submitGuard,isSbcAllowed,isSbcPlayer,sanitizeSbcPolicy,MAX_EVALUATIONS,MAX_ROUNDS,TIME_BUDGET_MS} from '../automation/sbc-solver.js'
import{KEY_NAMES,REQUIREMENT_KEY,COMPARE,COUNT_BASED_KEYS,parseRequirement,parseRequirements,needOf,satisfies,clubOf,linkedClubOf,isMeasurableRequirement,measureRequirement,tierOf,RATING_TIER} from '../automation/sbc-requirements.js'
import{squadRatingExact} from '../automation/squad-rating.js'
import{valuationFrom,burnTotalOf,priceTotalOf,poolReport,duplicateIds,uniqueById,bucketTokenOf,bucketIndexOf,ladderLedger,stampOf,nowMs,BLOB_SLICE_MS,LADDER_FROM_WARM} from './sbc-valuation.js'
import{isLightChallenge,judgeLightSquad,orderByBurn,pickLightSquad} from './sbc-light.js'
import{cardTag} from './club-actions.js'
import{cardLockKey} from './card-locks.js'
import{ctxOf} from './sbc-valuation.js'
import{burnCostOf} from '../automation/card-value.js'
import{tradabilityOf} from './club-analysis.js'
import{floorToValidPrice,nextPrice} from './price-grid.js'
import{sbcIneligibleReason,cardResourceKey} from '../adapter/sbc-submit.js'
import{isVirtualConcept,isConceptItem} from '../adapter/concept-item.js'
import{nameFromEa} from './sbc-chips.js'
export const SBC_FEATURE='sbcSolver'
const REQ_LABEL='sbc.req.'
export const requirementLabelKey=(key)=>`${REQ_LABEL}${KEY_NAMES[key] ?? `UNKNOWN_${key}`}`
export const requirementNameKey=(name)=>`${REQ_LABEL}${typeof name==='string'&&name!==''?name:'UNKNOWN'}`
export const SOLVE_REASON_KEYS=Object.freeze({'unknown-requirement':'sbc.unsupported','unparsed-requirement':'sbc.unsupported','not-enough-players':'sbc.noClub','search-exhausted':'sbc.exhausted','no-solution':'sbc.noSolution',
'invalid-fixed':'sbcWindow.badMine'
})
export function solveReasonKey(reason){return Object.hasOwn(SOLVE_REASON_KEYS,reason)?SOLVE_REASON_KEYS[reason]:'sbc.noSolution'
}
const GUARD_BLOCKER_KEYS=Object.freeze({'empty-squad':'sbcGuard.empty','locked-card':'sbcGuard.locked','active-squad-card':'sbcGuard.active','unbought-virtual':'sbcGuard.unbought','needs-live-chemistry':'sbcGuard.noChemistry','live-chemistry-short':'sbcGuard.chemistryShort','active-unknown':'sbcGuard.activeUnknown','ineligible-item':'sbcGuard.ineligible','duplicate-variation':'sbcGuard.variation',
'guard-unavailable':'sbcGuard.unavailable','policy-unknown':'sbcGuard.policyUnknown','service-blocked':'sbcGuard.serviceBlocked',
'requirements-short':'sbcGuard.reqShort','requirements-unknown':'sbcGuard.reqUnknown','needs-live-player-chemistry':'sbcGuard.noPlayerChemistry',
'recreated-lock':'sbcGuard.recreated'
})
export const ACTIVE_UNKNOWN='active-unknown'
const INELIGIBLE_ITEM='ineligible-item'
const DUPLICATE_VARIATION='duplicate-variation'
const RECREATED_LOCK='recreated-lock'
export function poolForSearch(club,taken=[]){
const list=uniqueById(club)
const hand=new Set()
for(const item of Array.isArray(taken)?taken:[]){const key=cardResourceKey(item)
if(key!==null)hand.add(key)}
if(hand.size===0)return list
return list.filter((item)=>{const key=cardResourceKey(item)
return key===null||!hand.has(key)})}
export function searchableCards(candidates,protectedIds){const policy=sanitizeSbcPolicy()
const shield=Array.isArray(protectedIds)?protectedIds:[]
return(Array.isArray(candidates)?candidates:[]).filter((item)=>isSbcAllowed(item,policy,shield))}
export function shieldCensus(candidates,protectedIds,lockedIds,freeSize){const eligible=searchableCards(candidates,[])
const free=searchableCards(candidates,protectedIds).length
const locks=new Set((Array.isArray(lockedIds)?lockedIds:[]).map((id)=>String(id)))
const shielded=Math.max(0,eligible.length-free)
const locked=Math.min(eligible.filter((item)=>locks.has(String(item?.id??item?.itemId))).length,shielded)
return{free,eligible:eligible.length,locked,active:Math.max(0,shielded-locked),
need:Number.isFinite(freeSize)?freeSize:null,
enough:Number.isFinite(freeSize)?eligible.length>=freeSize:false}}
const PER_CARD_REQUIREMENTS=Object.freeze(new Set([REQUIREMENT_KEY.PLAYER_QUALITY]))
function countedRequirement(req){if(!Number.isFinite(req?.count))return false
if(Array.isArray(req?.combined)){
return req.combined.length>0&&!req.combined.some((entry)=>entry?.key===REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS)}
return COUNT_BASED_KEYS.has(req?.key)}
function holdsFor(card,req,opts){const have=measureRequirement({players:[card]},req,opts)
return have!==undefined&&satisfies(req.compare,have,needOf(req))}
function countsFor(card,req,opts){return measureRequirement({players:[card]},req,opts)===1}
export function scarcityOf(input={}){const cards=Array.isArray(input.cards)?input.cards:[]
if(cards.length===0)return null
const opts=typeof input.linkedTeam==='function'?{linkedTeam:input.linkedTeam}:{}
const counted=[]
const gates=[]
let read=0
let anyCounted=false
for(const req of parseRequirements(input.requirements).requirements){if(!isMeasurableRequirement(req))continue
const need=needOf(req)
if(need===null)continue
read+=1
if(countedRequirement(req)){anyCounted=true
if(need>0&&req.compare!==COMPARE.LOWER)counted.push({req,need})
continue}
if(PER_CARD_REQUIREMENTS.has(req.key))gates.push(req)}
if(counted.length===0)return!anyCounted&&read>0?{noCounted:true}:null
const passes=(card)=>gates.every((req)=>holdsFor(card,req,opts))
const gated=gates.length===0?cards:cards.filter(passes)
let best=null
for(const{req,need}of counted){const candidates=gated.filter((card)=>countsFor(card,req,opts)).length
const ratio=candidates/need
if(best===null||ratio<best.ratio||(ratio===best.ratio&&candidates<best.candidates)){best={req,name:req.name,candidates,need,ratio}}}
if(best===null)return null
const out={name:best.name,candidates:best.candidates,need:best.need}
if(Array.isArray(input.taken))out.fromClub=input.taken.filter((card)=>card?.virtual!==true&&passes(card)&&countsFor(card,best.req,opts)).length
return out}
function footballerCopies(club,taken){const seen=new Set()
let copies=0
for(const item of Array.isArray(taken)?taken:[]){const key=cardResourceKey(item)
if(key!==null)seen.add(key)}
for(const item of Array.isArray(club)?club:[]){const key=cardResourceKey(item)
if(key===null)continue
if(seen.has(key))copies+=1
else seen.add(key)}
return copies}
function linkedTeamsOf(cards,manager,linkedTeam){if(typeof linkedTeam!=='function')return[]
const seen=new Set()
const pairs=[]
const add=(raw)=>{if(!Number.isFinite(raw)||seen.has(raw))return
seen.add(raw)
let linked=raw
try{const told=linkedTeam(raw)
if(Number.isFinite(told))linked=told}catch{
}
if(linked!==raw)pairs.push([raw,linked])}
for(const card of Array.isArray(cards)?cards:[])add(clubOf(card))
add(Number.isFinite(manager?.teamId)?manager.teamId:null)
return pairs}
function fixedOnPitch(slots,ours,size,locked){const list=Array.isArray(slots)?slots:[]
const known=ours instanceof Set?ours:new Set((Array.isArray(ours)?ours:[]).map(String))
const shut=locked instanceof Set?locked:new Set((Array.isArray(locked)?locked:[]).map(String))
const limit=Number.isFinite(size)&&size>0?Math.min(list.length,Math.floor(size)):list.length
const fixed=[]
const ids=new Set()
const dropped=[]
for(let slot=0;slot<limit;slot+=1){let item=null
try{item=list[slot]?.item??null}catch{item=null}
if(!isSbcPlayer(item))continue
if(isConceptItem(item))continue
const id=String(item?.id??'')
if(id===''||id==='0')continue
if(known.has(id)||ids.has(id))continue
if(shut.has(id)){dropped.push(id)
continue}
fixed.push({player:item,slot})
ids.add(id)}
return{fixed,ids,locked:dropped}}
export function duplicateVariationIds(players){const seen=new Set()
const extra=[]
for(const item of Array.isArray(players)?players:[]){const key=cardResourceKey(item)
if(key===null)continue
if(seen.has(key)){const id=String(item?.id??'')
if(id!=='')extra.push(id)}
else seen.add(key)}
return extra}
export function judgeSubmit(input={}){const players=Array.isArray(input.players)?input.players:[]
const known=Array.isArray(input.activeSquadIds)
const verdict=submitGuard({squad:{players},requirements:input.requirements,lockedIds:input.lockedIds,activeSquadIds:known?input.activeSquadIds:[],liveChemistry:input.liveChemistry,offlineChemistry:input.offlineChemistry,
slots:input.slots,squadRef:input.squadRef,operation:input.operation,linkedTeam:input.linkedTeam})
const blockers=[...verdict.blockers]
if(!known)blockers.push({code:ACTIVE_UNKNOWN,confirmable:true})
const unbought=players.filter((item)=>isVirtualConcept(item)).map((item)=>String(item?.id??''))
if(unbought.length>0)blockers.push({code:'unbought-virtual',ids:unbought,confirmable:false})
const ineligible=players.filter((item)=>!isVirtualConcept(item)&&sbcIneligibleReason(item)!==null).map((item)=>String(item?.id??''))
if(ineligible.length>0)blockers.push({code:INELIGIBLE_ITEM,ids:ineligible,confirmable:false})
const variations=duplicateVariationIds(players)
if(variations.length>0)blockers.push({code:DUPLICATE_VARIATION,ids:variations,confirmable:false})
const recreated=recreatedRows(input.recreatedIds)
if(recreated.length>0)blockers.push({code:RECREATED_LOCK,ids:recreated.map((row)=>row.id),confirmable:false})
const names=new Map
for(const item of players){const id=String(item?.id??'')
if(id!=='')names.set(id,cardTag(item,id))}
for(const row of recreated)if(row.name!==null&&!names.has(row.id))names.set(row.id,row.name)
return{allowed:blockers.length===0,blockers,warnings:verdict.warnings,signature:typeof input.signature==='string'?input.signature:null,names}}
function recreatedRows(value){const out=[]
for(const one of Array.isArray(value)?value:[]){const row=one&&typeof one==='object'?one:{id:one}
const id=String(row.id??'').trim()
if(id==='')continue
const name=typeof row.name==='string'&&row.name.trim()!==''?row.name.trim():null
out.push({id,name})}
return out}
export function recreatedLockNotice(ids){const list=recreatedRows(ids)
return list.length===0?null:{key:'sbc.recreatedLock',params:{cards:list.map((row)=>row.name??row.id).join(', ')}}}
export function warmShieldStop(activeIds){return activeIds===null
?{key:'sbc.loadFailed',params:{reason:'active-unknown'}}
:null}
export function guardBlockerKey(code){return Object.hasOwn(GUARD_BLOCKER_KEYS,code)?GUARD_BLOCKER_KEYS[code]:null}
export const MIN_SOLVE_EVALUATIONS=MAX_EVALUATIONS
export const MAX_SOLVE_EVALUATIONS=150_000
const SOLVE_SLICE=500
const SOLVE_PHASES=Object.freeze(['entry','prep','locks','club','ladders','blob','shape','market','search','after','draw'])
const PHASE_WORDS=Object.freeze({entry:'вход',prep:'подготовка',locks:'замки',club:'чтение',
ladders:'лестницы',blob:'ценники',shape:'пул',market:'рынок',
search:'поиск',after:'хвост',draw:'показ'})
const REASON_WORDS=Object.freeze({enter:'вход на экран',run:'рука',redo:'дожим'})
const PREP_WORDS=Object.freeze({'кэш':'из кэша','счёт':'полная','общий':'от прогрева'})
const LADDER_MARK=Object.freeze({'кэш':'к','счёт':'с','общий':'о',[LADDER_FROM_WARM]:'п'})
const LADDER_WORDS=Object.freeze([['general','общая'],['rarity','редкие'],['identity','принадлежность'],['buckets','вёдра']])
function ladderLine(rows){const bits=[]
for(const[name,word]of LADDER_WORDS){const one=rows?.[name]
if(!one||typeof one!=='object')continue
bits.push(`${word} ${Math.round(one.ms??0)}${LADDER_MARK[one.from]??'?'}`)}
return bits.length===0?null:`лестницы: ${bits.join(' · ')}`}
function phaseLine(run){if(run===null)return 'фазы: подбора в этой вкладке ещё не было'
const by=run.by??{}
const notes=run.notes??{}
const names=[...SOLVE_PHASES,...Object.keys(by).filter((one)=>!SOLVE_PHASES.includes(one))]
const sum=names.reduce((all,one)=>all+(by[one]??0),0)
const work=Number.isFinite(notes.searchWork)?notes.searchWork:null
const bits=names.map((name)=>{const word=PHASE_WORDS[name]??name
const ms=Math.round(by[name]??0)
if(name!=='search'||work===null)return `${word} ${ms}`
return `${word} ${ms} (счёт ${Math.round(work)} + кадры ${Math.round((by.search??0)-work)})`})
const passes=Array.isArray(run.passes)?run.passes:[]
bits.push(`заходов ${passes.length} [${passes.map((one)=>Math.round(one)).join(' + ')}]`)
bits.push(`сумма ${Math.round(sum)}`)
if(typeof run.tag==='string'&&run.tag!=='')bits.push(`повод ${REASON_WORDS[run.tag]??run.tag}`)
if(typeof notes.prep==='string')bits.push(`подготовка ${PREP_WORDS[notes.prep]??notes.prep}`)
if(Number.isFinite(notes.warm))bits.push(`прогрев ${Math.round(notes.warm)} в тени входа`)
const ladders=ladderLine(notes.ladders)
if(ladders!==null)bits.push(ladders)
bits.push(`память ${notes.memo===true?'да':'нет'}`)
if(Number.isFinite(notes.candidates)&&Number.isFinite(notes.club))bits.push(`клуб ${notes.candidates}/${notes.club}`)
if(Number.isFinite(notes.ladder))bits.push(`лестница ${notes.ladder}`)
if(Number.isFinite(notes.buckets))bits.push(`вёдра ${notes.buckets}`)
if(Number.isFinite(notes.evaluations))bits.push(`проверок ${notes.evaluations}`)
if(Number.isFinite(notes.pauses))bits.push(`кадров ${notes.pauses}`)
if(typeof notes.mode==='string')bits.push(`режим ${notes.mode}`)
if(typeof notes.reason==='string'&&notes.reason!=='')bits.push(`ответ ${notes.reason}`)
if(typeof notes.timeStopped==='boolean')bits.push(`часы оборвали ${notes.timeStopped?'да':'нет'}`)
return `подбор ${Math.round(run.total)} мс: ${bits.join(' · ')}`}
export function createSolvePhases(opts={}){const clock=typeof opts.now==='function'?opts.now:nowMs
const ladders=opts.ladders===null?null:(opts.ladders??ladderLedger)
let open=null
let last=null
let chains=0
const blank=()=>{const by={}
for(const name of SOLVE_PHASES)by[name]=0
return by}
const close=()=>{const at=clock()
const spent=at-open.mark
open.by[open.phase]=(open.by[open.phase]??0)+spent
open.passes[open.pass-1]=(open.passes[open.pass-1]??0)+spent
open.mark=at}
const stop=()=>{if(open===null)return false
close()
const families=ladders===null?{}:ladders.since(open.ladderSeq)
last={total:open.mark-open.startedAt,by:{...open.by},passes:open.passes.slice(),
notes:{...open.notes,...(Object.keys(families).length>0?{ladders:families}:{})},tag:open.tag}
open=null
return true}
const begin=(tag)=>{const at=clock()
chains+=1
open={id:chains,startedAt:at,mark:at,phase:'entry',pass:1,by:blank(),passes:[0],notes:{},tag:tag??null,
ladderSeq:ladders===null?0:ladders.seq()}
return chains}
const drop=(id)=>{if(open===null)return false
if(id!==undefined&&open.id!==id)return false
open=null
return true}
const isChain=(id)=>open!==null&&open.id===id
const at=(name)=>{if(open===null||typeof name!=='string'||name==='')return false
close()
open.phase=name
return true}
const pass=()=>{if(open===null)return false
close()
open.pass+=1
open.passes[open.pass-1]=0
return true}
const note=(key,value)=>{if(open===null||typeof key!=='string'||key==='')return false
open.notes[key]=value
return true}
const copy=(run)=>run===null?null:{total:run.total,by:{...run.by},passes:run.passes.slice(),
notes:{...run.notes},tag:run.tag}
return{begin,at,pass,note,stop,drop,isChain,running:()=>open!==null,
state:()=>({running:open!==null,last:copy(last),line:phaseLine(last),
ladders:ladders===null?null:ladders.state()})}}
export const solvePhases=createSolvePhases()
export async function pricesForClub(items,deps={}){const priceOf=typeof deps.priceOf==='function'?deps.priceOf:null
if(priceOf===null)throw new Error('sbc: обходу цен нужен читатель цены')
const pause=typeof deps.pause==='function'?deps.pause:null
const clock=typeof deps.now==='function'?deps.now:nowMs
const sliceMs=Number.isFinite(deps.sliceMs)&&deps.sliceMs>0?deps.sliceMs:BLOB_SLICE_MS
const out=new Map()
let since=clock()
for(const item of Array.isArray(items)?items:[]){const id=item?.definitionId??item?.defId
if(!Number.isSafeInteger(id)||id<=0||out.has(id))continue
const price=await priceOf(id)
if(Number.isFinite(price)&&price>0)out.set(id,price)
if(pause===null)continue
if(clock()-since<sliceMs)continue
try{await pause()}catch{return null}
since=clock()}
return out}
export function createPrepCache(){let key=null
let value=null
let flight=null
const seen={hits:0,misses:0,shared:0,aborted:0,moved:0,blind:0}
const keyOf=(stamp)=>{let parts=null
try{parts=typeof stamp==='function'?stamp():stamp}catch{return null}
return stampOf(parts)}
return{
async serve(stamp,build,help={}){const before=keyOf(stamp)
const say=typeof help.onServe==='function'?help.onServe:()=>{}
const pause=typeof help.pause==='function'?help.pause:null
if(before===null){seen.blind+=1
say('счёт')
return build({pause})}
if(key===before&&value!==null){seen.hits+=1
say('кэш')
return value}
if(flight!==null&&flight.key===before){const got=await flight.promise
if(got!==null&&got!==undefined){seen.shared+=1
say('общий')
return got}
seen.aborted+=1}
seen.misses+=1
say('счёт')
const promise=Promise.resolve().then(()=>build({pause}))
flight={key:before,promise}
let built=null
try{built=await promise}finally{if(flight!==null&&flight.key===before)flight=null}
if(built===null||built===undefined)return built
if(keyOf(stamp)===before){key=before
value=built}
else{key=null
value=null
seen.moved+=1}
return built},
state:()=>({warm:key!==null,...seen})}}
function familySize(one){if(Array.isArray(one))return one.length
if(one&&typeof one==='object')return Object.keys(one).length
return null}
export function evaluationBudget(poolSize,squadSize=11){const pool=Number.isFinite(poolSize)&&poolSize>0?Math.floor(poolSize):0
const size=Number.isFinite(squadSize)&&squadSize>0?Math.floor(squadSize):11
const round=size*Math.max(pool-size,0)
return Math.min(MAX_SOLVE_EVALUATIONS,Math.max(MIN_SOLVE_EVALUATIONS,round*MAX_ROUNDS))}
export function solvePercent(done,ceiling){const spent=Number.isFinite(done)&&done>0?done:0
const cap=Number.isFinite(ceiling)&&ceiling>0?ceiling:0
if(cap===0)return 0
return Math.min(99,Math.floor(spent*100/cap))}
const RATING_KEYS=Object.freeze(new Set([REQUIREMENT_KEY.TEAM_RATING]))
const CHEMISTRY_KEYS=Object.freeze(new Set([REQUIREMENT_KEY.CHEMISTRY_POINTS]))
export function meetsLive(requirements,keys,value){const parsed=parseRequirements(requirements).requirements.filter((req)=>keys.has(req.key))
if(parsed.length===0)return null
if(typeof value!=='number'||!Number.isFinite(value))return false
return parsed.every((req)=>{const need=needOf(req)
return need!==null&&satisfies(req.compare,value,need)})}
export function slotPositions(slots){if(!Array.isArray(slots)||slots.length===0)return null
const out=[]
for(const slot of slots){let typeId
try{typeId=slot?.position?.typeId}catch{return null}
if(!Number.isFinite(typeId))return null
out.push(typeId)}
return out}
function liveManager(squad){try{if(squad?.hasManager?.()!==true)return null
const item=squad.getManager?.()?.item
return item&&typeof item==='object'?item:null}catch{return null}}
function liveNumber(read){try{const value=read()
return typeof value==='number'&&Number.isFinite(value)?value:null}catch{return null}}
function lineupOf(players,input={}){const spare=input.spare instanceof Set?input.spare:new Set
const mine=input.mine instanceof Set?input.mine:new Set
const priceOf=typeof input.priceOf==='function'?input.priceOf:null
const concepts=input.concepts instanceof Map?input.concepts:new Map
const named=Array.isArray(input.named)?input.named:[]
return(Array.isArray(players)?players:[]).map((item)=>{const id=String(item?.id??'')
const buy=item?.virtual===true
const price=buy?item?.buyPrice:(priceOf?priceOf(item):null)
return{id,lock:buy?null:cardLockKey(item),name:buy?String(item?.rating??''):cardTag(item,id),
price:Number.isFinite(price)&&price>0?price:null,
duplicate:!buy&&spare.has(id),untradeable:!buy&&tradabilityOf(item)==='untradeable',mine:mine.has(id),
...(buy?{estimate:concepts.get(id)?.live!==true,posEstimate:concepts.get(id)?.attrs?.positionsEstimate===true}:{}),
buy,affiliation:buy?affiliationOf(item,named,input.linkedTeam):null,
...(buy?{definitionId:concepts.get(id)?.definitionId??null}:{}),
rating:Number.isFinite(item?.rating)?item.rating:null}})}
export const CHEAPEN_MIN_COINS=1000
export const CHEAPEN_MIN_SHARE=0.15
export function baselineCostOf(rows,valuation,priceOf,mine){if(!Array.isArray(rows))return undefined
if(!valuation)return null
const owned=rows.filter((one)=>one?.virtual!==true)
const burn=burnTotalOf(owned,valuation,priceOf,mine)
if(burn===null)return null
let spend=0
for(const one of rows){if(one?.virtual!==true)continue
if(!Number.isFinite(one?.buyPrice)||one.buyPrice<=0)return null
spend+=one.buyPrice}
return{cost:burn.cost,spend,unknown:burn.unknown,priced:burn.priced,mine:burn.mine}}
export function columnTotal(column){if(!column||typeof column!=='object')return null
const cost=column.cost
const spend=column.spend
if(!Number.isFinite(cost))return null
if(spend===undefined)return cost
if(!Number.isFinite(spend))return null
return cost+(spend>0?spend:0)}
export function swapOf(baseRows,newRows,valuation,priceOf,mine,named){if(!Array.isArray(baseRows)||!Array.isArray(newRows))return null
const idOf=(one)=>String(one?.id??'')
const after=new Set(newRows.map(idOf))
const before=new Set(baseRows.map(idOf))
const gone=baseRows.filter((one)=>!after.has(idOf(one)))
const came=newRows.filter((one)=>!before.has(idOf(one)))
if(gone.length===0)return null
const ctx=valuation?{...ctxOf(valuation),priceOf:typeof priceOf==='function'?priceOf:undefined}:null
const own=mine instanceof Set?mine:new Set((Array.isArray(mine)?mine:[]).map(String))
const costOf=(one)=>{if(one?.virtual===true)return Number.isFinite(one?.buyPrice)&&one.buyPrice>0?one.buyPrice:0
if(ctx===null)return 0
try{const value=burnCostOf(one,valuation.prices,ctx)
return Number.isFinite(value)?value:0}catch{return 0}}
const list=Array.isArray(named)?named:[]
const face=(one)=>{if(one===null||one===undefined)return null
const id=idOf(one)
const buy=one?.virtual===true
return{id,buy,rating:Number.isFinite(one?.rating)?one.rating:null,
affiliation:buy?affiliationOf(one,list):null,
name:buy?null:cardTag(one,id),mine:own.has(id)}}
const dearest=(rows)=>{let best=null
let bestCost=-Infinity
for(const one of rows){const value=costOf(one)
if(value>bestCost){bestCost=value
best=one}}
return{card:best,cost:bestCost===-Infinity?null:bestCost}}
const out=dearest(gone)
const slot=baseRows.indexOf(out.card)
const sameSlot=slot>=0&&slot<newRows.length?newRows[slot]:null
const arrived=sameSlot!==null&&!before.has(idOf(sameSlot))?sameSlot:dearest(came).card
return{out:{...face(out.card),cost:out.cost,slot:slot>=0?slot:null},in:face(arrived)}}
export function cheaperVerdict(answer,minCoins=CHEAPEN_MIN_COINS,minShare=CHEAPEN_MIN_SHARE){const swap=answer?.swap??null
const blank={ok:false,why:'unknown-cost',savings:0,share:null,before:null,after:null,out:swap?.out??null,in:swap?.in??null}
if(answer?.ok!==true)return{...blank,why:'unfinished'}
const base=answer.baseline??null
const burn=answer.burn??null
if(base===null||base===undefined||burn===null||burn===undefined)return blank
if(base.unknown!==0||burn.unknown!==0)return blank
const before=columnTotal(base)
const after=columnTotal({cost:burn.cost,spend:answer.spend})
if(before===null||after===null)return blank
const savings=before-after
const share=before>0?savings/before:null
const told={savings,share,before,after,out:swap?.out??null,in:swap?.in??null}
if(savings<=0)return{ok:false,why:'no-savings',...told}
if(savings<minCoins||share===null||share<minShare)return{ok:false,why:'below-threshold',...told}
return{ok:true,why:'ok',...told}}
export function phaseReason(answer,redoSpent){const seek=answer?.search
if(seek===null||seek===undefined||typeof seek!=='object')return{kind:null,why:'no-search'}
if(answer?.ok===true)return{kind:'cheapen',why:null}
if(seek.unfinished===true)return redoSpent===true?{kind:'rescue-unfinished',why:null}:{kind:null,why:'redo-pending'}
return{kind:'rescue',why:null}}
export function rescueVerdict(answer){const blank={ok:false,why:'unknown-cost',savings:null,share:null,before:null,after:null,out:null,in:null}
if(answer?.ok!==true)return{...blank,why:answer?.search?.unfinished===true?'unfinished':'no-solution'}
const burn=answer.burn??null
if(burn===null||burn===undefined||burn.unknown!==0)return blank
const after=columnTotal({cost:burn.cost,spend:answer.spend})
if(after===null)return{...blank}
return{ok:true,why:'rescue',savings:null,share:null,before:null,after,out:null,in:null}}
function buysOf(result,prices,named,linkedTeam){const list=Array.isArray(result?.buys)?result.buys:[]
const taken=new Set()
for(const buy of list){const one=conceptSourceOf(buy,prices)
if(Number.isSafeInteger(one?.definitionId))taken.add(one.definitionId)}
return list.map((buy)=>{const source=conceptSourceOf(buy,prices)
return{id:String(buy?.id??''),
alts:altsOfBuy(buy,prices,source,taken),
rating:Number.isFinite(buy?.rating)?buy.rating:null,
price:Number.isFinite(buy?.buyPrice)&&buy.buyPrice>0?buy.buyPrice:null,
definitionId:source?.definitionId??null,
live:source?.live===true,
posEstimate:source?.attrs?.positionsEstimate===true,
posBlind:!(Array.isArray(buy?.possiblePositions)&&buy.possiblePositions.length>0),
teamId:idOrNull(buy?.teamId),leagueId:idOrNull(buy?.leagueId),nationId:idOrNull(buy?.nationId),
affiliation:affiliationOf(buy,named,linkedTeam)}})}
const idOrNull=(value)=>(Number.isSafeInteger(value)&&value>0?value:null)
export function affiliationNamesOf(requirements){const out=[]
for(const raw of Array.isArray(requirements)?requirements:[]){let said=null
try{const text=raw?.buildString?.()
if(typeof text==='string'&&text.trim()!=='')said=text.trim()}catch{said=null}
const req=parseRequirement(raw)
if(req===null)continue
if(Array.isArray(req.combined)){const half=combinedAffiliation(req,said)
if(half!==null)out.push(half)
continue}
const name=nameFromEa(said)
if(name===null)continue
const field=AFFILIATION_FIELD[req.key]
if(field===undefined)continue
const values=(Array.isArray(req.values)?req.values:[]).filter((one)=>Number.isSafeInteger(one)&&one>0)
if(values.length===0)continue
out.push({field,values,name})}
return out}
function combinedAffiliation(req,said){const parts=req.combined
const at=parts.findIndex((one)=>AFFILIATION_FIELD[one?.key]!==undefined)
if(at<0)return null
const field=AFFILIATION_FIELD[parts[at].key]
const value=parts[at].value
if(!Number.isSafeInteger(value)||value<=0)return null
if((Array.isArray(parts[at].values)?parts[at].values:[]).length>1)return null
const head=typeof said==='string'?said.split(EA_COUNT_SPLIT)[0]:''
const names=head===''?[]:head.split(EA_COMBINED_SPLIT)
if(names.length!==parts.length)return null
const name=names[at].trim()
return name===''?null:{field,values:[value],name,combined:true}}
const EA_COMBINED_SPLIT=' + '
const EA_COUNT_SPLIT=': '
const AFFILIATION_FIELD=Object.freeze({[REQUIREMENT_KEY.CLUB_ID]:'teamId',
[REQUIREMENT_KEY.LEAGUE_ID]:'leagueId',[REQUIREMENT_KEY.NATION_ID]:'nationId'})
export function affiliationOf(buy,named,linkedTeam){for(const one of named){const value=buy?.[one.field]
if(!Number.isSafeInteger(value))continue
if(one.field==='teamId'){if(clubMatches(value,one.values,linkedTeam,one.combined===true))return{field:one.field,value,name:one.name}
continue}
if(one.values.includes(value))return{field:one.field,value,name:one.name}}
return null}
function clubMatches(club,values,linkedTeam,combined=false){const mine=linkedClubOf({teamId:club},linkedTeam)
for(const one of Array.isArray(values)?values:[]){
if(combined===true){if(one===mine)return true
continue}
if(one===club||one===mine)return true
if(typeof linkedTeam==='function'&&linkedClubOf({teamId:one},linkedTeam)===mine)return true}
return false}
export const ALT_PICKS=3
export function altsOfBuy(buy,prices,source,taken){const parts=String(buy?.id??'').split(':')
const token=parts.length>3?parts[1]:null
if(token===null||!/^[rlnc]\d+$/.test(token))return[]
const rating=Number.isFinite(buy?.rating)?buy.rating:null
if(rating===null||source===null)return[]
const step=stepsOfBuy(buy,prices).find((one)=>one?.rating===rating)
const picks=Array.isArray(step?.picks)?step.picks:[]
const out=[]
for(let i=copyIndexOf(buy?.id)+1;i<picks.length&&out.length<ALT_PICKS;i+=1){const pick=picks[i]
const id=Number.isSafeInteger(pick?.id)&&pick.id>0?pick.id:null
if(id===null||id===source.definitionId||taken.has(id))continue
out.push({id,price:Number.isFinite(pick?.price)&&pick.price>0?pick.price:null})}
return out}
function copyIndexOf(id){const parts=String(id??'').split(':')
const copy=Number(parts[parts.length-1])
return Number.isSafeInteger(copy)&&copy>=0?copy:0}
export function conceptSourceOf(buy,prices){const rating=Number.isFinite(buy?.rating)?buy.rating:null
if(rating===null||!prices||typeof prices!=='object')return null
const token=bucketTokenOf(buy?.id)
if(token!==null)return bucketSource(bucketIndexOf(prices).get(token)??null,buy,rating)
const steps=stepsOfBuy(buy,prices)
const step=steps.find((one)=>one?.rating===rating)
const picks=Array.isArray(step?.picks)&&step.picks.length>0
?step.picks
:(Number.isSafeInteger(step?.id)&&step.id>0?[{id:step.id,attrs:step.attrs??null}]:[])
const pick=picks[copyIndexOf(buy?.id)]??null
const definitionId=Number.isSafeInteger(pick?.id)&&pick.id>0?pick.id:null
return definitionId===null?null:{definitionId,rating,attrs:pick.attrs??null,
price:Number.isFinite(pick?.price)&&pick.price>0?pick.price:null,
live:pick?.live===true,
...rarityOfBuy(buy)}}
export function tierStepPrice(prices,tier){if(!prices||typeof prices!=='object')return null
const want=Number(tier)
if(!Number.isFinite(want)||want===RATING_TIER.NONE)return null
let best=null
const look=(steps)=>{for(const one of Array.isArray(steps)?steps:[]){const rating=Number(one?.rating)
if(!Number.isFinite(rating)||tierOf({rating})!==want)continue
const price=Number(one?.price)
if(!Number.isFinite(price)||price<=0)continue
if(best===null||price<best)best=price}}
look(prices.ladder)
for(const steps of Object.values(prices.rarityLadders??{}))look(steps)
return best}
function tierFloorOf(failed,prices){const out={}
for(const row of Array.isArray(failed)?failed:[]){if(row?.key!==REQUIREMENT_KEY.PLAYER_LEVEL)continue
const tier=Number(row?.value)
if(!Number.isFinite(tier)||tier===RATING_TIER.NONE)continue
if(Object.hasOwn(out,tier))continue
out[tier]=tierStepPrice(prices,tier)}
return Object.keys(out).length===0?null:out}
function stepsOfBuy(buy,prices){const parts=String(buy?.id??'').split(':')
const token=parts.length>3?parts[1]:null
const family=token===null?null:/^([rlnc])(\d+)$/.exec(token)
if(family!==null){const steps=prices[BUY_FAMILY[family[1]]]?.[Number(family[2])]
return Array.isArray(steps)?steps:[]}
if(parts.length===3&&Array.isArray(prices.ladder))return prices.ladder
const rarity=Number.isFinite(buy?.rareflag)?buy.rareflag:null
const known=rarity!==null?prices.rarityLadders?.[rarity]:null
return Array.isArray(known)?known:(Array.isArray(prices.ladder)?prices.ladder:[])}
function bucketSource(bucket,buy,rating){if(bucket===null||bucket.rating!==rating)return null
const picks=Array.isArray(bucket.picks)?bucket.picks:[]
const pick=picks[copyIndexOf(buy?.id)]??null
const definitionId=Number.isSafeInteger(pick?.id)&&pick.id>0?pick.id:null
return definitionId===null?null:{definitionId,rating,attrs:bucketAttrs(bucket,pick),
price:Number.isFinite(pick?.price)&&pick.price>0?pick.price:null,
live:pick?.live===true,...rarityOfBuy(buy)}}
function bucketAttrs(bucket,pick){const base=pick?.attrs&&typeof pick.attrs==='object'?pick.attrs:null
const own={}
for(const field of BUCKET_ATTRS){const value=bucket?.[field]
if(Number.isSafeInteger(value)&&value>0)own[field]=value}
return Object.keys(own).length===0?base:{...(base??{}),...own}}
const BUCKET_ATTRS=Object.freeze(['leagueId','nationId','teamId'])
function rarityOfBuy(buy){const out={}
if(Number.isSafeInteger(buy?.rareflag)&&buy.rareflag>=0)out.rareflag=buy.rareflag
const groups=Array.isArray(buy?.groups)?buy.groups.filter((one)=>Number.isSafeInteger(one)):[]
if(groups.length>0)out.groups=groups
return out}
const BUY_FAMILY={r:'rarityLadders',l:'leagueLadders',n:'nationLadders',c:'clubLadders'}
const LADDER_FAMILIES=['rarityLadders','leagueLadders','nationLadders','clubLadders']
function marketBlindSpots(requirements,prices,buys){const out=new Set()
const groups=prices?.rarityGroups&&typeof prices.rarityGroups==='object'?prices.rarityGroups:null
for(const req of parseRequirements(requirements).requirements){
if(req?.key===REQUIREMENT_KEY.PLAYER_RARITY_GROUP&&!groupKnown(groups,req?.values))out.add('rarity')
if(CHEMISTRY_BLIND.has(req?.key)&&!buysCarryPositions(prices,buys))out.add('chemistry')
if(neverBought(req)||(Array.isArray(req?.combined)?req.combined:[]).some(neverBought))out.add('ownership')
const need=needOf(req)
const scan=(entry)=>{const dim=BLIND_IDENTITY[entry?.key]
if(dim===undefined)return
if(ladderCards(prices?.[dim.prop],entry?.values)+bucketCards(prices,dim.field,entry?.values)<(Number.isFinite(need)&&need>0?need:1))out.add('identity')}
scan(req)
for(const entry of Array.isArray(req?.combined)?req.combined:[])scan(entry)}
return[...out]}
const BLIND_IDENTITY={[REQUIREMENT_KEY.LEAGUE_ID]:{prop:'leagueLadders',field:'leagueId'},
[REQUIREMENT_KEY.NATION_ID]:{prop:'nationLadders',field:'nationId'},
[REQUIREMENT_KEY.CLUB_ID]:{prop:'clubLadders',field:'teamId'}}
const CHEMISTRY_BLIND=new Set([REQUIREMENT_KEY.CHEMISTRY_POINTS,REQUIREMENT_KEY.ALL_PLAYERS_CHEMISTRY_POINTS])
function neverBought(entry){if(entry?.key===REQUIREMENT_KEY.FIRST_OWNER_PLAYERS_COUNT)return true
return entry?.key===REQUIREMENT_KEY.PLAYER_TRADABILITY&&Number.isFinite(entry?.value)&&entry.value!==0}
function buysCarryPositions(prices,buys){const chosen=Array.isArray(buys)?buys:[]
if(chosen.length>0)return chosen.every((buy)=>Array.isArray(buy?.possiblePositions)&&buy.possiblePositions.length>0)
if(!prices||typeof prices!=='object')return false
const known=(steps)=>{for(const step of Array.isArray(steps)?steps:[]){
for(const pick of Array.isArray(step?.picks)?step.picks:[]){if(Array.isArray(pick?.attrs?.possiblePositions)&&pick.attrs.possiblePositions.length>0)return true}
if(Array.isArray(step?.attrs?.possiblePositions)&&step.attrs.possiblePositions.length>0)return true}
return false}
if(known(prices.ladder))return true
if(known(prices.buckets))return true
for(const family of LADDER_FAMILIES){const ladders=prices[family]
if(!ladders||typeof ladders!=='object')continue
for(const key of Object.keys(ladders)){if(known(ladders[key]))return true}}
return false}
function ladderCards(ladders,values){if(!ladders||typeof ladders!=='object')return 0
let cards=0
for(const value of Array.isArray(values)?values:[]){for(const step of Array.isArray(ladders[value])?ladders[value]:[]){
cards+=Array.isArray(step?.picks)&&step.picks.length>0?step.picks.length
:(Number.isSafeInteger(step?.id)&&step.id>0?1:0)}}
return cards}
function bucketCards(prices,field,values){const list=Array.isArray(prices?.buckets)?prices.buckets:[]
if(list.length===0)return 0
const wanted=new Set(Array.isArray(values)?values:[])
if(wanted.size===0)return 0
let cards=0
for(const bucket of list){if(!wanted.has(bucket?.[field]))continue
cards+=Array.isArray(bucket?.picks)?bucket.picks.length:0}
return cards}
function groupKnown(dictionary,values){if(dictionary===null)return false
const wanted=Array.isArray(values)?values:[]
if(wanted.length===0)return false
for(const key of Object.keys(dictionary)){const member=dictionary[key]
if(Array.isArray(member)&&member.some((group)=>wanted.includes(group)))return true}
return false}
const marketHasCards=(family)=>Array.isArray(family)&&family.length>0
function freeMarket(prices,taken){if(!prices||typeof prices!=='object')return{prices,shop:null}
const seen=new Set()
for(const item of Array.isArray(taken)?taken:[]){const key=cardResourceKey(item)
if(key!==null)seen.add(key)}
const shop={steps:0,picks:0,left:0,base:{picks:0,left:0},identity:{picks:0,left:0},buckets:{picks:0,left:0}}
const prune=(steps,into)=>(Array.isArray(steps)?steps:[]).map((step)=>{const picks=Array.isArray(step?.picks)?step.picks:null
if(picks===null)return step
shop.steps+=1
shop.picks+=picks.length
if(into)into.picks+=picks.length
const left=[]
for(const pick of picks){const key=cardResourceKey({definitionId:pick?.id})
if(key===null||seen.has(key))continue
seen.add(key)
left.push(pick)}
shop.left+=left.length
if(into)into.left+=left.length
return{...step,picks:left}})
const out={...prices}
out.ladder=prune(prices.ladder,shop.base)
if(Array.isArray(prices.buckets))out.buckets=prune(prices.buckets,shop.buckets)
for(const family of LADDER_FAMILIES){const ladders=prices[family]
if(!ladders||typeof ladders!=='object')continue
const cleaned={}
const into=family==='rarityLadders'?null:shop.identity
for(const key of Object.keys(ladders))cleaned[key]=prune(ladders[key],into)
out[family]=cleaned}
return{prices:out,shop}}
function conceptSourcesOf(players,prices){const out=new Map
for(const player of Array.isArray(players)?players:[]){if(player?.virtual!==true)continue
const source=conceptSourceOf(player,prices)
if(source!==null)out.set(String(player?.id??''),source)}
return out}
export function spendOf(result){const asked=result?.spend
if(asked===null||asked===undefined)return(result?.buys?.length??0)>0?null:0
if(!Number.isFinite(asked))return null
return asked>0?asked:0}
function counterweightOf(result){const row=result?.counterweight
if(!row||typeof row!=='object')return null
const num=(value)=>Number.isFinite(value)?value:0
return{tried:num(row.tried),taken:num(row.taken),saved:num(row.saved)}}
function specGateOf(result){const row=result?.specGate
if(!row||typeof row!=='object')return null
const num=(value)=>Number.isFinite(value)?value:0
return{tried:num(row.tried),taken:num(row.taken)}}
function clubGateOf(result){const row=result?.clubGate
if(!row||typeof row!=='object')return null
const num=(value)=>Number.isFinite(value)?value:0
return{tried:num(row.tried),taken:num(row.taken)}}
function lightPlan(input={}){const size=Number.isFinite(input.size)&&input.size>0?Math.floor(input.size):0
const hand=Array.isArray(input.mine?.fixed)?input.mine.fixed:[]
const free=size-hand.length
if(free<=0||!isLightChallenge(input.requirements,input.operation))return null
const allowed=(Array.isArray(input.candidates)?input.candidates:[])
.filter((item)=>isSbcAllowed(item,sanitizeSbcPolicy(),input.protectedIds??[]))
const picks=pickLightSquad({pool:orderByBurn(allowed,{valuation:input.valuation,cachedPriceOf:input.cachedPriceOf}),
requirements:input.requirements,free,taken:hand.map((one)=>one.player),keyOf:input.keyOf})
if(picks===null)return null
const busy=new Set(hand.map((one)=>one.slot))
const freeSlots=[]
for(let slot=0;slot<size;slot+=1)if(!busy.has(slot))freeSlots.push(slot)
const wanted=Array.isArray(input.positions)?freeSlots.map((slot)=>input.positions[slot]):null
const arrange=typeof input.arrange==='function'?input.arrange:null
const native=wanted===null||arrange===null?null:arrange(wanted,picks)
const line=Array.isArray(native)&&native.length===picks.length?native:picks
const fixed=[...hand,...line.map((player,index)=>({player,slot:freeSlots[index]}))]
const verdict=judgeLightSquad({players:fixed.map((one)=>one.player),requirements:input.requirements,operation:input.operation})
return{fixed,native:line!==picks,ok:verdict.ok===true,why:verdict.reason}}
export async function resolveClubPool(deps={}){const fail=(reason)=>({ok:false,notice:{key:'sbc.loadFailed',params:{reason}}})
if(deps.poolFromMemory===true){const seen=typeof deps.peek==='function'?deps.peek():null
const held=Array.isArray(seen?.players)?seen.players:null
if(held===null||held.length===0)return fail('no-club')
if(typeof deps.stale==='function'&&deps.stale()===true)return fail('stale')
return{ok:true,club:held,poolRepeated:0}}
try{const merged=await deps.read()
return{ok:true,club:merged.items,poolRepeated:merged.repeated}}catch(err){return fail(String(err?.message??err))}}
export async function prepareChallenge(deps){
const phases=deps.phases??solvePhases
phases.at('shape')
const challenge=deps.challenge
if(!challenge||typeof challenge!=='object'){return{ok:false,prepared:null,notice:{key:'sbc.loadFailed',params:{reason:'нет challenge'}}}}
const liveSquad=challenge.squad
if(!liveSquad||typeof liveSquad!=='object'){return{ok:false,prepared:null,notice:{key:'sbcWindow.noSquad',params:{}}}}
const requirements=extractRequirements(challenge)??[]
const affiliations=affiliationNamesOf(requirements)
const slots=liveSlots(liveSquad)
const bricks=liveBricks(liveSquad)
const required=requiredPlayers(liveSquad)
const size=Number.isFinite(deps.size)?deps.size:required
const mine=fixedOnPitch(slots,deps.ours,size,deps.lockedIds)
const spare=duplicateIds(deps.club)
const hand=mine.fixed.map((one)=>one.player)
const cards=uniqueById(deps.club)
const candidates=poolForSearch(cards,hand)
const available=searchableCards(candidates,deps.protectedIds)
const valuation=valuationFrom({prices:deps.prices,requirements,club:deps.club,available,
openChallenges:deps.openChallenges,remembered:deps.remembered,rememberedRatings:deps.rememberedRatings})
const pool={...poolReport(deps.club,deps.poolRepeated,typeof deps.cachedPriceOf==='function'?deps.cachedPriceOf:undefined),
candidates:candidates.length,variations:footballerCopies(cards,hand),
shield:shieldCensus(candidates,deps.protectedIds,deps.lockedIds,Math.max(0,size-mine.fixed.length))}
const budget=evaluationBudget(pool.candidates,size)
const slice=Number.isFinite(deps.slice)&&deps.slice>0?Math.floor(deps.slice):SOLVE_SLICE
const pause=typeof deps.pause==='function'?deps.pause:null
const onProgress=typeof deps.onProgress==='function'?deps.onProgress:null
let ceiling=budget
let pauses=0
let percent=-1
let work=0
let mark=0
const paced=pause?()=>{work+=nowMs()-mark
pauses+=1
if(onProgress&&ceiling>0){const next=solvePercent(pauses*slice,ceiling)
if(next>percent){percent=next
try{onProgress(next)}catch{}}}
return Promise.resolve(pause()).then(()=>{mark=nowMs()})}:null
mark=nowMs()
const startedAt=mark
phases.at('market')
const excluded=(Array.isArray(deps.excludeIds)?deps.excludeIds:[]).filter((id)=>Number.isSafeInteger(id)&&id>0).map((id)=>({definitionId:id}))
const pruned=deps.mode==='club+market'&&(marketHasCards(deps.prices?.ladder)||marketHasCards(deps.prices?.buckets))
?freeMarket(deps.prices,[...(Array.isArray(deps.club)?deps.club:[]),...mine.fixed.map((one)=>one.player),...excluded])
:null
const market=pruned===null?null:{prices:pruned.prices}
const shopping=market===null?deps.prices:market.prices
const keyMemo=new WeakMap()
const footballerKeyOf=(player)=>{if(!player||typeof player!=='object')return null
const known=keyMemo.get(player)
if(known!==undefined)return known
let key=null
if(player.virtual===true){const source=conceptSourceOf(player,shopping)
key=source===null?null:cardResourceKey({definitionId:source.definitionId})}
else key=cardResourceKey(player)
keyMemo.set(player,key)
return key}
const positions=slotPositions(slots)
const input={club:candidates,protectedIds:deps.protectedIds,requirements,size,operation:challenge.eligibilityOperation,valuation,footballerKeyOf,
mode:market?'club+market':'club',market,
fixed:mine.fixed,
...(Array.isArray(deps.heir)&&deps.heir.length>0?{__heir:deps.heir}:{}),
...(deps.finish!==null&&typeof deps.finish==='object'?{__finish:deps.finish}:{}),
maxEvaluations:Number.isFinite(deps.evaluationCeiling)&&deps.evaluationCeiling>0?deps.evaluationCeiling:budget,
onBudget:(one)=>{if(Number.isFinite(one?.ceiling)&&one.ceiling>0)ceiling=one.ceiling},
formationPositions:positions,manager:liveManager(liveSquad),
...(bricks.length>0?{bricks}:{}),
cachedPriceOf:typeof deps.cachedPriceOf==='function'?deps.cachedPriceOf:undefined,
floatRating:typeof deps.floatRating==='boolean'?deps.floatRating:null,
linkedTeam:typeof deps.linkedTeam==='function'?deps.linkedTeam:undefined,
timeBudgetMs:Number.isFinite(deps.timeBudgetMs)&&deps.timeBudgetMs>0?deps.timeBudgetMs:undefined,
now:typeof deps.now==='function'?deps.now:undefined,
virtualClock:deps.virtualClock===undefined?undefined:deps.virtualClock}
phases.at('search')
const workAtSearch=work+(nowMs()-mark)
const light=market===null?lightPlan({requirements,operation:challenge.eligibilityOperation,candidates,protectedIds:deps.protectedIds,mine,size,valuation,cachedPriceOf:typeof deps.cachedPriceOf==='function'?deps.cachedPriceOf:undefined,keyOf:footballerKeyOf,positions,arrange:deps.arrange})
:null
const approved=light?.ok===true?light:null
let result=await solveSquadPaced(approved===null?input:{...input,club:[],fixed:approved.fixed},{slice,pause:paced})
const lightMark=light===null?null:approved===null?'refused':result.ok===true?'taken':'refused'
if(approved!==null&&result.ok!==true)result=await solveSquadPaced(input,{slice,pause:paced})
work+=nowMs()-mark
phases.at('after')
const search={evaluations:result.evaluations??null,pool:pool.candidates,budget,slice:paced?slice:null,pauses,work:Math.round(work),ms:Math.round(nowMs()-startedAt),
shaping:result.shaping??null,exhausted:result.exhausted===true||result.reason==='search-exhausted',
starts:result.starts??null,
finish:result.finish??null,
circles:result.circles??null,
deficitPhase:result.deficitPhase??null,
chemOrder:result.chemOrder??null,
solverBudget:result.budget??null,
panic:result.panic??null,
unfinished:result.unfinished===true,
timeBudgetMs:Number.isFinite(deps.timeBudgetMs)&&deps.timeBudgetMs>0?deps.timeBudgetMs:TIME_BUDGET_MS,
live:{protectedIds:(Array.isArray(deps.protectedIds)?deps.protectedIds:[]).map((id)=>String(id)),
fixed:(Array.isArray(mine.fixed)?mine.fixed:[]).map((one)=>({id:String(one?.player?.id??''),slot:one?.slot??null})),
manager:(()=>{const boss=input.manager
return boss&&typeof boss==='object'?{league:boss.leagueId??null,nation:boss.nationId??null,club:boss.teamId??null}:null})(),
linkedTeam:typeof deps.linkedTeam==='function',
linkedTeams:linkedTeamsOf(Array.isArray(deps.club)?deps.club:candidates,input.manager,deps.linkedTeam),
floatRating:typeof deps.floatRating==='boolean'?deps.floatRating:null,
bricks:bricks.map((one)=>({at:one.at,position:one.position,club:one.player.teamId??null,league:one.player.leagueId??null,nation:one.player.nationId??null,positions:[...one.player.possiblePositions]}))},
clusters:result.clusters??null,
light:lightMark,native:light===null?null:light.native,
unmet:Number.isFinite(result.unmet)?result.unmet:null,lack:Number.isFinite(result.lack)?result.lack:null}
phases.note('searchWork',work-workAtSearch)
phases.note('evaluations',search.evaluations)
phases.note('pauses',pauses)
phases.note('slice',search.slice)
phases.note('candidates',pool.candidates)
phases.note('club',pool.size)
phases.note('mode',market===null?'club':'club+market')
phases.note('ladder',familySize(deps.prices?.ladder))
phases.note('buckets',familySize(deps.prices?.buckets))
phases.note('reason',result.ok===true?'ok':String(result.reason??'?'))
phases.note('timeStopped',result.budget?.timeStopped===true)
if(!result.ok){return{ok:false,prepared:null,verdict:null,burn:null,price:null,search,pool,mine:[...mine.ids],market:market!==null,shop:pruned?.shop??null,buys:buysOf(result,shopping,affiliations,deps.linkedTeam),spend:spendOf(result),counterweight:counterweightOf(result),specGate:specGateOf(result),clubGate:clubGateOf(result),marketBlind:market===null?[]:marketBlindSpots(requirements,shopping,result.buys),failed:[...(result.failed??[])],tierFloor:tierFloorOf(result.failed,deps.prices),notice:{key:solveReasonKey(result.reason),params:{reason:result.reason}}}}
const players=result.squad.players
const offlineChemistry=typeof result.squad?.chemistry==='number'?result.squad.chemistry:null
const float=typeof deps.floatRating==='boolean'?deps.floatRating:null
const rating=typeof result.squad?.rating==='number'?result.squad.rating:null
const ratingExact=squadRatingExact({field:players,float})
const owned=players.filter((player)=>player?.virtual!==true)
const concepts=conceptSourcesOf(players,shopping)
const burn=burnTotalOf(owned,valuation,deps.cachedPriceOf,mine.ids)
const price=priceTotalOf(owned,deps.cachedPriceOf)
const baseline=baselineCostOf(deps.baseline,valuation,deps.cachedPriceOf,mine.ids)
const swap=baseline===undefined?undefined:swapOf(deps.baseline,players,valuation,deps.cachedPriceOf,mine.ids,affiliations)
return{
...(baseline===undefined?{}:{baseline,swap:swap??null}),
ok:true,prepared:{challenge,set:deps.set,
squad:null,
field:liveSquad,selection:players,requirements,protectedIds:Array.isArray(deps.protectedIds)?[...deps.protectedIds]:[],
mine:[...mine.ids],
chemistry:{live:null,offline:offlineChemistry},
concepts},
verdict:{ratingExact,rating,ratingMet:meetsLive(requirements,RATING_KEYS,rating),chemistry:offlineChemistry},
lineup:lineupOf(players,{spare,mine:mine.ids,priceOf:deps.cachedPriceOf,concepts,named:affiliations,linkedTeam:deps.linkedTeam}),
mine:[...mine.ids],
market:market!==null,shop:pruned?.shop??null,buys:buysOf(result,shopping,affiliations,deps.linkedTeam),spend:spendOf(result),
counterweight:counterweightOf(result),
specGate:specGateOf(result),
clubGate:clubGateOf(result),
marketBlind:market===null?[]:marketBlindSpots(requirements,shopping,result.buys),
scarcity:scarcityOf({requirements,cards:available,taken:players,linkedTeam:deps.linkedTeam}),
burn,price,search,pool,failed:[],notice:{key:'sbc.solved',params:{count:players.length}}}}
export function exhaustedWindow(passport){if(!passport||passport.known!==true)return null
if(passport.limited!==true||passport.complete!==true)return null
const remaining=Number(passport.remaining)
return Number.isFinite(remaining)&&remaining<=0?passport:null}
function passportOf(deps,challenge){try{return typeof deps?.sbc?.challengePassport==='function'
?deps.sbc.challengePassport(challenge):null}catch{return null}}
export function saveRefusalNotice(err){const http=Number(err?.httpStatus)
if(!(http>=500&&http<600))return null
const owned=Number(err?.response?.error?.code)
if(Number.isFinite(owned))return null
const status=Number(err?.status)
if(Number.isFinite(status)&&status!==http)return null
return{key:'sbcWindow.saveRefused',params:{}}}
export async function showPreparedOnPitch(deps,prepared){const challenge=prepared?.challenge
const selection=Array.isArray(prepared?.selection)?prepared.selection:null
if(!challenge||!selection||selection.length===0){return{ok:false,live:null,notice:{key:'sbc.nothingPrepared',params:{}}}}
const conceptOf=typeof deps?.concept==='function'?deps.concept:null
const sources=prepared?.concepts instanceof Map?prepared.concepts:new Map
const wanted=selection.filter((item)=>item?.virtual===true)
const refuse=(reason,detail)=>({ok:false,live:null,reason,detail:detail??null,notice:{key:'sbcWindow.buysNotOnPitch',params:{count:wanted.length}}})
let field=selection
if(wanted.length>0){if(conceptOf===null)return refuse('no-factory')
const built=[]
for(const item of selection){if(item?.virtual!==true){built.push(item)
continue}
const key=String(item?.id??'')
const source=sources.get(key)??null
if(source===null)return refuse('no-source',{buy:key,rating:item?.rating??null})
let concept=null
try{concept=conceptOf(source)}catch{concept=null}
if(!concept)return refuse('build-failed',{buy:key,definitionId:source.definitionId,rating:source.rating})
built.push(concept)}
field=built}
const liveSquad=prepared.field
if(!liveSquad||typeof liveSquad.addItemToSlot!=='function'){return{ok:false,live:null,notice:{key:'sbc.loadFailed',params:{reason:'у вердикта нет живого состава'}}}}
if(challenge.squad!==liveSquad){return{ok:false,live:null,notice:{key:'sbcWindow.staleSquad',params:{}}}}
let squad
try{squad=materializeSelection(liveSquad,field,prepared.protectedIds,prepared.mine)}catch(err){return{ok:false,live:null,notice:{key:'sbcWindow.showFailed',params:{reason:reasonOf(err)}}}}
const rating=liveNumber(()=>squad.getRating?.())
const chemistry=liveNumber(()=>squad.getChemistry?.())
const requirements=Array.isArray(prepared.requirements)?prepared.requirements:[]
prepared.squad=squad
prepared.chemistry={live:chemistry,offline:prepared.chemistry?.offline??null}
const passport=passportOf(deps,challenge)
const shut=exhaustedWindow(passport)
let saveFailed=null
let saveWord=null
if(shut===null){try{await deps.sbc.saveChallenge(challenge)}catch(err){saveFailed=reasonOf(err)
saveWord=saveRefusalNotice(err)}}
else{saveFailed='окно повторов исчерпано'
saveWord={key:'sbcWindow.saveExhausted',params:{}}}
return{ok:true,live:{rating,chemistry,ratingMet:meetsLive(requirements,RATING_KEYS,rating),chemistryMet:meetsLive(requirements,CHEMISTRY_KEYS,chemistry)},
sent:shut===null,passport,saveReason:saveFailed,
placed:field.map((item)=>String(item?.id??'')).filter((id)=>id!==''&&id!=='0'),
saved:saveFailed===null,notice:saveFailed===null?{key:'sbcWindow.shown',params:{}}:saveWord??{key:'sbcWindow.saveFailed',params:{reason:saveFailed}}}}
function conceptSlotOf(squad,definitionId,taken){for(const slot of liveSlots(squad)){let item=null
try{item=slot?.item??null}catch{item=null}
if(!isVirtualConcept(item))continue
let card=null
try{card=Number(item?.definitionId)}catch{card=null}
if(card!==definitionId)continue
const index=Number.isSafeInteger(slot?.index)?slot.index:null
if(index===null)continue
if(taken instanceof Set&&taken.has(index))continue
return index}
return null}
function pitchSnapshot(squad,definitionId){const slots=liveSlots(squad)
let filled=0
let ours=0
let dreams=0
let seen=false
let elsewhere=null
const ids=[]
for(const slot of slots){let item=null
try{item=slot?.item??null}catch{item=null}
if(item===null||item===undefined)continue
const id=String(item?.id??'')
if(id===''||id==='0')continue
filled+=1
let card=null
try{card=Number(item?.definitionId)}catch{card=null}
if(!Number.isFinite(card))card=null
if(isVirtualConcept(item)){ours+=1
if(card!==null){ids.push(card)
if(card===definitionId)seen=true}}
else if(isConceptItem(item))dreams+=1
if(card!==null&&card===definitionId&&elsewhere===null){elsewhere=Number.isSafeInteger(slot?.index)?slot.index:-1}}
return{slots:slots.length,filled,ours,dreams,wanted:definitionId,seen,ids,elsewhere}}
function standingCard(squad,card,definitionId,want){if(!Number.isSafeInteger(want))return null
const bought=String(card?.id??'')
for(const slot of liveSlots(squad)){const index=Number.isSafeInteger(slot?.index)?slot.index:null
if(index!==want)continue
let item=null
try{item=slot?.item??null}catch{item=null}
if(item===null||item===undefined)return null
if(isVirtualConcept(item)||isConceptItem(item))return null
const id=String(item?.id??'')
if(id===''||id==='0')return null
if(bought!==''&&bought!=='0'&&id===bought)return{slot:index,id,how:'same-item'}
let mine=null
try{mine=Number(item?.definitionId)}catch{mine=null}
return Number.isFinite(mine)&&mine===definitionId?{slot:index,id,how:'same-card'}:null}
return null}
export function planSlotsFor(prepared,targets){const out=[]
const slots=new Map
const taken=new Set
const sources=prepared?.concepts instanceof Map?prepared.concepts:null
const squad=prepared?.field??null
const hasSquad=Boolean(squad)&&typeof squad.addItemToSlot==='function'
for(const one of Array.isArray(targets)?targets:[]){const row=String(one?.row??'')
const name=typeof one?.name==='string'&&one.name!==''?one.name:null
const source=sources?.get(row)??null
const definitionId=Number.isSafeInteger(source?.definitionId)?source.definitionId:null
if(definitionId===null){out.push({row,id:null,name,why:'no-source'})
continue}
if(!hasSquad){out.push({row,id:definitionId,name,why:'no-squad'})
continue}
const at=conceptSlotOf(squad,definitionId,taken)
if(at===null){out.push({row,id:definitionId,name,why:'not-on-pitch'})
continue}
taken.add(at)
slots.set(row,at)}
return{missing:out,slots}}
export function conceptsMissingFor(prepared,targets){return planSlotsFor(prepared,targets).missing}
export function mismatchInPlan(prepared,targets){const out=[]
const sources=prepared?.concepts instanceof Map?prepared.concepts:null
for(const one of Array.isArray(targets)?targets:[]){const row=String(one?.row??'')
const name=typeof one?.name==='string'&&one.name!==''?one.name:null
const source=sources?.get(row)??null
const definitionId=Number.isSafeInteger(source?.definitionId)?source.definitionId:null
const wanted=Number.isSafeInteger(one?.id)&&one.id>0?one.id:null
if(definitionId===null){out.push({row,id:wanted,name,why:'no-source',source:null})
continue}
if(wanted===definitionId)continue
const root=Number.isFinite(one?.swapped)&&one.swapped>0&&Number.isSafeInteger(one?.swapRoot)?one.swapRoot:null
if(wanted!==null&&root===definitionId)continue
out.push({row,id:wanted,name,why:'mismatch',source:definitionId})}
return out}
export function twiceInPlan(prepared,targets){const out=[]
const seen=new Map
for(const one of Array.isArray(targets)?targets:[]){const row=String(one?.row??'')
const name=typeof one?.name==='string'&&one.name!==''?one.name:null
const wanted=Number.isSafeInteger(one?.id)&&one.id>0?one.id:null
if(wanted===null)continue
const first=seen.get(wanted)
if(first===undefined){seen.set(wanted,row)
continue}
out.push({row,id:wanted,name,why:'twice',first})}
return out}
export function searchBuyOnMarket(deps,prepared,buyId){const open=typeof deps?.search==='function'?deps.search:null
if(open===null)return{ok:false,reason:'no-search'}
const sources=prepared?.concepts instanceof Map?prepared.concepts:null
const source=sources?.get(String(buyId))??null
const definitionId=Number.isSafeInteger(source?.definitionId)?source.definitionId:null
if(definitionId===null)return{ok:false,reason:'no-source'}
const squad=prepared?.field
const slot=conceptSlotOf(squad,definitionId)
if(slot===null)return{ok:false,reason:'not-on-pitch'}
const maxBuy=searchCeiling(source?.price)
let result=null
try{result=open({squad,slot,maxBuy})}catch(err){return{ok:false,reason:'failed',detail:String(err?.message??err),slot,maxBuy}}
return result?.ok===true
?{ok:true,reason:null,slot,maxBuy,applied:result?.applied??null}
:{ok:false,reason:result?.reason??'failed',detail:result?.detail??null,slot,maxBuy,applied:result?.applied??null}}
export function placeBoughtCard(prepared,buyId,card,plan){const sources=prepared?.concepts instanceof Map?prepared.concepts:null
const source=sources?.get(String(buyId))??null
const definitionId=Number.isSafeInteger(source?.definitionId)?source.definitionId:null
if(definitionId===null)return{ok:false,reason:'no-source'}
if(!isSbcPlayer(card)||isVirtualConcept(card))return{ok:false,reason:'not-a-card'}
const squad=prepared?.field??null
if(!squad||typeof squad.addItemToSlot!=='function')return{ok:false,reason:'no-squad'}
const slot=conceptSlotOf(squad,definitionId)
if(slot===null){const field=pitchSnapshot(squad,definitionId)
const want=plan instanceof Map&&Number.isSafeInteger(plan.get(String(buyId)))?plan.get(String(buyId)):null
const standing=standingCard(squad,card,definitionId,want)
if(standing!==null)return{ok:true,reason:null,slot:standing.slot,id:standing.id,already:standing.how,field}
return{ok:false,reason:'not-on-pitch',field}}
try{squad.addItemToSlot(slot,card)}catch(err){return{ok:false,reason:'failed',detail:reasonOf(err),slot,field:pitchSnapshot(squad,definitionId)}}
const id=String(card?.id??'')
const landed=slotItemId(squad,slot)
if(landed===null||landed!==id)return{ok:false,reason:'not-swapped',slot,field:pitchSnapshot(squad,definitionId)}
return{ok:true,reason:null,slot,id}}
function slotItemId(squad,index){for(const slot of liveSlots(squad)){if(slot?.index!==index)continue
let item=null
try{item=slot?.item??null}catch{item=null}
const id=String(item?.id??'')
return id===''?null:id}
return null}
export const SEARCH_HEADROOM=1.2
function searchCeiling(price){if(!Number.isFinite(price)||price<=0)return null
const raised=price*SEARCH_HEADROOM
const grid=floorToValidPrice(raised)
const value=grid>=raised?grid:nextPrice(grid)
return Number.isSafeInteger(value)&&value>0?value:null}
function extractRequirements(challenge){const list=challenge?.eligibilityRequirements
return Array.isArray(list)?list:null}
function requiredPlayers(squad){try{const count=squad?.getNumOfRequiredPlayers?.()
if(Number.isFinite(count)&&count>0)return count} catch{/* ниже — по слотам */}
return liveSlots(squad).length||11}
const FIELD_SLOTS=11
function liveSlots(squad){try{const slots=squad?.getNonBrickSlots?.()
if(Array.isArray(slots))return slots} catch{/* следующий настоящий метод */}
try{const slots=squad?.getSBCSlots?.()
if(Array.isArray(slots))return slots.slice(0,FIELD_SLOTS)} catch{/* нет живых слотов */}
return[]}
function liveBricks(squad){let field=null
try{field=squad?.getFieldPlayers?.()}catch{field=null}
if(!Array.isArray(field))return[]
const out=[]
for(const slot of field){let custom=false
try{custom=slot?.isCustomBrick?.()===true}catch{custom=false}
if(!custom)continue
const item=slot?.item
const at=slot?.index
let position=null
try{position=slot?.position?.typeId}catch{position=null}
if(!Number.isInteger(at)||!Number.isFinite(position)||!item||typeof item!=='object')return[]
out.push({at,position,player:{id:`brick:${at}`,teamId:item.teamId,leagueId:item.leagueId,nationId:item.nationId,
possiblePositions:Array.isArray(item.possiblePositions)?[...item.possiblePositions]:[]}})}
return out}
function materializeSelection(squad,players,protectedIds=[],mine=[]){const slots=liveSlots(squad)
const safePolicy=sanitizeSbcPolicy()
const own=new Set((Array.isArray(mine)?mine:[]).map(String))
if(!Array.isArray(players)
||!players.every((item)=>(own.has(String(item?.id??''))?isSbcPlayer(item):isSbcAllowed(item,safePolicy,protectedIds)))
||slots.length<players.length){throw new Error('SBC: выбор содержит не-player или не помещается')}
if(typeof squad?.removeItemFromSlot!=='function'){throw new Error('SBC: живой состав не умеет очищать слот поля')}
for(const slot of slots){const index=Number.isFinite(slot?.index)?slot.index:null
if(index!==null)squad.removeItemFromSlot(index)}
players.forEach((player,index)=>{const slotIndex=Number.isFinite(slots[index]?.index)?slots[index].index:index;
squad.addItemToSlot(slotIndex,player)})
return squad}
const reasonOf=(err)=>{const text=String(err?.message??err)
const code=Number.isFinite(err?.status)?err.status:null
const http=Number.isFinite(err?.httpStatus)?err.httpStatus:null
if(code===null&&http===null)return text
const parts=[code===null?null:`код ${code}`,http===null||http===code?null:`HTTP ${http}`].filter((one)=>one!==null)
return`${text} (${parts.join(', ')})`}
