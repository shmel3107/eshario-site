import{MIN_PRICE} from './price-grid.js'
export const PRICE_FEATURE='priceSources'
export const DEFAULT_TTL_MS=10*60*1000
export const DEFAULT_MAX_ENTRIES=500
export function createPriceCache(options={}){const{clock,ttlMs=DEFAULT_TTL_MS,maxEntries=DEFAULT_MAX_ENTRIES}=options
if(!clock||typeof clock.now!=='function'){throw new Error('price-cache: нужны часы с now() (правило 6 NIGHT_BRIEF)')}
if(!Number.isFinite(ttlMs)||ttlMs<=0){throw new Error('price-cache: ttlMs должен быть положительным числом')}
if(!Number.isInteger(maxEntries)||maxEntries<=0){throw new Error('price-cache: maxEntries должен быть положительным целым')}
const entries=new Map()
const isExpired=(entry,now)=>now-entry.storedAt>=entry.ttl
const prune=()=>{const now=clock.now()
let removed=0
for(const[key,entry]of entries){if(isExpired(entry,now)){entries.delete(key)
removed+=1}}
return removed}
return{
has(key){const k=normalizeKey(key)
if(k===null)return false
const entry=entries.get(k)
if(entry===undefined)return false
if(isExpired(entry,clock.now())){entries.delete(k)
return false}
return true},
get(key){const k=normalizeKey(key)
if(k===null)return undefined
const entry=entries.get(k)
if(entry===undefined)return undefined
if(isExpired(entry,clock.now())){entries.delete(k)
return undefined}
return entry.value},
set(key,value,options={}){const k=normalizeKey(key)
if(k===null) throw new Error('price-cache: ключ должен быть непустой строкой или числом')
if(value===undefined){
throw new Error('price-cache: undefined не значение; для «цены нет» кладите null')}
const own=Number(options?.ttlMs)
const ttl=Number.isFinite(own)&&own>0?own:ttlMs
const price=value===null?null:normalizePrice(value)
entries.delete(k)
prune()
while(entries.size>=maxEntries){const oldest=entries.keys().next()
if(oldest.done)break
entries.delete(oldest.value)}
entries.set(k,{value:price,storedAt:clock.now(),ttl})
return price},
storedAt(key){const k=normalizeKey(key)
if(k===null)return undefined
const entry=entries.get(k)
if(entry===undefined)return undefined
if(isExpired(entry,clock.now())){entries.delete(k)
return undefined}
return entry.storedAt},
delete(key){const k=normalizeKey(key)
return k===null?false:entries.delete(k)},
clear(){entries.clear()},
prune,
keys(){prune()
return[...entries.keys()]},
get size(){prune()
return entries.size}}}
export function createPriceLookup(options={}){const{cache,source}=options
const ttlOf=typeof options.ttlOf==='function'?options.ttlOf:null
const clock=options.clock&&typeof options.clock.now==='function'?options.clock:null
if(!cache||typeof cache.get!=='function'||typeof cache.set!=='function'){throw new Error('price-lookup: нужен кэш из createPriceCache')}
if(typeof source!=='function'){throw new Error('price-lookup: источник приходит функцией')}
const staleEmpty=(k,cached,hint)=>{if(cached!==null||clock===null)return false
const ttl=Number(hint?.emptyTtlMs)
if(!Number.isFinite(ttl)||ttl<=0)return false
const at=cache.storedAt?.(k)
return !Number.isFinite(at)||clock.now()-at>=ttl}
const inFlight=new Map()
const provenance=new Map()
return{
async lookup(key,hint=null){const k=normalizeKey(key)
if(k===null) return result(null,'none',false,'bad-key')
const cached=cache.get(k)
if(cached!==undefined&&!staleEmpty(k,cached,hint)){return result(cached,'cache',true,cached===null?'no-price':null,null,provenance.get(k)??null,cache.storedAt?.(k)??null)}
const pending=inFlight.get(k)
if(pending)return pending
const promise=(async()=>{try{const parsed=readSourceResult(await source(k,hint));
if(!parsed.ok) return{...result(null,'source',false,parsed.reason),detail:parsed.detail??null,waitMs:parsed.waitMs??null};
cache.set(k,parsed.price,{ttlMs:ttlOf?.(parsed.provider)});
if(parsed.provider)provenance.set(k,parsed.provider)
else provenance.delete(k)
return result(parsed.price,'source',true,parsed.price===null?'no-price':null,null,parsed.provider,cache.storedAt?.(k)??null)}catch(err){return result(null,'source',false,'source-unavailable',err)}finally{inFlight.delete(k)}})()
inFlight.set(k,promise)
return promise},
get pending(){return inFlight.size}}}
export function createPriceFallback(providers){if(!Array.isArray(providers)
||providers.length===0
||providers.some((item)=>(!item||typeof item.id!=='string'||item.id.trim()===''||typeof item.source!=='function'
))) throw new Error('price-fallback: нужны именованные функции-источники')
return async function fallbackSource(key){const failures=[]
for(const item of providers){let parsed
try{parsed=readSourceResult(await item.source(key))}catch{parsed={ok:false,price:null,reason:'source-unavailable'}}
if(parsed.ok&&parsed.price!==null){return{ok:true,price:parsed.price,reason:null,provider:item.id}}
if(!parsed.ok) failures.push(`${item.id}:${parsed.reason}`)}
return failures.length
?{ok:false,price:null,reason:failures.join('|'),provider:null}
:{ok:true,price:null,reason:'no-price',provider:null}}}
export function normalizePrice(value){let n=NaN
if(typeof value==='number') n=value
else if(typeof value==='string'&&value.trim()!=='') n=Number(value)
if(!Number.isFinite(n))return null
const rounded=Math.round(n)
return rounded<MIN_PRICE?null:rounded}
export function normalizeKey(key){if(typeof key==='number'&&Number.isFinite(key)) return String(key)
if(typeof key!=='string') return null
const trimmed=key.trim()
return trimmed===''?null:trimmed}
function readSourceResult(raw){if(raw===null||raw===undefined) return{ok:true,price:null,reason:'no-price',provider:null}
if(typeof raw==='number'||typeof raw==='string'){return{ok:true,price:normalizePrice(raw),reason:null,provider:null}}
if(typeof raw==='object'){if(raw.ok===false) return{ok:false,price:null,reason:raw.reason??'source-error',provider:null,
detail:typeof raw.detail==='string'&&raw.detail!==''?raw.detail:null,
waitMs:Number.isFinite(raw.waitMs)&&raw.waitMs>0?raw.waitMs:null}
if('price' in raw) return{ok:true,price:normalizePrice(raw.price),reason:null,provider:typeof raw.provider==='string'&&raw.provider!==''?raw.provider:null}}
return{ok:false,price:null,reason:'bad-source-result',provider:null}}
function result(price,from,ok,reason=null,error=null,provider=null,observedAt=null){return{price:price??null,from,ok,reason,error,provider:provider??null,observedAt:observedAt??null}}
