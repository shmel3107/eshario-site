import{el,clear,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoLink} from '../ui/controls.js'
import{ensureWindow,WINDOW_CLOSE_CLASS,WINDOW_CLOSE_MARK} from '../ui/window.js'
import{previewDefinitionId,promoTimeLeft} from '../adapter/store-packs.js'
import{peekSums,peekVerdictWords} from './pack-value.js'
import{mountRevealCard} from '../adapter/pack-peek.js'
import{priceBadgePeek} from './price-badges.js'
import{packLockKey} from './pack-locks.js'
export const STORE_CATALOG_FEATURE='packGrid'
const STORE_CATALOG_STYLESHEET=new URL('../ui/store-catalog.css',import.meta.url).href
const STORE_CATALOG_LINK_ID='fut-companion-store-catalog'
const OURS_SELECTOR='[data-fut-catalog]'
const HOST_FLAG='futCatalogHost'
const FLAT_FLAG='futCatalogFlat'
const DISCLAIMER_SELECTOR='.ut-store-hub-view--disclaimer'
const PACK_SELECTOR='[data-fut-catalog-pack]'
export const CATALOG_FILTERS=Object.freeze(['all','tradeable','untradeable'])
const FILTER_LABELS=Object.freeze({all:'storeCatalog.filter.all',
tradeable:'storeCatalog.filter.tradeable',
untradeable:'storeCatalog.filter.untradeable'})
const KIND_LABELS=Object.freeze({players:'storeCatalog.kind.players',
mixed:'storeCatalog.kind.mixed',
vanity:'storeCatalog.kind.vanity'})
const HOUR=3600
const DAY=86400
export function catalogMatches(card,view={}){const trade=CATALOG_FILTERS.includes(view.trade)?view.trade:'all'
if(trade==='tradeable'&&card?.tradable!==true)return false
if(trade==='untradeable'&&card?.tradable!==false)return false
if(card?.hidden===true&&view.showHidden!==true)return false
return nameMatches(card?.name,view.query)}
export function nameMatches(name,query){const needle=typeof query==='string'?query.trim().toLowerCase():''
if(needle==='')return true
return String(name??'').toLowerCase().includes(needle)}
export function catalogCounts(cards){const list=Array.isArray(cards)?cards:[]
let tradeable=0
for(const card of list){if(card?.tradable===true)tradeable+=1}
return{packs:list.length,tradeable}}
export const CATALOG_SORTS=Object.freeze(['price','time','name'])
export const CATALOG_SORT_OPTIONS=Object.freeze([
Object.freeze({value:'price-down',by:'price',desc:true,label:'storeCatalog.sort.priceDown'}),
Object.freeze({value:'price-up',by:'price',desc:false,label:'storeCatalog.sort.priceUp'}),
Object.freeze({value:'time',by:'time',desc:false,label:'storeCatalog.sort.time'}),
Object.freeze({value:'name',by:'name',desc:false,label:'storeCatalog.sort.name'}),
])
export function catalogSortValue(sort){const{by,desc}=sanitizeCatalogSort(sort)
const hit=CATALOG_SORT_OPTIONS.find((one)=>one.by===by&&one.desc===desc)
return(hit??CATALOG_SORT_OPTIONS[0]).value}
export function catalogSortOf(value){const hit=CATALOG_SORT_OPTIONS.find((one)=>one.value===value)
return hit?{by:hit.by,desc:hit.desc}:{...CATALOG_SORT_DEFAULT}}
const SORT_FIRST=Object.freeze({price:true,time:false,name:false})
export const CATALOG_SORT_DEFAULT=Object.freeze({by:'price',desc:true})
export function sanitizeCatalogSort(stored){const raw=stored&&typeof stored==='object'&&!Array.isArray(stored)?stored:{}
const by=CATALOG_SORTS.includes(raw.by)?raw.by:CATALOG_SORT_DEFAULT.by
const desc=typeof raw.desc==='boolean'?raw.desc:SORT_FIRST[by]
return{by,desc}}
function sortKeyOf(card,by){if(by==='price'){const value=Number(card?.coins)
return Number.isFinite(value)&&value>0?value:null}
if(by==='time'){const value=Number(card?.endsAt)
return Number.isFinite(value)&&value>0?value:null}
const name=typeof card?.name==='string'?card.name.trim().toLowerCase():''
return name===''?null:name}
export function catalogSort(cards,sort){const list=Array.isArray(cards)?cards:[]
const{by,desc}=sanitizeCatalogSort(sort)
const rows=list.map((card,index)=>({card,index,hidden:card?.hidden===true,key:sortKeyOf(card,by)}))
rows.sort((a,b)=>{if(a.hidden!==b.hidden)return a.hidden?-1:1
if(a.key===null&&b.key===null)return a.index-b.index
if(a.key===null)return 1
if(b.key===null)return -1
if(a.key===b.key)return a.index-b.index
const ahead=a.key<b.key?-1:1
return desc?-ahead:ahead})
return rows.map((row)=>row.card)}
export function oddsSections(rows){const list=Array.isArray(rows)?rows:[]
const main=[]
const picks=[]
for(const row of list){if(row?.group!=='picks'){main.push(row)
continue}
const key=Number.isFinite(row?.packId)?String(row.packId):''
const hit=picks.find((one)=>one.key===key)
if(hit)hit.rows.push(row)
else picks.push({key,rows:[row]})}
return{main,picks}}
export function printMark(parts){const list=Array.isArray(parts)?parts:[]
let out=''
for(const one of list){const text=String(one??'')
out+=text.length+':'+text+'|'}
return out}
export function timeLeftLabel(endsAt,nowMs){if(!Number.isFinite(endsAt)||endsAt<=0)return null
const left=Math.round(endsAt-nowMs/1000)
if(!Number.isFinite(left)||left<=0)return null
const hot=left<DAY
if(left>=DAY)return{key:'storeCatalog.time.days',params:{days:Math.floor(left/DAY)},hot}
if(left>=HOUR)return{key:'storeCatalog.time.hours',params:{hours:Math.floor(left/HOUR)},hot}
return{key:'storeCatalog.time.mins',params:{mins:Math.max(1,Math.floor(left/60))},hot}}
export function previewState(preview,opts,nowMs){const items=Array.isArray(preview?.items)?preview.items:[]
const expires=preview?.expiresAt??null
const left=Number.isFinite(expires)&&expires>0?Math.round(expires-nowMs/1000):null
if(left!==null&&left<=0)return{state:'unseen'}
if(items.length===0){const best=preview?.best
const real=Number.isSafeInteger(best?.definitionId)&&best.definitionId>0
return real&&left!==null?{state:'known',left}:{state:'unseen'}}
const sums=peekSums(items.map((item)=>({item})),{priceOf:opts?.priceOf,packTradable:typeof opts?.tradable==='boolean'?opts.tradable:null,coins:opts?.coins??null})
return{state:'seen',sums,left}}
export function clockParts(left){if(!Number.isFinite(left)||left<=0)return null
const minutes=Math.ceil(left/60)
return{h:Math.floor(minutes/60),mm:String(minutes%60).padStart(2,'0')}}
export function mainAction(card){if(card?.preview)return{kind:'preview',price:null}
if(Number.isFinite(card?.coins)&&card.coins>0)return{kind:'coins',price:card.coins}
if(Number.isFinite(card?.points)&&card.points>0)return{kind:'points',price:card.points}
return{kind:'none',price:null}}
export function altAction(card){if(mainAction(card).kind!=='coins')return null
return Number.isFinite(card?.points)&&card.points>0?{kind:'points',price:card.points}:null}
export function readCatalogFacts(root){const clean=(value)=>(typeof value==='string'?value.trim().replace(/\s+/g,' '):'')
const shown=(selector)=>{const node=root?.querySelector?.(selector)??null
if(!node)return ''
if(node.style&&node.style.display==='none')return ''
const text=clean(node.querySelector?.('.label')?.textContent)
const value=clean(node.querySelector?.('.value')?.textContent)
if(text===''&&value==='')return clean(node.textContent)
return[text,value].filter((one)=>one!=='').join(' ')}
const source=root?.querySelector?.('.ut-pack-graphic-view--background')?.getAttribute?.('src')
const title=root?.querySelector?.('.ut-store-pack-details-view--title span')
??root?.querySelector?.('.ut-store-xray-pack-details-view--title')
return{name:clean(title?.textContent),
art:typeof source==='string'?source:'',
limit:shown('.ut-store-pack-details-view--user-quantity')||shown('.ut-store-xray-pack-details-view--user-quantity'),
world:shown('.ut-store-pack-details-view--global-quantity')||shown('.ut-store-xray-pack-details-view--global-quantity')}}
export function nativeButton(root,kind){if(kind==='coins')return root?.querySelector?.('button.currency.coins')??null
if(kind==='points')return root?.querySelector?.('button.currency.points')??null
if(kind==='preview')return root?.querySelector?.('.ut-store-xray-pack-details-view--preview-container button')??null
return null}
export function nativeOff(button){if(!button)return true
if(button.disabled===true)return true
const cls=typeof button.className==='string'?button.className:''
return cls.split(/\s+/).includes('disabled')}
export function screenBusy(screen){if(typeof screen?.isInteractionEnabled!=='function')return false
try{return screen.isInteractionEnabled()===false}catch{return false}}
export function createStoreCatalog(deps={}){const{doc,t}=deps
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const isHidden=typeof deps.isHidden==='function'?deps.isHidden:null
const setHidden=typeof deps.setHidden==='function'?deps.setHidden:null
const priceOf=typeof deps.priceOf==='function'?deps.priceOf:null
const formatCoins=typeof deps.formatCoins==='function'?deps.formatCoins:(value)=>String(Math.round(value))
const readView=typeof deps.view==='function'?deps.view:null
const writeView=typeof deps.setView==='function'?deps.setView:null
const now=typeof deps.now==='function'?deps.now:()=>Date.now()
const previewPrices=new Map()
const previewAsking=new Set()
const PREVIEW_PRICE_TTL_MS=10*60*1000
const PREVIEW_RETRY_MS=60*1000
const peekPrice=typeof deps.peek==='function'?deps.peek:priceBadgePeek
const reveals=new Map()
const mountCard=typeof deps.mountCard==='function'?deps.mountCard:mountRevealCard
const memory=deps.memory&&typeof deps.memory.recall==='function'&&typeof deps.memory.remember==='function'?deps.memory:null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let last=null
let scheduled=false
let lastResult={ok:false,reason:'not-run'}
let settles=0
let renders=0
let pinned=true
const view={trade:'all',query:'',showHidden:false,sort:{...CATALOG_SORT_DEFAULT}}
let openWin=null
let doorman=null
const busy=new Map()
let captures=0
let lastPress=null
const record=(result)=>{lastResult=result
return result}
function apply(catalog){if(!doc)return record({ok:false,reason:'no-doc'})
if(!catalog?.box){const box=last?.box??null
last=null
busy.clear()
if(box)drop(box)
return record({ok:false,reason:'not-catalog'})}
last=catalog
captures+=1
schedule()
return record({ok:true,reason:'pending'})}
function schedule(){if(scheduled)return
scheduled=true
Promise.resolve().then(()=>{scheduled=false
try{settle()}catch(err){onError(err)}})}
function settle(){settles+=1
if(!last)return record({ok:false,reason:'no-capture'})
releaseBusy()
const{box,tiles}=last
if(!isActive(STORE_CATALOG_FEATURE)){drop(box)
return record({ok:false,reason:'locked'})}
if(box.isConnected===false){drop(box)
return record({ok:false,reason:'detached'})}
if(!Array.isArray(tiles)||tiles.length===0){drop(box)
return record({ok:false,reason:'empty'})}
if(!tiles.some((tile)=>tile?.root?.parentNode===box)){drop(box)
last=null
return record({ok:false,reason:'gone'})}
ensureTheme(doc)
ensureControls(doc)
ensureWindow(doc)
ensureStylesheet(doc,STORE_CATALOG_STYLESHEET,STORE_CATALOG_LINK_ID)
watchBox(box)
for(const tile of tiles){const key=String(tile.id)
if(tile.root?.dataset&&tile.root.dataset.futCatalogPack!==key)tile.root.dataset.futCatalogPack=key}
if(box.dataset&&box.dataset[HOST_FLAG]!=='1')box.dataset[HOST_FLAG]='1'
flatten(box)
render(mount(box),tiles)
renders+=1
return record({ok:true,reason:null,packs:tiles.length})}
function mount(box){const existing=box.querySelector?.(OURS_SELECTOR)??null
if(existing)return existing
const node=el(doc,'div',{class:'fut-catalog',dataset:{futCatalog:'1'}})
box.appendChild(node)
return node}
function render(host,tiles){const head=ensureHead(host)
const note=ensureNote(host)
const stamp=now()
const cards=tiles.map((tile)=>({tile,
key:String(tile.id),
facts:readCatalogFacts(tile.root),
value:tile.preview?previewValue(tile,stamp):null}))
const order=new Map(catalogSort(cards.map((card)=>({key:card.key,
coins:card.tile.coins,endsAt:card.tile.endsAt,name:card.facts.name,
hidden:hiddenOf(card.key)})),view.sort)
.map((row,index)=>[row.key,index+1]))
const known=new Set()
let shown=0
for(const card of cards){known.add(card.key)
const node=ensureCard(host,card.key)
const on=catalogMatches({tradable:card.tile.tradable,name:card.facts.name,hidden:hiddenOf(card.key)},view)
if(on)shown+=1
if(node.dataset&&node.dataset.futCatalogOff!==(on?'0':'1'))node.dataset.futCatalogOff=on?'0':'1'
setOrder(node,order.get(card.key)??1)
renderCard(node,card,stamp)}
for(const node of host.querySelectorAll?.('[data-fut-catalog-card]')??[]){const key=String(node.dataset?.futCatalogCard??'')
if(!known.has(key)){dropReveal(key)
node.remove?.()}}
write(note,cards.length>0&&shown===0?t('storeCatalog.none'):'')
renderHead(head,cards,shown)}
function setOrder(node,place){const value=String(place)
if(node?.style&&node.style.order!==value)node.style.order=value
if(node?.dataset&&node.dataset.futCatalogOrder!==value)node.dataset.futCatalogOrder=value}
function ensureNote(host){const existing=host.querySelector?.('[data-fut-catalog-note]')??null
if(existing)return existing
const node=el(doc,'div',{class:'fut-catalog-note',dataset:{futCatalogNote:'1'}})
host.appendChild(node)
return node}
function previewValue(tile,nowMs){let preview=tile.preview
let remembered=false
if(memory!==null){const nowSec=nowMs/1000
const win=doc?.defaultView??null
try{if(preview.items.length>0)memory.remember(tile.id,preview,nowSec,(item)=>previewDefinitionId(item,win))
else{const items=memory.recall(tile.id,preview,nowSec)
if(items){preview={...preview,items}
remembered=true}}}catch(err){onError(err)}}
const value=previewState(preview,{priceOf:cardPrice,tradable:tile.tradable,coins:tile.coins},nowMs)
return value.state==='seen'?{...value,remembered}:value}
function cardPrice(item){if(priceOf===null)return null
const win=doc?.defaultView??null
const id=previewDefinitionId(item,win)
if(id===null)return null
const warm=peekPrice(id)
if(warm!==null)return warm
const known=previewPrices.get(id)
if(known&&now()-known.at<(known.refused?PREVIEW_RETRY_MS:PREVIEW_PRICE_TTL_MS))return known.price
if(previewAsking.has(id))return known?.price??null
let value=null
try{value=priceOf(item?.definitionId===id?item:{definitionId:id})}catch(err){onError(err)
return null}
if(value&&typeof value.then==='function'){previewAsking.add(id)
value.then((price)=>{previewPrices.set(id,previewAnswer(price))},
()=>{previewPrices.set(id,previewAnswer(undefined))}).then(()=>{previewAsking.delete(id)
if(previewAsking.size===0)refreshView()})
return known?.price??null}
const answer=previewAnswer(value)
previewPrices.set(id,answer)
return answer.price}
function previewAnswer(value){if(value===undefined)return{price:null,refused:true,at:now()}
return{price:Number.isFinite(value)&&value>0?value:null,refused:false,at:now()}}
function ensureHead(host){const existing=host.querySelector?.('[data-fut-catalog-head]')??null
if(existing)return existing
const search=el(doc,'input',{class:'fx-search fut-catalog-search',attrs:{type:'search'},dataset:{futCatalogSearch:'1'}})
search.addEventListener?.('input',()=>{view.query=String(search.value??'')
refreshView()})
const sort=el(doc,'select',{class:'fut-catalog-sort',dataset:{futCatalogSort:'1'}},
CATALOG_SORT_OPTIONS.map((one)=>el(doc,'option',{attrs:{value:one.value},dataset:{futCatalogSortOption:one.value}})))
sort.addEventListener?.('change',()=>{pickSort(String(sort.value??''))})
const chips=CATALOG_FILTERS.map((name)=>el(doc,'button',{class:'fut-catalog-chip',attrs:{type:'button'},dataset:{futCatalogChip:name},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
view.trade=name
refreshView()}}},[el(doc,'span',{dataset:{futCatalogChipText:'1'}})]))
const check=isHidden&&setHidden
?el(doc,'label',{class:'fut-catalog-check'},[el(doc,'input',{attrs:{type:'checkbox'},dataset:{futCatalogShowHidden:'1'},
on:{change:(event)=>{view.showHidden=event?.target?.checked===true
refreshView()}}}),
el(doc,'span',{dataset:{futCatalogShowHiddenText:'1'}})])
:null
const node=el(doc,'div',{class:'fx-bar fut-catalog-head',dataset:{futCatalogHead:'1'}},[logoLink(doc),
search,
sort,
el(doc,'div',{class:'fut-catalog-chips',dataset:{futCatalogChips:'1'}},chips),
check,
el(doc,'span',{class:'fut-catalog-sum',dataset:{futCatalogSum:'1'}}),
el(doc,'span',{class:'fut-catalog-air',dataset:{futCatalogAir:'1'}}),
pinButton()].filter(Boolean))
paintPin(node)
host.appendChild(node)
return node}
function pickSort(value){const next=catalogSortOf(value)
if(next.by===view.sort.by&&next.desc===view.sort.desc)return false
view.sort=next
try{writeView?.({sort:view.sort.by,desc:view.sort.desc})}catch(err){onError(err)}
return refreshView()}
function hideKeyOf(key){const tile=(last?.tiles??[]).find((one)=>String(one.id)===key)??null
return tile?packLockKey(tile.id,tile.tradable):null}
function hiddenOf(key){if(!isHidden)return false
const mark=hideKeyOf(key)
if(mark===null)return false
try{return isHidden(mark)===true}catch(err){onError(err)
return false}}
function toggleHidden(key){if(!setHidden)return false
const mark=hideKeyOf(key)
if(mark===null)return false
let done=false
try{done=setHidden(mark,!hiddenOf(key))===true}catch(err){onError(err)
return false}
if(done)refreshView()
return done}
function renderHead(head,cards,shown){const counts=catalogCounts(cards.map((card)=>({tradable:card.tile.tradable})))
write(head.querySelector?.('[data-fut-catalog-sum]'),shown===cards.length
?t('storeCatalog.summary',counts)
:t('storeCatalog.shown',{shown,packs:counts.packs}))
const search=head.querySelector?.('[data-fut-catalog-search]')
if(search){nameNode(search,t('storeCatalog.search'),'placeholder')
if(search.value!==view.query)search.value=view.query}
for(const button of head.querySelectorAll?.('[data-fut-catalog-chip]')??[]){const name=String(button.dataset?.futCatalogChip??'')
const on=(CATALOG_FILTERS.includes(view.trade)?view.trade:'all')===name
if(button.dataset&&button.dataset.futCatalogChipOn!==(on?'1':'0'))button.dataset.futCatalogChipOn=on?'1':'0'
button.setAttribute?.('aria-pressed',on?'true':'false')
write(button.querySelector?.('[data-fut-catalog-chip-text]'),t(FILTER_LABELS[name]??FILTER_LABELS.all))}
const sortNode=head.querySelector?.('[data-fut-catalog-sort]')
if(sortNode){const value=catalogSortValue(view.sort)
for(const option of sortNode.querySelectorAll?.('[data-fut-catalog-sort-option]')??[]){const name=String(option.dataset?.futCatalogSortOption??'')
const hit=CATALOG_SORT_OPTIONS.find((one)=>one.value===name)
if(hit)write(option,t(hit.label))
const on=name===value
if(option.selected!==on)option.selected=on}
if(sortNode.value!==value)sortNode.value=value
nameNode(sortNode,t('storeCatalog.sort.title'))}
const check=head.querySelector?.('[data-fut-catalog-show-hidden]')
if(check&&check.checked!==view.showHidden)check.checked=view.showHidden
write(head.querySelector?.('[data-fut-catalog-show-hidden-text]'),t('storeCatalog.showHidden'))
paintPin(head)}
function pinButton(){const on=pinned!==false
const button=el(doc,'button',{class:'fx-action fx-action-square fut-catalog-pin',
dataset:{futCatalogPin:on?'1':'0'},
attrs:{type:'button','aria-pressed':on?'true':'false',title:t(on?'storeCatalog.pinOn':'storeCatalog.pinOff')},
text:'📌'})
button.addEventListener?.('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
pinned=pinned===false
try{writeView?.({pinned})}catch(err){onError(err)}
const head=button.closest?.('[data-fut-catalog-head]')??doc?.querySelector?.('[data-fut-catalog-head]')
if(head)paintPin(head)})
return button}
function paintPin(head){if(!head?.dataset)return false
readStored()
const on=pinned!==false
if(head.dataset.futCatalogPinned!==(on?'1':'0'))head.dataset.futCatalogPinned=on?'1':'0'
const button=head.querySelector?.('[data-fut-catalog-pin]')
if(button){if(button.dataset.futCatalogPin!==(on?'1':'0'))button.dataset.futCatalogPin=on?'1':'0'
button.setAttribute?.('aria-pressed',on?'true':'false')
button.setAttribute?.('title',t(on?'storeCatalog.pinOn':'storeCatalog.pinOff'))}
return true}
function readStored(){if(!readView)return false
const stored=readView()
if(!stored||typeof stored!=='object')return false
if(typeof stored.pinned==='boolean')pinned=stored.pinned
if(CATALOG_SORTS.includes(stored.sort)||typeof stored.desc==='boolean'){
view.sort=sanitizeCatalogSort({by:stored.sort,desc:stored.desc})}
return true}
function refreshView(){if(!last)return false
try{return settle().ok===true}catch(err){onError(err)
return false}}
function ensureCard(host,key){const existing=host.querySelector?.(`[data-fut-catalog-card="${key}"]`)??null
if(existing)return existing
const node=el(doc,'div',{class:'fut-catalog-card',dataset:{futCatalogCard:key}},[
isHidden&&setHidden?el(doc,'button',{class:'fut-catalog-hide',attrs:{type:'button'},dataset:{futCatalogHide:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{toggleHidden(key)}catch(err){onError(err)}}}}):null,
el(doc,'div',{class:'fut-catalog-art',dataset:{futCatalogArt:'1'}},[
el(doc,'span',{class:'fut-catalog-shot',dataset:{futCatalogShot:'1',futCatalogEmpty:'1'}}),
el(doc,'span',{class:'fut-catalog-timer',dataset:{futCatalogTimer:'1'}}),
el(doc,'span',{class:'fut-catalog-trade',dataset:{futCatalogTrade:'1'}}),
el(doc,'button',{class:'fut-catalog-odds-btn',attrs:{type:'button'},dataset:{futCatalogOddsToggle:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
toggleWindow(key,'odds')}}},[el(doc,'span',{class:'fut-catalog-odds-sign',text:'%'}),
el(doc,'span',{class:'fut-catalog-odds-peek',dataset:{futCatalogOddsPeek:'1'}})]),
el(doc,'div',{class:'fut-catalog-odds-list',dataset:{futCatalogOddsList:key}},[
el(doc,'div',{class:'fut-catalog-odds-head'},[
el(doc,'span',{class:'fut-catalog-odds-title',dataset:{futCatalogOddsTitle:'1'}}),
el(doc,'button',{class:WINDOW_CLOSE_CLASS,text:'✕',attrs:{type:'button'},
dataset:{[WINDOW_CLOSE_MARK]:'1',futCatalogOddsClose:key},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
closeWindow()}}}),
]),
el(doc,'div',{class:'fut-catalog-odds-rows',dataset:{futCatalogOddsRows:'1'}}),
]),
el(doc,'div',{class:'fut-catalog-desc-list',dataset:{futCatalogDescList:key}},[
el(doc,'div',{class:'fut-catalog-odds-head'},[
el(doc,'span',{class:'fut-catalog-odds-title',dataset:{futCatalogDescTitle:'1'}}),
el(doc,'button',{class:WINDOW_CLOSE_CLASS,text:'✕',attrs:{type:'button'},
dataset:{[WINDOW_CLOSE_MARK]:'1',futCatalogDescClose:key},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
closeWindow()}}}),
]),
el(doc,'div',{class:'fut-catalog-desc-body',dataset:{futCatalogDescBody:'1'}}),
]),
]),
el(doc,'div',{class:'fut-catalog-name',dataset:{futCatalogName:'1'}}),
el(doc,'div',{class:'fut-catalog-row'},[
el(doc,'div',{class:'fut-catalog-facts',dataset:{futCatalogFacts:'1'}}),
el(doc,'span',{class:'fut-catalog-lim',dataset:{futCatalogLim:'1',futCatalogLimTight:'0'}}),
]),
el(doc,'button',{class:'fut-catalog-desc',attrs:{type:'button'},dataset:{futCatalogDescToggle:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
toggleWindow(key,'desc')}}},[el(doc,'span',{class:'fut-catalog-desc-text',dataset:{futCatalogDescText:'1'}}),
el(doc,'span',{class:'fut-catalog-desc-sign',text:'\u24D8'})]),
el(doc,'div',{class:'fut-catalog-value',dataset:{futCatalogValue:'1',futCatalogValueHas:'0'}},[
logoLink(doc,'fut-catalog-value-logo'),
el(doc,'span',{class:'fut-catalog-value-text',dataset:{futCatalogValueText:'1'}}),
el(doc,'span',{class:'fut-catalog-value-time',dataset:{futCatalogValueTime:'1'}},[
el(doc,'span',{class:'fut-catalog-value-icon',dataset:{futCatalogValueIcon:'1'}}),
el(doc,'span',{class:'fut-catalog-value-clock',dataset:{futCatalogValueClock:'1'}}),
]),
]),
el(doc,'div',{class:'fut-catalog-limit',dataset:{futCatalogLimit:'1'}}),
el(doc,'button',{class:'fut-catalog-buy',attrs:{type:'button'},dataset:{futCatalogBuy:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{press(key,'main')}catch(err){onError(err)}}}},[el(doc,'span',{class:'fut-catalog-buy-text',dataset:{futCatalogBuyText:'1'}})]),
el(doc,'button',{class:'fut-catalog-alt',attrs:{type:'button'},dataset:{futCatalogAlt:key},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{press(key,'alt')}catch(err){onError(err)}}}},[el(doc,'span',{class:'fut-catalog-alt-text',dataset:{futCatalogAltText:'1'}})]),
].filter(Boolean))
host.appendChild(node)
return node}
function drawEye(host,hidden){if(!host)return false
const now=hidden?'1':'0'
if(host.dataset?.futCatalogEye===now&&host.firstChild)return false
if(host.dataset)host.dataset.futCatalogEye=now
if(typeof doc?.createElementNS!=='function')return false
const SVG='http://www.w3.org/2000/svg'
const shape=(tag,attrs)=>{const one=doc.createElementNS(SVG,tag)
for(const[name,value]of Object.entries(attrs))one.setAttribute(name,String(value))
return one}
const box=shape('svg',{viewBox:'0 0 20 20',fill:'none','aria-hidden':'true'})
box.appendChild(shape('path',{d:'M1.8 10C3.6 6.4 6.6 4.6 10 4.6C13.4 4.6 16.4 6.4 18.2 10C16.4 13.6 13.4 15.4 10 15.4C6.6 15.4 3.6 13.6 1.8 10Z',stroke:'currentColor','stroke-width':1.5,'stroke-linejoin':'round'}))
box.appendChild(shape('circle',{cx:10,cy:10,r:2.4,stroke:'currentColor','stroke-width':1.5}))
if(hidden){box.appendChild(shape('path',{d:'M4 16L16 4',stroke:'var(--fx-surface)','stroke-width':4,'stroke-linecap':'round'}))
box.appendChild(shape('path',{d:'M4 16L16 4',stroke:'currentColor','stroke-width':1.8,'stroke-linecap':'round'}))}
clear(host)
host.appendChild(box)
return true}
function renderHide(node,key){const button=node.querySelector?.('[data-fut-catalog-hide]')
const on=hiddenOf(key)
if(node.dataset&&node.dataset.futCatalogHidden!==(on?'1':'0'))node.dataset.futCatalogHidden=on?'1':'0'
if(!button)return false
if(button.dataset&&button.dataset.futCatalogHideOn!==(on?'1':'0'))button.dataset.futCatalogHideOn=on?'1':'0'
drawEye(button,on)
nameNode(button,on?t('storeCatalog.hide.on'):t('storeCatalog.hide.off'))
return true}
function renderCard(node,card,stamp){const{tile,facts}=card
setArt(node.querySelector?.('[data-fut-catalog-shot]'),facts.art)
renderReveal(node,card)
renderHide(node,card.key)
write(node.querySelector?.('[data-fut-catalog-name]'),facts.name)
writeFacts(node.querySelector?.('[data-fut-catalog-facts]'),tile)
renderTimer(node,tile,stamp)
renderTrade(node,tile)
renderOdds(node,tile)
renderDesc(node,tile)
renderValue(node,card)
renderLimit(node,facts.limit)
write(node.querySelector?.('[data-fut-catalog-limit]'),facts.world)
renderButtons(node,card)}
const LIMIT_TIGHT=2
function renderLimit(node,text){const chip=node.querySelector?.('[data-fut-catalog-lim]')
if(!chip)return
write(chip,text)
const found=/(\d+)/.exec(String(text??''))
const tight=found!==null&&Number(found[1])<=LIMIT_TIGHT?'1':'0'
if(chip.dataset&&chip.dataset.futCatalogLimTight!==tight)chip.dataset.futCatalogLimTight=tight}
function writeFacts(host,tile){if(!host)return
const parts=[{text:t('storeCatalog.items',{items:tile.items}),num:String(tile.items)}]
if(Number.isFinite(tile.players)&&tile.players>0)parts.push({text:t('storeCatalog.minPlayers',{players:tile.players}),num:String(tile.players)})
const kind=KIND_LABELS[tile.kind]
if(kind)parts.push({text:t(kind),num:null})
if(tile.playerPick===true)parts.push({text:t('storeCatalog.pick'),num:null})
const size=parts.map((one)=>one.text).join(' · ')
if(host.dataset?.futCatalogFactsSize===size)return
if(host.dataset)host.dataset.futCatalogFactsSize=size
clear(host)
parts.forEach((one,index)=>{
if(index>0)host.appendChild(el(doc,'span',{text:' · '}))
const at=one.num===null?-1:one.text.indexOf(one.num)
if(at<0){host.appendChild(el(doc,'span',{text:one.text}))
return}
if(at>0)host.appendChild(el(doc,'span',{text:one.text.slice(0,at)}))
host.appendChild(el(doc,'b',{class:'fut-catalog-num',text:one.num}))
const tail=one.text.slice(at+one.num.length)
if(tail!=='')host.appendChild(el(doc,'span',{text:tail}))})}
function renderTimer(node,tile,stamp){const box=node.querySelector?.('[data-fut-catalog-timer]')
if(!box)return
const label=timeLeftLabel(tile.endsAt,stamp)
const own=label===null?null:promoTimeLeft(doc?.defaultView??null,Math.round(tile.endsAt-stamp/1000))
write(box,label===null?'':(own??t(label.key,label.params)))
const hot=label?.hot===true?'1':'0'
if(box.dataset&&box.dataset.futCatalogHot!==hot)box.dataset.futCatalogHot=hot}
function renderTrade(node,tile){const host=node.querySelector?.('[data-fut-catalog-trade]')
if(!host)return
const now2=tile.tradable?'1':'0'
nameNode(host,tile.tradable?t('storeCatalog.tradeable'):t('storeCatalog.untradeable'))
if(host.dataset?.futCatalogTradable===now2&&host.firstChild)return
if(host.dataset)host.dataset.futCatalogTradable=now2
if(typeof doc?.createElementNS!=='function')return
const SVG='http://www.w3.org/2000/svg'
const shape=(tag,attrs)=>{const one=doc.createElementNS(SVG,tag)
for(const[name,value]of Object.entries(attrs))one.setAttribute(name,String(value))
return one}
const box=shape('svg',{viewBox:'0 0 20 20',fill:'none','aria-hidden':'true'})
box.appendChild(shape('path',{d:'M10 2.9V17.1',stroke:'currentColor','stroke-width':1.7,'stroke-linecap':'round'}))
box.appendChild(shape('path',{d:'M13.7 7.1C13.7 5.4 12 4.5 10 4.5C8 4.5 6.5 5.4 6.5 7C6.5 8.6 8.1 9.3 10 9.7C11.9 10.1 13.7 10.9 13.7 12.7C13.7 14.4 12 15.4 10 15.4C8 15.4 6.3 14.5 6.3 12.7',stroke:'currentColor','stroke-width':1.7,'stroke-linecap':'round','stroke-linejoin':'round'}))
if(!tile.tradable){box.appendChild(shape('path',{d:'M4.2 15.8L15.8 4.2',stroke:'var(--fx-surface)','stroke-width':4,'stroke-linecap':'round'}))
box.appendChild(shape('path',{d:'M4.2 15.8L15.8 4.2',stroke:'currentColor','stroke-width':1.8,'stroke-linecap':'round'}))}
clear(host)
host.appendChild(box)}
function renderOdds(node,tile){const button=node.querySelector?.('[data-fut-catalog-odds-toggle]')
const list=node.querySelector?.('[data-fut-catalog-odds-list]')
const rows=Array.isArray(tile.odds)?tile.odds:[]
const has=rows.length>0?'1':'0'
if(node.dataset&&node.dataset.futCatalogOddsHas!==has)node.dataset.futCatalogOddsHas=has
if(!button||!list)return
if(rows.length===0)return
write(button.querySelector?.('[data-fut-catalog-odds-peek]'),t('storeCatalog.odds.button'))
nameNode(button,t('storeCatalog.odds'))
write(node.querySelector?.('[data-fut-catalog-odds-title]'),t('storeCatalog.odds.title'))
nameNode(node.querySelector?.('[data-fut-catalog-odds-close]'),t('storeCatalog.odds.close'))
const open=openMark(String(tile.id),'odds')
if(node.dataset&&node.dataset.futCatalogOddsOpen!==open)node.dataset.futCatalogOddsOpen=open
button.setAttribute?.('aria-expanded',open==='1'?'true':'false')
const body=node.querySelector?.('[data-fut-catalog-odds-rows]')??list
const{main,picks}=oddsSections(rows)
const plan=main.map((row)=>({row}))
if(picks.length>0)plan.push({label:t('storeCatalog.odds.picks')})
for(const group of picks)for(const row of group.rows)plan.push({row})
const size=printMark(plan.flatMap((one)=>(one.row?['%',one.row.text,one.row.odds]:['#',one.label])))
if(body.dataset?.futCatalogOddsSize===size)return
if(body.dataset)body.dataset.futCatalogOddsSize=size
clear(body)
for(const one of plan)body.appendChild(one.row?oddsRow(one.row):el(doc,'div',{class:'fut-catalog-odds-group',text:one.label}))}
function renderDesc(node,tile){const rows=Array.isArray(tile.desc)?tile.desc:[]
const has=rows.length>0?'1':'0'
if(node.dataset&&node.dataset.futCatalogDescHas!==has)node.dataset.futCatalogDescHas=has
const button=node.querySelector?.('[data-fut-catalog-desc-toggle]')
const list=node.querySelector?.('[data-fut-catalog-desc-list]')
if(!button||!list)return
if(rows.length===0)return
const line=rows.join(' ')
write(node.querySelector?.('[data-fut-catalog-desc-text]'),line)
nameNode(button,line)
write(node.querySelector?.('[data-fut-catalog-desc-title]'),t('storeCatalog.desc.title'))
nameNode(node.querySelector?.('[data-fut-catalog-desc-close]'),t('storeCatalog.odds.close'))
const open=openMark(String(tile.id),'desc')
if(node.dataset&&node.dataset.futCatalogDescOpen!==open)node.dataset.futCatalogDescOpen=open
button.setAttribute?.('aria-expanded',open==='1'?'true':'false')
const body=node.querySelector?.('[data-fut-catalog-desc-body]')
if(!body)return
const size=printMark(rows)
if(body.dataset?.futCatalogDescSize===size)return
if(body.dataset)body.dataset.futCatalogDescSize=size
clear(body)
for(const one of rows)body.appendChild(el(doc,'p',{class:'fut-catalog-desc-para',text:one}))}
function oddsRow(row){return el(doc,'div',{class:'fut-catalog-odds-row'},[el(doc,'span',{class:'fut-catalog-odds-name',text:row.text}),
el(doc,'span',{class:'fut-catalog-odds-value',text:row.odds})])}
function toggleWindow(key,kind){openWin=openWin!==null&&openWin.key===key&&openWin.kind===kind?null:{key,kind}
refreshView()}
function closeWindow(){if(openWin===null)return false
openWin=null
refreshView()
return true}
function openMark(key,kind){return openWin!==null&&openWin.key===key&&openWin.kind===kind?'1':'0'}
function watchBox(box){if(doorman&&doorman.box===box)return false
unwatchBox()
if(typeof box?.addEventListener!=='function')return false
const onDown=(event)=>{if(openWin===null)return
const node=event?.target
if(node?.closest?.('[data-fut-catalog-odds-list]'))return
if(node?.closest?.('[data-fut-catalog-odds-toggle]'))return
if(node?.closest?.('[data-fut-catalog-desc-list]'))return
if(node?.closest?.('[data-fut-catalog-desc-toggle]'))return
closeWindow()}
const onKey=(event)=>{if(openWin===null)return
if(event?.key!=='Escape')return
closeWindow()}
box.addEventListener('pointerdown',onDown)
if(typeof doc?.addEventListener==='function')doc.addEventListener('keydown',onKey)
doorman={box,onDown,onKey}
return true}
function unwatchBox(){if(doorman===null)return false
try{doorman.box?.removeEventListener?.('pointerdown',doorman.onDown)}catch{}
try{doc?.removeEventListener?.('keydown',doorman.onKey)}catch{}
doorman=null
return true}
function renderValue(node,card){const box=node.querySelector?.('[data-fut-catalog-value]')
if(!box)return
const has=card.value!==null?'1':'0'
if(box.dataset&&box.dataset.futCatalogValueHas!==has)box.dataset.futCatalogValueHas=has
if(card.value===null)return
const value=card.value
const text=box.querySelector?.('[data-fut-catalog-value-text]')
const time=box.querySelector?.('[data-fut-catalog-value-time]')
const icon=box.querySelector?.('[data-fut-catalog-value-icon]')
const clock=box.querySelector?.('[data-fut-catalog-value-clock]')
setMark(box,'futCatalogValueState',value.state)
if(value.state==='unseen'){write(text,t('storeCatalog.value.unseen'))
setMark(box,'futCatalogValueTone','none')
for(const key of ['futCatalogValueVerdict','futCatalogValueMarket','futCatalogValueUnpriced','futCatalogValueSource'])setMark(box,key,'')
setTitle(text,'')
drawValueIcon(icon,'wait')
write(clock,'')
setTitle(time,t('storeCatalog.value.wait.title'))
return}
if(value.state==='known'){write(text,t('storeCatalog.value.known'))
setMark(box,'futCatalogValueTone','none')
setTitle(text,t('storeCatalog.value.known.title'))
setMark(box,'futCatalogValueVerdict','')
setMark(box,'futCatalogValueMarket','')
setMark(box,'futCatalogValueUnpriced','')
setMark(box,'futCatalogValueSource','')
renderClock(value.left,icon,clock,time)
return}
const sums=value.sums
const said=peekVerdictWords(sums,t,formatCoins)
write(text,said.approx?`${t('packPeek.approx')} ${said.word}`:said.word)
setTitle(text,said.title)
setMark(box,'futCatalogValueTone',said.tone)
setMark(box,'futCatalogValueVerdict',sums.verdict===null?'':String(sums.verdict))
setMark(box,'futCatalogValueMarket',String(sums.market))
setMark(box,'futCatalogValueUnpriced',String(sums.unpriced))
setMark(box,'futCatalogValueSource',value.remembered===true?'memory':'ea')
renderClock(value.left,icon,clock,time)}
function renderClock(left,icon,clock,time){const parts=clockParts(left)
if(parts===null){drawValueIcon(icon,'none')
write(clock,'')
setTitle(time,'')
return}
drawValueIcon(icon,'clock')
write(clock,t('storeCatalog.value.clock',parts))
setTitle(time,t('storeCatalog.value.refresh.title',parts))}
function drawValueIcon(host,kind){if(!host)return
if(host.dataset?.futCatalogValueIconKind===kind)return
if(host.dataset)host.dataset.futCatalogValueIconKind=kind
clear(host)
if(kind==='wait'){write(host,'⏳')
return}
if(kind!=='clock'||typeof doc?.createElementNS!=='function')return
const SVG='http://www.w3.org/2000/svg'
const shape=(tag,attrs)=>{const one=doc.createElementNS(SVG,tag)
for(const[name,value]of Object.entries(attrs))one.setAttribute(name,String(value))
return one}
const box=shape('svg',{viewBox:'0 0 16 16',fill:'none','aria-hidden':'true'})
box.appendChild(shape('circle',{cx:8,cy:8,r:6.5,stroke:'currentColor','stroke-width':1.6}))
box.appendChild(shape('path',{d:'M8 4.2V8L10.6 9.6',stroke:'currentColor','stroke-width':1.6,'stroke-linecap':'round','stroke-linejoin':'round'}))
host.appendChild(box)}
function setMark(node,key,value){if(node?.dataset&&node.dataset[key]!==value)node.dataset[key]=value}
function setTitle(node,text){if(!node)return
if(text===''){if(node.getAttribute?.('title')!==null)node.removeAttribute?.('title')
return}
if(node.getAttribute?.('title')!==text)node.setAttribute?.('title',text)}
function renderReveal(node,card){const shot=node.querySelector?.('[data-fut-catalog-shot]')
if(!shot)return
const best=card.value?.state==='seen'||card.value?.state==='known'?(card.tile.preview?.best??null):null
const had=reveals.get(card.key)??null
if(had&&had.item===best){setMark(shot,'futCatalogRevealed',had.node?'1':'0')
return}
dropReveal(card.key)
setMark(shot,'futCatalogRevealed','0')
if(!best)return
const host=el(doc,'span',{class:'fut-catalog-reveal',dataset:{futCatalogReveal:'1'}})
shot.appendChild(host)
let made=null
try{made=mountCard(doc?.defaultView??null,host,best)}catch(err){onError(err)
made=null}
if(!made?.ok){host.remove?.()
reveals.set(card.key,{item:best,node:null,dispose(){},step:made?.step??'failed'})
return}
reveals.set(card.key,{item:best,node:host,dispose(){try{made.dispose?.()}catch(err){onError(err)}
host.remove?.()}})
setMark(shot,'futCatalogRevealed','1')}
function dropReveal(key){const had=reveals.get(key)
if(!had)return
reveals.delete(key)
try{had.dispose()}catch(err){onError(err)}}
function renderButtons(node,card){const{tile}=card
const main=mainAction(tile)
const alt=altAction(tile)
const buy=node.querySelector?.('[data-fut-catalog-buy]')
const altNode=node.querySelector?.('[data-fut-catalog-alt]')
if(buy){const button=nativeButton(tile.root,main.kind)
const off=main.kind==='none'||nativeOff(button)||busy.has(card.key)
write(buy.querySelector?.('[data-fut-catalog-buy-text]'),main.kind==='preview'
?t('storeCatalog.buy.preview')
:main.kind==='points'
?t('storeCatalog.buy.points',{points:formatCoins(main.price)})
:main.kind==='coins'
?t('storeCatalog.buy.coins',{coins:formatCoins(main.price)})
:t('storeCatalog.buy.none'))
if(buy.dataset&&buy.dataset.futCatalogBuyKind!==main.kind)buy.dataset.futCatalogBuyKind=main.kind
if(buy.disabled!==off)buy.disabled=off}
if(altNode){const button=alt===null?null:nativeButton(tile.root,alt.kind)
const has=alt===null?'0':'1'
if(altNode.dataset&&altNode.dataset.futCatalogAltHas!==has)altNode.dataset.futCatalogAltHas=has
write(altNode.querySelector?.('[data-fut-catalog-alt-text]'),alt===null?'':t('storeCatalog.alt.points',{points:formatCoins(alt.price)}))
const off=alt===null||nativeOff(button)||busy.has(card.key)
if(altNode.disabled!==off)altNode.disabled=off}}
function press(key,where){const tile=(last?.tiles??[]).find((one)=>String(one.id)===key)??null
if(!tile){lastPress={key,where,ok:false,reason:'no-pack'}
return false}
if(busy.has(key)){lastPress={key,where,ok:false,reason:'busy'}
return false}
const action=where==='alt'?altAction(tile):mainAction(tile)
if(action===null||action.kind==='none'){lastPress={key,where,ok:false,reason:'no-action'}
return false}
const button=nativeButton(tile.root,action.kind)
if(!button?.dispatchEvent){lastPress={key,where,ok:false,reason:'no-native'}
return false}
if(nativeOff(button)){lastPress={key,where,ok:false,reason:'native-off'}
return false}
const win=doc?.defaultView??null
const send=(type,ctor)=>{const Ctor=win?.[ctor]??win?.MouseEvent
if(typeof Ctor!=='function')return
try{button.dispatchEvent(new Ctor(type,{bubbles:true,cancelable:true,composed:true}))}catch(err){onError(err)}}
send('pointerdown','PointerEvent')
send('mousedown','MouseEvent')
send('mouseup','MouseEvent')
send('click','MouseEvent')
busy.set(key,{at:captures})
lastPress={key,where,ok:true,reason:action.kind}
refreshView()
return true}
function releaseBusy(){if(busy.size===0)return
const held=screenBusy(last?.screen??null)
for(const[key,lock]of[...busy]){const tile=(last?.tiles??[]).find((one)=>String(one.id)===key)??null
if(!tile){busy.delete(key)
continue}
if(captures>lock.at){busy.delete(key)
continue}
if(!held)busy.delete(key)}}
function setArt(host,src){if(!host)return
const existing=host.querySelector?.('[data-fut-catalog-img]')??null
if(host.dataset)host.dataset.futCatalogEmpty=src===''?'1':'0'
if(src===''){existing?.remove?.()
return}
if(existing){if(existing.getAttribute?.('src')!==src)existing.setAttribute?.('src',src)
return}
const node=el(doc,'img',{class:'fut-catalog-img',attrs:{src,alt:''},dataset:{futCatalogImg:'1'}})
if(typeof host.insertBefore==='function'&&host.firstChild)host.insertBefore(node,host.firstChild)
else host.appendChild(node)}
function flatten(box){const note=box?.querySelector?.(DISCLAIMER_SELECTOR)??null
const empty=note!==null&&String(note.textContent??'').trim()===''
if(!box?.dataset)return false
if(empty){if(box.dataset[FLAT_FLAG]!=='1')box.dataset[FLAT_FLAG]='1'}
else if(box.dataset[FLAT_FLAG]==='1')delete box.dataset[FLAT_FLAG]
return empty}
function drop(box){if(!box)return
unwatchBox()
openWin=null
box.querySelector?.(OURS_SELECTOR)?.remove?.()
if(box.dataset&&box.dataset[HOST_FLAG]==='1')delete box.dataset[HOST_FLAG]
if(box.dataset&&box.dataset[FLAT_FLAG]==='1')delete box.dataset[FLAT_FLAG]
for(const node of box.querySelectorAll?.(PACK_SELECTOR)??[]){if(node.dataset)delete node.dataset.futCatalogPack}}
function write(node,text){if(node&&node.textContent!==text)node.textContent=text}
function nameNode(node,title,attr=null){if(attr!==null){if(node?.getAttribute?.(attr)!==title)node?.setAttribute?.(attr,title)
return}
if(node?.getAttribute?.('title')!==title)node?.setAttribute?.('title',title)
if(node?.getAttribute?.('aria-label')!==title)node?.setAttribute?.('aria-label',title)}
return{apply,
refresh(){releaseBusy()
if(!last)return false
return settle().ok===true},
relabel(){if(!last)return false
return settle().ok===true},
dispose(){const box=last?.box??null
busy.clear()
for(const key of [...reveals.keys()])dropReveal(key)
unwatchBox()
if(box)drop(box)
last=null},
state:()=>({active:isActive(STORE_CATALOG_FEATURE),lastResult,
build:'STOREFC27-1',
packs:last?.tiles?.length??0,shown:view.trade,pinned,
query:view.query,sort:sanitizeCatalogSort(view.sort),
odds:openWin?.kind==='odds'?openWin.key:null,
desc:openWin?.kind==='desc'?openWin.key:null,
oddsRaw:(last?.tiles??[]).map((one)=>({id:one.id,
name:readCatalogFacts(one.root).name,
raw:Number.isFinite(one.oddsRaw)?one.oddsRaw:-1,
rows:Array.isArray(one.odds)?one.odds.length:0,
picks:(Array.isArray(one.odds)?one.odds:[]).filter((row)=>row?.group==='picks').length,
lost:one.oddsLost??{total:0,rows:[]}})),
order:[...(doc?.querySelectorAll?.('[data-fut-catalog-card]')??[])]
.map((node)=>({id:String(node.dataset?.futCatalogCard??''),
place:Number(node.dataset?.futCatalogOrder??0),
hidden:node.dataset?.futCatalogHidden==='1'}))
.sort((a,b)=>a.place-b.place),
showHidden:view.showHidden,hiddenStorage:Boolean(isHidden&&setHidden),
hidden:(last?.tiles??[]).filter((one)=>hiddenOf(String(one.id))).map((one)=>String(one.id)),
busy:[...busy.keys()],held:screenBusy(last?.screen??null),
lastPress,work:{settles,renders,captures}})}}
