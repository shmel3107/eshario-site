import{COMPARE,OPERATION,REQUIREMENT_KEY,RATING_TIER,checkSquad,groupsOf,needOf,parseRequirements,rarityOf,tierOf} from '../automation/sbc-requirements.js'
import{searchBurnOf} from '../automation/card-value.js'
import{preferenceOf} from '../automation/sbc-solver.js'
import{ctxOf} from './sbc-valuation.js'
export const LIGHT_KEYS=Object.freeze(new Set([REQUIREMENT_KEY.PLAYER_QUALITY,REQUIREMENT_KEY.PLAYER_LEVEL,REQUIREMENT_KEY.PLAYER_RARITY,REQUIREMENT_KEY.PLAYER_RARITY_GROUP,REQUIREMENT_KEY.PLAYER_COUNT,REQUIREMENT_KEY.PLAYER_COUNT_COMBINED,REQUIREMENT_KEY.PLAYER_MIN_OVR,REQUIREMENT_KEY.PLAYER_EXACT_OVR,REQUIREMENT_KEY.PLAYER_MAX_OVR]))
export function isLightChallenge(requirements,operation){if(operation===OPERATION.OR)return false
const{requirements:parsed,skipped}=parseRequirements(requirements)
if(skipped>0||parsed.length===0)return false
return parsed.every((req)=>!Array.isArray(req?.combined)&&LIGHT_KEYS.has(req?.key)&&needOf(req)!==null)}
export function orderByBurn(pool,input={}){const list=Array.isArray(pool)?[...pool]:[]
const valuation=input.valuation&&typeof input.valuation==='object'?input.valuation:null
const cachedPriceOf=typeof input.cachedPriceOf==='function'?input.cachedPriceOf:undefined
const mark=new Map(list.map((player)=>[player,valuation
?{untradeable:0,price:searchBurnOf(player,valuation.prices,{...ctxOf(valuation),priceOf:cachedPriceOf}),rarity:weightOf(player),rating:ratingOf(player)}
:preferenceOf(player,{cachedPriceOf})]))
return list.sort((a,b)=>{const pa=mark.get(a)
const pb=mark.get(b)
if(pa.untradeable!==pb.untradeable)return pa.untradeable-pb.untradeable
if(pa.price!==pb.price)return pa.price-pb.price
const ra=pa.rarity??0
const rb=pb.rarity??0
if(ra!==rb)return ra-rb
if(pa.rating!==pb.rating)return pa.rating-pb.rating
return String(a?.id??'').localeCompare(String(b?.id??''))})}
const ratingOf=(player)=>(Number.isFinite(player?.rating)?player.rating:0)
const weightOf=(player)=>{const rarity=rarityOf(player)
return Number.isFinite(rarity)?rarity:0}
function qualityGate(parsed){const checks=[]
for(const req of parsed){if(req?.key!==REQUIREMENT_KEY.PLAYER_QUALITY)continue
const need=needOf(req)
if(!Number.isFinite(need))continue
if(req.compare===COMPARE.GREATER)checks.push((tier)=>tier>=need)
else if(req.compare===COMPARE.LOWER)checks.push((tier)=>tier<=need)
else checks.push((tier)=>tier===need)}
if(checks.length===0)return null
return(player)=>{const tier=tierOf(player)
return tier!==RATING_TIER.NONE&&checks.every((check)=>check(tier))}}
const READABLE=Object.freeze({[REQUIREMENT_KEY.PLAYER_QUALITY]:(p)=>tierOf(p)!==RATING_TIER.NONE,
[REQUIREMENT_KEY.PLAYER_LEVEL]:(p)=>tierOf(p)!==RATING_TIER.NONE,
[REQUIREMENT_KEY.PLAYER_RARITY]:(p)=>Number.isFinite(rarityOf(p)),
[REQUIREMENT_KEY.PLAYER_RARITY_GROUP]:(p)=>groupsOf(p).length>0,
[REQUIREMENT_KEY.PLAYER_MIN_OVR]:(p)=>Number.isFinite(p?.rating),
[REQUIREMENT_KEY.PLAYER_MAX_OVR]:(p)=>Number.isFinite(p?.rating),
[REQUIREMENT_KEY.PLAYER_EXACT_OVR]:(p)=>Number.isFinite(p?.rating)})
function cardGate(parsed){const checks=[]
for(const req of Array.isArray(parsed)?parsed:[]){const read=READABLE[req?.key]
if(read!==undefined&&!checks.includes(read))checks.push(read)}
const quality=qualityGate(parsed)
if(quality!==null)checks.push(quality)
if(checks.length===0)return null
return(player)=>checks.every((check)=>check(player))}
export function judgeLightSquad(input={}){const players=Array.isArray(input.players)?input.players:[]
if(players.length===0)return{ok:false,reason:'empty'}
const{requirements:parsed}=parseRequirements(input.requirements)
const gate=cardGate(parsed)
if(gate!==null&&!players.every((player)=>gate(player)))return{ok:false,reason:'unreadable'}
const verdict=checkSquad({players},input.requirements,{operation:input.operation})
if(verdict.ok)return{ok:true,reason:null}
return{ok:false,reason:verdict.failed.length>0?'failed':'unknown'}}
function matcherOf(req){const values=Array.isArray(req?.values)&&req.values.length>0?req.values.filter(Number.isFinite):[]
const value=Number.isFinite(req?.value)?req.value:null
switch(req?.key){
case REQUIREMENT_KEY.PLAYER_LEVEL:return values.length===0?null:(p)=>values.includes(tierOf(p))
case REQUIREMENT_KEY.PLAYER_RARITY:return values.length===0?null:(p)=>values.includes(rarityOf(p))
case REQUIREMENT_KEY.PLAYER_RARITY_GROUP:return values.length===0?null:(p)=>values.some((v)=>groupsOf(p).includes(v))
case REQUIREMENT_KEY.PLAYER_MIN_OVR:return value===null?null:(p)=>Number.isFinite(p?.rating)&&p.rating>=value
case REQUIREMENT_KEY.PLAYER_MAX_OVR:return value===null?null:(p)=>Number.isFinite(p?.rating)&&p.rating<=value
case REQUIREMENT_KEY.PLAYER_EXACT_OVR:return value===null?null:(p)=>p?.rating===value
default:return null}}
export function pickLightSquad(input={}){const free=Number.isFinite(input.free)&&input.free>0?Math.floor(input.free):0
if(free===0)return null
const{requirements:parsed}=parseRequirements(input.requirements)
const gate=cardGate(parsed)
const keyOf=typeof input.keyOf==='function'?input.keyOf:null
const taken=Array.isArray(input.taken)?input.taken:[]
if(gate!==null&&!taken.every((player)=>gate(player)))return null
const pool=(Array.isArray(input.pool)?input.pool:[]).filter((player)=>gate===null||gate(player))
const wants=[]
const caps=[]
for(const req of parsed){const match=matcherOf(req)
if(match===null)continue
const need=needOf(req)
if(!Number.isFinite(need))continue
if(req.compare===COMPARE.LOWER){caps.push({match,max:need})
continue}
wants.push({match,need})
if(req.compare===COMPARE.EXACT)caps.push({match,max:need})}
const count=(match)=>taken.reduce((sum,player)=>sum+(match(player)?1:0),0)
const capCount=caps.map((cap)=>count(cap.match))
const wantCount=wants.map((want)=>count(want.match))
const busy=new Set()
if(keyOf!==null)for(const player of taken){const key=keyOf(player)
if(key!==null&&key!==undefined)busy.add(key)}
const used=new Set()
const chosen=[]
const fits=(player)=>{if(used.has(player))return false
if(keyOf!==null){const key=keyOf(player)
if(key!==null&&key!==undefined&&busy.has(key))return false}
for(let i=0;i<caps.length;i+=1){if(caps[i].match(player)&&capCount[i]+1>caps[i].max)return false}
return true}
const take=(player)=>{used.add(player)
chosen.push(player)
if(keyOf!==null){const key=keyOf(player)
if(key!==null&&key!==undefined)busy.add(key)}
for(let i=0;i<caps.length;i+=1)if(caps[i].match(player))capCount[i]+=1
for(let i=0;i<wants.length;i+=1)if(wants[i].match(player))wantCount[i]+=1}
for(let i=0;i<wants.length;i+=1){for(const player of pool){if(wantCount[i]>=wants[i].need||chosen.length>=free)break
if(!wants[i].match(player)||!fits(player))continue
take(player)}
if(wantCount[i]<wants[i].need)return null}
for(const player of pool){if(chosen.length>=free)break
if(!fits(player))continue
take(player)}
return chosen.length===free?chosen:null}
