import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoLink,logoMark} from '../ui/controls.js'
import{netAfterTax,taxFor} from './tax.js'
import{priceBadgePeek} from './price-badges.js'
import{itemForEvidenceRow} from './item-evidence.js'
import{localizeNumber} from '../adapter/ea.js'
import{CARD_VIEW_STYLESHEET,CARD_VIEW_LINK_ID} from './card-views.js'
export const DEAL_GOOD='good'
export const DEAL_MARKET='market'
export const DEAL_BAD='bad'
export const DEAL_MARK='futDeal'
export const DEAL_SELECTOR='[data-fut-deal]'
export const DEAL_TIME_MARK='futDealTime'
export const DEAL_TIME_SELECTOR='[data-fut-deal-time]'
export const DEAL_TIME_SOON='soon'
export const DEAL_GAIN_CLASS='fx-deal-gain'
export const DEAL_GAIN_MARK='futDealGain'
export const DEAL_GAIN_SELECTOR='[data-fut-deal-gain]'
export const DEAL_GAIN_LABEL_CLASS='fx-deal-gain-label'
export const DEAL_GAIN_NAME_CLASS='fx-deal-gain-name'
export const DEAL_GAIN_VALUE_CLASS='fx-deal-gain-value'
export const DEAL_GAIN_NONE='none'
export const DEAL_SOON_SECONDS=60
export function judgeDeal(market,buy){const price=coins(market)
const ask=coins(buy)
const silent={verdict:null,market:price>0?price:null,buy:ask>0?ask:null,net:null,gain:null,band:null}
if(price<=0)return Object.freeze(silent)
if(ask<=0)return Object.freeze(silent)
const net=netAfterTax(price)
const band=taxFor(price)
const gain=net-ask
const verdict=ask<net?DEAL_GOOD:(ask<=price+band?DEAL_MARKET:DEAL_BAD)
return Object.freeze({verdict,market:price,buy:ask,net,gain,band})}
function coins(value){const number=Number(value)
if(!Number.isFinite(number)||number<=0)return 0
return Math.round(number)}
export function dealCoinsText(win,value){const number=Math.round(Number(value)||0)
const body=dealCoins(win,Math.abs(number))
if(number>0)return`+${body}`
if(number<0)return`−${body}`
return body}
export function dealCoins(win,value){const digits=Math.max(0,Math.round(Number(value)||0))
const said=localizeNumber(win,digits)
if(said!==null)return said
return String(digits).replace(/\B(?=(\d{3})+(?!\d))/g,' ')}
export function auctionParts(row){let money=null
try{money=row?.querySelector?.('.auction')??null}catch{money=null}
if(!money)return null
let kids=[]
try{kids=Array.from(money.children??[])}catch{kids=[]}
if(kids.length<4)return null
let time=null
try{time=money.querySelector?.('.auction-state')??null}catch{time=null}
return{money,buy:kids[2]??null,time}}
function secondsOf(item){try{const auction=item?.getAuctionData?.()
if(!auction||typeof auction.getSecondsRemaining!=='function')return null
const left=Number(auction.getSecondsRemaining())
return Number.isFinite(left)?left:null}catch{return null}}
function buyOf(item){try{const auction=item?.getAuctionData?.()
const value=Number(auction?.buyNowPrice)
return Number.isFinite(value)&&value>0?Math.round(value):0}catch{return 0}}
function defOf(item){const raw=item?.definitionId??item?.defId
const id=Number(raw)
return Number.isSafeInteger(id)&&id>0?id:null}
export function judgeRow(row,deps={}){const itemOf=typeof deps.itemOf==='function'?deps.itemOf:itemForEvidenceRow
let item=null
try{item=itemOf(row)??null}catch{item=null}
if(!item)return{deal:judgeDeal(null,null),item:null,seconds:null}
return judgeItem(item,deps)}
export function judgeItem(item,deps={}){const priceOf=typeof deps.priceOf==='function'?deps.priceOf:priceBadgePeek
if(!item)return{deal:judgeDeal(null,null),item:null,seconds:null}
const id=defOf(item)
let market=null
if(id!==null){try{market=priceOf(id)}catch{market=null}}
return{deal:judgeDeal(market,buyOf(item)),item,seconds:secondsOf(item)}}
function paintGain(doc,money,buyHost,verdict,label,text){if(!money)return false
let row=null
try{row=money.querySelector?.(DEAL_GAIN_SELECTOR)??null}catch{row=null}
if(text===null||verdict===null){if(!row)return false
row.remove?.()
return true}
if(row){let touched=false
if(row.dataset&&row.dataset[DEAL_GAIN_MARK]!==verdict){row.dataset[DEAL_GAIN_MARK]=verdict
touched=true}
let value=null
try{value=row.querySelector?.(`.${DEAL_GAIN_VALUE_CLASS}`)??null}catch{value=null}
if(value&&value.textContent!==text){value.textContent=text
touched=true}
let name=null
try{name=row.querySelector?.(`.${DEAL_GAIN_NAME_CLASS}`)??null}catch{name=null}
if(name&&name.textContent!==label){name.textContent=label
touched=true}
return touched}
const node=el(doc,'div',{class:DEAL_GAIN_CLASS,dataset:{[DEAL_GAIN_MARK]:verdict}},
[el(doc,'span',{class:DEAL_GAIN_LABEL_CLASS},
[logoMark(doc),el(doc,'span',{class:DEAL_GAIN_NAME_CLASS,text:label})]),
el(doc,'span',{class:DEAL_GAIN_VALUE_CLASS,text})])
const after=buyHost?.nextSibling??null
if(after)money.insertBefore(node,after)
else money.appendChild(node)
return true}
export function paintDealRows(input={}){const{doc}=input
const out={seen:0,good:0,market:0,bad:0,silent:0,noPrice:0,noBuy:0,gains:0,soon:0,writes:0}
if(!doc)return out
const t=typeof input.t==='function'?input.t:(key)=>key
const onError=typeof input.onError==='function'?input.onError:()=>{}
const win=input.win??doc.defaultView??null
for(const row of Array.isArray(input.rows)?input.rows:[]){try{const parts=auctionParts(row)
if(!parts)continue
out.seen+=1
const{deal,seconds}=judgeRow(row,input)
const verdict=deal.verdict
if(verdict===DEAL_GOOD)out.good+=1
else if(verdict===DEAL_MARKET)out.market+=1
else if(verdict===DEAL_BAD)out.bad+=1
else out.silent+=1
const noBuy=verdict===null&&deal.buy===null
const noPrice=verdict===null&&!noBuy
if(noBuy)out.noBuy+=1
if(noPrice)out.noPrice+=1
const buyHost=parts.buy
if(buyHost?.dataset){if(verdict===null){if(buyHost.dataset[DEAL_MARK]!==undefined){delete buyHost.dataset[DEAL_MARK]
out.writes+=1}}
else if(buyHost.dataset[DEAL_MARK]!==verdict){buyHost.dataset[DEAL_MARK]=verdict
out.writes+=1}}
const gainWord=noBuy?null
:(verdict===null?t('deal.noPrice')
:(verdict===DEAL_MARKET?t('transfers.chip.market'):dealCoinsText(win,deal.gain)))
const gainMark=noBuy?null:(verdict===null?DEAL_GAIN_NONE:verdict)
if(gainWord!==null)out.gains+=1
if(paintGain(doc,parts.money,buyHost,gainMark,t('deal.gain'),gainWord))out.writes+=1
const soon=typeof seconds==='number'&&seconds>0&&seconds<DEAL_SOON_SECONDS
if(soon)out.soon+=1
const timeHost=parts.time
if(timeHost?.dataset){if(soon){if(timeHost.dataset[DEAL_TIME_MARK]!==DEAL_TIME_SOON){timeHost.dataset[DEAL_TIME_MARK]=DEAL_TIME_SOON
out.writes+=1}}
else if(timeHost.dataset[DEAL_TIME_MARK]!==undefined){delete timeHost.dataset[DEAL_TIME_MARK]
out.writes+=1}}}catch(err){onError(err)}}
return out}
export function clearDealMarks(doc){let gone=0
const drop=(selector,mark)=>{for(const node of Array.from(doc?.querySelectorAll?.(selector)??[])){if(node?.dataset&&node.dataset[mark]!==undefined){delete node.dataset[mark]
gone+=1}}}
drop(DEAL_SELECTOR,DEAL_MARK)
drop(DEAL_TIME_SELECTOR,DEAL_TIME_MARK)
for(const gain of Array.from(doc?.querySelectorAll?.(DEAL_GAIN_SELECTOR)??[])){gain.remove?.()
gone+=1}
return gone}
export const DEAL_PANEL_CLASS='fx-deal-panel'
export const DEAL_PANEL_MARK='futDealPanel'
export const DEAL_PANEL_SELECTOR='[data-fut-deal-panel]'
export const DEAL_PANEL_ANCHOR='.bidOptions'
export const DEAL_PANEL_SILENT='silent'
export const DEAL_PANEL_CELLS=Object.freeze([
Object.freeze({key:'market',label:'deal.market'}),
Object.freeze({key:'net',label:'deal.net'}),
Object.freeze({key:'gain',label:'deal.gain'})])
export const DEAL_PANEL_DASH='–'
export function createDealPanel(deps={}){const{doc}=deps
const t=typeof deps.t==='function'?deps.t:(key)=>key
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const win=()=>doc?.defaultView??null
let passes=0
let writes=0
let shown=0
let lot=null
const painted=new WeakMap()
const allowed=()=>{if(typeof deps.isActive!=='function')return false
try{return deps.isActive()===true}catch(err){onError(err)
return false}}
const onMarket=()=>{if(typeof deps.onMarket!=='function')return false
try{return deps.onMarket()===true}catch(err){onError(err)
return false}}
function anchorOf(){const root=lot?.root??null
if(!root||root.isConnected===false)return null
try{return root.querySelector?.(DEAL_PANEL_ANCHOR)??null}catch(err){onError(err)
return null}}
function rowsOf(){try{return Array.from(doc?.querySelectorAll?.(DEAL_PANEL_SELECTOR)??[])}catch{return[]}}
function clear(){let gone=0
for(const node of rowsOf()){painted.delete(node)
node.remove?.()
gone+=1}
if(gone>0)writes+=1
return gone}
function build(){const node=el(doc,'div',{class:DEAL_PANEL_CLASS,dataset:{[DEAL_PANEL_MARK]:DEAL_PANEL_SILENT}})
node.appendChild(logoLink(doc,'fx-deal-panel-mark'))
for(const cell of DEAL_PANEL_CELLS){const box=el(doc,'div',{class:`fx-deal-panel-cell fx-deal-panel-${cell.key}`})
box.appendChild(el(doc,'span',{class:'fx-deal-panel-label'}))
box.appendChild(el(doc,'span',{class:'fx-deal-panel-value'}))
node.appendChild(box)}
return node}
function signature(verdict,texts){return JSON.stringify([verdict,texts])}
function paint(){passes+=1
if(!allowed()||!onMarket())return clear()
const anchor=anchorOf()
if(!anchor)return clear()
const host=anchor.parentNode
if(!host)return clear()
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,CARD_VIEW_STYLESHEET,CARD_VIEW_LINK_ID)
let node=null
for(const one of rowsOf()){if(node===null&&one.parentNode===host)node=one
else{painted.delete(one)
one.remove?.()
writes+=1}}
if(node===null){node=build()
writes+=1}
if(node.parentNode!==host||node.previousElementSibling!==anchor){host.insertBefore(node,anchor.nextSibling)
painted.delete(node)
writes+=1}
const{deal}=judgeItem(lot?.item??null,deps)
const view=win()
const texts=DEAL_PANEL_CELLS.map((cell)=>{const value=deal[cell.key]
if(typeof value!=='number')return[t(cell.label),DEAL_PANEL_DASH]
return[t(cell.label),cell.key==='gain'?dealCoinsText(view,value):dealCoins(view,value)]})
const verdict=deal.verdict??DEAL_PANEL_SILENT
const mark=signature(verdict,texts)
if(painted.get(node)===mark)return 0
painted.set(node,mark)
if(node.dataset)node.dataset[DEAL_PANEL_MARK]=verdict
const labels=Array.from(node.querySelectorAll?.('.fx-deal-panel-label')??[])
const values=Array.from(node.querySelectorAll?.('.fx-deal-panel-value')??[])
for(let at=0;at<texts.length;at+=1){if(labels[at])labels[at].textContent=texts[at][0]
if(values[at])values[at].textContent=texts[at][1]}
writes+=1
if(deal.verdict!==null)shown+=1
return 1}
function apply(capture){const root=capture?.root??null
lot=root?{root,item:capture?.item??null}:null
return lot!==null}
function safePaint(){try{return paint()}catch(err){onError(err)
return 0}}
return{apply,
refresh(){return safePaint()},
relabel(){safePaint()
return true},
dispose(){lot=null
try{clear()}catch(err){onError(err)}},
state(){const node=rowsOf()[0]??null
const{deal}=judgeItem(lot?.item??null,deps)
const out={allowed:allowed(),
market:onMarket(),
lot:lot!==null,
anchor:anchorOf()!==null,
row:node!==null,
verdict:deal.verdict,
deal:{market:deal.market,net:deal.net,gain:deal.gain,buy:deal.buy},
work:{passes,writes,shown},
ports:{isActive:typeof deps.isActive==='function',onMarket:typeof deps.onMarket==='function',priceOf:typeof deps.priceOf==='function'}}
out.line=`панель ${out.row?'есть':'нет'} · тариф ${out.allowed?'открыт':'закрыт'} · выдача ${out.market?'открыта':'нет'} · лот ${out.lot?'выбран':'нет'} · приговор ${out.verdict??'молчит'} · проходов ${passes} · записей ${writes}`
return out}}}
