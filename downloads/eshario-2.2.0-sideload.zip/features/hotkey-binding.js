import{actionForEvent,matchesCombo,defaultBindings,sanitizeBindings,HOTKEY_ACTIONS,HOTKEY_NAV_FEATURE,LAYERS,NEED_ROW_X,NEED_ENTER,NEED_TARGET,NEED_NO_POPUP} from './hotkeys.js'
import{axisNow,enterKindNow,holdAllowed,AXIS_X} from './list-rows.js'
import{popupOpen} from '../adapter/popup-door.js'
import{appBusy,shieldUp,shieldKind} from '../adapter/click-shield.js'
import{createBindCapture,elementEntry,parseElementKey,createConfirmWatcher,roadOfKey,roadOfNode,roadScreenVisible,ROAD_HERE,visibleDialogs,dangerAtNode,cardMatchAt,noteCardKey} from './hotkey-bind.js'
import{eaWord} from '../adapter/item-actions.js'
import{createHotkeyBadges,createHotkeyWindow,createDangerNote} from './hotkey-badges.js'
import{PRESS_GESTURE,layerVisible,lockedCardAt,pressNode,pressTarget,targetOf} from './hotkey-bind.js'
export{PRESS_GESTURE,layerVisible,pressNode,pressTarget,targetOf}
export const HOTKEYS_FEATURE='hotkeys'
export{HOTKEY_NAV_FEATURE}
export const REPEATABLE_ACTIONS=Object.freeze(new Set(['minBidDown','minBidUp','maxBidDown','maxBidUp','minBuyDown','minBuyUp','maxBuyDown','maxBuyUp','nextCard','prevCard','cardLeft','cardRight']))
export function isTypingTarget(node){if(!node||typeof node!=='object') return false
const tag=String(node.tagName??'').toUpperCase()
if(tag==='INPUT'||tag==='TEXTAREA'||tag==='SELECT') return true
if(node.isContentEditable===true)return true
return String(node.contentEditable??'')==='true'
}
function insideAny(boxes,node){const list=Array.isArray(boxes)?boxes:[]
if(list.length===0)return false
for(let up=node;up;up=up.parentElement){if(list.includes(up))return true}
return false}
export function confirmPlan(win,meta){const key=typeof meta?.confirmTitle==='string'?meta.confirmTitle:''
if(key==='')return{allowed:false,title:'',why:'no-name'}
const title=eaWord(win,key)
if(title==='')return{allowed:false,title:'',why:'no-word'}
const rivals=Array.isArray(meta?.confirmNotTitle)?meta.confirmNotTitle:[]
for(const other of rivals){if(eaWord(win,other)===title)return{allowed:false,title:'',why:'same-word'}}
return{allowed:true,title,why:'ok'}}
export function scopedConfirm(meta,node){if(typeof meta?.autoConfirmIn!=='string'||meta.autoConfirmIn==='')return false
try{return node?.closest?.(meta.autoConfirmIn)!=null}catch{return false}}
export function realTarget(event){const path=event?.composedPath?.()
if(Array.isArray(path)&&path.length>0)return path[0]
return event?.target??null}
export const AUTO_CONFIRM_ACTIONS=Object.freeze(new Set(['buyNow','discardItem']))
export const LOCK_GUARDED_ACTIONS=Object.freeze(new Set(['discardItem']))
export const CONCEPT_GUARDED_ACTIONS=Object.freeze(new Set(['listForTransfer','sendToTransfer','sendToStorage','discardItem']))
export const CARD_MATCH_ACTIONS=Object.freeze(new Set(['buyNow','placeBid']))
export const CONCEPT_MARK='[data-fut-sell-concept="1"]'
const LISTING_ROOT='.ut-quick-list-panel-view'
const CONCEPT_LOOKUP_DEPTH=5
export function conceptCardAt(node){let at=node
for(let depth=0;at&&depth<CONCEPT_LOOKUP_DEPTH;depth+=1,at=at.parentElement){const doc=at.ownerDocument
if(at===doc?.body||at===doc?.documentElement)break
let root=null
try{root=at.matches?.(LISTING_ROOT)?at:(at.querySelector?.(LISTING_ROOT)??null)}catch{root=null}
if(root)return root.matches?.(CONCEPT_MARK)===true}
return false}
export const TRAVEL_FRAMES=120
export function roadOfMeta(meta){if(typeof meta?.boundKey!=='string'||meta.boundKey==='')return null
const road=typeof meta.road==='string'&&meta.road!==''?meta.road:roadOfKey(meta.boundKey)
return road===null||road===ROAD_HERE?null:road}
export function bindHotkeys(deps){const{target,isActive,run,bindings=defaultBindings(),onError=()=>{},isBlocked=()=>false,win=null,registry=HOTKEY_ACTIONS,onPress=()=>{},afterPress=()=>{},travel=null,noteRoad=null}=deps
if(!target||typeof target.addEventListener!=='function'){throw new Error('hotkeys: нужна цель с addEventListener')}
if(typeof run!=='function') throw new Error('hotkeys: нужен обработчик действия')
const readRegistry=typeof registry==='function'?registry:()=>registry
const doc=deps.doc??target
const window_=win??doc?.defaultView??null
const readBindings=typeof bindings==='function'?bindings:()=>bindings
const NEEDS=Object.freeze({[NEED_ROW_X]:(page)=>axisNow(page)===AXIS_X,
[NEED_ENTER]:(page)=>enterKindNow(page)!==null,
[NEED_NO_POPUP]:()=>popupOpen(window_)===false,
[NEED_TARGET]:(page,meta)=>targetOf(page,meta)!==null})
const CURSOR_ARROWS=Object.freeze(new Set(['nextCard','prevCard','cardLeft','cardRight']))
const holdOk=(action)=>{if(!REPEATABLE_ACTIONS.has(action))return false
if(!CURSOR_ARROWS.has(action))return true
try{return holdAllowed(doc)}catch(err){onError(err)
return true}}
const nodeOnScreen=(name,meta)=>{const ask=NEEDS[name]
if(typeof ask!=='function')return false
try{return ask(doc,meta)===true}catch(err){onError(err)
return false}}
function handle(event){if(!event)return null
if(typeof isActive==='function'&&!isActive(HOTKEYS_FEATURE)&&!isActive(HOTKEY_NAV_FEATURE)) return null
if(isBlocked())return null
if(isTypingTarget(realTarget(event)))return null
const table=readRegistry()
const action=actionForEvent(event,readBindings(),(feature)=>(typeof isActive==='function'?isActive(feature):true),{registry:table,onScreen:(layer)=>layerVisible(doc,layer),onNeeds:nodeOnScreen})
if(action===null)return typeof travel==='function'?fly(event):null
const meta=table[action]
const seeking=Boolean(meta?.press||meta?.boundKey)
const node=seeking?targetOf(doc,meta):null
if(node&&meta?.roadGuessed===true&&typeof noteRoad==='function'){try{noteRoad(action,node)}catch(err){onError(err)}}
if(seeking&&!node){const road=roadOfMeta(meta)
if(road!==null&&typeof travel==='function'){event.preventDefault?.()
event.stopPropagation?.()
claimUp(event,action)
try{const result=travel(action,meta,road)
if(result&&typeof result.then==='function')result.then(undefined,onError)}catch(err){onError(err)}
return action}
if(typeof meta?.boundKey==='string'&&meta.boundKey!==''){event.preventDefault?.()
event.stopPropagation?.()
claimUp(event,action)
onPress({action,ok:false,reason:parseElementKey(meta.boundKey)?.layer==='global'?'no-road':'no-target'})
return action}
return null}
if(event.repeat===true&&!holdOk(action)){event.preventDefault?.()
return null}
event.preventDefault?.()
event.stopPropagation?.()
claimUp(event,action)
try{const result=seeking?pressAction(action,meta,node):run(action,event)
if(result&&typeof result.then==='function') result.then(undefined,onError)}catch(err){onError(err)}
return action}
function fly(event){const table=readRegistry()
for(const[action,combo]of Object.entries(readBindings()??{})){const meta=table[action]
if(!meta||meta.reserved)continue
const road=roadOfMeta(meta)
if(road===null)continue
if(!matchesCombo(event,combo))continue
if(typeof isActive==='function'&&!isActive(meta.feature))return null
event.preventDefault?.()
if(event.repeat===true)return null
event.stopPropagation?.()
claimUp(event,action)
try{const result=travel(action,meta,road)
if(result&&typeof result.then==='function')result.then(undefined,onError)}catch(err){onError(err)}
return action}
return null}
function pressAction(action,meta,node){
if(CONCEPT_GUARDED_ACTIONS.has(action)&&conceptCardAt(node)){onPress({action,ok:false,reason:'concept'})
return{ok:false,reason:'concept'}}
if(LOCK_GUARDED_ACTIONS.has(action)&&lockedCardAt(node)){onPress({action,ok:false,reason:'locked'})
return{ok:false,reason:'locked'}}
const dialogs=visibleDialogs(doc)
const inWindow=dialogs.length>0&&insideAny(dialogs,node)
if(!inWindow){if(dialogs.length>0||popupOpen(window_)===true){onPress({action,ok:false,reason:'popup'})
return{ok:false,reason:'popup'}}
if(meta?.danger===true){const match=CARD_MATCH_ACTIONS.has(action)?cardMatchAt(node):'no-panel'
if(match==='other'){noteCardKey('other')
onPress({action,ok:false,reason:'other-card'})
return{ok:false,reason:'other-card'}}
if(match==='left-screen'){noteCardKey('left-screen')
onPress({action,ok:false,reason:'left-screen'})
return{ok:false,reason:'left-screen'}}
if(match!=='match'){const up=shieldUp(window_,doc)===true
const fast=up&&match==='live-panel'&&shieldKind(window_,doc)==='redraw'
if(up&&!fast){noteCardKey(match==='blind-finger'?'blind':'busy')
onPress({action,ok:false,reason:'busy'})
return{ok:false,reason:'busy'}}
if(CARD_MATCH_ACTIONS.has(action))noteCardKey(fast?'fast':'quiet')}
else if(CARD_MATCH_ACTIONS.has(action))noteCardKey('match')}}
if(typeof meta?.boundKey==='string'&&meta.boundKey!==''){const own=dangerAtNode(node,readRegistry())
if(own!==null){onPress({action,ok:false,reason:'own-action',owner:own})
return{ok:false,reason:'own-action'}}}
if(CARD_MATCH_ACTIONS.has(action)&&node?.disabled===true){noteCardKey('off')
onPress({action,ok:false,reason:'button-off'})
return{ok:false,reason:'button-off'}}
const pressed=pressNode(node,window_,onError)
onPress({action,ok:pressed,reason:pressed?null:'no-target'})
if(pressed&&(AUTO_CONFIRM_ACTIONS.has(action)||scopedConfirm(meta,node)))
{try{afterPress(action,node,dialogs)}catch(err){onError(err)}}
return{ok:pressed,reason:pressed?null:'no-target'}}
let claimed=null
const claimUp=(event,action)=>{const key=typeof event?.key==='string'?event.key:null
if(key===null)return
claimed={key,action}}
const upListener=(event)=>{const key=typeof event?.key==='string'?event.key:null
if(claimed===null||key===null)return
if(claimed.key!==key){claimed=null
return}
claimed=null
event.preventDefault?.()
event.stopPropagation?.()}
const blurListener=()=>{claimed=null}
const listener=(event)=>{handle(event)}
target.addEventListener('keydown',listener,true)
target.addEventListener('keyup',upListener,true)
window_?.addEventListener?.('blur',blurListener)
return{handle,
get bindings(){return readBindings()},
get registry(){return readRegistry()},
visibleLayers(){return Object.keys(LAYERS).filter((layer)=>layer!=='global'&&layerVisible(doc,layer))},dispose(){target.removeEventListener?.('keydown',listener,true)
target.removeEventListener?.('keyup',upListener,true)
window_?.removeEventListener?.('blur',blurListener)
claimed=null}}}
export function installHotkeys(deps){const{doc,win=null,t,isActive=()=>true,isBlocked=()=>false,run,read,write,onNotice=()=>{},onError=()=>{}}=deps
const goSection=typeof deps.goSection==='function'
?(name)=>{try{return deps.goSection(name)??{ok:false,reason:'failed'}}catch(err){onError(err)
return{ok:false,reason:'failed'}}}
:()=>({ok:false,reason:'unavailable'})
const state=()=>{let raw={}
try{raw=read?.()??{}}catch(err){onError(err)
raw={}}
return{bindings:raw.bindings&&typeof raw.bindings==='object'?raw.bindings:{},custom:raw.custom&&typeof raw.custom==='object'?raw.custom:{},badges:raw.badges!==false,dangerSeen:Array.isArray(raw.dangerSeen)?raw.dangerSeen:[]}}
const save=(patch)=>{try{write?.({...state(),...patch})}catch(err){onError(err)}}
const registry=()=>{const custom={}
for(const[key,saved]of Object.entries(state().custom)){if(!parseElementKey(key))continue
custom[key]=elementEntry(key,typeof saved?.label==='string'?saved.label:key,saved?.danger===true,saved?.road)}
return{...HOTKEY_ACTIONS,...custom}}
const bindings=()=>sanitizeBindings(state().bindings,registry())
const badges=createHotkeyBadges({doc,t,isActive,bindings,registry,enabled:()=>state().badges,onError})
const without=(profile,action)=>{const custom={...profile.custom}
const bindings={...profile.bindings}
if(Object.hasOwn(HOTKEY_ACTIONS,action))bindings[action]=''
else{delete custom[action]
delete bindings[action]}
return{custom,bindings}}
const capture=createBindCapture({doc,win,t,bindings,registry,isActive,onError,onNotice,
onBind:(key,entry,combo,drop)=>{const now=state()
const base=drop?without(now,drop):{custom:{...now.custom},bindings:{...now.bindings}}
base.custom[key]={label:entry.label,danger:entry.danger,road:entry.road}
base.bindings[key]=combo
save(base)
refresh()
if(entry?.danger===true)danger.note([{action:key,combo,label:entry.label}])},
onAssign:(action,combo,drop)=>{const now=state()
const base=drop&&drop!==action?without(now,drop):{custom:{...now.custom},bindings:{...now.bindings}}
base.bindings[action]=combo
save(base)
refresh()
const meta=registry()[action]
if(meta?.danger===true)danger.note([{action,combo,label:labelOf(action)}])},
onUnbind:(action)=>{save(without(state(),action))
refresh()}})
const danger=createDangerNote({doc,t,onError,seen:()=>state().dangerSeen,onSeen:(action)=>{const now=state()
if(now.dangerSeen.includes(action))return
save({dangerSeen:[...now.dangerSeen,action]})}})
const dangerKeys=(only=null)=>{const table=registry()
const map=bindings()
return Object.entries(table).filter(([action,meta])=>meta?.danger===true&&meta?.reserved===undefined&&(only===null||action===only)&&(map[action]??'')!=='').map(([action,meta])=>({action,combo:map[action],label:meta.label??(meta.labelKey?t(meta.labelKey):action)}))}
const confirm=createConfirmWatcher({doc,win,onError,onDone:(result)=>{if(result?.ok!==true&&result?.reason==='no-dialog')return
if(result?.ok===true&&AUTO_CONFIRM_ACTIONS.has(result.action))onNotice({key:'hotkeys.buy.confirmed',params:{}})}})
const window_=createHotkeyWindow({doc,t,bindings,registry,isActive,onError,badgesOn:()=>state().badges,
onBadges:(on)=>{save({badges:on===true})
refresh()},
onRebind:(action)=>{const node=doc?.querySelector?.(`[data-fut-hotkey-row="${action}"]`)
capture.openAction(action,node)},
onReset:()=>{save({bindings:{},custom:{}})
refresh()}})
const travel=(action,meta,section)=>{const label=labelOf(action)
if(meta?.danger===true){onNotice({key:'hotkeys.travel.danger',params:{action:label}})
return{ok:false,reason:'danger'}}
if(popupOpen(win)===true){onNotice({key:'hotkeys.travel.popup',params:{action:label}})
return{ok:false,reason:'popup'}}
if(roadScreenVisible(doc,section)){onNotice({key:'hotkeys.press.noTarget',params:{action:label}})
return{ok:false,reason:'already-here'}}
const result=goSection(section)
if(result?.ok!==true){onNotice({key:'hotkeys.travel.unavailable',params:{action:label}})
return result??{ok:false,reason:'failed'}}
return waitFrame(action,meta,label,TRAVEL_FRAMES)}
const arrive=(action,meta,label,left)=>{if(appBusy(win)===true)return waitFrame(action,meta,label,left-1)
let node=null
try{node=targetOf(doc,meta)}catch(err){onError(err)
node=null}
if(node){const pressed=pressNode(node,win,onError)
if(!pressed)onNotice({key:'hotkeys.press.noTarget',params:{action:label}})
return{ok:pressed,reason:pressed?null:'no-target',frames:TRAVEL_FRAMES-left}}
return waitFrame(action,meta,label,left-1)}
const waitFrame=(action,meta,label,left)=>{const frame=win?.requestAnimationFrame
if(left<=0||typeof frame!=='function'){onNotice({key:'hotkeys.travel.noScreen',params:{action:label}})
return{ok:false,reason:left<=0?'no-screen':'no-frames'}}
try{frame.call(win,()=>{arrive(action,meta,label,left)})}catch(err){onError(err)
onNotice({key:'hotkeys.travel.noScreen',params:{action:label}})
return{ok:false,reason:'failed'}}
return{ok:null,reason:'waiting'}}
const roadStored=(saved)=>saved?.road===null||(typeof saved?.road==='string'&&saved.road!=='')
const noteRoad=(action,node)=>{const now=state()
const saved=now.custom[action]
if(!saved||typeof saved!=='object')return null
if(roadStored(saved))return null
let road=null
try{road=roadOfNode(node,doc).section}catch(err){onError(err)
return null}
if(road===undefined)return null
save({custom:{...now.custom,[action]:{...saved,road}}})
return road}
const dropRoadless=()=>{const now=state()
const gone=[]
const custom={...now.custom}
const map={...now.bindings}
for(const[key,saved]of Object.entries(now.custom)){
if(parseElementKey(key)===null)continue
const road=roadStored(saved)?saved.road:roadOfKey(key)
if(road!==null)continue
if(parseElementKey(key)?.layer!=='global')continue
gone.push(typeof saved?.label==='string'&&saved.label!==''?saved.label:key)
delete custom[key]
delete map[key]}
if(gone.length===0)return 0
save({custom,bindings:map})
if(licensed())onNotice({key:'hotkeys.bind.dropped',params:{count:gone.length,names:gone.slice(0,3).join(', ')}})
return gone.length}
const runAction=(action,event)=>(action==='showKeys'?badges.toggleHelp():run(action,event))
const keys=bindHotkeys({target:doc,doc,win,isActive,run:runAction,bindings,registry,onError,
travel,noteRoad,
afterPress:(action,node,known)=>{const plan=confirmPlan(win,registry()[action])
if(!plan.allowed)return
confirm.arm(node,plan.title,action,known)},
isBlocked:()=>isBlocked()||capture.state()!==null||window_.isOpen()||badges.helpOpen()||danger.isOpen(),
onPress:({action,ok,reason,owner})=>{if(ok)return
if(reason==='no-target'||reason==='left-screen')onNotice({key:'hotkeys.press.noTarget',params:{action:labelOf(action)}})
if(reason==='no-road')onNotice({key:'hotkeys.press.noRoad',params:{action:labelOf(action)}})
if(reason==='locked')onNotice({key:'hotkeys.press.locked',params:{action:labelOf(action)}})
if(reason==='popup')onNotice({key:'hotkeys.press.popup',params:{action:labelOf(action)}})
if(reason==='busy')onNotice({key:'hotkeys.press.busy',params:{action:labelOf(action)}})
if(reason==='other-card')onNotice({key:'hotkeys.press.otherCard',params:{}})
if(reason==='button-off')onNotice({key:'hotkeys.press.buttonOff',params:{action:labelOf(action)}})
if(reason==='own-action')onNotice({key:'hotkeys.bind.ownAction',params:{action:owner??''}})}})
const labelOf=(action)=>{const meta=registry()[action]
return meta?.label??(meta?.labelKey?t(meta.labelKey):action)}
const refresh=()=>{try{capture.refresh()}catch(err){onError(err)}
try{badges.refresh()}catch(err){onError(err)}
if(!licensed()){try{badges.hideHelp()}catch(err){onError(err)}
try{danger.close()}catch(err){onError(err)}}
try{window_.refresh()}catch(err){onError(err)}
if(screenSeen)greet()}
function licensed(){try{return isActive(HOTKEYS_FEATURE)===true}catch(err){onError(err)
return false}}
const greet=()=>{try{if(isActive(HOTKEYS_FEATURE)!==true)return 0
return danger.note(dangerKeys())}catch(err){onError(err)
return 0}}
let greetWaiting=true
let screenSeen=false
const waitForScreen=()=>{const frame=win?.requestAnimationFrame
if(typeof frame!=='function'||!greetWaiting)return
try{frame.call(win,()=>{if(!greetWaiting)return
if(keys.visibleLayers().length>0){greetWaiting=false
screenSeen=true
greet()
return}
waitForScreen()})}catch(err){onError(err)}}
waitForScreen()
const dropped=dropRoadless()
return{keys,badges,capture,danger,confirm,window:window_,refresh,bindings,registry,greet,
dropped,
openWindow:()=>window_.open(),
toggleHelp:()=>badges.toggleHelp(),dispose(){greetWaiting=false
keys.dispose()
capture.dispose()
window_.dispose()
badges.dispose()
danger.close()
confirm.disarm()}}}
