import{sanitizePackLocks} from './pack-locks.js'
import{isDayBudgetError} from './day-budget.js'
import{pricePickPolicy,runPickStep} from './player-picks.js'
import{recoveryPolicy,reviewUnassignedRecovery,runRecoveryStep,runDiscardStep,parseDiscardAllowlist} from './unassigned-recovery.js'
const fail=(reason)=>({ok:false,reason})
const budgetFail=(err,fallback)=>(isDayBudgetError(err)?fail(err.reason):fallback)
const int=Number.isSafeInteger
const arr=Array.isArray,fn=(x)=>typeof x==='function'
const running=new WeakSet()
const sessions=new WeakMap()
const dirs=['club','transfer','storage']
const posInt=(value)=>{if(typeof value==='number')return int(value)&&value>0?value:null
if(typeof value!=='string'||!/^[1-9]\d*$/.test(value))return null
const parsed=Number(value)
return int(parsed)?parsed:null}
const validPack=(pack)=>(pack&&int(pack.id)&&pack.id>=0
&&typeof pack.tradable==='boolean'&&typeof pack.playerPick==='boolean'
&&pack.key===`${pack.id}:${pack.tradable?1:0}`
)
const validPend=(value)=>(value&&arr(value.items)&&int(value.availablePicks)
&&value.availablePicks>=0&&value.availablePicks<=value.items.length
&&(value.availablePicks===0)===(value.items.length===0))
const validPile=(value)=>(value&&arr(value.items)&&int(value.count)
&&value.count>=0&&value.count===value.items.length)
const sameDtos=(a,b)=>arr(a)&&arr(b)&&a.length===b.length&&!a.some((x,i)=>!x||typeof x!=='object'||arr(x)
||Object.entries(x).some(([k,v])=>b[i]?.[k]!==v))
export function beginPackAutomationSession(r,confirmed,clock,policy){if(confirmed!==true)return fail('not-confirmed')
if(r?.ok!==true||!validPack(r.nextPack)||!int(r.maxPacks)
||r.maxPacks<1||!int(r.maxDurationMs)||r.maxDurationMs<1
||r.maxDurationMs%60_000!==0||!fn(clock?.now))return fail('invalid')
try{const now=clock.now()
const deadlineAt=now+r.maxDurationMs
if(!int(now)||now<0||!int(deadlineAt))return fail('invalid')
const rawOrder=String(policy?.recoveryOrder??'').toLowerCase().split('>')
const recoveryOrder=rawOrder?.length===3&&new Set(rawOrder).size===3
&&rawOrder.every((d)=>dirs.includes(d))?Object.freeze(rawOrder):null
const discardAllowlist=Object.freeze(parseDiscardAllowlist(policy?.discardAllowlist)??[])
const ticket=Object.freeze({maxPacks:r.maxPacks,maxDurationMs:r.maxDurationMs,deadlineAt,autoPick:policy?.autoPick===true,autoRecovery:policy?.autoRecovery===true,autoDiscard:policy?.autoDiscard===true,autoContinue:policy?.autoContinue===true,recoveryOrder,discardAllowlist})
sessions.set(ticket,{clock,opened:0,discards:0,blocked:null,continuation:null})
return{ok:true,reason:null,ticket}}catch{return fail('unknown-state')}}
export function recordPackAutomationSessionOutcome(ticket,o){const s=sessions.get(ticket)
if(!s||s.blocked!=='outcome')return fail('invalid-session')
const blockedBy=o?.ok===true&&['pending-pick','unassigned'].includes(o.kind)?o.kind
:o?.ok===false&&['outcome-missing','unknown-state'].includes(o.reason)
?o.reason:'unknown-state'
s.blocked=blockedBy
return{ok:true,reason:null,opened:s.opened,remaining:ticket.maxPacks-s.opened,blockedBy}}
export function previewPackAutomationOutcomeAction(ticket,o,state){const s=sessions.get(ticket)
if(!s||o?.ok!==true||s.blocked!==o.kind
||!['pending-pick','unassigned'].includes(o.kind))return fail('invalid-session')
const pick=o.kind==='pending-pick'
if(pick)return ticket.autoPick
?{ok:true,reason:null,kind:o.kind,action:'pick'}
:{...fail('policy-disabled'),kind:o.kind}
if(ticket.autoRecovery&&ticket.autoDiscard)
return{...fail('policy-conflict'),kind:o.kind}
if(ticket.autoRecovery)return{ok:true,reason:null,kind:o.kind,action:'recovery'}
if(!ticket.autoDiscard)return{...fail('policy-disabled'),kind:o.kind}
if(s.discards>0)return{...fail('discard-limit'),kind:o.kind}
if(state?.loaded!==true||state.count!==o.count||!sameDtos(o.items,state.items))
return{...fail('stale'),kind:o.kind}
const p=state.discardPreview
if(p?.ok!==true||!arr(p.items)||p.count!==p.items.length||p.count<1)
return{...fail('manual-required'),kind:o.kind}
const allow=ticket.discardAllowlist
if(!arr(p.allowlist)||p.allowlist.length!==allow.length
||p.allowlist.some((x,i)=>x!==allow[i]))return{...fail('stale'),kind:o.kind}
const targets=state.items.filter((x)=>allow.includes(x.definitionId)
&&x.discardable===true&&x.duplicateLoan===false)
if(targets.length!==p.items.length
||new Set(targets.map((x)=>x.id)).size!==targets.length
||targets.some((x,i)=>x.index!==p.items[i]?.index||x.id!==p.items[i]?.id
||x.definitionId!==p.items[i]?.definitionId
||x.discardValue!==p.items[i]?.discardValue)
||p.value!==targets.reduce((n,x)=>n+x.discardValue,0))
return{...fail('stale'),kind:o.kind}
return Object.freeze({ok:true,reason:null,kind:o.kind,action:'discard',count:p.count,value:p.value})}
export async function runPackAutomationPickOutcome({ticket,outcome,adapter,state,priceOf}={}){const authority=previewPackAutomationOutcomeAction(ticket,outcome)
if(!authority.ok)return authority
if(authority.action!=='pick')return fail('wrong-action')
const session=sessions.get(ticket)
session.blocked='pick-running'
const done=(result)=>{session.blocked=result.ok?'pick-complete':result.reason
if(result.ok)Object.assign(state,{items:[],availablePicks:0,selected:[],review:null,loaded:false})
return{...result,kind:'pending-pick',action:'pick',executed:true,...(result.ok?{stoppedBy:'pick-complete'}:{})}}
if(!arr(state?.items)||state.availablePicks!==outcome.availablePicks
||state.items.length!==outcome.items?.length
||outcome.items.some((x,i)=>{const y=state.items[i];
return x?.index!==y?.index||x?.definitionId!==y?.definitionId
||x?.rating!==y?.rating||x?.tradable!==y?.tradable}))return done(fail('stale'))
if(!fn(priceOf))return done(fail('price-unavailable'))
const plan=await pricePickPolicy(state,priceOf)
if(!plan.ok)return done(plan)
let result
try{result=await runPickStep({adapter,state,confirmed:true})}
catch(err){result=budgetFail(err,fail('unknown-state'))}
if(!(result?.ok===true&&result.reason===null&&int(result.rewards)&&result.rewards>=0)
&&!(result?.ok===false&&typeof result.reason==='string'))result=fail('unknown-state')
return done(result)}
export async function runPackAutomationRecoveryOutcome({ticket,outcome,adapter,state}={}){const authority=previewPackAutomationOutcomeAction(ticket,outcome)
if(!authority.ok)return authority
if(authority.action!=='recovery')return fail('wrong-action')
const session=sessions.get(ticket)
session.blocked='recovery-running'
const done=(result,destination)=>{session.blocked=result.ok?'recovery-complete':result.reason
return{...result,kind:'unassigned',action:'recovery',...(destination?{destination}:{}),executed:true,...(result.ok?{stoppedBy:'recovery-complete'}:{})}}
if(state?.loaded!==true||state.count!==outcome.count
||!sameDtos(outcome.items,state.items))
return done(fail('stale'))
let destination,result,total=0
const moved=[]
try{result=recoveryPolicy(state)
if(!result.ok)return done(result)
result=reviewUnassignedRecovery(adapter,state)
if(!result.ok)return done(result)
const ready=dirs.filter((d)=>state[d]>0)
const order=ready.length===1?ready:ticket.recoveryOrder
if(!order)return done(fail('manual-required'))
for(destination of order){if(!ready.includes(destination))continue
if(state[destination]<1)return done(fail('stale'),destination)
result=await runRecoveryStep({adapter,state,destination,confirmed:true})
if(!result.ok)return done(result,destination)
total+=result.count
moved.push(destination)}
result={ok:true,reason:null,count:total}
if(moved.length>1)result.destinations=moved}catch(err){result=budgetFail(err,fail('unknown-state'))}
if(!(result?.ok===true&&result.reason===null&&int(result.count)&&result.count>=0)
&&!(result?.ok===false&&typeof result.reason==='string'))result=fail('unknown-state')
return done(result,moved.length===1?moved[0]:null)}
export async function runPackAutomationDiscardOutcome({ticket,outcome,adapter,state}={}){const authority=previewPackAutomationOutcomeAction(ticket,outcome,state)
if(!authority.ok)return authority
if(authority.action!=='discard')return fail('wrong-action')
const session=sessions.get(ticket)
session.blocked='discard-running'
const done=(result)=>{if(result.ok)session.discards+=1
session.blocked=result.ok?'discard-complete':result.reason
return{...result,kind:'unassigned',action:'discard',executed:true,...(result.ok?{stoppedBy:'discard-complete'}:{})}}
let result
try{result=await runDiscardStep({adapter,state,confirmed:true})}catch(err){result=budgetFail(err,fail('unknown-state'))}
if(result?.ok===true&&(result.reason!==null||result.count!==authority.count
||result.value!==authority.value))result=fail('uncertain')
if(!(result?.ok===true&&result.reason===null&&int(result.count)&&result.count>0
&&int(result.value)&&result.value>=0)
&&!(result?.ok===false&&typeof result.reason==='string'))result=fail('unknown-state')
return done(result)}
export async function previewPackAutomationContinuation({ticket,adapter,provider}={}){const s=sessions.get(ticket)
if(!s||!['pick-complete','recovery-complete','discard-complete'].includes(s.blocked))
return fail('invalid-session')
if(s.continuation)return fail('continuation-ready')
if(!ticket.autoContinue)return fail('policy-disabled')
if(s.opened>=ticket.maxPacks)return fail('pack-limit')
let now
try{now=s.clock.now()}catch{return fail('unknown-state')}
if(!int(now)||now<0)return fail('unknown-state')
if(now>=ticket.deadlineAt)return fail('time-limit')
const result=await previewPackAutomation({adapter,provider,maxPacks:ticket.maxPacks,maxMinutes:ticket.maxDurationMs/60_000,
})
if(!result.ok)return result
const continuation=Object.freeze({...result,sessionOpened:s.opened,sessionRemaining:ticket.maxPacks-s.opened,deadlineAt:ticket.deadlineAt,nextPack:Object.freeze(result.nextPack)})
s.continuation=continuation
return continuation}
export async function runPackAutomationContinuation(o={}){const s=sessions.get(o.ticket),r=o.continuation
if(!s||s.continuation!==r)return fail('invalid-session')
const key=r.nextPack.key
s.continuation=null
s.blocked=null
const result=await runPackAutomationStep({...o,expectedKey:key,confirmed:true})
if(!result.ok&&s.blocked===null)s.blocked=result.reason
return{...result,action:'continue',executed:true,key}}
export async function previewPackAutomation({adapter,provider,maxPacks,maxMinutes}={}){const packLimit=posInt(maxPacks)
const minutes=posInt(maxMinutes)
const duration=minutes===null?null:minutes*60_000
if(packLimit===null||!int(duration))return fail('invalid-limits')
if(!fn(adapter?.pendingPicks)||!fn(adapter?.unassigned)
||!fn(adapter?.list)||!fn(provider?.read))return fail('guard-unavailable')
try{const pending=await adapter.pendingPicks()
if(!validPend(pending))return fail('unknown-state')
if(pending.availablePicks>0)return fail('pending-pick')
const purchased=await adapter.unassigned()
if(!validPile(purchased))return fail('unknown-state')
if(purchased.count>0)return fail('unassigned')
const packs=await adapter.list()
if(!arr(packs)||packs.some((pack)=>!validPack(pack))
||new Set(packs.map((pack)=>pack.key)).size!==packs.length){return fail('unknown-state')}
const rawLocks=provider.read()
const locks=sanitizePackLocks(rawLocks)
if(!arr(rawLocks)||locks.length!==rawLocks.length)return fail('unknown-state')
const locked=new Set(locks)
const nextPack=packs.find((pack)=>!locked.has(pack.key))
if(!nextPack)return fail('no-pack')
if(nextPack.playerPick)return fail('player-pick')
return{ok:true,reason:null,nextPack:{...nextPack},maxPacks:packLimit,maxDurationMs:duration,ownedCount:packs.length,lockedCount:packs.filter((pack)=>locked.has(pack.key)).length}}catch(err){return budgetFail(err,fail('unknown-state'))}}
export async function runPackAutomationStep(options={}){const{adapter,expectedKey:key,confirmed,ticket}=options
if(confirmed!==true)return fail('not-confirmed')
if(!fn(adapter?.open)||typeof key!=='string')
return fail('guard-unavailable')
const s=sessions.get(ticket)
if(!s)return fail('invalid-session')
if(s.blocked&&!['pending-pick','unassigned'].includes(s.blocked))return fail(s.blocked)
if(s.opened>=ticket.maxPacks)return fail('pack-limit')
const stop=(reason)=>(s.blocked=reason,fail(reason))
let now
try{now=s.clock.now()}catch{return stop('unknown-state')}
if(!int(now)||now<0)return stop('unknown-state')
if(now>=ticket.deadlineAt)return stop('time-limit')
if(running.has(adapter))return fail('busy')
running.add(adapter)
let sent=false
try{const review=await previewPackAutomation({...options,maxPacks:ticket.maxPacks,maxMinutes:ticket.maxDurationMs/60_000,
})
if(!review.ok)return stop(review.reason)
if(review.nextPack.key!==key)return stop('stale')
now=s.clock.now()
if(!int(now)||now<0)return stop('unknown-state')
if(now>=ticket.deadlineAt)return stop('time-limit')
sent=true
const result=await adapter.open(key)
if(result?.ok===true&&result.reason===null&&arr(result.items)){s.opened+=1
s.blocked='outcome'
return{...result,opened:1,stoppedBy:'outcome',sessionOpened:s.opened,sessionRemaining:ticket.maxPacks-s.opened}}
const reason=result?.ok===false&&typeof result.reason==='string'
?result.reason:'uncertain'
return stop(reason)}catch(err){
if(isDayBudgetError(err))return stop(err.reason)
return stop(sent?'uncertain':'unknown-state')}finally{running.delete(adapter)}}
export async function inspectPackAutomationOutcome(a){if(!fn(a?.pendingPicks)||!fn(a?.unassigned))return fail('guard-unavailable')
try{const p=await a.pendingPicks()
if(!validPend(p))return fail('unknown-state')
if(p.availablePicks>0)return{ok:true,reason:null,kind:'pending-pick',count:p.items.length,availablePicks:p.availablePicks,items:p.items.map((item)=>({...item}))}
const u=await a.unassigned()
if(!validPile(u))return fail('unknown-state')
if(u.count>0)return{ok:true,reason:null,kind:'unassigned',count:u.count,items:u.items.map((item)=>({...item}))}
return fail('outcome-missing')}catch(err){return budgetFail(err,fail('unknown-state'))}}
export function hydratePackAutomationOutcome(o,p,r){if(!p||typeof p!=='object'||arr(p)
||!r||typeof r!=='object'||arr(r)
||o?.ok!==true||!arr(o.items)
||!int(o.count)||o.count<1
||o.count!==o.items.length)return fail('invalid')
const indices=o.items.map((item)=>item?.index)
if(indices.some((index)=>!int(index)||index<0)
||new Set(indices).size!==indices.length)return fail('invalid')
if(o.kind==='pending-pick'){if(!int(o.availablePicks)||o.availablePicks<1
||o.availablePicks>o.count)return fail('invalid')
Object.assign(p,{items:o.items.map((item)=>({...item})),availablePicks:o.availablePicks,selected:[],review:null,loaded:true})
Object.assign(r,{count:0,keep:0,club:0,transfer:0,storage:0,items:[],review:null,loaded:false})}else if(o.kind==='unassigned'){Object.assign(p,{items:[],availablePicks:0,selected:[],review:null,loaded:false})
Object.assign(r,{count:o.count,keep:o.count,club:0,transfer:0,storage:0,review:null,loaded:true,items:o.items.map((item)=>({...item,disposition:'keep'}))})}else return fail('invalid')
return{ok:true,reason:null,kind:o.kind,count:o.count}}
