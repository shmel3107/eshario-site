import{BUYER,SELLER} from '../automation/journal.js'
export const JOURNAL_ROWS=12
export const EVENT_KEYS=Object.freeze({search:'journal.event.search',found:'journal.event.found',bought:'journal.event.bought','would-buy':'journal.event.wouldBuy',bid:'journal.event.bid','would-bid':'journal.event.wouldBid',outbid:'journal.event.outbid',moved:'journal.event.moved',rest:'journal.event.rest',planned:'journal.event.planned',listed:'journal.event.listed','quick-sold':'journal.event.quickSold','would-sell':'journal.event.wouldSell',relisted:'journal.event.relisted',cleared:'journal.event.cleared',sold:'journal.event.sold',failure:'journal.event.failure',stopped:'journal.event.stopped','no-price':'journal.event.noPrice',kept:'journal.event.kept'
})
export const SOURCE_KEYS=Object.freeze({[BUYER]:'journal.source.buyer',[SELLER]:'journal.source.seller'
})
export function eventLabel(t,event){const key=EVENT_KEYS[event]
return key?t(key):String(event)}
export function sourceLabel(t,source){const key=SOURCE_KEYS[source]
return key?t(key):String(source)}
export function ageLabel(t,ms){const seconds=Math.max(0,Math.round((Number.isFinite(ms)?ms:0) / 1000));
if(seconds<5) return t('journal.age.now');
if(seconds<60) return t('journal.age.seconds',{count:seconds});
const minutes=Math.floor(seconds / 60);
if(minutes<60) return t('journal.age.minutes',{count:minutes});
return t('journal.age.hours',{count:Math.floor(minutes / 60)});
}
export function journalLine(t,entry,now){const parts=[ageLabel(t,now-entry.at),sourceLabel(t,entry.source),eventLabel(t,entry.event)];
if(entry.item)parts.push(entry.item);
if(entry.price!==null) parts.push(t('journal.coins',{coins:entry.price}));
if(entry.detail)parts.push(entry.detail);
if(entry.count>1) parts.push(`×${entry.count}`);
return parts.join(' · ')}
export function journalRows(t,view){const entries=Array.isArray(view?.entries)?view.entries:[];
return entries.map((entry)=>({id:String(entry.seq),label:journalLine(t,entry,view.now)}))}
export function journalText(t,view){const entries=Array.isArray(view?.entries)?view.entries:[];
if(entries.length===0) return t('journal.empty');
return entries.map((entry)=>journalLine(t,entry,view.now)).join('\n')}
