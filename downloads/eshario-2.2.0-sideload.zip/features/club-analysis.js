import{buildClubItemTable} from './club-table.js'
import{readClubOnce,CLUB_MIRROR_PAGE,CLUB_MIRROR_MAX_PAGES} from './club-mirror.js'
export const ITEM_PILE=Object.freeze({ANY:0,TRANSFER:5,PURCHASED:6,CLUB:7,INBOX:8,GIFT:9,STORAGE:10,EVOLUTION:11})
export const LIMITED_USE_NONE=0
export const STATE_FOR_SALE='forSale'
const ACTIVE_STATE_PREFIX='active'
export const DEFAULT_MAX_LOOKUPS=200
export const CLUB_PAGE_SIZE=CLUB_MIRROR_PAGE
export const CLUB_MAX_PAGES=CLUB_MIRROR_MAX_PAGES
export async function readClubItems(club,deps={}){if(!club||typeof club.search!=='function') return[]
if(typeof deps.createCriteria!=='function')return[]
const result=await readClubOnce(club,deps)
return result.items}
export async function readSbcStorageItems(item,deps={}){const createCriteria=deps.createCriteria
if(!item||typeof item.searchStorageItems!=='function'||typeof createCriteria!=='function')throw new Error('SBC Storage: read boundary unavailable')
const all=[]
for(let page=0;page<60;page+=1){const batch=await item.searchStorageItems(createCriteria({count:150,offset:page*150}))
if(!batch||typeof batch!=='object'||Array.isArray(batch)||!Array.isArray(batch.items)||typeof batch.endOfList!=='boolean')throw new Error('SBC Storage: unknown page shape')
all.push(...batch.items)
if(batch.endOfList)return all
if(batch.items.length===0)throw new Error('SBC Storage: empty non-terminal page')}
throw new Error('SBC Storage: page limit reached')}
export function identityOf(item){const raw=item?.definitionId??item?.defId
if(typeof raw==='number'&&Number.isFinite(raw)&&raw>0) return String(raw)
if(typeof raw==='string'&&raw.trim()!=='') return raw.trim()
return null}
export function tradabilityOf(item){if(!item||typeof item!=='object') return 'unknown'
if(item.tradable===true) return 'tradeable'
if(item.tradable===false) return 'untradeable'
if(item.untradeable===true) return 'untradeable'
if(item.untradeable===false) return 'tradeable'
return 'unknown'
}
export function isInActiveSquad(item){const state=item?.state
return typeof state==='string'&&state.startsWith(ACTIVE_STATE_PREFIX)}
export function isListed(item){return item?.state===STATE_FOR_SALE}
export function isLoanItem(item){const loans=Number(item?.loans)
if(Number.isFinite(loans)&&loans>0)return true
const limited=Number(item?.limitedUseType)
return Number.isFinite(limited)&&limited>LIMITED_USE_NONE}
export function isSellable(item){return tradabilityOf(item)==='tradeable'
&&!isInActiveSquad(item)
&&!isListed(item)
&&!isLoanItem(item)}
export function summarizeClub(items){const list=onlyObjects(items)
const summary={total:list.length,tradeable:0,untradeable:0,unknownTradability:0,inActiveSquad:0,listed:0,loans:0,sellable:0,withoutIdentity:0}
for(const item of list){const tradability=tradabilityOf(item)
if(tradability==='tradeable') summary.tradeable+=1
else if(tradability==='untradeable') summary.untradeable+=1
else summary.unknownTradability+=1
if(isInActiveSquad(item))summary.inActiveSquad+=1
if(isListed(item))summary.listed+=1
if(isLoanItem(item))summary.loans+=1
if(isSellable(item))summary.sellable+=1
if(identityOf(item)===null)summary.withoutIdentity+=1}
return summary}
export function findDuplicates(items){const groups=groupByIdentity(items)
const out=[]
for(const[id,group]of groups){if(group.length<2)continue
out.push({id,count:group.length,extra:group.length-1,sellable:group.filter(isSellable).length,items:group})}
out.sort((a,b)=>(b.count-a.count)||a.id.localeCompare(b.id))
return out}
export function sellCandidates(items,options={}){const keep=Number.isInteger(options.keepPerDefinition)&&options.keepPerDefinition>=0
?options.keepPerDefinition
:1
const excluded=new Set([...(options.excludeIds??[])].map((id)=>String(id)))
const out=[]
for(const[id,group]of groupByIdentity(items)){const ordered=group.slice().sort(keepFirst)
const surplus=ordered.slice(keep)
for(const item of surplus){if(!isSellable(item))continue
if(excluded.has(String(item?.id??item?.itemId??''))) continue
out.push({id,item,copies:group.length})}}
out.sort((a,b)=>(b.copies-a.copies)||a.id.localeCompare(b.id)||compareItemId(a.item,b.item))
return out}
export async function analyzeClub(input={}){const items=onlyObjects(input.items)
const summary=summarizeClub(items)
const duplicates=findDuplicates(items)
const candidates=sellCandidates(items,input)
const table=await buildClubItemTable(items,{priceEvidenceOf:input.priceEvidenceOf,priceOf:input.priceOf,maxLookups:input.maxLookups,now:input.now})
return{summary,duplicates,candidates,value:table.value,table}}
export async function valueOfClub(items,priceOf,maxLookups){const list=onlyObjects(items)
const limit=Number.isInteger(maxLookups)&&maxLookups>=0?maxLookups:DEFAULT_MAX_LOOKUPS
const value={coins:0,priced:0,withoutPrice:0,notAsked:0,limitReached:false}
if(typeof priceOf!=='function'){value.notAsked=list.length
return value}
let asked=0
for(const item of list){if(asked>=limit){
value.notAsked+=1
value.limitReached=true
continue}
asked+=1
let price=null
try{price=await priceOf(item)}catch{price=null;// Недоступный источник не роняет анализ.
}
if(typeof price==='number'&&Number.isFinite(price)&&price>0){value.coins+=Math.round(price)
value.priced+=1}else{value.withoutPrice+=1}}
return value}
function onlyObjects(items){return Array.isArray(items)?items.filter((item)=>item&&typeof item==='object'):[]}
function groupByIdentity(items){const groups=new Map()
for(const item of onlyObjects(items)){const id=identityOf(item)
if(id===null)continue
const group=groups.get(id)
if(group)group.push(item)
else groups.set(id,[item])}
return groups}
function keepFirst(a,b){const sa=isSellable(a)?1:0
const sb=isSellable(b)?1:0
if(sa!==sb)return sa-sb
const ra=ratingOf(b)-ratingOf(a)
if(ra!==0)return ra
return compareItemId(a,b)}
function ratingOf(item){const rating=Number(item?.rating)
return Number.isFinite(rating)?rating:0}
function compareItemId(a,b){return String(a?.id??a?.itemId??'').localeCompare(String(b?.id??b?.itemId??''))}
