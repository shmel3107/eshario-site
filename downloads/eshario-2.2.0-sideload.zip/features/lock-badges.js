import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{SBC_FEATURE} from './sbc-actions.js'
import{cardLockKey} from './card-locks.js'
export const LOCK_BADGE_FEATURE=SBC_FEATURE
const BADGE_SELECTOR='[data-fut-lock-badge]'
const ROW_CLASS='listFUTItem'
const CARD_SELECTOR='.item'
const SLOT_CARD_SELECTOR=`.small${CARD_SELECTOR}`
const SLOT_ROOT_CLASS='ut-squad-slot-view'
export const LOCK_BADGE_SURFACES=Object.freeze([Object.freeze({id:'transfer',rootClass:'ut-transfer-list-view'}),
Object.freeze({id:'targets',rootClass:'ut-watch-list-view'}),
Object.freeze({id:'unassigned',rootClass:'ut-unassigned-view'}),
Object.freeze({id:'club',rootClass:'ut-club-search-results-view'})])
const LOCK_BADGES_STYLESHEET=new URL('../ui/lock-badges.css',import.meta.url).href
const LOCK_BADGES_LINK_ID='fut-companion-lock-badges'
export const MAX_DRAWS_PER_PASS=40
export function createLockBadges(deps={}){const{doc,win=null,t}=deps
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const itemOf=typeof deps.itemOf==='function'?deps.itemOf:()=>null
const lockedIds=typeof deps.lockedIds==='function'?deps.lockedIds:null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const painted=new WeakMap()
const slotItems=new WeakMap()
let epoch=0
let framePending=false
let stats={screens:[],anchors:0,drawn:0,removed:0,missed:0,locked:0,capped:false,reason:'not-run'}
function note(root,item){if(!root)return false
if(!item||typeof item!=='object'){slotItems.delete(root)
return false}
slotItems.set(root,item)
return true}
function refresh(){if(!doc?.querySelectorAll)return record({reason:'no-doc'})
if(!safeActive()){const removed=dropAll()
return record({reason:'locked',removed})}
if(!lockedIds)return record({reason:'no-storage'})
const records=[]
const screens=[]
const seen=new Set()
let anchors=0
for(const surface of LOCK_BADGE_SURFACES){let roots=0
let rows=0
for(const root of doc.querySelectorAll(`.${surface.rootClass}`)??[]){roots+=1
for(const row of root.querySelectorAll?.(`.${ROW_CLASS}`)??[]){if(seen.has(row))continue
seen.add(row)
rows+=1
records.push({host:row,item:safeItem(row),cardSelector:CARD_SELECTOR})}}
anchors+=roots
screens.push({id:surface.id,roots,rows})}
let slotRoots=0
for(const root of doc.querySelectorAll(`.${SLOT_ROOT_CLASS}`)??[]){slotRoots+=1
records.push({host:root,item:slotItems.get(root)??null,cardSelector:SLOT_CARD_SELECTOR})}
anchors+=slotRoots
screens.push({id:'squad',roots:slotRoots,rows:slotRoots})
const items=[]
for(const one of records){if(one.item&&typeof one.item==='object')items.push(one.item)}
const locked=new Set(safeLocked(items))
let drawn=0
let removed=0
let missed=0
let capped=false
for(const one of records){const{host,item,cardSelector}=one
const id=item&&typeof item==='object'?safeKey(item):null
const on=id!==null&&locked.has(id)
const current=painted.get(host)
if(current&&current.item===item&&current.on===on&&current.epoch===epoch&&(!on||alive(current.node)))continue
if(!on){if(drop(host,cardSelector))removed+=1
painted.set(host,{item,on,node:null,epoch})
continue}
if(drawn>=MAX_DRAWS_PER_PASS){capped=true
break}
const card=host.querySelector?.(cardSelector)??null
if(!card){painted.delete(host)
missed+=1
continue}
const node=mount(card,id)
if(!node){painted.delete(host)
missed+=1
continue}
painted.set(host,{item,on,node,epoch})
drawn+=1}
if(capped)nextFrame()
return record({reason:null,screens,anchors,drawn,removed,missed,locked:locked.size,capped})}
function mount(card,id){if(typeof card.appendChild!=='function')return null
ensureStyles()
host(card)
let node=card.querySelector?.(BADGE_SELECTOR)??null
if(!node){node=el(doc,'div',{class:'fut-lock-badge',attrs:{role:'img'},dataset:{futLockBadge:'1'}})
card.appendChild(node)}
if(node.dataset)node.dataset.futLockBadgeId=String(id)
label(node)
return node}
function label(node){if(typeof t!=='function'||typeof node.setAttribute!=='function')return
let title=''
try{title=t('sell.lock.on')}catch{return}
if(node.getAttribute('title')===title)return
node.setAttribute('title',title)
node.setAttribute('aria-label',title)}
function host(card){if(card.dataset?.futLockBadgeHost==='1')return
let position=''
try{position=doc?.defaultView?.getComputedStyle?.(card)?.position??''}catch{position=''}
if(position!=='static'||!card.style)return
card.dataset.futLockBadgeHost='1'
card.dataset.futLockBadgePosition=card.style.position??''
card.style.position='relative'}
function drop(hostNode,cardSelector=CARD_SELECTOR){const mark=painted.get(hostNode)
const node=hostNode.querySelector?.(BADGE_SELECTOR)??null
if(!node&&!mark?.node)return false
node?.remove?.()
mark?.node?.remove?.()
restore(hostNode.querySelector?.(cardSelector)??null)
return true}
function dropAll(){let count=0
for(const node of doc?.querySelectorAll?.(BADGE_SELECTOR)??[]){restore(node.parentNode)
node.remove?.()
count+=1}
return count}
function restore(card){if(card?.dataset?.futLockBadgeHost!=='1')return
if(card.style)card.style.position=card.dataset.futLockBadgePosition??''
delete card.dataset.futLockBadgeHost
delete card.dataset.futLockBadgePosition}
function nextFrame(){if(framePending)return
const raf=typeof win?.requestAnimationFrame==='function'?win.requestAnimationFrame:null
const timer=typeof win?.setTimeout==='function'?win.setTimeout:null
if(!raf&&!timer)return
framePending=true
let done=false
const go=()=>{if(done)return
done=true
framePending=false
try{refresh()}catch(err){onError(err)}}
if(raf){try{raf.call(win,go)}catch{/* кадра не будет — остаётся таймер */}}
if(timer){try{timer.call(win,go,32)}catch{/* и таймера тоже: подождём прохода */}}}
function ensureStyles(){ensureTheme(doc)
ensureStylesheet(doc,LOCK_BADGES_STYLESHEET,LOCK_BADGES_LINK_ID)}
function alive(node){return node!==null&&node!==undefined&&node.isConnected!==false}
function safeActive(){try{return isActive(LOCK_BADGE_FEATURE)===true}catch(err){onError(err)
return false}}
function safeItem(row){try{return itemOf(row)??null}catch(err){onError(err)
return null}}
function safeKey(item){try{return cardLockKey(item)}catch(err){onError(err)
return null}}
function safeLocked(items){try{const answer=lockedIds(items)
return Array.isArray(answer)?answer:[]}catch(err){onError(err)
return[]}}
function record(next){stats={screens:[],anchors:0,drawn:0,removed:0,missed:0,locked:0,capped:false,...next}
return stats}
function relabel(){epoch+=1
refresh()
return true}
return{refresh,note,relabel,
state:()=>({active:safeActive(),reason:stats.reason,screens:stats.screens,anchors:stats.anchors,
drawn:doc?.querySelectorAll?.(BADGE_SELECTOR)?.length??0,
drawnLastPass:stats.drawn,removed:stats.removed,missed:stats.missed,locked:stats.locked,capped:stats.capped,
available:Boolean(lockedIds),
shown:Array.from(doc?.querySelectorAll?.(BADGE_SELECTOR)??[],(node)=>Number(node.dataset?.futLockBadgeId)||null)}),
dispose(){dropAll()}}}
