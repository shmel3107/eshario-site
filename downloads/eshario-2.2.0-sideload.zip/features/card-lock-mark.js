import{el,ensureSidebarStyles} from '../ui/dom.js'
import{SBC_FEATURE} from './sbc-actions.js'
import{cardLockKey} from './card-locks.js'
import{cardTag} from './club-actions.js'
import{isSbcPlayer} from '../automation/sbc-solver.js'
import{isOwnedItem,isSoldItem,detailsCardOf} from '../adapter/item-details.js'
const LOCK_SELECTOR='[data-fut-card-lock]'
const LOCK_FEATURE=SBC_FEATURE
export function createCardLockMark(deps={}){const{doc,t}=deps
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const isLocked=typeof deps.isLocked==='function'?deps.isLocked:null
const setLock=typeof deps.setLock==='function'?deps.setLock:null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let last=null
let scheduled=false
let lastResult={ok:false,reason:'not-run'}
const record=(result)=>{lastResult=result
return result}
function apply(capture){if(!doc||!capture?.root)return record({ok:false,reason:'no-capture'})
const id=cardLockKey(capture.item)
last={root:capture.root,id,item:capture.item,owned:isOwnedItem(capture.item),sold:isSoldItem(capture.item),player:isSbcPlayer(capture.item)}
schedule()
return record({ok:true,reason:'pending'})}
function schedule(){if(scheduled)return
scheduled=true
Promise.resolve().then(()=>{scheduled=false
try{settle()}catch(err){onError(err)}})}
function settle(){if(!last)return record({ok:false,reason:'no-capture'})
const{root,id,owned,sold,player}=last
if(!isActive(LOCK_FEATURE)){drop(root)
return record({ok:false,reason:'locked'})}
if(!setLock||!isLocked)return record({ok:false,reason:'no-storage'})
if(!owned){drop(root)
return record({ok:false,reason:'not-ours'})}
if(sold){drop(root)
return record({ok:false,reason:'sold'})}
if(id===null){drop(root)
return record({ok:false,reason:'no-id'})}
if(!player&&!lockedById(id)){drop(root)
return record({ok:false,reason:'not-a-player'})}
const card=detailsCardOf(root)
if(!card)return record({ok:false,reason:'no-card'})
ensureSidebarStyles(doc)
const node=mount(card)
if(!node)return record({ok:false,reason:'no-mark'})
node.dataset.futCardLockId=String(id)
node.dataset.futCardLockTag=tagOf(last?.item,id)
paintAll()
return record({ok:true,reason:null,id,locked:locked()})}
function refresh(){paintAll()
if(!last)return false
return settle().ok===true}
function mount(card){const existing=card.querySelector?.(LOCK_SELECTOR)??null
if(existing)return existing
let position=''
try{position=doc?.defaultView?.getComputedStyle?.(card)?.position??''}catch{position=''}
if(position==='static'&&card.style){card.dataset.futCardLockHost='1'
card.dataset.futCardLockPosition=card.style.position??''
card.style.position='relative'}
const node=el(doc,'button',{class:'fut-card-lock',attrs:{type:'button'},dataset:{futCardLock:'1'},on:{click:(event)=>{
event?.preventDefault?.()
event?.stopPropagation?.()
try{toggle(event?.currentTarget??node)}catch(err){onError(err)}}}})
card.appendChild(node)
return node}
function keyOf(node){const value=Number(node?.dataset?.futCardLockId)
return Number.isSafeInteger(value)&&value>0?value:null}
function lockedById(id){if(id===null||!isLocked)return false
try{return isLocked(id)===true}catch(err){onError(err)
return false}}
function locked(){return lockedById(last?.id??null)}
function tagOf(item,id){if(item===null||item===undefined)return''
try{const tag=cardTag(item,String(id))
return tag===String(id)?'':tag}catch(err){onError(err)
return''}}
function toggle(node){const id=keyOf(node)
if(id===null||!setLock)return false
const label=node?.dataset?.futCardLockTag
const done=setLock(id,!lockedById(id),typeof label==='string'&&label!==''?label:undefined)
paintAll()
return done}
function paint(node){const on=lockedById(keyOf(node))
node.dataset.futCardLockOn=on?'1':'0'
const title=on?t('sell.lock.on'):t('sell.lock.off')
if(node.getAttribute?.('title')===title)return
node.setAttribute?.('title',title)
node.setAttribute?.('aria-label',title)}
function paintAll(){let count=0
for(const node of doc?.querySelectorAll?.(LOCK_SELECTOR)??[]){paint(node)
count+=1}
return count}
function relabel(){paintAll()
return true}
function drop(root){const card=detailsCardOf(root)
if(!card)return
card.querySelector?.(LOCK_SELECTOR)?.remove?.()
if(card.dataset?.futCardLockHost==='1'&&card.style){card.style.position=card.dataset.futCardLockPosition??''
delete card.dataset.futCardLockHost
delete card.dataset.futCardLockPosition}}
return{apply,refresh,relabel,
state:()=>({active:isActive(LOCK_FEATURE),lastResult,id:last?.id??null,owned:last?.owned??null,sold:last?.sold??null,player:last?.player??null,on:locked(),available:Boolean(setLock&&isLocked),marks:doc?.querySelectorAll?.(LOCK_SELECTOR)?.length??0,shown:Array.from(doc?.querySelectorAll?.(LOCK_SELECTOR)??[],(node)=>({id:keyOf(node),on:node.dataset?.futCardLockOn==='1'}))}),
dispose(){drop(last?.root??null)
last=null}}}
