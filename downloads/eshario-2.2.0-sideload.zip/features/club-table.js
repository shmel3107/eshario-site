import{netAfterTax} from './tax.js'
export const CLUB_TABLE_PAGE_SIZE=15
export const CLUB_CSV_SCHEMA='fut-companion-club-v1'
export const CLUB_CSV_COLUMNS=Object.freeze(['schema','snapshot_at','definition_id','identity_known','name','count',
'discard_coins','discard_known','discard_total','discard_state',
'bought_coins','bought_known','bought_total','bought_state',
'price_coins','price_known','price_total','price_state',
'profit_coins','profit_known','profit_total','profit_state',
'rating','rating_state','quality','quality_state','rarity','rarity_state',
'nation','nation_state','league','league_state','club','club_state',
'pile','pile_state','type','type_state','tradeable','tradeable_state',
'price_from','price_sources','price_observed_at'])
export const CLUB_TABLE_COLUMNS=Object.freeze([
{key:'name',labelKey:'clubTable.column.name'},
{key:'count',labelKey:'clubTable.column.count'},
{key:'discard',labelKey:'clubTable.column.discard'},
{key:'bought',labelKey:'clubTable.column.bought'},
{key:'price',labelKey:'clubTable.column.price'},
{key:'profit',labelKey:'clubTable.column.profit'},
{key:'rating',labelKey:'clubTable.column.rating'},
{key:'quality',labelKey:'clubTable.column.quality'},
{key:'rarity',labelKey:'clubTable.column.rarity'},
{key:'nation',labelKey:'clubTable.column.nation'},
{key:'league',labelKey:'clubTable.column.league'},
{key:'club',labelKey:'clubTable.column.club'},
{key:'pile',labelKey:'clubTable.column.pile'},
{key:'type',labelKey:'clubTable.column.type'},
{key:'tradeable',labelKey:'clubTable.column.tradeable'},
])
export const CLUB_TABLE_FILTERS=Object.freeze([
{key:'pile',labelKey:'clubTable.filter.pile'},
{key:'type',labelKey:'clubTable.filter.type'},
{key:'tradeable',labelKey:'clubTable.filter.tradeable'},
{key:'rating',labelKey:'clubTable.filter.rating'},
{key:'quality',labelKey:'clubTable.filter.quality'},
{key:'rarity',labelKey:'clubTable.filter.rarity'},
{key:'nation',labelKey:'clubTable.filter.nation'},
{key:'league',labelKey:'clubTable.filter.league'},
{key:'club',labelKey:'clubTable.filter.club'},
])
export function defaultClubTableFilters(){return Object.fromEntries(CLUB_TABLE_FILTERS.map((filter)=>[filter.key,'']))}
export async function buildClubItemTable(items,options={}){const list=onlyObjects(items)
const limit=Number.isInteger(options.maxLookups)&&options.maxLookups>=0?options.maxLookups:200
const priceEvidenceOf=typeof options.priceEvidenceOf==='function'
?options.priceEvidenceOf
:(typeof options.priceOf==='function'?async(item)=>normalizeLegacyPrice(await options.priceOf(item)):null)
const observedAt=nowOf(options.now)
const grouped=groupItems(list)
let asked=0
let notAsked=0
const priced=new Map()
for(const entry of grouped){const evidence=[]
for(const item of entry.items){if(!priceEvidenceOf){evidence.push(null);notAsked+=1;continue}
if(asked>=limit){evidence.push(null);notAsked+=1;continue}
asked+=1
let result=null
try{result=normalizePriceEvidence(await priceEvidenceOf(item),observedAt)}catch{result=null}
evidence.push(result)}
priced.set(entry.id,evidence)}
const rows=grouped.map((entry)=>rowOf(entry,priced.get(entry.id)??[]))
.sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true,sensitivity:'base'})||a.id.localeCompare(b.id,undefined,{numeric:true}))
const totals=totalsOf(rows,list.length)
const value={coins:totals.money.price.coins,priced:totals.money.price.known,withoutPrice:Math.max(0,asked-totals.money.price.known),notAsked,limitReached:notAsked>0&&Boolean(priceEvidenceOf)&&asked>=limit}
return{columns:CLUB_TABLE_COLUMNS,rows,totals,value,pricing:{asked,notAsked,limitReached:value.limitReached,observedAt}}
}
export function filterClubItemTable(table,filters={}){const rows=Array.isArray(table?.rows)?table.rows:[]
const name=clean(filters.name).toLocaleLowerCase()
const exact=Object.entries(filters).filter(([key,value])=>key!=='name'&&tokens(value).length>0)
return rows.filter((row)=>{if(name&&!row.name.toLocaleLowerCase().includes(name))return false
for(const[key,value]of exact){const accepted=tokens(value)
const actual=row.fields?.[key]?.values??[]
if(!actual.some((candidate)=>accepted.includes(String(candidate).toLocaleLowerCase())))return false}
return true})}
export function viewClubItemTable(table,filters={},page=1,pageSize=CLUB_TABLE_PAGE_SIZE){const filtered=filterClubItemTable(table,filters)
const size=Number.isInteger(pageSize)&&pageSize>0?pageSize:CLUB_TABLE_PAGE_SIZE
const pages=Math.max(1,Math.ceil(filtered.length/size))
const requested=Number.isFinite(Number(page))?Math.trunc(Number(page)):1
const current=Math.min(pages,Math.max(1,requested))
return{columns:table?.columns??CLUB_TABLE_COLUMNS,rows:filtered.slice((current-1)*size,current*size),totals:table?.totals??totalsOf([],0),page:current,pages,total:filtered.length,pageSize:size,pricing:table?.pricing??null}}
export function exportClubItemTableCsv(table,filters={}){const rows=filterClubItemTable(table,filters)
const snapshot=Number.isFinite(table?.pricing?.observedAt)?table.pricing.observedAt:''
const records=rows.map((row)=>{const record=[CLUB_CSV_SCHEMA,snapshot,row.identityKnown?row.id:'',row.identityKnown===true,row.name,row.count]
for(const key of['discard','bought','price','profit']){const value=row.money?.[key]
record.push(value?.state==='unknown'?'':finiteOrBlank(value?.coins),finiteOrBlank(value?.known),finiteOrBlank(value?.total),stateOrUnknown(value?.state))}
for(const key of['rating','quality','rarity','nation','league','club','pile','type','tradeable']){const value=row.fields?.[key]
record.push(fieldValues(value),stateOrUnknown(value?.state))}
record.push(fieldValues({values:row.priceEvidence?.from}),fieldValues({values:row.priceEvidence?.sources}),fieldValues({values:row.priceEvidence?.observedAt}))
return record})
const lines=[CLUB_CSV_COLUMNS,...records].map((record)=>record.map(csvCell).join(','))
return{ok:true,schema:CLUB_CSV_SCHEMA,rows:records.length,text:`\uFEFF${lines.join('\r\n')}\r\n`}}
function groupItems(items){const groups=new Map()
let anonymous=0
for(const item of items){const identity=identityOf(item)
const id=identity??`physical:${physicalId(item)??++anonymous}`
if(groups.has(id))groups.get(id).items.push(item)
else groups.set(id,{id,identityKnown:identity!==null,items:[item]})}
return[...groups.values()]}
function rowOf(entry,evidence){const items=entry.items
const fields={
rating:field(items.map((item)=>item.rating)),
quality:field(items.map((item)=>safeCall(item,'getTier'))),
rarity:field(items.map((item)=>item.rareflag)),
nation:field(items.map((item)=>item.nationId)),
league:field(items.map((item)=>item.leagueId)),
club:field(items.map((item)=>item.teamId)),
pile:field(items.map((item)=>item.utasPile)),
type:field(items.map((item)=>item.type)),
tradeable:field(items.map(tradeableValue)),
}
const discard=money(items.map((item)=>coins(item.discardValue,true)),items.length)
const boughtValues=items.map((item)=>coins(item.lastSalePrice,true))
const bought=money(boughtValues,items.length)
const priceValues=evidence.map((item)=>coins(item?.price,false))
const price=money(priceValues,items.length)
const profitValues=priceValues.map((value,index)=>value===null||boughtValues[index]===null?null:netAfterTax(value)-boughtValues[index])
const profit=money(profitValues,items.length,true)
return{id:entry.id,identityKnown:entry.identityKnown,name:nameOf(items[0],entry.id),count:items.length,fields,money:{discard,bought,price,profit},priceEvidence:{from:unique(evidence.map((item)=>item?.from)),sources:unique(evidence.map((item)=>item?.source)),observedAt:unique(evidence.map((item)=>item?.observedAt))}}
}
function totalsOf(rows,total){const sum=(key)=>money(rows.flatMap((row)=>expandMoney(row.money[key])),total,key==='profit')
return{count:total,money:{discard:sum('discard'),bought:sum('bought'),price:sum('price'),profit:sum('profit')}}}
function expandMoney(value){if(!value||value.known===0)return[]
return[{coins:value.coins,count:value.known}]}
function money(values,total,allowNegative=false){let sum=0
let known=0
for(const value of values){if(value&&typeof value==='object'&&Number.isFinite(value.coins)&&Number.isSafeInteger(value.count)){sum+=value.coins;known+=value.count;continue}
if(typeof value!=='number'||!Number.isFinite(value)||(value<0&&!allowNegative))continue
sum+=Math.round(value);known+=1}
return{coins:sum,known,total,state:known===0?'unknown':known===total?'known':'partial'}}
function field(values){const cleaned=unique(values.filter(knownScalar).map((value)=>typeof value==='string'?value.trim():value))
const known=values.filter(knownScalar).length
return{values:cleaned,known,total:values.length,state:known===0?'unknown':known<values.length?'partial':cleaned.length>1?'mixed':'known'}}
function normalizeLegacyPrice(value){return{ok:typeof value==='number'&&value>0,price:value,from:'legacy',source:'configured external fallback'}}
function normalizePriceEvidence(value,observedAt){if(typeof value==='number')return normalizePriceEvidence(normalizeLegacyPrice(value),observedAt)
if(!value||typeof value!=='object')return null
const price=coins(value.price,false)
if(price===null)return null
return{price,ok:value.ok!==false,from:clean(value.from)||'unknown',source:clean(value.source)||null,observedAt:Number.isFinite(value.observedAt)?value.observedAt:observedAt}}
function nameOf(item,id){let staticName=null
try{staticName=item?.getStaticData?.()?.name}catch{}
for(const value of[staticName,item?.displayName,item?.name,item?.commonName]){if(clean(value))return clean(value)}
return String(id)}
function identityOf(item){const value=item?.definitionId??item?.defId
if(typeof value==='number'&&Number.isFinite(value)&&value>0)return String(value)
if(clean(value))return clean(value)
return null}
function physicalId(item){const value=item?.id??item?.itemId
return knownScalar(value)?String(value):null}
function tradeableValue(item){if(item?.tradable===true)return true
if(item?.tradable===false)return false
if(item?.untradeable===true)return false
if(item?.untradeable===false)return true
return null}
function safeCall(item,method){try{return typeof item?.[method]==='function'?item[method]():null}catch{return null}}
function nowOf(now){try{const value=typeof now==='function'?now():now
return Number.isFinite(value)?value:Date.now()}catch{return Date.now()}}
function coins(value,allowZero){return typeof value==='number'&&Number.isFinite(value)&&(allowZero?value>=0:value>0)?Math.round(value):null}
function knownScalar(value){return(typeof value==='number'&&Number.isFinite(value))||(typeof value==='boolean')||clean(value)!==''}
function tokens(value){return clean(value).split(/[\s,;]+/).map((item)=>item.toLocaleLowerCase()).filter(Boolean)}
function clean(value){return typeof value==='string'?value.trim():value==null?'':String(value).trim()}
function unique(values){return[...new Set(values.filter((value)=>value!==null&&value!==undefined&&value!==''))]}
function onlyObjects(items){return Array.isArray(items)?items.filter((item)=>item&&typeof item==='object'):[]}
function finiteOrBlank(value){return typeof value==='number'&&Number.isFinite(value)?value:''}
function stateOrUnknown(value){return typeof value==='string'&&value!==''?value:'unknown'}
function fieldValues(value){return Array.isArray(value?.values)?value.values.filter((item)=>item!==null&&item!==undefined&&item!=='').map(String).join(' | '):''}
function csvCell(value){let text=value===null||value===undefined?'':String(value)
if(typeof value==='string'&&/^[=+\-@\t\r]/.test(text.trimStart()))text=`'${text}`
return`"${text.replaceAll('"','""')}"`}
