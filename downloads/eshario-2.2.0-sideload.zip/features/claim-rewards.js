import{bandPauseMs} from '../core/pace-jitter.js'
import{mustStop,classifyStatus} from '../adapter/error-codes.js'
import{askDayBudget,COUNTER_UNAVAILABLE} from './day-budget.js'
import{STOP_REASON_KEYS} from '../automation/stop-reasons.js'
export const HUB_REWARDS_FEATURE='hubRewards'
export const CLAIM_MAX_PER_PRESS=20
export function claimCost(one){return one?.kind==='group'?2:1}
export const GRANT_CALLS=1
export const LIST_CALLS=1
export const REFRESH_CALLS=1
export const CLAIM_NO_REFRESH=Object.freeze(['captcha','fatal','out-of-coins'])
export const CLAIM_PAUSE_BAND_MS=Object.freeze({minMs:800,maxMs:1600})
export const CLAIM_LOAD_COOLDOWN_MS=60_000
export const CLAIM_EVENT_WINDOW_MS=15_000
export const CLAIM_EMPTY_COOLDOWN_MS=30_000
export const CLAIM_EMPTY_MAX_MS=900_000
export function loadCooldownMs(holds,emptyStreak){if(holds===true)return CLAIM_LOAD_COOLDOWN_MS
const streak=Number.isSafeInteger(emptyStreak)&&emptyStreak>0?Math.min(emptyStreak,10):0
return Math.min(CLAIM_EMPTY_COOLDOWN_MS*(2**streak),CLAIM_EMPTY_MAX_MS)}
export const CLAIM_STOP_REASONS=Object.freeze(['objectives-off','unreadable-objectives'])
export function claimPauseMs(random){return bandPauseMs(CLAIM_PAUSE_BAND_MS.minMs,CLAIM_PAUSE_BAND_MS.maxMs,random)}
export function claimedLine(sum,t){const say=typeof t==='function'?t:(key)=>key
const parts=[]
const num=(value)=>(Number.isSafeInteger(value)&&value>0?value:0)
if(num(sum?.coins)>0)parts.push(say('hubRewards.coins',{coins:num(sum.coins)}))
if(num(sum?.packs)>0)parts.push(say('hubRewards.packs',{count:num(sum.packs)}))
if(num(sum?.items)>0)parts.push(say('hubRewards.items',{count:num(sum.items)}))
if(num(sum?.xp)>0)parts.push(say('hubRewards.xp'))
if(num(sum?.other)>0)parts.push(say('hubRewards.other',{count:num(sum.other)}))
if(num(sum?.unreadable)>0)parts.push(say('hubRewards.unreadable',{count:num(sum.unreadable)}))
return parts.join(' · ')}
export const CLAIM_WHY=Object.freeze({'day-budget':'hubRewards.why.dayBudget',
captcha:'hubRewards.why.captcha',fatal:'hubRewards.why.fatal','out-of-coins':'hubRewards.why.fatal',
'objectives-off':'hubRewards.why.off','unreadable-objectives':'hubRewards.why.unreadable',
[COUNTER_UNAVAILABLE]:STOP_REASON_KEYS[COUNTER_UNAVAILABLE],
failed:'hubRewards.why.failed'})
export function claimWhy(reason,t){const say=typeof t==='function'?t:(key)=>key
return say(CLAIM_WHY[reason]??CLAIM_WHY.failed)}
const emptySum=()=>({coins:0,packs:0,items:0,xp:0,other:0,unreadable:0})
function addKinds(sum,kinds){for(const key of Object.keys(sum)){const value=kinds?.[key]
if(Number.isSafeInteger(value)&&value>0)sum[key]+=value}
return sum}
function addLoot(loot,lootOf,rewards){if(lootOf===null)return loot
const part=lootOf(rewards)
const items=Array.isArray(part?.items)?part.items:[]
for(const item of items){if(item&&typeof item==='object')loot.items.push(item)}
if(Number.isSafeInteger(part?.packs)&&part.packs>0)loot.packs+=1
return loot}
export function createClaimRewards(deps={}){const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const read=typeof deps.read==='function'?deps.read:()=>({ok:false,reason:'unavailable',claimable:[]})
const review=typeof deps.review==='function'?deps.review:()=>({verdict:'unknown',reason:'no-door'})
const claim=typeof deps.claim==='function'?deps.claim:null
const grant=typeof deps.grant==='function'?deps.grant:null
const kinds=typeof deps.kinds==='function'?deps.kinds:()=>emptySum()
const lootOf=typeof deps.loot==='function'?deps.loot:null
const note=typeof deps.note==='function'?deps.note:null
const budget=deps.budget??null
const sleep=typeof deps.sleep==='function'?deps.sleep:()=>Promise.resolve()
const random=typeof deps.random==='function'?deps.random:Math.random
const onProgress=typeof deps.onProgress==='function'?deps.onProgress:()=>{}
const loadList=typeof deps.load==='function'?deps.load:null
const now=typeof deps.now==='function'?deps.now:null
const say=typeof deps.say==='function'?deps.say:()=>{}
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const counts={runs:0,claimed:0,granted:0,skipped:0,stopped:0,refusedByBudget:0,loads:0,failedLoads:0,events:0,glued:0,
refreshed:0,refreshFailed:0}
let running=false
let last=null
let failure=null
let loading=false
let loadedAt=null
let emptyStreak=0
const activeNow=()=>{try{return isActive(HUB_REWARDS_FEATURE)===true}catch(err){onError(err)
return null}}
function view(){if(activeNow()!==true)return{ok:false,reason:'locked',count:0,choice:0,running}
let facts=null
try{facts=read()}catch(err){onError(err)
return{ok:false,reason:'unreadable',count:0,choice:0,running}}
if(facts?.ok!==true)return{ok:false,reason:facts?.reason??'unreadable',count:0,choice:0,running}
if(!(Number.isSafeInteger(facts.groupsAll)&&facts.groupsAll>0))void load().catch(onError)
const list=Array.isArray(facts.claimable)?facts.claimable:[]
return{ok:true,reason:null,count:list.length,choice:Number.isSafeInteger(facts.choice)?facts.choice:0,running}}
async function run(){const idle=(reason)=>({ok:false,reason,claimed:0,left:0,sum:emptySum(),stoppedBy:null})
if(running)return idle('busy')
if(activeNow()!==true)return idle('locked')
if(claim===null)return idle('unavailable')
let facts=null
try{facts=read()}catch(err){onError(err)
return idle('unreadable')}
if(facts?.ok!==true)return idle(facts?.reason??'unreadable')
const queue=(Array.isArray(facts.claimable)?facts.claimable:[]).slice(0,CLAIM_MAX_PER_PRESS)
if(queue.length===0)return idle('nothing')
running=true
counts.runs+=1
const sum=emptySum()
const loot={items:[],packs:0}
let claimed=0
let stoppedBy=null
try{for(let index=0;index<queue.length;index+=1){const one=queue[index]
onProgress({done:claimed,total:queue.length,running:true})
let verdict=null
try{verdict=review(one)}catch(err){onError(err)
verdict={verdict:'unknown',reason:'door-failed'}}
if(verdict?.verdict!=='allowed'){counts.skipped+=1
if(CLAIM_STOP_REASONS.includes(verdict?.reason)){stoppedBy=verdict.reason
break}
continue}
const stop=await askDayBudget(budget,claimCost(one))
if(stop!==null){counts.refusedByBudget+=1
stoppedBy=stop
break}
let answer=null
let missed=false
try{answer=await claim(one)}catch(err){
if(err?.skip===true){counts.skipped+=1
missed=true
onError(err)}
else{const status=err?.status??null
stoppedBy=mustStop(status)?classifyStatus(status):'failed'
counts.stopped+=1
failure={status,httpStatus:err?.httpStatus??null,kind:one?.kind??null,id:one?.id??null,
message:String(err?.message??err).slice(0,120)}
onError(err)
break}}
if(!missed){claimed+=1
counts.claimed+=1
addKinds(sum,kinds(answer?.rewards))
addLoot(loot,lootOf,answer?.rewards)
if(answer?.hasUTRewards===true&&grant!==null){const paid=await askDayBudget(budget,GRANT_CALLS)
if(paid!==null){counts.refusedByBudget+=1
stoppedBy=paid
break}
try{const got=await grant()
counts.granted+=1
addLoot(loot,lootOf,got?.items)}catch(err){const status=err?.status??null
stoppedBy=mustStop(status)?classifyStatus(status):'failed'
counts.stopped+=1
onError(err)
break}}}
if(index<queue.length-1){try{await sleep(claimPauseMs(random))}catch(err){onError(err)}}}}finally{running=false
onProgress({done:claimed,total:queue.length,running:false})}
if(note!==null&&(loot.items.length>0||loot.packs>0)){
const hard=stoppedBy!==null&&CLAIM_NO_REFRESH.includes(stoppedBy)
let refused=hard?stoppedBy:null
if(!hard&&loot.items.length>0){refused=await askDayBudget(budget,REFRESH_CALLS)
if(refused!==null)counts.refusedByBudget+=1}
try{const out=note({items:loot.items,packs:loot.packs},{net:refused===null})
if(out?.ok===true)counts.refreshed+=1
else counts.refreshFailed+=1}catch(err){counts.refreshFailed+=1
onError(err)}}
let left=0
try{const after=read()
left=after?.ok===true&&Array.isArray(after.claimable)?after.claimable.length:0}catch(err){onError(err)}
const result={ok:claimed>0,reason:claimed>0?null:(stoppedBy??'nothing'),claimed,left,sum,stoppedBy}
last={...result,sum:{...sum}}
if(claimed>0){const parts=claimedLine(sum,deps.t)
say(parts===''?'hubRewards.claimedOnly':'hubRewards.claimed',{count:claimed,parts})}
else if(stoppedBy!==null)say('hubRewards.stopped',{why:claimWhy(stoppedBy,deps.t)})
else say('hubRewards.gone')
return result}
function holdsList(){try{const facts=read()
return Number.isSafeInteger(facts?.groupsAll)&&facts.groupsAll>0}catch(err){onError(err)
return false}}
async function load(){if(loadList===null)return{ok:false,reason:'unavailable'}
if(loading)return{ok:false,reason:'busy'}
if(activeNow()!==true)return{ok:false,reason:'locked'}
const cooldown=loadCooldownMs(holdsList(),emptyStreak)
if(loadedAt!==null&&now!==null&&now()-loadedAt<cooldown)return{ok:false,reason:'cooldown'}
loading=true
try{const stop=await askDayBudget(budget,LIST_CALLS)
if(stop!==null){counts.refusedByBudget+=1
return{ok:false,reason:stop}}
counts.loads+=1
await loadList()
if(now!==null)loadedAt=now()
emptyStreak=holdsList()?0:emptyStreak+1
return{ok:true,reason:null}}catch(err){counts.failedLoads+=1
emptyStreak+=1
if(now!==null)loadedAt=now()
onError(err)
return{ok:false,reason:'failed'}}finally{loading=false}}
function facts(){try{return read()}catch(err){onError(err)
return{ok:false,reason:'unreadable'}}}
return{view,run,facts,load,
invalidate(){if(now!==null&&loadedAt!==null&&now()-loadedAt<CLAIM_EVENT_WINDOW_MS){counts.glued+=1
return{ok:false,reason:'glued'}}
counts.events+=1
loadedAt=null
return{ok:true,reason:null}},
state:()=>({active:activeNow(),running,loading,feature:HUB_REWARDS_FEATURE,
holds:holdsList(),
rule:{maxPerPress:CLAIM_MAX_PER_PRESS,pauseMinMs:CLAIM_PAUSE_BAND_MS.minMs,pauseMaxMs:CLAIM_PAUSE_BAND_MS.maxMs,
loadCooldownMs:CLAIM_LOAD_COOLDOWN_MS,emptyCooldownMs:CLAIM_EMPTY_COOLDOWN_MS,
eventWindowMs:CLAIM_EVENT_WINDOW_MS,
nextLoadMs:loadCooldownMs(holdsList(),emptyStreak),emptyStreak},
counts:{...counts},failure:failure===null?null:{...failure},
last:last===null?null:{...last,sum:{...last.sum}}}),
dispose(){last=null
failure=null}}}
