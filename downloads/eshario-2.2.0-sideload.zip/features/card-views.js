import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
export const CARD_VIEW_STYLESHEET=new URL('../ui/card-views.css',import.meta.url).href
export const CARD_VIEW_LINK_ID='fut-companion-card-views'
export const CARD_VIEW_FIT_BUILD='CVC1'
export const CARD_VIEWS=Object.freeze(['stats','compact'])
export const CARD_VIEW_DEFAULT='stats'
export const VIEW_MARK='futCardView'
export const VIEW_SELECTOR='[data-fut-card-view]'
export const FIT_MARK='futCardFit'
export const TILE_MIN_VAR='--fut-card-min'
export const SOLO_MARK='futCardSolo'
export const SOLO_FACE_VAR='--fut-card-solo-face'
export const SOLO_FACE_H_VAR='--fut-card-solo-face-h'
export const SOLO_K_VAR='--fut-card-solo-k'
export const EA_FACE=Object.freeze({small:82,large:144,largeHeight:200})
export const MEASURE_MARK='futCardMeasure'
export const PAGE_MARK='futCardPage'
export const PAGE_SELECTOR='[data-fut-card-page]'
export const STATS_MARK='futCardStats'
export const COLS_VAR='--fut-card-cols'
export const FACE_VAR='--fut-card-face'
export const FACE_H_VAR='--fut-card-face-h'
export const FACE_K_VAR='--fut-card-face-k'
export const GAP_X_VAR='--fut-card-gap-x'
export const GAP_Y_VAR='--fut-card-gap-y'
export const STATS_W_VAR='--fut-card-stats'
export const BOOSTS_W_VAR='--fut-card-boosts'
export const SCROLL_MARK='futScrollGutter'
export const SCROLL_SELECTOR='[data-fut-scroll-gutter]'
const SCROLL_KINDS=Object.freeze(['auto','scroll','overlay'])
const SCROLL_STOP='.ut-root-view'
const SCROLL_DEPTH=12
export function scrollChain(from,win,stop=SCROLL_STOP){const out=[]
let node=from??null
for(let depth=0;node&&depth<SCROLL_DEPTH;depth+=1){if(node.nodeType!==undefined&&node.nodeType!==1)break
let style=null
try{style=win?.getComputedStyle?.(node)??null}catch{style=null}
const overflowY=typeof style?.overflowY==='string'?style.overflowY:''
const client=Number(node.clientHeight)||0
const scroll=Number(node.scrollHeight)||0
const name=`${String(node.tagName??'').toLowerCase()}.${String(node.className??'').split(' ')[0]}`
out.push({node,name,overflowY,
bar:Math.max(0,(Number(node.offsetWidth)||0)-(Number(node.clientWidth)||0)),
scrolls:scroll>client+1,
box:SCROLL_KINDS.includes(overflowY),
gutter:node.dataset?.[SCROLL_MARK]==='1'})
let last=false
try{last=node.matches?.(stop)===true}catch{last=false}
if(last)break
node=node.parentNode??null}
return out}
export function findScrollHost(from,win,stop=SCROLL_STOP){for(const one of scrollChain(from,win,stop)){if(one.box)return one.node}
return null}
export function markScrollGutter(from,win,stop=SCROLL_STOP){const host=findScrollHost(from,win,stop)
if(!host?.dataset)return null
if(host.dataset[SCROLL_MARK]!=='1')host.dataset[SCROLL_MARK]='1'
return host}
export function clearScrollGutter(host){if(!host?.dataset)return false
if(host.dataset[SCROLL_MARK]===undefined)return false
delete host.dataset[SCROLL_MARK]
return true}
export function inDetailColumn(root){let nav=false
let node=root?.parentNode??null
for(let depth=0;node&&depth<SCROLL_DEPTH;depth+=1){const names=String(node.className??'').split(/\s+/)
if(names.includes('ut-root-view'))return false
if(names.includes('ut-split-view'))return nav
if(names.includes('ut-navigation-container-view'))nav=true
node=node.parentNode??null}
return false}
export const PAGE_COLUMNS=5
export const PAGE_SIZE=20
export const MARKET_COLUMNS=4
export const MARKET_COLUMNS_NARROW=3
export const STAT_COLUMNS=Object.freeze([3,2])
export const FACE_FLOOR=0.5
export const MARKET_FACE_FLOOR=1
export const MAX_PRICE_CHARS=10
export function moneyFloorOf(input){const num=(one)=>(Number.isFinite(one)&&one>0?one:0)
const value=num(input?.value)
const per=num(input?.per)
const gap=num(input?.gap)
if(value<=0)return 0
return Math.ceil(Math.max(value,per*MAX_PRICE_CHARS)+gap)}
export function moneyCellsOf(cells){let value=0
let per=0
let chars=0
for(const cell of Array.isArray(cells)?cells:[]){const width=Number.isFinite(cell?.width)&&cell.width>0?cell.width:0
if(width<=0)continue
if(width>value)value=width
const long=Number.isSafeInteger(cell?.chars)&&cell.chars>0?cell.chars:0
if(cell?.time===true||long<=0)continue
if(long>chars){chars=long
per=width/long}}
return{value,per}}
export function marketColumns(input){const num=(value)=>(Number.isFinite(value)&&value>0?value:0)
const box=num(input?.box)
const native=num(input?.faceNative)
const floor=num(input?.moneyFloor)
if(box<=0||native<=0||floor<=0)return MARKET_COLUMNS
const gapX=num(input?.gapX)
const side=num(input?.side)
const tile=(box-gapX*(MARKET_COLUMNS-1))/MARKET_COLUMNS
return tile-side-native>=floor?MARKET_COLUMNS:MARKET_COLUMNS_NARROW}
export const ROW_SELECTOR='li.listFUTItem'
const BOX_SELECTOR='.entityContainer'
const BUTTON_SELECTOR='button.btnAction'
const FACE_CLASS='item'
const PLAYER_STATS_SELECTOR='.player-stats-data-component ul'
const BOOST_STATS_SELECTOR='.list-data-playstyle ul'
const STATS_SELECTOR=`${PLAYER_STATS_SELECTOR},${BOOST_STATS_SELECTOR}`
function statsKindOf(node){if(!node)return null
try{if(node.closest?.('.list-data-playstyle'))return 'boosts'}catch{/* спросим иначе */}
let up=node.parentElement??node.parentNode??null
for(let depth=0;up&&depth<3;depth+=1){const cls=typeof up.className==='string'?up.className:''
if(cls.includes('list-data-playstyle'))return 'boosts'
if(cls.includes('player-stats-data-component'))return 'stats'
up=up.parentElement??up.parentNode??null}
return 'stats'}
const CONTENT_SELECTOR='.rowContent'
const MONEY_SELECTOR='.auction'
const DESK_SELECTOR='.fx-desk'
const MONEY_CELL_SELECTOR='.value,.time'
const MONEY_TIME_CLASS='time'
const ROW_SAMPLE=12
const MAX_TRIES=8
const STYLE_WAITS=40
const DESK_WAITS=20
export function tileStyled(row,win){let box=null
try{box=row?.querySelector?.(BOX_SELECTOR)??null}catch{box=null}
if(!box)return true
let display=null
try{display=win?.getComputedStyle?.(box)?.display??null}catch{display=null}
if(display===null||display===undefined||display==='')return true
if(display!=='grid'&&display!=='contents')return false
return deskStyled(row,win)}
function deskStyled(row,win){let desk=null
try{desk=row?.querySelector?.(`${MONEY_SELECTOR} > ${DESK_SELECTOR}`)??null}catch{desk=null}
if(!desk)return true
let cap=null
try{cap=win?.getComputedStyle?.(desk)?.maxWidth??null}catch{cap=null}
if(cap===null||cap===undefined||cap==='')return true
return cap!=='none'}
const FRAME_TIMEOUT_MS=250
export function sanitizeCardView(stored){return CARD_VIEWS.includes(stored)?stored:CARD_VIEW_DEFAULT}
export function nextCardView(current){const at=CARD_VIEWS.indexOf(sanitizeCardView(current))
return CARD_VIEWS[(at+1)%CARD_VIEWS.length]}
export function tileMinWidth(parts){const num=(value)=>(Number.isFinite(value)&&value>0?value:0)
const face=num(parts?.face)
if(face<=0)return null
const stats=num(parts?.stats)
const money=stats>0||parts?.desk===false?0:num(parts?.money)
const card=face+num(parts?.mar)
const beside=card+num(parts?.sideGap)+money
const side=stats>0?face+num(parts?.mar)+num(parts?.gap)+stats
:(parts?.stack===false?beside:Math.max(card,money))
const rest=side+num(parts?.pad)+num(parts?.frame)
const share=num(parts?.share)
if(share>0&&share<0.9)return Math.ceil(rest/(1-share))
return Math.ceil(num(parts?.button)+rest)}
export function buttonShare(button,rowWidth,basis){const wide=Number(button)
if(!Number.isFinite(wide)||wide<=0)return 0
const said=String(basis??'').trim()
if(said.endsWith('%')){const part=Number.parseFloat(said)
if(Number.isFinite(part)&&part>0&&part<90)return part/100}
const row=Number(rowWidth)
return Number.isFinite(row)&&row>0?wide/row:0}
export function tileFormOf(row){if(!row)return null
const pick=(selector)=>{try{return row.querySelector?.(selector)??null}catch{return null}}
const cls=(node)=>(node?String(node.className??'').trim():'—')
const box=pick(BOX_SELECTOR)
const face=box?.firstElementChild??box?.children?.[0]??null
const stats=pick(STATS_SELECTOR)
const money=pick(MONEY_SELECTOR)
let desk=false
if(money!==null){try{desk=(money.querySelector?.(DESK_SELECTOR)??null)!==null}catch{desk=false}}
return[cls(row),cls(box),cls(face),
pick(BUTTON_SELECTOR)?'кнопка':'—',
stats?(statsKindOf(stats)??'статы'):'—',
cls(pick(CONTENT_SELECTOR)),
money?'торги':'—',desk?'касса':'—'].join('|')}
export function readTileParts(row,win){if(!row)return null
const px=(value)=>{const number=Number.parseFloat(value??'')
return Number.isFinite(number)&&number>0?number:0}
const width=(node)=>{if(!node)return 0
let value=null
try{value=Number(node.getBoundingClientRect?.()?.width)}catch{value=null}
if(!Number.isFinite(value)||value<=0){const fallback=Number(node.offsetWidth??node.clientWidth)
value=Number.isFinite(fallback)?fallback:0}
return value>0?value:0}
const pick=(selector)=>{try{return row.querySelector?.(selector)??null}catch{return null}}
const style=(node)=>{if(!node)return null
try{return win?.getComputedStyle?.(node)??null}catch{return null}}
const box=pick(BOX_SELECTOR)
const boxStyle=style(box)
const face=box?.firstElementChild??box?.children?.[0]??null
const faceStyle=style(face)
const sides=(node)=>{const one=style(node)
if(!one)return 0
return px(one.paddingLeft)+px(one.paddingRight)+px(one.borderLeftWidth)+px(one.borderRightWidth)}
const buttonNode=pick(BUTTON_SELECTOR)
const button=width(buttonNode)
const rowWidth=width(row)
const statsNode=pick(STATS_SELECTOR)
const content=pick(CONTENT_SELECTOR)
const contentStyle=style(content)
const stack=String(contentStyle?.flexDirection??'column').startsWith('column')
const moneyNode=pick(MONEY_SELECTOR)
let desk=null
if(moneyNode!==null){try{desk=(moneyNode.querySelector?.(DESK_SELECTOR)??null)!==null}catch{desk=null}}
return{button,
share:buttonShare(button,rowWidth,style(buttonNode)?.flexBasis),
face:width(face),
mar:faceStyle?px(faceStyle.marginLeft)+px(faceStyle.marginRight):0,
gap:px(boxStyle?.columnGap),
stats:width(statsNode),
money:width(moneyNode),
stack,
desk,
sideGap:px(contentStyle?.columnGap),
statsKind:statsKindOf(statsNode),
pad:sides(row),
frame:sides(content)+sides(box)}}
export function readTileHeights(row,win){if(!row)return null
const px=(value)=>{const number=Number.parseFloat(value??'')
return Number.isFinite(number)&&number>0?number:0}
const style=(node)=>{if(!node)return null
try{return win?.getComputedStyle?.(node)??null}catch{return null}}
const pick=(selector)=>{try{return row.querySelector?.(selector)??null}catch{return null}}
const size=(node)=>{if(!node)return{width:0,height:0}
let rect=null
try{rect=node.getBoundingClientRect?.()}catch{rect=null}
const width=Number(rect?.width)
const height=Number(rect?.height)
return{width:Number.isFinite(width)&&width>0?width:0,height:Number.isFinite(height)&&height>0?height:0}}
const box=pick(BOX_SELECTOR)
const face=box?.firstElementChild??box?.children?.[0]??null
if(!face)return null
const stats=pick(STATS_SELECTOR)
const name=(()=>{try{return box?.querySelector?.(':scope > .name')??null}catch{return null}})()
const faceBox=size(face)
if(faceBox.width<=0)return null
const vertical=(node)=>{const one=style(node)
if(!one)return 0
return px(one.paddingTop)+px(one.paddingBottom)+px(one.borderTopWidth)+px(one.borderBottomWidth)}
return{faceWidth:faceBox.width,faceHeight:faceBox.height,
nameHeight:size(name).height,
statsWidth:size(stats).width,statsHeight:size(stats).height,
rowGap:px(style(box)?.rowGap),
padY:vertical(row)+vertical(pick(CONTENT_SELECTOR))+vertical(box)}}
export function pageGridPlan(input){const num=(value)=>(Number.isFinite(value)&&value>0?value:0)
const box=num(input?.box)
const height=num(input?.height)
const ratio=num(input?.ratio)
const native=num(input?.faceNative)
const page=Math.max(PAGE_SIZE,Number.isSafeInteger(input?.page)&&input.page>0?input.page:0)
const tried=[]
if(box<=0||height<=0||ratio<=0||native<=0)return{best:null,tried}
const gapX=num(input?.gapX)
const gapY=num(input?.gapY)
const side=num(input?.side)
const padY=num(input?.padY)
const nameHeight=num(input?.nameHeight)
const rowGap=num(input?.rowGap)
const ceiling=num(input?.faceMax)>native?num(input.faceMax):native
const columns=Number.isSafeInteger(input?.columns)&&input.columns>0?input.columns:PAGE_COLUMNS
const rows=Math.ceil(page/columns)
const tileWidth=(box-gapX*(columns-1))/columns
const tileRoom=(height-gapY*(rows-1))/rows
for(const stats of Array.isArray(input?.stats)?input.stats:[]){const statsWidth=num(stats?.width)
const statsHeight=num(stats?.height)
const byWidth=tileWidth-side-statsWidth
const byHeight=(tileRoom-padY)/ratio
const floor=nameHeight+statsHeight+rowGap+padY
const face=Math.floor(Math.min(byWidth,byHeight))
const share=input?.money===true?MARKET_FACE_FLOOR:FACE_FLOOR
const floorFace=Math.max(1,Math.floor(native*share))
tried.push({columns,statColumns:stats?.columns??null,rows,
tileWidth:Math.round(tileWidth*100)/100,tileRoom:Math.round(tileRoom*100)/100,
byWidth:Math.round(byWidth*100)/100,byHeight:Math.round(byHeight*100)/100,
floor:Math.round(floor*100)/100,
statsWidth:Math.round(statsWidth*100)/100,statsHeight:Math.round(statsHeight*100)/100,
face:Math.min(Math.max(face,floorFace),ceiling),
big:face>=native,
noScroll:floor<=tileRoom&&(input?.money===true||face>=floorFace),
fitsWidth:byWidth>=native,
fits:byWidth>=native&&byHeight>=native&&floor<=tileRoom})}
const pick=(list)=>list.reduce((win,one)=>{if(one.statColumns!==win.statColumns)return one.statColumns>win.statColumns?one:win
return one.face>win.face?one:win})
const good=tried.filter((one)=>one.noScroll)
const last=pick(tried.map((one)=>({...one,face:Math.min(Math.max(one.face,native),ceiling)})))
const best=tried.length===0?null:(good.length>0?pick(good):last)
return{best,tried}}
export const BOX_ASK_LIMIT=3
export const OVER_ASK_LIMIT=3
const BOX_ASK_MEMORY=4
export const CARD_VIEW_BUILD='W21M1b'
export function overflowOf(scrollHeight,clientHeight){const full=Number(scrollHeight)
const seen=Number(clientHeight)
if(!Number.isFinite(full)||!Number.isFinite(seen))return 0
return full-seen}
export function pageRoom(list,win=null){let host=null
try{host=list?.parentNode??null}catch{host=null}
if(host===null||host===undefined)return 0
let box=0
try{box=Number(host.clientHeight)||0}catch{box=0}
if(box<=0)return 0
let kids=[]
try{kids=Array.from(host.children??[])}catch{kids=[]}
let taken=0
for(const kid of kids){if(kid===list)continue
let style=null
try{style=win?.getComputedStyle?.(kid)??null}catch{style=null}
const display=typeof style?.display==='string'?style.display:''
let height=0
if(display==='none'){const own=Number.parseFloat(style?.height??'')
height=Number.isFinite(own)&&own>0?own:0}
else{try{height=Number(kid.getBoundingClientRect?.()?.height)||0}catch{height=0}}
taken+=height}
const room=box-taken
return room>0?room:0}
export function faceHeightOf(face,ratio){const width=Number.isFinite(face)&&face>0?face:0
const k=Number.isFinite(ratio)&&ratio>0?ratio:0
if(width<=0||k<=0)return 0
return Math.max(1,Math.floor(width*k))}
export function boxWake(now,base,memory,max=BOX_ASK_LIMIT){const seen=Array.isArray(memory)?memory:[]
const width=Number(now?.box)||0
const height=Number(now?.height)||0
if(width<=0||height<=0)return{wake:false,why:'no-box',memory:seen}
if(!base)return{wake:false,why:'no-plan',memory:[]}
const drift=(Math.abs(width-(Number(base.box)||0))>=1?'width':'')
+(Math.abs(height-(Number(base.height)||0))>=1?'height':'')
if(drift==='')return{wake:false,why:'same',memory:[]}
const same=(one)=>Math.abs(width-one.box)<1&&Math.abs(height-one.height)<1
const known=seen.find(same)??null
if(known&&known.asks>=max)return{wake:false,why:'loop',memory:seen}
const next=known
?seen.map((one)=>(one===known?{...one,asks:one.asks+1}:one))
:[{box:width,height,asks:1},...seen].slice(0,BOX_ASK_MEMORY)
return{wake:true,why:drift==='widthheight'?'both':drift,memory:next}}
const SVG_NS='http://www.w3.org/2000/svg'
export function drawViewIcon(doc,host,view){if(!host)return false
const kind=sanitizeCardView(view)
if(host.dataset&&host.dataset.futCardViewIcon===kind&&host.firstChild)return false
if(host.dataset)host.dataset.futCardViewIcon=kind
if(typeof doc?.createElementNS!=='function')return false
const shape=(tag,attrs)=>{const node=doc.createElementNS(SVG_NS,tag)
for(const[name,value]of Object.entries(attrs))node.setAttribute(name,String(value))
return node}
const box=shape('svg',{viewBox:'0 0 16 16',width:15,height:15,fill:'none',
stroke:'currentColor','stroke-width':1.3,'aria-hidden':'true'})
if(kind==='stats'){box.appendChild(shape('rect',{x:1.2,y:2.2,width:5,height:11.6,rx:1}))
for(const y of[4.6,8,11.4])box.appendChild(shape('line',{x1:8.4,y1:y,x2:14.6,y2:y}))}
else for(const y of[1.6,9])for(const x of[1.2,6.15,11.1]){box.appendChild(shape('rect',{x,y,width:3.7,height:5.4,rx:.8}))}
while(host.firstChild)host.removeChild(host.firstChild)
host.appendChild(box)
return true}
export function cardViewButton(doc,opts={}){const view=sanitizeCardView(opts.view)
const t=typeof opts.t==='function'?opts.t:(key)=>key
const onPick=typeof opts.onPick==='function'?opts.onPick:null
const onError=typeof opts.onError==='function'?opts.onError:()=>{}
const title=t(view==='compact'?'cardView.compact':'cardView.stats')
const button=el(doc,'button',{class:'fx-view-toggle',
dataset:{futCardViewToggle:view},
attrs:{type:'button',title,'aria-label':title}})
drawViewIcon(doc,button,view)
if(onPick)button.addEventListener('click',(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{onPick(nextCardView(view))}catch(err){onError(err)}})
return button}
export function createCardViews(deps={}){const{doc}=deps
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const windowOf=()=>{try{return doc?.defaultView??null}catch{return null}}
const frame=(fn)=>{const given=typeof deps.frame==='function'?deps.frame:null
if(given){try{given(fn)
return}catch(err){onError(err)}}
const view=windowOf()
if(typeof view?.requestAnimationFrame==='function'){try{view.requestAnimationFrame(fn)
return}catch(err){onError(err)}}
const later=typeof view?.setTimeout==='function'?view.setTimeout.bind(view)
:(typeof setTimeout==='function'?setTimeout:null)
if(later){try{later(fn,0)
return}catch(err){onError(err)}}
fn()}
let view=CARD_VIEW_DEFAULT
let min=null
let solo=null
let bigFace=null
let bigForm=null
let bigMeasured=false
let statsWidth=null
let boostsWidth=null
let measuredFor=null
let refit=false
let parts=null
let tries=0
let pending=false
let measures=0
let waits=0
let deskWaits=0
let desks=0
let rowsSeen=0
let wakes=0
function ensure(){ensureTheme(doc)
const link=ensureStylesheet(doc,CARD_VIEW_STYLESHEET,CARD_VIEW_LINK_ID)
try{if(link?.dataset&&link.dataset.futBuild!==CARD_VIEW_FIT_BUILD)link.dataset.futBuild=CARD_VIEW_FIT_BUILD}catch{/* метка — удобство, а не условие */}
return link}
const rowsOf=(list)=>{try{return Array.from(list?.querySelectorAll?.(ROW_SELECTOR)??[])}catch(err){onError(err)
return[]}}
let seer=null
let harked=new WeakSet()
let watched=[]
function faceTouched(records){for(const one of Array.isArray(records)?records:[]){let hit=false
try{hit=one?.target?.classList?.contains?.(FACE_CLASS)===true}catch{hit=false}
if(hit)return true}
return false}
function hark(lists){const all=Array.isArray(lists)?lists:[]
watched=all
const host=windowOf()
const Observer=host?.MutationObserver
if(typeof Observer!=='function')return 0
if(!seer){try{seer=new Observer((records)=>{if(measuredFor===view)return
if(!faceTouched(records))return
wakes+=1
tries=0
schedule(watched)})}catch(err){onError(err)
seer=null
return 0}}
let seen=0
for(const list of all){if(!list)continue
seen+=1
if(harked.has(list))continue
try{seer.observe(list,{attributes:true,attributeFilter:['class'],subtree:true})
harked.add(list)}catch(err){onError(err)}}
return seen}
function unhark(){try{seer?.disconnect?.()}catch(err){onError(err)}
harked=new WeakSet()
watched=[]}
function setVar(list,name,value){const wanted=Number.isFinite(value)&&value>0?`${value}px`:null
try{if(wanted===null){list.style?.removeProperty?.(name)
return false}
if(list.style?.getPropertyValue?.(name)!==wanted)list.style?.setProperty?.(name,wanted)}catch{/* переменная — удобство, а не условие */}
return wanted!==null}
function setNumber(list,name,value){const wanted=Number.isFinite(value)&&value>0?String(value):null
try{if(wanted===null){list.style?.removeProperty?.(name)
return false}
if(list.style?.getPropertyValue?.(name)!==wanted)list.style?.setProperty?.(name,wanted)}catch{/* переменная — удобство, а не условие */}
return wanted!==null}
function askBigFace(parts){const body=doc?.body??null
const узлы=[]
const поставить=(className)=>{if(!body)return null
let node=null
try{node=doc.createElement('div')
node.className=className
node.setAttribute('style','position:absolute;left:-9999px;top:0;visibility:hidden;pointer-events:none')
body.appendChild(node)}catch(err){onError(err)
node=null}
if(node)узлы.push(node)
return node}
const size=(node)=>{if(!node)return null
let rect=null
try{rect=node.getBoundingClientRect?.()}catch{rect=null}
const width=Number(rect?.width)||0
const height=Number(rect?.height)||0
return width>0?{width,height:height>0?height:width*EA_FACE.largeHeight/EA_FACE.large}:null}
const smallNode=поставить('item small')
const largeNode=поставить('item large')
const small=size(smallNode)
const large=size(largeNode)
for(const node of узлы){try{node.remove?.()}catch{/* узел унесли вместе со страницей */}}
const native=Number(small?.width)>0?small.width:(Number(parts?.face)>0?Number(parts.face):EA_FACE.small)
if(large)return{width:Math.round(large.width),height:Math.round(large.height),native}
const width=Math.round(native*EA_FACE.large/EA_FACE.small)
return{width,height:Math.round(width*EA_FACE.largeHeight/EA_FACE.large),native}}
function paintSolo(lists){const on=solo===true&&Number(bigFace?.width)>0
for(const list of Array.isArray(lists)?lists:[]){if(!list?.dataset)continue
if(on){if(list.dataset[SOLO_MARK]!=='1')list.dataset[SOLO_MARK]='1'}
else if(list.dataset[SOLO_MARK]!==undefined)delete list.dataset[SOLO_MARK]
setVar(list,SOLO_FACE_VAR,on?bigFace.width:0)
setVar(list,SOLO_FACE_H_VAR,on?bigFace.height:0)
setNumber(list,SOLO_K_VAR,on&&bigFace.native>0?Math.round(bigFace.width/bigFace.native*100)/100:0)}
return on}
function forget(){const had=min!==null
min=null
solo=null
bigFace=null
bigForm=null
bigMeasured=false
statsWidth=null
boostsWidth=null
measuredFor=null
refit=false
parts=null
tries=0
waits=0
deskWaits=0
desks=0
rowsSeen=0
unhark()
return had}
function apply(lists,next){const wanted=sanitizeCardView(next)
if(wanted!==view){view=wanted
parts=null
tries=0
refit=false}
const all=Array.isArray(lists)?lists:[]
let marked=0
let fresh=false
for(const list of all){if(!list?.dataset)continue
if(list.dataset[VIEW_MARK]!==view){
if(list.dataset[VIEW_MARK]===undefined)fresh=true
list.dataset[VIEW_MARK]=view}
if(min===null){if(list.dataset[FIT_MARK]!==undefined)delete list.dataset[FIT_MARK]
try{list.style?.removeProperty?.(TILE_MIN_VAR)}catch{/* нечего снимать */}}
else{const value=`${min}px`
try{if(list.style?.getPropertyValue?.(TILE_MIN_VAR)!==value)list.style?.setProperty?.(TILE_MIN_VAR,value)}catch{/* переменная — удобство, а не условие */}
if(list.dataset[FIT_MARK]!=='1')list.dataset[FIT_MARK]='1'}
setVar(list,STATS_W_VAR,statsWidth)
setVar(list,BOOSTS_W_VAR,boostsWidth)
marked+=1}
if(marked>0)paintSolo(all)
if(fresh){tries=0
measuredFor=null
refit=true}
if(marked>0)hark(all)
if(desks>0&&marked>0&&measuredFor!==view&&deskLive(all)){tries=0
desks=0}
if(rowsSeen===0&&measures>0&&marked>0&&measuredFor!==view&&rowsLive(all))tries=0
if(measuredFor!==view&&marked>0)schedule(all)
return marked}
function rowsLive(lists){for(const list of Array.isArray(lists)?lists:[]){try{if(list?.querySelector?.(ROW_SELECTOR))return true}catch{/* следующий список */}}
return false}
function deskLive(lists){for(const list of Array.isArray(lists)?lists:[]){try{if(list?.querySelector?.(`${MONEY_SELECTOR} > ${DESK_SELECTOR}`))return true}catch{/* следующий список */}}
return false}
function schedule(lists){if(pending||measuredFor===view||tries>=MAX_TRIES)return false
pending=true
tries+=1
let raced=false
const once=()=>{if(raced)return
raced=true
pending=false
try{measure(lists)}catch(err){onError(err)}}
frame(once)
const host=windowOf()
const later=typeof host?.setTimeout==='function'?host.setTimeout.bind(host)
:(typeof setTimeout==='function'?setTimeout:null)
if(later){try{later(once,FRAME_TIMEOUT_MS)}catch(err){onError(err)}}
return true}
function sweep(live){const out={best:null,bestParts:null,bestRow:null,form:null,
wideStats:0,wideBoosts:0,skipped:0,deskless:0,desk:0,rows:0}
unclamp(live,true)
try{for(const list of live){for(const row of rowsOf(list).slice(0,ROW_SAMPLE)){out.rows+=1
const read=readTileParts(row,windowOf())
if(read?.money>0&&read.money>out.desk)out.desk=read.money
if(read?.stats>0){if(read.statsKind==='boosts')out.wideBoosts=Math.max(out.wideBoosts,read.stats)
else out.wideStats=Math.max(out.wideStats,read.stats)}
if(read?.desk===false&&!(read?.stats>0)&&read?.money>0){out.deskless+=1
if(deskWaits<DESK_WAITS){out.skipped+=1
continue}}
const value=tileMinWidth(read)
if(value===null){out.skipped+=1
continue}
if(out.best===null||value>out.best){out.best=value
out.bestParts=read
out.bestRow=row}}
if(out.best!==null)break}}finally{unclamp(live,false)}
out.form=tileFormOf(out.bestRow)
return out}
function measure(lists){measures+=1
const live=(Array.isArray(lists)?lists:[]).filter((one)=>one?.isConnected!==false&&one?.dataset?.[VIEW_MARK]===view)
if(live.length===0)return null
if(!tileStyled(rowsOf(live[0])[0],windowOf())){if(waits>=STYLE_WAITS)return null
waits+=1
tries=Math.max(0,tries-1)
schedule(live)
return null}
let scan=sweep(live)
rowsSeen=scan.rows
if(solo===null&&scan.best!==null)solo=scan.desk<=0
if(solo===true&&(bigFace===null||bigForm!==scan.form)){bigFace=askBigFace(scan.bestParts)
bigForm=scan.form
bigMeasured=false}
if(paintSolo(live)&&!bigMeasured){bigMeasured=true
scan=sweep(live)}
const best=scan.best
const bestParts=scan.bestParts
const wideStats=scan.wideStats
const wideBoosts=scan.wideBoosts
const skipped=scan.skipped
const deskless=scan.deskless
if(best===null&&deskless>0&&deskWaits<DESK_WAITS){deskWaits+=1
desks=deskless
tries=Math.max(0,tries-1)
schedule(live)
return null}
if(best===null)return null
const waiting=(refit&&skipped>0)||deskless>0
if(waiting&&min!==null&&best<min){measuredFor=null
return null}
min=best
measuredFor=waiting?null:view
if(!waiting)refit=false
desks=deskless
parts=bestParts
statsWidth=wideStats>0?Math.ceil(wideStats):null
boostsWidth=wideBoosts>0?Math.ceil(wideBoosts):null
apply(live,view)
return best}
function unclamp(lists,on){for(const list of Array.isArray(lists)?lists:[]){if(!list?.dataset)continue
if(on){if(list.dataset[MEASURE_MARK]!=='1')list.dataset[MEASURE_MARK]='1'}
else if(list.dataset[MEASURE_MARK]!==undefined)delete list.dataset[MEASURE_MARK]}}
function clear(){let gone=0
for(const list of Array.from(doc?.querySelectorAll?.(VIEW_SELECTOR)??[])){if(unmark(list))gone+=1}
forget()
return gone}
function unmark(list){if(!list)return false
let touched=false
for(const mark of[VIEW_MARK,FIT_MARK,MEASURE_MARK,SOLO_MARK]){if(list.dataset&&list.dataset[mark]!==undefined){delete list.dataset[mark]
touched=true}}
for(const name of[TILE_MIN_VAR,STATS_W_VAR,BOOSTS_W_VAR,SOLO_FACE_VAR,SOLO_FACE_H_VAR,SOLO_K_VAR]){try{if(list.style?.getPropertyValue?.(name))touched=true
list.style?.removeProperty?.(name)}catch{/* нечего снимать */}}
return touched}
return{ensure,apply,clear,unmark,forget,
state:()=>({view,min,statsWidth,boostsWidth,measuredFor,stale:measuredFor!==null&&measuredFor!==view,
solo,bigFace:bigFace?{...bigFace}:null,bigForm,bigMeasured,
parts:parts?{...parts}:null,tries,waits,measures,pending,
deskWaits,desks,
rowsSeen,
wakes,harks:watched.length,seer:seer!==null,
styles:Boolean(doc?.getElementById?.(CARD_VIEW_LINK_ID))})}}
export function createPageGrid(deps={}){const{doc}=deps
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const windowOf=()=>{try{return doc?.defaultView??null}catch{return null}}
const frame=(fn)=>{const given=typeof deps.frame==='function'?deps.frame:null
if(given){try{given(fn)
return}catch(err){onError(err)}}
const view=windowOf()
if(typeof view?.requestAnimationFrame==='function'){try{view.requestAnimationFrame(fn)
return}catch(err){onError(err)}}
const later=typeof view?.setTimeout==='function'?view.setTimeout.bind(view)
:(typeof setTimeout==='function'?setTimeout:null)
if(later){try{later(fn,0)
return}catch(err){onError(err)}}
fn()}
function raceFrame(run){let done=false
const once=()=>{if(done)return
done=true
try{run()}catch(err){onError(err)}}
frame(once)
const view=windowOf()
const later=typeof view?.setTimeout==='function'?view.setTimeout.bind(view)
:(typeof setTimeout==='function'?setTimeout:null)
if(later){try{later(once,FRAME_TIMEOUT_MS)}catch(err){onError(err)}}}
let layout=null
let base=null
let tried=[]
let tries=0
let fixes=0
let pending=false
let measures=0
let waits=0
let asked=[]
let refits=0
let over=0
let fitPending=false
let cutTried=null
let fitted='never'
let want={columns:PAGE_COLUMNS,money:false}
function ensure(){ensureTheme(doc)
return ensureStylesheet(doc,CARD_VIEW_STYLESHEET,CARD_VIEW_LINK_ID)}
const rowsOf=(list)=>{try{return Array.from(list?.querySelectorAll?.(ROW_SELECTOR)??[])}catch(err){onError(err)
return[]}}
const roomOf=(list,view)=>{const room=pageRoom(list,view)
if(room>0)return room
try{return list?.clientHeight??0}catch{return 0}}
const aliveOf=(lists)=>(Array.isArray(lists)?lists:[])
.filter((one)=>one?.isConnected!==false&&one?.dataset?.[VIEW_MARK]===CARD_VIEW_DEFAULT)
function statsAsk(list){const out={stats:{width:0,height:0},boosts:{width:0,height:0},hidden:false,found:false}
const view=windowOf()
for(const row of rowsOf(list).slice(0,ROW_SAMPLE)){let node=null
try{node=row.querySelector?.(STATS_SELECTOR)??null}catch{node=null}
if(!node)continue
out.found=true
let display=null
try{display=view?.getComputedStyle?.(node)?.display??null}catch{display=null}
if(display==='none'){out.hidden=true
continue}
let rect=null
try{rect=node.getBoundingClientRect?.()}catch{rect=null}
const width=Number(rect?.width)||0
const height=Number(rect?.height)||0
const one=out[statsKindOf(node)==='boosts'?'boosts':'stats']
if(width>one.width)one.width=width
if(height>one.height)one.height=height}
return out}
const askOf=(read)=>(read.stats.width>0?read.stats:read.boosts)
function moneyAsk(list){const out={width:0,height:0,floor:0,hidden:false,found:false}
const view=windowOf()
const cells=[]
let gap=0
for(const row of rowsOf(list).slice(0,ROW_SAMPLE)){let node=null
try{node=row.querySelector?.(MONEY_SELECTOR)??null}catch{node=null}
if(!node)continue
out.found=true
let display=null
try{display=view?.getComputedStyle?.(node)?.display??null}catch{display=null}
if(display==='none'){out.hidden=true
continue}
let rect=null
try{rect=node.getBoundingClientRect?.()}catch{rect=null}
const width=Number(rect?.width)||0
const height=Number(rect?.height)||0
if(width>out.width)out.width=width
if(height>out.height)out.height=height
if(gap<=0){let kid=null
try{kid=node.firstElementChild??null}catch{kid=null}
try{gap=px(view?.getComputedStyle?.(kid)?.columnGap)}catch{gap=0}}
let nodes=[]
try{nodes=Array.from(node.querySelectorAll?.(MONEY_CELL_SELECTOR)??[])}catch{nodes=[]}
for(const cell of nodes){let box=null
try{box=cell.getBoundingClientRect?.()}catch{box=null}
let time=false
try{time=cell.classList?.contains?.(MONEY_TIME_CLASS)===true}catch{time=false}
cells.push({width:Number(box?.width)||0,
chars:String(cell.textContent??'').trim().length,
time})}}
out.floor=moneyFloorOf({...moneyCellsOf(cells),gap})
return out}
const px=(value)=>{const number=Number.parseFloat(value??'')
return Number.isFinite(number)&&number>0?number:0}
function largeFaceProbe(native){return facadeProbe('item large',native*144/82)}
function smallFaceProbe(){return facadeProbe('item small',0)}
function facadeProbe(className,fallback){const body=doc?.body??null
if(!body)return fallback
try{const node=doc.createElement('div')
node.className=className
node.setAttribute('style','position:absolute;left:-9999px;top:0;visibility:hidden;pointer-events:none')
body.appendChild(node)
return node}catch(err){onError(err)
return fallback}}
function unclamp(lists,on){for(const list of Array.isArray(lists)?lists:[]){if(!list?.dataset)continue
if(on){if(list.dataset[MEASURE_MARK]!=='1')list.dataset[MEASURE_MARK]='1'}
else if(list.dataset[MEASURE_MARK]!==undefined)delete list.dataset[MEASURE_MARK]}}
function markStats(lists,columns){for(const list of Array.isArray(lists)?lists:[]){if(!list?.dataset)continue
const value=String(columns)
if(list.dataset[STATS_MARK]!==value)list.dataset[STATS_MARK]=value}}
function apply(lists,order={}){const all=Array.isArray(lists)?lists:[]
const columns=Number.isSafeInteger(order?.columns)&&order.columns>0?order.columns:PAGE_COLUMNS
const money=order?.money===true
if(columns!==want.columns||money!==want.money){want={columns,money}
layout=null
base=null
tried=[]
tries=0
fixes=0
waits=0}
let marked=0
let fresh=false
for(const list of all){if(!list?.dataset)continue
if(list.dataset[VIEW_MARK]!==CARD_VIEW_DEFAULT){if(list.dataset[VIEW_MARK]===undefined)fresh=true
list.dataset[VIEW_MARK]=CARD_VIEW_DEFAULT}
if(layout===null){if(list.dataset[PAGE_MARK]!==undefined)delete list.dataset[PAGE_MARK]}
else paintOne(list)
marked+=1}
if(fresh)tries=0
if(layout===null&&marked>0)schedule(all)
return marked}
function paintOne(list){if(!layout||!list?.dataset)return false
const set=(name,value)=>{try{if(list.style?.getPropertyValue?.(name)!==value)list.style?.setProperty?.(name,value)}catch{/* переменная — удобство, а не условие */}}
set(COLS_VAR,String(layout.columns))
set(FACE_VAR,`${layout.face}px`)
set(FACE_H_VAR,`${layout.faceHeight}px`)
if(base?.faceNative>0)set(FACE_K_VAR,String(Math.round(layout.face/base.faceNative*100)/100))
if(!base?.money){if(layout.statsWidth>0)set(STATS_W_VAR,`${Math.ceil(layout.statsWidth)}px`)
if(base?.boosts>0)set(BOOSTS_W_VAR,`${Math.ceil(base.boosts)}px`)}
markStats([list],layout.statColumns)
if(list.dataset[PAGE_MARK]!=='1')list.dataset[PAGE_MARK]='1'
return true}
function schedule(lists){if(pending||layout!==null||tries>=MAX_TRIES)return false
pending=true
tries+=1
raceFrame(()=>stepOne(lists))
return true}
function stepOne(lists){const live=aliveOf(lists)
if(live.length===0){pending=false
return null}
const list=live[0]
const row=rowsOf(list)[0]??null
if(!tileStyled(row,windowOf())){if(waits>=STYLE_WAITS){pending=false
return null}
waits+=1
raceFrame(()=>stepOne(lists))
return null}
unclamp(live,true)
const heights=readTileHeights(row,windowOf())
const parts=readTileParts(row,windowOf())
const wide=statsAsk(list)
const cash=want.money?moneyAsk(list):null
unclamp(live,false)
const ask=want.money?{width:cash?.width??0,height:cash?.height??0}:askOf(wide)
const empty=want.money?cash?.hidden===true:wide.hidden===true
const noStats=empty&&ask.width<=0
if(!heights||!parts||(ask.width<=0&&!noStats)){pending=false
return null}
const view=windowOf()
let style=null
try{style=view?.getComputedStyle?.(list)??null}catch{style=null}
base={box:list.clientWidth??0,height:roomOf(list,view),
gapX:px(style?.getPropertyValue?.(GAP_X_VAR)),gapY:px(style?.getPropertyValue?.(GAP_Y_VAR)),
ratio:heights.faceHeight>0?heights.faceHeight/heights.faceWidth:0,
faceNative:heights.faceWidth,
side:parts.mar+parts.gap+parts.pad+parts.frame,
padY:heights.padY,nameHeight:heights.nameHeight,rowGap:heights.rowGap,
page:Math.max(PAGE_SIZE,rowsOf(list).length),
boosts:wide.boosts.width,
columns:want.columns,
money:want.money,
moneyFloor:want.money?cash?.floor??0:0,
stats:[{columns:STAT_COLUMNS[0],width:ask.width,height:ask.height}]}
if(want.money){const probeOnly=largeFaceProbe(base.faceNative)
const smallOnly=smallFaceProbe()
raceFrame(()=>stepTwo(lists,probeOnly,smallOnly))
return true}
markStats(live,STAT_COLUMNS[1])
const probe=largeFaceProbe(base.faceNative)
const small=smallFaceProbe()
raceFrame(()=>stepTwo(lists,probe,small))
return true}
function stepTwo(lists,probe,small){const live=aliveOf(lists)
const takeProbe=()=>{if(typeof probe==='number')return probe
let width=0
try{width=Number(probe?.getBoundingClientRect?.()?.width)||0}catch{width=0}
try{probe?.remove?.()}catch{/* узел уже унесли вместе со страницей */}
return width>0?width:(base?.faceNative??0)*144/82}
const takeSmall=()=>{if(typeof small==='number')return small
let width=0
try{width=Number(small?.getBoundingClientRect?.()?.width)||0}catch{width=0}
try{small?.remove?.()}catch{/* узел уже унесли вместе со страницей */}
return width}
if(live.length===0||!base){pending=false
takeProbe()
takeSmall()
return null}
const list=live[0]
if(!want.money){unclamp(live,true)
const narrow=statsAsk(list)
unclamp(live,false)
markStats(live,STAT_COLUMNS[0])
const askNarrow=askOf(narrow)
if(askNarrow.width>0)base.stats.push({columns:STAT_COLUMNS[1],width:askNarrow.width,height:askNarrow.height})}
const faceMax=takeProbe()
const faceSmall=takeSmall()
if(faceSmall>0)base.faceNative=faceSmall
base.faceMax=faceMax
if(base.money)base.columns=marketColumns(base)
measures+=1
const made=pageGridPlan(base)
tried=made.tried
pending=false
if(!made.best)return null
layout={...made.best,faceHeight:faceHeightOf(made.best.face,base.ratio)}
for(const one of live)paintOne(one)
fixes=0
raceFrame(()=>verify(lists))
return layout}
function verify(lists){const live=aliveOf(lists)
if(live.length===0||!layout||!base)return null
const list=live[0]
const row=rowsOf(list)[0]??null
let tileHeight=0
try{tileHeight=Number(row?.getBoundingClientRect?.()?.height)||0}catch{tileHeight=0}
const scrollHeight=list.scrollHeight??0
const clientHeight=roomOf(list,windowOf())
const scrolls=overflowOf(scrollHeight,clientHeight)>0
layout.scrolls=scrolls
layout.tileHeight=Math.round(tileHeight*100)/100
if(cutTried){const helped=tileHeight<=cutTried.height-0.5
const back=cutTried.face
cutTried=null
if(!helped){layout={...layout,face:back,faceHeight:faceHeightOf(back,base.ratio)}
for(const one of live)paintOne(one)
layout.held='right'
return layout}
layout.held='face'}
if(!scrolls||fixes>=3||layout.face<=base.faceNative)return layout
const excess=scrollHeight-clientHeight
const cut=Math.ceil(excess/Math.max(1,layout.rows)/Math.max(0.01,base.ratio))+1
const next=Math.max(base.faceNative,layout.face-cut)
if(next===layout.face)return layout
fixes+=1
cutTried={face:layout.face,height:tileHeight}
layout={...layout,face:next,faceHeight:faceHeightOf(next,base.ratio)}
for(const one of live)paintOne(one)
raceFrame(()=>verify(lists))
return layout}
function forget(){const had=layout!==null
layout=null
base=null
tried=[]
tries=0
fixes=0
waits=0
asked=[]
over=0
cutTried=null
return had}
function refit(lists){refits+=1
const live=aliveOf(lists)
if(live.length===0){fitted='no-list'
return fitted}
if(pending){fitted='pending'
return fitted}
if(fitPending)return 'queued'
fitPending=true
raceFrame(()=>{fitPending=false
const list=aliveOf(lists)[0]
if(!list||pending)return
const step=boxWake({box:list.clientWidth??0,height:roomOf(list,windowOf())},base,asked)
asked=step.memory
fitted=step.why
if(step.wake){over=0
remeasure([list])
return}
if(step.why!=='same')return
const room=overflowOf(list.scrollHeight??0,roomOf(list,windowOf()))
if(room<=0){over=0
return}
if(over>=OVER_ASK_LIMIT){fitted='over-stop'
return}
over+=1
fitted='over'
fixes=0
raceFrame(()=>verify(lists))})
return 'frame'}
function remeasure(lists){const all=Array.isArray(lists)?lists:[]
tries=0
fixes=0
waits=0
over=0
cutTried=null
if(all.length===0||pending)return false
pending=true
tries+=1
raceFrame(()=>stepOne(all))
return true}
function clear(){let gone=0
for(const list of Array.from(doc?.querySelectorAll?.(PAGE_SELECTOR)??[])){if(unmark(list))gone+=1}
forget()
return gone}
function unmark(list){if(!list)return false
let touched=false
for(const mark of[VIEW_MARK,PAGE_MARK,STATS_MARK,MEASURE_MARK]){if(list.dataset&&list.dataset[mark]!==undefined){delete list.dataset[mark]
touched=true}}
for(const name of[COLS_VAR,FACE_VAR,FACE_H_VAR,FACE_K_VAR,STATS_W_VAR,BOOSTS_W_VAR]){try{if(list.style?.getPropertyValue?.(name))touched=true
list.style?.removeProperty?.(name)}catch{/* нечего снимать */}}
return touched}
return{ensure,apply,clear,unmark,forget,remeasure,refit,
state:()=>({build:CARD_VIEW_BUILD,
plan:layout?{...layout}:null,base:base?{...base}:null,tried:tried.map((one)=>({...one})),
asked:asked.map((one)=>({...one})),
refits,fitted,over,
want:{...want},
tries,waits,fixes,measures,pending,
styles:Boolean(doc?.getElementById?.(CARD_VIEW_LINK_ID))})}}
