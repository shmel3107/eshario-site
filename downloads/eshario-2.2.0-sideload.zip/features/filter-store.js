import{serializeFilterSet,parseFilterSet} from './filters.js'
import{createCachedProvider} from '../core/storage-provider.js'
export const STORE_KEY='filters.sets'
export const READ_METHOD='filters.read'
export const WRITE_METHOD='filters.write'
export const MAX_SETS=50
export const MAX_BYTES=64*1024
export function nextId(existing){let max=0
for(const set of existing){const match=/^f(\d+)$/.exec(set.id??'')
if(match)max=Math.max(max,Number(match[1]))}
return `f${max + 1}`
}
export const EXPORT_VERSION=1
export function freeName(name,taken){if(!taken.has(normalizeName(name)))return name
for(let n=2;n<1000;n++){const candidate=`${name} (${n})`
if(!taken.has(normalizeName(candidate)))return candidate}
return `${name} (${taken.size + 1})`
}
export function normalizeName(name){return typeof name==='string'?name.trim().toLocaleLowerCase():''
}
export function sanitizeStored(stored){if(!Array.isArray(stored))return[]
return stored.filter((item)=>typeof item==='string'&&item!=='')}
export function createBridgeFilterProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function'){throw new Error('filters: мост недоступен')}
return createCachedProvider({fetch:()=>bridge.request(READ_METHOD),push:(value)=>bridge.request(WRITE_METHOD,value),sanitize:sanitizeStored,fallback:()=>[],onError:opts.onError})}
export function createFilterStore(opts={}){const provider=opts.provider
if(!provider||typeof provider.read!=='function'||typeof provider.write!=='function'){throw new Error('filters: провайдер хранилища недоступен')}
function raw(){try{return sanitizeStored(provider.read())}catch{
return[]}}
function parsed(){const out=[]
for(const[index,json]of raw().entries()){const res=parseFilterSet(json)
if(res.ok&&res.set)out.push({...res.set,index,lost:[...res.unknown,...res.invalid]})}
return out}
const byName=(a,b)=>a.name.localeCompare(b.name)||a.id.localeCompare(b.id)
function persist(list){try{provider.write(list)
return{ok:true,reason:null}}catch(err){return{ok:false,reason:'write-failed',detail:String(err?.message??err)}}}
const store={
list:()=>parsed().sort(byName),
get(id){if(typeof id!=='string'||id==='') return null
return parsed().find((set)=>set.id===id)??null},
count:()=>raw().length,
bytes:()=>JSON.stringify(raw()).length,
problems(){const bad=[]
for(const[index,json]of raw().entries()){const res=parseFilterSet(json)
if(!res.ok)bad.push({index,reason:res.reason})}
return bad},
save(input={}){const name=typeof input.name==='string'?input.name.trim():''
if(name==='') return{ok:false,reason:'name-required'}
const list=raw()
const existing=parsed()
const wanted=typeof input.id==='string'?input.id.trim():''
const target=wanted!==''?existing.find((set)=>set.id===wanted):null
if(wanted!==''&&!target) return{ok:false,reason:'not-found'}
const clash=existing.find((set)=>set.id!==wanted&&normalizeName(set.name)===normalizeName(name))
if(clash) return{ok:false,reason:'name-taken'}
const id=target?target.id:nextId(existing)
const json=serializeFilterSet({id,name,criteria:input.criteria})
const candidate=parseFilterSet(json).set
const next=[...list]
if(target)next[target.index]=json
else next.push(json)
if(next.length>MAX_SETS) return{ok:false,reason:'too-many',limit:MAX_SETS}
const size=JSON.stringify(next).length
if(size>MAX_BYTES) return{ok:false,reason:'too-large',limit:MAX_BYTES,size}
const written=persist(next)
return written.ok?{ok:true,reason:null,set:candidate}:written},
rename(id,name){const set=store.get(id)
if(!set) return{ok:false,reason:'not-found'}
const trimmed=typeof name==='string'?name.trim():''
if(trimmed==='') return{ok:false,reason:'name-required'}
const clash=parsed().find((other)=>other.id!==id&&normalizeName(other.name)===normalizeName(trimmed))
if(clash) return{ok:false,reason:'name-taken'}
const list=raw()
list[set.index]=serializeFilterSet({id:set.id,name:trimmed,criteria:set.criteria})
const written=persist(list)
return written.ok?{ok:true,reason:null}:written},
remove(id){const set=store.get(id)
if(!set) return{ok:false,reason:'not-found'}
const list=raw()
list.splice(set.index,1)
const written=persist(list)
return written.ok?{ok:true,reason:null}:written},
clear(){return persist([])},
exportSets(){const sets=[]
for(const json of raw()){try{sets.push(JSON.parse(json))}catch{
}}
return JSON.stringify({v:EXPORT_VERSION,sets})},
importSets(json,opts={}){const mode=opts.mode==='replace'?'replace':'merge'
const empty={imported:0,skipped:0,renamed:0}
if(typeof json!=='string'||json.trim()===''){return{ok:false,reason:'empty',...empty}}
const text=json.trim().replace(/^```[A-Za-z]*/,'').replace(/```$/,'').trim()
let payload
try{payload=JSON.parse(text)}catch{return{ok:false,reason:'not-json',...empty}}
const incoming=Array.isArray(payload)?payload:payload?.sets
if(!Array.isArray(incoming)) return{ok:false,reason:'no-sets',...empty}
const kept=mode==='replace'?[]:raw()
const existing=mode==='replace'?[]:parsed()
const taken=new Set(existing.map((set)=>normalizeName(set.name)))
const usedIds=new Set(existing.map((set)=>set.id))
let skipped=0
let renamed=0
const next=[...kept]
for(const entry of incoming){const name=typeof entry?.name==='string'?entry.name.trim():''
if(name===''){skipped+=1;continue}
const free=freeName(name,taken)
if(free!==name)renamed+=1
const wanted=typeof entry.id==='string'?entry.id.trim():''
const id=(wanted!==''&&!usedIds.has(wanted))
?wanted
:nextId([...usedIds].map((value)=>({id:value})))
const line=serializeFilterSet({id,name:free,criteria:entry.criteria})
if(!parseFilterSet(line).ok){skipped+=1;continue}
next.push(line)
taken.add(normalizeName(free))
usedIds.add(id)}
if(next.length>MAX_SETS){return{ok:false,reason:'too-many',limit:MAX_SETS,...empty}}
const size=JSON.stringify(next).length
if(size>MAX_BYTES){return{ok:false,reason:'too-large',limit:MAX_BYTES,size,...empty}}
const written=persist(next)
if(!written.ok)return{...written,...empty}
return{ok:true,reason:null,imported:next.length-kept.length,skipped,renamed}}}
return store}
