import{parseRequirement,COMPARE,REQUIREMENT_KEY,KEY_NAMES} from '../automation/sbc-requirements.js'
export const SHAPE_NUM='num'
export const SHAPE_RATING='rating'
export const SHAPE_NAMED='named'
export const SHAPE_QUALITY='quality'
export const SHAPE_FLAG='flag'
const K=REQUIREMENT_KEY
export const CHIP_SHAPE=Object.freeze({
[K.TEAM_RATING]:SHAPE_NUM,[K.TEAM_STAR_RATING]:SHAPE_NUM,
[K.CHEMISTRY_POINTS]:SHAPE_NUM,[K.ALL_PLAYERS_CHEMISTRY_POINTS]:SHAPE_NUM,
[K.NATION_COUNT]:SHAPE_NUM,[K.LEAGUE_COUNT]:SHAPE_NUM,[K.CLUB_COUNT]:SHAPE_NUM,
[K.SAME_NATION_COUNT]:SHAPE_NUM,[K.SAME_LEAGUE_COUNT]:SHAPE_NUM,[K.SAME_CLUB_COUNT]:SHAPE_NUM,
[K.LEGEND_COUNT]:SHAPE_NUM,[K.FIRST_OWNER_PLAYERS_COUNT]:SHAPE_NUM,
[K.PLAYER_COUNT]:SHAPE_NUM,[K.PLAYER_COUNT_COMBINED]:SHAPE_NUM,
[K.NUM_TROPHY_REQUIRED]:SHAPE_NUM,[K.SCOPE]:SHAPE_NUM,
[K.PLAYER_MIN_OVR]:SHAPE_RATING,[K.PLAYER_MAX_OVR]:SHAPE_RATING,[K.PLAYER_EXACT_OVR]:SHAPE_RATING,
[K.NATION_ID]:SHAPE_NAMED,[K.LEAGUE_ID]:SHAPE_NAMED,[K.CLUB_ID]:SHAPE_NAMED,
[K.PLAYER_RARITY]:SHAPE_NAMED,[K.PLAYER_RARITY_GROUP]:SHAPE_NAMED,[K.PLAYER_LEVEL]:SHAPE_NAMED,
[K.PLAYER_QUALITY]:SHAPE_QUALITY,
[K.PLAYER_TRADABILITY]:SHAPE_FLAG})
const RANK=Object.freeze({[K.TEAM_RATING]:0,[K.TEAM_STAR_RATING]:0,
[K.CHEMISTRY_POINTS]:1,[K.ALL_PLAYERS_CHEMISTRY_POINTS]:1})
const RANK_REST=2
const QUALITY_KEYS=Object.freeze({1:'sbcChip.quality.1',2:'sbcChip.quality.2',3:'sbcChip.quality.3'})
const KEY_SAYS_COMPARE=Object.freeze({[K.PLAYER_MIN_OVR]:COMPARE.GREATER,
[K.PLAYER_MAX_OVR]:COMPARE.LOWER,[K.PLAYER_EXACT_OVR]:COMPARE.EXACT})
function compareOf(req){const said=KEY_SAYS_COMPARE[req?.key]
return said===undefined?req?.compare:said}
const EA_NAME_SPLIT=': '
const CHIP_KEY='sbcChip.'
export function nameFromEa(text){if(typeof text!=='string')return null
const at=text.indexOf(EA_NAME_SPLIT)
if(at<=0)return null
const name=text.slice(0,at).trim()
return name===''?null:name}
function signed(compare,value,t){const n=String(value)
if(compare===COMPARE.LOWER)return t('sbcChip.max',{n})
if(compare===COMPARE.EXACT)return t('sbcChip.exact',{n})
return t('sbcChip.min',{n})}
function signedRating(compare,value,t){const n=String(value)
if(compare===COMPARE.LOWER)return t('sbcChip.rating.max',{n})
if(compare===COMPARE.EXACT)return t('sbcChip.rating.exact',{n})
return t('sbcChip.min',{n})}
function times(count,t){return Number.isFinite(Number(count))&&Number(count)>1
?t('sbcChip.times',{count:String(count)}):''}
function wordOf(key,t){const name=KEY_NAMES[key]
if(typeof name!=='string')return null
return t(CHIP_KEY+name)}
function parsed(raw){try{return parseRequirement(raw)}catch{return null}}
function said(text){return typeof text==='string'&&text.trim()!==''?text.trim():null}
function chipFrom(req,word,t){
if(req===null||!Number.isFinite(Number(req.key))||Array.isArray(req.combined))return word
const shape=CHIP_SHAPE[req.key]
if(shape===undefined)return word
const label=wordOf(req.key,t)
if(shape===SHAPE_NAMED){const head=nameFromEa(word)??label
if(head===null)return word
const count=Number.isFinite(Number(req.count))&&Number(req.count)>0?Number(req.count):1
return compareOf(req)===COMPARE.GREATER
?`${head} ${count}`
:`${head} ${signed(compareOf(req),count,t)}`}
if(shape===SHAPE_RATING){const n=signedRating(compareOf(req),req.value,t)
const many=times(req.count,t)
return many===''?`${label} ${n}`:`${n} ${many}`}
if(shape===SHAPE_QUALITY){const tier=QUALITY_KEYS[Number(req.value)]
if(tier===undefined||label===null)return word
return `${label} ${t(tier)}`}
if(shape===SHAPE_FLAG){const untradeable=Number(req.value)===1
const head=untradeable?label:t('sbcChip.PLAYER_TRADABILITY.yes')
if(head===null)return word
const many=times(req.count,t)
return many===''?head:`${head} ${many}`}
if(label===null)return word
return `${label} ${signed(compareOf(req),req.value,t)}`}
export function chipOf(raw,text,t){return chipFrom(parsed(raw),said(text),t)}
export function chipsOf(pairs,t){const list=Array.isArray(pairs)?pairs:[]
const out=[]
for(let at=0;at<list.length;at+=1){const pair=list[at]
const word=said(pair?.text)
const req=parsed(pair?.raw)
let text=null
try{text=chipFrom(req,word,t)}catch{text=word}
if(typeof text!=='string'||text.trim()==='')continue
const rank=req!==null&&RANK[req.key]!==undefined?RANK[req.key]:RANK_REST
out.push({text:text.trim(),hint:word,rank,at})}
out.sort((a,b)=>(a.rank-b.rank)||(a.at-b.at))
return out.map((one)=>({text:one.text,hint:one.hint}))}
export function packChips(widths,space){const list=(Array.isArray(widths)?widths:[]).map(Number)
if(list.length===0)return{shown:0,hidden:0}
const box=Number(space?.box)
const rows=Math.max(1,Math.floor(Number(space?.rows)||1))
const gap=Number.isFinite(Number(space?.gap))?Number(space.gap):0
const more=Number.isFinite(Number(space?.more))?Number(space.more):0
if(!Number.isFinite(box)||box<=0||list.some((one)=>!Number.isFinite(one)))return{shown:list.length,hidden:0}
if(laidRows(list,box,gap,0)<=rows)return{shown:list.length,hidden:0}
for(let n=list.length-1;n>=1;n-=1){if(laidRows(list.slice(0,n),box,gap,more)<=rows)return{shown:n,hidden:list.length-n}}
return{shown:0,hidden:list.length}}
function laidRows(widths,box,gap,extra){const all=extra>0?widths.concat([extra]):widths
if(all.length===0)return 1
let rows=1
let x=0
for(const w of all){if(x===0){x=w
continue}
const need=x+gap+w
if(need<=box){x=need
continue}
rows+=1
x=w}
return rows}
