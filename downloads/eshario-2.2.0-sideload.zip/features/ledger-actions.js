import{DEAL} from '../automation/ledger.js'
export const DEAL_ROWS=5
export const DEAL_KEYS=Object.freeze({[DEAL.BOUGHT]:'ledger.deal.bought',[DEAL.SOLD]:'ledger.deal.sold',[DEAL.QUICK]:'ledger.deal.quick'
})
export const ESTIMATE_MARK='≈'
export const TRADE_CSV_SCHEMA='fut-companion-trades-v1'
export const TRADE_CSV_COLUMNS=Object.freeze(['schema','snapshot_at','seq','at','kind','item','gross_coins','net_coins','estimated'])
export function totalRows(t,totals){if(!totals)return[]
const rows=[{id:'bought',label:t('ledger.bought',{count:totals.bought.count,coins:totals.bought.coins})},{id:'sold',label:`${totals.estimated ? `${ESTIMATE_MARK} `:''}${t('ledger.sold',{count:totals.sold.count,coins:totals.sold.net})}`}]
if(totals.quick.count>0){rows.push({id:'quick',label:t('ledger.quick',{count:totals.quick.count,coins:totals.quick.coins})})}
rows.push({id:'profit',label:`${totals.estimated ? `${ESTIMATE_MARK} `:''}${t('ledger.profit',{coins:totals.profit})}`
})
return rows}
export function dealLine(t,deal){const parts=[t(DEAL_KEYS[deal.kind]??DEAL_KEYS[DEAL.BOUGHT])]
if(deal.item)parts.push(deal.item)
parts.push(`${deal.estimated ? ESTIMATE_MARK:''}${t('ledger.coins',{coins:deal.coins})}`)
if(deal.kind===DEAL.SOLD) parts.push(t('ledger.net',{coins:deal.net}))
return parts.join(' · ')}
export function dealRows(t,totals,limit=DEAL_ROWS){const deals=Array.isArray(totals?.deals)?totals.deals.slice(0,limit):[]
return deals.map((deal)=>({id:String(deal.seq),label:dealLine(t,deal)}))}
export function ledgerText(t,view){const session=view?.session??null
const allTime=view?.allTime??null
if(!allTime||(allTime.bought.count===0&&allTime.sold.count===0&&allTime.quick.count===0)){return t('ledger.empty')}
const lines=[t('ledger.session')]
for(const row of totalRows(t,session))lines.push(row.label);
lines.push('')
lines.push(t('ledger.allTime'))
for(const row of totalRows(t,allTime))lines.push(row.label);
const deals=Array.isArray(allTime.deals)?allTime.deals:[]
if(deals.length>0){lines.push('')
lines.push(t('ledger.deals',{count:deals.length}))
for(const deal of deals)lines.push(dealLine(t,deal))}
if(allTime.estimated){lines.push('')
lines.push(t('ledger.estimatedNote'))}
lines.push(t('tax.unverified'))
return lines.join('\n')}
export function ledgerCsv(totals){const deals=totals?.deals
if(!Number.isFinite(totals?.now)||!Array.isArray(deals)||deals.some((deal)=>!validDeal(deal))){return{ok:false,reason:'invalid-ledger',schema:TRADE_CSV_SCHEMA,rows:0,text:''}}
const rows=deals.slice().sort((a,b)=>a.seq-b.seq).map((deal)=>[TRADE_CSV_SCHEMA,totals.now,deal.seq,deal.at,deal.kind,deal.item??'',deal.coins,deal.net,deal.estimated])
const lines=[TRADE_CSV_COLUMNS,...rows].map((row)=>row.map(csvCell).join(','))
return{ok:true,schema:TRADE_CSV_SCHEMA,rows:rows.length,text:`\uFEFF${lines.join('\r\n')}\r\n`}}
function validDeal(deal){return deal&&typeof deal==='object'&&!Array.isArray(deal)
&&Number.isFinite(deal.seq)&&deal.seq>0&&Number.isFinite(deal.at)
&&Object.values(DEAL).includes(deal.kind)
&&Number.isFinite(deal.coins)&&deal.coins>=0&&Number.isFinite(deal.net)&&deal.net>=0
&&(deal.item===null||typeof deal.item==='string')&&typeof deal.estimated==='boolean'}
function csvCell(value){let text=value===null||value===undefined?'':String(value)
if(typeof value==='string'&&/^[=+\-@\t\r]/.test(text.trimStart()))text=`'${text}`
return`"${text.replaceAll('"','""')}"`}
