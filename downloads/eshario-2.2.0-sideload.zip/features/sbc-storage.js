import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoMark} from '../ui/controls.js'
import{SBC_FEATURE} from './sbc-actions.js'
import{SCREEN_SELECTOR} from '../adapter/storage-screen.js'
import{meterCalls,dayBudgetError,isDayBudgetError,COUNTER_UNAVAILABLE} from './day-budget.js'
export const STORAGE_FEATURE=SBC_FEATURE
export const SAFETY_MS=60_000
export const SUBMIT_SETTLE_MS=SAFETY_MS
export const CLUB_HUB_ROOT='.ut-club-hub-view'
export const STORAGE_TILE='.sbc-storage-tile'
export const BADGE_SELECTOR='[data-fut-storage-badge]'
export const CHIP_SELECTOR='[data-fut-storage-chip]'
export const TOOLS_BAR='[data-fut-card-bar]'
const OTHER_FORM='.other'
const BADGE_MARK='futStorageBadge'
const CHIP_MARK='futStorageChip'
const STORAGE_STYLESHEET=new URL('../ui/sbc-storage.css',import.meta.url).href
const STORAGE_LINK_ID='fut-companion-sbc-storage'
export function freeStorageItems(items){const list=Array.isArray(items)?items:[]
const out=[]
for(const item of list){if(!item||typeof item!=='object')continue
let duplicateId=null
try{duplicateId=item.duplicateId}catch{continue}
if(duplicateId===0)out.push(item)}
return out}
export function clubCopiesAwaited(items){const out=new Set()
for(const item of Array.isArray(items)?items:[]){if(!item||typeof item!=='object')continue
let duplicateId=null
try{duplicateId=item.duplicateId}catch{continue}
if(typeof duplicateId!=='number'||!Number.isFinite(duplicateId)||duplicateId<=0)continue
out.add(String(duplicateId))}
return out}
export const LEAVE_EVENTS=Object.freeze(['ITEM_MOVE','ITEM_DISCARD','ITEM_CLEARSOLD'])
export const STORAGE_PILE='STORAGE'
export function storageGrew(event){const name=event&&typeof event==='object'?event.name:null
return name==='ITEM_MOVE'&&event.to===STORAGE_PILE}
export function storageItemIds(items){const out=new Set()
for(const item of Array.isArray(items)?items:[]){if(!item||typeof item!=='object')continue
let id=null
try{id=item.id}catch{continue}
if(id===null||id===undefined)continue
const text=String(id)
if(text!=='')out.add(text)}
return out}
export function isLeaveEvent(event){const name=event&&typeof event==='object'?event.name:null
if(typeof name!=='string'||!LEAVE_EVENTS.includes(name))return false
return name!=='ITEM_MOVE'||event.to!=='CLUB'}
export function refusedIds(answer,asked){const ids=answer&&typeof answer==='object'&&!Array.isArray(answer)
?answer.itemIds:null
if(!Array.isArray(ids))return null
const moved=new Set()
for(const value of ids){if(value===null||value===undefined)continue
moved.add(String(value))}
const out=[]
for(const item of Array.isArray(asked)?asked:[]){let id=null
try{id=item?.id}catch{id=null}
if(id===null||id===undefined)continue
const text=String(id)
if(!moved.has(text))out.push(text)}
return out}
export function movedCountOf(answer,asked){const refused=refusedIds(answer,asked)
if(refused===null)return null
let named=0
for(const item of Array.isArray(asked)?asked:[]){let id=null
try{id=item?.id}catch{id=null}
if(id!==null&&id!==undefined)named+=1}
return named-refused.length}
export const MOVE_STAGE='storage-move'
export async function moveStorageToClub(req){const market=req?.market??null
if(market===null||typeof market.move!=='function')throw new Error('storage: рынок EA ещё не готов')
const day=req?.day??null
if(!day||typeof day.take!=='function'||typeof day.warm!=='function')throw dayBudgetError(MOVE_STAGE,COUNTER_UNAVAILABLE)
const refusal=await day.warm(1,{market:false})
if(refusal!==null)throw dayBudgetError(MOVE_STAGE,refusal)
return meterCalls(market,day,['move'],{stage:MOVE_STAGE,market:false}).move(req.items,req.pile)}
export function createSbcStorage(deps={}){const doc=deps.doc??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const num=typeof deps.formatNumber==='function'?deps.formatNumber:(value)=>String(value)
const plural=typeof deps.plural==='function'?deps.plural:(base,count,params)=>t(base+OTHER_FORM,params)
const read=typeof deps.read==='function'?deps.read:null
const moveToClub=typeof deps.moveToClub==='function'?deps.moveToClub:null
const now=typeof deps.now==='function'?deps.now:null
const say=typeof deps.say==='function'?deps.say:()=>{}
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const onCount=typeof deps.onCount==='function'?deps.onCount:null
const win=()=>doc?.defaultView??null
const allowed=()=>{if(typeof deps.isActive!=='function')return false
try{return deps.isActive(STORAGE_FEATURE)===true}catch(err){onError(err)
return false}}
let known=null
let knownAt=null
let ranAt=null
let running=false
let pending=false
let hubSeen=false
let screenSeen=false
let waiting=new Set()
let mine=new Set()
let countDue=false
let dirty=false
let rest=null
const counts={runs:0,locked:0,noDoor:0,readFailed:0,empty:0,moves:0,
moveFull:0,movePartial:0,moveNone:0,moveUnknown:0,moveRefused:0,moveNoBudget:0,
returned:0,busy:0,
noClock:0,throttled:0,safetyLocked:0,safetyBusy:0,safetyWoke:0,
leaves:0,leaveOther:0,leaveNoSnapshot:0,leaveMiss:0,leaveNoClock:0,
leaveThrottled:0,leaveLocked:0,leaveBusy:0,leaveWoke:0,
leaveStale:0,
enters:0,enterNoClock:0,enterThrottled:0,enterLocked:0,enterBusy:0,enterWoke:0,shrank:0,
restSettled:0,restStuck:0,
safety:0,passes:0,paints:0,
owedKept:0,owedPaid:0,owedDropped:0,
submits:0,submitNoClock:0,submitLocked:0,submitOwed:0,
owedEarly:0,owedHeld:0,
alarmSet:0,alarmSkipped:0,alarmFired:0,alarmDropped:0,
eats:0,eatEmpty:0,eatNoSnapshot:0,eatMiss:0,eatHit:0,eatGone:0}
let last=null
let owed=null
let owedNotBefore=null
const SUBMIT_REASON='sbc-submitted'
let alarm=null
const clock=()=>{if(now===null)return null
try{const value=now()
return Number.isFinite(value)?value:null}catch(err){onError(err)
return null}}
function setKnown(next){const value=next===null?null:Math.max(0,next)
const changed=known!==value
known=value
knownAt=clock()
if(changed)tellCount()
return known}
function tellCount(){if(onCount===null)return false
if(countDue)return false
countDue=true
soon(()=>{countDue=false
try{onCount()}catch(err){onError(err)}})
return true}
function noteItems(items){if(!Array.isArray(items))return known
setKnown(items.length)
waiting=clubCopiesAwaited(items)
mine=storageItemIds(items)
dirty=false
settleRest(items)
return known}
function settleRest(items){if(rest===null)return
let stuck=false
for(const item of freeStorageItems(items)){let id=null
try{id=item?.id}catch{id=null}
if(id===null||id===undefined)continue
if(rest.ids.has(String(id))){stuck=true
break}}
if(stuck){counts.restStuck+=1
say('storage.returnedPartial',{count:num(rest.moved),total:num(rest.asked)})}
else counts.restSettled+=1
rest=null}
function count(){return known}
function soon(fn){const view=win()
const raf=typeof view?.requestAnimationFrame==='function'?view.requestAnimationFrame:null
const timer=typeof view?.setTimeout==='function'?view.setTimeout:null
const direct=typeof deps.frame==='function'?deps.frame:null
if(!direct&&!raf&&!timer){fn()
return}
let done=false
const go=()=>{if(done)return
done=true
try{fn()}catch(err){onError(err)}}
if(direct){try{direct(go)}catch{/* свой планировщик отказал — остаются кадр и таймер */}}
if(raf){try{raf.call(view,go)}catch{/* кадра не будет — остаётся таймер */}}
if(timer){try{timer.call(view,go,32)}catch{/* и таймера тоже: прогон подождёт следующего повода */}}}
async function run(why){if(running){counts.busy+=1
return{ok:false,reason:'busy'}}
if(!allowed()){counts.locked+=1
return{ok:false,reason:'locked'}}
if(read===null||moveToClub===null){counts.noDoor+=1
return{ok:false,reason:'no-door'}}
running=true
counts.runs+=1
ranAt=clock()
try{let items=null
try{items=await read()}catch(err){counts.readFailed+=1
last={ok:false,reason:'read-failed',why,detail:String(err?.message??err)}
onError(err)
return{ok:false,reason:'read-failed'}}
noteItems(items)
const free=freeStorageItems(items)
if(free.length===0){counts.empty+=1
last={ok:true,reason:'nothing',why,free:0,moved:0}
return{ok:true,reason:'nothing',moved:0}}
counts.moves+=1
let answer=null
try{answer=await moveToClub(free)}catch(err){
if(isDayBudgetError(err)){counts.moveNoBudget+=1
last={ok:false,reason:'move-no-budget',why,free:free.length,detail:String(err?.message??err)}
onError(err)
return{ok:false,reason:'move-no-budget',asked:free.length}}
counts.moveRefused+=1
last={ok:false,reason:'move-refused',why,free:free.length,detail:String(err?.message??err)}
onError(err)
return{ok:false,reason:'move-refused'}}
const moved=movedCountOf(answer,free)
if(moved===null){counts.moveUnknown+=1
last={ok:false,reason:'move-unproven',why,free:free.length}
return{ok:false,reason:'move-unproven'}}
counts.returned+=moved
if(known!==null&&moved>0)setKnown(known-moved)
{const refused=new Set(refusedIds(answer,free)??[])
for(const one of free){let id=null
try{id=one?.id}catch{id=null}
if(id===null||id===undefined)continue
const text=String(id)
if(!refused.has(text))mine.delete(text)}}
if(moved===0){counts.moveNone+=1
last={ok:false,reason:'move-none',why,free:free.length,moved:0}
return{ok:false,reason:'move-none',moved:0,asked:free.length}}
if(moved<free.length){counts.movePartial+=1
rest={ids:new Set(refusedIds(answer,free)??[]),moved,asked:free.length}
last={ok:false,reason:'move-partial',why,free:free.length,moved}
say('storage.returned',{count:num(moved)})
apply()
return{ok:false,reason:'move-partial',moved,asked:free.length}}
counts.moveFull+=1
last={ok:true,reason:null,why,free:free.length,moved}
say('storage.returned',{count:num(moved)})
apply()
return{ok:true,reason:null,moved,asked:free.length}}finally{running=false}}
function left(event){counts.leaves+=1
if(storageGrew(event))grew(event)
if(!isLeaveEvent(event)){counts.leaveOther+=1
return false}
if(known===null){counts.leaveNoSnapshot+=1
return false}
shrink(event)
let hit=false
for(const id of Array.isArray(event?.ids)?event.ids:[]){if(id===null||id===undefined)continue
if(waiting.has(String(id))){hit=true
break}}
if(!hit&&!dirty){counts.leaveMiss+=1
return false}
const stale=!hit
const at=clock()
if(at===null){counts.leaveNoClock+=1
return false}
if(ranAt!==null&&at-ranAt<SAFETY_MS){counts.leaveThrottled+=1
return false}
if(!allowed()){counts.leaveLocked+=1
return false}
if(pending||running){counts.leaveBusy+=1
return false}
counts.leaveWoke+=1
if(stale)counts.leaveStale+=1
pending=true
soon(()=>{pending=false
void run(stale?'club-gone-stale':'club-gone').catch((err)=>onError(err))})
return true}
function grew(event){counts.enters+=1
dirty=true
const at=clock()
if(at===null){counts.enterNoClock+=1
return false}
if(ranAt!==null&&at-ranAt<SAFETY_MS){counts.enterThrottled+=1
return false}
if(!allowed()){counts.enterLocked+=1
return false}
if(pending||running){counts.enterBusy+=1
return false}
counts.enterWoke+=1
pending=true
soon(()=>{pending=false
void run('storage-grew').catch((err)=>onError(err))})
return true}
function submitted(){counts.submits+=1
dirty=true
const at=clock()
if(at===null){counts.submitNoClock+=1
return true}
if(!allowed()){counts.submitLocked+=1
return true}
counts.submitOwed+=1
if(owed===null)owed=SUBMIT_REASON
const ready=at+SUBMIT_SETTLE_MS
if(owedNotBefore===null||owedNotBefore<ready)owedNotBefore=ready
armAlarm(owedNotBefore-at)
return true}
function eaten(ids){counts.eats+=1
const list=Array.isArray(ids)?ids:[]
if(list.length===0){counts.eatEmpty+=1
return 0}
if(mine.size===0){counts.eatNoSnapshot+=1
return 0}
let gone=0
for(const id of list){if(id===null||id===undefined)continue
const text=String(id)
if(!mine.has(text))continue
mine.delete(text)
gone+=1}
if(gone===0){counts.eatMiss+=1
return 0}
counts.eatHit+=1
counts.eatGone+=gone
counts.shrank+=gone
if(known!==null)setKnown(known-gone)
return gone}
function shrink(event){if(mine.size===0)return 0
let gone=0
for(const id of Array.isArray(event?.ids)?event.ids:[]){if(id===null||id===undefined)continue
const text=String(id)
if(!mine.has(text))continue
mine.delete(text)
gone+=1}
if(gone===0)return 0
counts.shrank+=gone
if(known!==null)setKnown(known-gone)
return gone}
function safety(why){counts.safety+=1
const at=clock()
if(at===null){counts.noClock+=1
return false}
if(ranAt!==null&&at-ranAt<SAFETY_MS){counts.throttled+=1
counts.owedKept+=1
if(owed===null)owed=why
armAlarm(SAFETY_MS-(at-ranAt))
return false}
if(!allowed()){counts.safetyLocked+=1
return false}
if(pending||running){counts.safetyBusy+=1
return false}
counts.safetyWoke+=1
pending=true
soon(()=>{pending=false
void run(why).catch((err)=>onError(err))})
return true}
function armAlarm(rest){if(alarm!==null){counts.alarmSkipped+=1
return false}
const view=win()
const timer=typeof view?.setTimeout==='function'?view.setTimeout:null
if(timer===null)return false
const wait=Number.isFinite(rest)&&rest>0?Math.ceil(rest)+1:1
try{alarm=timer.call(view,()=>{
alarm=null
counts.alarmFired+=1
try{payOwed()}catch(err){onError(err)}},wait)}catch(err){onError(err)
alarm=null
return false}
counts.alarmSet+=1
return true}
function dropAlarm(){if(alarm===null)return
const view=win()
try{view?.clearTimeout?.(alarm)}catch(err){onError(err)}
alarm=null
counts.alarmDropped+=1}
function forgetOwed(){if(owed===null)return
if(owed===SUBMIT_REASON){counts.owedHeld+=1
return}
owed=null
owedNotBefore=null
dropAlarm()
counts.owedDropped+=1}
function payOwed(){if(owed===null)return false
if(owedNotBefore!==null){const at=clock()
if(at!==null&&at<owedNotBefore){counts.owedEarly+=1
armAlarm(owedNotBefore-at)
return false}}
if(pending||running){owed=null
owedNotBefore=null
dropAlarm()
counts.owedDropped+=1
return false}
if(!safety(owed))return false
owed=null
owedNotBefore=null
dropAlarm()
counts.owedPaid+=1
return true}
function countText(){return known===null?'?':num(known)}
function mountBadge(root){let tile=null
try{tile=root?.querySelector?.(STORAGE_TILE)??null}catch(err){onError(err)
tile=null}
if(!tile)return null
const existing=tile.querySelector?.(BADGE_SELECTOR)??null
const node=existing??el(doc,'span',{class:'fx-storage-badge',dataset:{[BADGE_MARK]:'1'},
attrs:{'aria-hidden':'false',title:t('storage.badgeHint')}})
if(node.parentNode!==tile)tile.appendChild(node)
const text=countText()
const key=`${text}/${t('storage.badgeHint')}`
if(node.dataset&&node.dataset.futStorageKey===key)return node
if(node.dataset)node.dataset.futStorageKey=key
counts.paints+=1
while(node.firstChild)node.removeChild(node.firstChild)
node.appendChild(logoMark(doc,'fx-storage-mark'))
node.appendChild(el(doc,'span',{class:'fx-storage-badge-value',text}))
return node}
function mountChip(){let root=null
try{root=doc?.querySelector?.(SCREEN_SELECTOR)??null}catch(err){onError(err)
root=null}
if(!root)return null
let bar=null
try{bar=root.querySelector?.(TOOLS_BAR)??null}catch(err){onError(err)
bar=null}
if(!bar){root.querySelector?.(CHIP_SELECTOR)?.remove?.()
return null}
const existing=bar.querySelector?.(CHIP_SELECTOR)??null
const node=existing??el(doc,'span',{class:'fx-storage-chip',dataset:{[CHIP_MARK]:'1'},
attrs:{title:t('storage.badgeHint')}})
if(node.parentNode!==bar)bar.appendChild(node)
const text=known===null?t('storage.chipUnknown'):plural('storage.chip',known,{count:num(known)})
if(node.dataset&&node.dataset.futStorageKey===text)return node
if(node.dataset)node.dataset.futStorageKey=text
counts.paints+=1
node.textContent=text
return node}
function clearAll(){let gone=0
for(const one of Array.from(doc?.querySelectorAll?.(`${BADGE_SELECTOR},${CHIP_SELECTOR}`)??[])){one.remove?.()
gone+=1}
return gone}
function apply(){if(!doc)return{ok:false,reason:'no-doc'}
counts.passes+=1
if(!allowed()){const gone=clearAll()
hubSeen=false
screenSeen=false
forgetOwed()
return{ok:true,reason:'off',cleared:gone}}
let hub=null
try{hub=doc.querySelector?.(CLUB_HUB_ROOT)??null}catch(err){onError(err)
hub=null}
let screen=null
try{screen=doc.querySelector?.(SCREEN_SELECTOR)??null}catch(err){onError(err)
screen=null}
if(hub===null&&screen===null){const gone=clearAll()
hubSeen=false
screenSeen=false
forgetOwed()
return{ok:true,reason:'away',cleared:gone}}
ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,STORAGE_STYLESHEET,STORAGE_LINK_ID)
const badge=hub===null?null:mountBadge(hub)
const chip=screen===null?null:mountChip()
const hubEntered=hub!==null&&!hubSeen
const screenEntered=screen!==null&&!screenSeen
hubSeen=hub!==null
screenSeen=screen!==null
if(hubEntered)safety('club-hub')
if(screenEntered)safety('storage-screen')
if(!hubEntered&&!screenEntered)payOwed()
return{ok:true,reason:null,badge:badge!==null,chip:chip!==null,count:known}}
return{
refresh(){return apply()},
apply,
relabel(){for(const one of Array.from(doc?.querySelectorAll?.(`${BADGE_SELECTOR},${CHIP_SELECTOR}`)??[])){try{delete one.dataset.futStorageKey}catch{/* чужой узел уже ушёл */}}
return apply()},
left,
submitted,
eaten,
run,
count,
noteItems,
state(){return{
build:'STOR-R5',
feature:STORAGE_FEATURE,allowed:allowed(),count:known,
age:known===null||knownAt===null||clock()===null?null:clock()-knownAt,
running,pending,safetyMs:SAFETY_MS,waiting:waiting.size,dirty,snapshot:mine.size,
owed,alarm:alarm!==null,
owedIn:owedNotBefore===null||clock()===null?null:Math.max(0,owedNotBefore-clock()),
rest:rest===null?null:{left:rest.ids.size,moved:rest.moved,asked:rest.asked},
sinceRun:ranAt===null||clock()===null?null:clock()-ranAt,
counts:{...counts},last:last===null?null:{...last},
badge:Boolean(doc?.querySelector?.(BADGE_SELECTOR)),
chip:Boolean(doc?.querySelector?.(CHIP_SELECTOR)),
bar:Boolean(doc?.querySelector?.(`${SCREEN_SELECTOR} ${TOOLS_BAR}`)),
screen:Boolean(doc?.querySelector?.(SCREEN_SELECTOR)),
hub:Boolean(doc?.querySelector?.(CLUB_HUB_ROOT)),
styles:Boolean(doc?.getElementById?.(STORAGE_LINK_ID))}},
dispose(){dropAlarm()
clearAll()}}}
