import{el,logoLink,ensureSbcStripStyles} from '../ui/dom.js'
import{ensureControls} from '../ui/controls.js'
import{squadRatingExact} from '../automation/squad-rating.js'
import{REQUIREMENT_KEY,COMPARE,parseRequirements,needOf,satisfies} from '../automation/sbc-requirements.js'
import{resultModel,costModel} from './sbc-window.js'
import{rewardTextOf} from '../adapter/sbc-set.js'
import{rewardSaleOf} from '../adapter/sbc-hub.js'
import{SBC_FEATURE} from './sbc-actions.js'
import{squadSummaryOf,summaryRightOf,challengeContentOf,challengeDetailsOf,
challengeAwardsOf,setAwardsOf,setChallengeCountOf,rewardImageOf,
squadLiveNumbers,squadFieldRatings,squadFieldSignature,squadFieldSlotPairs,
observeSquadChanges,refreshSquadNumbers,repaintSquadNumbers,frozenKeyOf} from '../adapter/sbc-screen.js'
export const STRIP_MARK='data-fut-sbc-bar'
export const STRIP_KEY='futSbcBar'
export const PANEL_MARK='data-fut-sbc-cut'
export const PANEL_KEY='futSbcCut'
const STRIP_CLASS='fx-sbc-strip'
export const CHIP_CLASS='fx-sbc-chip'
export function solutionFitsField(entry,fieldIds,fieldSignature,storedSignature){if(!entry)return false
if(storedSignature!==''&&fieldSignature===storedSignature)return true
const ids=entry.ids instanceof Set?entry.ids:new Set
const lineup=Array.isArray(entry.result?.lineup)?entry.result.lineup.length:0
if(lineup===0||fieldIds.length!==lineup)return false
const buys=Array.isArray(entry.result?.buys)?entry.result.buys.length:0
let unknown=0
for(const id of fieldIds){if(!ids.has(id))unknown+=1}
return unknown<=buys}
const RATING_KEY=REQUIREMENT_KEY.TEAM_RATING
const CHEMISTRY_KEY=REQUIREMENT_KEY.CHEMISTRY_POINTS
export function requirementPair(parsed,key,have){const rows=(Array.isArray(parsed)?parsed:[])
.filter((req)=>req?.key===key&&!Array.isArray(req?.combined))
.map((req)=>({compare:req.compare,need:needOf(req)}))
.filter((row)=>Number.isFinite(row.need))
if(rows.length===0)return null
if(!Number.isFinite(have))return null
const met=rows.every((row)=>satisfies(row.compare,have,row.need))
const floors=rows.filter((row)=>row.compare!==COMPARE.LOWER)
const shown=(floors.length>0?floors:rows).reduce((top,row)=>(row.need>top?row.need:top),
(floors.length>0?floors:rows)[0].need)
return{need:shown,met,rows:rows.length}}
export function stripModel(input={}){const t=typeof input.t==='function'?input.t:(key)=>key
const coins=typeof input.coins==='function'?input.coins:(value)=>String(value)
const{requirements:parsed}=parseRequirements(input.requirements)
const live=input.live??{rating:null,chemistry:null}
const exact=Number.isFinite(input.exact)?input.exact:null
const wholeRating=exact===null?null:Math.floor(exact)
const eaAgrees=live.rating===null||live.rating===undefined||live.rating===wholeRating
const ratingPair=wholeRating===null?null:requirementPair(parsed,RATING_KEY,wholeRating)
const chemistryPair=requirementPair(parsed,CHEMISTRY_KEY,live.chemistry)
const ratingMark=ratingPair===null?null:!ratingPair.met?'no':eaAgrees?'ok':null
const haveRating=exact===null?null:exact.toFixed(2)
const rating=ratingPair===null?null:{label:t('sbcStrip.rating'),
value:t('sbcStrip.pair',{have:haveRating,need:ratingPair.need}),
mark:ratingMark,
title:eaAgrees?t('sbcStrip.ratingTitle',{have:haveRating,need:ratingPair.need})
:t('sbcStrip.ratingStale',{have:haveRating,need:ratingPair.need,ea:live.rating})}
const money=moneyModel({t,coins,solution:input.solution})
const chemTitle=t('sbcStrip.chemistryTitle',{have:live.chemistry,need:chemistryPair===null?null:chemistryPair.need})
const chemistryStale=!eaAgrees||input.chemistryFresh===false
const chemistry=chemistryPair===null?null:{label:t('sbcStrip.chemistry'),
value:chemistryStale?t('sbcStrip.pairStale',{need:chemistryPair.need})
:t('sbcStrip.pair',{have:live.chemistry,need:chemistryPair.need}),
mark:chemistryStale?null:chemistryPair.met?'ok':'no',
title:chemistryStale?t('sbcStrip.chemistryStale',{need:chemistryPair.need,ea:live.chemistry})
:money.chemNote===null?chemTitle:chemTitle+' '+money.chemNote}
const hides=[]
if(rating!==null)hides.push(HIDE_RATING)
if(chemistry!==null)hides.push(HIDE_CHEMISTRY)
const blank={ok:false,reason:null,hides:'',rating:null,chemistry:null,cost:null,reward:null,rewardless:false,hint:null}
if(hides.length===0&&(parsed.some((req)=>req?.key===RATING_KEY)||parsed.some((req)=>req?.key===CHEMISTRY_KEY))){
return{...blank,reason:'no-live-numbers'}}
const awards=Array.isArray(input.awards)?input.awards:[]
const setAwards=Array.isArray(input.setAwards)?input.setAwards:[]
const setTotal=Number.isSafeInteger(input.setTotal)&&input.setTotal>0?input.setTotal:null
const fromSet=awards.length===0&&setTotal===1&&setAwards.length>0
const shown=fromSet?setAwards:awards
return{ok:true,reason:null,hides:hides.join(' '),rating,chemistry,cost:money.cost,
reward:rewardModel({t,awards:shown,fromSet,textOf:input.rewardTextOf,imageOf:input.rewardImageOf}),
rewardless:shown.length===0,
hint:input.solution?null:t('sbcStrip.hint')}}
export function rewardModel(input={}){const t=typeof input.t==='function'?input.t:(key)=>key
const textOf=typeof input.textOf==='function'?input.textOf:()=>null
const imageOf=typeof input.imageOf==='function'?input.imageOf:()=>null
const awards=Array.isArray(input.awards)?input.awards:[]
if(awards.length===0)return null
const names=[]
for(const award of awards){const said=textOf(award)
names.push(typeof said==='string'&&said.trim()!==''?said.trim():null)}
const first=names[0]
if(first===null)return null
const rest=names.length-1
const value=rest>0?t('sbcStrip.rewardMore',{name:first,count:rest}):first
let image=null
try{image=imageOf(awards[0])}catch{image=null}
const listed=names.filter((one)=>one!==null)
let sale=null
try{sale=rewardSaleOf(awards[0])}catch{sale=null}
const title=listed.length>1?t('sbcStrip.rewardTitle',{list:listed.join(' · ')}):first
return{label:t('sbcStrip.reward'),value,image:typeof image==='string'&&image!==''?image:null,
sale:sale==='yes'||sale==='no'||sale==='coins'?sale:null,
title:input.fromSet===true?title+' · '+t('sbcStrip.rewardWholeSet'):title}}
const HIDE_RATING='rating'
const HIDE_CHEMISTRY='chemistry'
function moneyModel(input={}){const{t,coins,solution}=input
const result=solution?.result??null
const none=t('sbcStrip.none')
const chem=(answer)=>(typeof answer?.chemistry?.note==='string'&&answer.chemistry.note!==''?answer.chemistry.note:null)
if(!result||result.ok!==true){return{chemNote:null,
cost:{label:t('sbcStrip.cost'),value:none,paren:null,muted:true,title:t('sbcStrip.noSolution')}}}
const model=resultModel({t,result,live:null})
const cost=costModel({result})
if(cost===null){return{chemNote:chem(model),
cost:{label:t('sbcStrip.cost'),value:none,paren:null,muted:true,title:t('sbcStrip.notCounted')}}}
const parts=[t('sbcStrip.costUntradable',{value:coins(cost.untradable)}),
t('sbcStrip.costTradable',{value:coins(cost.tradable)})]
if(cost.buys>0)parts.push(t('sbcStrip.costBuys',{count:cost.buys,value:coins(cost.spend)}))
if(cost.unpriced>0)parts.push(t('sbcStrip.costUnpriced',{unknown:cost.unpriced}))
if(cost.mine>0)parts.push(t('sbcStrip.costMine',{mine:cost.mine}))
return{chemNote:chem(model),
cost:{label:t('sbcStrip.cost'),value:coins(cost.total),
paren:t('sbcStrip.costParen',{value:coins(cost.real)}),muted:false,
title:t('sbcStrip.costTitle')+' '+parts.join(' · ')}}}
export const CHIP_MARK='data-fut-sbc-chip'
const CHIP_MUTED_MARK='data-fut-sbc-chip-muted'
export const CHIP_SALE_MARK='data-fut-sbc-chip-sale'
const CHIP_PAIR_MARK='data-fut-sbc-mark'
export const STRIP_BUILD='SBW7B-1'
export function chipNode(doc,name,chip){const line=[]
if(typeof chip.image==='string'&&chip.image!==''){line.push(el(doc,'img',{class:'fx-sbc-chip-icon',
attrs:{src:chip.image,alt:'',loading:'lazy'},
on:{error:(event)=>{const node=event?.currentTarget??event?.target
try{node?.remove?.()}catch{/* узел уже снят */}}}}))}
line.push(el(doc,'span',{class:'fx-sbc-chip-value',text:chip.value},
typeof chip.paren==='string'&&chip.paren!==''
?[el(doc,'span',{class:'fx-sbc-chip-paren',text:chip.paren})]:[]))
if(chip.mark==='ok'||chip.mark==='no'){const знак=el(doc,'span',{class:'fx-sbc-tick',
text:chip.mark==='ok'?'✓':'✕'})
знак.setAttribute(CHIP_PAIR_MARK,chip.mark)
line.push(знак)}
const labelParts=[el(doc,'span',{class:'fx-sbc-chip-word',text:chip.label})]
const parts=[el(doc,'span',{class:'fx-sbc-chip-label'},labelParts),
el(doc,'span',{class:'fx-sbc-chip-line'},line)]
const attrs={title:chip.title}
attrs[CHIP_MARK]=name
if(chip.muted===true)attrs[CHIP_MUTED_MARK]='1'
if(chip.sale==='yes'||chip.sale==='no'||chip.sale==='coins')attrs[CHIP_SALE_MARK]=chip.sale
return el(doc,'span',{class:CHIP_CLASS,attrs},parts)}
export function chipMarkNode(doc,linkClass){return el(doc,'span',{class:CHIP_CLASS+' fx-sbc-mark'},
[el(doc,'span',{class:'fx-sbc-chip-label'}),
el(doc,'span',{class:'fx-sbc-chip-line'},[logoLink(doc,linkClass)])])}
export function createSbcStrip(deps={}){const doc=deps.doc??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const coins=typeof deps.coins==='function'?deps.coins:(value)=>String(value)
const isActiveOf=typeof deps.isActive==='function'?deps.isActive:()=>true
const isActive=()=>isActiveOf(SBC_FEATURE)===true
const frozen=deps.frozen??null
const floatRating=typeof deps.floatRating==='boolean'?deps.floatRating:null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let strip=null
let panel=null
let rewardBuilt=false
let last=null
let watch={dispose(){}}
let watched=null
const stats={applies:0,paints:0,skips:0,cuts:0,uncuts:0,holds:0}
let fingerprint=null
let reason=null
function unmountStrip(){if(strip===null)return
try{delete strip.bar.dataset[STRIP_KEY]}catch{/* узел уже чужой */}
try{strip.node.remove()}catch{/* узел уже снят */}
strip=null
fingerprint=null}
function stripNode(model){const chips=[['rating',model.rating],['chemistry',model.chemistry],
['cost',model.cost],['reward',model.reward]]
.filter((pair)=>pair[1]!==null&&pair[1]!==undefined)
.map((pair)=>chipNode(doc,pair[0],pair[1]))
const kids=[chipMarkNode(doc,'fx-sbc-strip-mark')]
for(const chip of chips)kids.push(chip)
return el(doc,'div',{class:STRIP_CLASS},kids)}
function printOf(model){return[model.hides,model.rating?.value,model.rating?.mark,
model.chemistry?.value,model.chemistry?.mark,
model.cost?.value,model.cost?.paren,model.cost?.muted,
model.reward?.value,model.reward?.image,model.reward?.sale].join('|')}
function paint(model,bar,right){const print=printOf(model)
if(strip!==null&&strip.bar===bar&&print===fingerprint){stats.skips+=1
return}
const node=stripNode(model)
if(strip!==null&&strip.bar===bar){strip.node.replaceWith(node)
strip.node=node}
else{unmountStrip()
right.appendChild(node)
strip={bar,right,node}}
bar.dataset[STRIP_KEY]=model.hides
fingerprint=print
stats.paints+=1}
const WINDOW_SELECTOR='[data-fut-sbc-window]'
function unmountPanel(){if(panel===null)return
try{delete panel.dataset[PANEL_KEY]}catch{/* узел уже чужой */}
panel=null
stats.uncuts+=1}
function applyPanel(content){const block=challengeDetailsOf(content)
if(block===null){unmountPanel()
return}
const alive=hasWindow(content)
if(!rewardBuilt||!alive){unmountPanel()
return}
if(panel!==null&&panel!==block)unmountPanel()
if(panel===block)return
block.dataset[PANEL_KEY]='1'
panel=block
stats.cuts+=1}
function hasWindow(content){if(content===null||typeof content.querySelector!=='function')return false
try{return content.querySelector(WINDOW_SELECTOR)!==null}catch{return false}}
const БЕЗ_ЗАМКА={squad:null,signature:null,chemistryFresh:true}
let refreshed=БЕЗ_ЗАМКА
const numbers={calls:0,rating:false,chemistry:false,reason:null,stale:false,
paint:0,painted:false,paintWhy:null}
function freshenNumbers(squad,live,whole,controller){let signature=null
try{signature=squadFieldSignature(squad).signature}catch{signature=null}
const тоЖеПоле=refreshed.squad===squad&&refreshed.signature===signature
if(!тоЖеПоле){numbers.calls=0
numbers.rating=false
numbers.chemistry=false
numbers.reason=null
numbers.paint=0
numbers.painted=false
numbers.paintWhy=null}
if(тоЖеПоле){numbers.stale=!refreshed.chemistryFresh
return{live,chemistryFresh:refreshed.chemistryFresh}}
const disagrees=whole!==null&&live.rating!==null
&&live.rating!==undefined&&live.rating!==whole
if(!disagrees){numbers.stale=false
return{live,chemistryFresh:true}}
let said={ok:false,rating:false,chemistry:false,reason:'refuse-threw'}
try{said=refreshSquadNumbers(squad)}catch{/* чужая дверь падать нам не даёт */}
numbers.calls+=1
numbers.rating=said.rating===true
numbers.chemistry=said.chemistry===true
numbers.reason=said.reason
refreshed={squad,signature,chemistryFresh:said.chemistry===true}
numbers.stale=!refreshed.chemistryFresh
if(said.ok===true){let paint={ok:false,reason:'refuse-threw',steps:0}
try{paint=repaintSquadNumbers(controller,squad)}catch{/* её вид падать нам не даёт */}
numbers.paint+=1
numbers.painted=paint.ok===true
numbers.paintWhy=paint.reason}
return{live:squadLiveNumbers(squad),chemistryFresh:refreshed.chemistryFresh}}
function readModel(challenge,set,controller){const squad=challenge?.squad??null
let live=squadLiveNumbers(squad)
const ratings=squadFieldRatings(squad)
const exact=squadRatingExact({field:ratings,float:floatRating})
const свежие=freshenNumbers(squad,live,exact===null?null:Math.floor(exact),controller)
live=свежие.live
let requirements=[]
try{requirements=Array.isArray(challenge?.eligibilityRequirements)?challenge.eligibilityRequirements:[]}catch{requirements=[]}
const win=doc?.defaultView??null
return stripModel({t,coins,requirements,exact,live,chemistryFresh:свежие.chemistryFresh,
solution:solutionOf(challenge,squad),
awards:challengeAwardsOf(challenge),
setAwards:setAwardsOf(set),setTotal:setChallengeCountOf(set),
rewardTextOf:(award)=>rewardTextOf(win,award),
rewardImageOf:(award)=>rewardImageOf(win,award)})}
function solutionOf(challenge,squad){if(frozen===null||typeof frozen.find!=='function')return null
const key=frozenKeyOf(challenge)
if(key===null)return null
const entry=frozen.find(key,squad)
if(entry===null||entry===undefined)return null
const fieldIds=squadFieldSlotPairs(squad).map((pair)=>String(pair[1]))
const signature=squadFieldSignature(squad).signature
return solutionFitsField(entry,fieldIds,signature,typeof entry.signature==='string'?entry.signature:'')?entry:null}
function стили(){ensureControls(doc)
ensureSbcStripStyles(doc)}
function apply(capture){if(!doc||!capture?.root)return
stats.applies+=1
try{
if(!isActive()){unmount()
reason='off'
return}
last=capture
const content=challengeContentOf(capture.root)
const bar=squadSummaryOf(capture.root)
if(bar===null){
const why=capture.root?.isConnected===false?'root-gone':'not-found'
if(strip!==null&&strip.bar?.isConnected===true){stats.holds+=1
reason='bar-held:'+why}
else{unmountStrip()
rewardBuilt=false
reason='no-bar:'+why}}
else{const right=summaryRightOf(bar)
const model=readModel(capture.challenge,capture.set??null,capture.controller??null)
reason=model.reason
rewardBuilt=model.ok===true&&right!==null&&(model.reward!==null||model.rewardless===true)
if(right===null){unmountStrip()
reason='no-right'}
else if(!model.ok)unmountStrip()
else{стили()
paint(model,bar,right)}}
if(content===null)unmountPanel()
else{стили()
applyPanel(content)}
watchSquad(capture.challenge?.squad??null)}
catch(err){onError(err)}}
function watchSquad(squad){if(squad===null||squad===undefined||squad===watched)return
watch.dispose()
watched=squad
watch=observeSquadChanges(squad,()=>refresh())}
function refresh(){if(last===null)return
try{apply(last)}catch(err){onError(err)}}
function unmount(){unmountStrip()
unmountPanel()
rewardBuilt=false}
function dispose(){watch.dispose()
watch={dispose(){}}
watched=null
unmount()
last=null
refreshed=БЕЗ_ЗАМКА}
function state(){return{build:STRIP_BUILD,ok:strip!==null,reason,mark:STRIP_MARK,print:fingerprint,
applies:stats.applies,paints:stats.paints,skips:stats.skips,holds:stats.holds,
numbers:{calls:numbers.calls,rating:numbers.rating,chemistry:numbers.chemistry,
reason:numbers.reason,chemStale:numbers.stale,
paint:numbers.paint,painted:numbers.painted,paintWhy:numbers.paintWhy},
cut:{mounted:panel!==null,mark:PANEL_MARK,reward:rewardBuilt,
cuts:stats.cuts,uncuts:stats.uncuts}}}
return{apply,refresh,dispose,state}}
export const SHARED_HANDS=Object.freeze(['apply','refresh','dispose'])
export function withStrip(windowSurface,strip){if(!windowSurface||typeof windowSurface!=='object')return windowSurface
if(!strip||typeof strip!=='object')return windowSurface
const out={}
for(const name of Object.keys(windowSurface)){const hand=windowSurface[name]
out[name]=typeof hand==='function'?(...args)=>hand.apply(windowSurface,args):hand}
for(const name of SHARED_HANDS){const first=windowSurface[name]
const second=strip[name]
if(typeof second!=='function')continue
out[name]=(...args)=>{let answer
if(typeof first==='function')answer=first.apply(windowSurface,args)
try{second.apply(strip,args)}catch{/* полоса своё падение уже записала */}
return answer}}
return out}
