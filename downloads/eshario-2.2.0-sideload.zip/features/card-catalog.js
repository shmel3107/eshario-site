import{manifestUrl,futggBlobUrl,currentGame,MANIFEST_TTL_MS} from './futgg.js'
import{seasonOf,seasonFits} from '../adapter/season.js'
export const CATALOG_SCHEMA=1
export const CATALOG_SHARDS=16
export const MAX_CATALOG_CARDS=40_000
export const POS_NONE=0
export const POS_PRIMARY=1
export const POS_FULL=2
export const UNKNOWN=-1
const I_RATING=0
const I_RARITY=1
const I_LEAGUE=2
const I_NATION=3
const I_TEAM=4
const I_POSMODE=5
const I_POS=6
const IDENTITY_INDEX={league:I_LEAGUE,nation:I_NATION,team:I_TEAM}
export function shardOf(definitionId){return definitionId%CATALOG_SHARDS}
export function definitionOf(item){let definitionId=null
let rating=null
try{definitionId=positive(item?.definitionId??item?.defId)
rating=ratingOf(item?.rating)}catch{return null}
if(definitionId===null||rating===null)return null
let rareflag=UNKNOWN
let leagueId=UNKNOWN
let nationId=UNKNOWN
let teamId=UNKNOWN
let positions=[]
let positionMode=POS_NONE
try{rareflag=count(item?.rareflag)
leagueId=positive(item?.leagueId)??UNKNOWN
nationId=positive(item?.nationId)??UNKNOWN
teamId=positive(item?.teamId)??UNKNOWN
positions=positionList(item?.possiblePositions)
if(positions.length>0)positionMode=POS_FULL
else{const primary=positionCode(item?.preferredPosition)
if(primary!==null){positions=[primary]
positionMode=POS_PRIMARY}}}catch{
}
return{definitionId,rating,rareflag,leagueId,nationId,teamId,positions,positionMode}}
function emptyRecord(){return[0,UNKNOWN,UNKNOWN,UNKNOWN,UNKNOWN,POS_NONE]}
export function mergeRecord(current,next,live=false){const record=Array.isArray(current)?current.slice():emptyRecord()
let changed=false
let conflicts=0
const conflictsBy={rating:0,rarity:0,league:0,nation:0,team:0}
const put=(index,value,absent,name)=>{if(value===absent)return
const was=record[index]
if(was===absent){record[index]=value
changed=true
return}
if(was===value)return
conflicts+=1
conflictsBy[name]+=1
if(live){record[index]=value
changed=true}}
put(I_RATING,ratingOf(next?.rating)??0,0,'rating')
put(I_RARITY,count(next?.rareflag),UNKNOWN,'rarity')
put(I_LEAGUE,positive(next?.leagueId)??UNKNOWN,UNKNOWN,'league')
put(I_NATION,positive(next?.nationId)??UNKNOWN,UNKNOWN,'nation')
put(I_TEAM,positive(next?.teamId)??UNKNOWN,UNKNOWN,'team')
const mode=next?.positionMode??POS_NONE
const list=positionList(next?.positions)
const richer=mode>record[I_POSMODE]||(mode===record[I_POSMODE]&&live)
if(mode!==POS_NONE&&list.length>0&&richer){const before=record.slice(I_POS).join(',')
if(before!==list.join(',')||record[I_POSMODE]!==mode){record.length=I_POS
for(const code of list)record.push(code)
record[I_POSMODE]=mode
changed=true}}
return{record,changed,conflicts,conflictsBy}}
export function readRecord(record){if(!Array.isArray(record)||record.length<I_POS)return null
const rating=record[I_RATING]
const positions=record.slice(I_POS).filter((code)=>positionCode(code)!==null)
return{rating:rating>0?rating:null,
rareflag:record[I_RARITY]===UNKNOWN?null:record[I_RARITY],
leagueId:record[I_LEAGUE]===UNKNOWN?null:record[I_LEAGUE],
nationId:record[I_NATION]===UNKNOWN?null:record[I_NATION],
teamId:record[I_TEAM]===UNKNOWN?null:record[I_TEAM],
positions,positionMode:record[I_POSMODE]??POS_NONE}}
export function encodeShard(entries,season=null){const cards={}
for(const[id,record]of entries??[])cards[id]=record
const out={v:CATALOG_SCHEMA,cards}
if(Number.isSafeInteger(season))out.s=season
return out}
export function decodeShard(raw,season=null){const out=[]
if(!raw||typeof raw!=='object'||raw.v!==CATALOG_SCHEMA)return out
if(!seasonFits(raw.s,season))return out
const cards=raw.cards
if(!cards||typeof cards!=='object')return out
for(const key of Object.keys(cards)){const id=positive(Number(key))
const record=cards[key]
if(id===null||!Array.isArray(record)||record.length<I_POS)continue
if(!record.every((value)=>Number.isSafeInteger(value)))continue
out.push([id,record])}
return out}
export function createCardCatalog(deps={}){const storage=deps.storage
const schedule=typeof deps.schedule==='function'?deps.schedule:(fn)=>{fn()}
const now=typeof deps.now==='function'?deps.now:()=>0
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const seasonNow=typeof deps.season==='function'?deps.season:()=>seasonOf()
const shards=[]
for(let shard=0;shard<CATALOG_SHARDS;shard+=1)shards.push(new Map())
const dirty=new Set()
let universe=null
let flushing=false
let loaded=false
let loading=false
let size=0
let revision=0
const stats={notes:0,seeded:0,base:0,refused:0,conflicts:0,writes:0,lastWriteAt:null}
const liveSeen=new Set()
const conflictNotes={rating:0,rarity:0,league:0,nation:0,team:0}
const everyRecord=function*(){for(const shard of shards)yield*shard.values()}
const touch=(definitionId)=>{if(loading)return
dirty.add(shardOf(definitionId))
if(flushing)return
flushing=true
schedule(step)}
function step(){const next=dirty.values().next()
if(next.done){flushing=false
return}
const shard=next.value
dirty.delete(shard)
try{const result=storage?.write?.(shard,encodeShard(shards[shard],seasonNow()))
stats.writes+=1
stats.lastWriteAt=now()
if(result&&typeof result.catch==='function')result.catch(onError)}catch(err){onError(err)}
schedule(step)}
function apply(definition,live){if(!definition)return false
const id=definition.definitionId
const bucket=shards[shardOf(id)]
const current=bucket.get(id)
if(current===undefined&&size>=MAX_CATALOG_CARDS){stats.refused+=1
return false}
const{record,changed,conflicts,conflictsBy}=mergeRecord(current,definition,live)
stats.conflicts+=conflicts
if(conflicts>0){for(const name of Object.keys(conflictsBy))conflictNotes[name]+=conflictsBy[name]}
if(!changed)return false
if(current===undefined)size+=1
revision+=1
bucket.set(id,record)
touch(id)
return true}
return{
note(item){stats.notes+=1
let id=null
try{id=positive(item?.definitionId??item?.defId)}catch{return false}
if(id!==null&&liveSeen.has(id)&&complete(shards[shardOf(id)].get(id)))return false
const definition=definitionOf(item)
if(definition===null)return false
liveSeen.add(definition.definitionId)
return apply(definition,true)},
noteAll(items){let added=0
for(const item of Array.isArray(items)?items:[]){if(this.note(item))added+=1}
return added},
seedRatings(list){let added=0
for(const entry of Array.isArray(list)?list:[]){const id=positive(entry?.id)
const rating=ratingOf(entry?.rating)
if(id===null||rating===null)continue
if(apply({definitionId:id,rating,rareflag:UNKNOWN,leagueId:UNKNOWN,nationId:UNKNOWN,teamId:UNKNOWN,positions:[],positionMode:POS_NONE},false))added+=1}
stats.seeded+=added
return added},
seedPositions(lane,from=0,to=Number.MAX_SAFE_INTEGER){let added=0
const ids=Array.isArray(lane?.ids)?lane.ids:[]
const positions=Array.isArray(lane?.positions)?lane.positions:[]
const end=Math.min(to,ids.length)
for(let i=Math.max(0,from);i<end;i+=1){const id=positive(ids[i])
const code=positionCode(positions[i])
if(id===null||code===null)continue
if(apply({definitionId:id,rating:0,rareflag:UNKNOWN,leagueId:UNKNOWN,nationId:UNKNOWN,teamId:UNKNOWN,positions:[code],positionMode:POS_PRIMARY},false))added+=1}
stats.seeded+=added
return added},
seedAttributes(list){let added=0
for(const definition of Array.isArray(list)?list:[]){if(definition===null||definition===undefined)continue
if(apply(definition,false))added+=1}
stats.seeded+=added
stats.base+=added
return added},
setUniverse(ids){universe=Array.isArray(ids)&&ids.length>0?ids:null
return universe===null?0:universe.length},
get(definitionId){const id=positive(definitionId)
return id===null?null:readRecord(shards[shardOf(id)].get(id))},
revision(){return revision},
unknownIds(limit){const out=[]
const cap=Number.isSafeInteger(limit)&&limit>0?limit:0
if(universe===null||cap===0)return out
for(const id of universe){if(out.length>=cap)break
const record=shards[shardOf(id)].get(id)
if(record===undefined||record[I_RARITY]===UNKNOWN)out.push(id)}
return out},
byIdentity(field,wanted){const index=IDENTITY_INDEX[field]
const out=new Map()
if(index===undefined)return out
const keep=new Set()
for(const value of wanted??[]){if(Number.isSafeInteger(value)&&value>0)keep.add(value)}
if(keep.size===0)return out
for(const bucket of shards){for(const[id,record]of bucket){const value=record[index]
const rating=record[I_RATING]
if(rating<=0||!keep.has(value))continue
const list=out.get(value)
if(list===undefined)out.set(value,[[id,rating]])
else list.push([id,rating])}}
return out},
byRarity(){const out=new Map()
for(const bucket of shards){for(const[id,record]of bucket){const rarity=record[I_RARITY]
const rating=record[I_RATING]
if(rarity===UNKNOWN||rating<=0)continue
const list=out.get(rarity)
if(list===undefined)out.set(rarity,[[id,rating]])
else list.push([id,rating])}}
return out},
async load(){loading=true
const season=seasonNow()
try{await Promise.all(shards.map(async(_bucket,shard)=>{try{for(const[id,record]of decodeShard(await storage?.read?.(shard),season)){if(shardOf(id)!==shard)continue
const stored=readRecord(record)
if(stored===null)continue
apply({definitionId:id,rating:stored.rating??0,rareflag:stored.rareflag??UNKNOWN,
leagueId:stored.leagueId??UNKNOWN,nationId:stored.nationId??UNKNOWN,teamId:stored.teamId??UNKNOWN,
positions:stored.positions,positionMode:stored.positionMode},false)}}catch(err){onError(err)}}))}finally{loading=false}
loaded=true
return size},
state(){const byRarity={}
let rated=0
let primaryOnly=0
let fullPositions=0
let knownRarity=0
let knownNation=0
let knownLeague=0
let knownTeam=0
for(const record of everyRecord()){if(record[I_RATING]>0)rated+=1
if(record[I_POSMODE]===POS_PRIMARY)primaryOnly+=1
else if(record[I_POSMODE]===POS_FULL)fullPositions+=1
if(record[I_NATION]!==UNKNOWN)knownNation+=1
if(record[I_LEAGUE]!==UNKNOWN)knownLeague+=1
if(record[I_TEAM]!==UNKNOWN)knownTeam+=1
const rarity=record[I_RARITY]
if(rarity===UNKNOWN)continue
knownRarity+=1
byRarity[rarity]=(byRarity[rarity]??0)+1}
const universeSize=universe===null?null:universe.length
let unknown=null
if(universe!==null){unknown=0
for(const id of universe){const record=shards[shardOf(id)].get(id)
if(record===undefined||record[I_RARITY]===UNKNOWN)unknown+=1}}
return{schema:CATALOG_SCHEMA,season:seasonNow(),size,loaded,revision,rated,knownRarity,byRarity,
knownNation,knownLeague,knownTeam,
live:liveSeen.size,conflictsBy:{...conflictNotes},
positions:{primaryOnly,full:fullPositions},universe:universeSize,unknown,
pendingShards:dirty.size,...stats}}}}
export function createCardLane(options={}){const fetchImpl=options.fetch
if(typeof fetchImpl!=='function')throw new Error('card-lane: нужен fetch')
const gameNow=()=>options.game??currentGame()
const ttl=Number.isFinite(options.manifestTtlMs)&&options.manifestTtlMs>0?options.manifestTtlMs:MANIFEST_TTL_MS
let cached=null
let inFlight=null
const at=()=>(typeof options.clock?.now==='function'?options.clock.now():0)
const json=async(url)=>{const response=await fetchImpl(url)
if(!response||typeof response.status!=='number')throw new Error('bad-response')
if(response.status<200||response.status>=300)throw new Error(`http-${response.status}`)
return response.json()}
const load=async()=>{const game=gameNow()
const manifest=await json(manifestUrl(game))
const version=manifest?._version
if(cached&&version!==undefined&&cached.version===version){cached={...cached,at:at()}
return cached.lane}
const url=futggBlobUrl(manifest,'player-gg-ratings',game)
if(url===null)throw new Error('bad-manifest')
cached={version,lane:parseCardLane(await json(url)),at:at()}
return cached.lane}
return{async read(){const stamp=at()
if(cached&&stamp-cached.at<ttl)return cached.lane
if(inFlight)return inFlight
const work=load().catch(()=>(cached?cached.lane:emptyLane()))
inFlight=work.finally(()=>{inFlight=null})
return inFlight}}}
export function parseCardLane(raw){if(!raw||typeof raw!=='object')return emptyLane()
const first=positive(raw.id0)
const deltas=raw.d
const codes=raw.pos
if(first===null||!Array.isArray(deltas)||!Array.isArray(codes))return emptyLane()
if(codes.length!==deltas.length+1)return emptyLane()
const ids=[first]
let id=first
for(const delta of deltas){if(!Number.isSafeInteger(delta)||delta<=0)return emptyLane()
id+=delta
ids.push(id)}
return{ids,positions:codes.map((code)=>(positionCode(code)===null?UNKNOWN:code))}}
function emptyLane(){return{ids:[],positions:[]}}
function complete(record){return Array.isArray(record)
&&record[I_RATING]>0
&&record[I_RARITY]!==UNKNOWN
&&record[I_LEAGUE]!==UNKNOWN
&&record[I_NATION]!==UNKNOWN
&&record[I_TEAM]!==UNKNOWN
&&record[I_POSMODE]===POS_FULL}
function positionCode(value){return Number.isSafeInteger(value)&&value>=0&&value<=27?value:null}
function positionList(value){if(!Array.isArray(value))return[]
const out=[]
for(const raw of value){const code=positionCode(raw)
if(code!==null&&!out.includes(code))out.push(code)}
return out}
function ratingOf(value){return Number.isSafeInteger(value)&&value>=1&&value<=99?value:null}
function count(value){return Number.isSafeInteger(value)&&value>=0?value:UNKNOWN}
function positive(value){const n=typeof value==='string'&&/^\d+$/.test(value.trim())?Number(value):value
return Number.isSafeInteger(n)&&n>0?n:null}
