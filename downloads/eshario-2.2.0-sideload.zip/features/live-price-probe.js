import{isUntradableSource} from './futgg.js'
import{stepFrom} from './price-ladder.js'
import{toleranceFor,priceLawLimit,withinPriceLaw} from '../automation/auto-buy.js'
import{futureRungsOf} from '../automation/card-value.js'
import{DAY_BUDGET_REFUSAL} from './day-budget.js'
import{SEARCH_HOUR_REFUSAL} from './head-counters.js'
export const LIVE_TTL_MS=10*60*1000
export const TOP_STEP_RATING=89
const QUEUE_LIMIT=12
export const TAIL_PRICE_FACTOR=2
export const UNKNOWN_LIMIT=3
export const UNKNOWN_REST_MS=60_000
export const BUY_EMPTY_TTL_MS=60_000
export const OVER_REFERENCE='over-reference'
export const CARD_SILENCE=new Set(['no-listings','no-price','source-unavailable','unreadable','card-cooldown','card-throttled'])
const KNOWN_REFUSALS=new Set(['budget','rest','throttled','captcha','fatal','no-listings','no-price','source-unavailable','unreadable','request-limit','bad-key','off','no-market',DAY_BUDGET_REFUSAL,SEARCH_HOUR_REFUSAL])
const STOP_REFUSALS=new Set(['budget','rest','throttled','captcha','fatal',DAY_BUDGET_REFUSAL,SEARCH_HOUR_REFUSAL])
const QUEUE_WAIT_ON=new Set(['budget'])
const COUNTER_SILENT='counter-unavailable'
const QUEUE_WAITS=3
const QUEUE_PAD_MS=1_000
const QUEUE_MIN_WAIT_MS=1_000
const QUEUE_MAX_WAIT_MS=90_000
const isId=(value)=>Number.isSafeInteger(value)&&value>0
const isPrice=(value)=>Number.isFinite(value)&&value>0
export function purchaseVerdict(rows){const list=Array.isArray(rows)?rows:[]
let total=0
let foundTotal=0
const missing=[]
const over=[]
for(const row of list){const price=isPrice(row?.price)?row.price:null
if(price!==null)foundTotal+=price
if(row?.live===true&&price!==null){total+=price
continue}
if(price!==null&&row?.reason===OVER_REFERENCE){const limit=priceLawLimit(row?.want)
over.push({id:row?.id??null,name:row?.name??null,price,
want:isPrice(row?.want)?row.want:null,
above:limit===null?null:Math.ceil(price-limit)})
continue}
missing.push(row?.id??null)}
const clear=missing.length===0&&over.length===0
return{ok:list.length>0&&clear,
cards:list.length,total,foundTotal,missing,over}}
export function measureQueueFrom(prices,opts={}){const limit=Number.isSafeInteger(opts.limit)&&opts.limit>0?opts.limit:QUEUE_LIMIT
const minRating=Number.isFinite(opts.minRating)?opts.minRating:TOP_STEP_RATING
const sourceOf=typeof opts.sourceOf==='function'?opts.sourceOf:null
const skip=(id)=>{if(sourceOf===null)return false
let value=null
try{value=sourceOf(id)}catch{return false}
return isUntradableSource(value)}
const seen=new Set()
const out=[]
const take=(id,rating,prior,why)=>{if(out.length>=limit||!isId(id)||seen.has(id))return
seen.add(id)
if(skip(id))return
out.push({id,rating:Number.isFinite(rating)?rating:null,prior:isPrice(prior)?prior:null,why})}
const money=verdictTargets(prices,opts.answer)
const moneyRatings=new Set()
for(const one of money){if(Number.isFinite(one.rating))moneyRatings.add(one.rating)}
for(const one of Array.isArray(opts.suspects)?opts.suspects:[]){if(moneyRatings.size>0&&!moneyRatings.has(one?.rating))continue
take(one?.id,one?.rating,one?.prior,'quarantine')}
for(const one of money)take(one.id,one.rating,one.prior,one.why)
const wanted=new Set()
for(const one of Array.isArray(opts.rarities)?opts.rarities:[]){const key=String(one??'')
if(key!=='')wanted.add(key)}
if(wanted.size>0){const asked=[]
const ladders=prices?.rarityLadders
if(ladders&&typeof ladders==='object'){for(const key of Object.keys(ladders)){if(!wanted.has(String(key)))continue
for(const step of Array.isArray(ladders[key])?ladders[key]:[]){if(!Number.isFinite(step?.rating))continue
const pick=moneyPick(step)
if(!isId(pick?.id))continue
asked.push({id:pick.id,rating:step.rating,prior:pick.price})}}}
asked.sort((a,b)=>b.rating-a.rating)
for(const one of asked)take(one.id,one.rating,one.prior,'required-rarity')}
let cap=null
for(const one of money){if(isPrice(one.prior)&&(cap===null||one.prior>cap))cap=one.prior}
if(cap!==null)cap*=TAIL_PRICE_FACTOR
const bar=cap===null?tailBarOf(prices,minRating):null
const top=[]
for(const steps of everyLadder(prices)){for(const step of Array.isArray(steps)?steps:[]){if(!Number.isFinite(step?.rating))continue
if(bar!==null&&step.rating<bar)continue
const pick=moneyPick(step)
if(!isId(pick?.id))continue
if(cap!==null&&!(isPrice(pick.price)&&pick.price<=cap))continue
top.push({id:pick.id,rating:step.rating,prior:pick.price})}}
top.sort(cap===null?(a,b)=>b.rating-a.rating:(a,b)=>(b.prior??0)-(a.prior??0))
for(const one of top)take(one.id,one.rating,one.prior,'top-step')
for(const id of Array.isArray(opts.unknownIds)?opts.unknownIds:[])take(id,null,null,'unknown')
return out}
function tailBarOf(prices,minRating){let highest=null
for(const steps of everyLadder(prices))for(const step of Array.isArray(steps)?steps:[]){if(!Number.isFinite(step?.rating))continue
if(step.rating>=minRating)return minRating
if(highest===null||step.rating>highest)highest=step.rating}
return highest===null?minRating:highest}
function verdictTargets(prices,answer){if(!answer||typeof answer!=='object')return[]
const buys=[]
for(const buy of Array.isArray(answer.buys)?answer.buys:[]){const id=buy?.definitionId
if(!isId(id))continue
buys.push({id,rating:Number.isFinite(buy?.rating)?buy.rating:null,prior:buy?.price,why:'verdict-buy'})}
buys.sort((a,b)=>(b.prior??0)-(a.prior??0))
const ratings=new Set()
for(const card of Array.isArray(answer.prepared?.selection)?answer.prepared.selection:[]){if(card?.virtual===true)continue
if(Number.isFinite(card?.rating))ratings.add(card.rating)}
const burn=burnTargets(prices,ratings)
burn.sort((a,b)=>(b.prior??0)-(a.prior??0))
return[...buys,...burn]}
function burnTargets(prices,ratings){if(ratings.size===0)return[]
let rungs=[]
try{rungs=futureRungsOf(prices,false)}catch{return[]}
if(rungs.length===0)return[]
const targets=new Set()
for(const rating of ratings){let best=null
let bestFloor=null
for(const rung of rungs){if(rung.rating<rating)continue
const floor=rungFloor(rung)
if(floor===null)continue
if(bestFloor===null||floor<bestFloor){bestFloor=floor
best=rung.rating}}
if(best!==null)targets.add(best)}
const out=[]
for(const rating of targets){const pick=moneyPick(cheapestStepAt(prices,rating))
if(isId(pick?.id))out.push({id:pick.id,rating,prior:pick.price,why:'verdict-burn'})}
return out}
function rungFloor(rung){const floor=rung?.prices?rung.prices[0]:rung?.price
return isPrice(floor)?floor:null}
function stepFloor(step){if(isPrice(step?.price))return step.price
for(const pick of Array.isArray(step?.picks)?step.picks:[])if(isPrice(pick?.price))return pick.price
return null}
function cheapestStepAt(prices,rating){let best=null
let bestFloor=null
for(const steps of everyLadder(prices,MERGED_FAMILIES))for(const step of Array.isArray(steps)?steps:[]){if(step?.rating!==rating)continue
const floor=stepFloor(step)
if(floor===null)continue
if(bestFloor===null||floor<bestFloor){bestFloor=floor
best=step}}
return best}
function moneyPick(step){if(isId(step?.id)&&isPrice(step?.price))return{id:step.id,price:step.price}
const picks=Array.isArray(step?.picks)&&step.picks.length>0?step.picks:null
return picks===null?null:picks[0]}
const ALL_FAMILIES=['rarityLadders','leagueLadders','nationLadders','clubLadders']
const MERGED_FAMILIES=['rarityLadders']
function*everyLadder(prices,families=ALL_FAMILIES){if(!prices||typeof prices!=='object')return
if(Array.isArray(prices.ladder))yield prices.ladder
for(const family of families){const ladders=prices[family]
if(!ladders||typeof ladders!=='object')continue
for(const key of Object.keys(ladders))yield ladders[key]}}
export function createLivePrices(deps={}){const{clock}=deps
if(!clock||typeof clock.now!=='function')throw new Error('live-price-probe: нужны часы (правило 6 NIGHT_BRIEF)')
const measure=typeof deps.measure==='function'?deps.measure:null
const ttlMs=Number.isFinite(deps.ttlMs)&&deps.ttlMs>0?deps.ttlMs:LIVE_TTL_MS
const rest=typeof deps.rest==='function'?deps.rest:null
const live=new Map()
let generation=0
let running=0
const waiting=[]
let holding=false
let lastUrgent=false
const HAND=0
const PROBE=1
const QUEUE=2
const grant=()=>{if(holding||waiting.length===0)return
let at=-1
if(lastUrgent){const turn=waiting.findIndex((one)=>one.priority>=QUEUE)
if(turn>=0)at=turn}
if(at<0){let best=0
for(let i=1;i<waiting.length;i+=1){if(waiting[i].priority<waiting[best].priority)best=i}
at=best}
const one=waiting.splice(at,1)[0]
holding=true
lastUrgent=one.priority<QUEUE
one.let()}
const enter=(priority)=>new Promise((done)=>{waiting.push({priority,let:done})
grant()})
const leave=()=>{holding=false
grant()}
const DETAIL_KEEP=6
const stats={measured:0,found:0,refused:0,lastReason:null,unknown:0,rested:0,waited:0,reasons:{},details:[],
forgotten:0,forgets:{},cancels:{}}
let unknownRow=0
const entryOf=(id)=>{const known=live.get(id)
if(known===undefined)return null
if(clock.now()>=known.until){live.delete(id)
return null}
return known}
const liveEntry=(result)=>{const now=clock.now()
const at=Number.isFinite(result?.observedAt)?result.observedAt:null
return{price:result.price,
until:at===null?now:Math.min(now+ttlMs,at+ttlMs),
at:at===null?now:at,
from:typeof result?.from==='string'?result.from:null}}
const priceOf=(id)=>{const known=entryOf(id)
return known===null?null:known.price}
const freshRows=()=>{const out=[]
for(const id of [...live.keys()]){const known=entryOf(id)
if(known===null)continue
out.push({id,price:known.price,at:known.at,until:known.until,from:known.from??null})}
return out.sort((a,b)=>a.id-b.id)}
const fresh=()=>freshRows().map((one)=>[one.id,one.price])
return{priceOf,fresh,
async slot(priority,take){await enter(Number.isSafeInteger(priority)?priority:HAND)
try{return await take()}finally{leave()}},
forget(reason){const word=typeof reason==='string'&&reason!==''?reason:'forget'
const dropped=live.size
live.clear()
stats.forgets[word]=(stats.forgets[word]??0)+1
stats.forgotten+=dropped
return dropped>0},
cancel(reason){const word=typeof reason==='string'&&reason!==''?reason:'cancel'
generation+=1
stats.cancels[word]=(stats.cancels[word]??0)+1
return running>0},
note(id,price){if(!isId(id)||!isPrice(price))return false
live.set(id,liveEntry({price,observedAt:clock.now(),from:'note'}))
return true},
async run(queue,hint={}){running+=1
try{let asked=0
let found=0
const pace=hint?.pace??null
const nap=typeof pace?.sleep==='function'?pace.sleep:null
const mine=generation
const cancelled=()=>{if(mine!==generation)return true
if(typeof pace?.cancelled!=='function')return false
try{return pace.cancelled()===true}catch{return false}}
const step=(done,total,waited)=>{if(typeof pace?.onStep!=='function')return
try{pace.onStep({done,total,waited})}catch{/* показ не указ очереди */}}
const priority=Number.isSafeInteger(hint?.priority)?hint.priority:(pace===null?PROBE:QUEUE)
const list=Array.isArray(queue)?queue.filter((one)=>isId(one?.id)):[]
let done=0
let waited=0
const reasons={}
let waitMs=null
if(measure===null)return{asked,found,stoppedBy:'no-measure',reasons,waitMs}
for(const one of list){
if(priceOf(one.id)!==null){done+=1
step(done,list.length,waited)
continue}
if(cancelled())return{asked,found,stoppedBy:'cancelled',reasons,waitMs}
let result=null
let naps=0
let sent=false
for(;;){await enter(priority)
if(cancelled()){leave()
return{asked,found,stoppedBy:'cancelled',reasons,waitMs}}
if(!sent){sent=true
asked+=1
stats.measured+=1}
try{result=await measure(one.id,{type:hint.type??null,
...(hint.reference===true&&isPrice(one.prior)?{prior:one.prior}:{}),
...(isPrice(hint.emptyTtlMs)?{emptyTtlMs:hint.emptyTtlMs}:{})
,slotted:true,...(pace===null?{}:{cancelled})})}catch(err){result={ok:false,reason:String(err?.message??err)}}
finally{leave()}
if(result?.ok===true||nap===null)break
const limit=QUEUE_WAIT_ON.has(result?.reason)?QUEUE_WAITS:(result?.reason===COUNTER_SILENT?1:0)
if(naps>=limit)break
naps+=1
const said=Number(result?.waitMs)
if(Number.isFinite(said)&&said>0)waitMs=said
const sleepMs=Math.min(Math.max((Number.isFinite(said)&&said>0?said:0)+QUEUE_PAD_MS,QUEUE_MIN_WAIT_MS),QUEUE_MAX_WAIT_MS)
waited+=sleepMs
stats.waited+=sleepMs
await nap(sleepMs)
if(cancelled())return{asked,found,stoppedBy:'cancelled',reasons,waitMs}}
if(result?.ok===true&&isPrice(result.price)){live.set(one.id,liveEntry(result))
found+=1
stats.found+=1
unknownRow=0
done+=1
step(done,list.length,waited)
continue}
stats.refused+=1
const reason=result?.reason??'unknown'
if(Number.isFinite(result?.waitMs)&&result.waitMs>0)waitMs=result.waitMs
stats.lastReason=reason
stats.reasons[reason]=(stats.reasons[reason]??0)+1
if(typeof result?.detail==='string'&&result.detail!==''){stats.details.push(`${one.id} ${reason}: ${result.detail}`)
if(stats.details.length>DETAIL_KEEP)stats.details.shift()}
reasons[one.id]=reason
if(STOP_REFUSALS.has(reason)){unknownRow=0
return{asked,found,stoppedBy:reason,reasons,waitMs}}
if(KNOWN_REFUSALS.has(reason)){unknownRow=0
done+=1
step(done,list.length,waited)
continue}
stats.unknown+=1
unknownRow+=1
if(unknownRow>=UNKNOWN_LIMIT){unknownRow=0
stats.rested+=1
if(rest!==null){try{rest(UNKNOWN_REST_MS)}catch{/* отдых не обязан ронять заход */}}
return{asked,found,stoppedBy:'unknown-refusals',reasons,waitMs}}
done+=1
step(done,list.length,waited)}
return{asked,found,stoppedBy:null,reasons,waitMs}}finally{running-=1}},
async confirmPrices(targets,opts={}){
const mine=generation
const list=(Array.isArray(targets)?targets:[]).filter((one)=>isId(one?.id))
if(list.length===0){return{...purchaseVerdict([]),asked:0,found:0,stoppedBy:'no-targets',waitMs:null,rows:[]}}
const outcome=await this.run(list.map((one)=>({id:one.id,prior:one.prior??one.want??null})),
{type:opts.type??'player',reference:true,emptyTtlMs:BUY_EMPTY_TTL_MS,
priority:opts.pace&&typeof opts.pace.sleep==='function'?QUEUE:HAND,
...(opts.pace&&typeof opts.pace.sleep==='function'?{pace:opts.pace}:{})})
if(mine!==generation){return{...purchaseVerdict([]),asked:outcome.asked,found:outcome.found,
stoppedBy:'cancelled',waitMs:null,rows:[]}}
const rows=list.map((one)=>{const seen=entryOf(one.id)
const price=seen===null?null:seen.price
const reference=isPrice(one.want)?one.want:null
const over=price!==null&&reference!==null&&!withinPriceLaw(price,reference)
return{id:one.id,name:one.name??null,want:reference,
price,live:price!==null&&!over,
age:seen===null?null:Math.max(0,clock.now()-seen.at),
origin:seen===null?null:(seen.from??null),
reason:over?OVER_REFERENCE:(price===null?(outcome.reasons?.[one.id]??outcome.stoppedBy??stats.lastReason??'no-price'):null)}})
return{...purchaseVerdict(rows),
asked:outcome.asked,found:outcome.found,stoppedBy:outcome.stoppedBy,
waitMs:Number.isFinite(outcome.waitMs)?outcome.waitMs:null,rows}},
applyTo(prices){if(live.size===0||!prices||typeof prices!=='object')return prices
let touched=0
const step=(one)=>{const picks=Array.isArray(one?.picks)&&one.picks.length>0
?one.picks.map((pick)=>{const fresh=priceOf(pick?.id)
if(fresh===null)return pick
touched+=1
return{...pick,price:fresh,live:true}}).sort((a,b)=>a.price-b.price)
:null
if(picks===null){const fresh=priceOf(one?.id)
if(fresh===null)return one
touched+=1
return{...one,price:fresh,live:true,liveUntil:live.get(one.id)?.until??null}}
const built=stepFrom(one.rating,picks,one.count)
return{...one,picks:built.picks,price:built.price,id:built.id,attrs:built.attrs,
live:priceOf(built.id)!==null,liveUntil:live.get(built.id)?.until??null}}
const out={...prices}
if(Array.isArray(prices.ladder))out.ladder=prices.ladder.map(step)
for(const family of ALL_FAMILIES){const ladders=prices[family]
if(!ladders||typeof ladders!=='object')continue
const next={}
for(const key of Object.keys(ladders))next[key]=(Array.isArray(ladders[key])?ladders[key]:[]).map(step)
out[family]=next}
if(Array.isArray(prices.buckets)&&prices.buckets.length>0){const hot=new Map()
for(const[id]of live){const price=priceOf(id)
if(price!==null)hot.set(id,price)}
if(hot.size>0)out.buckets=prices.buckets.map((one)=>{const picks=Array.isArray(one?.picks)?one.picks:null
if(picks===null||picks.length===0)return one
let hit=false
const next=picks.map((pick)=>{const fresh=hot.get(pick?.id)
if(fresh===undefined)return pick
hit=true
touched+=1
return{...pick,price:fresh,live:true}})
if(!hit)return one
next.sort((a,b)=>a.price!==b.price?a.price-b.price:a.id-b.id)
return{...one,picks:next}})}
return touched===0?prices:out},
state(){const now=clock.now()
const rows=freshRows().map((one)=>({id:one.id,price:one.price,
ageMs:Math.max(0,now-one.at),untilMs:Math.max(0,one.until-now),from:one.from}))
return{known:live.size,fresh:rows.length,rows,ttlMs,...stats,unknownRow,running}}}}
export async function lagReport(prices,deps={}){const measure=typeof deps.measure==='function'?deps.measure:null
const count=Number.isSafeInteger(deps.count)&&deps.count>0?deps.count:10
const minRating=Number.isFinite(deps.minRating)?deps.minRating:75
const minPrice=Number.isFinite(deps.minPrice)&&deps.minPrice>0?deps.minPrice:0
const steps=(Array.isArray(prices?.ladder)?prices.ladder:[]).filter((one)=>Number.isFinite(one?.rating)&&one.rating>=minRating&&isId(one?.id)&&isPrice(one?.price)&&one.price>=minPrice)
const byPrice=[...steps].sort((a,b)=>a.price-b.price||a.id-b.id)
const edge=Math.floor(byPrice.length/2)
const marked=byPrice.map((step,i)=>({step,cls:i<edge?'cheap':'dear'}))
const picked=fillTo(interleave(everyNth(marked.slice(0,edge),Math.ceil(count/2)),
everyNth(marked.slice(edge),Math.floor(count/2))),marked,count)
const sleep=typeof deps.sleep==='function'?deps.sleep:null
const waitOf=typeof deps.waitMs==='function'?deps.waitMs:null
const rows=[]
let stopped=null
let waited=0
if(sleep!==null&&waitOf!==null){let standing=0
try{standing=Number(waitOf(null))||0}catch{standing=0}
if(standing>0){const nap=Math.min(standing+RHYTHM_PAD_MS,REST_WAIT_MS)
waited+=nap
await sleep(nap)}}
for(const asked of picked){if(rows.length>=count)break
const one=asked.step
const cls=asked.cls
if(measure===null){rows.push({rating:one.rating,id:one.id,cls,blob:one.price,live:null,lagPct:null,reason:'no-measure'})
continue}
if(stopped!==null){rows.push({rating:one.rating,id:one.id,cls,blob:one.price,live:null,lagPct:null,reason:stopped})
continue}
let result=null
for(let attempt=0;attempt<=RHYTHM_WAITS;attempt+=1){try{result=await measure(one.id,{})}catch(err){result={ok:false,reason:String(err?.message??err)}}
if(result?.ok===true||!RHYTHM_REFUSALS.has(result?.reason)||sleep===null||attempt===RHYTHM_WAITS)break
let wait=0
try{wait=waitOf===null?0:Number(waitOf(one.id))||0}catch{wait=0}
const nap=Math.min(Math.max(Math.max(wait,0)+RHYTHM_PAD_MS,RHYTHM_MIN_WAIT_MS),RHYTHM_MAX_WAIT_MS)
waited+=nap
await sleep(nap)}
if(result?.ok!==true&&BAND_STOPS.has(result?.reason))stopped=result.reason
const from=typeof result?.from==='string'?result.from:null
const mine=result?.ok===true&&isPrice(result.price)&&from==='market'
const price=mine?result.price:null
const seen=Number.isFinite(result?.observedAt)?result.observedAt:null
rows.push({rating:one.rating,id:one.id,cls,blob:one.price,live:price,from,observedAt:seen,
lagPct:price===null?null:Math.round(((price-one.price)/one.price)*100),
...(result?.ok===true&&isPrice(result.price)&&!mine?{memoryPrice:result.price}:{}),
reason:price===null?(result?.ok===true&&isPrice(result.price)
?`${from===null?'без происхождения':from} ${result.price}`
:(result?.reason??'unknown')):null,
...(typeof result?.detail==='string'&&result.detail!==''?{detail:result.detail}:{})})}
let nowRef=null
for(const row of rows){if(row.from==='market'&&Number.isFinite(row.observedAt)&&(nowRef===null||row.observedAt>nowRef))nowRef=row.observedAt}
for(const row of rows){row.ageMs=nowRef===null||!Number.isFinite(row.observedAt)?null:Math.max(0,nowRef-row.observedAt)
if(row.live===null&&row.from==='memory'&&Number.isFinite(row.ageMs))row.reason=`${row.reason} · ${Math.round(row.ageMs/1000)} с`}
const lags=rows.map((row)=>row.lagPct).filter((one)=>Number.isFinite(one)).sort((a,b)=>a-b)
const median=lags.length===0?null:lags[Math.floor(lags.length/2)]
return{rows,median,waitedMs:waited,stoppedBy:stopped,
asked:rows.length,
memory:rows.filter((row)=>row.from==='memory').length,
cheap:rows.filter((row)=>row.cls==='cheap'&&row.live!==null).length,
dear:rows.filter((row)=>row.cls==='dear'&&row.live!==null).length,
...toleranceBand(rows)}}
function everyNth(pool,take){if(take<=0||pool.length===0)return[]
const stride=Math.max(1,Math.floor(pool.length/take))
const out=[]
for(let i=0;i<pool.length&&out.length<take;i+=stride)out.push(pool[i])
return out}
function interleave(a,b){const out=[]
for(let i=0;i<Math.max(a.length,b.length);i+=1){if(i<a.length)out.push(a[i])
if(i<b.length)out.push(b[i])}
return out}
function fillTo(chosen,marked,count){if(chosen.length>=count)return chosen.slice(0,count)
const used=new Set(chosen)
const out=[...chosen]
for(const one of marked){if(out.length>=count)break
if(used.has(one))continue
out.push(one)}
return out}
const RHYTHM_REFUSALS=new Set(['throttled','budget','rest','counter-unavailable',SEARCH_HOUR_REFUSAL])
const RHYTHM_MIN_WAIT_MS=1_000
const BAND_STOPS=new Set(['captcha','fatal','off','no-market','bad-key',DAY_BUDGET_REFUSAL,SEARCH_HOUR_REFUSAL])
const RHYTHM_WAITS=3
const RHYTHM_PAD_MS=1_000
const RHYTHM_MAX_WAIT_MS=90_000
const REST_WAIT_MS=330_000
function toleranceBand(rows){const band=[]
for(const row of Array.isArray(rows)?rows:[]){if(!isPrice(row?.blob)||!isPrice(row?.live))continue
const gap=row.live-row.blob
const allow=toleranceFor(row.blob)
const within=withinPriceLaw(row.live,row.blob)
band.push({gap,allow,within,pct:Math.round((gap/row.blob)*100)})
row.gap=gap
row.allow=allow
row.within=within}
if(band.length===0)return{measured:0,within:0,worstGap:null,worstPct:null,medianGap:null}
const gaps=band.map((one)=>one.gap).sort((a,b)=>a-b)
const worst=band.reduce((max,one)=>one.gap>max.gap?one:max,band[0])
return{measured:band.length,
within:band.filter((one)=>one.within).length,
worstGap:worst.gap,worstPct:worst.pct,
medianGap:gaps[Math.floor(gaps.length/2)]}}
