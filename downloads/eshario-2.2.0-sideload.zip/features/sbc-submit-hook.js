import{SUBMIT_GESTURE,SUBMIT_TARGET_SELECTOR,SUBMIT_DOORS,submitButtonsOf,installSubmitServiceGuard} from '../adapter/sbc-submit.js'
import{createSbcSubmits} from './head-counters.js'
import{stopOnEaLimit} from './day-budget.js'
export const SECOND_LOOK_FRAMES=120
export const GUARD_UNAVAILABLE='guard-unavailable'
export const POLICY_UNKNOWN='policy-unknown'
export const SERVICE_BLOCKED='service-blocked'
const CONTINUATION='native-continuation'
export function createSubmitGuardHook(deps={}){const doc=deps.doc??null
const win=deps.win??doc?.defaultView??globalThis
const judge=typeof deps.judge==='function'?deps.judge:null
const policy=typeof deps.policy==='function'?deps.policy
:typeof deps.isActive==='function'?()=>(deps.isActive()===true?'on':'off')
:()=>'on'
const activeGeneration=typeof deps.activeGeneration==='function'?deps.activeGeneration:()=>null
const onStopped=typeof deps.onStopped==='function'?deps.onStopped:()=>{}
const onSubmitted=typeof deps.onSubmitted==='function'?deps.onSubmitted:()=>{}
const wired=Object.freeze({shield:typeof deps.activeGeneration==='function',fresh:typeof deps.onStopped==='function',policy:typeof deps.policy==='function',submitted:typeof deps.onSubmitted==='function'})
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const budgetNow=()=>{if(typeof deps.budget!=='function')return deps.budget??null
try{return deps.budget()??null}catch(err){onError(err)
return null}}
const clock=deps.clock&&typeof deps.clock.now==='function'?deps.clock:null
const submits=clock===null?null:createSbcSubmits({clock,storage:deps.storage??null,onError})
if(submits!==null)void submits.load().catch(onError)
let target=null
let question=null
let ticket=null
let lastBlock=null
let continuation=null
let gesture=null
let onVerdict=()=>{}
let onDoors=()=>{}
let installed=false
let service={ok:false,reason:'not-run',state:()=>({blocked:0,passed:0,errors:0}),dispose(){}}
let stopped=0
let passed=0
let faults=0
let submitted=0
let serverRefused=0
let eaLimits=0
let answerTicket=null
let repeatAnswers=0
function armAnswer(challenge){answerTicket={challenge:idOf(challenge),at:clockNow()}}
function spendAnswer(challenge){if(answerTicket===null){repeatAnswers+=1
return false}
const id=idOf(challenge)
const mine=answerTicket.challenge
if(mine!==''&&id!==''&&mine!==id){repeatAnswers+=1
return false}
answerTicket=null
return true}
function onAnswer(answer){try{
let violations=0
try{const list=answer?.data?.itemViolations
violations=Array.isArray(list)?list.length:0}catch{violations=0}
if(continuation!==null)continuation={...continuation,armed:continuation.armed===true||violations>0,violations}
if(answer?.success!==true){serverRefused+=1
const limit=stopOnEaLimit(budgetNow(),answer)
if(limit!==null)eaLimits+=1
return}
continuation=null
if(!spendAnswer(answer?.challenge))return
submitted+=1
if(submits!==null)submits.take()
try{onSubmitted(answer)}catch(err){faults+=1
onError(err)}}catch(err){faults+=1
onError(err)}}
function report(verdict){try{onVerdict(verdict)}catch(err){onError(err)}}
function policyNow(){let value=null
try{value=policy()}catch(err){onError(err)
return 'unknown'}
return value==='on'||value==='off'?value:'unknown'}
function generationNow(){try{const value=activeGeneration()
return value===null||value===undefined?null:String(value)}catch(err){onError(err)
return null}}
function printOf(blockers,signature,generation){const parts=blockers.map((blocker)=>{const ids=(Array.isArray(blocker?.ids)?blocker.ids:[]).map(String).sort()
return`${String(blocker?.code)}#${ids.join('.')}`}).sort()
return JSON.stringify([parts,signature,generation])}
const fits=(held,id,signature,print)=>held!==null&&held.challenge===id&&held.signature===signature&&held.print===print
const idOf=(challenge)=>{try{return String(challenge?.id??'')}catch{return ''}}
function stop(blockers,verdict,reason){stopped+=1
report({blockers,warnings:Array.isArray(verdict?.warnings)?verdict.warnings:[],
names:verdict?.names instanceof Map?verdict.names:null})
return{stop:true,reason}}
function decide(subject,origin){const service=origin==='service'
let verdict=null
let broken=judge===null
if(!broken){try{verdict=judge(subject)}catch(err){onError(err)
broken=true}}
if(!broken&&(!verdict||!Array.isArray(verdict.blockers)))broken=true
if(broken){faults+=1
return stop([{code:GUARD_UNAVAILABLE,confirmable:false}],null,GUARD_UNAVAILABLE)}
const blockers=verdict.blockers
const signature=typeof verdict.signature==='string'?verdict.signature:null
const print=printOf(blockers,signature,generationNow())
const id=idOf(subject)
if(blockers.length===0){passed+=1
report(null)
return{stop:false,signature,print}}
const passable=blockers.every((blocker)=>blocker?.confirmable===true)&&signature!==null&&id!==''
if(service){
if(passable&&fits(ticket,id,signature,print)){ticket=null
question=null
continuation={challenge:id,signature,print,armed:false,violations:0}
passed+=1
report(null)
return{stop:false,signature,print}}
if(passable&&continuation?.armed===true&&fits(continuation,id,signature,print)){continuation=null
passed+=1
report(null)
return{stop:false,signature,print,reason:CONTINUATION}}
return stop(blockers,verdict,blockers[0]?.code??'blocked')}
if(passable&&fits(question,id,signature,print)){ticket={challenge:id,signature,print}
passed+=1
report(null)
return{stop:false,signature,print,minted:true}}
const answer=stop(blockers,verdict,blockers[0]?.code??'blocked')
const fresh=passable&&(question===null||question.print!==print)
question=passable?{challenge:id,signature,print,codes:blockers.map((blocker)=>String(blocker.code))}:null
ticket=null
if(fresh){try{onStopped()}catch(err){onError(err)}}
return answer}
function better(next,prev){return next.length<prev.length&&next.every((name)=>prev.includes(name))}
function lookAgain(watched){if(watched.missing.length===0)return
const frame=win?.requestAnimationFrame
if(typeof frame!=='function')return
const step=()=>{if(target!==watched)return
watched.looks+=1
let next=null
try{next=submitButtonsOf(watched.controller,watched.root)}catch(err){onError(err)
return}
if(better(next.missing,watched.missing)){watched.nodes=next.nodes
watched.missing=next.missing
watched.doors=next.doors
try{onDoors({missing:[...next.missing],doors:next.doors,looks:watched.looks})}catch(err){onError(err)}}
if(watched.missing.length===0||watched.looks>=SECOND_LOOK_FRAMES)return
try{frame.call(win,step)}catch(err){onError(err)}}
try{frame.call(win,step)}catch(err){onError(err)}}
function isSubmitTarget(node){if(!node||typeof node!=='object')return false
for(const known of target?.nodes??[]){if(known===node)return true
try{if(typeof known?.contains==='function'&&known.contains(node))return true}catch{
}}
try{return typeof node.closest==='function'&&node.closest(SUBMIT_TARGET_SELECTOR)!==null}catch{return false}}
function onGesture(event){if(!target)return
const type=event?.type
if(type==='mousedown'||type==='touchstart')gesture=null
if(!isSubmitTarget(event?.target))return
if(type==='mousedown'||type==='touchstart'){ticket=null
continuation=null}
if(gesture===null)gesture=judgeGesture()
if(gesture.stop===true){try{event.stopImmediatePropagation()}catch(err){onError(err)}
try{event.preventDefault()}catch(err){onError(err)}}
if(type==='click'||type==='touchend')gesture=null}
function judgeGesture(){const mode=policyNow()
if(mode==='off')return{stop:false}
if(mode!=='on')return stop([{code:POLICY_UNKNOWN,confirmable:false}],null,POLICY_UNKNOWN)
return decide(target.challenge,'gesture')}
function blockService(reason,challenge){lastBlock={reason,at:clockNow(),challenge:idOf(challenge),shown:false}
if(target!==null)showLastBlock()
return false}
function clockNow(){try{return clock===null?null:clock.now()}catch{return null}}
function allowService(challenge){const mode=policyNow()
if(mode==='off')return true
if(mode!=='on')return blockService(POLICY_UNKNOWN,challenge)
if(!target)return blockService('no-target',challenge)
const id=idOf(challenge)
const mine=idOf(target.challenge)
if(id===''||mine==='')return blockService('no-challenge-id',challenge)
if(id!==mine)return blockService('foreign-challenge',challenge)
const decision=decide(challenge,'service')
if(decision.stop===true)return blockService(decision.reason??'blocked',challenge)
return true}
function showLastBlock(){if(lastBlock===null||lastBlock.shown===true)return
lastBlock={...lastBlock,shown:true}
report({blockers:[{code:SERVICE_BLOCKED,reason:lastBlock.reason,confirmable:false}],warnings:[],names:null})}
return{
install(){if(!installed){installed=true
for(const type of SUBMIT_GESTURE){try{doc?.addEventListener?.(type,onGesture,true)}catch(err){onError(err)}}}
if(service.ok!==true)service=installSubmitServiceGuard(win,(challenge)=>{const pass=allowService(challenge)
if(pass===true)armAnswer(challenge)
return pass},onAnswer)
return{ok:service.ok===true,reason:service.reason}},
attach(capture){const challenge=capture?.challenge??null
if(!challenge)return{ok:false,reason:'no-challenge',missing:[...SUBMIT_DOORS]}
const id=idOf(challenge)
if(id===''||id!==idOf(target?.challenge)){question=null
ticket=null
continuation=null
gesture=null}
const controller=capture?.controller??null
const root=capture?.root??null
const{nodes,missing,doors}=submitButtonsOf(controller,root)
target={challenge,controller,root,nodes,missing,doors,looks:0}
lookAgain(target)
showLastBlock()
return{ok:missing.length===0,reason:missing.length===0?null:'partial',missing}},
detach(){target=null
question=null
ticket=null
continuation=null
gesture=null},
observe(fn){onVerdict=typeof fn==='function'?fn:()=>{}},
observeDoors(fn){onDoors=typeof fn==='function'?fn:()=>{}},
state(){return{ok:service.ok===true,reason:service.reason??null,installed,missing:target?.missing??[...SUBMIT_DOORS],doors:target?.doors??null,watching:target!==null,nodes:target?.nodes?.length??0,looks:target?.looks??0,stopped,passed,faults,submitted,serverRefused,eaLimits,repeatAnswers,ticketArmed:answerTicket!==null,rate:submits===null?null:submits.state(),
armed:question!==null?[...question.codes]:[],ticket:ticket!==null,policy:policyNow(),
continuation:continuation===null?null:{armed:continuation.armed===true,violations:continuation.violations},
lastBlock:lastBlock===null?null:{...lastBlock},wired,
gestures:{stopped,passed,faults},corridor:{...service.state()},...service.state()}},
dispose(){for(const type of SUBMIT_GESTURE){try{doc?.removeEventListener?.(type,onGesture,true)}catch(err){onError(err)}}
service.dispose()
service={ok:false,reason:'disposed',state:()=>({blocked:0,passed:0,errors:0}),dispose(){}}
installed=false
target=null
question=null
ticket=null
continuation=null
answerTicket=null
gesture=null}}}
