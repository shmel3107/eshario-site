import{manifestUrl,futggBlobUrl,currentGame,MANIFEST_TTL_MS} from './futgg.js'
export const NON_PROMO_BLOBS=Object.freeze(['manifest','fc-core-data','config','config-web','config-ios','config-android','all-evolutions','active-evolutions','metarank-definition','icon-swaps','token-store','playstyle-ranking','playstyle-ranking-per-player','play-styles','roles','player-prices-ps5','player-prices-pc','player-prices-index','player-prices-ps5-dyn','player-prices-pc-dyn','player-gg-ratings','player-gg-rating-ranks'])
export function promoNames(manifest){if(!manifest||typeof manifest!=='object'||Array.isArray(manifest))return[]
const skip=new Set(NON_PROMO_BLOBS)
const out=[]
for(const[name,value]of Object.entries(manifest)){
if(name.startsWith('_')||skip.has(name))continue
if(typeof value==='string'&&value!=='')out.push(name)}
return out}
export function parsePromo(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw))return null
const rarity=raw.rarityEaId
if(!Number.isSafeInteger(rarity)||rarity<0||rarity>100000)return null
if(!Array.isArray(raw.players))return null
const ids=[]
const seen=new Set()
for(const player of raw.players){const id=player?.eaId
if(!Number.isSafeInteger(id)||id<=0||seen.has(id))continue
seen.add(id)
ids.push(id)}
return ids.length>0?{rarity,ids}:null}
export function createRarityGroups(options={}){const fetchImpl=options.fetch
if(typeof fetchImpl!=='function')throw new Error('futgg-rarities: нужен fetch')
const gameNow=()=>options.game??currentGame()
const ttl=Number.isFinite(options.manifestTtlMs)&&options.manifestTtlMs>0?options.manifestTtlMs:MANIFEST_TTL_MS
let cached=null
let inFlight=null
const now=()=>(typeof options.clock?.now==='function'?options.clock.now():0)
const json=async(url)=>{const response=await fetchImpl(url)
if(!response||typeof response.status!=='number')throw new Error('bad-response')
if(response.status<200||response.status>=300)throw new Error(`http-${response.status}`)
return response.json()}
const load=async()=>{const game=gameNow()
const manifest=await json(manifestUrl(game))
const version=manifest?._version
if(cached&&version!==undefined&&cached.version===version){cached={...cached,at:now()}
return cached.groups}
const groups=[]
for(const name of promoNames(manifest)){const url=futggBlobUrl(manifest,name,game)
if(url===null)continue
let promo=null
try{promo=parsePromo(await json(url))}catch{promo=null}
if(promo!==null)groups.push(promo)}
cached={version,groups,at:now()}
return groups}
return{
async read(){const at=now()
if(cached&&at-cached.at<ttl)return cached.groups
if(inFlight)return inFlight
const work=load().catch(()=>(cached?cached.groups:[]))
inFlight=work.finally(()=>{inFlight=null})
return inFlight}}}
