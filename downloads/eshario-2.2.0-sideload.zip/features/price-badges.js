import{el,ensureSidebarStyles} from '../ui/dom.js'
import{pickItemFacts} from '../adapter/player-picks.js'
import{inDetailColumn} from './card-views.js'
import{MIN_BIN_FEATURE} from './min-bin.js'
export const PRICE_BADGE_FEATURE='priceBadges'
export const RETRY_AFTER_MS=30_000
const BADGE_SELECTOR='[data-fut-price-badge]'
export const BADGES_PER_FRAME=4
let queue=[]
let queued=false
let booked=new WeakSet()
const shownOn=new WeakMap()
let lastPass={restored:0,booked:0,drawn:0,removed:0,rows:0}
let lastFrame=null
function frameFor(doc){if(typeof lastFrame==='function')return lastFrame
const view=doc?.defaultView??null
if(typeof view?.requestAnimationFrame!=='function')return null
return (fn)=>{let raced=false
const once=()=>{if(raced)return
raced=true
fn()}
try{view.requestAnimationFrame(once)}catch{once()
return}
try{view.setTimeout?.(once,250)}catch{/* кадра хватит */}}}
function later(doc,job,row=null){const frame=frameFor(doc)
if(!frame)return false
if(row!==null){if(booked.has(row))return true
booked.add(row)}
queue.push(job)
if(queued)return true
queued=true
frame(()=>{queued=false
run(doc)})
return true}
function run(doc){const take=queue.splice(0,BADGES_PER_FRAME)
for(const job of take){try{job()}catch{/* одна плашка не роняет остальные */}}
if(queue.length===0)return 0
const frame=frameFor(doc)
if(!frame){for(const job of queue.splice(0,queue.length)){try{job()}catch{/* см. выше */}}
return 0}
queued=true
frame(()=>{queued=false
run(doc)})
return queue.length}
function forgetQueue(){const had=queue.length
queue=[]
queued=false
booked=new WeakSet()
return had}
const MARK_PRICE='price'
const MARK_WAIT='wait'
const MARK_NONE='none'
const MARK_SEALED='sealed'
const QUIET_CLASS='fut-price-badge--quiet'
const ROW_CLASS='listFUTItem'
const CARD_SELECTOR='.item'
const SINGLE_SURFACES=Object.freeze([Object.freeze({id:'details',rootClass:'DetailView',cardSelector:'.detail-carousel',big:true}),
Object.freeze({id:'squad',rootClass:'ut-squad-slot-view',cardSelector:`.small${CARD_SELECTOR}`,big:false})])
const singleItems=new WeakMap()
export function notePriceBadgeCard(root,item){if(!root)return false
if(!item||typeof item!=='object'){singleItems.delete(root)
return false}
singleItems.set(root,item)
return true}
export const PRICE_BADGE_SURFACES=Object.freeze([Object.freeze({id:'market',rootClass:'SearchResults',detail:'pinned'}),
Object.freeze({id:'transfer',rootClass:'ut-transfer-list-view'}),
Object.freeze({id:'targets',rootClass:'ut-watch-list-view'}),
Object.freeze({id:'unassigned',rootClass:'ut-unassigned-view'}),
Object.freeze({id:'club',rootClass:'ut-club-search-results-view'})])
const MILLION=1_000_000
export function shortCoins(value){if(typeof value!=='number'||!Number.isFinite(value)||value<=0)return null
const coins=Math.round(value)
if(coins<1000)return String(coins)
const million=coins>=MILLION-500
const scaled=coins/(million?MILLION:1000)
const text=scaled>=100?String(Math.round(scaled)):trimZero(scaled.toFixed(1))
return`${text}${million?'M':'K'}`}
const trimZero=(text)=>(text.endsWith('.0')?text.slice(0,-2):text)
function face(t,{state,coins=null,live=false}){if(state===MARK_WAIT)return{text:t('priceBadge.waiting'),title:t('priceBadge.waiting.title')}
if(state===MARK_NONE)return{text:t('priceBadge.none'),title:t('priceBadge.none.title')}
const short=shortCoins(coins)
const value=Math.round(Number(coins))
return live?{text:t('priceBadge.verified',{value:short}),title:t('priceBadge.verified.title',{value})}
:{text:short,title:t('priceBadge.title.ask',{value})}}
export function definitionOf(item){const id=item?.definitionId??item?.defId
return Number.isSafeInteger(id)&&id>0?id:null}
function sealedOf(item){const facts=pickItemFacts(item)
return facts.player===false&&facts.tradable===false}
const painted=new WeakMap()
const known=new Map()
const failedAt=new Map()
let nowMs=()=>Date.now()
function resting(id){const at=failedAt.get(id)
if(at===undefined)return false
const passed=nowMs()-at
if(passed>=0&&passed<RETRY_AFTER_MS)return true
failedAt.delete(id)
return false}
let epoch=0
export function relabelPriceBadges(){epoch+=1
return epoch}
export function setPriceBadgeCoins(definitionId,coins){const id=Number(definitionId)
if(!Number.isSafeInteger(id)||id<=0)return false
const price=typeof coins==='number'&&Number.isFinite(coins)&&coins>0?Math.round(coins):null
if(price===null)return false
verified.set(id,{coins:price,at:nowMs()})
failedAt.delete(id)
repaintNow(id,price)
for(const listener of measured){try{listener(id,price)}catch{/* показ — не замер */}}
return true}
const measured=new Set()
export function onPriceBadgeMeasured(listener){if(typeof listener!=='function')return()=>{}
measured.add(listener)
return()=>{measured.delete(listener)}}
function repaintNow(id,price){const doc=lastDoc
if(!doc?.querySelectorAll)return 0
const shown=typeof lastLabel==='function'?face(lastLabel,{state:MARK_PRICE,coins:price,live:true}):{text:shortCoins(price),title:null}
const text=shown.text
if(text===null||text===undefined)return 0
let touched=0
for(const node of Array.from(doc.querySelectorAll(`[data-fut-price-badge-id="${id}"]`)??[])){
if(node.textContent!==text)node.textContent=text
if(node.dataset)node.dataset.futPriceBadge=String(price)
if(node.dataset)node.dataset.futPriceBadgeMark=MARK_PRICE
if(typeof node.className==='string'&&node.className.includes(QUIET_CLASS))node.className=node.className.split(/\s+/).filter((one)=>one&&one!==QUIET_CLASS).join(' ')
if(node.dataset&&node.dataset.futPriceBadgeLive!=='1')node.dataset.futPriceBadgeLive='1'
if(node.dataset&&node.dataset.futPriceBadgePress!=='1')node.dataset.futPriceBadgePress='1'
if(shown.title!==null&&typeof node.setAttribute==='function'){try{node.setAttribute('title',shown.title)}catch{/* подпись не важнее числа */}
explain(node.parentNode,shown.title,id)}
touched+=1}
return touched}
let lastDoc=null
let lastLabel=null
let lastPriceOf=null
let lastMeasure=null
let lastActive=null
export function priceBadgeCoins(item){const id=definitionOf(item)
if(id===null)return null
const live=verified.get(id)
if(live)return live.coins
const answer=known.get(id)
if(answer!==undefined)return answer
if(typeof lastPriceOf!=='function'||resting(id))return null
return askPrice(id,item,lastPriceOf)}
export function priceBadgePeek(definitionId){const id=Number(definitionId)
if(!Number.isSafeInteger(id)||id<=0)return null
const answer=verified.get(id)?.coins??known.get(id)
return typeof answer==='number'&&Number.isFinite(answer)&&answer>0?answer:null}
const verified=new Map()
export function verifiedPriceOf(definitionId){const id=Number(definitionId)
if(!Number.isSafeInteger(id)||id<=0)return null
const seen=verified.get(id)
if(!seen)return null
const passed=nowMs()-seen.at
if(!(passed>=0))return{coins:seen.coins,at:seen.at,ageMs:Number.POSITIVE_INFINITY,age:AGE_UNKNOWN}
return{coins:seen.coins,at:seen.at,ageMs:passed,age:AGE_KNOWN}}
export const AGE_KNOWN='known'
export const AGE_UNKNOWN='unknown'
export function priceBadgeState(doc){const view=doc?.defaultView??null
const marks=[]
for(const node of doc?.querySelectorAll?.(BADGE_SELECTOR)??[]){const card=node.parentNode??null
let position='?'
try{position=view?.getComputedStyle?.(node)?.position??'?'}catch{}
let off=null
try{const one=node.getBoundingClientRect?.()
const two=card?.getBoundingClientRect?.()
if(one&&two)off=Math.round((one.left+one.width/2)-(two.left+two.width/2))}catch{}
marks.push({coins:Number(node.dataset?.futPriceBadge)||null,mark:node.dataset?.futPriceBadgeMark??MARK_PRICE,
id:Number(node.dataset?.futPriceBadgeId)||null,
verified:node.dataset?.futPriceBadgeLive==='1',
press:node.dataset?.futPriceBadgePress==='1',
text:String(node.textContent??''),
listed:insideRow(node),
big:String(node.className).includes('--big'),position,off,
card:String(card?.className??'').slice(0,40)})}
const tally={price:0,wait:0,none:0}
for(const one of marks)tally[one.mark]=(tally[one.mark]??0)+1
return{rows:nativeRows(doc),count:marks.length,listed:marks.filter((one)=>one.listed).length,
cards:new Set(marks.map((one)=>one.id).filter((id)=>id!==null)).size,
checked:marks.filter((one)=>one.verified).length,
buttons:marks.filter((one)=>one.press).length,
listeners:measured.size,
pass:{...lastPass},tally,marks}}
function nativeRows(doc){const seen=new Set()
for(const surface of PRICE_BADGE_SURFACES){for(const root of doc?.querySelectorAll?.(`.${surface.rootClass}`)??[]){
for(const row of root.querySelectorAll?.(`.${ROW_CLASS}`)??[])seen.add(row)}}
return seen.size}
function insideRow(node){for(let at=node?.parentNode??null;at;at=at.parentNode??null){
if(String(at.className??'').split(/\s+/).includes(ROW_CLASS))return true}
return false}
function insidePinned(row,root){for(let at=row?.parentNode??null;at&&at!==root;at=at.parentNode??null){
if(String(at.className??'').split(/\s+/).includes('ut-pinned-item'))return true}
return false}
export function enhancePriceBadges(options={}){const{doc,t,itemOf}=options
const done={drawn:0,removed:0,pending:Promise.resolve()}
if(!doc||typeof t!=='function'||typeof itemOf!=='function')return done
lastDoc=doc
lastLabel=t
if(typeof options.priceOf==='function')lastPriceOf=options.priceOf
if(typeof options.measure==='function')lastMeasure=options.measure
if(typeof options.isActive==='function')lastActive=options.isActive
if(typeof options.now==='function')nowMs=options.now
lastFrame=typeof options.frame==='function'?options.frame:null
if(!safeActive(options.isActive)){forgetQueue()
const removed=dropAll(doc)
if(removed>0)epoch+=1
return{...done,removed}}
const priceOf=typeof options.priceOf==='function'?options.priceOf:null
const surfaces=Array.isArray(options.surfaces)?options.surfaces:PRICE_BADGE_SURFACES
const waiting=[]
const seen=new Set()
let drawn=0
let removed=0
let restored=0
let booked_=0
for(const surface of surfaces){for(const root of doc.querySelectorAll?.(`.${surface.rootClass}`)??[]){
const pinnedOnly=surface.detail==='pinned'&&inDetailColumn(root)
const было=shownOn.get(root)??null
const сейчас=new Set()
let покрашено=0
const потолок=было===null?0:было.rows
let вернули=0
let рядов=0
for(const row of root.querySelectorAll?.(`.${ROW_CLASS}`)??[]){if(seen.has(row))continue
seen.add(row)
рядов+=1
if(pinnedOnly&&!insidePinned(row,root)){if(dropRow(row))removed+=1
continue}
const item=itemOf(row)
if(!item||typeof item!=='object'){if(dropRow(row))removed+=1
continue}
const id=definitionOf(item)
if(id===null){if(dropRow(row))removed+=1
continue}
const plan=decide(id,priceOf,item)
if(plan.mark===MARK_SEALED){if(dropRow(row))removed+=1
continue}
if(plan.mark===null)continue
if(!alreadyPainted(row,item,plan.coins,plan.mark,plan.live)){
if(было!==null&&было.ids.has(id)&&вернули<потолок){вернули+=1
restored+=1
if(paint({doc,t,row,item,coins:plan.coins,mark:plan.mark,live:plan.live,surface:surface.id})){drawn+=1
сейчас.add(id)
покрашено+=1}}
else{const план=plan
const строка=row
const карта=item
if(!later(doc,()=>{
booked.delete(строка)
if(itemOf(строка)!==карта)return
paint({doc,t,row:строка,item:карта,coins:план.coins,mark:план.mark,live:план.live,surface:surface.id})},строка)
){if(paint({doc,t,row,item,coins:plan.coins,mark:plan.mark,live:plan.live,surface:surface.id})){drawn+=1
сейчас.add(id)
покрашено+=1}}
else booked_+=1}}
else{сейчас.add(id)
покрашено+=1}
if(plan.ask)waiting.push(askPrice(id,item,priceOf).then(()=>{
if(itemOf(row)!==item)return
const after=decide(id,priceOf,item)
if(after.mark===null)return
if(paint({doc,t,row,item,coins:after.coins,mark:after.mark,live:after.live,surface:surface.id}))drawn+=1}))}
if(рядов>0)shownOn.set(root,{ids:сейчас,rows:покрашено})}}
if(restored>0||booked_>0||drawn>0||removed>0)lastPass={restored,booked:booked_,drawn,removed,rows:seen.size}
for(const single of SINGLE_SURFACES){const{cardSelector,big}=single
for(const root of doc.querySelectorAll?.(`.${single.rootClass}`)??[]){const item=singleItems.get(root)
if(!item){if(dropRow(root,cardSelector))removed+=1
continue}
const id=definitionOf(item)
if(id===null){if(dropRow(root,cardSelector))removed+=1
continue}
const plan=decide(id,priceOf,item)
if(plan.mark===MARK_SEALED){if(dropRow(root,cardSelector))removed+=1
continue}
if(plan.mark===null)continue
if(paint({doc,t,row:root,item,coins:plan.coins,mark:plan.mark,live:plan.live,cardSelector,big,surface:single.id}))drawn+=1
if(plan.ask)waiting.push(askPrice(id,item,priceOf).then(()=>{
if(singleItems.get(root)!==item)return
const after=decide(id,priceOf,item)
if(after.mark===null)return
if(paint({doc,t,row:root,item,coins:after.coins,mark:after.mark,live:after.live,cardSelector,big,surface:single.id}))drawn+=1}))}}
return{drawn,removed,pending:Promise.all(waiting)}}
function decide(id,priceOf,item=null){
if(sealedOf(item))return{mark:MARK_SEALED,coins:null,ask:false,live:false}
const live=verified.get(id)
if(live)return{mark:MARK_PRICE,coins:live.coins,ask:false,live:true}
const answer=known.get(id)
if(answer===undefined){if(typeof priceOf!=='function')return{mark:null,coins:null,ask:false,live:false}
return{mark:MARK_WAIT,coins:null,ask:!resting(id),live:false}}
if(typeof answer?.then==='function')return{mark:MARK_WAIT,coins:null,ask:false,live:false}
return{mark:MARK_PRICE,coins:answer,ask:false,live:false}}
function askPrice(id,item,priceOf){const request=Promise.resolve().then(()=>priceOf(item))
.then((value)=>{
if(value===undefined)return refuse(id,request)
const coins=typeof value==='number'&&Number.isFinite(value)&&value>0?value:null
if(known.get(id)!==request)return coins
known.set(id,coins)
failedAt.delete(id)
return coins})
.catch(()=>refuse(id,request))
known.set(id,request)
return request}
function refuse(id,request=null){if(request!==null&&known.get(id)!==request)return null
known.delete(id)
failedAt.set(id,nowMs())
return null}
function badgeFace(coins,mark,live){const short=mark===MARK_WAIT?null:shortCoins(coins)
const state=mark===MARK_WAIT?MARK_WAIT:(short===null?MARK_NONE:MARK_PRICE)
return{short,state,proven:state===MARK_PRICE&&live===true}}
function alreadyPainted(row,item,coins,mark,live){const current=painted.get(row)
if(!current)return false
const{state,proven}=badgeFace(coins,mark,live)
return current.item===item&&current.coins===coins&&current.mark===state
&&current.live===proven&&current.epoch===epoch}
function paint({doc,t,row,item,coins,mark=MARK_PRICE,live=false,cardSelector=CARD_SELECTOR,big=false,surface=null}){
const{short,state,proven}=badgeFace(coins,mark,live)
const current=painted.get(row)
if(current&&current.item===item&&current.coins===coins&&current.mark===state&&current.live===proven&&current.epoch===epoch)return false
current?.node?.remove?.()
const shown=face(t,{state,coins,live:proven})
const text=shown.text
const card=row.querySelector?.(cardSelector)??null
if(!card){painted.delete(row)
return false}
ensureSidebarStyles(doc)
host(doc,card,surface)
const shape=[big?'fut-price-badge fut-price-badge--big':'fut-price-badge',state===MARK_PRICE?'':QUIET_CLASS].filter(Boolean).join(' ')
const title=shown.title
const marks={futPriceBadge:state===MARK_PRICE?String(Math.round(coins)):'',
futPriceBadgeId:String(definitionOf(item)),futPriceBadgeMark:state}
if(proven)marks.futPriceBadgeLive='1'
const pressable=state!==MARK_WAIT&&safeMinBin(lastActive)
if(pressable)marks.futPriceBadgePress='1'
const node=el(doc,'div',{class:shape,text,attrs:{title},dataset:marks})
explain(card,title,definitionOf(item))
listen(node,item)
card.appendChild(node)
painted.set(row,{item,coins,mark:state,live:proven,node,epoch})
return true}
function listen(node,item){if(typeof node?.addEventListener!=='function')return false
node.addEventListener('click',(event)=>{
if(node?.dataset?.futPriceBadgePress!=='1')return
try{event?.preventDefault?.()
event?.stopPropagation?.()}catch{/* жест важнее его отмены */}
press(node,item)})
return true}
function press(node,item){if(node?.dataset?.futPriceBadgePress!=='1')return false
if(node?.dataset?.futPriceBadgeBusy==='1')return false
const door=lastMeasure
if(typeof door!=='function')return false
if(node?.dataset)node.dataset.futPriceBadgeBusy='1'
const free=()=>{if(node?.dataset)delete node.dataset.futPriceBadgeBusy}
let answer=null
try{answer=door(item)}catch{free()
return false}
if(answer&&typeof answer.then==='function')answer.then(free,free)
else free()
return true}
function host(doc,card,surface){if(card.dataset?.futPriceBadgeHost==='1')return
const position=hostPosition(doc,card,surface)
if(position!=='static'||!card.style)return
card.dataset.futPriceBadgeHost='1'
card.dataset.futPriceBadgePosition=card.style.position??''
card.style.position='relative'}
let hostMemo=new Map()
let hostMemoEpoch=-1
let hostMemoDoc=null
function hostPosition(doc,card,surface){if(hostMemoEpoch!==epoch||hostMemoDoc!==doc){hostMemo=new Map()
hostMemoEpoch=epoch
hostMemoDoc=doc}
const key=String(surface??'?')+'|'+String(card.className??'')
const known=hostMemo.get(key)
if(known!==undefined)return known
let position=''
try{position=doc?.defaultView?.getComputedStyle?.(card)?.position??''}catch{position=''}
hostMemo.set(key,position)
return position}
export function priceBadgeHostMemory(){return hostMemo.size}
function explain(card,title,id=null){if(typeof card?.setAttribute!=='function'||!card.dataset)return false
const mine=id===null||id===undefined?'1':String(id)
if(card.dataset.futPriceBadgeTip!==mine){const now=card.getAttribute?.('title')??''
if(card.dataset.futPriceBadgeTip===undefined||ourTitle.get(card)!==now)card.dataset.futPriceBadgeTitle=now
card.dataset.futPriceBadgeTip=mine}
try{if(card.getAttribute?.('title')!==title)card.setAttribute('title',title)}catch{return false}
ourTitle.set(card,title)
return true}
const ourTitle=new WeakMap()
function restoreTitle(card){if(card?.dataset?.futPriceBadgeTip===undefined)return false
const was=card.dataset.futPriceBadgeTitle??''
try{if(was==='')card.removeAttribute?.('title')
else card.setAttribute?.('title',was)}catch{/* подпись не важнее уборки */}
delete card.dataset.futPriceBadgeTip
delete card.dataset.futPriceBadgeTitle
ourTitle.delete(card)
return true}
function dropRow(row,cardSelector=CARD_SELECTOR){const record=painted.get(row)
painted.delete(row)
const node=row.querySelector?.(BADGE_SELECTOR)??null
if(!node&&!record?.node)return false
node?.remove?.()
record?.node?.remove?.()
restore(row.querySelector?.(cardSelector)??null)
return true}
export function dropAllPriceBadges(doc){return dropAll(doc)}
function dropAll(doc){let count=0
for(const node of doc?.querySelectorAll?.(BADGE_SELECTOR)??[]){restore(node.parentNode)
node.remove?.()
count+=1}
return count}
function restore(card){
restoreTitle(card)
if(card?.dataset?.futPriceBadgeHost!=='1')return
if(card.style)card.style.position=card.dataset.futPriceBadgePosition??''
delete card.dataset.futPriceBadgeHost
delete card.dataset.futPriceBadgePosition}
function safeActive(isActive){try{return typeof isActive==='function'&&isActive(PRICE_BADGE_FEATURE)===true}catch{return false}}
function safeMinBin(isActive){try{return typeof isActive==='function'&&isActive(MIN_BIN_FEATURE)===true}catch{return false}}
