import{el,clear,ensureSidebarStyles} from '../ui/dom.js'
import{smartListPrice,nudgeListPrice,listingBounds,readPriceLimits,normalizeDuration,LIST_DURATIONS,DEFAULT_DURATION,LIST_FEATURE} from './list-actions.js'
import{profitOf,TAX_FEATURE} from './tax-actions.js'
import{MIN_BIN_FEATURE} from './min-bin.js'
import{relistPriceOf,sanitizeRelistPricing} from './transfer-list.js'
import{onPriceBadgeMeasured} from './price-badges.js'
import{LISTING_SELECTOR,LISTING_BODY_SELECTOR,LISTING_ROW_SELECTOR,PRICE_INPUT_SELECTOR,SPINNER_SELECTOR,SPINNER_DOWN_SELECTOR,DURATION_SELECTOR,MENU_SELECTOR,columnOf,rowsHostOf,readListingItem,readListingPrices,applyListingPrices,applyListingDuration,readListingDuration,hasDurationControl,openListingPanel,isListingOpen,overflowBelow,clearNativeAir,trimNativeAir,restoreNativeAir} from '../adapter/quick-list.js'
import{isConceptItem} from '../adapter/concept-item.js'
import{installItemEvents} from '../adapter/item-events.js'
const OURS_SELECTOR='[data-fut-sell-reference],[data-fut-sell-controls],[data-fut-sell-durations],[data-fut-sell-jump],[data-fut-sell-rows]'
const LOCKED_ROW_SELECTOR='[data-fut-sell-row="locked"]'
export const MARKET_ROW_FEATURES=Object.freeze([MIN_BIN_FEATURE])
const BUSY_REASONS=Object.freeze(['budget','rest','throttled'])
export const NUDGE_DOWN=0.95
export const NUDGE_UP=1.15
const NATIVE_LIST_BUTTON='button.primary'
export const CONCEPT_MARK_SELECTOR='[data-fut-sell-concept="1"]'
export function formatStamp(ms){const value=Number(ms)
if(!Number.isFinite(value)||value<=0)return null
const date=new Date(value)
if(Number.isNaN(date.getTime()))return null
const pad=(n)=>String(n).padStart(2,'0')
return{time:`${pad(date.getHours())}:${pad(date.getMinutes())}`,date:`${pad(date.getDate())}.${pad(date.getMonth()+1)}`}}
export function sourceLabel(t,evidence){const provider=typeof evidence?.provider==='string'?evidence.provider:''
const from=provider!==''?provider:(typeof evidence?.from==='string'?evidence.from:'')
if(from==='futgg')return 'FUT.GG'
if(from==='market')return t('sell.source.market')
if(from==='cache')return t('sell.source.cache')
if(from==='source')return t('sell.source.external')
return t('sell.source.unknown')}
export function referenceModel(input={}){const{t,evidence,formatCoins}=input
const coins=Number(evidence?.price)
if(!Number.isFinite(coins)||coins<=0)return{value:null,caption:t('sell.reference.none')}
const stamp=formatStamp(evidence?.observedAt)
const source=sourceLabel(t,evidence)
return{value:formatCoins(coins),caption:stamp?t('sell.reference.caption',{stamp:t('sell.reference.stamp',stamp),source}):source}}
export function repeatedMeasurement(shownAt,observedAt){const was=Number(shownAt)||0
const fresh=Number(observedAt)||0
return fresh>0&&fresh===was}
export function lockedRowModel(t,status){if(status==='active')return null
const feature=t('settings.feature.autoSeller')
const row=(titleKey,reasonKey)=>({title:t(titleKey),caption:'',
hint:t('sell.locked.hint',{feature,reason:lowerFirst(t(reasonKey))})})
if(status==='not-entitled')return row('sell.locked.premium','license.premiumRequired')
if(status==='switched-off')return row('sell.locked.off','settings.switchedOff')
return row('sell.locked.off','common.off')}
function lowerFirst(text){const value=String(text??'')
return value===''?value:value[0].toLowerCase()+value.slice(1)}
export function marketMinRefusal(state={}){if(state.locked===true)return 'locked'
if(state.available!==true)return 'unavailable'
if(state.card!==true)return 'no-card'
if(state.screen!==true)return 'no-screen'
if(state.busy===true)return 'busy'
if(Number(state.wait)>0)return 'wait'
return null}
export const GUARDED_GESTURE=Object.freeze(['pointerdown','mousedown','mouseup','click'])
export function listGuardAnswer(state={}){if(state.concept===true)return 'concept'
if(state.active!==true)return null
if(state.known!==true)return null
if(state.current!==true)return 'stale-panel'
if(state.listed===true)return 'listed'
const proof=state.proof??null
const hand=proof?.human===true&&proof.key===state.key
if(!hand){if(state.price==='none')return null
if(state.price!=='priced')return 'no-price-yet'
if(!proof||proof.key!==state.key)return 'not-filled'}
const fields=state.fields??{}
if(fields.startingBid!==proof.startingBid||fields.buyNow!==proof.buyNow)return 'overwritten'
return null}
export function listAtMinNotice(result){if(result?.ok===true){const coins=Number(result.coins)||0
const stamp=result.repeated===true?formatStamp(result.at):null
if(stamp)return{key:'hotkeys.listAtMin.recent',params:{coins,time:stamp.time}}
return{key:'hotkeys.listAtMin.ready',params:{coins}}}
const reason=String(result?.reason??'')
if(reason==='locked'||reason==='unavailable')return{key:'hotkeys.listAtMin.off',params:{}}
if(reason==='no-card'||reason==='card-changed')return{key:'hotkeys.listAtMin.noCard',params:{}}
if(reason==='no-screen')return{key:'hotkeys.listAtMin.noScreen',params:{}}
if(reason==='wait')return{key:'hotkeys.listAtMin.wait',params:{seconds:Number(result?.seconds)||0}}
if(reason==='busy')return{key:'hotkeys.listAtMin.busy',params:{}}
if(reason==='no-price'||reason==='failed')return{key:'hotkeys.listAtMin.noPrice',params:{}}
return{key:'hotkeys.listAtMin.noFit',params:{}}}
export function createSellSidebar(deps={}){const{doc,t}=deps
const isActive=typeof deps.isActive==='function'?deps.isActive:()=>false
const statusOf=typeof deps.statusOf==='function'?deps.statusOf:()=>'unknown'
const formatCoins=typeof deps.formatCoins==='function'?deps.formatCoins:(coins)=>String(coins)
const priceEvidenceOf=typeof deps.priceEvidenceOf==='function'?deps.priceEvidenceOf:null
const measureMarket=typeof deps.measureMarket==='function'?deps.measureMarket:null
const marketWaitMs=typeof deps.marketWaitMs==='function'?deps.marketWaitMs:()=>0
const listingPricing=typeof deps.listingPricing==='function'?deps.listingPricing:()=>null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
const blank=()=>({key:null,info:null,evidence:null,touched:null,price:'none',refusal:null,duration:DEFAULT_DURATION,opened:false,settled:false,concept:false,listed:false,market:{state:'idle',reason:null,coins:0,at:0}})
let current=blank()
let request=0
const hidden=new WeakMap()
let last=null
let scheduled=false
let bandAsks={called:0,sent:0}
let lastResult={ok:false,reason:'not-run'}
let atMin={ok:false,reason:'not-run'}
let ticker=null
const stopMeasured=onPriceBadgeMeasured((definitionId,coins)=>{try{takeMeasuredPrice(definitionId,coins)}catch(err){onError(err)}})
let listening=null
let air={trimmed:0,records:[],over:0}
const proofs=new WeakMap()
const rootKeys=new WeakMap()
const guarded=new WeakSet()
const commits=new WeakMap()
const committing=new WeakSet()
let gesture=null
let lastGuard={ok:true,reason:'not-run',key:null,presses:0}
const TRACE_BUILD='A104-FIX'
const TRACE_LIMIT=80
const trace={armed:false,at:0,rows:[],views:new WeakMap(),roots:new WeakMap(),seq:{v:0,r:0},trapped:new WeakSet()}
function traceNow(){try{return Number(doc?.defaultView?.performance?.now?.())||Date.now()}catch{return Date.now()}}
function note(line){if(!trace.armed)return
const text=typeof line==='function'?line():line
trace.rows.push(`+${Math.round(traceNow()-trace.at)} ${text}`)
if(trace.rows.length>TRACE_LIMIT)trace.rows.shift()}
function tid(kind,obj){if(!obj||typeof obj!=='object')return `${kind}0`
const map=kind==='v'?trace.views:trace.roots
let id=map.get(obj)
if(!id){trace.seq[kind]+=1
id=trace.seq[kind]
map.set(obj,id)}
return `${kind}${id}`}
function caller(){let stack=''
let limit=10
try{limit=Error.stackTraceLimit
Error.stackTraceLimit=30
stack=String(new Error().stack??'')}catch{}finally{try{Error.stackTraceLimit=limit}catch{}}
const names=[]
let seenEa=false
let ours=false
for(const line of stack.split('\n').slice(1)){if(line.includes('chrome-extension:')){if(seenEa)ours=true
continue}
seenEa=true
const found=/at\s+(?:async\s+)?(?:new\s+)?([^\s(]+)\s*\(/.exec(line)
const name=found?found[1]:'?'
if(/InputControl|SpinnerControl/.test(name))continue
if(names.length<4)names.push(name)}
return `${ours?'we+':''}${names.join('<')||'-'}`}
function fieldsOf(root){const prices=readListingPrices(root)
return `${prices.startingBid??'-'}/${prices.buyNow??'-'}`}
function visibleRoots(){const out=[]
for(const node of Array.from(doc?.querySelectorAll?.(LISTING_SELECTOR)??[])){let seen=true
try{seen=Number(node.getBoundingClientRect?.().height)>0}catch{}
out.push(`${tid('r',node)}:${fieldsOf(node)}${seen?'':'(скрыта)'}`)}
return out.join(',')||'нет'}
function trapInputs(root){if(!trace.armed||!root)return
const win=doc?.defaultView
let desc=null
try{desc=win?.HTMLInputElement?.prototype?Object.getOwnPropertyDescriptor(win.HTMLInputElement.prototype,'value'):null}catch{desc=null}
if(typeof desc?.get!=='function'||typeof desc?.set!=='function')return
Array.from(root.querySelectorAll?.(PRICE_INPUT_SELECTOR)??[]).forEach((input,index)=>{if(trace.trapped.has(input))return
trace.trapped.add(input)
const field=index===0?'bid':'buy'
try{Object.defineProperty(input,'value',{configurable:true,enumerable:true,get(){return desc.get.call(this)},set(value){const was=desc.get.call(this)
desc.set.call(this,value)
const now=desc.get.call(this)
if(now!==was)note(()=>`w ${tid('r',root)} ${field} ${was||'-'}>${now||'-'} ${caller()}`)}})}catch{}})
if(trace.trapped.has(root))return
trace.trapped.add(root)
try{root.addEventListener?.('mouseup',(event)=>{if(!event?.target?.closest?.(NATIVE_LIST_BUTTON))return
note(()=>`list ${tid('r',root)} ${event.isTrusted?'рукой':'клавишей'} поля=${fieldsOf(root)} id=${current.info?.id??'-'} ключ=${current.key??'-'}`)},true)}catch{}}
function checkLater(label){const win=doc?.defaultView
const look=(when)=>{const root=last?.capture?.root??null
note(()=>`${when} ${label} сейчас=${tid('r',root)} поля=${fieldsOf(root)} в_доке=${root?.isConnected===false?0:1} все=[${visibleRoots()}]`)}
try{win?.requestAnimationFrame?.(()=>look('кадр'))}catch{}
try{win?.setTimeout?.(()=>look('500мс'),500)}catch{}}
function arm(){if(trace.armed)return
trace.armed=true
trace.at=traceNow()
note(()=>`взведён ${TRACE_BUILD}`)
const root=last?.capture?.root??null
if(root){trapInputs(root)
note(()=>`сейчас ${tid('v',last.capture.view)} ${tid('r',root)} поля=${fieldsOf(root)} ключ=${current.key??'-'}`)}}
const keyOf=(info)=>(info.id!==null?`i${info.id}`:info.definitionId!==null?`d${info.definitionId}`:null)
const bounds=()=>listingBounds(current.info?.limits??null,current.info?.eaHasNoBand===true)
const record=(result)=>{lastResult=result
return result}
function apply(capture){if(!doc||!capture)return record({ok:false,reason:'no-capture'})
const{item,view,root}=capture
if(!root||typeof root.querySelector!=='function')return record({ok:false,reason:'no-root'})
listenListed()
const info=readListingItem(item)
const before=last?.capture?.root??null
last={capture,info}
if(markConcept(root,item))return keepOffConcept(root,before,info)
if(!isActive(LIST_FEATURE)){restoreDuration(root.querySelector(LISTING_BODY_SELECTOR))
restoreNativeAir(air.records)
air={trimmed:0,records:[],over:0}
stopTicker()
clearOurs(root)
request+=1
current=blank()
return record({ok:false,reason:'locked',row:Boolean(mountLocked(root))})}
const key=keyOf(info)
if(trace.armed){trapInputs(root)
note(()=>`apply id=${info.id??'-'} ${key!==null&&key===current.key?'та_же':'новая'} ${tid('v',view)} ${tid('r',root)} в_доке=${root.isConnected===false?0:1} поля=${fieldsOf(root)} тронута=${isTouched()?1:0} путь=${caller()}`)
checkLater(`после_apply_${tid('r',root)}`)}
if(key===null||key!==current.key){request+=1
proofs.delete(root)
current={...blank(),key,info,duration:readListingDuration(view)??DEFAULT_DURATION,price:priceEvidenceOf&&item?'pending':'none'}}
else{current.info=info
if(current.listed&&backOnSale(item)){current.listed=false
note(()=>`лот вернулся непроданным id=${info.id??'-'} ключ=${key??'-'}`)}}
rootKeys.set(root,key)
guardRoot(root)
askPrice(item)
current.opened=false
current.settled=false
schedule()
return record({ok:true,reason:'pending'})}
function markConcept(root,item){const concept=isConceptItem(item)
try{if(concept)root.dataset.futSellConcept='1'
else if(root.dataset?.futSellConcept!==undefined)delete root.dataset.futSellConcept}catch{}
return concept}
function clearOurs(root){if(!root)return
removeOurs(columnOf(root)?.node)
removeOurs(rowsHostOf(root))
removeOurs(root)}
function keepOffConcept(root,before,info){for(const one of new Set([before,root])){restoreDuration(one?.querySelector?.(LISTING_BODY_SELECTOR)??null)
clearOurs(one)}
restoreNativeAir(air.records)
air={trimmed:0,records:[],over:0}
stopTicker()
request+=1
proofs.delete(root)
const key=keyOf(info)
note(()=>`проектная id=${info.id??'-'} ${tid('r',root)} в_доке=${root.isConnected===false?0:1} колонки нет`)
current={...blank(),key,info,concept:true}
rootKeys.set(root,key)
guardRoot(root)
ensureSidebarStyles(doc)
schedule()
return record({ok:false,reason:'concept'})}
function askPrice(item){if(!priceEvidenceOf||!item)return
const ticket=request
Promise.resolve()
.then(()=>priceEvidenceOf(item))
.then((evidence)=>{if(ticket!==request)return note(()=>'цена чужой_билет')
if(!(Number(evidence?.price)>0)){if(!(Number(current.evidence?.price)>0))current.price='none'
return note(()=>'цена нет_у_источника')}
current.price='priced'
if(!fresher(evidence))return note(()=>`цена не_свежее ${evidence?.price??'-'} сейчас=${tid('v',last?.capture?.view)}`)
current.evidence=evidence
const view=last?.capture?.view??null
const why=isTouched()?'тронута':''
const filled=autoPrice(view)
note(()=>`цена ${evidence?.price??'-'} в ${tid('v',view)} записано=${filled?1:0}${why?'/'+why:''}`)
redraw()
refit()},(err)=>{if(ticket===request&&current.price==='pending')current.price='none'
onError(err)})}
function fresher(evidence){if(!evidence)return false
const was=Number(current.evidence?.observedAt)
if(!current.evidence||!Number.isFinite(was))return true
const now=Number(evidence.observedAt)
return Number.isFinite(now)&&now>was}
function schedule(){if(scheduled)return
scheduled=true
Promise.resolve().then(()=>{scheduled=false
try{settle()}catch(err){onError(err)}})}
function settle(){if(!last)return record({ok:false,reason:'no-capture'})
const{view,root}=last.capture
if(current.concept){if(root.isConnected===false)return record({ok:false,reason:'detached'})
clearOurs(root)
current.settled=true
return record({ok:false,reason:'concept'})}
if(!isActive(LIST_FEATURE))return record({ok:false,reason:'locked',row:Boolean(mountLocked(root))})
if(root.isConnected===false)return record({ok:false,reason:'detached'})
ensureSidebarStyles(doc)
const live=readListingDuration(view)
if(live!==null)current.duration=normalizeDuration(live)
const column=columnOf(root)
const body=root.querySelector(LISTING_BODY_SELECTOR)
const reference=mountReference(column)
const controls=mountControls(body,view,root)
const marketRow=mountRows(root)
try{bandAsks.called+=1
if(last.capture.askBand?.()===true)bandAsks.sent+=1}catch(err){onError(err)}
if(!current.opened){current.opened=true
if(!isListingOpen(root))openListingPanel(view,root)}
const why=current.listed?'выставлена':isTouched()?'тронута':(Number(current.evidence?.price)>0?'':'нет_цены')
const filled=autoPrice(view)
const hand=!filled&&handBack(root)
note(()=>`settle ${tid('v',view)} ${tid('r',root)} записано=${filled?1:0}${why?'/'+why:''}${hand?' рука_вернулась':''} поля=${fieldsOf(root)}`)
render(reference,controls,marketRow)
const air=fitListButton(root,column)
current.settled=true
return record({ok:true,reason:null,reference:Boolean(reference),controls:Boolean(controls),market:Boolean(marketRow),header:column?.header===true,air})}
function refit(){if(!current.settled||!last)return air
const root=last.capture?.root??null
return fitListButton(root,columnOf(root))}
function fitListButton(root,column){restoreNativeAir(air.records)
air={trimmed:0,records:[],over:0}
const button=root?.querySelector?.(NATIVE_LIST_BUTTON)
const host=column?.node
if(!button||!host)return air
const cleared=clearNativeAir(host)
const records=[...cleared.records]
let trimmed=cleared.trimmed
let over=overflowBelow(button)
for(let pass=0;pass<3&&over>0;pass+=1){const result=trimNativeAir({column:host,needed:over})
if(result.trimmed<=0)break
records.push(...result.records)
trimmed+=result.trimmed
over=overflowBelow(button)}
air={trimmed,records,over:Math.max(0,over)}
return air}
function refresh(){if(!last||current.settled)return false
return settle().ok===true}
function autoPrice(view){if(isTouched()||current.listed)return false
const price=relistPriceOf(listingPricing(),current.evidence?.price,current.info?.limits??null,current.info?.eaHasNoBand===true)
if(!price.ok)return false
if(!applyListingPrices(view,price))return false
if(view===(last?.capture?.view??null))seal()
return true}
function isTouched(){const root=last?.capture?.root??null
return current.touched!==null&&current.touched===root}
function seal(human=false){const root=last?.capture?.root??null
if(!root)return
const fields=readListingPrices(root)
proofs.set(root,{key:current.key,startingBid:fields.startingBid,buyNow:fields.buyNow,human})
if(human)current.listed=false}
function humanEdit(root){keepHand(root)
current.refusal=null
touch()}
function keepHand(root){if(!root||current.key===null||rootKeys.get(root)!==current.key)return
const fields=readListingPrices(root)
proofs.set(root,{key:current.key,startingBid:fields.startingBid,buyNow:fields.buyNow,human:true})
current.listed=false}
function awaitRelease(root,hold){if(typeof doc?.addEventListener!=='function')return
const types=['mouseup','touchend','touchcancel']
const done=(event)=>{if(event?.isTrusted===false)return
for(const type of types)doc.removeEventListener?.(type,done,true)
if(!stepOfHand(hold,readListingPrices(root)))return note(()=>`отпускание не шаг руки ${tid('r',root)} было=${hold.start.startingBid??'-'}/${hold.start.buyNow??'-'} поля=${fieldsOf(root)}`)
keepHand(root)}
for(const type of types)doc.addEventListener(type,done,true)}
function holdOf(body,spinner,target,root){const inputs=Array.from(body.querySelectorAll?.(PRICE_INPUT_SELECTOR)??[])
const own=spinner.querySelector?.(PRICE_INPUT_SELECTOR)??null
const field=own!==null&&own===inputs[0]?'startingBid':own!==null&&own===inputs[1]?'buyNow':null
return{field,dir:target?.closest?.(SPINNER_DOWN_SELECTOR)?-1:1,start:readListingPrices(root)}}
function stepOfHand(hold,now){const{field,dir,start}=hold
if(field===null)return now.startingBid===start.startingBid&&now.buyNow===start.buyNow
const was=start[field]
const is=now[field]
if(was!==null&&(is===null||(dir>0?is<was:is>was)))return false
const other=field==='startingBid'?'buyNow':'startingBid'
const before=start[other]
const after=now[other]
if(after===before)return true
if(before===null||after===null)return false
if(field==='startingBid'&&dir>0)return after>before
if(field==='buyNow'&&dir<0)return after<before
return false}
function restoreHand(root){const proof=proofs.get(root)
if(proof?.human!==true)return false
if(!applyListingPrices(last?.capture?.view??null,{startingBid:proof.startingBid,buyNow:proof.buyNow}))return false
keepHand(root)
note(()=>`пара руки вернулась ${tid('r',root)} поля=${fieldsOf(root)}`)
return true}
function handBack(root){if(current.listed||handHeld(root))return false
return restoreHand(root)}
function listRefusalFor(root){const known=rootKeys.has(root)
return listGuardAnswer({concept:root?.dataset?.futSellConcept==='1',active:isActive(LIST_FEATURE),known,current:known&&root===(last?.capture?.root??null)&&rootKeys.get(root)===current.key,listed:current.listed,key:current.key,price:current.price,proof:proofs.get(root)??null,fields:readListingPrices(root)})}
function guardRoot(root){if(!root||guarded.has(root)||typeof root.addEventListener!=='function')return
guarded.add(root)
const onGesture=(event)=>{const button=event?.target?.closest?.(NATIVE_LIST_BUTTON)??null
if(!button)return
if(event?.isTrusted!==false){if(event?.type==='click')sentToEa(root,'рукой')
return}
let decision=gesture!==null&&gesture.button===button?gesture:null
if(decision===null){const reason=listRefusalFor(root)
decision={button,reason,root}
gesture=decision
lastGuard={ok:reason===null,reason:reason??null,key:current.key,presses:lastGuard.presses+1}
note(()=>`страж ${tid('r',root)} ${reason??'пропустил'} поля=${fieldsOf(root)} ключ=${current.key??'-'}`)
if(reason===null)sentToEa(root,'клавишей')
Promise.resolve().then(()=>{if(gesture===decision)gesture=null
try{afterGuard(decision)}catch(err){onError(err)}})}
if(decision.reason===null)return
event.preventDefault?.()
event.stopImmediatePropagation?.()
event.stopPropagation?.()}
for(const type of GUARDED_GESTURE)root.addEventListener(type,onGesture,true)}
function sentToEa(root,how){if(rootKeys.get(root)!==current.key)return
note(()=>`нажатие ушло к EA ${how} ${tid('r',root)} поля=${fieldsOf(root)} ключ=${current.key??'-'}, ждём ответа`)}
function confirmListed(ids){const id=current.info?.id??null
if(id===null||!ids.includes(String(id)))return
current.listed=true
note(()=>`EA выставила id=${id} ключ=${current.key??'-'} поля=${fieldsOf(last?.capture?.root??null)}`)}
function listenListed(){if(listening!==null&&listening.attached)return
const win=doc?.defaultView??null
if(!win)return
const events=installItemEvents(win,(event)=>{if(event?.name==='ITEM_LIST')confirmListed(event.ids)})
listening={ok:!events.missing.includes('ITEM_LIST'),reason:events.reason,attached:events.reason!=='no-dispatcher'&&events.reason!=='no-events',dispose:events.dispose}}
function backOnSale(item){try{const auction=item?.getAuctionData?.()??null
return auction?.isValid?.()===true&&auction?.isExpired?.()===true&&auction?.tradeOwner===true}catch{return false}}
function afterGuard(decision){if(decision.reason===null){if(current.refusal!==null){current.refusal=null
redraw()}
return}
current.refusal=decision.reason
if(isTouched()){if(decision.reason==='overwritten')restoreHand(decision.root)}
else if(current.price==='priced')autoPrice(last?.capture?.view??null)
redraw()
refit()}
function mountReference(column){const host=column?.node
if(!host||typeof host.querySelector!=='function')return null
const existing=host.querySelector('[data-fut-sell-reference]')
if(existing){if(existing.parentElement!==host)place(host,existing)
return existing}
const node=el(doc,'div',{class:'fut-sell-reference',dataset:{futSellReference:'1'}})
place(host,node)
return node}
function place(host,node){if(typeof host.prepend==='function')host.prepend(node)
else host.appendChild(node)
return node}
function mountRows(root){const host=rowsHostOf(root)
if(!host)return null
const group=ensureGroup(host,root)
group.querySelector?.(LOCKED_ROW_SELECTOR)?.remove?.()
return mountMarketRow(group)}
function ensureGroup(host,root){const existing=host.querySelector?.('[data-fut-sell-rows]')??null
const group=existing??el(doc,'div',{class:`fut-sell-rows ${MENU_SELECTOR.slice(1)}`,dataset:{futSellRows:'1'}})
if(group.nextElementSibling!==root)host.insertBefore(group,root)
return group}
function mountLocked(root){const host=rowsHostOf(root)
if(!host||typeof host.insertBefore!=='function')return null
if(!lockedRowModel(t,statusOf(LIST_FEATURE)))return null
ensureSidebarStyles(doc)
const group=ensureGroup(host,root)
const node=group.querySelector?.(LOCKED_ROW_SELECTOR)??place(group,menuRow('locked',()=>{}))
node.setAttribute?.('aria-disabled','true')
renderLockedRow(node)
return node}
function menuRow(kind,onClick){return el(doc,'button',{class:'fut-sell-row',attrs:{type:'button'},dataset:{futSellRow:kind},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{onClick()}catch(err){onError(err)}}}},[el(doc,'span',{class:'btn-text',dataset:{futSellRowText:'1'}}),el(doc,'span',{class:'btn-subtext',dataset:{futSellRowHint:'1'}})])}
function mountMarketRow(group){const existing=group.querySelector('[data-fut-sell-row="market"]')
if(!measureMarket||!MARKET_ROW_FEATURES.every((feature)=>isActive(feature))){existing?.remove?.()
return null}
if(existing)return existing
const node=menuRow('market',()=>checkMarket())
place(group,node)
return node}
function ensureTicker(seconds){if(seconds<=0)return stopTicker()
const win=doc?.defaultView??null
if(ticker!==null||typeof win?.setTimeout!=='function')return false
ticker=win.setTimeout(()=>{ticker=null
try{const node=rowsHostOf(last?.capture?.root??null)?.querySelector?.('[data-fut-sell-row="market"]')??null
if(node)renderMarketRow(node)}catch(err){onError(err)}},1000)
return true}
function stopTicker(){if(ticker===null)return false
try{doc?.defaultView?.clearTimeout?.(ticker)}catch{}
ticker=null
return false}
function waitSeconds(){return Math.ceil(Number(marketWaitMs(last?.capture?.item??null))/1000)||0}
function readiness(){const root=last?.capture?.root??null
return{locked:!isActive(LIST_FEATURE),available:Boolean(measureMarket)&&MARKET_ROW_FEATURES.every((feature)=>isActive(feature)),card:Boolean(last?.capture?.item)&&current.concept!==true,screen:root?.isConnected!==false&&current.settled===true,busy:current.market.state==='busy',wait:waitSeconds()}}
function checkMarket(){if(marketMinRefusal(readiness())!==null){
redraw()
return false}
runMarket(false).catch(onError)
return true}
function runMarket(over){
const seenAt=Number(current.market.at)||0
setMarket({state:'busy',reason:null,at:seenAt})
const ticket=request
const item=last.capture.item
return Promise.resolve()
.then(()=>measureMarket(item))
.then((evidence)=>{
if(ticket!==request)return{ok:false,reason:'card-changed'}
if(!evidence||evidence.ok!==true){setMarket({state:'failed',reason:String(evidence?.reason??'no-answer')})
return{ok:false,reason:'failed'}}
const coins=Number(evidence.price)
if(!Number.isFinite(coins)||coins<=0){setMarket({state:'empty',reason:String(evidence.reason??'no-listings')})
return{ok:false,reason:'no-price'}}
current.evidence=evidence
current.price='priced'
const at=Number(evidence.observedAt)||0
const repeated=repeatedMeasurement(seenAt,at)
setMarket({state:'found',reason:null,coins,at})
const written=over?priceInto(coins):{ok:autoPrice(last?.capture?.view??null),reason:'not-written'}
redraw()
refit()
return written.ok?{ok:true,reason:null,coins,at,repeated,startingBid:written.startingBid,buyNow:written.buyNow}:{ok:false,reason:written.reason,coins}},(err)=>{onError(err)
if(ticket===request)setMarket({state:'failed',reason:String(err?.message??err)})
return{ok:false,reason:'failed'}})}
function priceInto(coins){const price=smartListPrice({reference:coins,limits:current.info?.limits??null,eaSaysNone:current.info?.eaHasNoBand===true})
if(!price.ok)return{ok:false,reason:price.reason}
const restore=clearPrices()
if(!applyListingPrices(last?.capture?.view??null,price)){restore()
return{ok:false,reason:'no-fields'}}
seal(true)
touch()
return{ok:true,reason:null,startingBid:price.startingBid,buyNow:price.buyNow}}
function clearPrices(){const inputs=Array.from(last?.capture?.root?.querySelectorAll?.(PRICE_INPUT_SELECTOR)??[])
const was=inputs.map((input)=>input.value)
for(const input of inputs){try{input.value=''}catch{}}
return()=>{for(const[index,input]of inputs.entries()){try{input.value=was[index]}catch{}}}}
async function priceAtMarketMin(){const state=readiness()
const refused=marketMinRefusal(state)
atMin=refused===null?await runMarket(true):{ok:false,reason:refused,seconds:state.wait}
return atMin}
function setMarket(value){current.market=value
redraw()
return value}
function takeMeasuredPrice(definitionId,coins){if(!last||!current.settled)return false
if(current.concept)return false
if(current.market.state==='busy')return false
const id=Number(definitionId)
if(!Number.isSafeInteger(id)||id<=0)return false
if(current.info?.definitionId!==id)return false
const price=Number(coins)
if(!Number.isFinite(price)||price<=0)return false
const at=Date.now()
current.evidence={price,from:'market',source:'market',observedAt:at}
current.price='priced'
setMarket({state:'found',reason:null,coins:price,at})
const written=priceInto(price)
if(!written.ok)return false
redraw()
refit()
return true}
function mountControls(body,view,root){if(!body||typeof body.querySelector!=='function')return null
mountExtremes(body,view)
mountDuration(body,view)
markTouched(body,root)
const existing=body.querySelector('[data-fut-sell-controls]')
if(existing)return existing
const node=el(doc,'div',{class:'fut-sell-controls',dataset:{futSellControls:'1'}})
const anchor=durationRow(body)??body.querySelector(NATIVE_LIST_BUTTON)
if(anchor&&typeof body.insertBefore==='function')body.insertBefore(node,anchor)
else body.appendChild(node)
return node}
function priceRows(body){return Array.from(body.querySelectorAll?.(LISTING_ROW_SELECTOR)??[])
.filter((row)=>row.querySelector?.(SPINNER_SELECTOR))}
function durationRow(body){return Array.from(body.querySelectorAll?.(LISTING_ROW_SELECTOR)??[])
.find((row)=>row.querySelector?.(DURATION_SELECTOR))??null}
function mountExtremes(body,view){const rows=priceRows(body)
const targets=[{row:rows[0],min:()=>bounds().bidMin,max:()=>bounds().bidMax,write:(value)=>view?.setBidValue?.(value)},{row:rows[1],min:()=>bounds().buyMin,max:()=>bounds().buyMax,write:(value)=>view?.setBuyNowValue?.(value)}]
const edge=(target,pick)=>{const value=pick()
if(!Number.isSafeInteger(value))return false
target.write(value)
return true}
for(const target of targets){const spinner=target.row?.querySelector?.(SPINNER_SELECTOR)
if(!spinner||spinner.querySelector('[data-fut-sell-jump]'))continue
const low=extremeButton('min',()=>edge(target,target.min))
const high=extremeButton('max',()=>edge(target,target.max))
const first=spinner.querySelector(SPINNER_DOWN_SELECTOR)??spinner.firstElementChild
if(first&&typeof spinner.insertBefore==='function')spinner.insertBefore(low,first)
else spinner.appendChild(low)
spinner.appendChild(high)}}
function extremeButton(kind,write){
const text=kind==='min'?'«':'»'
const node=el(doc,'button',{class:'fut-sell-jump',text,attrs:{type:'button'},dataset:{futSellJump:kind},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
try{const edge=write()
if(edge===false)return
seal(true);touch()}catch(err){onError(err)}}}})
nameJump(node)
return node}
function nameJump(node){const title=node.dataset?.futSellJump==='min'?t('sell.toMin'):t('sell.toMax')
if(node.getAttribute?.('title')===title)return
node.setAttribute?.('title',title)
node.setAttribute?.('aria-label',title)}
function mountDuration(body,view){if(!hasDurationControl(view))return null
const row=durationRow(body)
if(!row)return null
const existing=row.querySelector('[data-fut-sell-durations]')
if(existing){paintDurations(existing)
return existing}
const strip=el(doc,'div',{class:'fut-sell-durations',dataset:{futSellDurations:'1'}})
for(const seconds of LIST_DURATIONS){strip.appendChild(el(doc,'button',{class:'fut-sell-duration',text:durationLabel(seconds),attrs:{type:'button'},dataset:{futSellDuration:String(seconds)},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
if(applyListingDuration(view,seconds))current.duration=normalizeDuration(seconds)
paintDurations(strip)}}}))}
row.appendChild(strip)
hideDuration(body)
paintDurations(strip)
return strip}
function durationLabel(seconds){if(seconds===10800)return t('list.duration.10800')
if(seconds===21600)return t('list.duration.21600')
if(seconds===43200)return t('list.duration.43200')
if(seconds===86400)return t('list.duration.86400')
if(seconds===259200)return t('list.duration.259200')
return t('list.duration.3600')}
function paintDurations(strip){for(const button of strip?.querySelectorAll?.('[data-fut-sell-duration]')??[]){const seconds=Number(button.dataset?.futSellDuration)
button.dataset.futSellOn=seconds===current.duration?'1':'0'}}
function hideDuration(body){const picker=body?.querySelector?.(DURATION_SELECTOR)
if(!picker||hidden.has(picker))return
hidden.set(picker,picker.style?.display??'')
if(picker.style)picker.style.display='none'}
function restoreDuration(body){const picker=body?.querySelector?.(DURATION_SELECTOR)
if(!picker||!hidden.has(picker))return
if(picker.style)picker.style.display=hidden.get(picker)
hidden.delete(picker)}
function markTouched(body,root){watchCommits(root)
for(const input of body.querySelectorAll?.(PRICE_INPUT_SELECTOR)??[]){if(input.dataset?.futSellWatched==='1')continue
input.dataset.futSellWatched='1'
input.addEventListener('input',(event)=>{if(event?.isTrusted===true)humanEdit(root)})
input.addEventListener('change',()=>{const held=commits.get(input)===true
commits.delete(input)
if(held)humanEdit(root)
else note(()=>`change без пары руки ${tid('r',root)} поля=${fieldsOf(root)}`)})}
for(const spinner of body.querySelectorAll?.(SPINNER_SELECTOR)??[]){if(spinner.dataset?.futSellWatched==='1')continue
spinner.dataset.futSellWatched='1'
const hand=(event)=>{if(event?.isTrusted===false)return
const target=event?.target??null
if(target?.closest?.('[data-fut-sell-jump]')||target?.closest?.(PRICE_INPUT_SELECTOR))return
const hold=holdOf(body,spinner,target,root)
humanEdit(root)
awaitRelease(root,hold)}
spinner.addEventListener('mousedown',hand,true)
spinner.addEventListener('touchstart',hand,true)}}
function watchCommits(root){if(!root||committing.has(root)||typeof root.addEventListener!=='function')return
committing.add(root)
root.addEventListener('change',(event)=>{const input=event?.target??null
if(input?.matches?.(PRICE_INPUT_SELECTOR)!==true)return
commits.set(input,handHeld(root))},true)}
function handHeld(root){const proof=proofs.get(root)
if(proof?.human!==true)return false
const fields=readListingPrices(root)
return fields.startingBid===proof.startingBid&&fields.buyNow===proof.buyNow}
function touch(){if(trace.armed&&!isTouched())note(()=>`тронута ${caller()}`)
current.touched=last?.capture?.root??null
redraw()}
function redraw(){if(!last)return
const root=last.capture?.root??null
const column=columnOf(root)?.node??null
const host=rowsHostOf(root)
render(column?.querySelector?.('[data-fut-sell-reference]')??null,root?.querySelector?.('[data-fut-sell-controls]')??null,host?.querySelector?.('[data-fut-sell-row="market"]')??null,host?.querySelector?.(LOCKED_ROW_SELECTOR)??null)}
function relabel(){if(!last)return false
const root=last.capture?.root??null
for(const node of root?.querySelectorAll?.('[data-fut-sell-jump]')??[])nameJump(node)
for(const node of root?.querySelectorAll?.('[data-fut-sell-duration]')??[]){const label=durationLabel(Number(node.dataset?.futSellDuration))
if(node.textContent!==label)node.textContent=label}
redraw()
return true}
function render(reference,controls,marketRow,lockedRow){if(reference)renderReference(reference)
if(controls)renderControls(controls)
if(marketRow)renderMarketRow(marketRow)
if(lockedRow)renderLockedRow(lockedRow)}
function renderLockedRow(node){const model=lockedRowModel(t,statusOf(LIST_FEATURE))
if(!model)return node.remove?.()
renderRow(node,model.title,model.caption)
if(node.getAttribute?.('title')!==model.hint){node.setAttribute?.('title',model.hint)
node.setAttribute?.('aria-label',model.hint)}}
function renderRow(node,title,caption){const label=node.querySelector?.('[data-fut-sell-row-text]')
const hint=node.querySelector?.('[data-fut-sell-row-hint]')
if(label&&label.textContent!==title)label.textContent=title
if(hint&&hint.textContent!==caption)hint.textContent=caption}
function renderMarketRow(node){const seconds=waitSeconds()
renderRow(node,seconds>0?t('sell.market.checkWait',{name:t('sell.market.check'),seconds}):t('sell.market.check'),marketHint())
node.dataset.futSellBusy=current.market.state==='busy'?'1':'0'
node.dataset.futSellFound=current.market.state==='found'?'1':'0'
ensureTicker(seconds)}
function marketHint(){const state=current.market.state
if(state==='found')return formatCoins(current.market.coins)
if(state==='busy')return t('sell.market.busy')
if(state==='empty')return t('sell.market.empty')
if(state==='failed')return BUSY_REASONS.includes(current.market.reason)?t('sell.market.often'):t('sell.market.failed')
return ''}
function renderReference(node){const model=referenceModel({t,evidence:current.evidence,formatCoins})
clear(node)
if(model.value)node.appendChild(el(doc,'span',{class:'fut-sell-value',text:model.value,dataset:{futSellValue:'1'}}))
node.appendChild(el(doc,'span',{class:'fut-sell-caption',text:model.caption,dataset:{futSellCaption:'1'}}))}
function renderControls(node){clear(node)
const root=last?.capture?.root??null
const input=root?.querySelector?.(PRICE_INPUT_SELECTOR)??null
const height=Math.round(input?.getBoundingClientRect?.().height??0)
if(height>0)node.style.setProperty('--fut-sell-row',`${height}px`)
const radius=nativeRadius(input)
if(radius)node.style.setProperty('--fut-sell-radius',radius)
node.appendChild(el(doc,'div',{class:'fut-sell-nudges',dataset:{futSellNudges:'1'}},[nudgeButton('down',NUDGE_DOWN),nudgeButton('up',NUDGE_UP)]))
const prices=readListingPrices(last?.capture?.root??null)
const paid=Number.isFinite(current.info?.lastSalePrice)&&current.info.lastSalePrice>0?Math.round(current.info.lastSalePrice):null
const profit=isActive(TAX_FEATURE)?profitOf(prices.buyNow,paid??0):null
if(profit&&paid===null)node.appendChild(profitRow(t('sell.profit'),t('sell.profitNoBuy',{coins:`+${formatCoins(profit.coins)}`}),null))
else if(profit)node.appendChild(profitRow(t('sell.profit'),t('sell.profitValue',{coins:`${profit.coins<0?'−':'+'}${formatCoins(Math.abs(profit.coins))}`,percent:profit.percent}),profit.positive))
if(current.refusal!==null)node.appendChild(el(doc,'div',{class:'fut-sell-money',dataset:{futSellGuard:current.refusal,futSellPositive:'0'}},[el(doc,'span',{class:'fut-sell-money-label',text:t('sell.guard.title')}),el(doc,'span',{class:'fut-sell-money-value',text:t('sell.guard.hint')})]))}
function nativeRadius(input){if(!input)return ''
try{const value=doc?.defaultView?.getComputedStyle?.(input)?.borderRadius??''
return typeof value==='string'&&value!==''&&value!=='0px'?value:''}catch{return ''}}
function profitRow(label,value,positive){const node=el(doc,'div',{class:'fut-sell-money',dataset:{futSellProfit:'1'}},[el(doc,'span',{class:'fut-sell-money-label',text:label}),el(doc,'span',{class:'fut-sell-money-value',text:value})])
if(positive!==null)node.dataset.futSellPositive=positive?'1':'0'
return node}
function nudgeButton(kind,factor){const label=kind==='down'?t('sell.nudgeDown'):t('sell.nudgeUp')
return el(doc,'button',{class:'fut-sell-nudge',text:label,attrs:{type:'button'},dataset:{futSellNudge:kind},on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
const root=last?.capture?.root??null
const next=nudgeListPrice({buyNow:readListingPrices(root).buyNow,factor,limits:current.info?.limits??null,eaSaysNone:current.info?.eaHasNoBand===true})
if(next.ok&&applyListingPrices(last?.capture?.view??null,next)){seal(true)
touch()}}}})}
function removeOurs(scope){for(const node of scope?.querySelectorAll?.(OURS_SELECTOR)??[])node.remove?.()}
function spaceReport(column,root){if(!column||typeof column.getBoundingClientRect!=='function')return null
const win=doc?.defaultView??null
if(typeof win?.getComputedStyle!=='function')return null
const stop=root?.querySelector?.(NATIVE_LIST_BUTTON)??null
const rows=[]
const walk=(node,depth)=>{if(rows.length>=24||!node?.getBoundingClientRect)return
for(const child of node.children??[]){if(rows.length>=24)return
const box=child.getBoundingClientRect()
if(box.height>=4){let style=null
try{style=win.getComputedStyle(child)}catch{}
const px=(value)=>Math.round(Number.parseFloat(value)||0)
rows.push({tag:`${child.tagName}.${String(child.className||'').split(/\s+/)[0]||'-'}`,h:Math.round(box.height),mt:px(style?.marginTop),mb:px(style?.marginBottom),pt:px(style?.paddingTop),pb:px(style?.paddingBottom),ours:Boolean(child.dataset?.futSellRows||child.dataset?.futSellReference)})}
if(child===stop)return
if(depth<3)walk(child,depth+1)}}
walk(column,1)
return rows}
return{apply,refresh,relabel,priceAtMarketMin,
state:()=>{
arm()
const root=last?.capture?.root??null
const column=columnOf(root)
const size=(node)=>{const box=typeof node?.getBoundingClientRect==='function'?node.getBoundingClientRect():null
return node?{w:Math.round(box?.width??0),h:Math.round(box?.height??0),x:Math.round(box?.left??0),y:Math.round(box?.top??0)}:null}
const count=(selector)=>doc?.querySelectorAll?.(selector)?.length??0
return{active:isActive(LIST_FEATURE),
status:statusOf(LIST_FEATURE),lastResult,key:current.key,concept:current.concept===true,settled:current.settled,connected:root?.isConnected??null,opened:current.opened,touched:isTouched(),listed:current.listed,
band:(()=>{let raw=null
try{raw=last?.capture?.item?.getPriceLimits?.()??null}catch{return 'бросок'}
if(raw===null||raw===undefined)return null
return{minimum:raw.minimum??null,maximum:raw.maximum??null}})(),
bandOk:readPriceLimits(current.info?.limits??null)!==null,
eaSaysNoBand:current.info?.eaHasNoBand===true,
bandAsks:{...bandAsks},
priceSays:(()=>{const coins=current.evidence?.price
const answer=relistPriceOf(listingPricing(),coins,current.info?.limits??null,current.info?.eaHasNoBand===true)
const reference=Number.isFinite(Number(coins))?Math.round(Number(coins)):null
return answer.ok===true
?{ok:true,startingBid:answer.startingBid,buyNow:answer.buyNow,reference}
:{ok:false,reason:answer.reason,reference}})(),
listing:{...sanitizeRelistPricing(listingPricing())},
confirm:{ok:listening?.ok===true,reason:listening===null?'not-run':listening.reason},priceState:current.price,refusal:current.refusal,guard:{...lastGuard},
kept:((proof)=>proof&&proof.key===current.key?{startingBid:proof.startingBid,buyNow:proof.buyNow,hand:proof.human===true}:null)(root?proofs.get(root):null),duration:current.duration,price:current.evidence?.price??null,source:current.evidence?.from??null,limits:current.info?.limits??null,column:column?{header:column.header,tag:column.node?.tagName??null,className:String(column.node?.className??'')}:null,
market:{state:current.market.state,coins:current.market.coins??0,reason:current.market.reason??null,wait:waitSeconds(),ticking:ticker!==null,available:Boolean(measureMarket),
atMin:{...atMin},refusal:marketMinRefusal(readiness())},
air:{trimmed:air.trimmed,touched:air.records.length,over:air.over},
space:spaceReport(column?.node??null,root),
nodes:{reference:count('[data-fut-sell-reference]'),controls:count('[data-fut-sell-controls]'),jumps:count('[data-fut-sell-jump]'),nudges:count('[data-fut-sell-nudge]'),durations:count('[data-fut-sell-duration]'),rows:count('[data-fut-sell-row]')},size:{reference:size(doc?.querySelector?.('[data-fut-sell-reference]')),controls:size(doc?.querySelector?.('[data-fut-sell-controls]')),nudge:size(doc?.querySelector?.('[data-fut-sell-nudge]')),row:size(doc?.querySelector?.('[data-fut-sell-row]'))},styles:{theme:Boolean(doc?.getElementById?.('fut-companion-theme')),sidebar:Boolean(doc?.getElementById?.('fut-companion-sidebar'))},
trace:{build:TRACE_BUILD,armed:trace.armed,rows:[...trace.rows],text:[`сборка ${TRACE_BUILD}`,...trace.rows].join('\n')}}},
dispose(){const root=last?.capture?.root??null
listening?.dispose?.()
listening=null
stopMeasured()
stopTicker()
restoreDuration(root?.querySelector?.(LISTING_BODY_SELECTOR)??null)
restoreNativeAir(air.records)
air={trimmed:0,records:[],over:0}
clearOurs(root)
try{if(root?.dataset?.futSellConcept!==undefined)delete root.dataset.futSellConcept}catch{}
last=null
current=blank()}}}
