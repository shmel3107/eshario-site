import{el,ensureTheme,ensureStylesheet} from '../ui/dom.js'
import{ensureControls,logoMark} from '../ui/controls.js'
export const HUB_BUTTON_MARK='futHubClaim'
const HUB_STYLESHEET=new URL('../ui/home-hub.css',import.meta.url).href
const HUB_LINK_ID='fut-companion-home-hub'
export function createHubButton(deps={}){const doc=deps.doc
if(!doc||typeof doc.createElement!=='function'){throw new Error('hub-button: нужен документ')}
const t=typeof deps.t==='function'?deps.t:(key)=>key
const flow=deps.flow??null
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let root=null
let node=null
let label=null
let busy=false
const counts={shown:0,hidden:0,presses:0}
function styles(){try{ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,HUB_STYLESHEET,HUB_LINK_ID)}catch(err){onError(err)}}
function ensureNode(){const found=root?.querySelector?.('[data-fut-hub-claim="1"]')??null
if(found!==null&&found===node)return node
if(found!==null){node=found
label=found.querySelector('.fx-hub-claim-text')
return node}
styles()
label=el(doc,'span',{class:'fx-hub-claim-text'})
node=el(doc,'button',{class:'fx-action fx-hub-claim',dataset:{futHubClaim:'1'},
attrs:{type:'button'},
on:{
pointerdown:(event)=>{event.stopPropagation()},
mousedown:(event)=>{event.stopPropagation()},
click:(event)=>{event.stopPropagation()
event.preventDefault()
press()}}},[logoMark(doc),label])
root.appendChild(node)
return node}
function drop(){try{const found=root?.querySelector?.('[data-fut-hub-claim="1"]')??null
if(found?.remove)found.remove()}catch(err){onError(err)}
node=null
label=null}
function write(target,text){if(target&&target.textContent!==text)target.textContent=text}
function paint(view){if(node===null||label===null)return
if(busy){write(label,t('hubRewards.button.busy',{done:view.done,total:view.total}))
if(node.disabled!==true)node.disabled=true
return}
const none=!(Number.isSafeInteger(view.count)&&view.count>0)
write(label,none?t('hubRewards.button.none'):t('hubRewards.button.idle',{count:view.count}))
if(node.disabled!==none)node.disabled=none
const title=view.choice>0?t('hubRewards.button.choiceLeft',{count:view.choice}):''
if(node.title!==title)node.title=title}
function progress(step){busy=step?.running===true
if(!busy){refresh()
return}
paint({count:0,choice:0,done:step?.done??0,total:step?.total??0})}
function press(){if(flow===null||busy||node?.disabled===true)return
counts.presses+=1
try{const done=flow.run()
if(done&&typeof done.then==='function'){done.then(()=>{refresh()}).catch((err)=>{onError(err)
refresh()})}}catch(err){onError(err)
refresh()}}
function refresh(){try{if(root===null||typeof root.appendChild!=='function')return{show:false,reason:'no-tile'}
const view=flow===null?{ok:false,reason:'unavailable'}:flow.view()
if(view?.ok!==true){counts.hidden+=1
drop()
return{show:false,reason:view?.reason??'nothing'}}
ensureNode()
busy=view.running===true
paint({...view,done:0,total:view.count})
counts.shown+=1
return{show:true,reason:null,count:view.count}}catch(err){onError(err)
return{show:false,reason:'failed'}}}
return{
apply(shown){root=shown?.root??null
return refresh()},
refresh,progress,
relabel(){refresh()},
state:()=>({attached:root!==null,busy,counts:{...counts}}),
dispose(){drop()
root=null}}}
