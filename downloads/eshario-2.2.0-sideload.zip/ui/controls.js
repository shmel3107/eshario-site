import{ensureTheme,ensureStylesheet} from './dom.js'
export const CONTROLS_STYLESHEET=new URL('./controls.css',import.meta.url).href
export const CONTROLS_LINK_ID='fut-companion-controls'
export function ensureControls(doc){ensureTheme(doc)
return ensureStylesheet(doc,CONTROLS_STYLESHEET,CONTROLS_LINK_ID)}
export{LOGO_SRC,MARK_HEIGHT_PX,MARK_CLASS,logoMark,SITE_URL,LOGO_LINK_MARK,logoLink} from './dom.js'
