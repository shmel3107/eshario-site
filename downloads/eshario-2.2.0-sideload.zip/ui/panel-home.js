import{el} from './dom.js'
import{logoLink} from './controls.js'
export function renderLever(doc,lever,onOrgan){if(!lever)return null
const id='fut-companion-day-x'
const input=el(doc,'input',{attrs:{type:'checkbox',id},dataset:{dayX:'toggle'},on:{change:(event)=>onOrgan(lever,Boolean(event?.target?.checked))}})
input.checked=lever.value===true
const status=lever.value===true
?el(doc,'div',{class:'day-x-status',dataset:{dayXStatus:'off'},text:lever.onLabel})
:(lever.mounted===false
?el(doc,'div',{class:'day-x-status',dataset:{dayXStatus:'reload'},text:lever.reloadLabel})
:null)
return el(doc,'section',{class:'day-x',dataset:{dayXRow:'1'}},[el(doc,'div',{class:'day-x-head'},[logoLink(doc),el(doc,'span',{class:'day-x-title',text:lever.title})]),el(doc,'div',{class:'row'},[input,el(doc,'label',{text:lever.label,attrs:{for:id,title:lever.hintFull}})]),el(doc,'div',{class:'day-x-hint',text:lever.hint??''}),status].filter(Boolean))}
