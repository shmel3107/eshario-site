import{el,ensureTheme,ensureStylesheet} from './dom.js'
import{ensureControls,logoMark} from './controls.js'
export const LOADER_ID='futweb-loader'
export const NATIVE_READY_SELECTOR='button.ut-tab-bar-item'
export const SPLASH_ID='fut-companion-boot'
export const SPLASH_STYLESHEET=new URL('./boot-splash.css',import.meta.url).href
export const SPLASH_LINK_ID='fut-companion-boot-splash'
export function createBootSplash(deps={}){const doc=deps.doc??null
const win=deps.win??doc?.defaultView??null
const t=typeof deps.t==='function'?deps.t:(key)=>key
const onError=typeof deps.onError==='function'?deps.onError:()=>{}
let node=null
let line=null
let gone=false
let observer=null
let said={key:null,params:null}
let holding=false
const stats={mounted:false,hidden:false,attempts:0,says:0}
const loaderVisible=()=>{const loader=doc?.getElementById?.(LOADER_ID)
if(!loader)return false
const display=loader.style?.display
if(display==='none')return false
const box=loader.getBoundingClientRect?.()
return box?Number(box.height)>0:true}
const nativeReady=()=>{const buttons=doc?.querySelectorAll?.(NATIVE_READY_SELECTOR)
return Array.from(buttons??[]).some((node)=>{const box=node?.getBoundingClientRect?.()
return box?Number(box.height)>0:true})}
function ensure(){if(gone||node!==null)return false
stats.attempts+=1
const loader=doc?.getElementById?.(LOADER_ID)
if(!loader||typeof doc.createElement!=='function')return false
if(nativeReady()&&!holding){gone=true
return false}
try{ensureTheme(doc)
ensureControls(doc)
ensureStylesheet(doc,SPLASH_STYLESHEET,SPLASH_LINK_ID)
const mark=logoMark(doc)
mark.setAttribute('alt','')
mark.setAttribute('aria-hidden','true')
line=el(doc,'span',{class:'fx-boot-line',text:said.key===null?'':t(said.key,said.params??{})})
node=el(doc,'div',{attrs:{id:SPLASH_ID,role:'status','aria-live':'polite'},class:'fx-boot'},[mark,line])
loader.parentNode?.insertBefore?.(node,loader.nextSibling)
stats.mounted=true}catch(err){onError(err)
node=null
line=null
return false}
watch()
return true}
function watch(){if(observer!==null)return
const Observer=win?.MutationObserver
const root=doc?.body??doc?.documentElement
if(typeof Observer!=='function'||!root)return
try{observer=new Observer(()=>{if(nativeReady()&&!holding)hide()})
observer.observe(root,{childList:true,subtree:true})}catch(err){onError(err)
observer=null}}
function hide(){gone=true
try{observer?.disconnect?.()}catch(err){onError(err)}
observer=null
try{node?.remove?.()}catch(err){onError(err)}
node=null
line=null
stats.hidden=true}
return{
ensure,
say(key,params){said={key,params:params??{}}
stats.says+=1
if(gone)return false
ensure()
if(line===null)return false
try{line.textContent=t(key,said.params)}catch(err){onError(err)
return false}
return true},
hold(){holding=true
return true},
hide,
loaderVisible,
nativeReady,
state(){return{...stats,gone,holding,said:said.key,mounted:node!==null,loaderVisible:loaderVisible(),nativeReady:nativeReady()}},
dispose(){hide()}}}
