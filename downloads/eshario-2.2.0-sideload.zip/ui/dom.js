export function el(doc,tag,props={},children=[]){const node=doc.createElement(tag)
if(props.class)node.className=props.class
if(props.text!==undefined)node.textContent=String(props.text)
for(const[name,value]of Object.entries(props.attrs??{})){node.setAttribute(name,String(value))}
for(const[name,value]of Object.entries(props.dataset??{})){node.dataset[name]=String(value)}
for(const[type,handler]of Object.entries(props.on??{})){node.addEventListener(type,handler)}
for(const child of children){if(child===null||child===undefined||child===false)continue
node.appendChild(child)}
return node}
export const THEME_STYLESHEET=new URL('./theme.css',import.meta.url).href
export const SIDEBAR_STYLESHEET=new URL('./sidebar.css',import.meta.url).href
export const SBC_STRIP_STYLESHEET=new URL('./sbc-strip.css',import.meta.url).href
export const SQUAD_STYLESHEET=new URL('./squad.css',import.meta.url).href
export const SBC_WINDOW_STYLESHEET=new URL('./sbc-window.css',import.meta.url).href
export const THEME_LINK_ID='fut-companion-theme'
export const SIDEBAR_LINK_ID='fut-companion-sidebar'
export const SBC_WINDOW_LINK_ID='fut-companion-sbc-window'
export const SBC_STRIP_LINK_ID='fut-companion-sbc-strip'
export const SQUAD_LINK_ID='fut-companion-squad'
export function ensureStylesheet(doc,href,id){try{return attachStylesheet(doc,href,id)}catch{return null}}
function attachStylesheet(doc,href,id){const head=doc?.head??doc?.documentElement
if(!head||typeof doc.createElement!=='function')return null
const existing=doc.getElementById?.(id)
if(existing)return existing
const link=el(doc,'link',{attrs:{id,rel:'stylesheet',href}})
head.appendChild(link)
return link}
export function ensureTheme(doc){return ensureStylesheet(doc,THEME_STYLESHEET,THEME_LINK_ID)}
export function ensureSidebarStyles(doc){ensureTheme(doc)
return ensureStylesheet(doc,SIDEBAR_STYLESHEET,SIDEBAR_LINK_ID)}
export function ensureSbcWindowStyles(doc){ensureTheme(doc)
return ensureStylesheet(doc,SBC_WINDOW_STYLESHEET,SBC_WINDOW_LINK_ID)}
export function ensureSbcStripStyles(doc){ensureTheme(doc)
return ensureStylesheet(doc,SBC_STRIP_STYLESHEET,SBC_STRIP_LINK_ID)}
export function ensureSquadStyles(doc){ensureTheme(doc)
return ensureStylesheet(doc,SQUAD_STYLESHEET,SQUAD_LINK_ID)}
export const LOGO_SRC=new URL('../assets/logo.png',import.meta.url).href
export const MARK_HEIGHT_PX=15
export const MARK_CLASS='fx-mark'
export function logoMark(doc,className){const classes=className?`${MARK_CLASS} ${className}`:MARK_CLASS
return el(doc,'img',{class:classes,attrs:{src:LOGO_SRC,alt:'ESHArio'}})}
export const SITE_URL='https://eshario.com'
export const LOGO_LINK_MARK='futLogo'
export function logoLink(doc,className){const classes=className?`fx-mark-link ${className}`:'fx-mark-link'
return el(doc,'a',{class:classes,
attrs:{href:SITE_URL,target:'_blank',rel:'noopener noreferrer','aria-label':'ESHArio'},
dataset:{[LOGO_LINK_MARK]:'1'}},[logoMark(doc)])}
export function clear(node){while(node.firstChild)node.removeChild(node.firstChild)}
export function replaceChildren(node,child){clear(node)
if(child)node.appendChild(child)
return node}
