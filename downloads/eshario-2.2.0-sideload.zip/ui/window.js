import{el,ensureStylesheet} from './dom.js'
import{ensureControls,logoLink} from './controls.js'
export const WINDOW_STYLESHEET=new URL('./window.css',import.meta.url).href
export const WINDOW_LINK_ID='fut-companion-window'
export const WINDOW_BOX_CLASS='fx-hk-capture-box'
export const WINDOW_OVERLAY_CLASS='fx-hk-capture'
export const WINDOW_TITLE_CLASS='fx-hk-help-title'
export const WINDOW_TITLE_TEXT_CLASS='fx-hk-title-text'
export const WINDOW_CLOSE_CLASS='fx-hk-close'
export const WINDOW_ROW_CLASS='fx-hk-capture-row'
export const WINDOW_BUTTON_CLASS='fx-action fx-hk-btn'
export const WINDOW_CLOSE_MARK='futWindowClose'
export const WINDOW_ANCHOR_ATTR='futWindowAnchor'
let openWindows=[]
const windowAlive=(one,doc)=>one.doc===doc&&one.host?.isConnected===true
export function noteWindow(list,entry){const mine=list.filter((one)=>one.doc===entry.doc)
const at=mine.findIndex((one)=>one.mark===entry.mark)
if(at>=0){const next=[...mine]
next[at]=entry
return next}
return [...mine.filter((one)=>one.host?.isConnected===true),entry]}
export function ourWindowOpen(doc){return topWindow(openWindows,doc)!==null}
export function topWindow(list,doc){for(let i=list.length-1;i>=0;i-=1){
if(windowAlive(list[i],doc))return list[i]}
return null}
let raised=null
export function onWindowRaised(hand){raised=typeof hand==='function'?hand:null}
export function noteWindowRaised(){try{raised?.()}catch{/* док покажется на следующем окне */}}
const ESCAPED=new WeakSet()
function ensureEscape(doc){if(typeof doc?.addEventListener!=='function')return
if(ESCAPED.has(doc))return
ESCAPED.add(doc)
let claimed=false
doc.addEventListener('keydown',(event)=>{if(event?.key!=='Escape')return
const top=topWindow(openWindows,doc)
if(top===null)return
claimed=true
event.preventDefault?.()
event.stopPropagation?.()
try{top.back()}catch{}},true)
doc.addEventListener('keyup',(event)=>{if(claimed!==true)return
if(event?.key!=='Escape'){claimed=false
return}
claimed=false
event.preventDefault?.()
event.stopPropagation?.()},true)
const view=doc.defaultView??null
if(typeof view?.addEventListener==='function')view.addEventListener('blur',()=>{claimed=false})}
function liftLater(host,doc){const later=typeof queueMicrotask==='function'
?queueMicrotask
:(hand)=>Promise.resolve().then(hand)
const lift=()=>{try{if(host?.isConnected!==true)return
if(typeof host.getRootNode==='function'&&host.getRootNode()!==doc)return
if(typeof host.showPopover!=='function'){host.dataset[WINDOW_ANCHOR_ATTR]='page'
return}
host.setAttribute('popover','manual')
host.showPopover()
host.dataset[WINDOW_ANCHOR_ATTR]='top-layer'}catch(err){try{host.removeAttribute('popover')}catch{}
try{host.dataset[WINDOW_ANCHOR_ATTR]='page'}catch{}}}
later(()=>{lift()
noteWindowRaised()})}
const CLOSE_GLYPH='✕'
export function ensureWindow(doc){ensureControls(doc)
return ensureStylesheet(doc,WINDOW_STYLESHEET,WINDOW_LINK_ID)}
export function modalHead(doc,shape={}){const text=shape.title===undefined?'':String(shape.title)
const close=el(doc,'button',{class:WINDOW_CLOSE_CLASS,text:CLOSE_GLYPH,
attrs:{type:'button','aria-label':String(shape.closeLabel??text)},
dataset:{[WINDOW_CLOSE_MARK]:'1'},
on:{click:(event)=>{event?.preventDefault?.()
event?.stopPropagation?.()
shape.onClose?.()}}})
return el(doc,'div',{class:WINDOW_TITLE_CLASS},
[logoLink(doc),el(doc,'span',{class:WINDOW_TITLE_TEXT_CLASS,text}),
...(Array.isArray(shape.tools)?shape.tools:[]),close].filter(Boolean))}
export function modalBox(doc,shape,children){ensureWindow(doc)
let host=null
const back=()=>{if(typeof shape.onBack==='function')shape.onBack()
else host?.remove?.()}
const box=el(doc,'div',{class:shape.box??WINDOW_BOX_CLASS,
dataset:shape.boxMark?{[shape.boxMark]:'1'}:{},
on:typeof shape.onKey==='function'?{keydown:shape.onKey}:{}},
[modalHead(doc,{title:shape.title,closeLabel:shape.closeLabel,tools:shape.tools,onClose:back}),
...children].filter(Boolean))
host=el(doc,'div',{class:shape.overlay??WINDOW_OVERLAY_CLASS,dataset:{[shape.mark]:shape.value??'1'},
on:{click:(event)=>{if(event?.target===host)back()}}},[box])
if(shape.lift===true)liftLater(host,doc)
openWindows=noteWindow(openWindows,{mark:shape.mark,host,back,doc})
ensureEscape(doc)
return host}
export function modalButtons(doc,buttons){return el(doc,'div',{class:WINDOW_ROW_CLASS},buttons.filter(Boolean).map((one)=>el(doc,'button',{class:one.kind?`${WINDOW_BUTTON_CLASS} ${one.kind}`:WINDOW_BUTTON_CLASS,text:one.text,attrs:{type:'button'},dataset:{[one.mark]:one.value??'1'},on:{click:one.on}})))}
