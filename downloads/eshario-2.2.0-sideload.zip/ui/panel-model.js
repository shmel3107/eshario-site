import{SECTIONS,defaultOf,floorOf,inWindow} from '../settings/registry.js'
import{REGISTRY_SOURCES} from '../settings/registry-values.js'
import{AFTER_BUY,AFTER_BUY_KEY,AFTER_BUY_SHOWN,afterBuyShownOf,SEARCH_REFRESH,SEARCH_REFRESH_KEY,searchRefreshOf,OPTION_FIELDS} from '../automation/options-input.js'
import{LIMIT_FIELDS,boundsOf} from '../automation/limits-input.js'
import{sanitizePackShowPolicy,PACK_SHOW_MODES,packShowModeOf,packShowPatchOf} from '../features/pack-show.js'
import{stopReasonKey} from '../features/automation-actions.js'
import{relistHasDirection,relistPriceOf,RELIST_PERCENT,RELIST_PERCENT_DEFAULT,sanitizeRelistPricing} from '../features/transfer-list.js'
import{PICK_PRESELECTS,PICK_PRESELECT_DEFAULT,sanitizePickPreselect} from '../features/pick-prices.js'
export const ORDERED_SECTIONS=Object.freeze([...SECTIONS].filter((one)=>one.shipped!==false).sort((a,b)=>a.order-b.order))
export const FIRST_SECTION=ORDERED_SECTIONS[0]?.id??null
export const sectionLocked=(status,section)=>(section?.parked!==true
&&(section?.tariff==='members'?membersLocked(status,section)
:section?.feature!==null&&section?.feature!==undefined
&&status(section.feature)==='not-entitled'))
function membersLocked(status,section){const features=new Set()
for(const organ of section.organs??[]){if(organ.shipped===true&&typeof organ.feature==='string')features.add(organ.feature)}
if(features.size===0)return false
for(const feature of features){if(status(feature)!=='not-entitled')return false}
return true}
export const sectionParked=(section)=>section?.parked===true
export function openSectionOf(state){const view=state.panelView??{}
if(typeof view.section!=='string')return null
const status=typeof state.statusOf==='function'?state.statusOf:()=>'unknown'
const wanted=ORDERED_SECTIONS.find((one)=>one.id===view.section)??null
return wanted===null||sectionLocked(status,wanted)?null:wanted.id}
export const DEEDS=Object.freeze({'ledger.exportCsv':'ledger.csv','ledger.reset':'ledger.reset','ledger.export':'journal.export','ledger.analyze':'club.analyze','hotkeys.open':'hotkeys.open','premium.apply':'premium.apply','premium.clear':'premium.clear','premium.account':'premium.account','diagnostics.guide':'diagnostics.guide',
'premium.buy':'premium.buy','premium.saveSettings':'premium.saveSettings','premium.loadSettings':'premium.loadSettings','premium.report':'premium.report','premium.resetAll':'premium.resetAll',
'premium.sync':'cloud.sync','premium.saveFile':'cloud.saveFile','premium.loadFile':'cloud.loadFile','premium.takeCloud':'cloud.takeCloud','premium.takeLocal':'cloud.takeLocal'})
export function routeOf(sectionId,organ){const store=organ?.store
if(Array.isArray(organ?.group))return{via:'toggleGroup',key:organ.id,keys:[...organ.group],
routes:organ.group.map((id)=>{const member=SECTIONS.find((one)=>one.id===sectionId)?.organs.find((one)=>one.id===id)??null
return member===null?{via:'toggle',key:id}:routeOf(sectionId,member)})}
if((organ?.kind==='action'||organ?.kind==='link')&&typeof DEEDS[`${sectionId}.${organ?.id}`]==='string'){return{via:'deed',key:DEEDS[`${sectionId}.${organ.id}`]}}
if(typeof store==='string'){const cut=store.indexOf('.')
const bucket=store.slice(0,cut)
const key=store.slice(cut+1)
if(bucket==='toggles')return{via:'toggle',key}
if(bucket==='limits')return{via:'limit',key}
if(bucket==='options')return{via:'option',key}
if(bucket==='seller')return{via:'seller',key}
if(bucket==='license')return{via:'license',key}
if(bucket==='ui')return uiRoute(key)}
if(organ?.id==='dryRun')return{via:sectionId==='seller'?'sellerDryRun':'buyerDryRun',key:'dryRun'}
if(sectionId==='packs'&&organ?.id==='showMode')return{via:'packShowMode',key:'mode',
patches:Object.fromEntries(PACK_SHOW_MODES.map((mode)=>[mode,packShowPatchOf(mode)]))}
if(sectionId==='ledger'&&organ?.id==='scope')return{via:'view',key:'ledgerScope'}
const deed=DEEDS[`${sectionId}.${organ?.id}`]
return typeof deed==='string'?{via:'deed',key:deed}:null}
function uiRoute(key){
if(key==='packShow.ratingMin')return{via:'packShowRating',key:'ratingMin'}
if(key.startsWith('packShow.'))return{via:'packShow',key:key.slice('packShow.'.length)}
if(key.startsWith('solver.'))return{via:'solver',key:key.slice('solver.'.length)}
if(key.startsWith('relist.'))return{via:'relist',key:key.slice('relist.'.length)}
if(key.startsWith('listing.'))return{via:'listing',key:key.slice('listing.'.length)}
if(key==='dayXOff')return{via:'dayX',key}
if(key==='soundVolume')return{via:'soundVolume',key}
if(key==='pickPreselect')return{via:'pickPreselect',key}
if(key==='onboarded')return{via:'onboarding',key}
return null}
export function valueOf(state,organ,sectionId=null){const store=organ?.store
if(typeof store!=='string'){if(organ?.id==='showMode'&&(sectionId==='packs'||sectionId===null))return packShowModeOf(state.packs?.show)
if(organ?.id!=='dryRun')return null
const engine=sectionId==='seller'?state.seller:state.automation
return engine?engine.dryRun!==false:true}
const cut=store.indexOf('.')
const bucket=store.slice(0,cut)
const key=store.slice(cut+1)
if(bucket==='toggles')return typeof state.statusOf==='function'&&state.statusOf(key)==='active'
if(bucket==='limits')return text(state.automation?.limits?.[key])
if(bucket==='options'){if(key===AFTER_BUY_KEY)return afterBuyShownOf(state.automation?.options?.[key])
if(key===SEARCH_REFRESH_KEY)return searchRefreshOf(state.automation?.options?.[key])
return raw(state.automation?.options?.[key])}
if(bucket==='seller')return raw(state.seller?.options?.[key])
if(bucket==='license')return typeof state.licenseKey==='string'?state.licenseKey:''
if(bucket==='ui')return uiValue(state,key)
return null}
const text=(value)=>(typeof value==='string'?value:'')
const raw=(value)=>(typeof value==='boolean'?value:text(value))
function uiValue(state,key){
if(key.startsWith('relist.'))return pricingValue(sanitizeRelistPricing(state.relist),key.slice('relist.'.length))
if(key.startsWith('listing.'))return pricingValue(sanitizeRelistPricing(state.listing),key.slice('listing.'.length))
if(key.startsWith('solver.'))return state.solver?.[key.slice('solver.'.length)]!==false
if(key==='packShow.ratingMin'){const min=sanitizePackShowPolicy(state.packs?.show).ratingMin
return min===null?'':String(min)}
if(key.startsWith('packShow.')){const show=sanitizePackShowPolicy(state.packs?.show)
return show[key.slice('packShow.'.length)]===true}
if(key==='dayXOff')return state.dayXOff===true
if(key==='soundVolume')return typeof state.soundVolume==='string'?state.soundVolume:null
if(key==='pickPreselect')return sanitizePickPreselect(state.pickPreselect)??PICK_PRESELECT_DEFAULT
if(key==='onboarded')return state.onboarded===true
if(key==='filters')return Array.isArray(state.chosenFilters)?state.chosenFilters.length:0
return null}
function pricingValue(pricing,field){if(field==='percent'){
return pricing.percent===RELIST_PERCENT_DEFAULT?'':String(pricing.percent)}
const value=pricing[field]
return typeof value==='string'?value:''}
function subOf(state,section,organ){const ids=Array.isArray(organ.sub)?organ.sub:null
if(ids===null)return null
const mode=valueOf(state,organ,section.id)
if(typeof organ.subWhen==='string'){if(mode!==organ.subWhen)return[]}
else if(!relistHasDirection(mode))return[]
const out=[]
for(const id of ids){const one=section.organs.find((other)=>other.id===id&&other.shipped===true)??null
if(one===null)continue
if(typeof one.subMode==='string'&&one.subMode!==mode)continue
out.push(organView(state,section,one))}
return out}
function priceSampleOf(state,section,organ){
if(organ.sample!==true||typeof organ.subIn!=='string')return null
const parent=section.organs.find((one)=>one.id===organ.subIn)??null
if(parent===null||typeof parent.store!=='string')return null
const price=relistPriceOf(valueOfPricing(state,parent),SAMPLE_MARKET,null,true)
return price.ok===true
?state.t('panel.organ.sample',{market:SAMPLE_MARKET,coins:price.buyNow})
:state.t('panel.organ.sampleNone')}
function valueOfPricing(state,parent){const store=parent.store
return sanitizeRelistPricing(store.startsWith('ui.listing.')?state.listing:state.relist)}
export const SAMPLE_MARKET=1000
export function groupStateOf(state,section,organ){if(!Array.isArray(organ?.group)||organ.group.length===0)return null
const status=typeof state.statusOf==='function'?state.statusOf:()=>'unknown'
let on=0
let off=0
let unpaid=0
for(const id of organ.group){const member=section.organs.find((one)=>one.id===id)??null
if(member!==null&&!(typeof member.store==='string'&&member.store.startsWith('toggles.'))){if(typeof member.feature==='string'&&status(member.feature)==='not-entitled')unpaid+=1
if(valueOf(state,member,section.id)===false)off+=1
else on+=1
continue}
const key=typeof member?.store==='string'&&member.store.startsWith('toggles.')?member.store.slice('toggles.'.length):id
const said=status(key)
if(said==='not-entitled')unpaid+=1
if(said==='switched-off')off+=1
else on+=1}
return{on:off===0,partial:on>0&&off>0,paid:unpaid>0}}
export function groupTierLocked(state,section,organ){return organ?.tierFromGroup!==false&&groupStateOf(state,section,organ)?.paid===true}
function freedFromGroup(state,section,organ){if(typeof organ?.groupIn!=='string'||typeof organ.feature!=='string')return false
const group=section.organs.find((one)=>one.id===organ.groupIn)??null
if(group===null||!groupTierLocked(state,section,group))return false
const status=typeof state.statusOf==='function'?state.statusOf:()=>'unknown'
return status(organ.feature)!=='not-entitled'}
function pricingLine(section,organ){if(typeof organ?.subIn!=='string')return false
if(organ.sample===true)return true
const via=routeOf(section.id,organ)?.via
return via==='relist'||via==='listing'}
export const organDefault=(organ)=>defaultOf(organ,REGISTRY_SOURCES)
export const organFloor=(organ)=>floorOf(organ,REGISTRY_SOURCES)??null
export function isCustom(organ,value){if(organ.kind==='toggle'){const fallback=organDefault(organ)
return typeof fallback==='boolean'?value!==fallback:false}
if(organ.kind==='number'||organ.kind==='text')return typeof value==='string'&&value.trim()!==''
if(organ.kind==='choice'){const fallback=organDefault(organ)
return fallback===null||fallback===undefined?false:value!==fallback}
return false}
function boundsViewOf(t,organ){if(organ.kind!=='number')return null
const bounds=organBounds(organ)
if(bounds===null)return null
const unit=organ.unit?t(organ.unit):''
return{min:bounds.min,max:bounds.max,
below:bounds.min===null?null:t('panel.bounds.below',{value:bounds.min,unit}),
above:bounds.max===null?null:t('panel.bounds.above',{value:bounds.max,unit})}}
export function organBounds(organ){const store=typeof organ?.store==='string'?organ.store:''
const dot=store.indexOf('.')
const from=store.slice(0,dot)
const key=store.slice(dot+1)
const fields=from==='limits'?LIMIT_FIELDS:(from==='options'?OPTION_FIELDS:null)
const field=fields===null?null:fields.find((one)=>one.key===key)??null
if(field===null)return null
const bounds=boundsOf(field)
const scale=Number(field.scale)>0?Number(field.scale):1
if(bounds.minMs===null&&bounds.maxMs===null)return null
return{min:bounds.minMs===null?null:bounds.minMs/scale,max:bounds.maxMs===null?null:bounds.maxMs/scale}}
export function outOfBounds(value,bounds){if(!bounds||typeof value!=='string'||value.trim()==='')return null
const number=Number(value.replace(',','.').replace(/\s/g,''))
if(!Number.isFinite(number))return null
if(bounds.min!==null&&number<bounds.min)return 'min'
if(bounds.max!==null&&number>bounds.max)return 'max'
return null}
export function isBelowFloor(organ,value,floor=organFloor(organ)){if(!floor||typeof value!=='string'||value.trim()==='')return false
const number=Number(value.replace(',','.').replace(/\s/g,''))
return Number.isFinite(number)&&number<floor.value}
const labelKeyOf=(state,sectionId,organ)=>(sectionId==='diagnostics'&&organ.id==='guide'&&state.onboarded!==true
?'onboarding.done':organ.labelKey)
function readoutOf(state,sectionId,organ){if(sectionId!=='diagnostics')return null
const value=state.diagnostics??{}
if(organ.id==='version'){const ready=value.bridge==='ok'&&typeof value.version==='string'&&value.version!==''
return ready?value.version:state.t('onboarding.unknown')}
if(organ.id==='errors')return String(Number.isSafeInteger(value.errors)&&value.errors>=0?value.errors:0)
return null}
function choicesOf(t,sectionId,organ){if(organ.id===SEARCH_REFRESH_KEY)return[{id:SEARCH_REFRESH.PAIR,label:t('marketBot.refresh.pair')},{id:SEARCH_REFRESH.MAX_BID,label:t('marketBot.refresh.maxBid')},{id:SEARCH_REFRESH.MIN_BID,label:t('marketBot.refresh.minBid')},{id:SEARCH_REFRESH.OFF,label:t('marketBot.refresh.off')}]
if(organ.id===AFTER_BUY_KEY){const word={[AFTER_BUY.UNASSIGNED]:t('snipe.settings.afterBuyUnassigned'),[AFTER_BUY.TRANSFER_LIST]:t('snipe.settings.afterBuyTransferList')}
return AFTER_BUY_SHOWN.map((id)=>({id,label:word[id]??id}))}
if(organ.id==='soundVolume')return[{id:'quiet',label:'🔈',glyph:true,title:t('settings.organ.snipe.soundVolume.quiet')},{id:'medium',label:'🔉',glyph:true,title:t('settings.organ.snipe.soundVolume.medium')},{id:'loud',label:'🔊',glyph:true,title:t('settings.organ.snipe.soundVolume.loud')}]
if(organ.id==='pickMode')return PICK_PRESELECTS.map((id)=>({id,label:t(PICK_PRESELECT_WORDS[id])}))
if(sectionId==='packs'&&organ.id==='showMode')return PACK_SHOW_MODES.map((id)=>({id,label:t(PACK_SHOW_MODE_WORDS[id])}))
if(sectionId==='ledger'&&organ.id==='scope')return[{id:'session',label:t('ledger.session')},{id:'all',label:t('ledger.allTime')}]
if(organ.id==='relistMode'||organ.id==='listingMode')return[{id:'market',label:t('transfers.gear.mode.market')},
{id:'step',label:t('transfers.gear.mode.step')},{id:'percent',label:t('transfers.gear.mode.percent')}]
if(organ.id==='relistDirection'||organ.id==='listingDirection')return[{id:'down',label:t('transfers.gear.dir.down')},
{id:'up',label:t('transfers.gear.dir.up')}]
return[]}
const PICK_PRESELECT_WORDS=Object.freeze({rating:'settings.organ.packs.pickMode.rating',price:'settings.organ.packs.pickMode.price',manual:'settings.organ.packs.pickMode.manual'})
const PACK_SHOW_MODE_WORDS=Object.freeze({always:'settings.organ.packs.showMode.always',valuable:'settings.organ.packs.showMode.valuable',never:'settings.organ.packs.showMode.never'})
export function organView(state,section,organ){const t=state.t
const readout=readoutOf(state,section.id,organ)??priceSampleOf(state,section,organ)
const value=readout!==null?readout
:organ.id==='scope'&&section.id==='ledger'
?(state.ledgerScope==='all'?'all':'session')
:valueOf(state,organ,section.id)
const fallback=organDefault(organ)
const floor=organFloor(organ)
const status=typeof state.statusOf==='function'?state.statusOf:()=>'unknown'
const own=typeof organ.store==='string'&&organ.store.startsWith('toggles.')
const gate=organ.feature??section.feature??null
const gateStatus=gate===null?'active':status(gate)
const group=groupStateOf(state,section,organ)
const paidByGroup=groupTierLocked(state,section,organ)
const locked=paidByGroup||(own?gateStatus==='not-entitled':gateStatus!=='active')
return{id:organ.id,section:section.id,kind:organ.kind,level:organ.level,zone:organ.zone,
place:organ.place,tier:organ.tier,
hit:typeof state.highlight==='string'&&state.highlight===organ.id,
label:t(labelKeyOf(state,section.id,wordsOf(state,organ))),hint:hintOf(t,section,wordsOf(state,organ),group),
lead:typeof organ.leadKey==='string'?t(organ.leadKey):null,
unit:organ.unit?t(organ.unit):null,
value:group===null?value:group.on,
partial:group?.partial===true,
partialLabel:group?.partial===true?t('panel.organ.partial'):null,
groupNames:group===null?null:organ.group.map((id)=>t(section.organs.find((one)=>one.id===id)?.labelKey??id)),
defaultLabel:fallback===null||fallback===undefined||typeof fallback==='boolean'?null:t('panel.organ.default',{value:fallback}),
defaultValue:fallback===null||fallback===undefined||typeof fallback==='boolean'?null:String(fallback),
inline:inlineOf(state,section,organ),
after:afterOf(state,section,organ),
sub:subOf(state,section,organ),
custom:pricingLine(section,organ)||paidByGroup||gateStatus==='not-entitled'||routeOf(section.id,organ)===null?false
:(group!==null?(group.partial!==true&&group.on!==(organDefault(organ)!==false)):(isCustom(organ,value)||inlineOf(state,section,organ)?.custom===true)),
muted:mutedOf(state,section,organ),
choices:choicesOf(t,section.id,organ),
floor:floor===null?null:{value:floor.value,hard:floor.hard===true,
blocked:floor.hard===true?t('panel.floor.blocked',{value:floor.value,unit:organ.unit?t(organ.unit):''}):null},
belowFloor:isBelowFloor(organ,typeof value==='string'?value:'',floor),
bounds:boundsViewOf(t,organ),
danger:organ.danger===true,
locked,lockLabel:locked?t(gateStatus==='switched-off'?'settings.switchedOff':'license.premiumRequired'):null,
busy:busyOf(state,section.id,organ)||idleOf(state,section.id,organ),
route:paidByGroup?null:routeOf(section.id,organ)}}
function hintOf(t,section,organ,group){const own=organ.hintKey?t(organ.hintKey):null
if(group===null)return own
const names=organ.group.map((id)=>t(section.organs.find((one)=>one.id===id)?.labelKey??id)).join(' · ')
return own===null?names:`${own}\n${names}`}
function inlineOf(state,section,organ){if(typeof organ.inline!=='string')return null
const inner=section.organs.find((one)=>one.id===organ.inline&&one.shipped===true)??null
return inner===null?null:organView(state,section,inner)}
function afterOf(state,section,organ){if(typeof organ.after!=='string')return null
const inner=section.organs.find((one)=>one.id===organ.after&&one.shipped===true)??null
return inner===null?null:organView(state,section,inner)}
function mutedOf(state,section,organ){if(typeof organ.dimWhen!=='string')return false
const by=section.organs.find((one)=>one.id===organ.dimWhen)??null
return by!==null&&valueOf(state,by,section.id)===true}
const ENGINES=Object.freeze({snipe:'buyer',seller:'seller'})
const engineOf=(state,sectionId)=>(ENGINES[sectionId]==='seller'?state.seller
:ENGINES[sectionId]==='buyer'?state.automation:null)
function busyOf(state,sectionId,organ=null){if(sectionId==='snipe')return state.automation?.running===true
if(sectionId==='seller')return state.seller?.running===true
if(sectionId==='packs')return state.packs?.busy===true
if(sectionId==='ledger'&&organ?.id==='analyze')return state.club?.busy===true
return false}
const PREMIUM_SECTION='premium'
const CLOUD_ORGANS=Object.freeze(['sync','saveFile','loadFile','takeCloud','takeLocal'])
const CLOUD_CHOICE=Object.freeze(['takeCloud','takeLocal'])
export const signedIn=(state)=>state?.license?.mode==='account'
&&(state.license.authenticated===true||state.license.unlocked===true)
const unlockedNow=(state)=>state?.license?.unlocked===true
export function shownNow(state,organ){const when=organ?.showWhen
if(typeof when!=='string')return true
if(when==='signedIn')return signedIn(state)
if(when==='unpaid')return !unlockedNow(state)
return true}
function wordsOf(state,organ){const words=organ?.signedIn
if(words===null||typeof words!=='object'||!signedIn(state))return organ
return{...organ,...words}}
const PORT_ORGANS=Object.freeze(['saveSettings','loadSettings','report'])
function idleOf(state,sectionId,organ){if(sectionId!==PREMIUM_SECTION)return false
if(PORT_ORGANS.includes(organ?.id))return state.accountLine?.busy===true
if(CLOUD_ORGANS.includes(organ?.id)){const cloud=state.cloud??null
if(cloud?.busy===true)return true
return CLOUD_CHOICE.includes(organ?.id)&&cloud?.choose!==true}
const license=state.license??null
if(organ.id==='clear')return license?.mode==='account'||!(license?.unlocked===true||license?.hasKey===true)
if(organ.id==='key'||organ.id==='apply')return license?.mode==='account'
if(organ.id==='account')return false
return false}
export function organsView(state,section,level){return section.organs
.filter((organ)=>organ.shipped===true&&organ.level===level&&inWindow(organ)&&typeof organ.inlineIn!=='string'&&typeof organ.afterIn!=='string'&&(typeof organ.groupIn!=='string'||freedFromGroup(state,section,organ))&&typeof organ.subIn!=='string'&&shownNow(state,organ))
.map((organ)=>organView(state,section,organ))}
export function splitFine(fine){return{fine:fine.filter((organ)=>organ.tier!=='pro'),
pro:fine.filter((organ)=>organ.tier==='pro')}}
export function resetPlan(section){const plan=[]
for(const organ of section.organs){if(organ.shipped!==true)continue
if(Array.isArray(organ.group))continue
const route=routeOf(section.id,organ)
if(route===null||route.via==='deed'||route.via==='license')continue
if(pricingLine(section,organ)){const parent=section.organs.find((one)=>one.id===organ.subIn)??null
const back=sanitizeRelistPricing({mode:parent===null?null:defaultOf(parent,REGISTRY_SOURCES)})[route.key]
if(back!==undefined)plan.push({route,value:typeof back==='number'?String(back):back})
continue}
if(organ.kind==='number'||organ.kind==='text'){plan.push({route,value:''})
continue}
const fallback=defaultOf(organ,REGISTRY_SOURCES)
if(organ.kind==='toggle'){if(typeof fallback==='boolean')plan.push({route,value:fallback})
continue}
if(organ.kind==='choice'&&fallback!==null&&fallback!==undefined)plan.push({route,value:fallback})}
return plan}
export function engineWord(t,engine){if(engine?.running===true)return t('automation.running')
if(engine?.reason)return t('automation.stoppedAs',{reason:t(stopReasonKey(engine.reason))})
return t('automation.idle')}
function engineAction(state,t,sectionId,engine,gate){const name=ENGINES[sectionId]
if(name===undefined)return null
const running=engine?.running===true
const stopping=running&&state.stopping?.[name]===true
return{deed:`${name}.${running?'stop':'start'}`,running,stopping,
label:t(stopping?'automation.stopping':(running?'automation.stop':'automation.start')),
disabled:gate!=='active'}}
export function dockModel(state){const t=state.t
const live=[]
for(const id of Object.keys(ENGINES)){const engine=engineOf(state,id)
if(engine?.running!==true)continue
const section=ORDERED_SECTIONS.find((one)=>one.id===id)??null
live.push({id,stop:STOP_DEEDS[id],name:section===null?id:t(section.titleKey),count:runCount(state,id,engine)})}
const known=(id)=>typeof id==='string'&&ORDERED_SECTIONS.some((one)=>one.id===id)
return{openLabel:t('panel.settings.open'),openHint:t('panel.settings.openHint'),
section:known(state.lastSection)?state.lastSection:FIRST_SECTION,
stopLabel:t('panel.dock.stop'),
stopHint:live.length>1?t('panel.dock.stopBothHint'):t('panel.dock.stopHint'),
line:live.length===0?null
:(live.length===1?t('panel.dock.one',{name:live[0].name,count:live[0].count})
:t('panel.dock.many',{count:live.length})),
running:live.map((one)=>one.id),
stops:live.map((one)=>one.stop)}}
const STOP_DEEDS=Object.freeze({snipe:'buyer.stop',seller:'seller.stop'})
function runCount(state,id,engine){const t=state.t
const stats=engine?.stats??null
const num=(value)=>(Number.isFinite(Number(value))?Number(value):0)
if(id==='seller')return t('panel.dock.listed',{count:num(stats?.listings)})
return t('panel.dock.bought',{searches:num(stats?.searches),count:num(stats?.purchases)})}
export function leverOf(state){const t=state.t
const section=ORDERED_SECTIONS.find((one)=>one.id==='diagnostics')??null
const organ=section?.organs.find((one)=>one.id==='dayXOff')??null
if(section===null||organ===null||organ.shipped!==true)return null
return{...organView(state,section,organ),
title:t('dayX.title'),hintFull:t('dayX.hintFull'),
mounted:state.dayXMounted!==false,
onLabel:t('dayX.on'),reloadLabel:t('dayX.reload')}}
export function sectionModel(state,sectionId){const section=ORDERED_SECTIONS.find((one)=>one.id===sectionId)??null
if(section===null)return null
const t=state.t
const view=state.panelView??{}
const status=typeof state.statusOf==='function'?state.statusOf:()=>'unknown'
const gate=section.feature===null?'active':status(section.feature)
const engine=engineOf(state,section.id)
const hasEngine=Object.hasOwn(ENGINES,section.id)
const main=organsView(state,section,'main')
const split=splitFine(organsView(state,section,'fine'))
const fine=split.fine
const pro=split.pro
const zones=zonesView(state,section,fine)
const parked=sectionParked(section)
return{id:section.id,title:t(section.titleKey),hint:t(section.hintKey),
icon:section.icon,tier:section.tier,
parked,parkedLabel:parked?t('settings.section.parked.line'):null,
locked:parked?false:gate!=='active',
lockLabel:gate==='active'?null:t(gate==='switched-off'?'settings.switchedOff':'license.premiumRequired'),
stateLabel:hasEngine&&!parked?engineWord(t,engine):null,
stateCount:hasEngine&&!parked&&engine?.running===true?runCount(state,section.id,engine):null,
stateRunning:hasEngine&&!parked&&engine?.running===true,
action:parked?null:engineAction(state,t,section.id,engine,gate),
mainLabel:t('panel.block.main'),
runLabel:t('panel.block.run'),
resetLabel:t('panel.organ.reset'),resetHint:t('panel.organ.resetHint'),
canReset:resetPlan(section).length>0,
customLabel:t('panel.organ.custom'),customHint:t('panel.organ.customHint'),
riskLabel:t('panel.organ.risk'),riskHint:t('panel.organ.riskHint'),
floorWarning:t('panel.floor.warning'),floorConfirm:t('panel.floor.confirm'),
refusalOk:t('dialog.ok'),
floorPending:t('panel.floor.pending'),
pro,
proLabel:t('panel.block.pro'),
main,fine,fineZones:zones}}
export function zonesView(state,section,fine){if(section.zones.length===0)return null
const t=state.t
const byZone=new Map(section.zones.map((zone)=>[zone.id,[]]))
for(const organ of fine){const list=byZone.get(organ.zone)
if(list!==undefined)list.push(organ)}
return section.zones.map((zone)=>{const organs=byZone.get(zone.id)??[]
return{id:zone.id,title:t(zone.titleKey),organs,
grid:zone.grid===true}})}
export function searchModel(state,query){const t=state.t
const needle=typeof query==='string'?query.trim().toLowerCase():''
if(needle==='')return null
const rows=[]
for(const section of ORDERED_SECTIONS){const sectionTitle=t(section.titleKey)
for(const organ of section.organs){if(organ.shipped!==true)continue
if(!shownNow(state,organ))continue
if(typeof organ.inlineIn==='string')continue
if(typeof organ.groupIn==='string')continue
if(typeof organ.subIn==='string')continue
const label=t(organ.labelKey)
const hint=organ.hintKey?t(organ.hintKey):''
const inner=typeof organ.inline==='string'?section.organs.find((one)=>one.id===organ.inline&&one.shipped===true)??null:null
const kids=Array.isArray(organ.group)?organ.group.map((id)=>t(section.organs.find((one)=>one.id===id)?.labelKey??id)).join(' '):''
const line=Array.isArray(organ.sub)?organ.sub.map((id)=>t(section.organs.find((one)=>one.id===id)?.labelKey??id)).join(' '):''
const also=`${inner?t(inner.labelKey):''} ${kids} ${line}`
if(!`${label} ${hint} ${also}`.toLowerCase().includes(needle))continue
const openable=inWindow(organ)
rows.push({section:section.id,organ:organ.id,label,hint,sectionTitle,
place:organ.place,openable,where:sectionTitle})}}
return{query:needle,rows,title:t('panel.search.title',{count:rows.length}),
empty:rows.length===0?t('panel.search.empty'):null}}
export function settingsModel(state){const t=state.t
const status=typeof state.statusOf==='function'?state.statusOf:()=>'unknown'
const locked=(section)=>sectionLocked(status,section)
const open=openSectionOf(state)
const searching=typeof state.query==='string'&&state.query.trim()!==''
const row=(section)=>({id:section.id,title:t(section.titleKey),icon:section.icon,tier:section.tier,
hint:t(section.hintKey),
parked:sectionParked(section),
parkedLabel:sectionParked(section)?t('settings.section.parked.rail'):null,
locked:locked(section),
lockLabel:locked(section)?t('panel.rail.locked'):null,
on:searching===false&&section.id===open})
const rows=ORDERED_SECTIONS.map(row)
return{title:t('panel.settings.title'),closeLabel:t('panel.settings.close'),
openLabel:t('panel.settings.open'),openHint:t('panel.settings.openHint'),
locale:{label:t('panel.settings.locale'),
now:typeof state.locale==='string'?state.locale:'',
options:[{id:'ru',short:'RU',label:'Русский'},{id:'en',short:'EN',label:'English'}]},
rail:{main:rows.filter((one)=>one.tier==='all'),
pro:rows.filter((one)=>one.tier==='pro'),
proLabel:t('panel.home.advanced'),proHint:t('panel.home.advancedHint'),
label:t('panel.tabs')}}}
