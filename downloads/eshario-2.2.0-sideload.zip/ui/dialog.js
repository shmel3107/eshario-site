import{el,clear} from './dom.js'
import{modalBox,modalButtons,noteWindowRaised} from './window.js'
export function createDialogs(deps){const{doc,root,t}=deps
if(!doc||!root) throw new Error('dialog: нужны документ и узел для монтирования')
let current=null
const isOpen=()=>current!==null
function close(value){if(!current)return
const{resolve}=current
current=null
clear(root)
resolve(value)}
function open(spec){
if(current)close(current.cancelValue)
return new Promise((resolve)=>{current={resolve,cancelValue:spec.cancelValue};
let field=null;
if(spec.field){field=el(doc,spec.field.tag,{attrs:spec.field.tag==='input'
?{type:'text',id:'fut-companion-dialog-field'}
:{id:'fut-companion-dialog-field'},dataset:{dialogField:'1'}});
field.value=spec.field.value??'';
if(spec.field.readOnly)field.readOnly=true}
const buttons=modalButtons(doc,spec.buttons.map((button)=>({text:t(button.labelKey),kind:button.kind,
mark:'dialogAction',value:button.id,
on:()=>close(button.fromField?String(field?.value??''):button.value)})));
const overlay=modalBox(doc,{mark:'dialogOverlay',overlay:'overlay',box:'box',boxMark:'dialog',
title:t(spec.titleKey,spec.titleParams),closeLabel:t('dialog.close'),
onBack:()=>close(spec.cancelValue),
onKey:(event)=>{
if(event?.key==='Escape'){event.preventDefault?.();
close(spec.cancelValue);
return}
if(event?.key==='Enter'&&spec.field?.tag!=='textarea'){const primary=spec.buttons.find((b)=>b.kind==='primary');
if(!primary)return;
event.preventDefault?.();
close(primary.fromField?String(field?.value??''):primary.value)}}},
[spec.messageKey?el(doc,'div',{class:'message',text:t(spec.messageKey,spec.messageParams)}):null,field,buttons]);
clear(root);
root.appendChild(overlay);
noteWindowRaised();
(field??buttons.children?.[0])?.focus?.();
field?.select?.()})}
function askDialog(opts){return open({titleKey:opts.titleKey,field:{tag:'input',value:opts.value??''},buttons:[{id:'cancel',labelKey:'dialog.cancel',value:null},{id:'ok',labelKey:'dialog.ok',kind:'primary',value:null,fromField:true}],cancelValue:null})}
function showDialog(opts){return open({titleKey:opts.titleKey,titleParams:opts.titleParams,field:{tag:'textarea',value:opts.text??'',readOnly:true},buttons:[{id:'ok',labelKey:'dialog.close',value:null}],cancelValue:null})}
function confirmDialog(opts){return open({titleKey:opts.titleKey,messageKey:opts.messageKey??null,
messageParams:opts.messageParams,buttons:[{id:'no',labelKey:'dialog.cancel',value:false},{id:'yes',labelKey:'dialog.confirm',kind:opts.danger===false?'primary':'danger',value:true}],cancelValue:false})}
function reportDialog(opts){if(current)close(current.cancelValue)
const done=[]
return new Promise((resolve)=>{current={resolve:()=>resolve({done:[...done]}),cancelValue:null}
const field=el(doc,'textarea',{attrs:{id:'fut-companion-dialog-field',placeholder:t(opts.placeholderKey),maxlength:'2000'},dataset:{dialogField:'1'}})
const contact=opts.contactKey?el(doc,'input',{attrs:{type:'text',placeholder:t(opts.contactKey),maxlength:'64'},dataset:{dialogContact:'1'}}):null
const status=el(doc,'div',{class:'message',attrs:{hidden:'hidden'},dataset:{dialogStatus:'1'}})
let busy=false
const row=modalButtons(doc,opts.actions.map((action)=>({text:t(action.labelKey),kind:action.kind,mark:'dialogAction',value:action.id,
on:async()=>{const buttons=[...(row.querySelectorAll?.('button')??[])]
const button=buttons.find((one)=>one.dataset?.dialogAction===action.id)??null
if(busy||button?.disabled)return
busy=true
const locked=buttons.filter((one)=>one.disabled)
for(const one of buttons)one.disabled=true
let said=null
try{said=await opts.onAction(action.id,{text:String(field.value??''),contact:String(contact?.value??'')})}catch{said=null}
busy=false
for(const one of buttons)if(!locked.includes(one))one.disabled=false
if(said?.lock===true&&button)button.disabled=true
if(said?.ok===true)done.push(action.id)
if(said&&typeof said.key==='string'){status.textContent=t(said.key,said.params)
status.removeAttribute('hidden')}}})))
const overlay=modalBox(doc,{mark:'dialogOverlay',overlay:'overlay',box:'box',boxMark:'dialog',
title:t(opts.titleKey),closeLabel:t('dialog.close'),
onBack:()=>close(null),
onKey:(event)=>{if(event?.key==='Escape'){event.preventDefault?.()
close(null)}}},
[el(doc,'div',{class:'message',text:t(opts.messageKey)}),field,contact,status,row])
clear(root)
root.appendChild(overlay)
noteWindowRaised()
field.focus?.()})}
return{isOpen,close:()=>close(current?.cancelValue),ask:askDialog,show:showDialog,confirm:confirmDialog,report:reportDialog}}
