import { MAX_SYNC_BYTES, SYNC_SCHEMA } from './settings-schema.js';
export const CHROME_SYNC_SUBJECT = 'chrome-sync';
export const META_KEY = 'settings.cloud.meta';
export const CHUNK_PREFIX = 'settings.cloud.';
const QUOTA_BYTES_PER_ITEM = 8192;
export const CHUNK_BUDGET = QUOTA_BYTES_PER_ITEM - 192;
const CLOUD_TOTAL_BYTES = 102_400;
const CLOUD_RESERVE = 2048;
function charCost(code) {
if (code === 0x22 || code === 0x5C) return 2;
if (code < 0x20) return (code === 8 || code === 9 || code === 10 || code === 12 || code === 13) ? 2 : 6;
if (code < 0x80) return 1;
if (code < 0x800) return 2;
return 3;
}
export function chunkText(text, budget = CHUNK_BUDGET) {
const out = [];
if (typeof text !== 'string' || text === '') return out;
const room = Math.max(1, budget - 2);
let start = 0;
let cost = 0;
for (let at = 0; at < text.length; at += 1) {
const one = charCost(text.charCodeAt(at));
if (cost + one > room && at > start) {
out.push(text.slice(start, at));
start = at;
cost = 0;
}
cost += one;
}
out.push(text.slice(start));
return out;
}
export const chunkKey = (index) => `${CHUNK_PREFIX}${index}`;
function storedBytes(parts) {
let total = 0;
for (let index = 0; index < parts.length; index += 1) {
total += chunkKey(index).length + new TextEncoder().encode(JSON.stringify(parts[index])).length;
}
return total;
}
export function reasonOf(error) {
const text = String(error?.message ?? error ?? '');
if (text.includes('QUOTA_BYTES_PER_ITEM')) return 'quota-item';
if (text.includes('MAX_ITEMS')) return 'quota-items';
if (text.includes('MAX_WRITE_OPERATIONS_PER_MINUTE')) return 'write-rate-minute';
if (text.includes('MAX_WRITE_OPERATIONS_PER_HOUR')) return 'write-rate-hour';
if (text.includes('QUOTA_BYTES')) return 'quota';
return 'sync-error';
}
const positive = (value) => (Number.isSafeInteger(value) && value >= 0 ? value : null);
export function createChromeSyncTransport(deps = {}) {
const sync = deps.sync;
if (!sync || typeof sync.get !== 'function' || typeof sync.set !== 'function'
|| typeof sync.remove !== 'function') {
throw new Error('chrome sync: storage required');
}
const now = deps.clock?.now ?? (() => Date.now());
const budget = deps.budget ?? CHUNK_BUDGET;
const empty = () => ({
ok: true,
schema: SYNC_SCHEMA,
subject: CHROME_SYNC_SUBJECT,
revision: 0,
initialized: false,
namespaces: null,
updatedAt: null,
chunks: 0,
});
async function readMeta() {
const stored = await sync.get([META_KEY]);
const meta = stored?.[META_KEY];
if (!meta || typeof meta !== 'object') return null;
const revision = positive(meta.revision);
const chunks = positive(meta.chunks);
if (meta.schema !== SYNC_SCHEMA || revision === null || chunks === null) return null;
return {
revision,
chunks,
updatedAt: positive(meta.updatedAt),
subject: typeof meta.subject === 'string' && meta.subject !== '' ? meta.subject : CHROME_SYNC_SUBJECT,
};
}
async function read() {
let meta;
try {
meta = await readMeta();
} catch (error) {
return { ok: false, reason: reasonOf(error) };
}
if (meta === null || meta.chunks === 0) return empty();
let stored;
try {
const keys = [];
for (let at = 0; at < meta.chunks; at += 1) keys.push(chunkKey(at));
stored = await sync.get(keys);
} catch (error) {
return { ok: false, reason: reasonOf(error) };
}
let text = '';
for (let at = 0; at < meta.chunks; at += 1) {
const part = stored?.[chunkKey(at)];
if (typeof part !== 'string') return { ok: false, reason: 'incomplete' };
text += part;
}
let namespaces;
try {
namespaces = JSON.parse(text);
} catch {
return { ok: false, reason: 'invalid-json' };
}
return {
ok: true,
schema: SYNC_SCHEMA,
subject: meta.subject,
revision: meta.revision,
initialized: true,
namespaces,
updatedAt: meta.updatedAt,
chunks: meta.chunks,
};
}
async function write(payload) {
if (payload?.schema !== SYNC_SCHEMA) return { ok: false, reason: 'schema' };
const base = positive(payload?.baseRevision);
if (base === null) return { ok: false, reason: 'revision' };
const namespaces = payload?.namespaces;
if (!namespaces || typeof namespaces !== 'object' || Array.isArray(namespaces)) {
return { ok: false, reason: 'namespaces' };
}
let meta;
try {
meta = await readMeta();
} catch (error) {
return { ok: false, reason: reasonOf(error) };
}
const current = meta === null ? 0 : meta.revision;
if (current !== base) return { ok: false, reason: 'stale' };
const text = JSON.stringify(namespaces);
if (new TextEncoder().encode(text).length > MAX_SYNC_BYTES) {
return { ok: false, reason: 'too-large' };
}
const parts = chunkText(text, budget);
if (storedBytes(parts) > CLOUD_TOTAL_BYTES - CLOUD_RESERVE) {
return { ok: false, reason: 'cloud-full' };
}
const revision = current + 1;
const at = now();
const payloadOut = { [META_KEY]: { schema: SYNC_SCHEMA, subject: CHROME_SYNC_SUBJECT, revision, chunks: parts.length, updatedAt: at } };
for (let index = 0; index < parts.length; index += 1) payloadOut[chunkKey(index)] = parts[index];
try {
await sync.set(payloadOut);
} catch (error) {
return { ok: false, reason: reasonOf(error) };
}
const stale = [];
for (let index = parts.length; index < (meta?.chunks ?? 0); index += 1) stale.push(chunkKey(index));
if (stale.length > 0) {
try {
await sync.remove(stale);
} catch { /* лишний кусок ничего не портит: его никто не читает */ }
}
return {
ok: true,
schema: SYNC_SCHEMA,
subject: CHROME_SYNC_SUBJECT,
revision,
initialized: true,
namespaces,
updatedAt: at,
chunks: parts.length,
};
}
return { read, write };
}
