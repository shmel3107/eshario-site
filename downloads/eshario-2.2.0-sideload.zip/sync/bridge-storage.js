import { SYNC_STATE_KEY, SYNC_STORAGE_KEYS } from './settings-schema.js';
import { CHUNK_PREFIX, META_KEY } from './chrome-sync-transport.js';
const CLOUD_READ = 'cloud.read';
const CLOUD_WRITE = 'cloud.write';
export const BRIDGE_DOORS = Object.freeze({
[SYNC_STORAGE_KEYS.features]: 'settings',
[SYNC_STORAGE_KEYS.filters]: 'filters',
[SYNC_STORAGE_KEYS.buyerLimits]: 'limits',
[SYNC_STORAGE_KEYS.buyerOptions]: 'options',
[SYNC_STORAGE_KEYS.sellerOptions]: 'seller',
[SYNC_STORAGE_KEYS.interface]: 'ui',
[SYNC_STORAGE_KEYS.packLocks]: 'packs',
[SYNC_STATE_KEY]: 'sync.base',
});
const asList = (keys) => {
if (keys === undefined || keys === null) return Object.keys(BRIDGE_DOORS);
return Array.isArray(keys) ? keys : [keys];
};
export function createBridgeArea(deps = {}) {
const request = deps.request;
if (typeof request !== 'function') throw new Error('bridge storage: нужен мост');
const memory = new Map();
return {
async get(keys) {
const out = {};
for (const key of asList(keys)) {
const door = BRIDGE_DOORS[key];
if (door === undefined) {
if (memory.has(key)) out[key] = memory.get(key);
continue;
}
const value = await request(`${door}.read`);
if (value !== null && value !== undefined) out[key] = value;
}
return out;
},
async set(values) {
const keys = Object.keys(values ?? {});
const ordered = [
...keys.filter((key) => key !== SYNC_STATE_KEY),
...keys.filter((key) => key === SYNC_STATE_KEY),
];
for (const key of ordered) {
const door = BRIDGE_DOORS[key];
if (door === undefined) { memory.set(key, values[key]); continue; }
const said = await request(`${door}.write`, values[key]);
if (said !== true) throw new Error(`bridge storage: ключ ${key} не записан`);
}
},
};
}
function chunkIndexOf(key) {
if (typeof key !== 'string' || !key.startsWith(CHUNK_PREFIX)) return null;
const tail = key.slice(CHUNK_PREFIX.length);
if (!/^\d+$/.test(tail)) return null;
return Number(tail);
}
export function createBridgeCloud(deps = {}) {
const request = deps.request;
if (typeof request !== 'function') throw new Error('bridge cloud: нужен мост');
let seen = 0;
let removed = [];
return {
async get(keys) {
const said = await request(CLOUD_READ);
const meta = said?.meta ?? null;
const parts = Array.isArray(said?.parts) ? said.parts : [];
seen = parts.length;
const out = {};
for (const key of asList(keys)) {
if (key === META_KEY) {
if (meta !== null && meta !== undefined) out[key] = meta;
continue;
}
const at = chunkIndexOf(key);
if (at === null) continue;
const part = parts[at];
if (typeof part === 'string') out[key] = part;
}
return out;
},
async set(values) {
const meta = values?.[META_KEY];
if (meta === undefined) throw new Error('bridge cloud: снимок без метаданных');
const parts = [];
for (const [key, value] of Object.entries(values ?? {})) {
if (key === META_KEY) continue;
const at = chunkIndexOf(key);
if (at === null) throw new Error(`bridge cloud: чужой ключ ${key}`);
parts[at] = value;
}
for (let at = 0; at < parts.length; at += 1) {
if (typeof parts[at] !== 'string') throw new Error('bridge cloud: дыра в кусках снимка');
}
const said = await request(CLOUD_WRITE, { meta, parts, dropFrom: seen });
if (said?.ok !== true) throw new Error(String(said?.reason ?? 'sync-error'));
removed = Array.isArray(said.removed) ? said.removed : [];
seen = parts.length;
},
async remove(keys) {
const missed = asList(keys).filter((key) => !removed.includes(key));
if (missed.length > 0) {
throw new Error(`bridge cloud: мост не сносил ${missed.join(', ')}`);
}
},
};
}
