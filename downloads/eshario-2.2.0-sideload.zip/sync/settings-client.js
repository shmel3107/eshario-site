import {
SYNC_NAMESPACES, SYNC_SCHEMA, applyLocalSettings, collectLocalSettings,
defaultSyncNamespaces, parseRemoteSettings, sameSyncValue,
sanitizeSyncMetadata, sanitizeSyncNamespaces,
} from './settings-schema.js';
const changed = (from, to) => SYNC_NAMESPACES.filter(
(key) => !sameSyncValue(from[key], to[key]),
);
export function planSettingsSync({
base, local, present = [], remote, resolution = null,
} = {}) {
const localValue = sanitizeSyncNamespaces(local);
if (!remote || remote.schema !== SYNC_SCHEMA || typeof remote.subject !== 'string') {
return { ok: false, reason: 'remote' };
}
if (!remote.initialized) {
return {
ok: true, action: 'push', resultAction: 'uploaded',
namespaces: localValue,
};
}
const remoteValue = sanitizeSyncNamespaces(remote.namespaces);
const validBase = sanitizeSyncMetadata(base);
if (!validBase || validBase.subject !== remote.subject) {
const conflicts = changed(localValue, remoteValue);
if (conflicts.length === 0 || present.length === 0 || resolution === 'cloud') {
return {
ok: true, action: 'apply', resultAction: 'downloaded',
namespaces: remoteValue,
};
}
if (resolution === 'local') {
return {
ok: true, action: 'push', resultAction: 'resolved-local',
namespaces: localValue,
};
}
return { ok: false, reason: 'conflict', conflicts };
}
if (remote.revision < validBase.revision) {
return { ok: false, reason: 'server-reset', conflicts: [...SYNC_NAMESPACES] };
}
const baseValue = validBase.namespaces;
const localChanges = changed(baseValue, localValue);
const remoteChanges = changed(baseValue, remoteValue);
const merged = {};
const conflicts = [];
for (const key of SYNC_NAMESPACES) {
const localChanged = localChanges.includes(key);
const remoteChanged = remoteChanges.includes(key);
if (localChanged && remoteChanged && !sameSyncValue(localValue[key], remoteValue[key])) {
conflicts.push(key);
merged[key] = resolution === 'local' ? localValue[key] : remoteValue[key];
} else if (localChanged) merged[key] = localValue[key];
else merged[key] = remoteValue[key];
}
if (conflicts.length > 0 && !['local', 'cloud'].includes(resolution)) {
return { ok: false, reason: 'conflict', conflicts };
}
if (sameSyncValue(merged, remoteValue)) {
return {
ok: true, action: 'apply',
resultAction: conflicts.length > 0 ? 'resolved-cloud'
: (remoteChanges.length > 0 ? 'downloaded' : 'unchanged'),
namespaces: merged,
};
}
return {
ok: true, action: 'push',
resultAction: conflicts.length > 0 ? 'resolved-local'
: (localChanges.length > 0 && remoteChanges.length > 0 ? 'merged' : 'uploaded'),
namespaces: merged,
};
}
export function createSettingsSync({ area, transport } = {}) {
if (!area || typeof area.get !== 'function' || typeof area.set !== 'function') {
throw new Error('settings sync: storage required');
}
if (!transport || typeof transport.read !== 'function' || typeof transport.write !== 'function') {
throw new Error('settings sync: transport required');
}
let busy = false;
return {
async run({ resolution = null, direction = null } = {}) {
if (busy) return { ok: false, reason: 'busy' };
busy = true;
try {
const local = await collectLocalSettings(area);
let rawRemote;
try { rawRemote = await transport.read(); } catch { return { ok: false, reason: 'network' }; }
if (rawRemote?.ok !== true) {
return { ok: false, reason: typeof rawRemote?.reason === 'string' ? rawRemote.reason : 'network' };
}
const parsed = parseRemoteSettings(rawRemote);
if (!parsed.ok) return { ok: false, reason: `invalid-${parsed.reason}` };
const remote = parsed.value;
const plan = planSettingsSync({
base: local.base, local: local.namespaces, present: local.present,
remote, resolution,
});
if (!plan.ok) return plan;
if (direction === 'up') {
const ahead = SYNC_NAMESPACES.filter(
(key) => !sameSyncValue(plan.namespaces[key], local.namespaces[key]),
);
if (ahead.length > 0) {
return { ok: false, reason: 'cloud-ahead', action: plan.resultAction, conflicts: ahead };
}
}
if (plan.action === 'apply') {
const current = await collectLocalSettings(area);
if (!sameSyncValue(current.namespaces, local.namespaces)) {
return { ok: false, reason: 'local-changed' };
}
await applyLocalSettings(area, plan.namespaces, remote);
return { ok: true, action: plan.resultAction, revision: remote.revision };
}
let rawWritten;
try {
rawWritten = await transport.write({
schema: SYNC_SCHEMA, baseRevision: remote.revision,
namespaces: plan.namespaces,
});
} catch {
return { ok: false, reason: 'network' };
}
if (rawWritten?.ok !== true) {
return { ok: false, reason: typeof rawWritten?.reason === 'string' ? rawWritten.reason : 'network' };
}
const written = parseRemoteSettings(rawWritten);
if (!written.ok || !written.value.initialized
|| written.value.subject !== remote.subject
|| written.value.revision < remote.revision
|| !sameSyncValue(written.value.namespaces, plan.namespaces)) {
return { ok: false, reason: 'invalid-response' };
}
const current = await collectLocalSettings(area);
if (!sameSyncValue(current.namespaces, local.namespaces)) {
return { ok: false, reason: 'local-changed' };
}
await applyLocalSettings(area, written.value.namespaces, written.value);
return { ok: true, action: plan.resultAction, revision: written.value.revision };
} finally {
busy = false;
}
},
};
}
