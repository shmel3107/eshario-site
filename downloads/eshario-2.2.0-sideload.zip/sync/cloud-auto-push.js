import { SYNC_STATE_KEY, SYNC_STORAGE_KEYS, sanitizeSyncMetadata } from './settings-schema.js';
import { createSettingsSync } from './settings-client.js';
import { CHROME_SYNC_SUBJECT } from './chrome-sync-transport.js';
export const CLOUD_STATUS_KEY = 'settings.cloud.status';
const PUSH_DELAY_MS = 10_000;
const PUSH_INTERVAL_MS = 60_000;
const WATCHED_KEYS = Object.freeze(Object.values(SYNC_STORAGE_KEYS));
const same = (a, b) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
export async function writeCloudStatus(area, state, extra = {}) {
const value = { at: Date.now(), ...extra, state };
try {
await area.set({ [CLOUD_STATUS_KEY]: value });
} catch { /* память о ходе не записалась — сам ход от этого не отменяется */ }
return value;
}
function worthPushing(changes) {
if (!changes || typeof changes !== 'object') return false;
for (const key of WATCHED_KEYS) {
if (!Object.hasOwn(changes, key)) continue;
const one = changes[key];
if (!same(one?.oldValue, one?.newValue)) return true;
}
return false;
}
const WAIT_REASONS = Object.freeze([
'busy', 'quota', 'quota-item', 'quota-items', 'cloud-full',
'write-rate-minute', 'write-rate-hour',
]);
export function createCloudAutoPush(deps = {}) {
const { area, transport } = deps;
if (!area || typeof area.get !== 'function' || typeof area.set !== 'function') {
throw new Error('cloud auto push: storage required');
}
const timers = deps.timers ?? {
setTimeout: (fn, ms) => setTimeout(fn, ms),
clearTimeout: (id) => clearTimeout(id),
};
const now = deps.clock?.now ?? (() => Date.now());
const delayMs = deps.delayMs ?? PUSH_DELAY_MS;
const intervalMs = deps.intervalMs ?? PUSH_INTERVAL_MS;
const sync = createSettingsSync({ area, transport });
let timer = null;
let lastWriteAt = null;
let running = false;
let pending = false;
let listener = null;
let armed = null;
const remember = (state, extra = {}) => writeCloudStatus(area, state, { at: now(), ...extra });
async function checkArmed() {
if (armed === true) return true;
try {
const stored = await area.get(SYNC_STATE_KEY);
const base = sanitizeSyncMetadata(stored?.[SYNC_STATE_KEY]);
armed = base !== null && base.subject === CHROME_SYNC_SUBJECT;
} catch { armed = false; }
return armed === true;
}
void checkArmed();
function schedule(ms) {
if (timer !== null) timers.clearTimeout(timer);
timer = timers.setTimeout(() => {
timer = null;
void push();
}, Math.max(0, ms));
}
async function push() {
if (running) { pending = true; return { ok: false, reason: 'busy' }; }
if (!(await checkArmed())) return { ok: false, reason: 'not-armed' };
if (lastWriteAt !== null && now() - lastWriteAt < intervalMs) {
schedule(intervalMs - (now() - lastWriteAt));
return { ok: false, reason: 'too-soon' };
}
running = true;
try {
const said = await sync.run({ direction: 'up' });
if (said.ok === true) {
if (said.action !== 'unchanged') lastWriteAt = now();
await remember(said.action === 'unchanged' ? 'unchanged' : 'pushed', { revision: said.revision });
return said;
}
if (said.reason === 'conflict') {
await remember('conflict', { conflicts: said.conflicts ?? [] });
return said;
}
if (said.reason === 'cloud-ahead') {
await remember('cloud-ahead');
return said;
}
await remember('error', { reason: said.reason });
if (WAIT_REASONS.includes(said.reason)) schedule(intervalMs);
return said;
} finally {
running = false;
if (pending) { pending = false; schedule(delayMs); }
}
}
return {
notice(changes, areaName = 'local') {
if (areaName !== 'local' || !worthPushing(changes)) return false;
if (armed === true) { schedule(delayMs); return true; }
void checkArmed().then((ok) => { if (ok) schedule(delayMs); });
return false;
},
start(storage = deps.storage) {
if (listener !== null || !storage?.onChanged?.addListener) return false;
listener = (changes, areaName) => { this.notice(changes, areaName); };
storage.onChanged.addListener(listener);
return true;
},
state() {
return { armed, scheduled: timer !== null, lastWriteAt };
},
stop(storage = deps.storage) {
if (timer !== null) { timers.clearTimeout(timer); timer = null; }
if (listener !== null && storage?.onChanged?.removeListener) {
storage.onChanged.removeListener(listener);
}
listener = null;
return true;
},
push,
};
}
