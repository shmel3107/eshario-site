import { CHANNEL, FROM_CONTENT, KIND_EVENT } from '../bridge/protocol.js';
export const TRANSFER_METHOD = 'settings.transfer';
export const TRANSFER_REASONS = Object.freeze([
'not-signed-in', 'offline', 'server', 'conflict', 'too-big', 'empty', 'no-port',
]);
export const SETTINGS_APPLIED = 'settings.applied';
export const TRANSFER_TIMEOUT_MS = 20_000;
export function transferAnswer(raw) {
const out = { ok: raw?.ok === true };
if (Number.isSafeInteger(raw?.revision) && raw.revision >= 0) out.revision = raw.revision;
if (!out.ok) out.reason = TRANSFER_REASONS.includes(raw?.reason) ? raw.reason : 'server';
return out;
}
export function createSettingsTransfer(deps = {}) {
const bridge = deps.bridge;
const onApplied = typeof deps.onApplied === 'function' ? deps.onApplied : () => {};
const onError = typeof deps.onError === 'function' ? deps.onError : () => {};
async function run(direction) {
if (!bridge || typeof bridge.request !== 'function') return transferAnswer({ reason: 'no-port' });
let raw;
try {
raw = await bridge.request(TRANSFER_METHOD, { direction }, { timeoutMs: TRANSFER_TIMEOUT_MS });
} catch {
return transferAnswer({ reason: 'no-port' });
}
const answer = transferAnswer(raw);
if (answer.ok && direction === 'load') {
try {
await onApplied();
} catch (err) {
onError(`transfer: ${err?.message ?? err}`);
}
}
return answer;
}
return {
save: () => run('save'),
load: () => run('load'),
};
}
export function watchSettingsApplied(win, onApplied) {
if (!win || typeof win.addEventListener !== 'function' || typeof onApplied !== 'function') return false;
win.addEventListener('message', (event) => {
if (event?.source !== undefined && event.source !== win) return;
const msg = event?.data;
if (!msg || msg.channel !== CHANNEL || msg.from !== FROM_CONTENT
|| msg.kind !== KIND_EVENT || msg.name !== SETTINGS_APPLIED) return;
onApplied();
});
return true;
}
