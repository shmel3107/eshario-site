import {
SYNC_SCHEMA, SYNC_STORAGE_KEYS, parseRemoteSettings, sanitizeSyncNamespaces,
} from './settings-schema.js';
import { sanitizeUiState } from '../features/ui-state.js';
export const FILE_SUBJECT = 'file';
const pad = (value) => String(value).padStart(2, '0');
export function settingsFileName(at = Date.now()) {
const date = at instanceof Date ? at : new Date(at);
const day = Number.isNaN(date.getTime()) ? new Date() : date;
return `eshario-settings-${day.getFullYear()}-${pad(day.getMonth() + 1)}-${pad(day.getDate())}.json`;
}
export function serializeSettingsFile(input = {}) {
const namespaces = sanitizeSyncNamespaces(input.namespaces);
const exported = Number.isSafeInteger(input.exported) ? input.exported : Date.now();
const snapshot = {
schema: SYNC_SCHEMA,
subject: FILE_SUBJECT,
revision: 0,
initialized: true,
exported: new Date(exported).toISOString(),
namespaces,
};
return `${JSON.stringify(snapshot, null, 2)}\n`;
}
export function parseSettingsFile(text) {
if (typeof text !== 'string' || text.trim() === '') return { ok: false, reason: 'empty' };
let raw;
try {
raw = JSON.parse(text);
} catch {
return { ok: false, reason: 'json' };
}
const parsed = parseRemoteSettings({ ...raw, ok: true });
if (!parsed.ok) return { ok: false, reason: parsed.reason };
if (!parsed.value.initialized) return { ok: false, reason: 'namespaces' };
return {
ok: true,
namespaces: parsed.value.namespaces,
exported: typeof raw.exported === 'string' && raw.exported !== '' ? raw.exported : null,
};
}
export async function applyFileSettings(area, namespaces) {
if (!area || typeof area.get !== 'function' || typeof area.set !== 'function') {
throw new Error('settings file: storage required');
}
const clean = sanitizeSyncNamespaces(namespaces);
const current = await area.get(SYNC_STORAGE_KEYS.interface);
const deviceUi = sanitizeUiState(current?.[SYNC_STORAGE_KEYS.interface]);
await area.set({
[SYNC_STORAGE_KEYS.features]: clean.features,
[SYNC_STORAGE_KEYS.filters]: clean.filters,
[SYNC_STORAGE_KEYS.buyerLimits]: clean.buyerLimits,
[SYNC_STORAGE_KEYS.buyerOptions]: clean.buyerOptions,
[SYNC_STORAGE_KEYS.sellerOptions]: clean.sellerOptions,
[SYNC_STORAGE_KEYS.interface]: {
...deviceUi,
filters: [...clean.interface.filters],
sbcPolicy: JSON.parse(JSON.stringify(clean.interface.sbcPolicy)),
},
[SYNC_STORAGE_KEYS.packLocks]: clean.packLocks,
});
}
