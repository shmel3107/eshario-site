import { verifyLicenseKey } from '../licensing/key.js';
import { BUY_URL } from '../licensing/buy-url.js';
import { chooseLocale, currentTimeZone } from '../i18n/detect.js';
import { en as panelEn } from '../i18n/dict.en.js';
import { ru as panelRu } from '../i18n/dict.ru.js';
import { settingsRegistryEn, settingsRegistryRu } from '../i18n/dict.settings-registry.js';
const UI_STATE_KEY = 'ui.state';
const DRAFT_KEY = 'account.draft';
const LAST_EMAIL_KEY = 'account.email';
async function readDraft() {
try {
const got = await chrome.storage?.session?.get?.(DRAFT_KEY);
const draft = got?.[DRAFT_KEY];
return typeof draft === 'object' && draft !== null ? draft : null;
} catch { return null; }
}
async function writeDraft(draft) {
try { await chrome.storage?.session?.set?.({ [DRAFT_KEY]: draft }); } catch { /* памяти сессии нет — живём без черновика */ }
}
async function dropDraft() {
try { await chrome.storage?.session?.remove?.(DRAFT_KEY); } catch { /* стирать нечего — и хорошо */ }
}
async function readLastEmail() {
try {
const got = await chrome.storage.local.get(LAST_EMAIL_KEY);
const email = got?.[LAST_EMAIL_KEY];
return typeof email === 'string' ? email : '';
} catch { return ''; }
}
async function rememberEmail(email) {
if (typeof email !== 'string' || email === '') return;
try { await chrome.storage.local.set({ [LAST_EMAIL_KEY]: email }); } catch { /* не записалось — в следующий раз наберёт руками */ }
}
async function forgetEmail() {
try { await chrome.storage.local.remove(LAST_EMAIL_KEY); } catch { /* нечего стирать */ }
}
let messages = null;
const msg = (key, args) => {
const entry = messages?.[key];
const own = entry?.message;
if (typeof own === 'string' && own !== '') {
const named = entry.placeholders ?? {};
const pick = (index) => String(args?.[Number(index) - 1] ?? '');
return own
.replace(/\$([A-Za-z0-9_]+)\$/g, (whole, name) => {
const content = named[String(name).toLowerCase()]?.content;
const index = typeof content === 'string' ? /^\$(\d)$/.exec(content)?.[1] : null;
return index === undefined || index === null ? whole : pick(index);
})
.replace(/\$(\d)/g, (whole, index) => (args?.[Number(index) - 1] === undefined ? whole : pick(index)));
}
return chrome.i18n.getMessage(key, args) || key;
};
async function storedLocale() {
try {
const stored = await chrome.storage.local.get(UI_STATE_KEY);
const locale = stored?.[UI_STATE_KEY]?.locale;
return typeof locale === 'string' ? locale : null;
} catch { return null; } /* хранилище недоступно — решает лестница */
}
async function chosenLocale() {
return chooseLocale(await storedLocale(), navigator.languages, currentTimeZone());
}
async function rememberLocale(locale) {
const stored = await chrome.storage.local.get(UI_STATE_KEY);
const state = stored?.[UI_STATE_KEY];
const next = typeof state === 'object' && state !== null ? { ...state, locale } : { locale };
await chrome.storage.local.set({ [UI_STATE_KEY]: next });
}
async function applyLocale() {
const locale = await chosenLocale();
try {
const response = await fetch(chrome.runtime.getURL(`_locales/${locale}/messages.json`));
messages = await response.json();
} catch { messages = null; }
document.querySelectorAll('[data-i18n]').forEach((node) => {
node.textContent = msg(node.dataset.i18n);
});
document.querySelectorAll('[data-i18n-title]').forEach((node) => {
node.title = msg(node.dataset.i18nTitle);
});
document.querySelectorAll('[data-i18n-label]').forEach((node) => {
node.setAttribute('aria-label', msg(node.dataset.i18nLabel));
});
return locale;
}
const WORDS = {
'invalid-credentials': 'accountBadCredentials',
'rate-limited': 'accountTooManyTries',
network: 'accountNoNetwork',
'invalid-input': 'accountShortPassword',
'no-response': 'accountNoAnswer',
'account-blocked': 'accountBlocked',
};
function dateOf(ms) {
const date = new Date(ms);
const pad = (value) => String(value).padStart(2, '0');
return `${pad(date.getDate())}.${pad(date.getMonth() + 1)}.${date.getFullYear()}`;
}
async function rightOf(entitlement) {
if (typeof entitlement !== 'string' || entitlement === '') return { ok: false, exp: null, none: true };
try {
const result = await verifyLicenseKey(entitlement, { now: Date.now() });
return { ok: result.ok === true, exp: result.exp ?? null, none: false };
} catch {
return { ok: false, exp: null, none: false };
}
}
async function doorOf() {
try {
const tab = await chrome.tabs?.getCurrent?.();
return tab === undefined || tab === null ? 'popup' : 'tab';
} catch {
return 'popup';
}
}
export async function startAccountUi() {
document.documentElement.dataset.shell = await doorOf();
const locale = await applyLocale();
let current = locale;
const byId = (id) => document.getElementById(id);
const status = byId('status');
const syncStatus = byId('sync-status');
const syncButtons = [...document.querySelectorAll('#sync-buttons button')];
const send = (method, params) => chrome.runtime.sendMessage({ method, params })
.then((value) => value || { ok: false, reason: 'no-response' },
() => ({ ok: false, reason: 'network' }));
let cloudUiDropped = false;
function dropCloudUi() {
if (cloudUiDropped) return;
cloudUiDropped = true;
const nodes = [
byId('account-actions'),
byId('settings-sync'),
byId('signin'),
...document.querySelectorAll('main form'),
];
for (const node of nodes) node?.remove();
}
function reflect(value) {
const signedIn = value?.ok === true && value.authenticated === true;
for (const node of document.querySelectorAll('[data-when]')) {
node.hidden = node.dataset.when === (signedIn ? 'out' : 'in');
}
}
const buy = byId('buy');
const links = byId('links');
function say(text, state, rightWorks = false) {
status.textContent = text;
status.dataset.state = state;
if (buy !== null) buy.hidden = rightWorks;
if (links !== null) links.hidden = rightWorks;
}
async function show(value) {
if (value?.configured === false) {
dropCloudUi();
say(msg('accountNotConfigured'), 'plain');
return;
}
reflect(value);
if (value?.ok !== true) {
say(msg(WORDS[value?.reason] ?? 'accountError'), 'error');
return;
}
if (value.authenticated === true) {
const hint = value.account?.hint ?? '';
const right = await rightOf(value.entitlement);
if (right.none) {
say(msg('accountFree', [hint]), 'free');
return;
}
if (!right.ok) {
say(msg('accountCheckFailed'), 'error');
return;
}
const until = dateOf(right.exp);
say(value.cached === true
? `${msg('accountPremiumUntil', [until, hint])} ${msg('accountOffline', [until])}`
: msg('accountPremiumUntil', [until, hint]),
value.cached === true ? 'offline' : 'premium', true);
return;
}
say(msg('accountSignedOut'), 'free');
}
const refresh = () => send('account.status', { force: true }).then(show);
const TRANSFER_WORDS = {
'not-signed-in': 'accountSyncNotSignedIn',
offline: 'accountSyncOffline',
server: 'accountSyncServer',
conflict: 'accountSyncConflict',
'too-big': 'accountSyncTooBig',
empty: 'accountSyncEmpty',
'no-port': 'accountSyncNoPort',
};
const TRANSFER_CONFIRMS = {
save: { titleKey: 'settings.organ.premium.confirm.saveTitle', messageKey: 'settings.organ.premium.confirm.saveText' },
load: { titleKey: 'settings.organ.premium.confirm.loadTitle', messageKey: 'settings.organ.premium.confirm.loadText' },
};
const TRANSFER_DONE = {
save: { key: 'settings.organ.premium.transfer.saved', plainKey: 'settings.organ.premium.transfer.savedPlain' },
load: { key: 'settings.organ.premium.transfer.loaded', plainKey: 'settings.organ.premium.transfer.loadedPlain' },
};
const confirmBox = byId('sync-confirm');
const panelWord = (key, params = {}) => {
const words = current === 'ru' ? { ...panelRu, ...settingsRegistryRu } : { ...panelEn, ...settingsRegistryEn };
return String(words[key] ?? key).replace(/\{(\w+)\}/g, (whole, name) => (name in params ? String(params[name]) : whole));
};
function askYesNo(direction) {
const ask = TRANSFER_CONFIRMS[direction];
const yes = byId('sync-confirm-yes');
const no = byId('sync-confirm-no');
if (confirmBox === null || yes === null || no === null || typeof confirmBox.showModal !== 'function') {
return Promise.resolve(false);
}
byId('sync-confirm-title').textContent = panelWord(ask.titleKey);
byId('sync-confirm-text').textContent = panelWord(ask.messageKey);
no.textContent = panelWord('dialog.cancel');
yes.textContent = panelWord('dialog.confirm');
return new Promise((resolve) => {
const done = (answer) => {
yes.removeEventListener('click', onYes);
no.removeEventListener('click', onNo);
confirmBox.removeEventListener('cancel', onEscape);
confirmBox.removeEventListener('click', onMiss);
if (confirmBox.open) confirmBox.close();
resolve(answer);
};
const onYes = () => done(true);
const onNo = () => done(false);
const onEscape = (event) => { event.preventDefault(); done(false); };
const onMiss = (event) => { if (event.target === confirmBox) done(false); };
yes.addEventListener('click', onYes);
no.addEventListener('click', onNo);
confirmBox.addEventListener('cancel', onEscape);
confirmBox.addEventListener('click', onMiss);
confirmBox.showModal();
no.focus();
});
}
async function runTransfer(direction) {
if (syncStatus === null) return;
if (!(await askYesNo(direction))) return;
syncButtons.forEach((button) => { button.disabled = true; });
try {
const value = await send('settings.transfer', { direction });
const revision = Number.isSafeInteger(value?.revision) ? value.revision : null;
const done = TRANSFER_DONE[direction];
syncStatus.textContent = value?.ok === true
? panelWord(revision === null ? done.plainKey : done.key, { revision })
: msg(TRANSFER_WORDS[value?.reason] ?? 'accountSyncServer');
syncStatus.dataset.state = value?.ok === true ? 'success'
: (value?.reason === 'conflict' || value?.reason === 'empty' ? 'offline' : 'error');
syncStatus.hidden = false;
} finally {
syncButtons.forEach((button) => { button.disabled = false; });
}
}
byId('refresh')?.addEventListener('click', refresh);
byId('logout')?.addEventListener('click', () => send('account.logout').then(show));
byId('sync-save')?.addEventListener('click', () => runTransfer('save'));
byId('sync-load')?.addEventListener('click', () => runTransfer('load'));
byId('login')?.addEventListener('submit', (event) => {
event.preventDefault();
const password = byId('password');
const email = byId('email').value;
send('account.login', {
email,
password: password.value,
}).then(async (value) => {
password.value = '';
if (value?.ok === true && value.authenticated === true) {
await rememberEmail(email);
await dropDraft();
}
show(value);
});
});
byId('recovery-start')?.addEventListener('submit', (event) => {
event.preventDefault();
send('account.recovery.start', {
email: byId('recovery-email').value,
}).then((value) => {
status.textContent = value?.ok === true
? msg('accountRecoveryAccepted') : msg('accountError');
});
});
byId('recovery-complete')?.addEventListener('submit', (event) => {
event.preventDefault();
const password = byId('new-password');
send('account.recovery.complete', {
token: byId('recovery-token').value,
password: password.value,
}).then((value) => {
password.value = '';
status.textContent = value?.ok === true
? msg('accountRecoveryDone') : msg('accountError');
});
});
const recoveryToggle = byId('recovery-toggle');
const recoveryForms = byId('recovery-forms');
const loginForm = byId('login');
function setRecovery(open) {
if (recoveryForms === null || recoveryToggle === null) return;
recoveryForms.hidden = !open;
if (loginForm !== null) loginForm.hidden = open;
recoveryToggle.setAttribute('aria-expanded', String(open));
recoveryToggle.textContent = msg(open ? 'accountRecoveryBack' : 'accountRecoveryTitle');
}
const emailField = byId('email');
const recoveryEmailField = byId('recovery-email');
const emailWipe = byId('email-wipe');
const markWipe = () => {
if (emailWipe !== null) emailWipe.hidden = (emailField?.value ?? '') === '';
};
const saveDraft = () => writeDraft({
email: emailField?.value ?? '',
recoveryEmail: recoveryEmailField?.value ?? '',
recovery: recoveryForms !== null && recoveryForms.hidden === false,
});
emailField?.addEventListener('input', () => { markWipe(); saveDraft(); });
recoveryEmailField?.addEventListener('input', saveDraft);
recoveryToggle?.addEventListener('click', () => {
setRecovery(recoveryForms.hidden);
saveDraft();
});
emailWipe?.addEventListener('click', async () => {
if (emailField !== null) {
emailField.value = '';
emailField.focus();
}
markWipe();
await forgetEmail();
await saveDraft();
});
const draft = await readDraft();
const lastEmail = await readLastEmail();
if (emailField !== null) {
emailField.value = typeof draft?.email === 'string' && draft.email !== ''
? draft.email : lastEmail;
}
if (recoveryEmailField !== null && typeof draft?.recoveryEmail === 'string') {
recoveryEmailField.value = draft.recoveryEmail;
}
if (draft?.recovery === true) setRecovery(true);
markWipe();
const langButtons = [...document.querySelectorAll('.lang[data-locale]')];
const markLanguage = (active) => {
for (const node of langButtons) {
node.setAttribute('aria-pressed', String(node.dataset.locale === active));
}
};
const useLocale = (next) => {
if (buy !== null) buy.href = BUY_URL[next] ?? BUY_URL.en;
if (recoveryToggle !== null && recoveryForms !== null && !recoveryForms.hidden) {
recoveryToggle.textContent = msg('accountRecoveryBack');
}
markLanguage(next);
};
useLocale(locale);
for (const node of langButtons) {
node.addEventListener('click', async () => {
const next = node.dataset.locale;
if (next === current) return;
current = next;
await rememberLocale(next);
useLocale(await applyLocale());
await refresh();
});
}
await refresh();
}
