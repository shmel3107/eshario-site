import{FEATURES} from '../licensing/features.js'
export const LIVE_EVIDENCE_SCHEMA=1
export const LIVE_EVIDENCE_LIMIT=50
export const PHASE_LOG_LIMIT=50
export const PHASE_LOG_KEY='eshario.phases'
const PHASE_LOG_BYTES=32_000
const VERDICT_KEYS_LIMIT=12
const STAT_KEYS=Object.freeze(['coins','spent','loss','purchases','searches','startedAt','earned','profit','wouldBuy','bids','outbid','moved','rests','listings','listedValue','quickSells','relisted','cleared','elapsedMs','policySkipped'
])
const SUMMARY_KEYS=Object.freeze(['total','tradeable','untradeable','unknownTradability','inActiveSquad','listed','loans','sellable','withoutIdentity'
])
const VALUE_KEYS=Object.freeze(['coins','priced','withoutPrice','notAsked','limitReached'
])
const ITEM_EVIDENCE_CONTEXTS=Object.freeze(['market','transfer','unassigned','club'])
const ITEM_EVIDENCE_MONEY_STATES=Object.freeze(['known','unknown','unavailable'])
const ITEM_EVIDENCE_FRESHNESS=Object.freeze(['observation-only','provider-timestamp','unknown'])
const ITEM_EVIDENCE_FIELD_COUNT=6
const ITEM_EVIDENCE_COUNT_LIMIT=10_000
const SAFE_SETTING_KEYS=new Set(Object.keys(FEATURES))
export function createLiveEvidenceRecorder(deps){if(!deps||typeof deps.now!=='function'){throw new Error('live evidence: нужны часы')}
const limit=positiveInteger(deps.limit,LIVE_EVIDENCE_LIMIT)
const events=[]
let seq=0
return{
record(kind,result,detail={}){const event={seq:++seq,at:finiteNumber(deps.now())??0,kind:safeText(kind,64)||'unknown',ok:result?.ok===true?true:(result?.ok===false?false:null),reason:resultReason(result),detail:primitiveDetail(detail)}
events.push(event)
if(events.length>limit)events.splice(0,events.length-limit)
return{...event,detail:{...event.detail}}},
list(){return events.map((event)=>({...event,detail:{...event.detail}}))}}}
export function createPhaseLog(deps={}){if(!deps||typeof deps.now!=='function'){throw new Error('phase log: нужны часы')}
const limit=positiveInteger(deps.limit,PHASE_LOG_LIMIT)
const key=safeText(deps.key,80)||PHASE_LOG_KEY
const maxBytes=positiveInteger(deps.maxBytes,PHASE_LOG_BYTES)
const entries=[]
const counts={marks:0,dropped:0,writes:0,writeFailed:0,tooBig:0,readFailed:0,noStorage:0}
let seq=0
const storage=reachableStorage(deps.storage)
if(storage===null&&deps.storage!==null&&deps.storage!==undefined)counts.noStorage+=1
let previous=[]
if(storage!==null){let raw=null
try{raw=storage.getItem?.(key)??null}catch{counts.readFailed+=1
raw=null}
if(typeof raw==='string'&&raw!==''){try{const parsed=JSON.parse(raw)
previous=sanitizePhases(parsed?.current,limit)}catch{counts.readFailed+=1
previous=[]}}}
const persist=()=>{if(storage===null)return false
let text=''
try{text=JSON.stringify({schema:LIVE_EVIDENCE_SCHEMA,previous,current:entries})}catch{counts.writeFailed+=1
return false}
if(text.length>maxBytes){counts.tooBig+=1
return false}
try{storage.setItem?.(key,text)
counts.writes+=1
return true}catch{counts.writeFailed+=1
return false}}
const push=(phase,detail)=>{const entry={seq:++seq,at:finiteNumber(deps.now())??0,phase:phaseName(phase),detail:phaseDetail(detail)}
entries.push(entry)
counts.marks+=1
if(entries.length>limit){counts.dropped+=entries.length-limit
entries.splice(0,entries.length-limit)}
persist()
return{...entry,detail:{...entry.detail}}}
return{
mark(phase,detail={}){return push(phase,detail)},
sample(phase,facts={}){const name=phaseName(phase)
const next=phaseDetail(facts)
for(let at=entries.length-1;at>=0;at-=1){const one=entries[at]
if(one.phase!==name)continue
return sameDetail(one.detail,next)?null:push(name,next)}
return push(name,next)},
list(){return entries.map((entry)=>({...entry,detail:{...entry.detail}}))},
previous(){return previous.map((entry)=>({...entry,detail:{...entry.detail}}))},
state(){return{limit,key,stored:storage!==null,previousEntries:previous.length,entries:entries.length,counts:{...counts}}}}}
function reachableStorage(value){let raw=null
try{raw=typeof value==='function'?value():value}catch{return null}
if(!raw||typeof raw!=='object'&&typeof raw!=='function')return null
try{return typeof raw.getItem==='function'&&typeof raw.setItem==='function'?raw:null}catch{return null}}
function sanitizePhases(value,limit=PHASE_LOG_LIMIT){if(!Array.isArray(value))return[]
return value.slice(-limit).map((raw)=>{if(!raw||typeof raw!=='object')return null
return{seq:nonNegativeInteger(raw.seq)??0,at:finiteNumber(raw.at)??0,phase:phaseName(raw.phase),detail:phaseDetail(raw.detail)}}).filter(Boolean)}
function phaseDetail(value){const out=primitiveDetail(value)
for(const[key,raw]of Object.entries(out)){if(typeof raw==='string')out[key]=maskSecrets(raw)
else if(typeof raw==='number')out[key]=maskNumber(raw)}
return out}
function maskNumber(value){const text=String(value)
const masked=maskSecrets(text)
return masked===text?value:masked}
function phaseName(value){return maskSecrets(safeText(value,64))||'unknown'}
function sameDetail(left,right){const a=left&&typeof left==='object'?left:{}
const b=right&&typeof right==='object'?right:{}
const keys=Object.keys(a)
if(keys.length!==Object.keys(b).length)return false
for(const one of keys){if(!Object.hasOwn(b,one)||a[one]!==b[one])return false}
return true}
export function autologinEvidence(result){if(!result||typeof result!=='object'){return{settled:false,ok:null,reason:'pending',attempts:null,landing:null}}
return{settled:true,ok:result.ok===true,reason:safeText(result.reason,80)||null,attempts:nonNegativeInteger(result.attempts),landing:landingEvidence(result.landing)}}
function landingEvidence(value){if(!value||typeof value!=='object')return null
return{last:safeText(value.last,80)||null,
pressed:value.pressed===true,
armed:typeof value.armed==='boolean'?value.armed:null,
asked:nonNegativeInteger(value.asked)??0,
login:typeof value.login==='boolean'?value.login:null,
session:typeof value.session==='boolean'?value.session:null,
seen:verdictCounts(value.seen),
lookedAt:finiteNumber(value.lookedAt),
seenAt:finiteNumber(value.seenAt),
pressedAt:finiteNumber(value.pressedAt),
previous:previousLanding(value.previous)}}
export function engineEvidence(status){const value=status&&typeof status==='object'?status:{}
return{running:value.running===true,dryRun:value.dryRun!==false,reason:safeText(value.reason,80)||null,stats:statsEvidence(value.stats)}}
export function clubEvidence(state){const value=state&&typeof state==='object'?state:{}
const analysis=value.analysis&&typeof value.analysis==='object'?value.analysis:null
return{busy:value.busy===true,notice:safeText(value.notice?.key,100)||null,analyzed:Boolean(analysis),summary:pickNumbers(analysis?.summary,SUMMARY_KEYS),duplicateGroups:Array.isArray(analysis?.duplicates)?analysis.duplicates.length:null,candidates:Array.isArray(analysis?.candidates)?analysis.candidates.length:null,value:pickNumbersAndBooleans(analysis?.value,VALUE_KEYS)}}
export function domEvidence(doc,panelHost=null){const cards=query(doc,'.ut-item-view')
const root=panelHost?.shadowRoot??null
return{cards:{found:cards.length,decorated:cards.filter((card)=>card?.dataset?.futCompanion==='card').length,toolbars:query(doc,'[data-fut-companion-tools="1"]').length,minBinButtons:query(doc,'[data-fut-action="minBin"]').length,readableNames:cards.filter((card)=>{const text=card?.querySelector?.('.name')?.textContent;
return typeof text==='string'&&text.trim()!==''
}).length},transferList:listEvidence(doc,'.ut-transfer-list-view','transfer'),unassignedList:listEvidence(doc,'.ut-unassigned-view','unassigned'),objectivesList:listEvidence(doc,'.ut-objectives-hub','objectives','.ut-objective-group-view'
),clubList:listEvidence(doc,'.ut-club-search-results-view','club'),itemEvidence:itemEvidence(doc),panel:{mounted:Boolean(panelHost),shadowRoot:Boolean(root),filterApplyButtons:query(root,'[data-action="apply"]').length,sellerSection:query(root,'[data-seller-status="1"]').length,clubSection:query(root,'[data-club-status="1"]').length}}}
export function buildLiveEvidence(input={}){const settings={}
for(const[key,value]of Object.entries(input.settings??{})){const safeKey=safeText(key,80)
if(SAFE_SETTING_KEYS.has(safeKey))settings[safeKey]=value===true}
return sanitizeLiveEvidenceSnapshot({schema:LIVE_EVIDENCE_SCHEMA,capturedAt:finiteNumber(input.now)??0,extension:{bridge:safeText(input.bridge,120)||null,version:safeText(input.version,40)||null,panel:safeText(input.panel,40)||null,errors:(Array.isArray(input.errors)?input.errors:[])
.slice(-20)
.map((value)=>safeError(value))
.filter(Boolean)},page:{origin:safeOrigin(input.origin),...(input.dom&&typeof input.dom==='object'?input.dom:{})},settings,buyer:engineEvidence(input.buyer),seller:engineEvidence(input.seller),club:clubEvidence(input.club),autologin:autologinEvidence(input.autologin),events:Array.isArray(input.events)
?input.events.slice(-LIVE_EVIDENCE_LIMIT).map(sanitizeEvent).filter(Boolean)
:[]})}
export function sanitizeLiveEvidenceSnapshot(input={}){const value=input&&typeof input==='object'&&!Array.isArray(input)?input:{}
const extension=value.extension&&typeof value.extension==='object'?value.extension:{}
const page=value.page&&typeof value.page==='object'?value.page:{}
const settings={}
for(const[key,raw]of Object.entries(value.settings??{})){const safeKey=safeText(key,80)
if(SAFE_SETTING_KEYS.has(safeKey))settings[safeKey]=raw===true}
return{schema:LIVE_EVIDENCE_SCHEMA,capturedAt:finiteNumber(value.capturedAt)??0,extension:{bridge:safeText(extension.bridge,120)||null,version:safeText(extension.version,40)||null,panel:safeText(extension.panel,40)||null,errors:(Array.isArray(extension.errors)?extension.errors:[])
.slice(-20).map((raw)=>safeError(raw)).filter(Boolean)},page:{origin:safeOrigin(page.origin),cards:countFields(page.cards,['found','decorated','toolbars','minBinButtons','readableNames']),transferList:countFields(page.transferList,['rows','toolbars']),unassignedList:countFields(page.unassignedList,['rows','toolbars']),objectivesList:countFields(page.objectivesList,['rows','toolbars']),clubList:countFields(page.clubList,['rows','toolbars']),...(page.itemEvidence&&typeof page.itemEvidence==='object'?{itemEvidence:storedItemEvidence(page.itemEvidence)}:{}),panel:panelEvidence(page.panel)},settings,buyer:engineEvidence(value.buyer),seller:engineEvidence(value.seller),club:storedClubEvidence(value.club),autologin:storedAutologinEvidence(value.autologin),events:(Array.isArray(value.events)?value.events:[])
.slice(-LIVE_EVIDENCE_LIMIT).map(sanitizeEvent).filter(Boolean)}}
function statsEvidence(value){if(!value||typeof value!=='object') return null
return{...pickNumbers(value,STAT_KEYS),captcha:value.captcha===true,fatal:finiteNumber(value.fatal),failures:pickNumbers(value.failures,['captcha','fatal','out-of-coins','gone','throttled','transient','unknown'])}}
function sanitizeEvent(value){if(!value||typeof value!=='object') return null
return{seq:nonNegativeInteger(value.seq)??0,at:finiteNumber(value.at)??0,kind:safeText(value.kind,64)||'unknown',ok:value.ok===true?true:(value.ok===false?false:null),reason:safeText(value.reason,120)||null,detail:primitiveDetail(value.detail)}}
function resultReason(result){const direct=safeText(result?.reason,120)
if(direct)return direct
return safeText(result?.notice?.key,120)||null}
function primitiveDetail(value){const out={}
if(!value||typeof value!=='object') return out
for(const[key,raw]of Object.entries(value)){const safeKey=safeText(key,60)
if(!safeKey)continue
if(typeof raw==='boolean') out[safeKey]=raw
else if(typeof raw==='number'&&Number.isFinite(raw)) out[safeKey]=raw
else if(typeof raw==='string') out[safeKey]=safeText(raw,120)
else if(raw===null)out[safeKey]=null}
return out}
function pickNumbers(value,keys){if(!value||typeof value!=='object') return null
const out={}
for(const key of keys){const number=finiteNumber(value[key])
if(number!==null)out[key]=number}
return out}
function pickNumbersAndBooleans(value,keys){if(!value||typeof value!=='object') return null
const out={}
for(const key of keys){if(typeof value[key]==='boolean') out[key]=value[key]
else{const number=finiteNumber(value[key])
if(number!==null)out[key]=number}}
return out}
function countFields(value,keys){const out={}
if(!value||typeof value!=='object')return out
for(const key of keys){const number=nonNegativeInteger(value[key])
if(number!==null)out[key]=number}
return out}
function panelEvidence(value){const out={}
if(!value||typeof value!=='object')return out
for(const key of ['mounted','shadowRoot'])if(typeof value[key]==='boolean')out[key]=value[key]
for(const key of ['filterApplyButtons','sellerSection','clubSection']){const number=nonNegativeInteger(value[key])
if(number!==null)out[key]=number}
return out}
function storedClubEvidence(value){if(!value||typeof value!=='object')return clubEvidence(null)
if(typeof value.analyzed!=='boolean')return clubEvidence(value)
return{busy:value.busy===true,notice:safeText(value.notice,100)||null,analyzed:value.analyzed,summary:pickNumbers(value.summary,SUMMARY_KEYS),duplicateGroups:nonNegativeInteger(value.duplicateGroups),candidates:nonNegativeInteger(value.candidates),value:pickNumbersAndBooleans(value.value,VALUE_KEYS)}}
function storedAutologinEvidence(value){if(value?.settled===false)return{settled:false,ok:null,reason:safeText(value.reason,80)||'pending',attempts:nonNegativeInteger(value.attempts),landing:landingEvidence(value.landing)}
return autologinEvidence(value)}
function verdictCounts(value){const out={}
if(!value||typeof value!=='object')return out
let left=VERDICT_KEYS_LIMIT
for(const[key,raw]of Object.entries(value)){if(left<=0)break
const safeKey=safeText(key,40)
if(!safeKey)continue
const number=nonNegativeInteger(raw)
if(number===null)continue
out[safeKey]=number
left-=1}
return out}
function previousLanding(value){if(!value||typeof value!=='object')return null
return{pressed:value.pressed===true,lookedAt:finiteNumber(value.lookedAt),seenAt:finiteNumber(value.seenAt),pressedAt:finiteNumber(value.pressedAt)}}
function query(root,selector){try{return Array.from(root?.querySelectorAll?.(selector)??[])}catch{return[]}}
function listEvidence(doc,root,key,row='.listFUTItem'){return{rows:query(doc,`${root} ${row}`).length,toolbars:query(doc,`[data-fut-${key}-tools="1"]`).length}}
function itemEvidence(doc){const out=emptyItemEvidence()
const overlays=query(doc,'[data-fut-item-evidence]').slice(0,ITEM_EVIDENCE_COUNT_LIMIT)
out.total=overlays.length
for(const overlay of overlays){const context=overlay?.dataset?.futItemEvidence
const priceState=overlay?.dataset?.futItemEvidencePriceState
const boughtState=overlay?.dataset?.futItemEvidenceBoughtState
const freshness=overlay?.dataset?.futItemEvidenceFreshness
const fields=query(overlay,'[data-fut-item-evidence-field]').length
out.actionControls=boundedCount(out.actionControls+query(overlay,'button,a[href],input,select,textarea,[data-action]').length)
if(!ITEM_EVIDENCE_CONTEXTS.includes(context)||!ITEM_EVIDENCE_MONEY_STATES.includes(priceState)||!ITEM_EVIDENCE_MONEY_STATES.includes(boughtState)||!ITEM_EVIDENCE_FRESHNESS.includes(freshness)||fields!==ITEM_EVIDENCE_FIELD_COUNT){out.malformed=boundedCount(out.malformed+1)
continue}
out.byContext[context]=boundedCount(out.byContext[context]+1)
out.priceStates[priceState]=boundedCount(out.priceStates[priceState]+1)
out.boughtStates[boughtState]=boundedCount(out.boughtStates[boughtState]+1)
out.freshness[freshnessKey(freshness)]=boundedCount(out.freshness[freshnessKey(freshness)]+1)}
out.duplicateRows=boundedCount(query(doc,'.listFUTItem').filter((row)=>query(row,'[data-fut-item-evidence]').length>1).length)
return out}
function emptyItemEvidence(){return{total:0,byContext:zeroCounts(ITEM_EVIDENCE_CONTEXTS),priceStates:zeroCounts(ITEM_EVIDENCE_MONEY_STATES),boughtStates:zeroCounts(ITEM_EVIDENCE_MONEY_STATES),freshness:{observationOnly:0,providerTimestamp:0,unknown:0},duplicateRows:0,malformed:0,actionControls:0}}
function storedItemEvidence(value){const out=emptyItemEvidence()
out.total=safeEvidenceCount(value?.total)
out.byContext=safeEvidenceCounts(value?.byContext,ITEM_EVIDENCE_CONTEXTS)
out.priceStates=safeEvidenceCounts(value?.priceStates,ITEM_EVIDENCE_MONEY_STATES)
out.boughtStates=safeEvidenceCounts(value?.boughtStates,ITEM_EVIDENCE_MONEY_STATES)
out.freshness=safeEvidenceCounts(value?.freshness,['observationOnly','providerTimestamp','unknown'])
out.duplicateRows=safeEvidenceCount(value?.duplicateRows)
out.malformed=safeEvidenceCount(value?.malformed)
out.actionControls=safeEvidenceCount(value?.actionControls)
return out}
function zeroCounts(keys){return Object.fromEntries(keys.map((key)=>[key,0]))}
function safeEvidenceCounts(value,keys){const out=zeroCounts(keys)
for(const key of keys)out[key]=safeEvidenceCount(value?.[key])
return out}
function safeEvidenceCount(value){return Number.isSafeInteger(value)&&value>=0?Math.min(value,ITEM_EVIDENCE_COUNT_LIMIT):0}
function boundedCount(value){return Math.min(value,ITEM_EVIDENCE_COUNT_LIMIT)}
function freshnessKey(value){return value==='observation-only'?'observationOnly':value==='provider-timestamp'?'providerTimestamp':'unknown'}
function safeOrigin(value){if(typeof value!=='string') return null
try{const url=new URL(value)
return url.protocol==='https:'?url.origin:null}catch{return null}}
function safeText(value,max){if(typeof value!=='string') return ''
return value.trim().slice(0,max)}
function safeError(value){return maskSecrets(safeText(value,240))}
function maskSecrets(text){return text
.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,'[email]')
.replace(/\b\d{6,}\b/g,'[id]')
.replace(/[A-Za-z0-9_-]{32,}/g,'[redacted]')
.replace(/https?:\/\/[^\s"'<>]+/gi,'[url]')}
function finiteNumber(value){return typeof value==='number'&&Number.isFinite(value)?value:null}
function nonNegativeInteger(value){return Number.isInteger(value)&&value>=0?value:null}
function positiveInteger(value,fallback){return Number.isInteger(value)&&value>0?value:fallback}
