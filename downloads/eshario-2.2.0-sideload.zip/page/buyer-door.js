export const BUYER_OFF_SCREEN='panel.start.onScreen'
export const BUYER_NO_ENGINE='snipe.noEngine'
export function createBuyerDoor({bar=()=>null,engine=null,onError=()=>{}}={}){
const barNow=()=>{try{return typeof bar==='function'?bar():(bar??null)}catch(err){onError(err)
return null}}
function ready(one){if(one===null||typeof one.askStart!=='function')return false
let said=null
try{said=typeof one.state==='function'?one.state():null}catch(err){onError(err)
return false}
return said?.screen===true&&Number(said?.bar??0)>0}
function start(){const one=barNow()
if(!ready(one))return{ok:false,notice:{key:BUYER_OFF_SCREEN,params:{}},reason:'off-screen',opened:false}
let opened=false
try{opened=one.askStart()===true}catch(err){onError(err)
opened=false}
return{ok:opened,notice:null,reason:opened?null:'refused',opened}}
function stop(){if(engine===null||typeof engine.stop!=='function'){
return{ok:false,notice:{key:BUYER_NO_ENGINE,params:{}},reason:'no-engine',opened:false}}
let result=null
try{result=engine.stop()}catch(err){onError(err)
return{ok:false,notice:{key:BUYER_NO_ENGINE,params:{}},reason:'threw',opened:false}}
return{...result,opened:false}}
return{
press(action){return action==='stop'?stop():start()},
ready:()=>ready(barNow())}}
