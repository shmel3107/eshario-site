import{createCachedProvider} from '../core/storage-provider.js'
import{sanitizeLiveEvidenceSnapshot} from './live-evidence.js'
export const LIVE_CONTROL_SCHEMA=2
export const LIVE_CONTROL_KEY='live.control'
export const LIVE_CONTROL_READ='live-control.read'
export const LIVE_CONTROL_WRITE='live-control.write'
export const SAFE_LIVE_CHECKS=Object.freeze([1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,21,22,23,24,25,26,27,29,31,33])
export const DEFERRED_LIVE_CHECKS=Object.freeze([13,20,28,30,32,34,35,36,37])
const SAFE_SET=new Set(SAFE_LIVE_CHECKS)
export function createBridgeLiveControlProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function')throw new Error('live control: bridge unavailable')
return createCachedProvider({fetch:()=>bridge.request(LIVE_CONTROL_READ),push:(value)=>bridge.request(LIVE_CONTROL_WRITE,value),sanitize:sanitizeControlState,fallback:emptyState,onError:opts.onError})}
export function createLiveControlSession(deps={}){if(typeof deps.now!=='function')throw new Error('live control: clock required')
if(typeof deps.capture!=='function')throw new Error('live control: capture required')
const provider=deps.provider??null
let state=sanitizeControlState(readProvider(provider))
const persist=()=>{if(provider&&typeof provider.write==='function'){try{provider.write(copyState(state))}catch{
}}
return copyState(state)}
const ensureStarted=()=>{if(state.startedAt===null)state.startedAt=finite(deps.now())??0}
return{
reset(){state=emptyState()
state.startedAt=finite(deps.now())??0
persist()
return summary(state)},
capture(check){const id=Number(check)
if(!Number.isInteger(id)||!SAFE_SET.has(id))throw new Error(`live control: check ${String(check)} not in safe control`)
ensureStarted()
const entry={check:id,at:finite(deps.now())??0,evidence:sanitizeLiveEvidenceSnapshot(deps.capture())}
const index=state.captures.findIndex((item)=>item.check===id)
if(index===-1)state.captures.push(entry)
else state.captures[index]=entry
persist()
return{check:id,...summary(state)}},
status(){return summary(state)},
export(){ensureStarted()
return{schema:LIVE_CONTROL_SCHEMA,safeChecks:[...SAFE_LIVE_CHECKS],deferredChecks:[...DEFERRED_LIVE_CHECKS],startedAt:state.startedAt,capturedAt:finite(deps.now())??0,captures:state.captures.map(copyCapture),completed:state.captures.map((item)=>item.check),pending:SAFE_LIVE_CHECKS.filter((id)=>!state.captures.some((item)=>item.check===id)),current:sanitizeLiveEvidenceSnapshot(deps.capture())}}
}}
export function sanitizeControlState(value){const input=value&&typeof value==='object'&&!Array.isArray(value)?value:{}
const captures=[]
const seen=new Set()
for(const raw of Array.isArray(input.captures)?input.captures:[]){const check=Number(raw?.check)
if(!Number.isInteger(check)||!SAFE_SET.has(check)||seen.has(check))continue
seen.add(check)
captures.push({check,at:finite(raw?.at)??0,evidence:sanitizeLiveEvidenceSnapshot(raw?.evidence)})}
return{schema:LIVE_CONTROL_SCHEMA,startedAt:finite(input.startedAt),captures}}
function emptyState(){return{schema:LIVE_CONTROL_SCHEMA,startedAt:null,captures:[]}}
function readProvider(provider){if(!provider||typeof provider.read!=='function')return null
try{return provider.read()}catch{return null}}
function summary(value){const completed=value.captures.map((item)=>item.check)
return{schema:LIVE_CONTROL_SCHEMA,startedAt:value.startedAt,completed,pending:SAFE_LIVE_CHECKS.filter((id)=>!completed.includes(id))}}
function copyCapture(value){return{check:value.check,at:value.at,evidence:structuredClone(value.evidence)}}
function copyState(value){return{schema:LIVE_CONTROL_SCHEMA,startedAt:value.startedAt,captures:value.captures.map(copyCapture)}}
function finite(value){return typeof value==='number'&&Number.isFinite(value)?value:null}
