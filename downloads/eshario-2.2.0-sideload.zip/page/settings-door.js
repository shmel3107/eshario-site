export function createSettingsDoor({update=()=>{}}={}){
let open=null
let last=null
const name=(id)=>(typeof id==='string'&&id!==''?id:null)
return{
section:()=>open,
last:()=>last,
goTo(id){const want=name(id)
open=want
if(want!==null)last=want
update()
return want!==null},
shut(){open=null
update()
return true}}}
