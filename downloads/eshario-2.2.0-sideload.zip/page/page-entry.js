import{createBridgeClient,checkBridge} from '../bridge/page-client.js'
import{createBridgeProvider,READ_METHOD as SETTINGS_READ} from '../settings/storage.js'
import{createSettings} from '../settings/index.js'
import{createLicensing} from '../licensing/index.js'
import{createKeyProvider,createBridgeLicenseProvider} from '../licensing/key.js'
import{createAccountProvider,createMigrationProvider,ACCOUNT_OPEN} from '../licensing/account.js'
import{createI18n,chooseLocale,currentTimeZone} from '../i18n/index.js'
import{doors} from '../adapter/doors.js'
import{createNavigation,appMain} from '../adapter/navigation.js'
import{createCriteria,createClubCriteria,createSbcStorageCriteria,createFiltersScreen,readUserCriteria} from '../adapter/search.js'
import{installMarketSearchQuick,tapSearchWire,widenMarketPage,marketSearchPageViews,marketPageSetting,WIDE_PAGE_LOTS} from '../adapter/market-search.js'
import{installItemEvents} from '../adapter/item-events.js'
import{createFilterStore,createBridgeFilterProvider} from '../features/filter-store.js'
import{createBridgePackLockProvider,setPackLock,isPackLocked,isPackHidden,setPackHidden} from '../features/pack-locks.js'
import{createBridgeCardLockProvider,isCardLocked,setCardLock,sanitizeCardLocks,lockedIdsFor,cardLockRecreatedRows,noteCardsRecreated} from '../features/card-locks.js'
import{createBridgeCardFrozenProvider,isCardFrozen,setCardFrozen,frozenIdsFor} from '../features/card-frozen.js'
import{createFrozenMarks} from '../features/frozen-marks.js'
import{createDropdownSearch} from '../features/dropdown-search.js'
import{previewPackAutomation,runPackAutomationStep,inspectPackAutomationOutcome,hydratePackAutomationOutcome,beginPackAutomationSession,recordPackAutomationSessionOutcome,previewPackAutomationOutcomeAction,runPackAutomationPickOutcome,runPackAutomationRecoveryOutcome,runPackAutomationDiscardOutcome,previewPackAutomationContinuation,runPackAutomationContinuation} from '../features/pack-automation.js'
import{setPlayerPickSelection,reviewPlayerPickSelection,runPickStep,pickPolicy} from '../features/player-picks.js'
import{invalidateUnassignedRecovery,refreshUnassignedRecovery,setUnassignedDisposition,resetUnassignedDispositions,reviewUnassignedRecovery,runRecoveryStep,recoveryPolicy,previewUnassignedDiscard,runDiscardStep} from '../features/unassigned-recovery.js'
import{applyFilter,saveCurrentFilter,renameFilter,removeFilter,exportFilters,importFilters} from '../features/filter-actions.js'
import{createAutomation,createBridgeLimitsProvider,createBridgeOptionsProvider} from '../features/automation-actions.js'
import{createSnipeKey} from '../features/snipe-key.js'
import{sanitizeOptionInput,parseOptions,AFTER_BUY_KEY,SEARCH_REFRESH_KEY,searchRefreshOf} from '../automation/options-input.js'
import{createSellerControl,createBridgeSellerProvider} from '../features/seller-actions.js'
import{createJournal,createBridgeJournalProvider,BUYER,SELLER} from '../automation/journal.js'
import{journalText,JOURNAL_ROWS} from '../features/journal-actions.js'
import{createLedger,createBridgeLedgerProvider} from '../automation/ledger.js'
import{ledgerText,ledgerCsv} from '../features/ledger-actions.js'
import{createSounds} from '../features/sound.js'
import{createSellSidebar} from '../features/sell-sidebar.js'
import{createCardLockMark} from '../features/card-lock-mark.js'
import{createLockBadges} from '../features/lock-badges.js'
import{createSquadBar} from '../features/squad-bar.js'
import{createSquadPick} from '../features/squad-pick.js'
import{createCardGrid,CARD_GRID_FEATURE,moneyScreenLive} from '../features/card-grid.js'
import{createDealPanel} from '../features/deal-judge.js'
import{createClubBar} from '../features/club-bar.js'
import{createSbcStorage,moveStorageToClub} from '../features/sbc-storage.js'
import{createTransfersHub} from '../features/transfers-hub.js'
import{itemForEvidenceRow} from '../features/item-evidence.js'
import{priceBadgeState,priceBadgeCoins,priceBadgePeek} from '../features/price-badges.js'
import{createSbcWindow} from '../features/sbc-window.js'
import{createStoreGrid} from '../features/store-grid.js'
import{createStoreCatalog} from '../features/store-catalog.js'
import{createPreviewMemory} from '../features/preview-memory.js'
import{createPackPeek} from '../features/pack-peek.js'
import{createPickPrices,PICK_BY_PRICE_FEATURE} from '../features/pick-prices.js'
import{createSbcTab} from '../features/sbc-tab.js'
import{createSbcSet} from '../features/sbc-set.js'
import{rewardTextOf} from '../adapter/sbc-set.js'
import{createFutggSbc} from '../adapter/futgg-sbc.js'
import{createFrozenStore} from '../features/sbc-frozen.js'
import{createSbcStrip,withStrip} from '../features/sbc-strip.js'
import{squadFieldSignature} from '../adapter/sbc-screen.js'
import{createSbcWarm,BACKGROUND_TIME_MS} from '../features/sbc-warm.js'
import{createSbcLadderWarm} from '../features/sbc-ladder-warm.js'
import{createPackShow,sanitizeShowRating} from '../features/pack-show.js'
import{goStoreHub,unassignedInCache} from '../adapter/store-packs.js'
import{prepareChallenge,resolveClubPool,showPreparedOnPitch,searchBuyOnMarket,placeBoughtCard,planSlotsFor,twiceInPlan,mismatchInPlan,judgeSubmit,recreatedLockNotice,warmShieldStop,poolForSearch,searchableCards,SBC_FEATURE,solvePhases,columnTotal,pricesForClub,createPrepCache} from '../features/sbc-actions.js'
import{createSubmitGuardHook} from '../features/sbc-submit-hook.js'
import{liveSubmitSnapshot,sbcIneligibleReason,cardResourceKey} from '../adapter/sbc-submit.js'
import{readSbcStorageItems,ITEM_PILE} from '../features/club-analysis.js'
import{createClubMirror,readClubOnce,readVerdict,playersInStats,MIRROR_SHARDS,CLUB_SESSION_RESCUE_READS} from '../features/club-mirror.js'
import{createBootSplash} from '../ui/boot-splash.js'
import{mergePool,laddersFrom,identityWantsFrom,createAgedMemo,valuationFrom,explainSolve,dumpSolve,clubWorth,liveClassesFrom,liveRatingsFrom,bucketsFrom,bucketsWanted,ladderLedger,ladderFromOf,IDENTITY_MEMO_KEEP,BLOB_SLICE_MS} from '../features/sbc-valuation.js'
import{createConceptItem,conceptSupport} from '../adapter/concept-item.js'
import{createSlotSearchScreen,slotSearchSupport} from '../adapter/squad-search.js'
import{arrangeByPositions} from '../adapter/squad-builder.js'
import{readTradeAccess} from '../adapter/trade-access.js'
import{sayEaNotice} from '../adapter/notification.js'
import{createPoolCache,createActiveSquadCache,PoolFeedError,poolHunger,poolPriceWatch,createPoolPriceEye} from '../features/sbc-pool.js'
import{analyzeClubAction,valueNotice,cardLabel,CLUB_FEATURE,PRICE_FEATURE} from '../features/club-actions.js'
import{defaultClubTableFilters,exportClubItemTableCsv} from '../features/club-table.js'
import{mountMarketResultSummary,showMarketDeals} from '../features/market-search-quick.js'
import{createMarketBotBar} from '../features/market-bot-bar.js'
import{createSearchNames} from '../adapter/search-names.js'
import{readLiveMarketCriteria,playerEntryOf,marketResultsLive,
SEARCH_SCREEN_ROOT,liveSearchButton,
readMarketFilterCriteria,readLiveMarketDefaults,restoreLiveMarketCriteria,
showSearchMinBid,restoreSearchMinBid,showSearchPair,restoreSearchPair,
} from '../adapter/market-screen.js'
import{createMarketFilterMemory} from '../features/market-filter-memory.js'
import{mountItemCard} from '../adapter/item-card.js'
import{createPriceCache,createPriceLookup,createPriceFallback} from '../features/price-source.js'
import{createMarketPriceSource,marketCacheKey,criteriaForCard} from '../features/market-price.js'
import{createLivePrices,measureQueueFrom,lagReport} from '../features/live-price-probe.js'
import{createMarketBudget,BUDGET_LIMIT} from '../features/min-bin.js'
import{DEFAULT_SEARCH_BAND_MS,SAFE_PAUSE_FLOOR_MS,MIN_BID_FLOOR,MIN_BID_STEP,MIN_BID_TOP,BID_REFRESH_TOP,MIN_BUY_FLOOR,MIN_BUY_STEP,MIN_BUY_TOP,MIN_BUY_AIM_SHARE,PAIR_MIN_BID_TOP,pairRing} from '../automation/sniper.js'
import{createDayBudget,withDayBudget,createHuntBudget,offMarket,meterCalls,isDayBudgetError,dayBudgetError,createBudgetOwner,stopOnEaLimit} from '../features/day-budget.js'
import{createHeadBar,chipScale} from '../features/head-bar.js'
import{createRivalsSource} from '../adapter/head-bar.js'
import{headCountersLine} from '../features/head-counters.js'
import{createAutoBuy,createBuyRate,createLotFinder,buyTargetOf,batchCeiling} from '../automation/auto-buy.js'
import{createSession} from '../automation/session.js'
import{createStopConditions} from '../automation/stop-conditions.js'
import{TAX_FEATURE} from '../features/tax-actions.js'
import{createUiState,createBridgeUiProvider,pickPreselectFromToggles,sanitizeHotkeyProfile} from '../features/ui-state.js'
import{createCloudDesk} from '../sync/cloud-desk.js'
import{createSettingsTransfer,watchSettingsApplied} from '../sync/transfer-port.js'
import{createProblemReport} from '../features/problem-report.js'
import{SYNC_STORAGE_KEYS} from '../sync/settings-schema.js'
import{setEaRequestPort,eaRequestState} from '../adapter/observable.js'
import{createFutggSource,priceCacheKey,currentGame,MANIFEST_TTL_MS as FUTGG_MANIFEST_TTL_MS} from '../features/futgg.js'
import{seasonOf} from '../adapter/season.js'
import{createLadderService,createSolvePriceReader,LADDER_TTL_MS} from '../features/price-ladder.js'
import{createPriceTrap} from '../features/price-trap.js'
import{createPriceQuarantine} from '../features/price-quarantine.js'
import{createRarityGroups} from '../features/futgg-rarities.js'
import{createBridgeFetch,CARDS_METHOD,CARDS_TIMEOUT_MS} from '../bridge/page-client.js'
import{createSbc,createSquad} from '../adapter/sbc.js'
import{demandClasses} from '../automation/card-value.js'
import{parseRequirements} from '../automation/sbc-requirements.js'
import{createWorkAreaProbe} from '../adapter/sbc-work-area.js'
import{createAdapter,createPackAdapter,createClubMemory,createStorageMemory,searchTypeOf} from '../adapter/ea.js'
import{createPersonaAdapter} from '../adapter/persona.js'
import{createSessionEpoch,sessionSince,stopRunning,stopQueue} from '../adapter/session-epoch.js'
import{createWalletAdapter} from '../adapter/wallet.js'
import{squadRatingFloatEnabled} from '../adapter/config.js'
import{createTeamConfig} from '../adapter/team-config.js'
import{createStaticPlayers} from '../adapter/static-players.js'
import{createCardCatalog,createCardLane} from '../features/card-catalog.js'
import{createCardBaseFeed,baseDefinitions} from '../features/card-base.js'
import{createRarityGroupBook} from '../features/rarity-group-book.js'
import{createDemandMemory,unionClasses} from '../features/demand-memory.js'
import{installPurchaseLog,purchaseLogState,notePurchasedItem,notePaid} from '../features/purchase-log.js'
import{createHuntLoot} from '../features/hunt-loot.js'
import{createClock} from '../core/clock.js'
import{storageFailed} from '../core/storage-provider.js'
import{mountPanel,PANEL_BUILD} from '../ui/panel.js'
import{ourWindowOpen} from '../ui/window.js'
import{FIRST_SECTION,DEEDS} from '../ui/panel-model.js'
import{HOTKEYS_FEATURE} from '../features/hotkey-binding.js'
import{publishTemplateMenu,pressNode,cardMatchProbe} from '../features/hotkey-bind.js'
import{wirePage} from './wiring.js'
import{createBuyerDoor} from './buyer-door.js'
import{createSettingsDoor} from './settings-door.js'
import{createLiveEvidenceRecorder,createPhaseLog,domEvidence,buildLiveEvidence} from './live-evidence.js'
import{createBridgeLiveControlProvider,createLiveControlSession} from './live-control.js'
import{createWaitNotice} from './wait-notice.js'
const bridge=createBridgeClient(window)
const state={bridge:'unknown',version:null,panel:'not-mounted',errors:[],
tariff:{last:null,asks:0}}
window.__eshario=state
const note=(message)=>{state.errors.push(String(message))
console.warn('[ESHArio]',message)}
const hint=(message)=>{state.errors.push(String(message))
console.info('[ESHArio]',message)}
const shout=(message,data)=>{console.warn('[ESHArio] ловушка цен:',message,data)}
const tell=(message)=>{state.tariff={...state.tariff,last:String(message)}
console.info('[ESHArio] тариф:',message)}
async function start(){const clock=createClock()
const phases=createPhaseLog({now:clock.now,storage:()=>window.localStorage})
phases.mark('page')
const initialHealth=await checkBridge(bridge)
if(!initialHealth.ok)throw new Error(initialHealth.reason)
state.bridge='ok'
state.version=initialHealth.version
phases.mark('bridge',{version:state.version})
const guessLocale=()=>chooseLocale(null,navigator.languages,currentTimeZone())
let i18n=createI18n({locale:guessLocale()})
const t=(key,params)=>i18n.t(key,params)
const formatCoins=(coins)=>i18n.formatCoins(coins)
const resolveLocale=(chosen)=>chooseLocale(chosen,navigator.languages,currentTimeZone())
const applyLocale=(chosen)=>{const next=resolveLocale(chosen)
if(next===i18n.locale)return false
i18n=createI18n({locale:next})
return true}
const CLOUD_WATCHED=Object.freeze({settings:SYNC_STORAGE_KEYS.features,filters:SYNC_STORAGE_KEYS.filters,
limits:SYNC_STORAGE_KEYS.buyerLimits,options:SYNC_STORAGE_KEYS.buyerOptions,
seller:SYNC_STORAGE_KEYS.sellerOptions,ui:SYNC_STORAGE_KEYS.interface,packs:SYNC_STORAGE_KEYS.packLocks})
let cloudNotice=()=>{}
const watchForCloud=(one,key)=>({...one,write(next){const before=one.read()
const said=one.write(next)
Promise.resolve(said).then((ok)=>{if(ok!==false)cloudNotice({[key]:{oldValue:before,newValue:one.read()}})},()=>{})
return said}})
const loadBridgeProvider=async(create,label)=>{const result=create({bridge,onError:(stage,err)=>note(`${label} ${stage}: ${err?.message ?? err}`)})
await result.load()
const watched=CLOUD_WATCHED[label]
return watched===undefined?result:watchForCloud(result,watched)}
const liveEvidence=createLiveEvidenceRecorder({now:clock.now})
const liveControlProvider=await loadBridgeProvider(createBridgeLiveControlProvider,'live control')
const keyStorage=await loadBridgeProvider(createBridgeLicenseProvider,'license')
const keyProvider=createKeyProvider({clock:createClock(),provider:keyStorage})
await keyProvider.load()
const accountProvider=createAccountProvider({bridge,clock:createClock()})
await accountProvider.refresh()
const migrationProvider=createMigrationProvider({account:accountProvider,legacy:keyProvider})
const licensing=createLicensing({provider:migrationProvider})
const provider=await loadBridgeProvider(createBridgeProvider,'settings')
const settings=createSettings({provider,isEnabled:licensing.isEnabled})
let nav=null
const navWait=createWaitNotice({name:'navigation',now:()=>clock.now(),record:(message)=>{state.errors.push(String(message))}})
const navOrNull=()=>{if(nav)return nav
try{nav=createNavigation(window)}catch(err){
navWait.waiting(`${err?.message ?? err}`)
nav=null}
return nav}
const goEaSection=(section)=>navOrNull()?.go?.(section)??{ok:false,reason:'unavailable'}
const filterProvider=await loadBridgeProvider(createBridgeFilterProvider,'filters')
const filterStore=createFilterStore({provider:filterProvider})
const packProvider=await loadBridgeProvider(createBridgePackLockProvider,'packs')
const cardLockProvider=await loadBridgeProvider(createBridgeCardLockProvider,'card locks')
const cardFrozenProvider=await loadBridgeProvider(createBridgeCardFrozenProvider,'card frozen')
const LOCKS_WAIT_STEP_MS=25
const LOCKS_WAIT_TRIES=120
const cardLocksMature=async()=>{for(let left=LOCKS_WAIT_TRIES;left>0;left-=1){if(cardLockProvider.isLoaded())return true
if(storageFailed(cardLockProvider))return false
await new Promise((done)=>{setTimeout(done,LOCKS_WAIT_STEP_MS)})}
return cardLockProvider.isLoaded()}
const packAdapter=createPackAdapter(window)
const packs={busy:false}
const packAutomation={maxPacks:'1',maxMinutes:'10',recoveryOrder:'',discardAllowlist:'',autoPick:false,autoRecovery:false,autoDiscard:false,autoContinue:false,review:null,outcome:null,outcomeAction:null,continuation:null,busy:false,ticket:null}
const clearPackAutomation=()=>Object.assign(packAutomation,{review:null,outcome:null,outcomeAction:null,continuation:null})
const unassignedRecovery={count:0,keep:0,club:0,transfer:0,storage:0,review:null,loaded:false,busy:false,items:[]}
const playerPicks={items:[],availablePicks:0,selected:[],review:null,loaded:false,busy:false}
const pick=()=>{const p=pickPolicy(playerPicks)
playerPicks.review=p.ok?packAdapter.reviewPicks(playerPicks.selected):p}
const recover=()=>{const result=recoveryPolicy(unassignedRecovery).ok
&&reviewUnassignedRecovery(packAdapter,unassignedRecovery)
previewUnassignedDiscard(unassignedRecovery,packAutomation.discardAllowlist)
return result}
const adoptPackAutomationOutcome=async()=>{invalidateUnassignedRecovery(unassignedRecovery)
Object.assign(playerPicks,{items:[],availablePicks:0,selected:[],review:null,loaded:false})
const o=packAutomation.outcome=await inspectPackAutomationOutcome(packAutoAdapter)
if(o.ok){const h=hydratePackAutomationOutcome(o,playerPicks,unassignedRecovery)
if(!h.ok)packAutomation.outcome={ok:false,reason:'unknown-state'}
else if(o.kind==='pending-pick')pick()
else if(o.kind==='unassigned')recover()}
const session=recordPackAutomationSessionOutcome(packAutomation.ticket,packAutomation.outcome)
if(!session.ok)note(`pack automation session: ${session.reason}`)
return o}
const filterDeps={store:filterStore,criteria:{create:(values)=>createCriteria(window,values),read:()=>readUserCriteria(window)?.criteria??null},screen:{open(dto){const navigation=navOrNull()
if(!navigation)return{ok:false,reason:'no-navigation'}
let screen
try{screen=createFiltersScreen(window,dto)}catch(err){return{ok:false,reason:'failed',detail:String(err?.message??err)}}
const put=navigation.pushScreen(screen)
if(put?.ok===true)marketFilterMemory.noteWrite()
return put}}}
const limitsProvider=await loadBridgeProvider(createBridgeLimitsProvider,'limits')
const optionsProvider=await loadBridgeProvider(createBridgeOptionsProvider,'options')
const sellerProvider=await loadBridgeProvider(createBridgeSellerProvider,'seller')
const journalProvider=await loadBridgeProvider(createBridgeJournalProvider,'journal')
const journal=createJournal({clock:createClock(),provider:journalProvider})
const ledgerProvider=await loadBridgeProvider(createBridgeLedgerProvider,'ledger')
const ledger=createLedger({clock:createClock(),provider:ledgerProvider})
const sounds=createSounds({isActive:settings.isActive,volume:()=>uiState.soundVolume()})
const seller=createSellerControl({clock:createClock(),market:()=>createAdapter(window).item,isActive:settings.isActive,isEnabled:licensing.isEnabled,optionsProvider:sellerProvider,journal:journal.for(SELLER),ledger,sounds,onUpdate:()=>panel.update(),budget:()=>huntBudget})
const wallet=createWalletAdapter(window)
const personas=createPersonaAdapter(window)
const sessionEpoch=createSessionEpoch({personas,win:window,onError:(err)=>note(`session epoch: ${err?.message??err}`)})
let sessionEpochBrokeAt=0
const sessionEpochPoll=()=>{try{return sessionEpoch.poll(clock.now())}catch(err){note(`session epoch: ${err?.message ?? err}`)
return null}}
const widePage=()=>widenMarketPage(window,WIDE_PAGE_LOTS,{onError:(message)=>note(message)});
const pageViews=()=>marketSearchPageViews(window);
const snipePileFeed=(onEvent)=>{const events=installItemEvents(window,onEvent)
if(events.ok!==true&&events.reason==='no-dispatcher'){note('snipe pile: диспетчер событий EA не найден')
return null}
return()=>{try{events.dispose()}catch(err){note(`snipe pile: ${err?.message??err}`)}}};
const automation=createAutomation({clock:createClock(),market:()=>createAdapter(window).item,
wire:()=>tapSearchWire(window,{onError:(err)=>note(`snipe wire: ${err?.message??err}`)}),
widePage,pageViews,pileFeed:snipePileFeed,
coinBalance:wallet.coins,isActive:settings.isActive,isEnabled:licensing.isEnabled,limitsProvider,optionsProvider,journal:journal.for(BUYER),ledger,sounds,onUpdate:()=>{panel.update()
marketBotAim?.refresh?.()},
budget:()=>huntBudget,
handOnScreen:()=>marketResultsLive(window),
buyRate:()=>buyRate,
consent:{text:()=>t('snipe.disclaimer'),granted:()=>uiState.snipeConsent(),grant:(fp)=>uiState.setSnipeConsent(fp)},
purchaseLog:{notePaid:(item,price)=>{notePaid(item,price)
try{huntLoot.note(item,price)}catch(err){note(`snipe loot: ${err?.message??err}`)}}}})
const marketOrNull=()=>{try{return createAdapter(window).item}catch{return null}}
const clubOrNull=()=>{try{return createAdapter(window).club}catch{return null}}
const clubPage=(page)=>createClubCriteria(window,page)
const storagePage=(page)=>createSbcStorageCriteria(window,page)
const readStorage=()=>readSbcStorageItems(meterCalls(marketOrNull(),dayBudget,['searchStorageItems'],{stage:'storage'}),{createCriteria:storagePage})
const storageHooks={submitted:()=>false,noteItems:()=>null}
const idleFrame=(fn)=>{const idle=window.requestIdleCallback
if(typeof idle==='function'){idle.call(window,()=>fn(),{timeout:2000})
return}
const frame=window.requestAnimationFrame
if(typeof frame==='function'){frame.call(window,()=>fn())
return}
setTimeout(fn,0)}
const paintFrame=(fn)=>{const frame=window.requestAnimationFrame
if(typeof frame==='function'){frame.call(window,()=>fn())
return}
setTimeout(fn,0)}
const catalog=createCardCatalog({storage:{read:(shard)=>bridge.request('catalog.read',{shard}),
write:(shard,value)=>bridge.request('catalog.write',{shard,value})},
schedule:idleFrame,now:()=>clock.now(),onError:(err)=>note(`catalog: ${err?.message??err}`)})
const groupBook=createRarityGroupBook({storage:{read:()=>bridge.request('groups.read'),
write:(value)=>bridge.request('groups.write',value)},
schedule:idleFrame,now:()=>clock.now(),onError:(err)=>note(`groups: ${err?.message??err}`)})
void groupBook.load().catch((err)=>note(`groups: ${err?.message??err}`))
const learnItem=(item,source)=>{catalog.note(item)
groupBook.note(item,source)
notePurchasedItem(item,ITEM_PILE.PURCHASED)}
const learnItems=(items,source)=>{for(const item of Array.isArray(items)?items:[])learnItem(item,source)}
const demandMemory=createDemandMemory({storage:{read:()=>bridge.request('demand.read'),
write:(value)=>bridge.request('demand.write',value)},
schedule:idleFrame,now:()=>clock.now(),onError:(err)=>note(`demand: ${err?.message??err}`)})
void demandMemory.load().catch((err)=>note(`demand: ${err?.message??err}`))
const purchaseLog=installPurchaseLog({storage:{read:()=>bridge.request('purchases.read'),
write:(value)=>bridge.request('purchases.write',value)},
schedule:idleFrame,now:()=>clock.now(),onError:(err)=>note(`purchases: ${err?.message??err}`)})
void purchaseLog.load().catch((err)=>note(`purchases: ${err?.message??err}`))
let lastClubSource=null
let clubDecision=null
const clubWhy={}
const decideClub=(decision)=>{clubDecision=decision
const why=decision?.why
if(typeof why==='string'&&why!=='')clubWhy[why]=(clubWhy[why]??0)+1
return decision}
let clubReadThisSession=false
const clubMemory=createClubMemory(window)
const storageMemory=createStorageMemory(window)
const clubMirror=createClubMirror({storage:{readShard:(shard)=>bridge.request('mirror.read',{shard}),
writeShard:(shard,value)=>bridge.request('mirror.write',{shard,value}),
readHead:()=>bridge.request('mirror.head.read'),
writeHead:(value)=>bridge.request('mirror.head.write',value)},
schedule:idleFrame,now:()=>clock.now(),onError:(err)=>note(`club mirror: ${err?.message??err}`)})
const mirrorReady=clubMirror.load().catch((err)=>{note(`club mirror: ${err?.message??err}`)
return null})
async function clubItemsForSolver(reason,force=false){await mirrorReady
const club=clubOrNull()
if(!club){decideClub({why:'no-adapter',usable:null,verify:null,mirrorSize:0,read:null})
return{ok:false,items:[],from:'no-club',reason:'no-adapter',got:0,expected:0}}
const alive=force?{ok:false,reason:'forced'}:clubMirror.usable()
decideClub({why:alive.ok?'mirror-alive':alive.reason,usable:alive.reason,verify:null,mirrorSize:clubMirror.state().size,read:null})
const metered=meterCalls(club,dayBudget,['stats','search'],{stage:'club'})
let live=null
try{live=await metered.stats()}catch(err){note(`club mirror: счётчики клуба не пришли — ${err?.message??err}`)
live=null}
if(alive.ok&&live!==null){const check=clubMirror.verify(live)
clubDecision={...clubDecision,verify:{ok:check.ok,reason:check.reason,checked:check.checked,diff:check.diff}}}
else if(alive.ok)clubDecision={...clubDecision,verify:{ok:false,reason:'stats-failed',checked:0,diff:[]}}
const may=clubMirror.mayRead({first:clubReadThisSession===false})
if(!may.ok){
note(`club mirror: чтений клуба за сутки ${may.used} из ${may.cap} — читать больше не буду`)
return{ok:false,items:[],from:'day-limit',reason:may.reason,got:0,expected:playersInStats(live)}}
if(may.reason==='rescue')hint(`club mirror: чтений за сутки ${may.used} из ${may.cap}, но пул этого сеанса пуст — беру спасательное чтение ${may.rescued+1} из ${CLUB_SESSION_RESCUE_READS}`)
clubMirror.spendRead(may.reason==='rescue')
let result
try{result=await readClubOnce(metered,{createCriteria:clubPage,pause:(ms)=>clock.sleep(ms),budget:dayBudget})}catch(err){
if(isDayBudgetError(err)){note(`club mirror: суточный объём обращений к EA исчерпан (${err.reason}) — обход клуба остановлен`)
return{ok:false,items:[],from:'day-budget',reason:err.reason,got:0,expected:playersInStats(live)}}
throw err}
const verdict=readVerdict(result,{expected:playersInStats(live)})
clubDecision={...clubDecision,read:{ok:verdict.ok,reason:verdict.reason,got:verdict.got,players:verdict.players,expected:verdict.expected,pages:result.pages,tries:result.tries??null}}
if(!verdict.ok){clubMirror.readRefused(verdict)
note(`club mirror: ответ EA не прошёл полноту (${verdict.reason}: ${verdict.players} игроков из ${verdict.expected}) — зеркало и пул остаются прежними`)
return{ok:false,items:[],from:'short-read',reason:verdict.reason,got:verdict.players,expected:verdict.expected}}
clubMirror.put(result.items,{pages:result.pages,source:reason??'read',stats:live,memory:clubMemory.stats(),
stamp:clubMemory.statsStamp()})
clubReadThisSession=true
return{ok:true,items:result.items,from:'read',reason:null,pages:result.pages,got:verdict.players,expected:verdict.expected}}
function clubForAnalysis(){const base=clubOrNull()
if(!base)return null
const club=meterCalls(base,dayBudget,['search'],{stage:'club'})
let spent=false
return{...club,search:async(criteria)=>{if(!spent){const may=clubMirror.mayRead()
if(!may.ok)throw new Error(`клуб: чтений за сутки ${may.used} из ${may.cap} — читать больше не буду`)
clubMirror.spendRead()
spent=true}
const page=await club.search(criteria)
if(page?.retrievedAll===true)void feedMirrorFromAnalysis(page.items)
return page}}}
async function feedMirrorFromAnalysis(items){try{const club=clubOrNull()
let live=null
const tail=meterCalls(club,dayBudget,['stats'],{stage:'club'})
try{live=await tail?.stats?.()??null}catch(err){stopOnEaLimit(dayBudget,err)
live=null}
const verdict=readVerdict({items,retrievedAll:true},{expected:playersInStats(live)})
if(!verdict.ok){clubMirror.readRefused(verdict)
note(`club mirror: анализ клуба принёс огрызок (${verdict.reason}) — зеркало осталось прежним`)
return}
clubMirror.put(items,{pages:1,source:'analyze',statsAt:'now',stats:live,memory:clubMemory.stats(),
stamp:clubMemory.statsStamp()})}catch(err){note(`club mirror: ${err?.message??err}`)}}
function checkMirrorFromMemory(){
if(clubMirror.settling())return{ok:true,reason:'settling'}
const live=clubMemory.stats()
if(live===null)return{ok:true,reason:'no-memory'}
const check=clubMirror.verifyMemory(live,clubMemory.statsStamp())
if(check.ok)return check
try{poolCache.markStale(check.reason??'server-moved')}catch(err){note(`club mirror: ${err?.message??err}`)}
return check}
let forceNextClubRead=false
let lastRefusedBy={loan:0,concept:0,academy:0}
const poolCache=createPoolCache({read:async()=>{const force=forceNextClubRead
forceNextClubRead=false
const clubRead=await clubItemsForSolver('pool',force)
lastClubSource=clubRead.from
if(clubRead.ok!==true)throw new PoolFeedError(clubRead.reason??clubRead.from,{got:clubRead.got,expected:clubRead.expected})
const storage=await readStorage()
const merged=mergePool(clubRead.items,storage)
const refusedBy={loan:0,concept:0,academy:0}
const items=merged.items.filter((item)=>{const why=sbcIneligibleReason(item)
if(why===null)return true
refusedBy[why]+=1
return false})
lastRefusedBy=refusedBy
try{storageHooks.noteItems(storage)}catch(err){note(`storage: ${err?.message??err}`)}
catalog.noteAll(merged.items)
groupBook.noteAll(merged.items,'pool')
return{...merged,items,refused:merged.items.length-items.length,
sources:{club:clubRead.items.length,storage:Array.isArray(storage)?storage.length:0}}},now:()=>clock.now(),
accept:(item)=>sbcIneligibleReason(item)===null,
storageItem:(id)=>storageMemory.item(id)})
const activeSquadCache=createActiveSquadCache({read:()=>meterCalls(createSquad(window),dayBudget,['requestActivePlayerIds'],{stage:'active-squad'}).requestActivePlayerIds(),now:()=>clock.now()})
const workArea=createWorkAreaProbe(window)
const blobStamp=()=>{const published=futggSource.publishedAt()
const reader=solveReader.state()
let platform=null
try{platform=personas.pricePlatform()}catch{platform=null}
return{pool:poolCache.generation(),published:published===null?null:published.at,
platform,closes:reader?.closes??null,closed:reader?.closed===true?1:0}}
const blobCache=createPrepCache()
const poolPriceEye=createPoolPriceEye()
const ladderStamp=()=>({platform:(()=>{try{return personas.pricePlatform()}catch{return null}})(),
closed:solveReader.state()?.closed===true?1:0})
let prepWarming=null
const prepareInputs=async(challenge,opts={})=>{const warm=opts.warm===true
const poolFromMemory=opts.poolFromMemory===true
if(!warm&&prepWarming!==null){try{await prepWarming}catch{}}
const mark=(name)=>warm?false:solvePhases.at(name)
if(storageFailed(cardLockProvider))return{ok:false,notice:{key:'sbc.locksUnreadable'}}
mark('locks')
if(!(await cardLocksMature()))return{ok:false,notice:{key:'sbc.locksUnreadable'}}
const recreatedStop=recreatedLockNotice(recreatedLockRows())
if(recreatedStop!==null)return{ok:false,notice:recreatedStop}
let protectedIds
let lockedIds
try{lockedIds=sanitizeCardLocks(cardLockProvider.read())
protectedIds=[...lockedIds,...(uiState.solver().keepActiveSquad===false?[]:await activeSquadCache.read())]}catch(err){return{ok:false,notice:{key:'sbc.loadFailed',params:{reason:String(err?.message??err)}}}}
let club
let poolRepeated=0
checkMirrorFromMemory()
mark('club')
const got=await resolveClubPool({poolFromMemory,peek:()=>poolCache.peek(),
read:()=>poolCache.read(),stale:()=>poolCache.state()?.stale===true})
if(got.ok!==true)return{ok:false,notice:got.notice}
club=got.club
poolRepeated=got.poolRepeated
const demand=demandNow(challenge)
let prices=null
let blob=new Map()
mark('ladders')
try{prices=await laddersFor({wants:identityWantsFrom(challenge?.eligibilityRequirements,demand.all),
buckets:bucketsWanted(challenge?.eligibilityRequirements)})
mark('blob')
let served=null
const got=await blobCache.serve(blobStamp,({pause})=>clubBlobPrices(club,{pause}),
{pause:opts.pause??null,onServe:(from)=>{served=from
solvePhases.note('prep',from)}})
poolPriceEye.note('подбор',{built:got?.size??null,of:club.length,from:served})
if(got===null)return{ok:false,aborted:true,notice:{key:'sbc.loadFailed',params:{reason:'prep-stale'}}}
blob=got}catch(err){note(`sbc valuation: ${err?.message??err}`)}
return{ok:true,club,poolRepeated,protectedIds,lockedIds,prices,blob}}
const solveOpenChallenge=async(challenge,set,report,ours,pace,mode,opts)=>{
workArea.install()
const quiet=opts?.quiet===true
if(quiet&&(poolCache.peek().players?.length??0)===0)return{ok:false,prepared:null,notice:{key:'sbc.loadFailed',params:{reason:'no-club'}}}
const ladderSeq=ladderLedger.seq()
const ready=quiet?await prepareInputs(challenge,{warm:true,poolFromMemory:true,pause:typeof pace?.pause==='function'?pace.pause:null}):await prepareInputs(challenge)
if(ready.ok!==true)return{ok:false,prepared:null,notice:ready.notice??{key:'sbc.loadFailed',params:{reason:'prep'}}}
lastPriceAges=ladderLedger.since(ladderSeq)
const{club,poolRepeated,protectedIds,lockedIds,prices,blob}=ready
const priceOf=solvePriceOf(blob)
const priced=(prices?.ladder?.length??0)+blob.size
if(priced===0){note(`sbc valuation: цен нет (${JSON.stringify(solveReader.state())})`)
if(typeof report==='function')report({key:'sbcWindow.noPrices',params:{}})}
const answer=await prepareChallenge({club,poolRepeated,challenge,set,protectedIds,lockedIds,prices,ours,mode,openChallenges:openChallengesNow(),
remembered:demandMemory.classes(),rememberedRatings:demandMemory.ratings(),
arrange:(positions,players)=>arrangeByPositions(window,positions,players),pause:typeof pace?.pause==='function'?pace.pause:null,onProgress:typeof pace?.progress==='function'?pace.progress:null,floatRating:squadRatingFloatEnabled(window),cachedPriceOf:priceOf,linkedTeam:createTeamConfig(window).linkedTeam,
...(Number.isFinite(opts?.timeBudgetMs)&&opts.timeBudgetMs>0?{timeBudgetMs:opts.timeBudgetMs}:{}),
...(Array.isArray(opts?.exclude)&&opts.exclude.length>0?{excludeIds:[...opts.exclude]}:{}),
...(Number.isFinite(opts?.evaluationCeiling)&&opts.evaluationCeiling>0?{evaluationCeiling:opts.evaluationCeiling}:{}),
...(quiet&&Array.isArray(opts?.baseline)?{baseline:opts.baseline}:{}),
...(quiet&&Array.isArray(opts?.heir)&&opts.heir.length>0?{heir:opts.heir}:{}),
...(quiet&&opts?.finish!==null&&typeof opts?.finish==='object'?{finish:opts.finish}:{})})
if(!quiet){lastSolve={challenge,prices,answer,mode,at:priceClock.now(),
timeBudgetMs:Number.isFinite(opts?.timeBudgetMs)&&opts.timeBudgetMs>0?opts.timeBudgetMs:null,
priceOf}
lastSolve.priceAges=lastPriceAges
return answer}
return{...answer,trace:{challenge,prices,mode,at:priceClock.now(),priceOf}}}
const prewarmOpenChallenge=async(challenge,pace)=>{const work=prepareInputs(challenge,
{pause:typeof pace?.pause==='function'?pace.pause:null,warm:true})
prepWarming=work
try{const ready=await work
return ready?.ok===true}finally{if(prepWarming===work)prepWarming=null}}
let lastSolve=null
let lastPriceAges=null
const adoptSolve=(trace,answer)=>{if(!trace||typeof trace!=='object'||!answer||typeof answer!=='object')return false
lastSolve={challenge:trace.challenge,prices:trace.prices??null,answer,mode:trace.mode,
at:Number.isFinite(trace.at)?trace.at:priceClock.now(),
ladder:trace.ladder&&typeof trace.ladder==='object'?trace.ladder:null,
buy:typeof trace.buy==='function'?trace.buy:null,
rebuilds:Number.isFinite(trace.rebuilds)?trace.rebuilds:null,
priceAges:lastPriceAges,
priceOf:typeof trace.priceOf==='function'?trace.priceOf:null}
return true}
const showOnPitch=async(prepared)=>{let sbc
try{sbc=meterCalls(createSbc(window),dayBudget,['saveChallenge'],{stage:'sbc-show'})}catch{return{ok:false,live:null,notice:{key:'sbc.unavailable',params:{}}}}
const result=await showPreparedOnPitch({sbc,concept:(source)=>{let item=null
try{item=createConceptItem(window,source)}catch(err){note(`sbc concept: ${err?.message??err}`)}
if(!item)note(`sbc concept: не собрался (${JSON.stringify({definitionId:source?.definitionId??null,rating:source?.rating??null,...conceptSupport(window)})})`)
return item}},prepared)
workArea.restore()
if(result?.ok===true&&result.saved===false){note(`sbc save: ${result.notice?.params?.reason??'без причины'} · слоты ${JSON.stringify(result.placed??[])}`)}
return result}
const searchBuy=(prepared,buyId)=>searchBuyOnMarket({search:({squad,slot,maxBuy})=>{const navigation=navOrNull()
if(!navigation)return{ok:false,reason:'no-navigation'}
const built=createSlotSearchScreen(window,squad,slot,{maxBuy})
if(!built.ok){note(`sbc buy search: ${built.reason} (${JSON.stringify(slotSearchSupport(window))})`)
return built}
if(built.applied?.ok!==true)note(`sbc buy search: критерий не поправлен (${built.applied?.reason??'нет ответа'})`)
const pushed=navigation.pushScreen(built.screen)
if(!pushed.ok)note(`sbc buy search: показать экран не вышло (${pushed.reason})`)
return{...pushed,applied:built.applied??null}}},prepared,buyId)
const UNREAD_LOCK='?'
const recreatedLockRows=()=>{try{const list=cardLockRecreatedRows(cardLockProvider)
return Array.isArray(list)?list:[]}catch(err){note(`sbc guard: пометки замков не прочитаны (${err?.message??err})`)
return[{id:UNREAD_LOCK,name:null}]}}
const recreatedLockIds=()=>recreatedLockRows().map((row)=>row.id)
const judgeNativeSubmit=(challenge)=>{const live=liveSubmitSnapshot(challenge)
if(!live)return null
let lockedIds
try{lockedIds=lockedIdsFor(cardLockProvider,live.players)}catch(err){note(`sbc guard: замки не прочитаны (${err?.message??err})`)
return null}
const activeSquadIds=activeSquadCache.peek()
if(activeSquadIds===null)activeSquadCache.read().catch((err)=>note(`sbc guard: активный состав не прочитан (${err?.message??err})`))
return judgeSubmit({players:live.players,requirements:live.requirements,lockedIds,activeSquadIds,liveChemistry:live.chemistry,signature:live.signature,
slots:live.slots,squadRef:live.squadRef,operation:live.operation,linkedTeam:(teamId)=>linkedTeamNow(teamId),
recreatedIds:recreatedLockRows()})}
const priceClock=createClock()
const sbcPolicy=()=>{const status=settings.statusOf(SBC_FEATURE)
if(status==='active')return 'on'
return status==='not-entitled'||status==='switched-off'?'off':'unknown'}
const submitHook=createSubmitGuardHook({doc:document,win:window,judge:judgeNativeSubmit,policy:sbcPolicy,onError:(err)=>note(`sbc guard: ${err?.message??err}`),
budget:()=>dayBudget,
activeGeneration:()=>activeSquadCache.stamp(),
onStopped:()=>{void activeSquadCache.refresh().catch((err)=>note(`sbc guard: активный состав не перечитан (${err?.message??err})`))},
clock:priceClock,
storage:{read:()=>bridge.request('sbcrate.read'),write:(value)=>bridge.request('sbcrate.write',value)},
onSubmitted:()=>{try{storageHooks.submitted()}catch(err){note(`storage: ${err?.message??err}`)}}})
const clubState={busy:false,notice:null,analysis:null,value:null,rows:[],tableFilters:defaultClubTableFilters(),tablePage:1}
const CLUB_ROWS=12
const priceCache=createPriceCache({clock:priceClock})
const futggSource=createFutggSource({fetch:createBridgeFetch(bridge),clock:priceClock,platform:()=>personas.pricePlatform()})
const priceLookup=createPriceLookup({cache:priceCache,ttlOf:(provider)=>(provider==='futgg'?FUTGG_MANIFEST_TTL_MS:undefined),source:createPriceFallback([{id:'futgg',source:futggSource}])})
const dayBudget=createDayBudget({clock:priceClock,
owner:createBudgetOwner({request:(method,params)=>bridge.request(method,params),clock:priceClock,
onError:(err)=>note(`budget owner: ${err?.message??err}`)}),
storage:{read:()=>bridge.request('daybudget.read'),write:(value)=>bridge.request('daybudget.write',value)},
onError:(err)=>note(`day budget: ${err?.message??err}`)})
void dayBudget.load().catch((err)=>note(`day budget: ${err?.message??err}`))
const marketBudget=withDayBudget(createMarketBudget({clock:priceClock,owner:dayBudget.owner}),dayBudget)
const packAutoAdapter=meterCalls(packAdapter,dayBudget,['list','unassigned','open','pendingPicks','confirmPicks','moveUnassigned','discardUnassigned'],{stage:'packs'})
const packHandAdapter=meterCalls(packAdapter,dayBudget,['unassigned','pendingPicks','confirmPicks','moveUnassigned','discardUnassigned'],{stage:'packs-hand'})
const huntBudget=createHuntBudget(marketBudget,dayBudget)
const buyRate=createBuyRate({clock:priceClock,owner:dayBudget.owner,
storage:{read:()=>bridge.request('buyrate.read'),write:(value)=>bridge.request('buyrate.write',value)},
onError:(err)=>note(`buy rate: ${err?.message??err}`)})
void buyRate.load().catch((err)=>note(`buy rate: ${err?.message??err}`))
const snipeKey=createSnipeKey({market:marketOrNull,
clock:createClock(),
buyRate:()=>buyRate,marketBudget,dayBudget,coinBalance:wallet.coins,
journal:journal.for(BUYER),
afterBuy:()=>sanitizeOptionInput(optionsProvider?.read?.()??null)?.[AFTER_BUY_KEY],
threshold:()=>sanitizeOptionInput(optionsProvider?.read?.()??null)?.matchGuard,
maxPrice:()=>parseOptions(sanitizeOptionInput(optionsProvider?.read?.()??null)).options?.maxPrice,
onError:(err)=>note(`snipe key: ${err?.message??err}`)})
const marketPrice=createMarketPriceSource({market:marketOrNull,clock:createClock(),isActive:settings.isActive,budget:marketBudget,note:(lots)=>learnItems(lots,'market')})
const marketLookup=createPriceLookup({cache:priceCache,source:marketPrice.source,clock:priceClock})
const livePrices=createLivePrices({clock:priceClock,measure:(id,hint)=>marketEvidenceOfItem({definitionId:id},hint),rest:(ms)=>marketBudget.rest(ms)})
let buyBatch=null
let buyBatchTicket=0
const autoBuyRefusal=(targets,stage,reason='bad-state')=>({ok:false,reason,detail:{stage},
planned:Array.isArray(targets)?targets.length:0,bought:0,placed:0,spent:0,saved:false,rows:[]})
const runAutoBuy=async(targets,onProgress,prepared)=>{
if(buyBatch!==null)return autoBuyRefusal(targets,'busy')
const ticket=++buyBatchTicket
const slot={ticket,engine:null,cancelled:false,lastPlace:null}
buyBatch=slot
try{return await openAutoBuy(slot,targets,onProgress,prepared)}
finally{if(buyBatch===slot)buyBatch=null}}
const openAutoBuy=async(slot,targets,onProgress,prepared)=>{const market=marketOrNull()
if(!market||typeof market.bid!=='function'||typeof market.searchTransferMarket!=='function')return autoBuyRefusal(targets,'market')
if(!prepared||typeof prepared!=='object')return autoBuyRefusal(targets,'plan')
const mismatch=mismatchInPlan(prepared,targets)
if(mismatch.length>0){const first=mismatch[0]
return{...autoBuyRefusal(targets,'concepts'),
detail:{stage:'concepts',why:first.why,name:first.name??null,id:first.id??null,count:mismatch.length}}}
const twice=twiceInPlan(prepared,targets)
if(twice.length>0){const first=twice[0]
return{...autoBuyRefusal(targets,'concepts'),
detail:{stage:'concepts',why:first.why,name:first.name??null,id:first.id??null,count:twice.length}}}
const pitchPlan=planSlotsFor(prepared,targets)
if(pitchPlan.missing.length>0){const first=pitchPlan.missing[0]
return{...autoBuyRefusal(targets,'concepts'),
detail:{stage:'concepts',why:first.why,name:first.name??null,id:first.id??null,count:pitchPlan.missing.length}}}
let sbc=null
try{sbc=createSbc(window)}catch{sbc=null}
try{await Promise.all([buyRate.load(),dayBudget.load()])}catch(err){note(`auto-buy: счётчики не прочитаны (${err?.message??err})`)}
const clock=createClock()
let startingCoins=null
try{startingCoins=wallet.coins()}catch{startingCoins=null}
if(!Number.isFinite(startingCoins)||startingCoins<0)return autoBuyRefusal(targets,'coins')
const session=createSession({clock,dryRun:false,startingCoins})
const plan=(Array.isArray(targets)?targets:[]).map(buyTargetOf)
const stop=createStopConditions({minCoins:0,maxSpend:batchCeiling(plan)},{clock})
slot.engine=createAutoBuy({market,session,stop,clock,moveTo:ITEM_PILE.CLUB,coinBalance:wallet.coins,buyRate,
budget:huntBudget,
findLot:createLotFinder({market,clock,budget:marketBudget,criteriaOf:(id)=>criteriaForCard(id,null)}),
place:(target,card,context)=>{const put=placeBoughtCard(context,target?.row,card,pitchPlan.slots)
if(put?.ok!==true)slot.lastPlace=put??null
else if(typeof put?.already==='string')note(`auto-buy: карта уже стояла в слоте ${put.slot} (${put.already})`)
return put},
save:async(context)=>{if(sbc===null||typeof sbc.saveChallenge!=='function')throw new Error('sbc: сохранять нечем')
return sbc.saveChallenge(context?.challenge)},
onEvent:(name,payload)=>{
if(name==='bought')notePaid(payload?.item,payload?.price)
if(name==='failure')note(`auto-buy: отказ ${payload?.stage??'?'} — ${payload?.category??'?'}`)
if(name==='stopped')note(`auto-buy: ${payload?.bought??0} из ${payload?.planned??0}, потрачено ${payload?.spent??0}, причина ${payload?.reason??'нет'}`)
if(name==='receipt')note(`auto-buy: расписка ${payload?.shape??'?'}, разбор ${payload?.how??'?'}, предмет лота ${payload?.lotNamed===true?'тот же':'другой'}`)}})
try{
if(slot.cancelled)return autoBuyRefusal(targets,'cancel','cancelled')
return placeSeen(await slot.engine.run(plan,onProgress,prepared),slot)}
finally{workArea.restore()}}
const placeSeen=(out,slot)=>{const snapshot=slot?.lastPlace?.field??null
if(snapshot===null||out?.reason!=='place-failed')return out
return{...out,detail:{...(out?.detail??{}),field:snapshot}}}
const probeQueueFrom=(prices)=>measureQueueFrom(prices,{suspects:priceQuarantine.suspects(prices),
answer:lastSolve?.answer??null,unknownIds:catalog.unknownIds(4),
sourceOf:(id)=>futggSource.sourceOf(priceCacheKey(id,{platform:personas.pricePlatform()}))})
const cachedPriceOfItem=(item)=>{const definitionId=item?.definitionId??item?.defId
const measured=priceCache.get(marketCacheKey(definitionId))
if(Number.isFinite(measured)&&measured>0)return measured
const external=priceCache.get(priceCacheKey(definitionId,{platform:personas.pricePlatform()}))
return Number.isFinite(external)&&external>0?external:null}
const solveReader=createSolvePriceReader({source:futggSource,keyOf:(id)=>priceCacheKey(id,{platform:personas.pricePlatform()}),clock:priceClock,closeMs:FUTGG_MANIFEST_TTL_MS})
const ladderPriceOf=(id)=>solveReader.priceOf(id)
const clubBlobPrices=(items,opts={})=>pricesForClub(items,{priceOf:ladderPriceOf,
pause:typeof opts.pause==='function'?opts.pause:null,now:()=>priceClock.now()})
const solvePriceOf=(blob)=>(item)=>{const measured=cachedPriceOfItem(item)
if(measured!==null)return measured
const price=blob.get(item?.definitionId??item?.defId)
return Number.isFinite(price)&&price>0?price:null}
const badgePriceOf=(item)=>{const measured=cachedPriceOfItem(item)
if(measured!==null)return measured
if(!settings.isActive(PRICE_FEATURE))return null
const id=item?.definitionId??item?.defId
return Number.isSafeInteger(id)&&id>0?ladderPriceOf(id):null}
const priceKeyOf=(id)=>priceCacheKey(id,{platform:personas.pricePlatform()})
const priceTrap=createPriceTrap({clock:priceClock,shout,
rawOf:(id,radius)=>futggSource.rawWindow(priceKeyOf(id),radius),
crossOf:(id)=>futggSource.crossCheck(priceKeyOf(id))})
const priceQuarantine=createPriceQuarantine({clock:priceClock,liveOf:(id)=>livePrices.priceOf(id)})
const priceLadder=createLadderService({players:createStaticPlayers(window),priceOf:ladderPriceOf,rarities:createRarityGroups({fetch:createBridgeFetch(bridge),clock:priceClock}),attrsOf:(id)=>catalog.get(id),clock:priceClock,isActive:()=>settings.isActive('sbcSolver'),onRebuild:(prev,next)=>priceTrap.watch(prev,next),quarantine:priceQuarantine})
const rarityLadderMemo=createAgedMemo({clock:priceClock,maxAgeMs:LADDER_TTL_MS,name:'rarity',stamp:ladderStamp})
const rarityLaddersNow=(help,as)=>rarityLadderMemo(catalog.revision(),async()=>{const built=await laddersFrom(catalog.byRarity(),ladderPriceOf,(id)=>catalog.get(id),help)
return built===undefined?undefined:priceQuarantine.guardLadders('rarityLadders',built)},as)
let ladderSnapshot=null
const noteLadderSnapshot=(prices)=>{if(prices&&Array.isArray(prices.ladder)&&prices.ladder.length>0)ladderSnapshot=prices
return prices}
const identityLadderMemo=createAgedMemo({clock:priceClock,maxAgeMs:LADDER_TTL_MS,name:'identity',keep:IDENTITY_MEMO_KEEP,stamp:ladderStamp})
const identityLaddersNow=(wants,help,as)=>{const asked=wants??{league:[],nation:[],team:[]}
return identityLadderMemo(`${catalog.revision()}|${asked.league}|${asked.nation}|${asked.team}`,async()=>{const value={}
for(const[field,prop]of IDENTITY_LADDERS){if((asked[field]?.length??0)===0)continue
const ladders=await laddersFrom(catalog.byIdentity(field,asked[field]),ladderPriceOf,(id)=>catalog.get(id),help)
if(ladders===undefined)return undefined
if(ladders!==null)value[prop]=priceQuarantine.guardLadders(prop,ladders)}
return value},as)}
const IDENTITY_LADDERS=[['league','leagueLadders'],['nation','nationLadders'],['team','clubLadders']]
const bucketMemo=createAgedMemo({clock:priceClock,maxAgeMs:LADDER_TTL_MS,name:'buckets',stamp:ladderStamp})
const bucketsNow=async(wanted,help,as)=>{if(wanted!==true)return{}
const buckets=await bucketMemo(catalog.revision(),()=>bucketsFrom(catalog.byRarity(),ladderPriceOf,(id)=>catalog.get(id),help),as)
if(buckets===undefined)return undefined
return buckets===null?{}:{buckets}}
let generalLadderLast={builtAt:null,from:null}
const generalLadderNow=async(as)=>{const startedAt=priceClock.now()
const got=await priceLadder.read()
const builtAt=Number.isFinite(got?.builtAt)?got.builtAt:null
const from=typeof as==='string'&&as!==''?as:null
if(builtAt===null){ladderLedger.note('general',{from:ladderFromOf(true,from),ms:priceClock.now()-startedAt,age:null,key:null})
return got}
const built=builtAt!==generalLadderLast.builtAt
if(built)generalLadderLast={builtAt,from}
ladderLedger.note('general',{from:ladderFromOf(built,generalLadderLast.from),ms:priceClock.now()-startedAt,age:priceClock.now()-builtAt,key:String(builtAt)})
return got}
const LADDER_ORDER=Object.freeze(['general','rarity','identity','buckets'])
const laddersFor=async(opts={})=>{const pause=typeof opts.pause==='function'?opts.pause:null
const as=typeof opts.as==='string'&&opts.as!==''?opts.as:undefined
const help=pause===null?undefined:{pause,sliceMs:BLOB_SLICE_MS,now:()=>priceClock.now()}
const order=Array.isArray(opts.families)&&opts.families.length>0?opts.families:LADDER_ORDER
let base=null
let rarity=null
let askedRarity=false
let identity=null
let buckets=null
for(const family of order){if(family==='general'){base=await generalLadderNow(as)
continue}
if(family==='rarity'){askedRarity=true
rarity=await rarityLaddersNow(help,as)
if(rarity===undefined)return undefined
continue}
if(family==='identity'){identity=await identityLaddersNow(opts.wants,help,as)
if(identity===undefined)return undefined
continue}
if(family==='buckets'){buckets=await bucketsNow(opts.buckets===true,help,as)
if(buckets===undefined)return undefined}}
const prices={...base}
if(askedRarity)prices.rarityLadders=rarity
prices.rarityGroups=groupBook.dictionary()
if(identity!==null)Object.assign(prices,identity)
if(buckets!==null)Object.assign(prices,buckets)
return noteLadderSnapshot(livePrices.applyTo(prices))}
let demandMemo={key:null,value:[]}
const openChallengesNow=()=>{let list=[]
try{list=createSbc(window).cachedChallenges()}catch{list=[]}
const key=`${list.length}.${list.reduce((sum,one)=>sum+(one.requirements?.length??0),0)}`
if(demandMemo.key!==key)demandMemo={key,value:list}
return demandMemo.value}
const liveClassesNow=(challenge)=>{try{return liveClassesFrom(challenge?.eligibilityRequirements,openChallengesNow())}catch{return[]}}
const liveRatingsNow=(challenge)=>{try{return liveRatingsFrom(challenge?.eligibilityRequirements,openChallengesNow())}catch{return[]}}
const demandNow=(challenge)=>{const live=liveClassesNow(challenge)
try{demandMemory.note(live,liveRatingsNow(challenge))
return{live,all:unionClasses(live,demandMemory.classes())}}catch(err){note(`demand: ${err?.message??err}`)
return{live,all:live}}}
const searchableNow=(club)=>{try{const mineIds=new Set((Array.isArray(lastSolve?.answer?.mine)?lastSolve.answer.mine:[]).map(String))
const hand=club.filter((one)=>mineIds.has(String(one?.id??'')))
const shield=[...sanitizeCardLocks(cardLockProvider.read()),...(activeSquadCache.peek()??[])]
return searchableCards(poolForSearch(club,hand),shield)}catch(err){note(`sbc worth: запас не посчитан (${err?.message??err})`)
return null}}
const demandReport=()=>{const open=openChallengesNow()
const challenge=lastSolve?.challenge??null
let classes=null
if(challenge!==null){try{classes=demandClasses(parseRequirements(challenge.eligibilityRequirements).requirements).length}catch{classes=null}}
return{challenges:open.length,classes,live:unionClasses(liveClassesNow(challenge),demandMemory.classes()).length}}
const CATALOG_SEED_SLICE=4000
const cardLane=createCardLane({fetch:createBridgeFetch(bridge),clock:priceClock})
const seedInSlices=(total,take,done)=>{let cursor=0
const finish=()=>{if(typeof done==='function')done()}
const step=()=>{const end=Math.min(cursor+CATALOG_SEED_SLICE,total)
try{take(cursor,end)}catch(err){note(`catalog seed: ${err?.message??err}`)}
cursor=end
if(cursor<total){idleFrame(step)
return}
finish()}
if(total>0)idleFrame(step)
else finish()}
const CATALOG_BASE_TRIES=40
const CATALOG_BASE_STEP_MS=3000
const CATALOG_WAIT_TRIES=300
const catalogWait=createWaitNotice({name:'catalog seed',pending:'справочник EA ещё не приехал, попробуем позже',gone:'справочник EA так и не приехал',now:()=>clock.now(),record:(message)=>{state.errors.push(String(message))},recordPending:false})
const seedBaseRatings=(tries)=>{const players=createStaticPlayers(window)
let base=[]
try{base=players.list()}catch{base=[]}
if(base.length>0){seedInSlices(base.length,(from,to)=>catalog.seedRatings(base.slice(from,to)))
return}
let ready=null
try{ready=players.ready()}catch{ready=null}
const left=ready===false?Math.max(tries,CATALOG_WAIT_TRIES)-1:tries-1
if(left>0){catalogWait.waiting(`дверь: ${ready===null?'нет':String(ready)}`)
setTimeout(()=>seedBaseRatings(left),CATALOG_BASE_STEP_MS)}
else catalogWait.lost({eaSeen:ready!==null})}
const catalogReady=catalog.load()
void catalogReady.then(()=>{seedBaseRatings(CATALOG_BASE_TRIES)
return cardLane.read()}).then((lane)=>{const ids=Array.isArray(lane?.ids)?lane.ids:[]
if(ids.length===0)return
catalog.setUniverse(ids)
seedInSlices(ids.length,(from,to)=>catalog.seedPositions(lane,from,to))}).catch((err)=>note(`catalog seed: ${err?.message??err}`))
const cardBase=createCardBaseFeed({
ask:(params)=>bridge.request(CARDS_METHOD,params,{timeoutMs:CARDS_TIMEOUT_MS}),
storage:{read:()=>bridge.request('cardbase.read'),write:(value)=>bridge.request('cardbase.write',value)},
season:()=>seasonOf(),
game:()=>currentGame(),
now:()=>clock.now(),
seed:(base)=>new Promise((resolve)=>{let cards=0
seedInSlices(base.count,(from,to)=>{cards+=catalog.seedAttributes(baseDefinitions(base,from,to))},()=>resolve({cards}))}),
groups:(dictionary)=>{groupBook.seedGroups(dictionary,'base')},
onError:(err)=>note(`card base: ${err?.message??err}`)})
const CARD_BASE_TICK_MS=1_800_000
const cardBaseTick=(why)=>{void cardBase.refresh(why).catch((err)=>note(`card base: ${err?.message??err}`))
setTimeout(()=>cardBaseTick('tick'),CARD_BASE_TICK_MS)}
void catalogReady.then(()=>cardBase.load()).then(()=>{cardBaseTick('start')}).catch((err)=>note(`card base: ${err?.message??err}`))
const priceEvidenceOfItem=async(item)=>{if(!settings.isActive(PRICE_FEATURE))return null
const key=priceCacheKey(item?.definitionId??item?.defId,{platform:personas.pricePlatform()})
if(key===null)return null
const result=await priceLookup.lookup(key)
return{...result,source:result.from==='cache'?'external price cache':'configured external fallback',observedAt:result.observedAt??priceClock.now()}}
const priceOfItem=async(item)=>(await priceEvidenceOfItem(item))?.price??null
const marketEvidenceOfItem=async(item,hint=null)=>{const key=marketCacheKey(item?.definitionId??item?.defId)
if(key===null)return{ok:false,price:null,reason:'bad-key',from:'market'}
const prior=Number.isFinite(hint?.prior)&&hint.prior>0?hint.prior:cachedPriceOfItem(item)
const ask=()=>marketLookup.lookup(key,{type:hint?.type??searchTypeOf(item),prior,
...(typeof hint?.cancelled==='function'?{cancelled:hint.cancelled}:{}),
...(Number.isFinite(hint?.emptyTtlMs)&&hint.emptyTtlMs>0?{emptyTtlMs:hint.emptyTtlMs}:{})})
const result=hint?.slotted===true?await ask():await livePrices.slot(hint?.priority??0,ask)
return{...result,from:result.from==='cache'?'memory':'market',provider:null,observedAt:result.observedAt??priceClock.now()}}
const sellMarketEvidence=async(item)=>{const one=await marketEvidenceOfItem(item)
return one?.from==='memory'?{...one,from:'market'}:one}
const uiProvider=await loadBridgeProvider(createBridgeUiProvider,'ui')
const uiState=createUiState({provider:uiProvider})
if(uiState.pickPreselect()===null){try{const raw=await bridge.request(SETTINGS_READ)
const moved=uiState.setPickPreselect(pickPreselectFromToggles(raw))
if(!moved.ok)note(`pick preselect move: ${moved.reason}`)}catch(err){note(`pick preselect move: ${err?.message??err}`)}}
if(uiState.pickPreselect()!==null&&settings.isOn(PICK_BY_PRICE_FEATURE)!==true){const on=settings.set(PICK_BY_PRICE_FEATURE,true)
if(!on.ok)note(`pick tariff key: ${on.reason}`)}
setEaRequestPort(()=>uiState.isDayXOff())
applyLocale(uiState.locale())
let notice=null
const taxState={price:'',want:''}
let selectedPlayer=null
const report=(result)=>{notice=result?.notice??null
if(!result?.ok)note(`filters: ${JSON.stringify(result?.notice ?? null)}`)
panel.update()}
publishTemplateMenu({sets:()=>filterStore.list(),
rename:(id,name)=>{const res=renameFilter(id,name,filterDeps)
panel.update()
wiring?.refresh?.()
return res},
remove:(id)=>{const res=removeFilter(id,filterDeps)
panel.update()
wiring?.refresh?.()
return res}})
const licenseAction=async(action,value)=>{if(action==='account')await bridge.request(ACCOUNT_OPEN);
else if(migrationProvider.state().mode!=='legacy')return undefined;
else if(action==='apply')await keyProvider.setKey(value);
else if(action==='clear')await keyProvider.setKey('');
else return undefined;
panel.update();
wiring?.refresh();
return undefined}
const CLOUD_SECTION=(()=>{for(const[address,hand]of Object.entries(DEEDS)){
if(typeof hand==='string'&&hand.startsWith('cloud.'))return address.slice(0,address.indexOf('.'))}
return null})()
const reloadStoredSettings=async()=>{await Promise.all([provider.load(),filterProvider.load(),packProvider.load(),
uiProvider.load(),limitsProvider.load(),optionsProvider.load(),sellerProvider.load()])
automation.reloadLimits()
automation.reloadOptions()
seller.reloadOptions()
if(applyLocale(uiState.locale()))wiring?.relabel?.()
panel?.update?.()
wiring?.refresh?.()}
const cloudDesk=createCloudDesk({request:(method,params)=>bridge.request(method,params),
doc:document,clock:{now:()=>clock.now()},
onChange:()=>panel?.update?.(),
onError:(message)=>note(message),
onApplied:reloadStoredSettings})
cloudNotice=(changes)=>{cloudDesk.notice(changes)}
const settingsTransfer=createSettingsTransfer({bridge,onApplied:reloadStoredSettings,onError:(message)=>note(message)})
watchSettingsApplied(window,()=>{void reloadStoredSettings().catch((err)=>note(`transfer: ${err?.message??err}`))})
const problemReport=createProblemReport({dialogs:{report:(opts)=>panel.dialogs.report(opts)},
signedIn:()=>migrationProvider.state().authenticated===true,bridge,
clipboard:{writeText:(text)=>navigator.clipboard.writeText(text)},
openTab:window,
onError:(message)=>note(message),
source:()=>({now:clock.now(),version:state.version,userAgent:navigator.userAgent,languages:[...(navigator.languages??[])],
window:{width:window.innerWidth,height:window.innerHeight,dpr:window.devicePixelRatio},locale:i18n.locale,
screen:document.querySelector('.ut-navigation-bar-view h1')?.textContent?.trim()?.slice(0,80)??null,
evidence:currentEvidence(),errors:state.errors,journal:journal.view(20),license:migrationProvider.state(),
settings:{features:provider.read(),filters:filterProvider.read(),buyerLimits:limitsProvider.read(),buyerOptions:optionsProvider.read(),
sellerOptions:sellerProvider.read(),interface:uiProvider.read(),packLocks:packProvider.read()}})})
let wiring=null
let wiringMounted=false
let applyDayX=()=>({ok:false,reason:'not-ready'})
const openSettingsWindow=()=>{notice=null
return settingsDoor.goTo(settingsDoor.last()??FIRST_SECTION)}
let marketBotAim=null
const buyerDoor=createBuyerDoor({bar:()=>marketBotAim,engine:automation,
onError:(err)=>note(`buyer door: ${err?.message??err}`)})
const settingsDoor=createSettingsDoor({update:()=>panel?.update?.()})
const panel=mountPanel({doc:document,getState:()=>({t,locale:i18n.locale,registry:settings.registry(),statusOf:settings.statusOf,
filters:filterStore.list(),filtersStatus:settings.statusOf('advancedFilters'),packs:{...packs,picks:playerPicks,recovery:unassignedRecovery,automation:packAutomation,show:uiState.packShow(),unassignedThreshold:uiState.unassignedThreshold()},
solver:uiState.solver(),
soundVolume:uiState.soundVolume(),
pickPreselect:uiState.pickPreselect(),
cloud:cloudDesk.state(),
chosenFilters:uiState.selectedFilters(),automation:automation.status(),automationStatus:settings.statusOf('autoBuyer'),seller:seller.status(),sellerStatus:settings.statusOf('autoSeller'),journal:journal.view(JOURNAL_ROWS),ledger:{session:ledger.session(),allTime:ledger.allTime()},license:{...migrationProvider.state(),now:clock.now()},tax:taxState,taxStatus:settings.statusOf(TAX_FEATURE),club:clubState,clubStatus:settings.statusOf(CLUB_FEATURE),selectedPlayer,diagnostics:{bridge:state.bridge,version:state.version,errors:state.errors.length},onboarded:uiState.isOnboarded(),notice,
coins:wallet.coins(),formatCoins,
relist:uiState.relist(),
listing:uiState.listing(),
panelView:{...uiState.panelView(),section:settingsDoor.section()},
lastSection:settingsDoor.last(),
dayXOff:uiState.isDayXOff(),dayXMounted:wiringMounted,
hotkeys:uiState.hotkeys(),hotkeysStatus:settings.statusOf(HOTKEYS_FEATURE)}),handlers:{
settingsTransfer,
onHotkeysReset:()=>{const res=uiState.setHotkeyState({...sanitizeHotkeyProfile(null),dangerSeen:uiState.hotkeyState().dangerSeen})
if(!res.ok)note(`hotkeys reset: ${res.reason}`)
wiring?.refresh?.()
return res},
problemReport,
onHotkey:()=>{wiring?.hotkeys?.openWindow?.()
return undefined},
onLocale:(value)=>{const res=uiState.setLocale(value)
if(!res.ok)note(`locale: ${res.reason}`)
if(applyLocale(uiState.locale()))wiring?.relabel?.()
panel.update()
return undefined},
onRelist:(field,value)=>{const res=uiState.setRelist({[field]:value})
if(!res.ok)note(`relist ${field}: ${res.reason}`)
panel.update()
wiring?.syncRelistPricing?.()
wiring?.refresh()
return undefined},
onListing:(field,value)=>{const res=uiState.setListing({[field]:value})
if(!res.ok)note(`listing ${field}: ${res.reason}`)
panel.update()
return undefined},
onToggle:(feature,value)=>{const res=settings.set(feature,value);
if(!res.ok)note(`toggle ${feature}: ${res.reason}`);
panel.update();
wiring?.refresh()},
onPanelView:(patch)=>{
if(Object.hasOwn(patch,'section'))settingsDoor.goTo(patch.section)
if(CLOUD_SECTION!==null&&patch?.section===CLOUD_SECTION)void cloudDesk.refresh()
const rest={...patch}
delete rest.section
if(Object.keys(rest).length>0){const res=uiState.setPanelView(rest);
if(!res.ok)note(`panel view: ${res.reason}`)}
panel.update()},
onDayX:(value)=>{const want=value===true
const res=uiState.setDayXOff(want)
if(!res.ok){note(`day-x: ${res.reason}`)
panel.update()
return}
const done=applyDayX(want)
if(!done.ok)note(`day-x: ${done.reason}`)
panel.update()},
onSoundVolume:(value)=>{const res=uiState.setSoundVolume(value)
if(!res.ok)note(`sound volume: ${res.reason}`)
panel.update()},
onPickPreselect:(value)=>{const res=uiState.setPickPreselect(value)
if(!res.ok)note(`pick preselect: ${res.reason}`)
panel.update()},
onOnboarding:(value)=>{const res=uiState.setOnboarded(value===true);
if(!res.ok)note(`ui onboarding: ${res.reason}`);
panel.update()},
onSolver:(field,value)=>{const res=uiState.setSolver(field,value===true)
if(!res.ok)note(`solver ${field}: ${res.reason}`)
panel.update()},
onCloud:(action)=>{if(action==='sync')void cloudDesk.run()
else if(action==='take-cloud')void cloudDesk.run('cloud')
else if(action==='take-local')void cloudDesk.run('local')
else if(action==='save-file')void cloudDesk.saveFile()
else if(action==='load-file')cloudDesk.loadFile()
else note(`cloud: неизвестное действие ${action}`)
return undefined},
onDiagnostics:async()=>{const health=await checkBridge(bridge);
state.bridge=health.ok?'ok':'failed';
if(health.ok)state.version=health.version;
if(!health.ok){automation.stop();
seller.stop();
note(`bridge check: ${health.reason}`)}
panel.update()},
onPacks:async(action,value)=>{
if(action==='show-policy'){const done=uiState.setPackShow(value?.field,value?.value===true);
if(!done.ok)note(`pack show: ${done.reason}`);
panel.update();
return}
if(action==='show-rating'){const text=String(value?.value??'').trim()
const done=uiState.setPackShow('ratingMin',text===''?null:sanitizeShowRating(Number(text)));
if(!done.ok)note(`pack show: ${done.reason}`);
panel.update();
return}
if(action==='automation-policy'){if(['autoPick','autoRecovery','autoDiscard','autoContinue'].includes(value?.field)){const next=value?.value===true;
if(packAutomation[value.field]!==next){packAutomation[value.field]=next;
packAutomation.ticket=null;
packAutomation.outcomeAction=null;
packAutomation.continuation=null}
panel.update()}
return}
if(action==='automation-limit'){if(['maxPacks','maxMinutes','recoveryOrder','discardAllowlist'].includes(value?.field)){packAutomation[value.field]=String(value?.value??'');
clearPackAutomation();
packAutomation.ticket=null;
if(value.field==='discardAllowlist'&&unassignedRecovery.loaded)
previewUnassignedDiscard(unassignedRecovery,packAutomation.discardAllowlist);
panel.update()}
return}
if(action==='automation-step'){const a=packAutomation;
if(a.busy||packs.busy||playerPicks.busy||unassignedRecovery.busy
||a.review?.ok!==true||a.review.nextPack?.key!==value)return;
const reviewed=a.review;
const confirmed=await panel.dialogs.confirm({titleKey:'packs.open',messageKey:'packs.confirm'
});
if(confirmed!==true)return;
if(!a.ticket){const started=beginPackAutomationSession(reviewed,confirmed,clock,packAutomation);
if(!started.ok){note(`pack automation session: ${started.reason}`);
return}
a.ticket=started.ticket}
a.busy=true;
packs.busy=true;
clearPackAutomation();
panel.update();
try{let result=await runPackAutomationStep({adapter:packAutoAdapter,provider:packProvider,expectedKey:value,confirmed,ticket:packAutomation.ticket});
notice={key:result.ok?'packs.opened':'packs.failed',params:{count:result.items?.length??0}};
if(!result.ok)note(`pack automation step: ${result.reason}`);
while(result.ok){await adoptPackAutomationOutcome();
a.outcomeAction=previewPackAutomationOutcomeAction(packAutomation.ticket,packAutomation.outcome,unassignedRecovery);
if(a.outcomeAction?.ok&&a.outcomeAction.action==='pick'){a.outcomeAction=await runPackAutomationPickOutcome({ticket:a.ticket,outcome:a.outcome,adapter:packAutoAdapter,state:playerPicks,priceOf:priceOfItem});
if(a.outcomeAction.ok)notice={key:'packs.picks.confirmed',params:{count:a.outcomeAction.rewards}};
else note(`pack automation pick: ${a.outcomeAction.reason}`)}else if(a.outcomeAction?.ok&&a.outcomeAction.action==='recovery'){unassignedRecovery.busy=true;
try{a.outcomeAction=await runPackAutomationRecoveryOutcome({ticket:a.ticket,outcome:a.outcome,adapter:packAutoAdapter,state:unassignedRecovery});
if(a.outcomeAction.ok)notice={key:'packs.recovery.moved',params:{count:a.outcomeAction.count}};
else note(`pack automation recovery: ${a.outcomeAction.reason}`)}finally{unassignedRecovery.busy=false}}else if(a.outcomeAction?.ok&&a.outcomeAction.action==='discard'){unassignedRecovery.busy=true;
try{a.outcomeAction=await runPackAutomationDiscardOutcome({ticket:a.ticket,outcome:a.outcome,adapter:packAutoAdapter,state:unassignedRecovery});
if(a.outcomeAction.ok)notice={key:'packs.recovery.discarded',params:{count:a.outcomeAction.count,value:a.outcomeAction.value}};
else note(`pack automation discard: ${a.outcomeAction.reason}`)}finally{unassignedRecovery.busy=false}}
if(a.outcomeAction?.ok!==true||a.outcomeAction.executed!==true)break;
a.continuation=await previewPackAutomationContinuation({ticket:a.ticket,adapter:packAutoAdapter,provider:packProvider});
if(!a.continuation.ok){if(a.continuation.reason!=='policy-disabled')
note(`pack automation continuation: ${a.continuation.reason}`);
break}
const continuation=a.continuation;
result=a.continuation=await runPackAutomationContinuation({ticket:a.ticket,adapter:packAutoAdapter,provider:packProvider,continuation});
if(!result.ok)note(`pack automation continuation: ${result.reason}`)}
if(a.outcome?.ok===false)note(`pack automation outcome: ${a.outcome.reason}`)}catch(err){note(`pack automation step: ${err?.message ?? err}`);
notice={key:'packs.failed',params:{}}}finally{a.busy=false;
packs.busy=false;
panel.update()}
return}
if(action==='automation-preview'){if(packAutomation.busy||packs.busy||playerPicks.busy||unassignedRecovery.busy)return;
packAutomation.busy=true;
packs.busy=true;
clearPackAutomation();
panel.update();
try{packAutomation.review=await previewPackAutomation({adapter:packAutoAdapter,provider:packProvider,maxPacks:packAutomation.maxPacks,maxMinutes:packAutomation.maxMinutes})}catch(err){note(`pack automation preview: ${err?.message ?? err}`);
packAutomation.review={ok:false,reason:'unknown-state'}}finally{packAutomation.busy=false;
packs.busy=false;
panel.update()}
return}
packAutomation.review=null;
if(action==='select'){if(setPlayerPickSelection(playerPicks,value?.index,value?.value)){const review=reviewPlayerPickSelection(playerPicks);
playerPicks.review=review.ok?packAdapter.reviewPicks(playerPicks.selected):review;
panel.update()}
return}
if(action==='recovery-plan'){const result=setUnassignedDisposition(unassignedRecovery,value?.index,value?.disposition);
if(!result.ok)note(`unassigned recovery plan: ${result.reason}`);
panel.update();
return}
if(action==='recovery-reset'){const result=resetUnassignedDispositions(unassignedRecovery);
if(!result.ok)note(`unassigned recovery reset: ${result.reason}`);
panel.update();
return}
if(action==='recovery-review'){const result=reviewUnassignedRecovery(packAdapter,unassignedRecovery);
if(!result.ok)note(`unassigned recovery review: ${result.reason}`);
panel.update();
return}
if(action==='recovery-discard'){const preview=unassignedRecovery.discardPreview;
if(unassignedRecovery.busy||preview?.ok!==true||preview.count<1)return;
const confirmed=await panel.dialogs.confirm({titleKey:'packs.recovery.discardApply',messageKey:'packs.recovery.discardConfirm',messageParams:{count:preview.count,value:preview.value}});
if(confirmed!==true||unassignedRecovery.discardPreview!==preview)return;
unassignedRecovery.busy=true;
panel.update();
const result=await runDiscardStep({adapter:packHandAdapter,state:unassignedRecovery,confirmed});
if(result.ok){notice={key:'packs.recovery.discarded',params:{count:result.count,value:result.value}}}else{note(`unassigned discard: ${result.reason}`);
notice={key:'packs.recovery.discardFailed',params:{}}}
unassignedRecovery.busy=false;
panel.update();
return}
if(action==='recovery-apply'){const destination=value?.destination;
if(unassignedRecovery.busy||unassignedRecovery.review?.ok!==true
||!['club','transfer','storage'].includes(destination))return;
const confirmed=await panel.dialogs.confirm({titleKey:'packs.recovery.confirm',messageKey:destination==='storage'
?'packs.recovery.confirmStorage':'packs.recovery.confirmMessage',messageParams:{count:unassignedRecovery[destination],destination:t({club:'packs.recovery.club',transfer:'packs.recovery.transfer',storage:'packs.recovery.storage'
}[destination])}});
if(confirmed!==true)return;
unassignedRecovery.busy=true;
panel.update();
const result=await runRecoveryStep({adapter:packHandAdapter,state:unassignedRecovery,destination,confirmed});
if(result.ok){notice={key:'packs.recovery.moved',params:{count:result.count}}}else{note(`unassigned recovery move: ${result.reason}`);
notice={key:'packs.recovery.moveFailed',params:{}}}
unassignedRecovery.busy=false;
panel.update();
return}
if(action==='recovery'){if(unassignedRecovery.busy)return;
unassignedRecovery.busy=true;
panel.update();
try{const result=await refreshUnassignedRecovery(packHandAdapter,unassignedRecovery);
if(!result.ok)throw new Error(result.reason);
recover()}catch(err){note(`unassigned recovery: ${err?.message ?? err}`);
notice={key:'packs.recovery.failed',params:{}}}finally{unassignedRecovery.busy=false}
panel.update();
return}
if(action==='confirm-picks'){if(playerPicks.busy||playerPicks.review?.ok!==true)return;
const confirmed=await panel.dialogs.confirm({titleKey:'packs.picks.confirm',messageKey:'packs.picks.confirmMessage'
});
if(confirmed!==true)return;
invalidateUnassignedRecovery(unassignedRecovery);
playerPicks.busy=true;
panel.update();
const result=await runPickStep({adapter:packHandAdapter,state:playerPicks,confirmed});
if(result.ok){Object.assign(playerPicks,{items:[],availablePicks:0,selected:[],review:null,loaded:true});
notice={key:'packs.picks.confirmed',params:{count:result.rewards}}}else{note(`player picks confirm: ${result.reason}`);
notice={key:'packs.picks.failed',params:{}}}
playerPicks.busy=false;
panel.update();
return}
if(action==='picks'){if(playerPicks.busy)return;
playerPicks.selected=[];
playerPicks.review=null;
playerPicks.busy=true;
panel.update();
try{const result=await packHandAdapter.pendingPicks();
playerPicks.items=result.items;
playerPicks.availablePicks=result.availablePicks;
playerPicks.loaded=true;
pick()}catch(err){playerPicks.items=[];
playerPicks.availablePicks=0;
playerPicks.loaded=false;
note(`player picks: ${err?.message ?? err}`);
notice={key:'packs.picks.failed',params:{}}}finally{playerPicks.busy=false}
panel.update();
return}
},
onTax:(field,text)=>{if(field!=='price'&&field!=='want')return undefined;
taxState[field]=typeof text==='string'?text:'';
panel.update();
return undefined},
onAutomation:(action)=>{const res=action==='stop'
?buyerDoor.press('stop')
:buyerDoor.press('start');
liveEvidence.record(`buyer.${action}`,res,{dryRun:automation.status().dryRun});
notice=res.notice??null;
panel.update();
return res.opened===true},onDryRun:(value)=>{const res=automation.setDryRun(value);
liveEvidence.record('buyer.dryRun',res,{dryRun:value===true});
return report(res)},
onFilterPick:(id,value)=>{const res=uiState.selectFilter(id,value===true);
if(!res.ok)note(`filter pick ${id}: ${res.reason}`);
panel.update();
return res},
onSeller:(action,value)=>{if(action==='dryRun'){const res=seller.setDryRun(value);
liveEvidence.record('seller.dryRun',res,{dryRun:value===true});
return report(res)}
const res=action==='stop'?seller.stop():seller.start({});
liveEvidence.record(`seller.${action}`,res,{dryRun:seller.status().dryRun});
return report(res)},onSellerOption:(key,value)=>{const res=seller.setOption(key,value);
if(!res.ok)report(res);
return res},
onLicense:licenseAction,
onJournal:async(action)=>{if(action!=='export')return undefined;
const view=journal.view();
await panel.dialogs.show({titleKey:'journal.exportTitle',titleParams:{count:view.total},text:journalText(t,view)});
return undefined},
onLedger:async(action)=>{if(action==='export'){const view={session:ledger.session(),allTime:ledger.allTime()};
await panel.dialogs.show({titleKey:'ledger.exportTitle',titleParams:{count:view.allTime.deals.length},text:ledgerText(t,view)});
return undefined}
if(action==='csv'){const exported=ledgerCsv(ledger.allTime());
if(exported.ok)await panel.dialogs.show({titleKey:'ledger.csvTitle',titleParams:{count:exported.rows},text:exported.text});
return exported}
if(action==='reset'){const confirmed=await panel.dialogs.confirm({titleKey:'ledger.reset',messageKey:'ledger.confirmReset'
});
if(confirmed===true)ledger.reset();
panel.update()}
return undefined},
onClub:async(action,id)=>{
if(action==='table-filter'){const key=String(id?.key??'')
if(Object.hasOwn(clubState.tableFilters,key)){clubState.tableFilters[key]=String(id?.value??'');clubState.tablePage=1;panel.update()}
return undefined}
if(action==='table-export'&&clubState.analysis?.table){const exported=exportClubItemTableCsv(clubState.analysis.table,clubState.tableFilters)
await panel.dialogs.show({titleKey:'clubTable.exportTitle',titleParams:{count:exported.rows},text:exported.text})
return exported}
if(action==='table-page'){const delta=id==='previous'?-1:id==='next'?1:0
clubState.tablePage=Math.max(1,clubState.tablePage+delta)
panel.update()
return undefined}
if(action==='price'){const row=clubState.rows.find((r)=>String(r.id)===String(id));
if(!row||row.price?.state==='busy')return undefined;
const wait=marketPrice.waitMs(marketCacheKey(row.id));
if(wait>0){row.price={state:'throttled',seconds:Math.ceil(wait / 1000)};
panel.update();
return undefined}
row.price={state:'busy'};
panel.update();
const res=await marketEvidenceOfItem({definitionId:row.id});
if(!res.ok)row.price={state:'failed',reason:res.reason};
else if(res.price===null)row.price={state:'unknown'};
else row.price={state:'known',coins:res.price};
liveEvidence.record('club.eaPrice',res,{state:row.price.state,known:row.price.state==='known'
});
panel.update();
return undefined}
if(action!=='analyze'||clubState.busy)return undefined;
clubState.busy=true;
panel.update();
const res=await analyzeClubAction({getClub:clubForAnalysis,clock,createCriteria:clubPage,priceEvidenceOf:priceEvidenceOfItem});
clubState.busy=false;
clubState.notice=res.notice;
clubState.analysis=res.analysis;
clubState.tablePage=1;
clubState.value=res.analysis
?valueNotice(res.analysis.value,res.analysis.summary.total)
:null;
clubState.rows=(res.analysis?.duplicates??[]).slice(0,CLUB_ROWS).map((dup)=>({id:dup.id,name:cardLabel(dup.items[0],dup.id),count:dup.count,sellable:dup.sellable,
price:null}));
liveEvidence.record('club.analyze',res,{total:res.analysis?.summary?.total??null,duplicateGroups:res.analysis?.duplicates?.length??null});
panel.update();
return undefined},
onLimit:(key,text)=>{const res=automation.setLimit(key,text);
if(!res.ok)report(res);
return res},
onOption:(key,value)=>{const res=automation.setOption(key,value);
if(!res.ok)report(res);
else if(res.redraw){panel.update()
marketBotAim?.refresh?.()}
return res},
onFilter:async(action,id)=>{if(action==='apply'){const res=applyFilter(id,filterDeps);
liveEvidence.record('filter.apply',res);
return report(res)}
if(action==='remove')return report(removeFilter(id,filterDeps));
if(action==='export'){const res=exportFilters(filterDeps);
if(res.ok){await panel.dialogs.show({titleKey:res.notice.key,titleParams:res.notice.params,text:res.text})}
return report(res)}
if(action==='import'){const text=await panel.dialogs.ask({titleKey:'filters.importPrompt'});
if(text===null)return undefined;
return report(importFilters(text,'merge',filterDeps))}
if(action==='rename'){const name=await panel.dialogs.ask({titleKey:'filters.rename',value:filterStore.get(id)?.name??''
});
if(name===null)return undefined;
return report(renameFilter(id,name,filterDeps))}
return undefined},onSaveFilter:async()=>{const name=await panel.dialogs.ask({titleKey:'filters.save'});
if(name===null)return undefined;
const res=saveCurrentFilter(name,filterDeps);
liveEvidence.record('filter.save',res);
return report(res)}}});
window.addEventListener('focus',()=>{void accountProvider.refresh().then(()=>{panel.update();
wiring?.refresh();
void chaseTariff()})});
const TARIFF_RETRIES=5
const TARIFF_STEP_MS=2000
const tariffPending=()=>{const why=accountProvider.state().reason
return why==='network'||why==='pending'}
let tariffNoted=false
const tariffLost=createWaitNotice({name:'тариф',prefix:'[ESHArio] тариф:',now:()=>clock.now(),record:(message)=>{state.tariff={...state.tariff,last:String(message)}}})
let tariffChasing=false
const chaseTariff=async()=>{if(tariffChasing||!tariffPending())return
tariffChasing=true
try{await chaseTariffLoop()}finally{tariffChasing=false}}
const chaseTariffLoop=async()=>{
if(!tariffNoted){tariffNoted=true
tell('ответа нет, наши вставки пока по бесплатному набору — переспрашиваем')}
for(let left=TARIFF_RETRIES;left>0;left-=1){try{await clock.sleep(TARIFF_STEP_MS)}catch{return}
await accountProvider.refresh()
state.tariff.asks+=1
if(tariffPending())continue
tell(`ответ получен с попытки ${state.tariff.asks} (${accountProvider.state().reason??'открыт'})`)
panel.update()
wiring?.refresh()
return}
tariffLost.lost({text:'ответа так и нет — премиум-вставки остаются выключенными до возврата фокуса'})}
void chaseTariff()
void(async()=>{for(let attempt=0;attempt<30;attempt+=1){if(navOrNull()){navWait.arrived();panel.update();
return}
try{await clock.sleep(1000)}catch{return}}
navWait.lost({eaSeen:clubOrNull()!==null})})();
const marketSearchQuick=installMarketSearchQuick(window,{isActive:()=>settings.isActive('advancedFilters'),mount:()=>null,mountResult:({root})=>mountMarketResultSummary({doc:document,root,t}),onError:(err)=>note(`market quick: ${err?.message??err}`)})
const sellSidebar=createSellSidebar({doc:document,t,formatCoins,isActive:settings.isActive,statusOf:settings.statusOf,priceEvidenceOf:priceEvidenceOfItem,measureMarket:sellMarketEvidence,marketWaitMs:(item)=>marketPrice.waitMs(marketCacheKey(item?.definitionId??item?.defId)),
listingPricing:()=>uiState.listing(),
onError:(err)=>note(`sell sidebar: ${err?.message??err}`)})
let lockWrites=0
const LOCK_SURFACES=()=>[['card-mark',cardLockMark],['badges',lockBadges],['club-bar',clubBar],['sbc-window',sbcWindow],['squad-bar',squadBar]]
let lockFailure=null
const lockWriteFailed=()=>{lockWrites+=1
note('card lock: запись замка не доехала до хранилища (save-failed)')
const refreshed=[]
for(const[name,surface]of LOCK_SURFACES()){try{if(typeof surface?.refresh!=='function')continue
surface.refresh()
refreshed.push(name)}catch(err){note(`card lock: ${name}: ${err?.message??err}`)}}
notice={key:'sbc.locksUnreadable',params:{}}
lockFailure={at:lockWrites,refreshed,notice:notice.key}
try{panel.update()}catch(err){note(`panel: ${err?.message??err}`)}}
const writeCardLock=(id,on,label)=>{const done=setCardLock(cardLockProvider,id,on,(ok)=>{if(ok!==true)lockWriteFailed()},label)
if(done){lockWrites+=1
try{sbcWindow?.refresh?.()}catch(err){note(`card lock: ${err?.message??err}`)}
try{lockBadges?.refresh?.()}catch(err){note(`lock badges: ${err?.message??err}`)}
try{clubBar?.refresh?.()}catch(err){note(`club bar: ${err?.message??err}`)}
try{squadBar?.refresh?.()}catch(err){note(`squad bar: ${err?.message??err}`)}}
return done}
const frozenSolutions=createFrozenStore({now:()=>priceClock.now(),signatureOf:squadFieldSignature})
const cardLockMark=createCardLockMark({doc:document,t,isActive:settings.isActive,isLocked:(id)=>isCardLocked(cardLockProvider,id),setLock:writeCardLock,onError:(err)=>note(`card lock: ${err?.message??err}`)})
const lockBadges=createLockBadges({doc:document,win:window,t,isActive:settings.isActive,itemOf:itemForEvidenceRow,
lockedIds:(items)=>lockedIdsFor(cardLockProvider,items),onError:(err)=>note(`lock badges: ${err?.message??err}`)})
const squadBar=createSquadBar({doc:document,win:window,t,coins:formatCoins,isActive:settings.isActive,
priceOf:(item)=>{const measured=cachedPriceOfItem(item)
return measured!==null?measured:priceBadgePeek(item?.definitionId??item?.defId)},
floatRating:squadRatingFloatEnabled(window),
isLocked:(id)=>isCardLocked(cardLockProvider,id),setLock:(id,on)=>writeCardLock(id,on),
canLock:()=>cardLockProvider!==null&&!storageFailed(cardLockProvider),
onError:(err)=>note(`squad bar: ${err?.message??err}`)})
const squadPick=createSquadPick({doc:document,win:window,t,isActive:settings.isActive,
priceOf:(item)=>{const measured=cachedPriceOfItem(item)
return measured!==null?measured:priceBadgePeek(item?.definitionId??item?.defId)},
onError:(err)=>note(`squad pick: ${err?.message??err}`)})
const frozenMarks=createFrozenMarks({doc:document,win:window,t,isActive:settings.isActive,itemOf:itemForEvidenceRow,
frozenIds:(items)=>frozenIdsFor(cardFrozenProvider,items),
isFrozen:(id)=>isCardFrozen(cardFrozenProvider,id),
setFrozen:(id,on)=>writeCardFrozen(id,on),
onNotice:(value)=>{notice=value
try{panel.update()}catch(err){note(`panel: ${err?.message??err}`)}},
onError:(err)=>note(`frozen marks: ${err?.message??err}`)})
const writeCardFrozen=(id,on)=>{const done=setCardFrozen(cardFrozenProvider,id,on,(ok)=>{if(ok===true)return
note('card frozen: запись заморозки не доехала до хранилища (save-failed)')
notice={key:'frozen.notice.failed',params:{}}
try{frozenMarks.refresh()}catch(err){note(`frozen marks: ${err?.message??err}`)}
try{panel.update()}catch(err){note(`panel: ${err?.message??err}`)}})
if(done){try{frozenMarks.refresh()}catch(err){note(`frozen marks: ${err?.message??err}`)}}
return done}
const cardGrid=createCardGrid({doc:document,t,isActive:settings.isActive,
view:()=>uiState.cardGrid(),
setView:(patch)=>{const res=uiState.setCardGrid(patch)
if(!res.ok)note(`card grid: ${res.reason}`)
return res},
cardView:()=>uiState.cardView(),
setCardView:(next)=>{const res=uiState.setCardView(next)
if(!res.ok)note(`card view: ${res.reason}`)
return res},
onDeals:(counts)=>{try{showMarketDeals({doc:document,counts})}catch(err){note(`card grid deals: ${err?.message??err}`)}},
onError:(err)=>note(`card grid: ${err?.message??err}`)})
const dealPanel=createDealPanel({doc:document,t,
isActive:()=>settings.isActive(CARD_GRID_FEATURE),
onMarket:()=>moneyScreenLive(document),
onError:(err)=>note(`deal panel: ${err?.message??err}`)})
const clubBar=createClubBar({doc:document,t,formatNumber:(value)=>i18n.formatNumber(value),
rows:()=>clubMirror.rows(),
stamp:()=>`${clubMirror.generation()}/${clubMirror.count()}/${lockWrites}`,
lockedIds:(cards)=>lockedIdsFor(cardLockProvider,cards),
recreatedIds:()=>recreatedLockIds(),
locksStatus:()=>{try{return String(cardLockProvider?.status?.()??'')}catch{return ''}},
isActive:settings.isActive,
priceOf:(definitionId)=>{const measured=cachedPriceOfItem({definitionId})
return measured!==null?measured:priceBadgePeek(definitionId)},
ladder:()=>ladderSnapshot?.ladder??null,
itemById:(id)=>clubMemory.item(id),
setLock:writeCardLock,
view:()=>uiState.clubBar(),
setView:(patch)=>{const res=uiState.setClubBar(patch)
if(!res.ok)note(`club bar: ${res.reason}`)
return res},
onError:(err)=>note(`club bar: ${err?.message??err}`)})
const storageEcho={countChanged:()=>false}
const sbcStorage=createSbcStorage({doc:document,t,plural:(base,count,params)=>i18n.plural(base,count,params),formatNumber:(value)=>i18n.formatNumber(value),
isActive:settings.isActive,
onCount:()=>{try{storageEcho.countChanged()}catch(err){note(`sbc window: ${err?.message??err}`)}},
read:async()=>{const refusal=await dayBudget.warm(1,{market:false})
if(refusal!==null)throw dayBudgetError('storage',refusal)
return readStorage()},
moveToClub:(items)=>moveStorageToClub({market:marketOrNull(),day:dayBudget,pile:ITEM_PILE.CLUB,items}),
frame:(fn)=>{try{window.requestAnimationFrame(fn)}catch{setTimeout(fn,0)}},
now:()=>clock.now(),
say:(key,params)=>{notice={key,params:params??{}}
panel.update()},
onError:(err)=>note(`storage: ${err?.message??err}`)})
storageHooks.noteItems=(items)=>sbcStorage.noteItems(items)
storageHooks.submitted=()=>sbcStorage.submitted()
let teamConfig=null
const linkedTeamNow=(teamId)=>{if(teamConfig===null||teamConfig.available!==true)teamConfig=createTeamConfig(window)
return teamConfig.linkedTeam(teamId)}
const sbcWindow=createSbcWindow({doc:document,t,isActive:settings.isActive,statusOf:settings.statusOf,solve:solveOpenChallenge,prewarm:prewarmOpenChallenge,show:showOnPitch,searchBuy,submitHook,
wantsCheapen:()=>uiState.solver().adviseBuy!==false,
coins:formatCoins,
storageCount:()=>{try{const value=sbcStorage.count()
return Number.isFinite(value)?value:null}catch{return null}},
onSolution:()=>{try{sbcStrip.refresh()}catch(err){note(`sbc strip: ${err?.message??err}`)}},
adopt:adoptSolve,
onEnterChallenge:()=>{void activeSquadCache.refresh().catch((err)=>note(`sbc guard: активный состав не перечитан (${err?.message??err})`))},
autoBuy:{confirmPrices:(targets,opts)=>livePrices.confirmPrices(targets,opts),
run:(targets,onProgress,prepared)=>runAutoBuy(targets,onProgress,prepared),
busy:()=>buyBatch!==null,
cancel:()=>{const live=buyBatch
if(live===null)return
live.cancelled=true
try{live.engine?.cancel?.()}catch(err){note(`auto-buy: ${err?.message??err}`)}}},
livePairs:()=>livePrices.fresh(),
askConfirm:(opts)=>panel.dialogs.confirm(opts),
tradeAccess:()=>readTradeAccess(window),
eaNotice:(text,kind)=>sayEaNotice(window,text,kind),
cacheState:()=>{const state=poolCache.state()
return{...state,source:lastClubSource,hunger:poolHunger(state,{mirrorRows:clubMirror.count()})}},
frozen:frozenSolutions,warm:()=>sbcWarm.state(),lockGeneration:()=>lockWrites,
refreshCache:()=>{forceNextClubRead=true
return Promise.all([poolCache.refresh(),activeSquadCache.refresh()])},
deadLocks:()=>recreatedLockRows(),
onSubmitted:(ids)=>{poolCache.forget(ids)
frozenSolutions.invalidate(ids,'submitted')
clubMirror.removed(ids)
try{const live=clubMemory.stats()
if(live!==null)clubMirror.noteOurChange(live)}catch(err){note(`club mirror: ${err?.message??err}`)}
try{sbcStorage.eaten(ids)}catch(err){note(`storage: ${err?.message??err}`)}},isLocked:(id)=>isCardLocked(cardLockProvider,id),setLock:writeCardLock,onError:(err)=>note(`sbc window: ${err?.message??err}`)})
storageEcho.countChanged=()=>sbcWindow.storageChanged()
const sbcStrip=createSbcStrip({doc:document,t,coins:formatCoins,isActive:settings.isActive,
frozen:frozenSolutions,floatRating:squadRatingFloatEnabled(window),
onError:(err)=>note(`sbc strip: ${err?.message??err}`)})
const sbcSurface=withStrip(sbcWindow,sbcStrip)
const warmSolve=async(challenge,set,pause)=>{const pool=poolCache.peek()
const club=Array.isArray(pool?.players)?pool.players:null
if(club===null||club.length===0)return{ok:false,prepared:null,notice:{key:'sbc.loadFailed',params:{reason:'no-club'}}}
const prices=ladderSnapshot
if(prices===null)return{ok:false,prepared:null,notice:{key:'sbc.loadFailed',params:{reason:'no-prices'}}}
if(storageFailed(cardLockProvider))return{ok:false,prepared:null,notice:{key:'sbc.locksUnreadable'}}
if(!cardLockProvider.isLoaded())return{ok:false,prepared:null,notice:{key:'sbc.locksUnreadable'}}
const warmRecreated=recreatedLockNotice(recreatedLockRows())
if(warmRecreated!==null)return{ok:false,prepared:null,notice:warmRecreated}
const keepActive=uiState.solver().keepActiveSquad!==false
const activeIds=keepActive?activeSquadCache.peek():[]
const shieldStop=keepActive?warmShieldStop(activeIds):null
if(shieldStop!==null)return{ok:false,prepared:null,notice:shieldStop}
let protectedIds
let lockedIds
try{lockedIds=sanitizeCardLocks(cardLockProvider.read())
protectedIds=[...lockedIds,...activeIds]}catch(err){return{ok:false,prepared:null,notice:{key:'sbc.loadFailed',params:{reason:String(err?.message??err)}}}}
return prepareChallenge({club,poolRepeated:0,challenge,set,protectedIds,lockedIds,prices,ours:new Set,mode:'club',
openChallenges:openChallengesNow(),remembered:demandMemory.classes(),rememberedRatings:demandMemory.ratings(),
arrange:(positions,players)=>arrangeByPositions(window,positions,players),
pause:typeof pause==='function'?pause:null,onProgress:null,
floatRating:squadRatingFloatEnabled(window),cachedPriceOf:solvePriceOf(new Map),linkedTeam:linkedTeamNow,
timeBudgetMs:BACKGROUND_TIME_MS})}
const ladderWarm=createSbcLadderWarm({doc:document,win:window,
isActive:()=>settings.isActive(SBC_FEATURE),
ladders:(job)=>laddersFor(job),
openChallenges:openChallengesNow,
demand:demandMemory,
pool:poolCache,
clubPrices:async({pause,club})=>{let served=null
const got=await blobCache.serve(blobStamp,({pause:slice})=>clubBlobPrices(club,{pause:slice}),
{pause,onServe:(from)=>{served=from}})
poolPriceEye.note('прогрев',{built:got?.size??null,of:Array.isArray(club)?club.length:null,from:served})
return got},
onError:(err)=>note(`sbc ladder warm: ${err?.message??err}`)})
const sbcWarm=createSbcWarm({frozen:frozenSolutions,solve:warmSolve,doc:document,win:window,ladderWarm,
isActive:()=>settings.isActive(SBC_FEATURE),onError:(err)=>note(`sbc warm: ${err?.message??err}`)})
const storeGrid=createStoreGrid({doc:document,t,isActive:settings.isActive,isLocked:(key)=>isPackLocked(packProvider,key),
budget:offMarket(dayBudget),
isHidden:(key)=>isPackHidden(packProvider,key),setHidden:(key,on)=>setPackHidden(packProvider,key,on),
goHub:()=>goStoreHub(window),
show:(cards)=>packShow.verdict(cards),
ratingMin:()=>packShow.ratingMin(),
setLock:(key,on)=>{const done=setPackLock(packProvider,key,on)
if(done)panel.update()
return done},onError:(err)=>note(`store grid: ${err?.message??err}`)})
const previewMemory=createPreviewMemory({storage:{read:()=>bridge.request('preview.read'),write:(value)=>bridge.request('preview.write',value)},onError:(err)=>note(`preview memory: ${err?.message??err}`)})
const storeCatalog=createStoreCatalog({doc:document,t,formatCoins,isActive:settings.isActive,
view:()=>uiState.storeCatalogView(),
setView:(patch)=>{const res=uiState.setStoreCatalogView(patch)
if(!res.ok)note(`store catalog: ${res.reason}`)
return res},
isHidden:(key)=>isPackHidden(packProvider,key),setHidden:(key,on)=>setPackHidden(packProvider,key,on),
priceOf:badgePriceOf,memory:previewMemory,onError:(err)=>note(`store catalog: ${err?.message??err}`)})
void previewMemory.load().then(()=>storeCatalog.refresh()).catch((err)=>note(`preview memory: ${err?.message??err}`))
state.packPeek=createPackPeek({doc:document,win:window,t,isActive:settings.isActive,priceOf:badgePriceOf,formatCoins,onError:(err)=>note(`pack peek: ${err?.message??err}`)}).state
const pickPrices=createPickPrices({doc:document,t,isActive:settings.isActive,preselect:()=>uiState.pickPreselect(),priceOf:priceBadgeCoins,onError:(err)=>note(`pick prices: ${err?.message??err}`)})
const sbcPrices=createFutggSbc({fetch:createBridgeFetch(bridge,{timeoutMs:15_000}),
platform:()=>{try{return personas.pricePlatform()}catch{return null}},
onError:(err)=>note(`sbc prices: ${err?.message??err}`)})
const sbcTab=createSbcTab({doc:document,win:window,t,formatCoins,
isActive:settings.isActive,poolOf:()=>poolCache.peek(),
pricesOf:()=>ladderSnapshot,
rewardPriceOf:priceBadgeCoins,
hiddenSets:()=>uiState.sbcHidden(),
setHidden:(id,on)=>{const res=uiState.setSbcHidden(id,on)
if(!res.ok)note(`sbc tab: ${res.reason}`)
return res},
sbcView:()=>uiState.sbcView(),
setSbcView:(patch)=>{const res=uiState.setSbcView(patch)
if(!res.ok)note(`sbc tab: ${res.reason}`)
return res},
frame:idleFrame,sbcPrices,onError:(err)=>note(`sbc tab: ${err?.message??err}`)})
const sbcSet=createSbcSet({doc:document,t,formatCoins,isActive:settings.isActive,
challengeCoinsOf:(eaId)=>sbcPrices.peekChallenge(eaId),
rewardTextOf:(award)=>rewardTextOf(window,award),
view:()=>uiState.sbcSetView(),
setView:(patch)=>{const res=uiState.setSbcSetView(patch)
if(!res.ok)note(`sbc set: ${res.reason}`)
return res},
frame:paintFrame,onError:(err)=>note(`sbc set: ${err?.message??err}`)})
const packShow=createPackShow({isActive:settings.isActive,policy:()=>uiState.packShow(),onError:(err)=>note(`pack show: ${err?.message??err}`)})
const headRivals=createRivalsSource(window,{budget:offMarket(dayBudget)})
const headBar=createHeadBar({doc:document,win:window,t,isActive:settings.isActive,
searchHour:()=>dayBudget.state().hour,
searchDay:()=>dayBudget.state(),
sbcRate:()=>submitHook.state().rate,
rivals:headRivals,
license:()=>migrationProvider.state(),
onOpenPanel:()=>openSettingsWindow(),
view:()=>uiState.headView(),
setView:(patch)=>{const res=uiState.setHeadView(patch)
if(!res.ok)note(`head bar: ${res.reason}`)
return res},
now:()=>priceClock.now(),onError:(err)=>note(`head bar: ${err?.message??err}`)})
const huntLoot=createHuntLoot({market:marketOrNull,budget:()=>huntBudget,
sessionAt:()=>{let at=null
try{at=automation.status()?.session?.startedAt??null}catch{return null}
return sessionSince(at,sessionEpochBrokeAt)},
clubPile:ITEM_PILE.CLUB,onError:(err)=>note(`snipe loot: ${err?.message??err}`)})
const transfersHub=createTransfersHub({doc:document,t,formatNumber:(value)=>i18n.formatNumber(value),
isActive:settings.isActive,
onError:(err)=>note(`transfers hub: ${err?.message??err}`)})
const marketBotBar=createMarketBotBar({doc:document,win:window,t,formatNumber:(value)=>i18n.formatNumber(value),searchNames:createSearchNames(window),
isActive:settings.isActive,
hunt:automation,
criteria:()=>readLiveMarketCriteria(window),
showMinBid:(value)=>showSearchMinBid(window,value),
restoreMinBid:(mine)=>restoreSearchMinBid(window,mine),
showPair:(pair)=>showSearchPair(window,pair),
restorePair:(mine,seat)=>{const back=restoreSearchPair(window,mine,seat)
if(back?.ok===true)marketFilterMemory.noteWrite()
return back},
budget:()=>dayBudget.state(),
volume:()=>({minute:marketBudget.stats(),buys:buyRate.state()}),
unassigned:()=>({count:unassignedInCache(window)}),
clock:createClock(),
playerOf:(definitionId)=>playerEntryOf(window,definitionId),
book:()=>(ladderSnapshot===null?null:{ladder:ladderSnapshot.ladder,builtAt:ladderSnapshot.builtAt??null}),
pickRatingCard:(definitionId,cap,opts)=>{const put=restoreLiveMarketCriteria(window,{maskedDefId:definitionId,maxBuy:cap})
if(put?.ok!==true)return{ok:false,reason:put?.reason??'no-screen'}
marketFilterMemory.noteWrite()
if(opts?.search===false)return{ok:true,reason:'',searched:false}
const go=liveSearchButton(window)
if(go===null)return{ok:false,reason:'no-search-button'}
if(!pressNode(go,window,(err)=>note(`rating search: ${err?.message??err}`))){
return{ok:false,reason:'press-refused'}}
return{ok:true,reason:'',searched:true}},
filters:()=>filterStore.list(),
applySet:(id)=>{const res=applyFilter(id,filterDeps)
liveEvidence.record('filter.apply',res)
return res},
saveSet:(name)=>{const res=saveCurrentFilter(name,filterDeps)
liveEvidence.record('filter.save',res)
return res},
loot:()=>huntLoot.loot(),
runMemory:()=>(uiProvider?.isLoaded?.()===false?null:{lastRun:uiState.marketBot().lastRun}),
setRunMemory:(patch)=>{const res=uiState.setMarketBot(patch)
if(!res.ok)note(`market bot memory: ${res.reason}`)
return res},
onError:(err)=>note(`market bot: ${err?.message??err}`)})
const marketFilterMemory=createMarketFilterMemory({doc:document,
screen:(node)=>node?.querySelector?.(SEARCH_SCREEN_ROOT)??null,
live:()=>readMarketFilterCriteria(window),
defaults:()=>readLiveMarketDefaults(window),
restore:(criteria)=>restoreLiveMarketCriteria(window,criteria),
searched:()=>readUserCriteria(window)?.criteria??null,
memory:()=>(uiProvider?.isLoaded?.()===false?null:{criteria:uiState.marketFilter().criteria}),
setMemory:(patch)=>{const res=uiState.setMarketFilter(patch)
if(!res.ok)note(`market filter memory: ${res.reason}`)
return res},
onError:(err)=>note(`market filter: ${err?.message??err}`)})
marketBotAim=marketBotBar
const mountWiring=()=>wirePage({doc:document,win:window,t,isActive:settings.isActive,clock:createClock(),market:marketOrNull,criteria:()=>readUserCriteria(window)?.criteria??null,personas,marketSearchQuick,marketBotBar,marketFilterMemory,sellSidebar,cardLockMark,lockBadges,squadBar,squadPick,frozenMarks,cardGrid,dealPanel,clubBar,sbcStorage,transfersHub,headBar,sbcWindow:sbcSurface,sbcTab,sbcSet,sbcWarm,ladderWarm,storeGrid,storeCatalog,pickPrices,packShow,submitHook,workArea,marketBudget,
snipeKey,badgePriceOf,
dayBudget,
itemPool:poolCache,
clubMirror,clubItemById:(id)=>clubMemory.item(id),
poolPeek:()=>poolCache.peek(),frame:idleFrame,
linkedTeam:linkedTeamNow,
noteCard:learnItem,
isBlocked:()=>panel.dialogs.isOpen()||ourWindowOpen(document),legacyItemSurfaces:false,
railPacksMemory:{read:()=>uiState.railPacks(),write:(list)=>uiState.setRailPacks(list)},
relistPricing:{read:()=>uiState.relist(),write:(patch)=>{const res=uiState.setRelist(patch)
if(!res.ok)note(`relist pricing: ${res.reason}`)
return res}},
isCardLocked:(id)=>isCardLocked(cardLockProvider,id),
noteRecreatedLocks:(ids)=>{const marked=noteCardsRecreated(cardLockProvider,ids,(ok)=>{if(ok!==true)lockWriteFailed()})
if(marked>0){lockWrites+=1
try{sbcWindow?.refresh?.()}catch(err){note(`card lock: ${err?.message??err}`)}}
return marked},
expensiveFrom:()=>uiState.unassignedThreshold(),
setExpensiveFrom:(value)=>{const res=uiState.setUnassignedThreshold(value)
if(!res.ok)note(`unassigned threshold: ${res.reason}`)
panel.update()
return res},
unassignedView:()=>uiState.unassignedView(),
setUnassignedView:(patch)=>{const res=uiState.setUnassignedView(patch)
if(!res.ok)note(`unassigned view: ${res.reason}`)
return res},
cardView:()=>uiState.cardView(),
setCardView:(next)=>{const res=uiState.setCardView(next)
if(!res.ok)note(`card view: ${res.reason}`)
return res},
hotkeyState:()=>uiState.hotkeyState(),
saveHotkeyState:(next)=>{const res=uiState.setHotkeyState(next)
if(!res.ok)note(`hotkeys save: ${res.reason}`)
panel.update()},
focusedPlayer:()=>selectedPlayer,
criteriaOfCard:criteriaForCard,
measureMarket:sellMarketEvidence,
askConfirm:(opts)=>panel.dialogs.confirm(opts),
goSection:goEaSection,
onSelectedPlayer:(value)=>{
const id=Number.isSafeInteger(value?.definitionId)?value.definitionId:null
selectedPlayer={name:value.name,definitionId:id}
panel.update()},onNotice:(value)=>{notice=value;panel.update()},onError:(err)=>note(`wiring: ${err?.message ?? err}`)});
wiring=mountWiring()
wiringMounted=true
phases.mark('wiring')
const dropdownSearch=createDropdownSearch({doc:document,win:window,t,isActive:settings.isActive,onError:(err)=>note(`dropdown search: ${err?.message??err}`)})
dropdownSearch.mount()
let autologinResult=null;
void wiring.autologin.then((result)=>{autologinResult=result;
liveEvidence.record('autologin',result,{attempts:result?.attempts??null})
phases.mark('autologin',{reason:result?.reason??null,pressed:result?.landing?.pressed===true,pressedAt:result?.landing?.pressedAt??null,seenAt:result?.landing?.seenAt??null})
sessionEpochPoll()});
const sessionEpochStops=[
{name:'buyer',act(){return stopRunning(automation)}},
{name:'seller',act(){return stopRunning(seller)}},
{name:'sbc-warm',act(){return stopQueue(sbcWarm,'session-epoch')}},
{name:'ladder-warm',act(){return stopQueue(ladderWarm,'session-epoch')}},
{name:'price-queue',act(){return livePrices.cancel('session-epoch')}},
{name:'sbc-window',act(){return sbcWindow.sessionEpoch.stop()}}]
const sessionEpochForgets=[
{name:'club-pool',act(){return poolCache.markStale('session-epoch')===true}},
{name:'sbc-window',act(){return sbcWindow.sessionEpoch.forget()}},
{name:'frozen',act(){const had=(frozenSolutions.state()?.size??0)>0
frozenSolutions.clear()
return had}},
{name:'submit-ticket',act(){const armed=submitHook.state()?.ticketArmed===true
submitHook.detach()
return armed}},
{name:'selected-player',act(){if(selectedPlayer===null)return false
selectedPlayer=null
return true}},
{name:'live-prices',act(){return livePrices.forget('session-epoch')}},
{name:'active-squad',act(){return activeSquadCache.forget()}},
{name:'sbc-scroll-park',act(){return sbcTab.forgetParked()}},
{name:'market-bot-log',act(event){return marketBotBar.forget(event)===true}},
{name:'market-filter-memory',act(event){return marketFilterMemory.forget(event)===true}}]
const sessionEpochWork={events:0,stopped:0,forgot:0,acts:Object.create(null),failed:0}
const sessionEpochRun=(list,event)=>{let acted=0
for(const one of list){let did=false
try{did=one.act(event)===true}catch(err){sessionEpochWork.failed+=1
note(`session epoch ${one.name}: ${err?.message ?? err}`)}
if(!did)continue
acted+=1
sessionEpochWork.acts[one.name]=(sessionEpochWork.acts[one.name]??0)+1}
return acted}
sessionEpoch.subscribe((event)=>{
sessionEpochBrokeAt=Number.isFinite(event?.at)?event.at:clock.now()
sessionEpochWork.events+=1
const stopped=sessionEpochRun(sessionEpochStops,event)
const forgot=sessionEpochRun(sessionEpochForgets,event)
sessionEpochWork.stopped+=stopped
sessionEpochWork.forgot+=forgot
liveEvidence.record('sessionEpoch',{ok:true,reason:event?.reason??null},{epoch:event?.epoch??null,stopped,forgot})
phases.mark('session-epoch',{epoch:event?.epoch??null,reason:event?.reason??null,stopped,forgot})
if(stopped>0)notice={key:'session.epochStopped',params:{}}
panel.update()})
const SESSION_EPOCH_POLL_MS=2000
void(async()=>{for(;;){sessionEpochPoll()
await clock.sleep(SESSION_EPOCH_POLL_MS)}})()
applyDayX=(off)=>{if(off===!wiringMounted)return{ok:true,reason:null}
if(off){try{wiring?.dispose?.()}catch(err){note(`day-x dispose: ${err?.message??err}`)
}
try{dropdownSearch.dispose()}catch(err){note(`day-x dropdown: ${err?.message??err}`)}
wiringMounted=false
return{ok:true,reason:null}}
try{wiring=mountWiring()
dropdownSearch.mount()
wiringMounted=true
return{ok:true,reason:null}}catch(err){note(`day-x remount: ${err?.message??err}`)
return{ok:false,reason:'remount-failed'}}}
if(uiState.isDayXOff())applyDayX(true)
const bootSplash=createBootSplash({doc:document,win:window,t,onError:(err)=>note(`boot splash: ${err?.message??err}`)});
const bootState={waitMs:null,ticks:0,ready:false,club:null,cards:null,readMs:null,warmMs:null,reason:null,done:false,splashSeen:false,attempts:0,lastError:null,lastReason:null};
const BOOT_READ_ATTEMPTS=3;
const BOOT_RETRY_MS=Object.freeze([1500,3500]);
const SPLASH_DWELL_MS=2500;
const SPLASH_DWELL_FAIL_MS=6000;
const WARM_START_CAP_MS=60_000
function waitForCondition(test,capMs=WARM_START_CAP_MS){return new Promise((resolve)=>{const started=clock.now()
let ticks=0
const step=()=>{ticks+=1
let ok=false
try{ok=test()===true}catch{ok=false}
const spent=clock.now()-started
if(ok){resolve({ok:true,ticks,ms:spent})
return}
if(spent>=capMs){resolve({ok:false,ticks,ms:spent})
return}
idleFrame(step)}
idleFrame(step)})}
function warmPrices(){return new Promise((resolve)=>{idleFrame(()=>{const started=clock.now()
Promise.resolve()
.then(()=>priceLadder.read())
.then(async(base)=>{const rarityLadders=await rarityLaddersNow()
noteLadderSnapshot(base===null?null:{...base,rarityLadders,rarityGroups:groupBook.dictionary()})
return rarityLadders})
.then(()=>resolve({ok:true,ms:clock.now()-started}))
.catch((err)=>{note(`warm prices: ${err?.message??err}`)
resolve({ok:false,ms:clock.now()-started})})})})}
async function warmStart(){
bootSplash.ensure()
bootSplash.hold()
bootSplash.say('boot.waiting')
const waited=await waitForCondition(()=>{bootSplash.ensure()
return clubOrNull()?.ready?.()===true&&personas.selectedPersona()!==null&&bootSplash.nativeReady()===true})
bootState.ticks=waited.ticks
bootState.waitMs=waited.ms
bootState.ready=waited.ok
if(!waited.ok){bootState.reason='ea-not-ready'
bootSplash.say('boot.skipped',{reason:'EA'})
bootState.done=true
return bootState}
bootState.splashSeen=bootSplash.say('boot.reading')
const started=clock.now()
let pool=null
for(let attempt=0;attempt<BOOT_READ_ATTEMPTS;attempt+=1){bootState.attempts=attempt+1
try{pool=await poolCache.read()
break}catch(err){bootState.lastError=String(err?.message??err)
bootState.lastReason=typeof err?.reason==='string'?err.reason:null
hint(`warm start (попытка ${attempt+1} из ${BOOT_READ_ATTEMPTS}): ${err?.message??err}`)
if(bootState.lastReason==='day-limit')break
if(attempt+1>=BOOT_READ_ATTEMPTS)break
await clock.sleep(BOOT_RETRY_MS[attempt]??3500)}}
if(pool===null){bootState.reason='read-failed'
bootSplash.say('boot.failed')
bootState.done=true
await clock.sleep(SPLASH_DWELL_FAIL_MS)
bootSplash.hide()
return bootState}
bootState.readMs=clock.now()-started
bootState.cards=pool.items.length
bootState.club=lastClubSource
const warm=await warmPrices()
bootState.warmMs=warm.ms
bootSplash.say('boot.ready',{count:bootState.cards??0})
bootState.done=true
await clock.sleep(SPLASH_DWELL_MS)
phases.mark('warm',{cards:bootState.cards,readMs:bootState.readMs,warmMs:bootState.warmMs,reason:bootState.reason})
bootSplash.hide()
return bootState}
void warmStart().catch((err)=>note(`warm start: ${err?.message??err}`));
state.hotkeys=()=>wiring.hotkeys.bindings();
state.autologin=()=>wiring.autologin;
state.dayX=()=>{const seen=eaRequestState()
return `рычаг: ${uiState.isDayXOff()?'ВКЛ (наше отключено)':'выкл'} · вставки: ${wiringMounted?'стоят':'сняты'}`
+` · порт: ${seen.port?'стоит':'НЕТ'} · запросов ушло ${seen.passed}`
+` · отказано до вызова ${seen.refusedBeforeCall} · после вызова ${seen.refusedAfterCall}`
+` · порт бросил ${seen.portErrors}`};
state.cloud=()=>cloudDesk.state();
state.cloudWatch=async()=>({сборка:PANEL_BUILD,...await cloudDesk.diag()});
state.cloudPush=()=>cloudDesk.pushNow();
state.plan=()=>licensing.plan();
state.license=()=>migrationProvider.state();
state.account=()=>{const probe=migrationProvider.probe();
return{build:probe.build,source:probe.source,until:chipScale({unlocked:probe.source!=='none',exp:probe.exp}).until}};
state.settings=()=>settings.all();
state.setToggle=(feature,value)=>settings.set(String(feature),value===true);
state.uiLocale=()=>i18n.locale;
state.filters=()=>filterStore.list();
state.automation=()=>automation.status();
state.seller=()=>seller.status();
state.snipeClock=()=>automation.raceTimes();
state.parity=()=>({сборка:state.version,
'страница':WIDE_PAGE_LOTS,
'страница_сейчас':marketPageSetting(window),
'темп':`${DEFAULT_SEARCH_BAND_MS.minMs}..${DEFAULT_SEARCH_BAND_MS.maxMs}`,
'пол_темпа':SAFE_PAUSE_FLOOR_MS,
'минутная_очередь':BUDGET_LIMIT,
'телеметрия':marketSearchPageViews(window)!==null,
'куча_по_событию':typeof window?.getDefaultDispatcher==='function'||appMain(window)?.getDefaultDispatcher!==undefined,
'кольцо':{'режим':searchRefreshOf(automation.status()?.options?.[SEARCH_REFRESH_KEY]),
'micr_от':MIN_BID_FLOOR,'micr_шаг':MIN_BID_STEP,'micr_до':MIN_BID_TOP,
'macr_от':BID_REFRESH_TOP,
'minb_от':MIN_BUY_FLOOR,'minb_шаг':MIN_BUY_STEP,'minb_до':MIN_BUY_TOP,
'minb_доля_цели_%':MIN_BUY_AIM_SHARE,'micr_в_паре_до':PAIR_MIN_BID_TOP,
'пар_в_круге':pairRing(Number(readUserCriteria(window)?.criteria?.maxBuy)||0).length},
'куча':automation.status()?.filter?.pile??null});
state.snipeRun=()=>{const said=automation.status();
const filter=said?.filter??{};
return{'поисков':said?.stats?.searches??0,
'ответов':filter.answers??null,
'лотов_последняя_выдача':filter.lastLots??null,
'полных_страниц':filter.pageFulls??null,
pageFulls:filter.pageFulls??null,
'куплено':said?.stats?.purchases??0,
'гонок_проиграно':filter.racesLost??0,
'не_успели':filter.misses??0,
'причина_остановки':said?.reason??null};};
state.journal=()=>journal.view();
state.ledger=()=>({session:ledger.session(),allTime:ledger.allTime()});
state.head=()=>headCountersLine({search:dayBudget.state().hour,sbc:submitHook.state().rate,profit:ledger.allTime().today});
state.doors=()=>{const report=doors(window)
const rows=report.found.map((row)=>`${row.name}: найдена (${row.source}, ${row.ms} мс)`)
for(const name of report.pending)rows.push(`${name}: ЖДЁМ — EA ещё не показала`)
if(rows.length===0)rows.push('ни одной двери ещё не спрашивали')
rows.push(report.hooked?'наш код в методах EA: стоит, пока ждём двери':'наш код в методах EA: снят')
return rows.join(String.fromCharCode(10))};
state.requests=()=>dayBudget.state().line;
state.bridgeCheck=()=>checkBridge(bridge);
state.snipeCriteria=()=>marketSearchQuick.state();
state.openSettings=(id)=>settingsDoor.goTo(id);
state.settingsSection=()=>settingsDoor.section();
state.guard=()=>{const hook=submitHook.state()
const doors=Object.entries(hook.doors??{}).map(([name,door])=>`${name}:${door?.identified===true?'ок':'нет'}`).join(' ')
const active=activeSquadCache.state()
const blocked=hook.lastBlock===null?'нет':`${hook.lastBlock.reason} (испытание ${hook.lastBlock.challenge})`
return[`замок сдачи: ${hook.ok===true?'стоит':`НЕТ (${hook.reason})`} · политика: ${hook.policy} · проводка: щит ${hook.wired?.shield===true?'ок':'НЕТ'}, свежесть ${hook.wired?.fresh===true?'ок':'НЕТ'}`,
`двери: ${doors===''?'не смотрели':doors} · следим за испытанием: ${hook.watching===true?'да':'нет'}`,
`клики: остановлено ${hook.gestures.stopped}, пропущено ${hook.gestures.passed}, судья не ответил ${hook.gestures.faults} раз · вопрос: ${hook.armed.length===0?'нет':hook.armed.join(', ')} · билет: ${hook.ticket===true?'есть':'нет'} · родное продолжение: ${hook.continuation===null?'нет':hook.continuation.armed===true?'вооружено':'ждёт ответа EA'}`,
`коридор: заблокировано ${hook.corridor.blocked}, прошло ${hook.corridor.passed}, ошибок ${hook.corridor.errors} · последний блок: ${blocked}`,
`активный щит: ${active.loaded?`${active.size} карт`:'не прочитан'} · чтений ${active.reads}, поколение ${active.generation} · мёртвых замков: ${recreatedLockIds().length}`].join(String.fromCharCode(10))};
state.headBar=()=>headBar.state();
state.sell=()=>sellSidebar.state();
state.locks=()=>({...cardLockMark.state(),writeFailed:lockFailure,captures:wiring?.captures?.()??null});
state.lockBadges=()=>({...lockBadges.state(),captures:wiring?.captures?.()??null});
state.squadBar=()=>({...squadBar.state(),captures:wiring?.captures?.()??null});
state.squadPick=()=>({...squadPick.state(),captures:wiring?.captures?.()??null});
state.frozen=()=>({...frozenMarks.state(),storage:String(cardFrozenProvider?.status?.()??'')});
state.cardGrid=()=>cardGrid.state();
state.dealPanel=()=>dealPanel.state();
state.clubBar=()=>clubBar.state();
state.snipe=()=>transfersHub.state();
state.snipeLoot=()=>huntLoot.state();
state.marketBot=()=>marketBotBar.state();
state.marketFilter=()=>marketFilterMemory.state();
state.storeGrid=()=>({...storeGrid.state(),captures:wiring?.captures?.()??null});
state.storeCatalog=()=>({...storeCatalog.state(),captures:wiring?.captures?.()??null});
state.pickPrices=()=>({...pickPrices.state(),captures:wiring?.captures?.()??null});
state.sbcTab=(opts)=>({...(wiring?.sbcTab?.(opts)??{}),ladderSnapshot:ladderSnapshot===null?null:{steps:ladderSnapshot.ladder.length,builtAt:ladderSnapshot.builtAt??null},captures:wiring?.captures?.()??null});
state.sbcSet=()=>{const own=wiring?.sbcSet?.()??{}
const prices=sbcPrices.state()
const captures=wiring?.captures?.()??null
const say=own.screen===null||own.screen===undefined
?'экрана набора сейчас нет'
:`набор ${own.screen.set} | плиток ${own.screen.rows} | в ряд ${own.screen.columns} | с ценой ${own.priced} | нет у FUT.GG ${own.unknown} | без решения ${own.noSolution} | источника нет ${own.noSource}`
let leftover=null
try{leftover=document.querySelectorAll('[data-fut-sbc-set-wide]').length}catch{leftover=null}
const line=`${say} | цен испытаний в памяти ${prices.challengePrices} | запросов ${prices.requests} | возраст копии ${prices.ageMs===null?'нет':Math.round(prices.ageMs/1000)+' с'} | рынок ${prices.platform??'не выбран'} | шов ${captures?.sbcSet===true?'стоит':'НЕТ ('+(captures?.sbcSetReason??'?')+')'} | раскрыто узлов ${leftover===null?'?':leftover}${Array.isArray(own.wideNames)&&own.wideNames.length>0?' ('+own.wideNames.join(', ')+')':''}`
return{...own,prices,captures,leftover,line}};
state.packShow=()=>({...packShow.state(),captures:wiring?.captures?.()??null});
state.rewardFlow=()=>wiring?.rewardFlow?.()??null;
state.storage=()=>wiring?.storage?.()??null;
state.hubRewards=()=>wiring?.hubRewards?.()??null;
state.railPacks=()=>wiring?.railPacks?.()??null;
state.headTop=()=>wiring?.headTop?.()??null;
state.promoClose=()=>wiring?.promoClose?.()??null;
state.homeGrid=()=>wiring?.homeGrid?.()??null;
state.dropdownSearch=()=>{try{return dropdownSearch.state()}catch{return null}};
const phaseSince=(list)=>{const base=list.length>0?list[0].at:0
return list.map((one)=>({...one,sinceMs:Math.max(0,Math.round(one.at-base))}))};
const phaseLine=(list)=>(list.length===0?'—':list.map((one)=>`${one.phase}@${one.sinceMs} мс`).join(' > '));
state.phases=()=>{const now=phaseSince(phases.list());
const previous=phaseSince(phases.previous());
return{now,previous,state:phases.state(),line:phaseLine(now),previousLine:phaseLine(previous)}};
state.sessionEpoch=(opts)=>{
if(opts?.ask===true)sessionEpochPoll()
return{...sessionEpoch.state(),brokeAt:sessionEpochBrokeAt,
work:{...sessionEpochWork,acts:{...sessionEpochWork.acts}},
subscribers:{stops:sessionEpochStops.map((one)=>one.name),forgets:sessionEpochForgets.map((one)=>one.name)}}};
state.unassigned=()=>wiring?.unassigned?.()??null;
state.unsort=()=>{const strip=wiring?.unassigned?.()?.strip ?? null;
if(!strip)return null;
return{rules:strip.rules,plan:strip.brain,ran:strip.ran,catalog:strip.catalog,armed:strip.armed}};
state.badges=()=>priceBadgeState(document);
state.catalog=()=>{const own=catalog.state();
const base=cardBase.state();
const bytes=base?.worker?.storageBytes ?? null;
return{...own,base,storageBytes:bytes,
line:'карт '+own.size
+' · рейтинг '+own.rated
+' · нация '+own.knownNation
+' · лига '+own.knownLeague
+' · клуб '+own.knownTeam
+' · редкость '+own.knownRarity
+' · база '+(base?.seeded?('сезон '+base.seeded.game+', карт '+(base.seeded.cards??'?')+', собрана '+(base.seeded.builtAt??'?')
+(base.seeded.complete===false?' (СОБРАНА НЕ ЦЕЛИКОМ)':'')):'нет')
+' · в этом сеансе: из базы '+own.base+', живьём '+own.live
+' · ответ '+(base?.status??'—')+(base?.reason?(' ('+base.reason+')'):'')
+' · хранилище '+(bytes===null?'?':(Math.round(bytes/1024)+' КБ'))}};
state.purchases=()=>purchaseLogState();
state.club=()=>({...clubMirror.state(),boot:{...bootState},decision:clubDecision===null?null:{...clubDecision,counts:{...clubWhy}},splash:bootSplash.state()});
state.rarityLadders=()=>rarityLaddersNow();
state.priceProbe=async()=>{const prices=livePrices.applyTo({...(await priceLadder.read()),rarityLadders:await rarityLaddersNow()})
const queue=probeQueueFrom(prices)
return{queue,run:await livePrices.run(queue,{type:'player'}),live:livePrices.state(),budget:marketBudget.stats()}};
state.priceLag=async(count)=>lagReport(await priceLadder.read(),{measure:(id,hint)=>marketEvidenceOfItem({definitionId:id},hint),count});
state.priceBand=async(count,minPrice)=>{const out=await lagReport(await priceLadder.read(),{measure:(id,hint)=>marketEvidenceOfItem({definitionId:id},hint),
waitMs:(id)=>marketPrice.waitMs(marketCacheKey(id)),sleep:(ms)=>new Promise((done)=>{window.setTimeout(done,ms)}),
count:Number.isSafeInteger(count)&&count>0?count:12,
...(Number.isFinite(minPrice)&&minPrice>0?{minPrice}:{})});
const minuteNow=marketBudget.stats();
const line=(row)=>`${row.rating} #${row.id} R=${row.blob??'—'} L=${row.live??'—'} `
+`L−R=${Number.isFinite(row.gap)?(row.gap>0?`+${row.gap}`:row.gap):'—'} `
+`допуск=${row.allow??'—'} ${row.within===true?'внутри':(row.within===false?'ВЫШЕ':row.reason??'нет цены')}`;
return`ПОЛОСА L−R (${out.measured} карт с живым лотом из ${out.rows.length} спрошенных)\n`
+`${out.rows.map(line).join('\n')}\n`
+`итог: внутри допуска ${out.within} из ${out.measured}; `
+`середина L−R ${out.medianGap??'—'}; худшая ${out.worstGap??'—'} (${out.worstPct??'—'} %); `
+`отставание блоба (медиана) ${out.median??'—'} %\n`
+`ждали ритма ${Math.round((out.waitedMs??0)/1000)} с; встали на: ${out.stoppedBy??'нет'}; `
+`минутный бюджет ${minuteNow.spent}/${minuteNow.limit}\n`
+`улики отказов: ${livePrices.state().details.join(' | ')||'нет'}`};
state.sbc=()=>{const shown=sbcWindow.state()
return{...shown,
pool:shown?.pool&&typeof shown.pool==='object'
?{...shown.pool,cover:poolPriceWatch(shown.pool,{by:poolPriceEye.last()})}
:shown?.pool??null,
poolPriceEye:poolPriceEye.state(),
strip:sbcStrip.state(),active:activeSquadCache.state(),prices:solveReader.state(),prep:blobCache.state(),groups:groupBook.state(),demand:demandReport(),demandMemory:demandMemory.state(),probe:livePrices.state(),budget:marketBudget.stats(),
hour:buyRate.state(),
priceMarket:{blob:personas.pricePlatform(),published:futggSource.publishedAt(),sku:(()=>{try{return personas.selectedPersona()?.sku??null}catch{return null}})(),
ladder:{generation:priceLadder.generation()}},
workArea:workArea.state(),
recreated:recreatedLockIds(),
captures:wiring?.captures?.()??null}};
state.sbcExplain=()=>{if(lastSolve===null)return{ok:false,reason:'no-solve',hint:'зайди на испытание и дождись подбора'}
const requirements=parseRequirements(lastSolve.challenge?.eligibilityRequirements).requirements
let valuation=null
const explainClub=poolCache.peek()?.players??[]
try{valuation=valuationFrom({prices:lastSolve.prices,requirements,club:explainClub,available:searchableNow(explainClub),
openChallenges:openChallengesNow(),remembered:demandMemory.classes(),rememberedRatings:demandMemory.ratings()})}catch(err){note(`sbc explain: ценность не собралась (${err?.message??err})`)}
return explainSolve({answer:lastSolve.answer,prices:lastSolve.prices,valuation,requirements,
openChallenges:openChallengesNow(),challenge:lastSolve.challenge?.id??null,at:lastSolve.at,
mode:lastSolve.mode,priceOf:cachedPriceOfItem,liveOf:(id)=>livePrices.priceOf(id),
blobAgeMs:futggSource.publishedAt()?.ageMs??null})};
const saveJsonFile=(name,text)=>{try{const url=URL.createObjectURL(new Blob([text],{type:'application/json'}))
const link=document.createElement('a')
link.href=url
link.download=name
link.style.display='none'
document.body.appendChild(link)
link.click()
link.remove()
setTimeout(()=>{try{URL.revokeObjectURL(url)}catch{/* уже снят */}},60000)
return true}catch(err){note(`sbc dump: файл не сохранился (${err?.message??err})`)
return false}};
state.sbcDump=(opts)=>{if(lastSolve===null)return{ok:false,reason:'no-solve',hint:'зайди на испытание и дождись подбора'}
const raw=Array.isArray(lastSolve.challenge?.eligibilityRequirements)?lastSolve.challenge.eligibilityRequirements:[]
const requirements=parseRequirements(raw).requirements
const dumpClub=poolCache.peek()?.players??[]
let valuation=null
try{valuation=valuationFrom({prices:lastSolve.prices,requirements,club:dumpClub,available:searchableNow(dumpClub),
openChallenges:openChallengesNow(),remembered:demandMemory.classes(),rememberedRatings:demandMemory.ratings()})}catch(err){note(`sbc dump: ценность не собралась (${err?.message??err})`)}
const shownBurn=lastSolve.answer?.burn
const poolFacts=(()=>{try{const said=poolCache.state()
const by={...lastRefusedBy}
return{sources:{club:said?.sources?.club??null,storage:said?.sources?.storage??null},
refused:{total:Number.isFinite(said?.refused)?said.refused:null,
read:by.loan+by.concept+by.academy,by}}}catch(err){note(`sbc dump: пул не отчитался (${err?.message??err})`)
return{sources:null,refused:null}}})()
const dump=dumpSolve({challenge:lastSolve.challenge,requirements:raw,prices:lastSolve.prices,valuation,
sources:poolFacts.sources,refused:poolFacts.refused,
club:dumpClub,mode:lastSolve.mode,at:lastSolve.at,priceOf:lastSolve.priceOf??cachedPriceOfItem,limit:opts?.limit,
atDump:clock.now(),
shownTotal:columnTotal(shownBurn&&typeof shownBurn==='object'?{cost:shownBurn.cost,spend:lastSolve.answer?.spend}:null),
ladder:lastSolve.ladder??null,
buy:(()=>{if(typeof lastSolve.buy!=='function')return null
try{return lastSolve.buy()}catch(err){note(`sbc dump: кнопка не прочиталась (${err?.message??err})`)
return null}})(),
rebuilds:lastSolve.rebuilds??null,
priceAges:lastSolve.priceAges??null,
phases:(()=>{const said=solvePhases.state()
return said?.last===null||said?.last===undefined?null:{...said.last,running:said.running===true}})(),
answer:lastSolve.answer,
run:{maxSpend:null,budget:lastSolve.answer?.search?.budget??null,slice:lastSolve.answer?.search?.slice??null,
timeBudgetMs:lastSolve.timeBudgetMs??null,
evaluations:lastSolve.answer?.search?.evaluations??null,size:lastSolve.answer?.prepared?.selection?.length??null,
pool:lastSolve.answer?.pool??null,light:lastSolve.answer?.search?.light??null}})
const name=`sbc-dump-${dump.challenge?.id??'x'}-${new Date(Number.isFinite(dump.at)?dump.at:clock.now()).toISOString().slice(0,16).replace(/[:T]/g,'-')}.json`
const out={...dump,saved:saveJsonFile(name,dump.json)?name:null,copied:null,
hint:'файл в загрузках браузера; если файла нет — работает copy(__eshario.sbcDump().json)'}
try{const asked=navigator?.clipboard?.writeText?.(out.json)
if(asked&&typeof asked.then==='function')asked.then(()=>{out.copied=true},(err)=>{out.copied=false
note(`sbc dump: буфер отказал (${err?.message??err}); бери файл или copy(...json)`)})
else out.copied=false}catch(err){out.copied=false
note(`sbc dump: буфер недоступен (${err?.message??err}); бери файл или copy(...json)`)}
return out};
state.cardMatch=()=>{try{return cardMatchProbe(document)}catch(err){return{ok:false,reason:String(err?.message??err)}}}
state.cardWorth=(ratings,count)=>{if(lastSolve===null)return{ok:false,reason:'no-solve',hint:'зайди на испытание и дождись подбора'}
const requirements=parseRequirements(lastSolve.challenge?.eligibilityRequirements).requirements
const club=poolCache.peek()?.players??[]
let valuation=null
try{valuation=valuationFrom({prices:lastSolve.prices,requirements,club,available:searchableNow(club),
openChallenges:openChallengesNow(),remembered:demandMemory.classes(),rememberedRatings:demandMemory.ratings()})}catch(err){note(`sbc worth: ценность не собралась (${err?.message??err})`)}
const mineIds=new Set((Array.isArray(lastSolve.answer?.mine)?lastSolve.answer.mine:[]).map(String))
let kept=null
try{kept=poolForSearch(club,club.filter((one)=>mineIds.has(String(one?.id??'')))).map((one)=>String(one?.id??''))}catch(err){note(`sbc worth: копии не разобраны (${err?.message??err})`)}
return clubWorth({club,valuation,ratings,count,priceOf:cachedPriceOfItem,answer:lastSolve.answer,
isLocked:(id)=>isCardLocked(cardLockProvider,id),activeIds:activeSquadCache.peek()??[],
keptIds:kept,keyOf:cardResourceKey,nameOf:(card)=>cardLabel(card,card?.id)})};
state.priceLadder=(opts)=>priceLadder.read(opts);
state.priceTrap=()=>({...priceTrap.state(),log:priceTrap.log(),
quarantine:{...priceQuarantine.state(),held:priceQuarantine.list()}});
state.priceTruth=async(id)=>{const key=priceKeyOf(id)
if(key===null)return{ok:false,reason:'bad-id',hint:'нужен id определения EA, а платформа — опознанная'}
const told=await futggSource(key)
const raw=futggSource.rawWindow(key)
return{ok:true,id,key,ours:told.price,reason:told.reason,
slot:raw?.slot??null,raw:(raw?.window??[]).find((row)=>row.slot===raw?.slot)??null,
window:raw?.window??[],lengths:raw?.lengths??null,file:raw?.file??null,
published:futggSource.publishedAt()}};
const currentEvidence=()=>buildLiveEvidence({now:clock.now(),bridge:state.bridge,version:state.version,panel:state.panel,errors:state.errors,origin:window.location?.origin,settings:settings.all(),dom:domEvidence(document,panel.host),buyer:automation.status(),seller:seller.status(),club:clubState,autologin:autologinResult,events:liveEvidence.list()});
state.evidence=currentEvidence;
const liveControl=createLiveControlSession({now:clock.now,provider:liveControlProvider,capture:currentEvidence});
state.control=Object.freeze({reset:()=>liveControl.reset(),capture:(check)=>liveControl.capture(check),status:()=>liveControl.status(),export:()=>liveControl.export()});
state.panel='mounted';
return panel}
start().catch((err)=>{state.bridge=`failed: ${err?.message ?? err}`;
note(err?.message??err)});
export{bridge};
