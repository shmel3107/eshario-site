export function createWaitNotice({name,now,record,out=globalThis.console,
prefix='[ESHArio]',
pending='ещё не поднялась, попробуем позже',
gone='так и не поднялась',
recordPending=true}){
const say=typeof record==='function'?record:()=>{}
const tick=typeof now==='function'?now:()=>0
let startedAt=null
let tries=0
let said=false
let closed=false
return{
waiting(detail){if(closed)return false
tries+=1
if(said)return false
said=true
startedAt=tick()
const message=`${name} (${pending}): ${detail}`
if(recordPending)say(message)
out.info(prefix,message)
return true},
arrived(){closed=true
return false},
lost({eaSeen=true,text=null}={}){if(closed)return false
closed=true
if(eaSeen!==true)return false
const ms=startedAt===null?0:tick()-startedAt
const message=typeof text==='string'&&text!==''
?text
:`${name}: ${gone} — попыток ${tries}, ждали ${ms} мс`
say(message)
out.warn(prefix,message)
return true},
state(){return{said,closed,tries,startedAt}}}}
