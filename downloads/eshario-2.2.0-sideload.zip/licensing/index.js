import{FEATURES,FREE,PREMIUM} from './features.js'
export function createStubProvider(opts={}){let premium=Boolean(opts.premium)
return{getPlan:()=>(premium?PREMIUM:FREE),
setPremium:(value)=>{premium=Boolean(value)}}}
export function combineProviders(providers){const list=(providers??[]).filter((p)=>p&&typeof p.getPlan==='function')
return{getPlan(){for(const provider of list){try{if(provider.getPlan()===PREMIUM)return PREMIUM}catch{
}}
return FREE}}}
export function createLicensing(opts={}){const provider=opts.provider??createStubProvider()
const registry=opts.registry??FEATURES
function plan(){try{const value=provider.getPlan()
return value===PREMIUM?PREMIUM:FREE}catch{
return FREE}}
function isEnabled(feature){
if(typeof feature!=='string'||!Object.hasOwn(registry,feature)) return false
const meta=registry[feature]
if(!meta)return false
if(meta.tier===FREE)return true
return plan()===PREMIUM}
return{isEnabled,plan,
enabledFeatures:()=>Object.keys(registry).filter(isEnabled).sort(),
isKnown:(feature)=>Object.hasOwn(registry,feature)}}
