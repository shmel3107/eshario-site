import{FREE,PREMIUM} from './features.js'
import{parseLicenseKey,verifyLicenseKey} from './key.js'
import{ACCOUNT_KEYS} from './public-key.js'
export const ACCOUNT_STATUS='account.status'
export const ACCOUNT_OPEN='account.open'
export const ACCOUNT_BUILD='ACC6'
export const ACCOUNT_CACHE_MS=604800000
export const ACCOUNT_CLOCK_SKEW_MS=300000
const REASONS=new Set(['pending','not-configured','signed-out','inactive','network','unauthorized','invalid-entitlement'])
const fail=(reason,configured=null)=>({mode:configured===false?'legacy':'account',configured,authenticated:false,unlocked:false,exp:null,reason:REASONS.has(reason)?reason:'network',cached:false,account:null,quota:null})
const noAnswer=(known)=>fail('network',known)
export function createAccountProvider(deps){const bridge=deps?.bridge,clock=deps?.clock
if(!bridge||typeof bridge.request!=='function')throw new Error('account: мост недоступен')
if(!clock||typeof clock.now!=='function')throw new Error('account: нужны часы')
let current=fail('pending'),inFlight=null
let until=null
const drop=(next)=>{until=null
current=next
return current}
const inactive=(account)=>{drop(fail('inactive',true))
current.authenticated=true
current.account={hint:account.hint}
return state()}
const apply=async(raw)=>{if(!raw||typeof raw!=='object')return drop(noAnswer(current.configured))
if(raw.configured===false&&raw.hasSession===false)return drop(fail('not-configured',false))
if(raw.configured!==true)return drop(fail(raw.reason,raw.configured??null))
if(raw.reason==='unauthorized')return drop(fail('unauthorized',true))
if(raw.ok!==true){return drop(fail('network',true))}
if(raw.authenticated!==true||raw.hasSession!==true){return drop(fail('signed-out',true))}
const account=raw.account,quota=raw.quota
if(account&&typeof account.id==='string'&&account.id!==''&&typeof account.hint==='string'
&&raw.entitlement===null&&quota===null)return inactive(account)
const parsed=parseLicenseKey(raw.entitlement)
if(!account||typeof account.id!=='string'||account.id===''||typeof account.hint!=='string'
||!quota||!Number.isSafeInteger(quota.total)||quota.total<0
||!Number.isSafeInteger(quota.remaining)||quota.remaining<0||quota.remaining>quota.total
||!parsed.ok||parsed.payload?.v!==1||parsed.payload?.sub!==account.id
||parsed.payload?.quota?.total!==quota.total||parsed.payload?.quota?.remaining!==quota.remaining){return drop(fail('invalid-entitlement',true))}
const verified=await verifyLicenseKey(raw.entitlement,{now:clock.now(),subtle:deps.subtle,keys:deps.keys??ACCOUNT_KEYS})
if(!verified.ok){if(verified.reason==='expired')return inactive(account)
return drop(fail('invalid-entitlement',true))}
const issued=parsed.payload?.iat
const age=clock.now()-issued
if(!Number.isSafeInteger(issued)||age<-ACCOUNT_CLOCK_SKEW_MS||!(age<ACCOUNT_CACHE_MS))return drop(fail('invalid-entitlement',true))
until=Math.min(verified.exp,issued+ACCOUNT_CACHE_MS)
current={mode:'account',configured:true,authenticated:true,unlocked:true,exp:verified.exp,reason:null,cached:raw.cached===true,account:{hint:account.hint},quota:{total:quota.total,remaining:quota.remaining}}
return state()}
const refresh=()=>{if(inFlight)return inFlight
inFlight=Promise.resolve().then(()=>bridge.request(ACCOUNT_STATUS)).then(apply,()=>{drop(noAnswer(current.configured))
return state()}).finally(()=>{inFlight=null})
return inFlight}
const live=()=>current.unlocked===true&&Number.isFinite(until)&&clock.now()<until
const state=()=>({build:ACCOUNT_BUILD,mode:current.mode,configured:current.configured,authenticated:current.authenticated,unlocked:live(),exp:current.exp,reason:current.reason,cached:current.cached,account:current.account?{...current.account}:null,quota:current.quota?{...current.quota}:null})
const legacyAllowed=()=>current.configured===false||(current.configured===true&&current.reason==='signed-out')
return{getPlan:()=>live()?PREMIUM:FREE,state,refresh,isLegacyAllowed:legacyAllowed}}
export function createMigrationProvider({account,legacy}={}){if(!account||typeof account.getPlan!=='function'||typeof account.isLegacyAllowed!=='function')throw new Error('account: нужен account provider')
if(!legacy||typeof legacy.getPlan!=='function')throw new Error('account: нужен legacy provider')
const state=()=>{if(account.isLegacyAllowed()){const old=typeof legacy.state==='function'?legacy.state():{}
return{...old,build:ACCOUNT_BUILD,mode:'legacy',configured:account.state().configured,account:null,quota:null}}
return account.state()}
return{getPlan:()=>account.isLegacyAllowed()?legacy.getPlan():account.getPlan(),state,
probe(){const view=state()
const open=view.unlocked===true
return{build:ACCOUNT_BUILD,source:open?(view.mode==='legacy'?'key':'account'):'none',exp:open&&Number.isFinite(view.exp)?view.exp:null}}}}
