export const CHANNEL='fut-companion'
export const FROM_PAGE=`${CHANNEL}/page`
export const FROM_CONTENT=`${CHANNEL}/content`
export const KIND_REQUEST='request'
export const KIND_RESPONSE='response'
export const KIND_EVENT='event'
export function makeRequest(id,method,params){return{channel:CHANNEL,from:FROM_PAGE,kind:KIND_REQUEST,id,method,params:params??null}}
export function makeResponse(id,value){return{channel:CHANNEL,from:FROM_CONTENT,kind:KIND_RESPONSE,id,ok:true,value}}
export function makeError(id,message){return{channel:CHANNEL,from:FROM_CONTENT,kind:KIND_RESPONSE,id,ok:false,error:message}}
export function makeEvent(name,payload){return{channel:CHANNEL,from:FROM_CONTENT,kind:KIND_EVENT,name,payload:payload??null}}
export function isFrom(msg,from){return Boolean(msg)&&typeof msg==='object'&&msg.channel===CHANNEL&&msg.from===from}
export function isRequest(msg){return isFrom(msg,FROM_PAGE)&&msg.kind===KIND_REQUEST&&typeof msg.method==='string'
}
export function isResponse(msg){return isFrom(msg,FROM_CONTENT)&&msg.kind===KIND_RESPONSE}
