import{CHANNEL,FROM_PAGE,FROM_CONTENT,makeRequest,isResponse} from './protocol.js'
export function createBridgeClient(win,opts={}){const{timeoutMs=5000,
prefix='',
setTimeout:setTimer=win.setTimeout?.bind(win),clearTimeout:clearTimer=win.clearTimeout?.bind(win)}=opts
let nextId=1
const pending=new Map()
win.addEventListener('message',(event)=>{if(event.source!==undefined&&event.source!==win)return;
const msg=event.data;
if(!isResponse(msg))return;
const entry=pending.get(msg.id);
if(!entry)return;
pending.delete(msg.id);
if(entry.timer!==undefined&&clearTimer)clearTimer(entry.timer);
if(msg.ok)entry.resolve(msg.value);
else entry.reject(new Error(msg.error))})
function request(method,params,opts={}){const id=typeof prefix==='string'&&prefix!==''?`${prefix}:${nextId++}`:nextId++;
const asked=Number(opts?.timeoutMs)
const wait=Number.isFinite(asked)&&asked>0?asked:timeoutMs
return new Promise((resolve,reject)=>{let timer;
if(setTimer){timer=setTimer(()=>{if(!pending.delete(id))return;
reject(new Error(`bridge timeout: ${method}`))},wait)}
pending.set(id,{resolve,reject,timer});
win.postMessage(makeRequest(id,method,params),win.location.origin)})}
return{request,get pendingCount(){return pending.size},CHANNEL,FROM_PAGE,FROM_CONTENT}}
export async function checkBridge(client){if(!client||typeof client.request!=='function'){return{ok:false,reason:'bridge-unavailable',version:null}}
try{if(await client.request('ping')!=='pong'){return{ok:false,reason:'unexpected-ping',version:null}}
const version=await client.request('version')
if(typeof version!=='string'||version===''){return{ok:false,reason:'invalid-version',version:null}}
return{ok:true,reason:null,version}}catch(err){return{ok:false,reason:String(err?.message??err),version:null}}}
export const FETCH_METHOD='price.fetch'
export const CARDS_METHOD='cards.base'
export const CARDS_TIMEOUT_MS=35000
export function createBridgeFetch(client,opts={}){if(!client||typeof client.request!=='function'){throw new Error('bridge-fetch: нужен клиент моста')}
const wait=Number.isFinite(Number(opts?.timeoutMs))&&Number(opts.timeoutMs)>0?{timeoutMs:Number(opts.timeoutMs)}:undefined
return async function bridgeFetch(url){const result=await client.request(FETCH_METHOD,{url},wait)
if(!result||result.ok!==true){
throw new Error(`bridge-fetch: ${result?.reason ?? 'нет ответа'}`)}
return{status:result.status,modified:typeof result.modified==='string'?result.modified:null,
json:async()=>JSON.parse(result.body),text:async()=>result.body}}}
