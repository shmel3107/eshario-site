export const outbidEn=Object.freeze({
'journal.event.outbid':'outbid',
'journal.event.wouldBid':'would bid',
'automation.stat.bids':'Bids',
'automation.stat.outbid':'Outbid',
'settings.feature.notifications':'Trading sounds',
})
export const outbidRu=Object.freeze({
'journal.event.outbid':'ставку перебили',
'journal.event.wouldBid':'план ставки',
'automation.stat.bids':'Ставки',
'automation.stat.outbid':'Перебито',
'settings.feature.notifications':'Звуки торговли',
})
