export const rewardFlowEn=Object.freeze({
'rewardFlow.claimed':'Reward: {parts}',
'rewardFlow.coins':'{coins} coins',
'rewardFlow.packs':'packs ×{count}',
'rewardFlow.card':'card {name}',
'rewardFlow.cards':'cards ×{count}',
'rewardFlow.xp':'XP',
'rewardFlow.other':'and {count} more',
'rewardFlow.unreadable':'{count} not readable',
'rewardFlow.unknown':'received (could not read what)'})
export const rewardFlowRu=Object.freeze({
'rewardFlow.claimed':'Награда: {parts}',
'rewardFlow.coins':'{coins} монет',
'rewardFlow.packs':'паков ×{count}',
'rewardFlow.card':'карта {name}',
'rewardFlow.cards':'карт ×{count}',
'rewardFlow.xp':'опыт',
'rewardFlow.other':'и ещё {count}',
'rewardFlow.unreadable':'{count} не прочитано',
'rewardFlow.unknown':'получена (прочитать, что именно, не вышло)'})
