export const homeGridEn=Object.freeze({
'settings.feature.homeLayout':'Home tiles laid out to fit without scrolling'})
export const homeGridRu=Object.freeze({
'settings.feature.homeLayout':'Плитки главной без прокрутки'})
