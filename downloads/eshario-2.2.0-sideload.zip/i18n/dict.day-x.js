export const dayXEn=Object.freeze({
'dayX.title':'Something broke after an EA update?',
'dayX.label':'Turn our stuff off on EA screens',
'dayX.hint':'The web app becomes EA\'s own again. This panel stays.',
'dayX.hintFull':'Our prices, grids and buttons disappear from EA\'s screens and we stop asking EA for anything at all. Nothing is deleted and nothing is lost: this panel stays, and the same switch brings everything back.',
'dayX.on':'Our stuff is off. EA\'s web app is untouched.',
'dayX.reload':'Turned back on, but the page needs a refresh. Press F5.',
});
export const dayXRu=Object.freeze({
'dayX.title':'После обновления EA что-то сломалось?',
'dayX.label':'Отключить наше на экранах EA',
'dayX.hint':'Вебап снова станет обычным. Панель останется.',
'dayX.hintFull':'Наши ценники, сетки и кнопки уйдут с экранов EA, и мы перестанем что-либо у неё спрашивать. Ничего не удаляется и не теряется: панель остаётся, и тот же тумблер возвращает всё обратно.',
'dayX.on':'Наше отключено. Вебап EA не тронут.',
'dayX.reload':'Включили обратно, но странице нужна перезагрузка. Нажмите F5.',
});
