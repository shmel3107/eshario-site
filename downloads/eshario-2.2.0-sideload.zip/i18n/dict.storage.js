export const storageEn=Object.freeze({
'storage.returned':'Returned to the club: {count}',
'storage.returnedPartial':'Returned to the club: {count} of {total}',
'storage.badgeHint':'Cards in SBC storage. Counted from a read that already happened, and nothing is requested for this number',
'storage.chip.one':'Storage: {count} item',
'storage.chip.few':'Storage: {count} items',
'storage.chip.many':'Storage: {count} items',
'storage.chip.other':'Storage: {count} items',
'storage.chipUnknown':'Storage has not been read yet'})
export const storageRu=Object.freeze({
'storage.returned':'Вернулось в клуб: {count}',
'storage.returnedPartial':'Вернулось в клуб: {count} из {total}',
'storage.badgeHint':'Карты в хранилище СБЧ. Считаются по уже случившемуся чтению: ради этого числа мы не спрашиваем ничего',
'storage.chip.one':'Хранилище: {count} предмет',
'storage.chip.few':'Хранилище: {count} предмета',
'storage.chip.many':'Хранилище: {count} предметов',
'storage.chip.other':'Хранилище: {count} предметов',
'storage.chipUnknown':'Хранилище ещё не читалось'})
