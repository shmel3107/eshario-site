export const listEn=Object.freeze({
'list.duration.3600':'1 hour',
'list.duration.10800':'3 hours',
'list.duration.21600':'6 hours',
'list.duration.43200':'12 hours',
'list.duration.86400':'1 day',
'list.duration.259200':'3 days',
})
export const listRu=Object.freeze({
'list.duration.3600':'1 час',
'list.duration.10800':'3 часа',
'list.duration.21600':'6 часов',
'list.duration.43200':'12 часов',
'list.duration.86400':'1 день',
'list.duration.259200':'3 дня',
})
