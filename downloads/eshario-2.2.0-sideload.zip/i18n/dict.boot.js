export const bootEn=Object.freeze({
'boot.waiting':'waiting for the web app…',
'boot.reading':'reading your club…',
'boot.ready':'club: {count} cards · prices warm',
'boot.skipped':'club not read: {reason}',
'boot.failed':'could not read the club',
})
export const bootRu=Object.freeze({
'boot.waiting':'жду вебап…',
'boot.reading':'читаю клуб…',
'boot.ready':'клуб: {count} карт · цены тёплые',
'boot.skipped':'клуб не читаю: {reason}',
'boot.failed':'клуб прочитать не вышло',
})
