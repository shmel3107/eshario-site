export const updateNoticeEn=Object.freeze({
'update.line':'Version {version} is available. Download',
'update.lead':'Version {version} is available.',
'update.zip':'Download zip',
'update.how':'How to update',
'update.unpacked':'Version {version} is unpacked.',
'update.reload':'Reload',
'update.reloadHint':'Developer mode must stay on at chrome://extensions',
'update.refresh':'Press F5 to refresh this tab',
'update.same':'The version is the same, unpack the archive into the same folder'})
export const updateNoticeRu=Object.freeze({
'update.line':'Есть версия {version}. Скачать',
'update.lead':'Есть версия {version}.',
'update.zip':'Скачать zip',
'update.how':'Как обновить',
'update.unpacked':'Версия {version} распакована.',
'update.reload':'Перезагрузить',
'update.reloadHint':'Режим разработчика на chrome://extensions должен остаться включённым',
'update.refresh':'Обновите вкладку клавишей F5',
'update.same':'Версия прежняя, распакуйте архив в ту же папку'})
