export const sessionEn=Object.freeze({
'session.epochStopped':'EA session changed, actions stopped'})
export const sessionRu=Object.freeze({
'session.epochStopped':'Сессия EA обновлена, действия остановлены'})
