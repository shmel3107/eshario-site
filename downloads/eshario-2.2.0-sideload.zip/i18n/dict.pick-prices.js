export const pickPricesEn=Object.freeze({
'pickPrices.owned':'Owned',
'pickPrices.items':'No prices for items, pick by hand',
'settings.feature.pickByPrice':'Pick by price, not rating',
})
export const pickPricesRu=Object.freeze({
'pickPrices.owned':'Уже есть',
'pickPrices.items':'На предметы цен нет, выбирайте рукой',
'settings.feature.pickByPrice':'Пик по цене, а не по рейтингу',
})
