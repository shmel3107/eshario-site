export const dropdownSearchEn=Object.freeze({
'dropdownSearch.placeholder':'Find…',
'dropdownSearch.empty':'Nothing found',
'dropdownSearch.hint':'Type to keep only the lines that contain those letters. Enter picks the highlighted line, arrows move it, Esc clears.',
'settings.feature.dropdownSearch':'Search in EA lists',
'settings.organ.features.dropdownSearch.hint':'Every EA dropdown opens with a search field inside it: quality, rarity, position, nation, league, club. The list is EA’s own: lines are only hidden, never removed or reordered.'})
export const dropdownSearchRu=Object.freeze({
'dropdownSearch.placeholder':'Найти…',
'dropdownSearch.empty':'Ничего не найдено',
'dropdownSearch.hint':'Печатайте, и останутся строки с этими буквами. Enter выбирает подсвеченную, стрелки её двигают, Esc очищает.',
'settings.feature.dropdownSearch':'Поиск в списках EA',
'settings.organ.features.dropdownSearch.hint':'Каждая выпадашка EA открывается с полем поиска внутри: качество, редкость, позиция, страна, лига, клуб. Список остаётся её: строки только скрываются, ничего не удаляется и не переставляется.'})
