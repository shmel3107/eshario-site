export const priceBadgeEn=Object.freeze({
'priceBadge.title':'FUT.GG price: {value} coins',
'priceBadge.title.ask':'FUT.GG price: {value} coins. Click the tag to ask the EA market itself.',
'priceBadge.waiting':'~',
'priceBadge.waiting.title':'FUT.GG price is on its way',
'priceBadge.none':'↻ no price',
'priceBadge.none.title':'FUT.GG has no price for this card. Click the tag and we will ask the EA market itself.',
'priceBadge.verified':'✓ {value}',
'priceBadge.verified.title':'Verified price: {value} coins, taken from the EA market itself, not from FUT.GG. Click the tag to measure it again.',
'settings.feature.priceBadges':'Price tags on cards',
})
export const priceBadgeRu=Object.freeze({
'priceBadge.title':'Цена FUT.GG: {value} монет',
'priceBadge.title.ask':'Цена FUT.GG: {value} монет. Нажми на ценник, и спросим сам рынок EA.',
'priceBadge.waiting':'~',
'priceBadge.waiting.title':'Цена FUT.GG ещё едет',
'priceBadge.none':'↻ цены нет',
'priceBadge.none.title':'У FUT.GG нет цены на эту карту. Нажми на ценник, и спросим сам рынок EA.',
'priceBadge.verified':'✓ {value}',
'priceBadge.verified.title':'Проверенный ценник: {value} монет, снят с самого рынка EA, а не из файла FUT.GG. Нажми на ценник, чтобы замерить снова.',
'settings.feature.priceBadges':'Ценники на карточках',
})
