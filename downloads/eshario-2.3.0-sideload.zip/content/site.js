(function(){'use strict';
var CHANNEL='fut-companion';
var FROM_PAGE='fut-companion/page';
var FROM_CONTENT='fut-companion/content';
var TOKEN=makeToken();
var SITE_DOORS=['account.who','code.status','runtime.info'];
var SEEN_CAP=10000;
var seenIds=new Set();
var hmacOnce=null;
function makeToken(){var bytes=new Uint8Array(16);
try{crypto.getRandomValues(bytes)}catch(err){for(var i=0;i<16;i+=1)bytes[i]=Math.floor(Math.random()*256)}
var out='';
for(var j=0;j<16;j+=1)out+=(bytes[j]<16?'0':'')+bytes[j].toString(16);
return out}
function isPlain(value){return !!value&&typeof value==='object'&&!Array.isArray(value)}
function own(){try{return chrome.runtime.getManifest().version}catch(err){return ''}}
try{var root=document.documentElement;
root.setAttribute('data-eshario-loader',own());
root.setAttribute('data-eshario-id',chrome.runtime.id);
root.setAttribute('data-eshario-token',TOKEN)}catch(err){}
function reply(message){window.postMessage(message,window.location.origin)}
function ask(method,params){var sent;
try{sent=chrome.runtime.sendMessage({method:method,params:params})}catch(err){sent=Promise.reject(err)}
return Promise.resolve(sent).then(function(result){return isPlain(result)&&typeof result.ok==='boolean'?result:{ok:false,reason:'no-response'}},function(){return{ok:false,reason:'no-port'}})}
function hello(){return ask('door',{name:'account.who',args:null}).then(function(who){var id='';
try{id=chrome.runtime.id}catch(err){}
return{ok:true,value:{installed:true,version:own(),id:id,account:who.ok?who.value:null}}})}
function hmacKey(){if(hmacOnce===null){var bytes=new Uint8Array(16);
for(var i=0;i<16;i+=1)bytes[i]=parseInt(TOKEN.slice(i*2,i*2+2),16);
hmacOnce=crypto.subtle.importKey('raw',bytes,{name:'HMAC',hash:'SHA-256'},false,['verify'])}
return hmacOnce}
function signedOk(msg){if(typeof msg.sig!=='string'||msg.sig===''||msg.sig.length>100)return Promise.resolve('no-token');
if((typeof msg.id!=='string'&&typeof msg.id!=='number')||String(msg.id).length>80)return Promise.resolve('no-token');
var id=String(msg.id);
if(seenIds.has(id))return Promise.resolve('replay');
var signature;
try{var binary=atob(msg.sig);
signature=new Uint8Array(binary.length);
for(var i=0;i<binary.length;i+=1)signature[i]=binary.charCodeAt(i)}catch(err){return Promise.resolve('no-token')}
var text=id+'\n'+msg.method+'\n'+JSON.stringify(msg.params===undefined?null:msg.params);
return hmacKey().then(function(key){return crypto.subtle.verify('HMAC',key,signature,new TextEncoder().encode(text))}).then(function(ok){if(ok!==true)return 'no-token';
if(seenIds.has(id))return 'replay';
seenIds.add(id);
if(seenIds.size>SEEN_CAP)seenIds.delete(seenIds.values().next().value);
return 'ok'},function(){return 'no-token'})}
function door(params,msg){var name=isPlain(params)?params.name:null;
if(typeof name!=='string'||!/^[a-z]+(?:\.[a-z]+)+$/i.test(name)||name.length>40)return Promise.resolve({ok:false,reason:'bad-door'});
if(SITE_DOORS.indexOf(name)<0)return Promise.resolve({ok:false,reason:'no-door'});
return signedOk(msg).then(function(verdict){if(verdict!=='ok')return{ok:false,reason:verdict};
return ask('door',{name:name,args:params.args===undefined?null:params.args})})}
window.addEventListener('message',function(event){if(event.source!==window)return;
var msg=event.data;
if(!msg||msg.channel!==CHANNEL||msg.from!==FROM_PAGE||msg.kind!=='request'||typeof msg.method!=='string')return;
var work=msg.method==='hello'?hello():msg.method==='door'?door(msg.params,msg):null;
if(work===null){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:false,error:'unknown method: '+msg.method});
return}
work.then(function(value){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:true,value:value})},function(err){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:false,error:String(err&&err.message||err)})})});
try{chrome.runtime.onMessage.addListener(function(message){if(!message||typeof message.loaderEvent!=='string'||!/^door\.[a-z]+$/.test(message.loaderEvent))return false;
window.postMessage({channel:CHANNEL,from:FROM_CONTENT,kind:'event',name:message.loaderEvent,payload:message.payload===undefined?null:message.payload},window.location.origin);
return false})}catch(err){}
})()
