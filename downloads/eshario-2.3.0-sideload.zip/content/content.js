(function(){'use strict';
var CHANNEL='fut-companion';
var FROM_PAGE='fut-companion/page';
var FROM_CONTENT='fut-companion/content';
var KIND_EVENT='event';
var LOCKS_CHANGED='locks.changed';
var LOCKS_WRITE='locks.write';
var ACCOUNT_OPEN_FAILED='account.open.failed';
var TRANSFER_METHOD='settings.transfer';
var TRANSFER_REASONS=['not-signed-in','offline','server','conflict','too-big','empty','no-port'];
var SETTINGS_APPLIED='settings.applied';
var REPORT_METHOD='report.send';
var REPORT_REASONS=['offline','too-many','too-big','server','no-port'];
var CODE_CURRENT='code.current';
var CODE_PREVIOUS='code.previous';
var CODE_STATE='code.state';
var CODE_CONTROL='code.control';
var CODE_NEEDS='code.needsLoader';
var MODULE_PATH='page/page-entry.js';
var BOOT_WAIT_MS=20000;
var FOCUS_FLOOR_MS=60000;
var WEBAPP_RE=/^https:\/\/www\.ea\.com\/(?:[^?#]*\/)?ultimate-team\/web-app/;
var WEBAPP_PREFIX_RE=/^https:\/\/www\.ea\.com\/[^?#\s]{4,200}$/;
var TOKEN=makeToken();
var HERE=here();
var ON_WEBAPP=WEBAPP_RE.test(HERE);
var WEBAPP=HERE===''||ON_WEBAPP||!/^https:\/\//i.test(HERE);
var loaded={source:null,version:null,sha8:null,sha256:null,bytes:null,readMs:null,injectMs:null,waitMs:null,injectAt:null};
var DEV_PASSPORT=devPassport();
var THIN_PASSPORT=thinPassport();
function devPassport(){try{if(!/^chrome-extension:\/\//.test(chrome.runtime.getURL('')))return false;
return namesModules(chrome.runtime.getManifest().web_accessible_resources||[])}catch(err){return false}}
function thinPassport(){try{var groups=chrome.runtime.getManifest().web_accessible_resources;
return Array.isArray(groups)&&groups.length>0&&!namesModules(groups)}catch(err){return false}}
function namesModules(groups){return groups.some(function(group){return isPlain(group)&&Array.isArray(group.resources)&&group.resources.indexOf('page/*.js')>=0})}
var boot=null;
function makeToken(){var bytes=new Uint8Array(16);
try{crypto.getRandomValues(bytes)}catch(err){for(var i=0;i<16;i+=1)bytes[i]=Math.floor(Math.random()*256)}
var out='';
for(var j=0;j<16;j+=1)out+=(bytes[j]<16?'0':'')+bytes[j].toString(16);
return out}
function here(){try{return String(window.location.href||'')}catch(err){return ''}}
function clock(){try{return performance.now()}catch(err){return Date.now()}}
function own(){try{return chrome.runtime.getManifest().version}catch(err){return ''}}
function isPlain(value){return !!value&&typeof value==='object'&&!Array.isArray(value)}
function goodCode(one){return isPlain(one)&&isPlain(one.meta)&&typeof one.text==='string'&&one.text!==''}
function pickCode(stored){var current=stored[CODE_CURRENT],previous=stored[CODE_PREVIOUS],state=stored[CODE_STATE];
var marked=goodCode(current)&&isPlain(state)&&isPlain(state.fallback)&&state.fallback.version===current.meta.version&&state.fallback.sha256===current.meta.sha256;
if(goodCode(current)&&!marked)return{source:'server',meta:current.meta,text:current.text};
if(marked&&goodCode(previous))return{source:'previous',meta:previous.meta,text:previous.text};
return null}
function attributes(node){node.dataset.esharioLoader=own();
node.dataset.esharioBase=chrome.runtime.getURL('');
node.dataset.esharioToken=TOKEN}
function inPage(parts){var sent;
try{sent=chrome.runtime.sendMessage({method:'code.main',params:{parts:parts}})}catch(err){sent=Promise.reject(err)}
return Promise.resolve(sent).then(function(answer){return isPlain(answer)&&answer.ok===true?answer:inDom(parts)},function(){return inDom(parts)})}
function inDom(parts){var out={ok:true,injectMs:null};
for(var i=0;i<parts.length;i+=1){try{var node=document.createElement('script');
var attrs=parts[i].attrs;
if(attrs)for(var key in attrs)node.dataset[key]=attrs[key];
node.textContent=parts[i].text;
var started=clock();
(document.head||document.documentElement).appendChild(node);
if(i===0)out.injectMs=Math.round(clock()-started);
if(typeof node.remove==='function')node.remove()}catch(err){}}
return out}
function tagAttrs(){return{esharioLoader:own(),esharioBase:chrome.runtime.getURL(''),esharioToken:TOKEN}}
function stampInject(){try{document.documentElement.setAttribute('data-eshario-inject',String(Math.round(clock())))}catch(err){}}
function injectText(code){stampInject();
return inPage([{text:code.text,attrs:tagAttrs()}]).then(function(done){loaded.injectMs=Number.isSafeInteger(done.injectMs)?done.injectMs:null})}
function injectModule(){stampInject();
var node=document.createElement('script');
node.type='module';
node.src=chrome.runtime.getURL(MODULE_PATH);
node.dataset.futCompanion='page-entry';
attributes(node);
node.addEventListener('load',function(){node.remove()});
(document.head||document.documentElement).appendChild(node)}
function startPage(){if(!DEV_PASSPORT)return startRelease();
loaded.source='module';
return injectDevTag().then(function(){injectModule();
watchBoot()})}
var DEV_TAG='(function(t){try{Object.defineProperty(window,"__eshario_tag",{value:Object.freeze(t),writable:false,configurable:false,enumerable:false})}catch(e){}})';
function injectDevTag(){return inPage([{text:DEV_TAG+'('+JSON.stringify({loader:own(),base:chrome.runtime.getURL(''),token:TOKEN})+')',attrs:{esharioDevTag:'1'}}]).then(function(){},function(){})}
function startRelease(){var started=clock();
var read;
try{read=chrome.storage.local.get([CODE_CURRENT,CODE_PREVIOUS,CODE_STATE,CODE_NEEDS,CODE_CONTROL])}catch(err){read=Promise.reject(err)}
return Promise.resolve(read).then(function(stored){loaded.readMs=Math.round(clock()-started);
var kept=isPlain(stored)?stored:{};
return{code:pickCode(kept),state:kept[CODE_STATE],needs:kept[CODE_NEEDS],config:isPlain(kept[CODE_CONTROL])&&isPlain(kept[CODE_CONTROL].config)?kept[CODE_CONTROL].config:{}}},function(){return{code:null,state:null,needs:null,config:{}}}).then(function(found){var code=found.code;
adoptWebapp(found.config);
loaded.injectAt=injectAtOf(found.config);
if(code===null){if(THIN_PASSPORT)return noCode(found.state,found.needs);
loaded.source='module';
injectModule();
watchBoot();
return}
dropLine();
loaded.source=code.source;
loaded.version=typeof code.meta.version==='string'?code.meta.version:null;
loaded.sha256=typeof code.meta.sha256==='string'?code.meta.sha256:null;
loaded.sha8=loaded.sha256===null?null:loaded.sha256.slice(0,8);
loaded.bytes=code.text.length;
var waitFrom=clock();
return(loaded.injectAt==='start'?Promise.resolve():whenParsed()).then(function(){loaded.waitMs=Math.round(clock()-waitFrom);
return injectText(code)}).then(injectInstrument).then(function(){watchBoot();
if(loaded.sha8===null)digestLater(code.text)})})}
function injectAtOf(config){return isPlain(config)&&config.injectAt==='start'?'start':'parsed'}
function adoptWebapp(config){if(ON_WEBAPP)return;
var list=isPlain(config)&&Array.isArray(config.webapp)?config.webapp.slice(0,10):[];
for(var i=0;i<list.length;i+=1){if(typeof list[i]==='string'&&WEBAPP_PREFIX_RE.test(list[i])&&HERE.indexOf(list[i])===0){ON_WEBAPP=true;
WEBAPP=true;
return}}}
function whenParsed(){var state='';
try{state=String(document.readyState||'')}catch(err){state=''}
if(state!=='loading')return Promise.resolve();
return new Promise(function(resolve){var done=false;
function go(){if(done)return;
done=true;
resolve()}
try{document.addEventListener('DOMContentLoaded',go,{once:true})}catch(err){go()}})}
function noCode(state,needs){loaded.source='none';
if(!ON_WEBAPP)return;
waiting=true;
showLine(lineKind(null,state,needs));
try{Promise.resolve(chrome.runtime.sendMessage({method:'code.boot',params:{ok:false,source:'none',version:null,sha256:null}})).then(function(){},function(){})}catch(err){}}
var LINE_ID='eshario-loader-line';
var LINE_TEXTS={
ru:{wait:'ESHArio загружает код с сервера…',silent:'ESHArio: сервер не отвечает, повторю позже',ready:'ESHArio: код загружен, обновите страницу (F5)',needs:'ESHArio: нужен новый архив, скачайте на eshario.com'},
en:{wait:'ESHArio is loading its code from the server…',silent:'ESHArio: server not responding, retrying later',ready:'ESHArio: code loaded, refresh the page (F5)',needs:'ESHArio: a new install is needed, download it at eshario.com'}};
var LINE_TEXT=LINE_TEXTS[lineLang()];
function lineLang(){try{var said=typeof navigator!=='undefined'&&navigator&&typeof navigator.language==='string'?navigator.language:'';
return /^ru/i.test(said)?'ru':'en'}catch(err){return 'en'}}
var LINE_SURFACE='#131417'; // --fx-surface
var LINE_INK='#EEF1F7'; // --fx-ink
var LINE_ACCENT='#3DD8FF'; // --fx-accent
var LINE_WARN='#FFB454'; // --fx-warn
var line=null;
var waiting=false;
function lineKind(current,state,needs){if(goodCode(current))return 'ready';
if(needsArchive(needs))return 'needs';
return isPlain(state)&&typeof state.lastError==='string'&&state.lastError!==''?'silent':'wait'}
function needsArchive(needs){return isPlain(needs)&&typeof needs.minLoader==='string'&&newerThan(needs.minLoader,own())}
function newerThan(a,b){var re=/^\d{1,5}(?:\.\d{1,5}){0,3}$/;
if(typeof a!=='string'||typeof b!=='string'||!re.test(a)||!re.test(b))return false;
var x=a.split('.').map(Number),y=b.split('.').map(Number);
for(var i=0;i<4;i+=1){var p=x[i]||0,q=y[i]||0;
if(p!==q)return p>q}
return false}
function lineStyle(kind){return 'position:fixed;top:0;left:0;right:0;z-index:2147483647;pointer-events:none;box-sizing:border-box;margin:0;padding:3px 12px;'
+'font:12px/16px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;'
+'background:'+LINE_SURFACE+';color:'+LINE_INK+';border-bottom:2px solid '+(kind==='silent'||kind==='needs'?LINE_WARN:LINE_ACCENT)}
function showLine(kind){if(!ON_WEBAPP||!Object.prototype.hasOwnProperty.call(LINE_TEXT,kind))return;
try{if(line===null){line=document.createElement('div');
line.id=LINE_ID;
line.setAttribute('role','status');
(document.documentElement||document.body).appendChild(line)}
line.dataset.esharioLine=kind;
line.textContent=LINE_TEXT[kind];
var css=lineStyle(kind);
if(line.style&&typeof line.style==='object')line.style.cssText=css;
else line.setAttribute('style',css)}catch(err){}}
function dropLine(){waiting=false;
try{var node=line;
if(node===null&&typeof document.getElementById==='function')node=document.getElementById(LINE_ID);
if(node&&typeof node.remove==='function')node.remove()}catch(err){}
line=null}
function refreshLine(){var read;
try{read=chrome.storage.local.get([CODE_CURRENT,CODE_STATE,CODE_NEEDS])}catch(err){return}
Promise.resolve(read).then(function(stored){if(!waiting)return;
var kept=isPlain(stored)?stored:{};
showLine(lineKind(kept[CODE_CURRENT],kept[CODE_STATE],kept[CODE_NEEDS]))},function(){})}
var INSTRUMENT='(function(snap,channel,from){var state=snap;'
+'function attach(box){if(box&&typeof box==="object"&&typeof box.loader!=="function")box.loader=function(){return JSON.parse(JSON.stringify(state))}}'
+'if(window.__eshario&&typeof window.__eshario==="object")attach(window.__eshario);'
+'else{try{Object.defineProperty(window,"__eshario",{configurable:true,get:function(){return undefined},'
+'set:function(v){Object.defineProperty(window,"__eshario",{value:v,writable:true,configurable:true,enumerable:true});attach(v)}})}catch(e){}}'
+'window.addEventListener("message",function(e){if(e.source!==window)return;var m=e.data;'
+'if(!m||m.channel!==channel||m.from!==from||m.kind!=="event"||m.name!=="loader.state"||!m.payload||typeof m.payload!=="object")return;state=m.payload})})';
function snapshot(status){var out={loader:own(),code:{version:loaded.version,source:loaded.source,sha256:loaded.sha8},
readMs:loaded.readMs,injectMs:loaded.injectMs,waitMs:loaded.waitMs,injectAt:loaded.injectAt,bytes:loaded.bytes,checkedAt:null,lastError:null,needsLoader:null,fallback:null,
server:null,previous:null,writeMs:null,log:[]};
if(isPlain(status)){out.checkedAt=Number.isSafeInteger(status.checkedAt)?status.checkedAt:null;
out.lastError=typeof status.lastError==='string'?status.lastError:null;
out.needsLoader=isPlain(status.needsLoader)?status.needsLoader:null;
out.fallback=isPlain(status.fallback)?status.fallback:null;
out.server=isPlain(status.current)?status.current:null;
out.previous=isPlain(status.previous)?status.previous:null;
out.writeMs=Number.isSafeInteger(status.writeMs)?status.writeMs:null;
out.log=Array.isArray(status.log)?status.log:[]}
return out}
function injectInstrument(){return inPage([{text:INSTRUMENT+'('+JSON.stringify(snapshot(null))+','+JSON.stringify(CHANNEL)+','+JSON.stringify(FROM_CONTENT)+')',attrs:null}]).then(function(){},function(){}).then(refreshInstrument)}
var refreshTimer=null;
function refreshInstrument(){if(loaded.source===null||loaded.source==='module'||loaded.source==='none'||refreshTimer!==null)return;
refreshTimer=setTimeout(function(){refreshTimer=null;
var sent;
try{sent=chrome.runtime.sendMessage({method:'code.status'})}catch(err){sent=Promise.reject(err)}
Promise.resolve(sent).then(function(status){window.postMessage({channel:CHANNEL,from:FROM_CONTENT,kind:KIND_EVENT,name:'loader.state',payload:snapshot(status)},window.location.origin)},function(){})},300)}
function digestLater(text){try{if(typeof crypto==='undefined'||!crypto.subtle)return;
crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)).then(function(buffer){var view=new Uint8Array(buffer),hex='';
for(var i=0;i<4;i+=1)hex+=(view[i]<16?'0':'')+view[i].toString(16);
loaded.sha8=hex;
refreshInstrument()},function(){})}catch(err){}}
function watchBoot(){if(!ON_WEBAPP)return;
boot={reported:false,timer:setTimeout(function(){reportBoot(false)},BOOT_WAIT_MS)}}
function reportBoot(ok){if(boot===null||boot.reported)return;
boot.reported=true;
clearTimeout(boot.timer);
var params={ok:ok,source:loaded.source,version:loaded.version,sha256:loaded.source==='server'?loaded.sha256:null};
try{Promise.resolve(chrome.runtime.sendMessage({method:'code.boot',params:params})).then(function(){},function(){})}catch(err){}}
var focusAt=0;
try{window.addEventListener('focus',function(){if(!ON_WEBAPP)return;
var now=Date.now();
if(now-focusAt<FOCUS_FLOOR_MS)return;
focusAt=now;
try{Promise.resolve(chrome.runtime.sendMessage({method:'code.focus'})).then(function(){},function(){})}catch(err){}})}catch(err){}
try{if(chrome.runtime.onMessage&&typeof chrome.runtime.onMessage.addListener==='function'){chrome.runtime.onMessage.addListener(function(message){if(!message||typeof message.loaderEvent!=='string'||!/^door\.[a-z]+$/.test(message.loaderEvent))return false;
window.postMessage({channel:CHANNEL,from:FROM_CONTENT,kind:KIND_EVENT,name:message.loaderEvent,payload:message.payload===undefined?null:message.payload},window.location.origin);
return false})}}catch(err){}
var SETTINGS_KEY='settings.toggles';
var FILTERS_KEY='filters.sets';
var LIMITS_KEY='automation.limits';
var OPTIONS_KEY='automation.options';
var SELLER_KEY='seller.options';
var UI_KEY='ui.state';
var JOURNAL_KEY='automation.journal';
var LEDGER_KEY='automation.ledger';
var LICENSE_KEY='license.key';
var PACKS_KEY='packs.locks';
var LOCKS_KEY='card.locks';
var FROZEN_KEY='card.frozen';
var LIVE_CONTROL_KEY='live.control';
var CATALOG_PREFIX='catalog.v1.';
var CATALOG_SHARDS=16;
var GROUPS_KEY='rarity.groups';
var CARDBASE_KEY='cards.seed';
var PREVIEW_KEY='preview.packs';
var DEMAND_KEY='demand.memory';
var PURCHASES_KEY='purchase.log';
var DAY_BUDGET_KEY='market.daybudget';
var BUY_RATE_KEY='market.buyrate';
var SBC_RATE_KEY='sbc.rate';
var MIRROR_PREFIX='club.mirror.v1.';
var MIRROR_HEAD_KEY='club.mirror.head';
var MIRROR_SHARDS=8;
var SYNC_BASE_KEY='settings.sync';
var CLOUD_META_KEY='settings.cloud.meta';
var CLOUD_CHUNK_PREFIX='settings.cloud.';
var CLOUD_MAX_CHUNKS=512;
function readKey(key){return function(){return chrome.storage.local.get(key).then(function(stored){return(stored&&stored[key]!==undefined)?stored[key]:null})}}
function writeKey(key){return function(params){var payload={};
payload[key]=params;
return chrome.storage.local.set(payload).then(function(){return true})}}
function writeLocks(params){if(!params||typeof params!=='object'||Array.isArray(params))return Promise.resolve(false);
return chrome.runtime.sendMessage({method:LOCKS_WRITE,params:params})
.then(function(result){if(result&&result.ok===true)return true;
return Promise.reject('locks: '+((result&&result.reason)||'no-response'))},
function(err){return Promise.reject('locks: '+String((err&&err.message)||err))})}
function catalogKey(params){var shard=params&&params.shard;
if(typeof shard!=='number'||!isFinite(shard)||Math.floor(shard)!==shard) return null;
if(shard<0||shard>=CATALOG_SHARDS) return null;
return CATALOG_PREFIX+shard}
function readCatalog(params){var key=catalogKey(params);
if(key===null) return Promise.resolve(null);
return chrome.storage.local.get(key).then(function(stored){return(stored&&stored[key]!==undefined)?stored[key]:null})}
function writeCatalog(params){var key=catalogKey(params);
if(key===null) return Promise.resolve(false);
var payload={};
payload[key]=params.value;
return chrome.storage.local.set(payload).then(function(){return true})}
function mirrorKey(params){var shard=params&&params.shard;
if(typeof shard!=='number'||!isFinite(shard)||Math.floor(shard)!==shard) return null;
if(shard<0||shard>=MIRROR_SHARDS) return null;
return MIRROR_PREFIX+shard}
function readMirror(params){var key=mirrorKey(params);
if(key===null) return Promise.resolve(null);
return chrome.storage.local.get(key).then(function(stored){return(stored&&stored[key]!==undefined)?stored[key]:null})}
function writeMirror(params){var key=mirrorKey(params);
if(key===null) return Promise.resolve(false);
var payload={};
payload[key]=params.value;
return chrome.storage.local.set(payload).then(function(){return true})}
function cloudRead(){return chrome.storage.sync.get([CLOUD_META_KEY]).then(function(head){var meta=head&&head[CLOUD_META_KEY];
var count=meta&&typeof meta==='object'?meta.chunks:null;
if(typeof count!=='number'||!isFinite(count)||Math.floor(count)!==count||count<=0){return{meta:meta===undefined?null:meta,parts:[]}}
if(count>CLOUD_MAX_CHUNKS)count=CLOUD_MAX_CHUNKS;
var keys=[];
for(var at=0;at<count;at+=1)keys.push(CLOUD_CHUNK_PREFIX+at);
return chrome.storage.sync.get(keys).then(function(stored){var parts=[];
for(var index=0;index<count;index+=1){var one=stored?stored[CLOUD_CHUNK_PREFIX+index]:undefined;
parts.push(typeof one==='string'?one:null)}
return{meta:meta,parts:parts}})})}
function cloudWrite(params){var parts=params&&params.parts;
var meta=params&&params.meta;
if(!Array.isArray(parts)||parts.length>CLOUD_MAX_CHUNKS||!meta||typeof meta!=='object')return Promise.resolve({ok:false,reason:'bad-payload'});
var payload={};
payload[CLOUD_META_KEY]=meta;
for(var at=0;at<parts.length;at+=1){if(typeof parts[at]!=='string')return Promise.resolve({ok:false,reason:'bad-payload'});
payload[CLOUD_CHUNK_PREFIX+at]=parts[at]}
var drop=Number(params&&params.dropFrom);
return chrome.storage.sync.set(payload).then(function(){var stale=[];
if(isFinite(drop)&&drop>parts.length){var end=Math.min(drop,CLOUD_MAX_CHUNKS);
for(var index=parts.length;index<end;index+=1)stale.push(CLOUD_CHUNK_PREFIX+index)}
if(stale.length===0)return{ok:true,removed:[]};
return chrome.storage.sync.remove(stale).then(function(){return{ok:true,removed:stale}},
function(){return{ok:true,removed:[]}})},
function(err){return{ok:false,reason:String((err&&err.message)||err)}})}
function fetchPrice(params){return chrome.runtime.sendMessage({method:'price.fetch',url:params&&params.url})
.then(function(result){return result||{ok:false,reason:'no-response'}},function(err){return{ok:false,reason:String((err&&err.message)||err)}})}
function budgetAsk(method){return function(params){return chrome.runtime.sendMessage({method:method,params:params||null})
.then(function(result){return result&&typeof result==='object'&&result.ok!==undefined?result:{ok:false,granted:0,reason:'counter-unavailable',state:null}},
function(){return{ok:false,granted:0,reason:'counter-unavailable',state:null}})}}
function cardsBase(params){return chrome.runtime.sendMessage({method:'cards.base',params:params||null})
.then(function(result){return result||{ok:false,reason:'no-response',state:null}},
function(err){return{ok:false,reason:String((err&&err.message)||err),state:null}})}
function updateCheck(params){return chrome.runtime.sendMessage({method:'update.check',params:{force:!!(params&&params.force===true)}})
.then(function(result){return result||{ok:false,show:false,reason:'no-response'}},
function(err){return{ok:false,show:false,reason:String((err&&err.message)||err)}})}
function updateReload(){return chrome.runtime.sendMessage({method:'update.reload'})
.then(function(result){return result||{ok:false,reason:'no-response'}},
function(err){return{ok:false,reason:String((err&&err.message)||err)}})}
var SEEN_CAP=10000;
var seenIds=new Set();
var hmacOnce=null;
function tokenBytes(){var out=new Uint8Array(16);
for(var i=0;i<16;i+=1)out[i]=parseInt(TOKEN.slice(i*2,i*2+2),16);
return out}
function hmacKey(){if(hmacOnce===null)hmacOnce=crypto.subtle.importKey('raw',tokenBytes(),{name:'HMAC',hash:'SHA-256'},false,['verify']);
return hmacOnce}
function sigBytes(text){var binary=atob(text);
var out=new Uint8Array(binary.length);
for(var i=0;i<binary.length;i+=1)out[i]=binary.charCodeAt(i);
return out}
function remember(id){seenIds.add(id);
if(seenIds.size>SEEN_CAP)seenIds.delete(seenIds.values().next().value)}
function signedOk(msg){if(!msg||typeof msg.sig!=='string'||msg.sig===''||msg.sig.length>100)return Promise.resolve('no-token');
if((typeof msg.id!=='string'&&typeof msg.id!=='number')||String(msg.id).length>80)return Promise.resolve('no-token');
var id=String(msg.id);
if(seenIds.has(id))return Promise.resolve('replay');
var text=id+'\n'+msg.method+'\n'+JSON.stringify(msg.params===undefined?null:msg.params);
var signature;
try{signature=sigBytes(msg.sig)}catch(err){return Promise.resolve('no-token')}
try{return hmacKey().then(function(key){return crypto.subtle.verify('HMAC',key,signature,new TextEncoder().encode(text))}).then(function(ok){if(ok!==true)return 'no-token';
if(seenIds.has(id))return 'replay';
remember(id);
return 'ok'},function(){return 'no-token'})}catch(err){return Promise.resolve('no-token')}}
function door(params,msg){return signedOk(msg).then(function(verdict){if(verdict!=='ok')return{ok:false,reason:verdict};
return doorSend(params)})}
function doorSend(params){var name=isPlain(params)?params.name:null;
if(typeof name!=='string'||!/^[a-z]+(?:\.[a-z]+)+$/i.test(name)||name.length>40)return Promise.resolve({ok:false,reason:'bad-door'});
var sent;
try{sent=chrome.runtime.sendMessage({method:'door',params:{name:name,args:params.args===undefined?null:params.args}})}catch(err){sent=Promise.reject(err)}
return Promise.resolve(sent).then(function(result){return isPlain(result)&&typeof result.ok==='boolean'?result:{ok:false,reason:'no-response'}},function(){return{ok:false,reason:'no-port'}})}
function accountStatus(){return chrome.runtime.sendMessage({method:'account.status'})
.then(function(result){return result||{ok:false,reason:'no-response'}},function(){return{ok:false,reason:'network'}})}
function openAccount(params){var sent;var ask=params&&typeof params==='object'&&params.ask==='logout'?'logout':null;
try{sent=ask===null?chrome.runtime.sendMessage({method:'account.open'}):chrome.runtime.sendMessage({method:'account.open',params:{ask:ask}})}catch(err){sent=Promise.reject(err)}
return Promise.resolve(sent).then(function(result){if(result&&result.ok===true)return{ok:true};
return accountDoorFailed(result&&typeof result.reason==='string'?result.reason:'no-response')},
function(){return accountDoorFailed('no-worker')})}
function accountDoorFailed(reason){var word=/^[a-z][a-z-]{0,39}$/.test(reason)?reason:'open-failed';
window.postMessage({channel:CHANNEL,from:FROM_CONTENT,kind:KIND_EVENT,name:ACCOUNT_OPEN_FAILED,payload:{reason:word}},window.location.origin);
return{ok:false,reason:word}}
function transferReply(result){var out={ok:!!(result&&result.ok===true)};
if(result&&Number.isSafeInteger(result.revision)&&result.revision>=0)out.revision=result.revision;
if(!out.ok)out.reason=result&&TRANSFER_REASONS.indexOf(result.reason)>=0?result.reason:'server';
return out}
function settingsTransfer(params){var direction=params&&params.direction;
if(direction!=='save'&&direction!=='load')return Promise.resolve({ok:false,reason:'server'});
var sent;
try{sent=chrome.runtime.sendMessage({method:TRANSFER_METHOD,params:{direction:direction}})}catch(err){sent=Promise.reject(err)}
return Promise.resolve(sent).then(transferReply,function(){return{ok:false,reason:'no-port'}})}
function reportSend(params){var report=params&&params.report;
if(!report||typeof report!=='object'||Array.isArray(report))return Promise.resolve({ok:false,reason:'server'});
var words=params&&typeof params.words==='string'?params.words.slice(0,2000):'';
var contact=params&&typeof params.contact==='string'?params.contact.slice(0,64):'';
var sent;
try{sent=chrome.runtime.sendMessage({method:REPORT_METHOD,params:{report:report,words:words,contact:contact}})}catch(err){sent=Promise.reject(err)}
return Promise.resolve(sent).then(function(result){var out={ok:!!(result&&result.ok===true)};
if(out.ok&&result&&Number.isSafeInteger(result.number)&&result.number>0)out.number=result.number;
if(!out.ok)out.reason=result&&REPORT_REASONS.indexOf(result.reason)>=0?result.reason:'server';
return out},function(){return{ok:false,reason:'no-port'}})}
var handlers={ping:function(){return 'pong'},version:function(){return chrome.runtime.getManifest().version},'price.fetch':fetchPrice,
'settings.read':readKey(SETTINGS_KEY),'settings.write':writeKey(SETTINGS_KEY),'filters.read':readKey(FILTERS_KEY),'filters.write':writeKey(FILTERS_KEY),'packs.read':readKey(PACKS_KEY),'packs.write':writeKey(PACKS_KEY),'locks.read':readKey(LOCKS_KEY),'locks.write':writeLocks,'frozen.read':readKey(FROZEN_KEY),'frozen.write':writeKey(FROZEN_KEY),'limits.read':readKey(LIMITS_KEY),'limits.write':writeKey(LIMITS_KEY),'options.read':readKey(OPTIONS_KEY),'options.write':writeKey(OPTIONS_KEY),'seller.read':readKey(SELLER_KEY),'seller.write':writeKey(SELLER_KEY),
'ui.read':readKey(UI_KEY),'ui.write':writeKey(UI_KEY),
'journal.read':readKey(JOURNAL_KEY),'journal.write':writeKey(JOURNAL_KEY),
'ledger.read':readKey(LEDGER_KEY),'ledger.write':writeKey(LEDGER_KEY),
'license.read':readKey(LICENSE_KEY),'license.write':writeKey(LICENSE_KEY),
'live-control.read':readKey(LIVE_CONTROL_KEY),'live-control.write':writeKey(LIVE_CONTROL_KEY),
'catalog.read':readCatalog,'catalog.write':writeCatalog,
'groups.read':readKey(GROUPS_KEY),'groups.write':writeKey(GROUPS_KEY),
'cards.base':cardsBase,
'cardbase.read':readKey(CARDBASE_KEY),'cardbase.write':writeKey(CARDBASE_KEY),
'preview.read':readKey(PREVIEW_KEY),'preview.write':writeKey(PREVIEW_KEY),
'demand.read':readKey(DEMAND_KEY),'demand.write':writeKey(DEMAND_KEY),
'purchases.read':readKey(PURCHASES_KEY),'purchases.write':writeKey(PURCHASES_KEY),
'daybudget.read':readKey(DAY_BUDGET_KEY),'daybudget.write':writeKey(DAY_BUDGET_KEY),
'buyrate.read':readKey(BUY_RATE_KEY),'buyrate.write':writeKey(BUY_RATE_KEY),
'sbcrate.read':readKey(SBC_RATE_KEY),'sbcrate.write':writeKey(SBC_RATE_KEY),
'mirror.read':readMirror,'mirror.write':writeMirror,
'mirror.head.read':readKey(MIRROR_HEAD_KEY),'mirror.head.write':writeKey(MIRROR_HEAD_KEY),
'sync.base.read':readKey(SYNC_BASE_KEY),'sync.base.write':writeKey(SYNC_BASE_KEY),
'cloud.read':cloudRead,'cloud.write':cloudWrite,
'account.status':accountStatus,'account.open':openAccount,
'settings.transfer':settingsTransfer,
'report.send':reportSend,
'update.check':updateCheck,
'door':door,
'update.reload':updateReload,
'budget.reserve':budgetAsk('budget.reserve'),'budget.spend':budgetAsk('budget.spend'),
'budget.release':budgetAsk('budget.release'),'budget.rest':budgetAsk('budget.rest'),
'budget.state':budgetAsk('budget.state')};
var OPEN_EVERYWHERE=['ping','version','door'];
window.addEventListener('message',function(event){if(event.source!==window)return;
var msg=event.data;
if(!msg||msg.channel!==CHANNEL||msg.from!==FROM_PAGE)return;
if(msg.kind!=='request'||typeof msg.method!=='string') return;
if(boot!==null&&!boot.reported)reportBoot(true);
if(waiting||line!==null)dropLine();
var handler=Object.prototype.hasOwnProperty.call(handlers,msg.method)?handlers[msg.method]:null;
if(handler&&!WEBAPP&&OPEN_EVERYWHERE.indexOf(msg.method)<0)handler=null;
if(!handler){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:false,error:'unknown method: '+msg.method});
return}
try{Promise.resolve(handler(msg.params,msg)).then(function(value){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:true,value:value})},function(err){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:false,error:String((err&&err.message)||err)})})}catch(err){reply({channel:CHANNEL,from:FROM_CONTENT,kind:'response',id:msg.id,ok:false,error:String((err&&err.message)||err)})}});
function reply(message){window.postMessage(message,window.location.origin)}
var LOADED_KEY='settings.loadedAt';
if(chrome.storage&&chrome.storage.onChanged&&typeof chrome.storage.onChanged.addListener==='function'){chrome.storage.onChanged.addListener(function(changes,area){if(area!=='local'||!changes)return;
if(changes[LOCKS_KEY]!==undefined)window.postMessage({channel:CHANNEL,from:FROM_CONTENT,kind:KIND_EVENT,name:LOCKS_CHANGED,payload:null},window.location.origin);
if(changes[LOADED_KEY]!==undefined)window.postMessage({channel:CHANNEL,from:FROM_CONTENT,kind:KIND_EVENT,name:SETTINGS_APPLIED,payload:null},window.location.origin);
if(changes[CODE_STATE]!==undefined||changes['code.log']!==undefined||changes[CODE_NEEDS]!==undefined)refreshInstrument();
if(waiting&&(changes[CODE_CURRENT]!==undefined||changes[CODE_STATE]!==undefined||changes[CODE_NEEDS]!==undefined))refreshLine()})}
startPage().then(function(){},function(){});
})()
