(function(){'use strict';
var L=globalThis.esharioLoader=globalThis.esharioLoader||{};
var NS='door.';
var PENDING='door.pending';
var KEY_RE=/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
var NAME_RE=/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
var WEBAPP_RE=/^https:\/\/www\.ea\.com\/(?:[^?#]*\/)?ultimate-team\/web-app/;
var DEFAULT_WEBAPP='https://www.ea.com/ea-sports-fc/ultimate-team/web-app/';
var WEBAPP_PREFIX_RE=/^https:\/\/www\.ea\.com\/[^?#\s]{4,200}$/;
var WEBAPP_PREFIX_MAX=10;
var SITE_DOMAINS=['eshario.com','eshario.app'];
var RULE_MIN=7000;
var RULE_MAX=7999;
var RULES_CAP=50;
var CAPTURE_MAX=4194304;
var RUN_MAX=1048576;
var POWER_KEY='loader.power';
var COMMAND_RE=/^eshario-[1-3]$/;
var FETCH_DEFAULT_MS=15000;
var FETCH_MAX_MS=60000;
var BODY_MAX=1048576;
var RESPONSE_MAX=20971520;
var DOWNLOAD_MAX=20971520;
var AUDIO_MAX=2097152;
var STORE_VALUE_MAX=5242880;
var OFFSCREEN_URL='loader/offscreen.html';
var OFFSCREEN_TARGET='eshario-offscreen';
var METHODS=['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'];
var MENU_CONTEXTS=['page','selection','link','image'];
function plain(value){return !!value&&typeof value==='object'&&!Array.isArray(value)}
function no(reason){return{ok:false,reason:reason}}
function yes(value){return{ok:true,value:value===undefined?null:value}}
function word(err){var text=String(err&&err.message||err||'error');
return text.slice(0,160)}
var domainsOnce=null;
function passportDomains(){if(domainsOnce)return domainsOnce;
var out=[];
try{var list=chrome.runtime.getManifest().host_permissions||[];
for(var i=0;i<list.length;i+=1){var wild=/^https:\/\/\*\.([a-z0-9.-]+)\/\*$/.exec(list[i]);
if(wild){out.push({host:wild[1],sub:true});
continue}
var exact=/^https:\/\/([a-z0-9.-]+)\//.exec(list[i]);
if(exact)out.push({host:exact[1],sub:false})}}catch(err){}
domainsOnce=out;
return out}
function inPassport(value){if(typeof value!=='string'||value===''||value.length>4096)return false;
var url;
try{url=new URL(value)}catch(err){return false}
if(url.protocol!=='https:'||url.username!==''||url.password!=='')return false;
var host=url.hostname;
var domains=passportDomains();
for(var i=0;i<domains.length;i+=1){var one=domains[i];
if(host===one.host)return true;
if(one.sub&&host.slice(-(one.host.length+1))==='.'+one.host)return true}
return false}
L.inPassport=inPassport;
function isSite(value){try{var url=new URL(value);
if(url.protocol!=='https:'||url.username!==''||url.password!=='')return false;
return SITE_DOMAINS.some(function(domain){return url.hostname===domain||url.hostname.slice(-(domain.length+1))==='.'+domain})}catch(err){return false}}
L.isSite=isSite;
L.SITE_DOMAINS=Object.freeze(SITE_DOMAINS.slice());
function webappPrefixes(config){var list=plain(config)&&Array.isArray(config.webapp)?config.webapp:[];
return list.filter(function(one){return typeof one==='string'&&WEBAPP_PREFIX_RE.test(one)}).slice(0,WEBAPP_PREFIX_MAX)}
L.webappPrefixes=webappPrefixes;
function isWebapp(value,config){if(typeof value!=='string')return false;
if(WEBAPP_RE.test(value))return true;
return webappPrefixes(config).some(function(prefix){return value.indexOf(prefix)===0})}
L.isWebapp=isWebapp;
function extensionPage(sender){var self='';
try{self=chrome.runtime.id}catch(err){}
var url=sender&&typeof sender.url==='string'?sender.url:'';
return self!==''&&url.indexOf('chrome-extension://'+self+'/')===0&&(sender.id===undefined||sender.id===self)}
function trusted(sender){if(!sender)return Promise.resolve(false);
var self='';
try{self=chrome.runtime.id}catch(err){}
if(sender.id!==undefined&&self&&sender.id!==self)return Promise.resolve(false);
var url=typeof sender.url==='string'?sender.url:'';
if(self&&url.indexOf('chrome-extension://'+self+'/')===0)return Promise.resolve(true);
if(inPassport(url))return Promise.resolve(true);
return typeof L.onBridgeHost==='function'?L.onBridgeHost(url):Promise.resolve(false)}
function granted(value){if(inPassport(value))return Promise.resolve(true);
var url;
try{url=new URL(value)}catch(err){return Promise.resolve(false)}
if(url.protocol!=='https:'||url.username!==''||url.password!=='')return Promise.resolve(false);
var perms=chrome.permissions;
if(!perms||typeof perms.contains!=='function')return Promise.resolve(false);
return Promise.resolve(perms.contains({origins:[url.origin+'/*']})).then(function(yesDoc){return yesDoc===true},function(){return false})}
L.granted=granted;
function toBase64(bytes){var out='',chunk=32768;
for(var i=0;i<bytes.length;i+=chunk)out+=String.fromCharCode.apply(null,bytes.subarray(i,i+chunk));
return btoa(out)}
function fromBase64(value){return L.b64bytes(value)}
function netFetch(args){if(!plain(args)||typeof args.url!=='string')return Promise.resolve(no('bad-args'));
return granted(args.url).then(function(ok){return ok?fetchGranted(args):no('outside-passport')})}
function fetchGranted(args){var method=typeof args.method==='string'?args.method.toUpperCase():'GET';
if(METHODS.indexOf(method)<0)return Promise.resolve(no('bad-method'));
var headers={};
if(plain(args.headers)){var names=Object.keys(args.headers);
for(var i=0;i<names.length&&i<64;i+=1){var name=names[i],value=args.headers[name];
if(typeof value!=='string'||name.length>100||value.length>8192)continue;
if(/^(cookie|cookie2)$/i.test(name))continue;
headers[name]=value}}
var init={method:method,headers:headers,credentials:'omit',redirect:'follow',
cache:['default','no-store','reload','no-cache','force-cache'].indexOf(args.cache)>=0?args.cache:'no-store'};
if(typeof args.body==='string'){if(args.body.length>BODY_MAX)return Promise.resolve(no('body-too-big'));
init.body=args.body}else if(typeof args.bodyBase64==='string'){var raw;
try{raw=fromBase64(args.bodyBase64)}catch(err){return Promise.resolve(no('bad-body'))}
if(raw.length>BODY_MAX)return Promise.resolve(no('body-too-big'));
init.body=raw}
var ms=Number.isSafeInteger(args.timeoutMs)?Math.max(1000,Math.min(FETCH_MAX_MS,args.timeoutMs)):FETCH_DEFAULT_MS;
try{init.signal=AbortSignal.timeout(ms)}catch(err){}
return fetch(args.url,init).then(function(response){var finalUrl=typeof response.url==='string'&&response.url!==''?response.url:args.url;
return granted(finalUrl).then(function(inside){if(!inside)return no('redirect-outside');
var out={status:response.status,url:finalUrl,headers:{}};
try{response.headers.forEach(function(value,name){out.headers[name]=value})}catch(err){}
return response.arrayBuffer().then(function(buffer){if(buffer.byteLength>RESPONSE_MAX)return no('too-big');
var bytes=new Uint8Array(buffer);
if(args.as==='base64')out.bodyBase64=toBase64(bytes);
else out.body=new TextDecoder('utf-8').decode(bytes);
return yes(out)})})},function(err){return no(/abort|timeout/i.test(word(err))?'timeout':'network')})}
function area(args){return plain(args)&&args.area==='sync'?chrome.storage.sync:chrome.storage.local}
function spaced(key){return typeof key==='string'&&KEY_RE.test(key)?NS+key:null}
function storeGet(args){if(!plain(args))return Promise.resolve(no('bad-args'));
var list=Array.isArray(args.keys)?args.keys:[args.key];
if(list.length===0||list.length>100)return Promise.resolve(no('bad-key'));
var keys=[];
for(var i=0;i<list.length;i+=1){var key=spaced(list[i]);
if(key===null)return Promise.resolve(no('bad-key'));
keys.push(key)}
return area(args).get(keys).then(function(stored){if(!Array.isArray(args.keys)){var one=stored&&stored[keys[0]];
return yes(one===undefined?null:one)}
var out={};
for(var j=0;j<keys.length;j+=1){var got=stored&&stored[keys[j]];
out[list[j]]=got===undefined?null:got}
return yes(out)},function(err){return no('storage')})}
function storeSet(args){if(!plain(args))return Promise.resolve(no('bad-args'));
var key=spaced(args.key);
if(key===null)return Promise.resolve(no('bad-key'));
var text;
try{text=JSON.stringify(args.value)}catch(err){return Promise.resolve(no('bad-value'))}
if(text===undefined)return Promise.resolve(no('bad-value'));
if(text.length>STORE_VALUE_MAX)return Promise.resolve(no('too-big'));
var payload={};
payload[key]=args.value;
return area(args).set(payload).then(function(){return yes(true)},function(err){return no(/quota/i.test(word(err))?'quota':'storage')})}
function storeRemove(args){if(!plain(args))return Promise.resolve(no('bad-args'));
var key=spaced(args.key);
if(key===null)return Promise.resolve(no('bad-key'));
return area(args).remove(key).then(function(){return yes(true)},function(){return no('storage')})}
function storeKeys(args){var store=area(args);
var listed=typeof store.getKeys==='function'?store.getKeys():store.get(null).then(function(all){return Object.keys(all||{})});
return Promise.resolve(listed).then(function(keys){return yes((keys||[]).filter(function(key){return key.indexOf(NS)===0&&key!==PENDING}).map(function(key){return key.slice(NS.length)}).sort())},function(){return no('storage')})}
function webappTabs(){return Promise.all([chrome.tabs.query({url:['https://www.ea.com/*']}),L.effectiveConfig()]).then(function(all){return(all[0]||[]).filter(function(tab){return isWebapp(tab.url,all[1])})},function(){return[]})}
function sendEvent(tabId,name,payload){return chrome.tabs.sendMessage(tabId,{loaderEvent:name,payload:payload===undefined?null:payload}).then(function(){return true},function(){return false})}
function deliver(name,payload,openTab){return webappTabs().then(function(tabs){if(tabs.length>0)return Promise.all(tabs.map(function(tab){return sendEvent(tab.id,name,payload)})).then(function(){return true});
return chrome.storage.local.get(PENDING).then(function(stored){var list=Array.isArray(stored&&stored[PENDING])?stored[PENDING]:[];
var payloadOut={};
payloadOut[PENDING]=list.concat([{name:name,payload:payload===undefined?null:payload,at:Date.now()}]).slice(-20);
return chrome.storage.local.set(payloadOut)}).then(function(){if(!openTab)return false;
return L.effectiveConfig().then(function(config){if(!plain(config)||config.alarmOpensTab!==true)return false;
var url=typeof config.webappUrl==='string'&&isWebapp(config.webappUrl,config)?config.webappUrl:DEFAULT_WEBAPP;
return chrome.tabs.create({url:url,active:false}).then(function(){return false},function(){return false})})})})}
L.flushPending=function(tabId){if(!Number.isSafeInteger(tabId))return Promise.resolve(0);
return chrome.storage.local.get(PENDING).then(function(stored){var list=Array.isArray(stored&&stored[PENDING])?stored[PENDING]:[];
if(list.length===0)return 0;
return chrome.storage.local.remove(PENDING).then(function(){return Promise.all(list.map(function(one){return sendEvent(tabId,one.name,one.payload)}))}).then(function(){return list.length})},function(){return 0})};
function alarmSet(args){if(!plain(args)||typeof args.name!=='string'||!NAME_RE.test(args.name))return Promise.resolve(no('bad-name'));
var info={};
if(Number.isFinite(args.when))info.when=args.when;
else if(Number.isFinite(args.delayMs)&&args.delayMs>0)info.delayInMinutes=args.delayMs/60000;
else return Promise.resolve(no('bad-time'));
if(Number.isFinite(args.periodMs)&&args.periodMs>0)info.periodInMinutes=args.periodMs/60000;
return Promise.resolve(chrome.alarms.create(NS+args.name,info)).then(function(){return yes(true)},function(err){return no('alarm')})}
function alarmClear(args){if(!plain(args)||typeof args.name!=='string'||!NAME_RE.test(args.name))return Promise.resolve(no('bad-name'));
return Promise.resolve(chrome.alarms.clear(NS+args.name)).then(function(done){return yes(done===true)},function(){return no('alarm')})}
function alarmList(){return Promise.resolve(chrome.alarms.getAll()).then(function(all){return yes((all||[]).filter(function(one){return one.name.indexOf(NS)===0}).map(function(one){return{name:one.name.slice(NS.length),scheduledTime:one.scheduledTime,periodMs:Number.isFinite(one.periodInMinutes)?Math.round(one.periodInMinutes*60000):null}}))},function(){return no('alarm')})}
function notifyShow(args){if(!plain(args)||typeof args.title!=='string'||typeof args.message!=='string')return Promise.resolve(no('bad-args'));
var id=typeof args.id==='string'&&NAME_RE.test(args.id)?args.id:'n'+Date.now();
var options={type:'basic',iconUrl:chrome.runtime.getURL('assets/icon128.png'),title:args.title.slice(0,100),message:args.message.slice(0,500),silent:args.silent===true};
return Promise.resolve(chrome.notifications.create(NS+id,options)).then(function(){return yes(id)},function(err){return no('notify')})}
function notifyClear(args){if(!plain(args)||typeof args.id!=='string'||!NAME_RE.test(args.id))return Promise.resolve(no('bad-name'));
return Promise.resolve(chrome.notifications.clear(NS+args.id)).then(function(done){return yes(done===true)},function(){return no('notify')})}
function ensureOffscreen(){if(!chrome.offscreen||typeof chrome.offscreen.createDocument!=='function')return Promise.reject(new Error('no-offscreen'));
var has=typeof chrome.offscreen.hasDocument==='function'?Promise.resolve(chrome.offscreen.hasDocument()):Promise.resolve(false);
return has.then(function(yesDoc){if(yesDoc)return;
return chrome.offscreen.createDocument({url:OFFSCREEN_URL,reasons:['CLIPBOARD','AUDIO_PLAYBACK'],justification:'ESHArio: буфер обмена и звук по просьбе кода страницы'}).then(function(){},function(err){if(/single offscreen|only a single/i.test(word(err)))return;
throw err})})}
function offscreen(op,data){return ensureOffscreen().then(function(){return chrome.runtime.sendMessage({target:OFFSCREEN_TARGET,op:op,data:data})}).then(function(answer){return plain(answer)&&answer.ok===true?yes(answer.value):no(plain(answer)&&typeof answer.reason==='string'?answer.reason.slice(0,40):'offscreen')},function(err){return no(word(err)==='no-offscreen'?'no-offscreen':'offscreen')})}
function clipboardWrite(args){if(!plain(args)||typeof args.text!=='string'||args.text.length>BODY_MAX)return Promise.resolve(no('bad-args'));
return offscreen('clipboard.write',{text:args.text})}
function clipboardRead(){return offscreen('clipboard.read',null)}
function audioPlay(args){if(!plain(args)||typeof args.src!=='string')return Promise.resolve(no('bad-args'));
if(!/^data:audio\/[a-z0-9.+-]+;base64,[A-Za-z0-9+/]+=*$/.test(args.src)||args.src.length>AUDIO_MAX)return Promise.resolve(no('bad-src'));
var volume=Number.isFinite(args.volume)?Math.max(0,Math.min(1,args.volume)):1;
return offscreen('audio.play',{src:args.src,volume:volume})}
function safeName(value){if(typeof value!=='string')return null;
var name=value.replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').replace(/^[.\s]+/,'').slice(0,120);
return name===''?null:name}
function downloadData(filename,mime,base64){var name=safeName(filename);
if(name===null)return Promise.resolve(no('bad-name'));
var type=typeof mime==='string'&&/^[a-z]+\/[a-z0-9.+-]+$/i.test(mime)?mime:'application/octet-stream';
if(base64.length>DOWNLOAD_MAX*1.4)return Promise.resolve(no('too-big'));
return Promise.resolve(chrome.downloads.download({url:'data:'+type+';base64,'+base64,filename:name,conflictAction:'uniquify',saveAs:false})).then(function(id){return yes(id)},function(){return no('download')})}
function downloadText(args){if(!plain(args)||typeof args.text!=='string')return Promise.resolve(no('bad-args'));
var bytes=new TextEncoder().encode(args.text);
if(bytes.length>DOWNLOAD_MAX)return Promise.resolve(no('too-big'));
return downloadData(args.filename,typeof args.mime==='string'?args.mime:'text/plain',toBase64(bytes))}
function downloadBytes(args){if(!plain(args)||typeof args.base64!=='string'||!/^[A-Za-z0-9+/]*={0,2}$/.test(args.base64))return Promise.resolve(no('bad-args'));
return downloadData(args.filename,args.mime,args.base64)}
function tabOf(args,sender){var id=plain(args)&&Number.isSafeInteger(args.tabId)?args.tabId:(sender&&sender.tab&&Number.isSafeInteger(sender.tab.id)?sender.tab.id:null);
if(id===null)return Promise.resolve(null);
return chrome.tabs.get(id).then(function(tab){return tab||null},function(){return null})}
function tabsOpen(args){if(!plain(args)||!inPassport(args.url))return Promise.resolve(no('outside-passport'));
return chrome.tabs.create({url:args.url,active:args.active!==false}).then(function(tab){return yes({id:tab&&tab.id})},function(){return no('tabs')})}
function tabsFocus(args,sender){return tabOf(args,sender).then(function(tab){if(!tab||!inPassport(tab.url))return no('outside-passport');
return chrome.tabs.update(tab.id,{active:true}).then(function(){return chrome.windows&&chrome.windows.update?chrome.windows.update(tab.windowId,{focused:true}):null}).then(function(){return yes(true)},function(){return no('tabs')})})}
function tabsReload(args,sender){return tabOf(args,sender).then(function(tab){if(!tab||!inPassport(tab.url))return no('outside-passport');
return chrome.tabs.reload(tab.id).then(function(){return yes(true)},function(){return no('tabs')})})}
function tabsQuery(){return Promise.all([chrome.tabs.query({}),L.effectiveConfig()]).then(function(all){var config=all[1];
return yes((all[0]||[]).filter(function(tab){return inPassport(tab.url)}).map(function(tab){return{id:tab.id,url:tab.url,title:typeof tab.title==='string'?tab.title.slice(0,200):'',active:tab.active===true,windowId:tab.windowId,status:tab.status||null,webapp:isWebapp(tab.url,config)}}))},function(){return no('tabs')})}
function scriptingInject(args,sender){return Promise.all([tabOf(args,sender),L.effectiveConfig()]).then(function(all){var tab=all[0];
if(!tab||!isWebapp(tab.url,all[1]))return no('not-webapp');
return chrome.scripting.executeScript({target:{tabId:tab.id},files:['content/content.js']}).then(function(){return yes(true)},function(){return no('scripting')})})}
function menuAdd(args){if(!plain(args)||typeof args.id!=='string'||!NAME_RE.test(args.id)||typeof args.title!=='string'||args.title==='')return Promise.resolve(no('bad-args'));
var contexts=Array.isArray(args.contexts)?args.contexts.filter(function(one){return MENU_CONTEXTS.indexOf(one)>=0}):['page'];
if(contexts.length===0)contexts=['page'];
return new Promise(function(resolve){try{chrome.contextMenus.create({id:NS+args.id,title:args.title.slice(0,100),contexts:contexts,documentUrlPatterns:['https://*.ea.com/*']},function(){var err=chrome.runtime.lastError;
resolve(err?no(/duplicate/i.test(word(err))?'duplicate':'menu'):yes(args.id))})}catch(err){resolve(no('menu'))}})}
function menuRemove(args){if(!plain(args)||typeof args.id!=='string'||!NAME_RE.test(args.id))return Promise.resolve(no('bad-name'));
return Promise.resolve(chrome.contextMenus.remove(NS+args.id)).then(function(){return yes(true)},function(){return no('menu')})}
function idleState(args){var seconds=plain(args)&&Number.isSafeInteger(args.seconds)?Math.max(15,Math.min(3600,args.seconds)):60;
return Promise.resolve(chrome.idle.queryState(seconds)).then(function(state){return yes(state)},function(){return no('idle')})}
function runtimeInfo(){try{var manifest=chrome.runtime.getManifest();
return Promise.resolve(yes({version:manifest.version,id:chrome.runtime.id,name:manifest.name,permissions:manifest.permissions||[],hostPermissions:manifest.host_permissions||[]}))}catch(err){return Promise.resolve(no('runtime'))}}
var PERM_LIST_MAX=20;
function permSet(args){if(!plain(args))return null;
var out={};
var origins=args.origins===undefined?[]:args.origins,permissions=args.permissions===undefined?[]:args.permissions;
if(!Array.isArray(origins)||!Array.isArray(permissions)||origins.length+permissions.length===0||origins.length>PERM_LIST_MAX||permissions.length>PERM_LIST_MAX)return null;
for(var i=0;i<origins.length;i+=1)if(typeof origins[i]!=='string'||!/^https:\/\/[^\s]{1,200}$/.test(origins[i]))return null;
for(var j=0;j<permissions.length;j+=1)if(typeof permissions[j]!=='string'||!/^[A-Za-z]{2,40}$/.test(permissions[j]))return null;
if(origins.length>0)out.origins=origins.slice();
if(permissions.length>0)out.permissions=permissions.slice();
return out}
function permContains(args){var set=permSet(args);
if(set===null)return Promise.resolve(no('bad-args'));
return Promise.resolve(chrome.permissions.contains(set)).then(function(has){return yes(has===true)},function(){return no('permissions')})}
function permRequest(args,sender){if(!extensionPage(sender))return Promise.resolve(no('extension-page-only'));
var set=permSet(args);
if(set===null)return Promise.resolve(no('bad-args'));
return Promise.resolve(chrome.permissions.request(set)).then(function(given){return yes(given===true)},function(err){return no(/gesture/i.test(word(err))?'gesture':'permissions')})}
var RULE_TYPES=['block','allow','modifyHeaders'];
var HEADER_OPS=['set','remove','append'];
var RESOURCE_TYPES=['main_frame','sub_frame','stylesheet','script','image','font','object','xmlhttprequest','ping','csp_report','media','websocket','webtransport','webbundle','other'];
var HOST_RE=/^(?:[a-z0-9-]+\.)+[a-z]{2,63}$/;
function headerList(list){if(list===undefined)return[];
if(!Array.isArray(list)||list.length===0||list.length>20)return null;
var out=[];
for(var i=0;i<list.length;i+=1){var one=list[i];
if(!plain(one)||typeof one.header!=='string'||!/^[A-Za-z0-9-]{1,100}$/.test(one.header)||HEADER_OPS.indexOf(one.operation)<0)return null;
if(/^(?:cookie|cookie2|set-cookie)$/i.test(one.header))return null;
var row={header:one.header,operation:one.operation};
if(one.operation!=='remove'){if(typeof one.value!=='string'||one.value.length>2000)return null;
row.value=one.value}
out.push(row)}
return out}
function ruleOf(raw){if(!plain(raw)||!Number.isSafeInteger(raw.id)||raw.id<RULE_MIN||raw.id>RULE_MAX)return 'bad-id';
var action=raw.action,condition=raw.condition;
if(!plain(action)||RULE_TYPES.indexOf(action.type)<0)return 'bad-action';
if(!plain(condition)||!Array.isArray(condition.requestDomains)||condition.requestDomains.length===0||condition.requestDomains.length>20)return 'no-domains';
var rule={id:raw.id,priority:Number.isSafeInteger(raw.priority)?Math.max(1,Math.min(100,raw.priority)):1,action:{type:action.type},condition:{requestDomains:[]}};
if(action.type==='modifyHeaders'){var req=headerList(action.requestHeaders),res=headerList(action.responseHeaders);
if(req===null||res===null||req.length+res.length===0)return 'bad-headers';
if(req.length>0)rule.action.requestHeaders=req;
if(res.length>0)rule.action.responseHeaders=res}
for(var i=0;i<condition.requestDomains.length;i+=1){var host=String(condition.requestDomains[i]).toLowerCase();
if(!HOST_RE.test(host))return 'bad-domain';
rule.condition.requestDomains.push(host)}
if(condition.urlFilter!==undefined){if(typeof condition.urlFilter!=='string'||condition.urlFilter===''||condition.urlFilter.length>500)return 'bad-filter';
rule.condition.urlFilter=condition.urlFilter}
if(condition.regexFilter!==undefined){if(typeof condition.regexFilter!=='string'||condition.regexFilter===''||condition.regexFilter.length>500||rule.condition.urlFilter!==undefined)return 'bad-filter';
rule.condition.regexFilter=condition.regexFilter}
if(condition.resourceTypes!==undefined){if(!Array.isArray(condition.resourceTypes)||condition.resourceTypes.length===0||condition.resourceTypes.some(function(one){return RESOURCE_TYPES.indexOf(one)<0}))return 'bad-types';
rule.condition.resourceTypes=condition.resourceTypes.slice()}
return rule}
L.ruleOf=ruleOf;
function doorRuleIds(){return Promise.resolve(chrome.declarativeNetRequest.getDynamicRules()).then(function(rules){return(rules||[]).filter(function(rule){return rule&&rule.id>=RULE_MIN&&rule.id<=RULE_MAX})})}
function rulesSet(args){if(!plain(args)||!Array.isArray(args.rules)||args.rules.length>RULES_CAP)return Promise.resolve(no('bad-args'));
var rules=[],ids={};
for(var i=0;i<args.rules.length;i+=1){var rule=ruleOf(args.rules[i]);
if(typeof rule==='string')return Promise.resolve(no(rule));
if(ids[rule.id])return Promise.resolve(no('bad-id'));
ids[rule.id]=true;
rules.push(rule)}
var hosts=[];
rules.forEach(function(rule){rule.condition.requestDomains.forEach(function(host){if(hosts.indexOf(host)<0)hosts.push(host)})});
return Promise.all(hosts.map(function(host){return granted('https://'+host+'/')})).then(function(all){if(all.some(function(ok){return !ok}))return no('outside-passport');
return doorRuleIds().then(function(existing){return Promise.resolve(chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:existing.map(function(rule){return rule.id}),addRules:rules})).then(function(){return yes(rules.length)})})}).then(function(v){return v},function(err){return no(word(err).slice(0,60)||'rules')})}
function rulesClear(){return doorRuleIds().then(function(existing){return Promise.resolve(chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:existing.map(function(rule){return rule.id})})).then(function(){return yes(existing.length)})}).then(function(v){return v},function(){return no('rules')})}
function rulesList(){return doorRuleIds().then(function(rules){return yes(rules)},function(){return no('rules')})}
function tabsCapture(args,sender){var quality=plain(args)&&Number.isSafeInteger(args.quality)?Math.max(40,Math.min(90,args.quality)):70;
return tabOf(args,sender).then(function(tab){if(!tab||!inPassport(tab.url))return no('outside-passport');
if(tab.active!==true)return no('not-visible');
return Promise.resolve(chrome.tabs.captureVisibleTab(tab.windowId,{format:'jpeg',quality:quality})).then(function(dataUrl){if(typeof dataUrl!=='string'||dataUrl.indexOf('data:image/jpeg')!==0)return no('capture');
if(dataUrl.length>CAPTURE_MAX)return no('too-big');
return yes(dataUrl)},function(){return no('capture')})})}
function powerKeep(args){var level=plain(args)&&args.level==='system'?'system':'display';
if(!chrome.power||typeof chrome.power.requestKeepAwake!=='function')return Promise.resolve(no('power'));
try{chrome.power.requestKeepAwake(level)}catch(err){return Promise.resolve(no('power'))}
var payload={};
payload[POWER_KEY]={level:level,at:Date.now()};
return chrome.storage.local.set(payload).then(function(){return yes(level)},function(){return yes(level)})}
function powerRelease(){if(!chrome.power||typeof chrome.power.releaseKeepAwake!=='function')return Promise.resolve(no('power'));
try{chrome.power.releaseKeepAwake()}catch(err){return Promise.resolve(no('power'))}
return chrome.storage.local.remove(POWER_KEY).then(function(){return yes(true)},function(){return yes(true)})}
function powerOnTabClosed(){return chrome.storage.local.get(POWER_KEY).then(function(stored){if(!stored||!stored[POWER_KEY])return false;
return webappTabs().then(function(tabs){if(tabs.length>0)return false;
return powerRelease().then(function(){return true})})},function(){return false})}
L.powerOnTabClosed=powerOnTabClosed;
var ISOLATED_FILES=['content/content.js'];
function scriptingRun(args,sender){if(!plain(args))return Promise.resolve(no('bad-args'));
var world=args.world===undefined?'MAIN':args.world;
if(world!=='MAIN'&&world!=='ISOLATED')return Promise.resolve(no('bad-world'));
if(world==='MAIN'&&(typeof args.text!=='string'||args.text===''||args.text.length>RUN_MAX))return Promise.resolve(no('bad-text'));
if(world==='ISOLATED'&&args.text!==undefined&&args.text!==null)return Promise.resolve(no('isolated-text'));
var file=args.file===undefined?ISOLATED_FILES[0]:args.file;
if(world==='ISOLATED'&&ISOLATED_FILES.indexOf(file)<0)return Promise.resolve(no('bad-file'));
return tabOf(args,sender).then(function(tab){if(!tab||!inPassport(tab.url))return no('outside-passport');
if(world==='ISOLATED'&&isSite(tab.url))return no('site-tab');
var call=world==='MAIN'?{target:{tabId:tab.id},world:'MAIN',func:L.intoPage,args:[[{text:args.text,attrs:null}]]}:{target:{tabId:tab.id},files:[file]};
return Promise.resolve(chrome.scripting.executeScript(call)).then(function(results){var got=Array.isArray(results)&&results[0]&&plain(results[0].result)?results[0].result:null;
return yes({ran:got&&Number.isSafeInteger(got.ran)?got.ran:(world==='ISOLATED'?1:null)})},function(){return no('scripting')})})}
function sidepanelEnable(args,sender){var on=plain(args)&&args.on===true;
if(!chrome.sidePanel||typeof chrome.sidePanel.setOptions!=='function')return Promise.resolve(no('sidepanel'));
return tabOf(args,sender).then(function(tab){if(!tab||!inPassport(tab.url))return no('outside-passport');
return Promise.resolve(chrome.sidePanel.setOptions({tabId:tab.id,path:L.PANEL_PATH,enabled:on})).then(function(){return yes(on)},function(){return no('sidepanel')})})}
function sidepanelOpen(args,sender){if(!chrome.sidePanel||typeof chrome.sidePanel.open!=='function')return Promise.resolve(no('sidepanel'));
return tabOf(args,sender).then(function(tab){if(!tab||!inPassport(tab.url))return no('outside-passport');
return Promise.resolve(chrome.sidePanel.open({tabId:tab.id})).then(function(){return yes(true)},function(err){return no(/gesture|user action/i.test(word(err))?'gesture':'sidepanel')})})}
function navFrames(args,sender){if(!chrome.webNavigation||typeof chrome.webNavigation.getAllFrames!=='function')return Promise.resolve(no('nav'));
return tabOf(args,sender).then(function(tab){if(!tab||!inPassport(tab.url))return no('outside-passport');
return Promise.resolve(chrome.webNavigation.getAllFrames({tabId:tab.id})).then(function(frames){return yes((frames||[]).slice(0,200).map(function(frame){return{frameId:frame.frameId,parentFrameId:frame.parentFrameId,url:inPassport(frame.url)?frame.url:null}}))},function(){return no('nav')})})}
function accountWho(){return chrome.storage.local.get('account.snapshot').then(function(stored){var kept=stored&&stored['account.snapshot'];
var account=plain(kept)&&plain(kept.answer)&&plain(kept.answer.account)?kept.answer.account:null;
if(!account||typeof account.id!=='string')return yes({signedIn:false,id:null,hint:null});
return yes({signedIn:true,id:account.id,hint:typeof account.hint==='string'?account.hint:null})},function(){return no('storage')})}
var DOORS={
'net.fetch':netFetch,
'store.get':storeGet,'store.set':storeSet,'store.remove':storeRemove,'store.keys':storeKeys,
'alarm.set':alarmSet,'alarm.clear':alarmClear,'alarm.list':alarmList,
'notify.show':notifyShow,'notify.clear':notifyClear,
'clipboard.read':clipboardRead,'clipboard.write':clipboardWrite,
'download.text':downloadText,'download.bytes':downloadBytes,
'tabs.open':tabsOpen,'tabs.focus':tabsFocus,'tabs.reload':tabsReload,'tabs.query':tabsQuery,
'scripting.inject':scriptingInject,
'offscreen.audio':audioPlay,
'menu.add':menuAdd,'menu.remove':menuRemove,
'idle.state':idleState,
'runtime.info':runtimeInfo,
'code.status':function(){return L.status().then(yes,function(){return no('loader')})},
'code.refresh':function(){return L.check('manual').then(function(){return L.status()}).then(yes,function(){return no('loader')})},
'config.get':function(){return L.effectiveConfig().then(yes,function(){return no('storage')})},
'account.who':accountWho,
'perm.contains':permContains,'perm.request':permRequest,
'net.rules.set':rulesSet,'net.rules.clear':rulesClear,'net.rules.list':rulesList,
'tabs.capture':tabsCapture,
'power.keepAwake':powerKeep,'power.release':powerRelease,
'scripting.run':scriptingRun,
'sidepanel.enable':sidepanelEnable,'sidepanel.open':sidepanelOpen,
'nav.frames':navFrames};
L.DOOR_NAMES=Object.freeze(Object.keys(DOORS).sort());
var SITE_DOORS=Object.freeze(['account.who','code.status','runtime.info']);
L.SITE_DOORS=SITE_DOORS;
function fromSitePage(sender){return !!sender&&typeof sender.url==='string'&&isSite(sender.url)}
L.door=function(params,sender,external){return(external?Promise.resolve(true):trusted(sender)).then(function(ok){if(!ok)return no('untrusted');
if(!plain(params)||typeof params.name!=='string')return no('bad-door');
if((external||fromSitePage(sender))&&SITE_DOORS.indexOf(params.name)<0)return no('no-door');
var work=Object.prototype.hasOwnProperty.call(DOORS,params.name)?DOORS[params.name]:null;
if(work===null)return no('no-door');
try{return Promise.resolve(work(params.args,sender)).then(function(result){return plain(result)&&typeof result.ok==='boolean'?result:no('door-error')},function(){return no('door-error')})}catch(err){return no('door-error')}},function(){return no('door-error')})};
function siteSender(sender){if(!sender)return false;
var origin=typeof sender.origin==='string'&&sender.origin!=='null'?sender.origin:(typeof sender.url==='string'?sender.url:'');
return isSite(origin)}
L.external=function(message,sender){if(!siteSender(sender))return Promise.resolve(no('untrusted'));
if(!plain(message))return Promise.resolve(no('bad-message'));
if(message.method==='hello')return accountWho().then(function(who){var id='';
try{id=chrome.runtime.id}catch(err){}
return yes({installed:true,version:L.own(),id:id,account:who.ok?who.value:null})});
if(message.method==='door')return L.door(message.params,sender,true);
return Promise.resolve(no('no-method'))};
try{chrome.runtime.onMessageExternal.addListener(function(message,sender,sendResponse){L.external(message,sender).then(sendResponse,function(){sendResponse(no('loader-error'))});
return true})}catch(err){}
try{chrome.alarms.onAlarm.addListener(function(alarm){if(!alarm||typeof alarm.name!=='string'||alarm.name.indexOf(NS)!==0)return;
void deliver('door.alarm',{name:alarm.name.slice(NS.length),scheduledTime:alarm.scheduledTime},true)})}catch(err){}
try{chrome.notifications.onClicked.addListener(function(id){if(typeof id!=='string'||id.indexOf(NS)!==0)return;
void deliver('door.notify',{id:id.slice(NS.length),action:'click'},false)})}catch(err){}
try{chrome.commands.onCommand.addListener(function(command,tab){if(typeof command!=='string'||!COMMAND_RE.test(command))return;
void deliver('door.command',{name:command,tabId:tab&&Number.isSafeInteger(tab.id)?tab.id:null},false)})}catch(err){}
function permissionsChanged(kind){return function(change){var out={kind:kind,origins:plain(change)&&Array.isArray(change.origins)?change.origins.slice(0,PERM_LIST_MAX):[],permissions:plain(change)&&Array.isArray(change.permissions)?change.permissions.slice(0,PERM_LIST_MAX):[]};
void deliver('door.permissions',out,false);
if(typeof L.applyConfig==='function')void L.applyConfig()}}
try{chrome.permissions.onAdded.addListener(permissionsChanged('added'))}catch(err){}
try{chrome.permissions.onRemoved.addListener(permissionsChanged('removed'))}catch(err){}
try{chrome.tabs.onRemoved.addListener(function(){void powerOnTabClosed()})}catch(err){}
try{chrome.contextMenus.onClicked.addListener(function(info,tab){if(!info||typeof info.menuItemId!=='string'||info.menuItemId.indexOf(NS)!==0||!tab||!Number.isSafeInteger(tab.id))return;
void sendEvent(tab.id,'door.menu',{id:info.menuItemId.slice(NS.length),selectionText:typeof info.selectionText==='string'?info.selectionText.slice(0,2000):null,linkUrl:info.linkUrl||null,srcUrl:info.srcUrl||null,pageUrl:info.pageUrl||null})})}catch(err){}
})()
