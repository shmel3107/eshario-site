(function(){'use strict';
var L=globalThis.esharioLoader=globalThis.esharioLoader||{};
var CODE_ORIGINS=['https://api.eshario.com','https://api.eshario.app'];
var FILE_ORIGINS=['https://eshario.com','https://eshario.app','https://api.eshario.com','https://api.eshario.app'];
var OFFER_FALLBACKS=['https://eshario.com/downloads/code/offer.json','https://eshario.app/downloads/code/offer.json'];
var CONTROL_ORIGINS_MAX=6;
var CODE_PATH='/v1/code';
var FILE_PATHS=['/v1/code/','/downloads/code/'];
var CURRENT='code.current';
var PREVIOUS='code.previous';
var STATE='code.state';
var NEEDS='code.needsLoader';
var LOG='code.log';
var CONFIG='code.config';
var CONTROL='code.control';
var SNAPSHOT='account.snapshot';
var ALARM='code.check';
var ALARM_MINUTES=60;
var FIRST_ALARM='code.first';
var FIRST_STEPS=[1,2,5,15];
var FIRST_STEP_AFTER=3;
var WHY_RE=/^[a-z]{1,12}$/;
var UNFLOORED=['alarm','first','install','start'];
var FLOOR_MS=60000;
var ASK_TIMEOUT_MS=8000;
var FETCH_TIMEOUT_MS=180000;
var MAX_BYTES=16777216;
var REJECT_LIMIT=3;
var BOOT_FAIL_LIMIT=2;
var LOG_CAP=60;
var PUBLIC_KEY_PATH='loader/code-public-key.js';
var VERSION_RE=/^(0|[1-9][0-9]{0,4})(?:\.(0|[1-9][0-9]{0,4})){0,3}$/;
var SHA_RE=/^[0-9a-f]{64}$/;
var SIG_RE=/^[A-Za-z0-9+/_-]{40,200}={0,2}$/;
var ACCT_RE=/^[A-Za-z0-9_-]{1,64}$/;
var RING_RE=/^[A-Za-z0-9._-]{1,32}$/;
var HEADER_RE=/^\/\/ ESHArio page-bundle (\S+)/;
var CONTROL_MAX=65536;
var FP_RE=/^[0-9a-f]{16}$/;
var JWK_COORD_RE=/^[A-Za-z0-9_-]{43}$/;
L.CODE_KEYS=Object.freeze({current:CURRENT,previous:PREVIOUS,state:STATE,needs:NEEDS,log:LOG,config:CONFIG,control:CONTROL});
function own(){try{var manifest=chrome.runtime.getManifest();
return manifest&&typeof manifest.version==='string'?manifest.version:'0.0.0'}catch(err){return '0.0.0'}}
L.own=own;
function vparts(value){if(typeof value!=='string'||!VERSION_RE.test(value))return null;
var out=value.split('.').map(Number);
while(out.length<4)out.push(0);
return out}
function newer(a,b){var x=vparts(a),y=vparts(b);
if(x===null||y===null)return false;
for(var i=0;i<4;i+=1){if(x[i]!==y[i])return x[i]>y[i]}
return false}
L.newer=newer;
function timeout(ms){try{return AbortSignal.timeout(ms)}catch(err){return undefined}}
function get(keys){return chrome.storage.local.get(keys).then(function(stored){return stored||{}},function(){return{}})}
function set(payload){return chrome.storage.local.set(payload)}
function plain(value){return !!value&&typeof value==='object'&&!Array.isArray(value)}
function sameCode(a,b){return plain(a)&&plain(b)&&a.version===b.version&&a.sha256===b.sha256}
function brief(meta){return plain(meta)?{version:meta.version,sha8:String(meta.sha256||'').slice(0,8)}:null}
function originOf(value){if(typeof value!=='string'||value===''||value.length>200)return null;
var url;
try{url=new URL(value)}catch(err){return null}
if(url.protocol!=='https:'||url.username!==''||url.password!==''||url.pathname!=='/'||url.search!==''||url.hash!=='')return null;
return url.origin}
L.originOf=originOf;
function listOf(control,field,wired){var out=[];
var extra=plain(control)&&Array.isArray(control[field])?control[field].slice(0,CONTROL_ORIGINS_MAX):[];
extra.concat(wired).forEach(function(one){var origin=originOf(one);
if(origin!==null&&out.indexOf(origin)<0)out.push(origin)});
return out}
function originList(control){return listOf(control,'origins',CODE_ORIGINS)}
function fileList(control){return listOf(control,'files',FILE_ORIGINS)}
L.CODE_ORIGINS=Object.freeze(CODE_ORIGINS.slice());
L.FILE_ORIGINS=Object.freeze(FILE_ORIGINS.slice());
L.OFFER_FALLBACKS=Object.freeze(OFFER_FALLBACKS.slice());
L.origins=function(){return readControl().then(originList)};
L.files=function(){return readControl().then(fileList)};
var originsNow=CODE_ORIGINS.slice();
var answeredNow=null;
L.origin=function(){return answeredNow!==null&&originsNow.indexOf(answeredNow)>=0?answeredNow:originsNow[0]};
function rememberOrigins(list,answered){if(Array.isArray(list)&&list.length>0)originsNow=list;
if(typeof answered==='string'&&answered!=='')answeredNow=answered}
var chain=Promise.resolve();
function serial(work){var next=chain.then(work,work);
chain=next.then(function(){},function(){});
return next}
function readState(){return get(STATE).then(function(stored){var kept=stored[STATE];
return plain(kept)?kept:{}})}
function writeState(state){var payload={};
payload[STATE]=state;
return set(payload).then(function(){return state},function(){return state})}
function log(kind,data){return get(LOG).then(function(stored){var list=Array.isArray(stored[LOG])?stored[LOG]:[];
var row=Object.assign({at:Date.now(),kind:kind},plain(data)?data:{});
var next=list.concat([row]).slice(-LOG_CAP);
var payload={};
payload[LOG]=next;
return set(payload).then(function(){return row},function(){return row})})}
L.log=function(kind,data){return serial(function(){return log(kind,data)})};
var keysOnce=null;
function b64bytes(value){var normal=String(value).replace(/-/g,'+').replace(/_/g,'/');
var padded=normal+'='.repeat((4-(normal.length%4))%4);
var binary=atob(padded);
var out=new Uint8Array(binary.length);
for(var i=0;i<binary.length;i+=1)out[i]=binary.charCodeAt(i);
return out}
L.b64bytes=b64bytes;
function keyShapes(text){var found=[];
if(typeof text!=='string')return found;
var objects=text.match(/\{[^{}]*\}/g)||[];
for(var i=0;i<objects.length;i+=1){var x=/["']?x["']?\s*:\s*["']([A-Za-z0-9_-]{43})["']/.exec(objects[i]);
var y=/["']?y["']?\s*:\s*["']([A-Za-z0-9_-]{43})["']/.exec(objects[i]);
if(x&&y)found.push({format:'jwk',data:{kty:'EC',crv:'P-256',x:x[1],y:y[1],ext:true}})}
var spki=text.match(/MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE[A-Za-z0-9+/]{86}={0,2}/g)||[];
for(var j=0;j<spki.length;j+=1)found.push({format:'spki',data:b64bytes(spki[j])});
var raw=text.match(/["'](B[A-Za-z0-9_-]{86})["']/g)||[];
for(var k=0;k<raw.length;k+=1)found.push({format:'raw',data:b64bytes(raw[k].slice(1,-1))});
return found}
L.keyShapes=keyShapes;
function keySource(){var listed=globalThis.ESHARIO_CODE_PUBLIC_KEYS;
if(Array.isArray(listed)&&listed.length>0){var shapes=[];
for(var i=0;i<listed.length;i+=1){var one=listed[i];
if(plain(one)&&typeof one.x==='string'&&typeof one.y==='string')shapes.push({format:'jwk',data:{kty:'EC',crv:'P-256',x:one.x,y:one.y,ext:true}})}
return Promise.resolve(shapes)}
return fetch(chrome.runtime.getURL(PUBLIC_KEY_PATH),{cache:'no-store'}).then(function(response){return response.ok?response.text():''}).then(keyShapes)}
function fingerprintOf(key){return crypto.subtle.exportKey('spki',key).then(function(der){return sha256hex(new Uint8Array(der))}).then(function(hex){return hex.slice(0,16)})}
function importRecord(shape,origin){return crypto.subtle.importKey(shape.format,shape.data,{name:'ECDSA',namedCurve:'P-256'},true,['verify']).then(function(key){return fingerprintOf(key).then(function(fp){return{key:key,fp:fp,origin:origin}})}).then(function(one){return one},function(){return null})}
function folderKeys(){if(keysOnce)return keysOnce;
keysOnce=keySource().then(function(shapes){return Promise.all(shapes.map(function(shape){return importRecord(shape,'folder')}))}).then(function(keys){var usable=keys.filter(Boolean);
if(usable.length===0)keysOnce=null;
return usable},function(){keysOnce=null;
return[]});
return keysOnce}
function publicKeys(){return Promise.all([folderKeys(),readControl()]).then(function(all){var folder=all[0],control=all[1];
var added=Array.isArray(control.added)?control.added:[];
return Promise.all(added.map(function(jwk){return importRecord({format:'jwk',data:{kty:'EC',crv:'P-256',x:jwk.x,y:jwk.y,ext:true}},'added')})).then(function(extra){var revoked=Array.isArray(control.revoked)?control.revoked:[];
var list=[],seen={};
folder.concat(extra.filter(Boolean)).forEach(function(one){if(revoked.indexOf(one.fp)>=0||seen[one.fp])return;
seen[one.fp]=true;
list.push(one)});
return list})})}
L.publicKeys=publicKeys;
function rawSignature(bytes){if(bytes.length===64)return bytes;
if(bytes.length<8||bytes[0]!==0x30)return null;
var at=2;
if(bytes[1]&0x80)at=2+(bytes[1]&0x7f);
var parts=[];
for(var n=0;n<2;n+=1){if(bytes[at]!==0x02)return null;
var len=bytes[at+1];
var body=bytes.subarray(at+2,at+2+len);
while(body.length>32&&body[0]===0)body=body.subarray(1);
if(body.length>32)return null;
var padded=new Uint8Array(32);
padded.set(body,32-body.length);
parts.push(padded);
at+=2+len}
var out=new Uint8Array(64);
out.set(parts[0],0);
out.set(parts[1],32);
return out}
function signerOf(bytes,sig){return publicKeys().then(function(keys){if(keys.length===0)return null;
var signature;
try{signature=rawSignature(b64bytes(sig))}catch(err){signature=null}
if(signature===null)return false;
var index=0;
function next(){if(index>=keys.length)return false;
var one=keys[index];
index+=1;
return crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},one.key,signature,bytes).then(function(ok){return ok===true?one:next()},function(){return next()})}
return next()})}
function verifySignature(bytes,sig){return signerOf(bytes,sig).then(function(one){return one===null?null:!!one})}
L.verifySignature=verifySignature;
function sha256hex(bytes){return crypto.subtle.digest('SHA-256',bytes).then(function(digest){var view=new Uint8Array(digest),out='';
for(var i=0;i<view.length;i+=1)out+=(view[i]<16?'0':'')+view[i].toString(16);
return out})}
L.sha256hex=sha256hex;
function parseOffer(body,origin,files,fromStatic){var from=originOf(origin===undefined?CODE_ORIGINS[0]:origin);
if(from===null||!plain(body))return null;
if(typeof body.version!=='string'||vparts(body.version)===null)return null;
if(typeof body.sha256!=='string'||!SHA_RE.test(body.sha256))return null;
if(!Number.isSafeInteger(body.bytes)||body.bytes<=0||body.bytes>MAX_BYTES)return null;
if(typeof body.sig!=='string'||!SIG_RE.test(body.sig))return null;
if(typeof body.minLoader!=='string'||vparts(body.minLoader)===null)return null;
if(typeof body.url!=='string'||body.url===''||body.url.length>300)return null;
var absolute=/^[a-z][a-z0-9+.-]*:/i.test(body.url)||body.url.indexOf('//')===0;
if(fromStatic===true&&!absolute)return null;
var url;
try{url=new URL(body.url,from)}catch(err){return null}
var allowed=Array.isArray(files)?files:FILE_ORIGINS;
if(url.protocol!=='https:'||url.username!==''||url.password!==''||url.hash!=='')return null;
if(absolute?(url.origin!==from&&allowed.indexOf(url.origin)<0):url.origin!==from)return null;
var tail=body.version+'/page-bundle.js';
if(!FILE_PATHS.some(function(head){return url.pathname===head+tail}))return null;
var ring=typeof body.ring==='string'&&RING_RE.test(body.ring)?body.ring:null;
return{version:body.version,sha256:body.sha256,bytes:body.bytes,sig:body.sig,minLoader:body.minLoader,url:url.href,ring:ring,origin:url.origin,offer:from,source:fromStatic===true?'static':'api'}}
L.parseOffer=parseOffer;
function accountId(){return get(SNAPSHOT).then(function(stored){var kept=stored[SNAPSHOT];
var id=plain(kept)&&plain(kept.answer)&&plain(kept.answer.account)?kept.answer.account.id:null;
return typeof id==='string'&&ACCT_RE.test(id)?id:''})}
function headerVersion(text){var first=text.slice(0,200).split('\n')[0];
var match=HEADER_RE.exec(first);
return match?match[1]:null}
var inFlight=null;
var devOnce=null;
var devLogged=false;
function devBuild(){if(devOnce)return devOnce;
var dev=false;
try{var groups=chrome.runtime.getManifest().web_accessible_resources||[];
dev=groups.some(function(group){return plain(group)&&Array.isArray(group.resources)&&group.resources.indexOf('page/*.js')>=0})}catch(err){dev=false}
devOnce=Promise.resolve(dev);
return devOnce}
L.devBuild=devBuild;
function check(reason){if(inFlight)return inFlight;
var why=typeof reason==='string'&&WHY_RE.test(reason)?reason:'manual';
inFlight=devBuild().then(function(dev){if(!dev)return serial(function(){return ask(why).then(function(result){return countFirst(result).then(function(){return result})})}).then(function(result){return ensureFirst().then(applyConfig).then(function(){return result})});
if(devLogged)return{ok:true,result:'dev'};
devLogged=true;
return L.log('code.dev',{reason:why}).then(function(){return{ok:true,result:'dev'}})}).then(function(result){inFlight=null;
return result},function(err){inFlight=null;
return{ok:false,reason:'loader-error',detail:String(err&&err.message||err)}});
return inFlight}
L.check=check;
function ask(why){return readState().then(function(state){var now=Date.now();
var floored=UNFLOORED.indexOf(why)<0;
if(floored&&Number.isSafeInteger(state.checkedAt)&&now>=state.checkedAt&&now-state.checkedAt<FLOOR_MS)return{ok:true,result:'floor'};
return Promise.all([accountId(),L.origins()]).then(function(got){var acct=got[0],list=got[1];
rememberOrigins(list,null);
var query=CODE_PATH+'?loader='+encodeURIComponent(own())+'&acct='+encodeURIComponent(acct);
var init={method:'GET',credentials:'omit',cache:'no-store',headers:{accept:'application/json'}};
function api(index){if(index>=list.length)return statics(0);
var origin=list[index];
return fetch(origin+query,Object.assign({signal:timeout(ASK_TIMEOUT_MS)},init)).then(function(response){if(response.status!==200&&response.status!==503)return miss(state,now,'http-'+response.status,why,origin,'api');
state.origin=origin;
rememberOrigins(list,origin);
if(response.status===503)return miss(state,now,'no-code',why,origin,'api');
return response.json().then(function(body){return offered(state,now,body,why,origin,'api')},function(){return miss(state,now,'bad-body',why,origin,'api')})},function(){return api(index+1)})}
function statics(index){if(index>=OFFER_FALLBACKS.length)return miss(state,now,'network',why,null,null,list.length+OFFER_FALLBACKS.length);
var address=OFFER_FALLBACKS[index];
var origin=new URL(address).origin;
return fetch(address,Object.assign({signal:timeout(ASK_TIMEOUT_MS)},init)).then(function(response){if(response.status!==200)return miss(state,now,'http-'+response.status,why,origin,'static');
return response.json().then(function(body){return offered(state,now,body,why,origin,'static')},function(){return miss(state,now,'bad-body',why,origin,'static')})},function(){return statics(index+1)})}
return api(0)})})}
function miss(state,now,reason,why,origin,source,tried){state.checkedAt=now;
state.lastError=reason;
var row={result:reason,why:why,origin:typeof origin==='string'?origin:null,source:source==='static'?'static':'api'};
if(Number.isSafeInteger(tried))row.tried=tried;
return writeState(state).then(function(){return log('code.check',row)}).then(function(){return{ok:true,result:reason}})}
function holds(offer){return get(CURRENT).then(function(stored){var kept=stored[CURRENT];
return plain(kept)&&typeof kept.text==='string'&&kept.text!==''&&sameCode(kept.meta,offer)})}
function offered(state,now,body,why,origin,source){var fromStatic=source==='static';
var config=fromStatic&&!(plain(body)&&plain(body.config))?Promise.resolve():saveConfig(body);
return config.then(function(){return noteUnsigned(body)}).then(function(){return applyControl(plain(body)?body.control:undefined,state)}).then(readControl).then(function(control){var offer=parseOffer(body,origin,fileList(control),fromStatic);
if(offer===null)return miss(state,now,'bad-body',why,origin,source);
if(typeof control.minVersion==='string'&&newer(control.minVersion,offer.version))return reject(state,now,offer,'below-min',why);
if(newer(offer.minLoader,own())){state.checkedAt=now;
state.lastError='minLoader';
var payload={};
payload[NEEDS]={version:offer.version,minLoader:offer.minLoader,at:now};
payload[STATE]=state;
return set(payload).then(function(){return log('code.reject',{version:offer.version,reason:'minLoader',minLoader:offer.minLoader,why:why})}).then(function(){return{ok:true,result:'needs-loader'}})}
return chrome.storage.local.remove(NEEDS).then(function(){},function(){}).then(function(){
if(sameCode(state.fallback,offer)){state.checkedAt=now;
return writeState(state).then(function(){return{ok:true,result:'fallback-held'}})}
return(sameCode(state.current,offer)?holds(offer):Promise.resolve(false)).then(function(kept){if(kept){state.checkedAt=now;
state.lastError=null;
return writeState(state).then(function(){return{ok:true,result:'same'}})}
if(sameCode(state.rejects,offer)&&state.rejects.count>=REJECT_LIMIT){state.checkedAt=now;
return writeState(state).then(function(){return{ok:true,result:'rejected-before'}})}
return download(state,now,offer,why)})})})}
function download(state,now,offer,why){return fetch(offer.url,{method:'GET',credentials:'omit',cache:'no-cache',signal:timeout(FETCH_TIMEOUT_MS)}).then(function(response){if(response.status!==200)return miss(state,now,'download-http-'+response.status,why,offer.origin,offer.source);
return response.arrayBuffer().then(function(buffer){var bytes=new Uint8Array(buffer);
if(bytes.byteLength!==offer.bytes)return reject(state,now,offer,'bytes',why);
return sha256hex(bytes).then(function(hex){if(hex!==offer.sha256)return reject(state,now,offer,'sha256',why);
return verifySignature(bytes,offer.sig).then(function(valid){if(valid!==true)return reject(state,now,offer,'signature',why);
var text;
try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes)}catch(err){return reject(state,now,offer,'utf8',why)}
if(headerVersion(text)!==offer.version)return reject(state,now,offer,'version',why);
return install(state,now,offer,text,why)})})},function(){return miss(state,now,'download-network',why,offer.origin,offer.source)})},function(){return miss(state,now,'download-network',why,offer.origin,offer.source)})}
function reject(state,now,offer,reason,why){var count=sameCode(state.rejects,offer)?state.rejects.count+1:1;
state.rejects={version:offer.version,sha256:offer.sha256,count:count};
state.checkedAt=now;
state.lastError=reason;
return writeState(state).then(function(){return log('code.reject',{version:offer.version,sha8:offer.sha256.slice(0,8),reason:reason,count:count,why:why,origin:offer.origin,source:offer.source})}).then(function(){return{ok:true,result:'reject',reason:reason}})}
function install(state,now,offer,text,why){return get(CURRENT).then(function(stored){var current=stored[CURRENT];
var hadCurrent=plain(current)&&plain(current.meta)&&typeof current.text==='string';
var bad=hadCurrent&&sameCode(state.fallback,current.meta);
var meta={version:offer.version,sha256:offer.sha256,bytes:offer.bytes,minLoader:offer.minLoader,sig:offer.sig,ring:offer.ring,installedAt:now};
var payload={};
payload[CURRENT]={meta:meta,text:text};
if(hadCurrent&&!bad){payload[PREVIOUS]=current;
state.previous={version:current.meta.version,sha256:current.meta.sha256}}
state.current={version:meta.version,sha256:meta.sha256};
state.fallback=null;
state.rejects=null;
state.boot=null;
state.lastError=null;
state.checkedAt=now;
payload[STATE]=state;
var started=Date.now();
return set(payload).then(function(){var ms=Date.now()-started;
state.writeMs=ms;
return writeState(state).then(function(){return log('code.set',{version:meta.version,sha8:meta.sha256.slice(0,8),bytes:meta.bytes,ring:meta.ring,ms:ms,askMs:Math.max(0,Date.now()-now),why:why,origin:offer.origin,offer:offer.offer,source:offer.source})}).then(function(){return{ok:true,result:'set',version:meta.version}})},function(err){state.lastError='storage';
return writeState(state).then(function(){return log('code.check',{result:'storage',why:why,detail:String(err&&err.message||err).slice(0,120)})}).then(function(){return{ok:false,result:'storage'}})})})}
function readControl(){return get(CONTROL).then(function(stored){var kept=stored[CONTROL];
return plain(kept)?kept:{}})}
L.readControl=readControl;
function parseControlText(text){var rec;
try{rec=JSON.parse(text)}catch(err){return null}
if(!plain(rec)||rec.v!==1||typeof rec.at!=='string'||!Number.isFinite(Date.parse(rec.at)))return null;
return{at:rec.at,atMs:Date.parse(rec.at),
revoke:Array.isArray(rec.revoke)?rec.revoke.filter(function(one){return typeof one==='string'&&FP_RE.test(one)}):[],
minVersion:typeof rec.minVersion==='string'&&vparts(rec.minVersion)!==null?rec.minVersion:null,
addKeys:Array.isArray(rec.addKeys)?rec.addKeys.filter(function(one){return plain(one)&&JWK_COORD_RE.test(String(one.x))&&JWK_COORD_RE.test(String(one.y))}).map(function(one){return{kty:'EC',crv:'P-256',x:one.x,y:one.y}}):[],
origins:controlList(rec.origins),
files:controlList(rec.files),
config:plain(rec.config)?signedPart(rec.config):null}}
function controlList(raw){return Array.isArray(raw)?raw.map(originOf).filter(function(one,i,all){return one!==null&&all.indexOf(one)===i}).slice(0,CONTROL_ORIGINS_MAX):null}
function applyControl(raw,state){if(raw===undefined||raw===null)return Promise.resolve(null);
if(!plain(raw)||typeof raw.text!=='string'||raw.text.length>CONTROL_MAX||typeof raw.sig!=='string'||!SIG_RE.test(raw.sig))return log('code.control',{result:'bad'}).then(function(){return null});
var rec=parseControlText(raw.text);
if(rec===null)return log('code.control',{result:'bad'}).then(function(){return null});
return readControl().then(function(kept){var keptMs=typeof kept.at==='string'?Date.parse(kept.at):NaN;
if(Number.isFinite(keptMs)&&rec.atMs<=keptMs)return null;
return signerOf(new TextEncoder().encode(raw.text),raw.sig).then(function(signer){if(!signer){if(kept.rejectedAt===rec.at)return null;
var marked=Object.assign({},kept,{rejectedAt:rec.at});
var payload={};
payload[CONTROL]=marked;
return set(payload).then(function(){return log('code.control',{result:'signature',at:rec.at})}).then(function(){return null})}
var revoked=Array.isArray(kept.revoked)?kept.revoked.slice():[];
rec.revoke.forEach(function(fp){if(fp!==signer.fp&&revoked.indexOf(fp)<0)revoked.push(fp)});
var added=Array.isArray(kept.added)?kept.added.slice():[];
rec.addKeys.forEach(function(jwk){if(!added.some(function(one){return one.x===jwk.x&&one.y===jwk.y}))added.push(jwk)});
var next={at:rec.at,revoked:revoked,added:added,minVersion:rec.minVersion!==null?rec.minVersion:(typeof kept.minVersion==='string'?kept.minVersion:null),signer:signer.fp,
origins:rec.origins!==null?rec.origins:(Array.isArray(kept.origins)?kept.origins:[]),
files:rec.files!==null?rec.files:(Array.isArray(kept.files)?kept.files:[]),
config:rec.config!==null?rec.config:(plain(kept.config)?kept.config:{})};
var payload={};
payload[CONTROL]=next;
return set(payload).then(function(){rememberOrigins(originList(next),null);
return log('code.control',{result:'applied',at:rec.at,signer:signer.fp,revoked:revoked.length,added:added.length,minVersion:next.minVersion,origins:next.origins.length,files:next.files.length,config:Object.keys(next.config),selfRevokeSkipped:rec.revoke.indexOf(signer.fp)>=0})}).then(function(){return dropBelowMin(next.minVersion,state)}).then(function(){return next})})})}
function dropBelowMin(min,state){if(typeof min!=='string')return Promise.resolve();
return get([CURRENT,PREVIOUS]).then(function(stored){var gone=[];
[[CURRENT,'current'],[PREVIOUS,'previous']].forEach(function(pair){var one=stored[pair[0]];
if(plain(one)&&plain(one.meta)&&newer(min,one.meta.version)){gone.push(pair[0]);
if(state)state[pair[1]]=null}});
if(gone.length===0)return;
return chrome.storage.local.remove(gone).then(function(){return log('code.below-min',{minVersion:min,removed:gone})})})}
function saveConfig(body){var next=plain(body)&&plain(body.config)?body.config:{};
var text;
try{text=JSON.stringify(next)}catch(err){return Promise.resolve()}
if(text.length>65536)return Promise.resolve();
return get(CONFIG).then(function(stored){var before;
try{before=JSON.stringify(stored[CONFIG]===undefined?null:stored[CONFIG])}catch(err){before=null}
if(before===text)return;
var payload={};
payload[CONFIG]=next;
return set(payload).then(function(){},function(){})})}
L.config=function(){return get(CONFIG).then(function(stored){return plain(stored[CONFIG])?stored[CONFIG]:{}})};
var SIGNED_FLAGS=['cspRelax','webapp','bridgeHosts','grantHosts','grantLabel','sidePanel','sidePanelUrl','injectAt'];
L.SIGNED_FLAGS=Object.freeze(SIGNED_FLAGS.slice());
function signedPart(raw){var out={};
if(!plain(raw))return out;
SIGNED_FLAGS.forEach(function(key){if(Object.prototype.hasOwnProperty.call(raw,key))out[key]=raw[key]});
return out}
function openPart(raw){var out={};
if(!plain(raw))return out;
Object.keys(raw).forEach(function(key){if(SIGNED_FLAGS.indexOf(key)<0)out[key]=raw[key]});
return out}
L.effectiveConfig=function(){return Promise.all([L.config(),readControl()]).then(function(all){return Object.assign(openPart(all[0]),plain(all[1].config)?signedPart(all[1].config):{})})};
var unsignedSeen='';
function noteUnsigned(body){var raw=plain(body)&&plain(body.config)?body.config:null;
if(raw===null)return Promise.resolve();
var names=SIGNED_FLAGS.filter(function(key){return Object.prototype.hasOwnProperty.call(raw,key)});
var said=names.join(',');
if(names.length===0||said===unsignedSeen)return Promise.resolve();
unsignedSeen=said;
return log('config.unsigned',{fields:names})}
var CSP_RULE_ID=8000;
var WEBAPP_DOC_FILTER='^https://www\\.ea\\.com/(?:[^?#]*/)?ultimate-team/web-app';
function cspRule(){return{id:CSP_RULE_ID,priority:1,
action:{type:'modifyHeaders',responseHeaders:[{header:'content-security-policy',operation:'remove'},{header:'content-security-policy-report-only',operation:'remove'}]},
condition:{regexFilter:WEBAPP_DOC_FILTER,requestDomains:['www.ea.com'],resourceTypes:['main_frame']}}}
L.CSP_RULE_ID=CSP_RULE_ID;
function applyCsp(config){var want=plain(config)&&config.cspRelax===true;
var dnr=chrome.declarativeNetRequest;
if(!dnr||typeof dnr.updateDynamicRules!=='function'||typeof dnr.getDynamicRules!=='function')return Promise.resolve(false);
return Promise.resolve(dnr.getDynamicRules()).then(function(rules){var has=(rules||[]).some(function(rule){return !!rule&&rule.id===CSP_RULE_ID});
if(want===has)return want;
var change=want?{removeRuleIds:[CSP_RULE_ID],addRules:[cspRule()]}:{removeRuleIds:[CSP_RULE_ID]};
return Promise.resolve(dnr.updateDynamicRules(change)).then(function(){return L.log('code.csp',{on:want})}).then(function(){return want})}).then(function(on){return on},function(){return false})}
var PANEL_PATH='account/panel.html';
L.PANEL_PATH=PANEL_PATH;
function applyPanel(config){var on=plain(config)&&config.sidePanel===true;
var panel=chrome.sidePanel;
if(!panel||typeof panel.setOptions!=='function')return Promise.resolve(false);
return Promise.resolve(panel.setOptions({path:PANEL_PATH,enabled:on})).then(function(){return on},function(){return false})}
var BRIDGE_ID='eshario-bridge-granted';
var BRIDGE_MAX=20;
var BRIDGE_RE=/^https:\/\/(?:\*\.)?(?:[a-z0-9-]+\.)+[a-z]{2,63}\/\*$/;
L.BRIDGE_ID=BRIDGE_ID;
function bridgePattern(value){if(typeof value!=='string'||value.length>200)return null;
var pattern=value.toLowerCase();
if(!BRIDGE_RE.test(pattern))return null;
var host=pattern.slice(8,-2).replace(/^\*\./,'');
if(host==='ea.com'||/\.ea\.com$/.test(host))return null;
if(typeof L.isSite==='function'&&L.isSite('https://'+host+'/'))return null;
return pattern}
L.bridgePattern=bridgePattern;
function patternHas(pattern,value){var url;
try{url=new URL(value)}catch(err){return false}
if(url.protocol!=='https:'||url.username!==''||url.password!=='')return false;
var host=pattern.slice(8,-2);
if(host.indexOf('*.')===0){var base=host.slice(2);
return url.hostname===base||url.hostname.slice(-(base.length+1))==='.'+base}
return url.hostname===host}
function bridgeHosts(){var scripting=chrome.scripting;
if(!scripting||typeof scripting.getRegisteredContentScripts!=='function')return Promise.resolve([]);
return Promise.resolve(scripting.getRegisteredContentScripts({ids:[BRIDGE_ID]})).then(function(list){return Array.isArray(list)&&list[0]&&Array.isArray(list[0].matches)?list[0].matches.slice():[]},function(){return[]})}
L.bridgeHosts=bridgeHosts;
function onBridgeHost(value){if(typeof value!=='string'||value.indexOf('https://')!==0)return Promise.resolve(false);
return bridgeHosts().then(function(list){return list.some(function(pattern){return patternHas(pattern,value)})})}
L.onBridgeHost=onBridgeHost;
function grantedOnly(patterns){var perms=chrome.permissions;
if(patterns.length===0||!perms||typeof perms.contains!=='function')return Promise.resolve([]);
return Promise.all(patterns.map(function(pattern){return Promise.resolve(perms.contains({origins:[pattern]})).then(function(yes){return yes===true?pattern:null},function(){return null})})).then(function(all){return all.filter(Boolean)})}
function applyBridge(config){var scripting=chrome.scripting;
if(!scripting||typeof scripting.registerContentScripts!=='function'||typeof scripting.getRegisteredContentScripts!=='function')return Promise.resolve([]);
var asked=plain(config)&&Array.isArray(config.bridgeHosts)?config.bridgeHosts:[];
var wanted=[];
asked.forEach(function(one){var pattern=bridgePattern(one);
if(pattern!==null&&wanted.indexOf(pattern)<0&&wanted.length<BRIDGE_MAX)wanted.push(pattern)});
return grantedOnly(wanted).then(function(granted){return bridgeHosts().then(function(have){var want=granted.slice().sort();
if(JSON.stringify(have.slice().sort())===JSON.stringify(want))return want;
var drop=have.length>0?Promise.resolve(scripting.unregisterContentScripts({ids:[BRIDGE_ID]})):Promise.resolve();
return drop.then(function(){if(want.length===0)return;
return scripting.registerContentScripts([{id:BRIDGE_ID,matches:want,js:['content/content.js'],runAt:'document_start',allFrames:false,persistAcrossSessions:true}])}).then(function(){return L.log('code.bridge',{hosts:want})}).then(function(){return want})})}).then(function(list){return list},function(){return[]})}
function applyConfig(){return devBuild().then(function(dev){if(dev)return null;
return L.effectiveConfig().then(function(config){return Promise.all([applyCsp(config),applyPanel(config),applyBridge(config)])})}).then(function(){},function(){})}
L.applyConfig=applyConfig;
L.needsLoader=function(){return get(NEEDS).then(function(stored){var kept=stored[NEEDS];
if(!plain(kept)||typeof kept.minLoader!=='string')return null;
return newer(kept.minLoader,own())?{version:kept.version,minLoader:kept.minLoader}:null})};
function boot(params,sender){var ok=!!(params&&params.ok===true);
var source=params&&typeof params.source==='string'?params.source:'';
var claimed={version:params&&params.version,sha256:params&&params.sha256};
return serial(function(){return readState().then(function(state){state.source=['server','previous','zip','module','none'].indexOf(source)>=0?source:null;
state.bootAt=Date.now();
if(source==='none')return writeState(state);
if(source!=='server'||!sameCode(state.current,claimed)){if(ok)return writeState(state);
return writeState(state).then(function(){return log('code.boot',{ok:false,source:source,version:typeof claimed.version==='string'?claimed.version:null})})}
if(ok){if(sameCode(state.boot,claimed))state.boot=null;
return writeState(state)}
var fails=(sameCode(state.boot,claimed)?state.boot.fails:0)+1;
state.boot={version:claimed.version,sha256:claimed.sha256,fails:fails};
var marked=fails>=BOOT_FAIL_LIMIT&&!sameCode(state.fallback,claimed);
if(marked)state.fallback={version:claimed.version,sha256:claimed.sha256};
return writeState(state).then(function(){return log('code.boot',{ok:false,source:source,version:claimed.version,fails:fails})}).then(function(){if(!marked)return;
return log('code.fallback',{version:claimed.version,to:plain(state.previous)?state.previous.version:'zip'})})})}).then(function(){
void check('boot');
if(ok&&sender&&sender.tab&&typeof L.flushPending==='function')void L.flushPending(sender.tab.id);
return{ok:true}})}
L.boot=boot;
L.status=function(){return Promise.all([readState(),get([LOG,NEEDS])]).then(function(all){var state=all[0],rest=all[1];
var needs=plain(rest[NEEDS])&&newer(rest[NEEDS].minLoader,own())?{version:rest[NEEDS].version,minLoader:rest[NEEDS].minLoader}:null;
return{loader:own(),current:brief(state.current),previous:brief(state.previous),source:typeof state.source==='string'?state.source:null,
checkedAt:Number.isSafeInteger(state.checkedAt)?state.checkedAt:null,lastError:typeof state.lastError==='string'?state.lastError:null,
fallback:brief(state.fallback),rejects:plain(state.rejects)?{version:state.rejects.version,count:state.rejects.count}:null,
needsLoader:needs,writeMs:Number.isSafeInteger(state.writeMs)?state.writeMs:null,
origin:typeof state.origin==='string'?state.origin:null,firstMisses:Number.isSafeInteger(state.firstMisses)?state.firstMisses:0,
log:Array.isArray(rest[LOG])?rest[LOG].slice(-20):[]}})};
function ensureAlarm(){try{return Promise.resolve(chrome.alarms.get(ALARM)).then(function(alarm){if(alarm)return;
return chrome.alarms.create(ALARM,{delayInMinutes:ALARM_MINUTES,periodInMinutes:ALARM_MINUTES})}).then(function(){},function(){})}catch(err){return Promise.resolve()}}
L.ensureAlarm=ensureAlarm;
function hasCode(kept){return plain(kept)&&plain(kept.meta)&&typeof kept.text==='string'&&kept.text!==''}
function firstStep(misses){var n=Number.isSafeInteger(misses)&&misses>0?misses:0;
return FIRST_STEPS[Math.min(FIRST_STEPS.length-1,Math.floor(n/FIRST_STEP_AFTER))]}
L.firstStep=firstStep;
function countFirst(result){var asked=plain(result)&&result.result!=='floor';
return get([CURRENT,STATE]).then(function(stored){var state=plain(stored[STATE])?stored[STATE]:{};
var misses=Number.isSafeInteger(state.firstMisses)?state.firstMisses:0;
var next=hasCode(stored[CURRENT])?0:(asked?misses+1:misses);
if(next===misses)return;
state.firstMisses=next;
return writeState(state)})}
function ensureFirst(){return devBuild().then(function(dev){return dev?null:get([CURRENT,STATE])}).then(function(stored){if(stored===null)return;
var missing=!hasCode(stored[CURRENT]);
var state=plain(stored[STATE])?stored[STATE]:{};
var step=firstStep(state.firstMisses);
return Promise.resolve(chrome.alarms.get(FIRST_ALARM)).then(function(alarm){if(missing&&(!alarm||alarm.periodInMinutes!==step))return chrome.alarms.create(FIRST_ALARM,{delayInMinutes:step,periodInMinutes:step});
if(!missing&&alarm)return chrome.alarms.clear(FIRST_ALARM)})}).then(function(){},function(){})}
L.ensureFirst=ensureFirst;
var EA_PAGE_RE=/^https:\/\/(?:[a-z0-9-]+\.)*ea\.com\//;
var MAIN_PARTS=4;
var MAIN_ATTR_RE=/^eshario[A-Z][A-Za-z]{0,30}$/;
function mainParts(params){var parts=plain(params)&&Array.isArray(params.parts)?params.parts:null;
if(parts===null||parts.length===0||parts.length>MAIN_PARTS)return null;
var out=[];
for(var i=0;i<parts.length;i+=1){var one=parts[i];
if(!plain(one)||typeof one.text!=='string'||one.text==='')return null;
var attrs=null;
if(one.attrs!==null&&one.attrs!==undefined){if(!plain(one.attrs))return null;
attrs={};
var keys=Object.keys(one.attrs);
for(var k=0;k<keys.length;k+=1){var value=one.attrs[keys[k]];
if(!MAIN_ATTR_RE.test(keys[k])||typeof value!=='string'||value.length>300)return null;
attrs[keys[k]]=value}}
out.push({text:one.text,attrs:attrs})}
return out}
function intoPage(parts){var out={ran:0,injectMs:null,nonce:false};
var nonce='';
try{var seen=document.querySelector('script[nonce]');
if(seen)nonce=String(seen.nonce||seen.getAttribute('nonce')||'')}catch(e){}
for(var i=0;i<parts.length;i+=1){try{var node=document.createElement('script');
var attrs=parts[i].attrs;
if(attrs)for(var key in attrs)node.dataset[key]=attrs[key];
if(nonce!==''){node.nonce=nonce;
out.nonce=true}
node.textContent=parts[i].text;
var started=performance.now();
(document.head||document.documentElement).appendChild(node);
if(i===0)out.injectMs=Math.round(performance.now()-started);
node.remove();
out.ran+=1}catch(e){}}
return out}
function toMain(params,sender){var parts=mainParts(params);
if(parts===null)return Promise.resolve({ok:false,reason:'parts'});
var self='';
try{self=chrome.runtime.id}catch(err){}
var tab=sender&&sender.tab&&Number.isSafeInteger(sender.tab.id)?sender.tab.id:null;
var url=sender&&typeof sender.url==='string'?sender.url:'';
if(tab===null||(self&&sender.id!==self))return Promise.resolve({ok:false,reason:'sender'});
return(EA_PAGE_RE.test(url)?Promise.resolve(true):onBridgeHost(url)).then(function(ours){if(!ours)return{ok:false,reason:'sender'};
var target=typeof sender.documentId==='string'&&sender.documentId!==''?{tabId:tab,documentIds:[sender.documentId]}:{tabId:tab,frameIds:[Number.isSafeInteger(sender.frameId)?sender.frameId:0]};
var run;
try{run=chrome.scripting.executeScript({target:target,world:'MAIN',injectImmediately:true,func:intoPage,args:[parts]})}catch(err){run=Promise.reject(err)}
return Promise.resolve(run).then(function(results){var got=Array.isArray(results)&&results[0]&&plain(results[0].result)?results[0].result:null;
return{ok:true,ran:got&&Number.isSafeInteger(got.ran)?got.ran:null,injectMs:got&&Number.isSafeInteger(got.injectMs)?got.injectMs:null}},function(){return{ok:false,reason:'scripting'}})})}
L.intoPage=intoPage;
function onMessage(message,sender,sendResponse){if(!message||typeof message.method!=='string')return false;
var work=null;
if(message.method==='code.main')work=toMain(message.params,sender);
else if(message.method==='code.boot')work=boot(message.params,sender);
else if(message.method==='code.focus')work=check('focus').then(function(){return{ok:true}});
else if(message.method==='code.status')work=L.status();
else if(message.method==='door'&&typeof L.door==='function')work=L.door(message.params,sender);
if(work===null)return false;
work.then(sendResponse,function(){sendResponse({ok:false,reason:'loader-error'})});
return true}
try{chrome.runtime.onMessage.addListener(onMessage)}catch(err){}
try{chrome.alarms.onAlarm.addListener(function(alarm){if(alarm&&alarm.name===ALARM)void check('alarm');
if(alarm&&alarm.name===FIRST_ALARM)void check('first')})}catch(err){}
try{chrome.runtime.onStartup.addListener(function(){void check('start')})}catch(err){}
try{chrome.runtime.onInstalled.addListener(function(){void check('install')})}catch(err){}
void ensureAlarm();
void ensureFirst();
void Promise.all([readState(),readControl()]).then(function(all){rememberOrigins(originList(all[1]),typeof all[0].origin==='string'?all[0].origin:null)},function(){});
void applyConfig();
})()
