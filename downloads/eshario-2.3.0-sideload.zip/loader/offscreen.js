(function(){'use strict';
var TARGET='eshario-offscreen';
function pad(){var node=document.getElementById('pad');
if(!node){node=document.createElement('textarea');
node.id='pad';
document.body.appendChild(node)}
return node}
function copy(text){var node=pad();
node.value=text;
node.select();
var ok=document.execCommand('copy');
node.value='';
return ok?{ok:true,value:true}:{ok:false,reason:'copy'}}
function paste(){var node=pad();
node.value='';
node.focus();
var ok=document.execCommand('paste');
var text=node.value;
node.value='';
return ok?{ok:true,value:text}:{ok:false,reason:'paste'}}
function play(data){return new Promise(function(resolve){try{var audio=new Audio(data.src);
audio.volume=typeof data.volume==='number'?data.volume:1;
audio.play().then(function(){resolve({ok:true,value:true})},function(){resolve({ok:false,reason:'audio'})})}catch(err){resolve({ok:false,reason:'audio'})}})}
chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){if(!message||message.target!==TARGET)return false;
var data=message.data&&typeof message.data==='object'?message.data:{};
var work;
try{if(message.op==='clipboard.write')work=Promise.resolve(copy(typeof data.text==='string'?data.text:''));
else if(message.op==='clipboard.read')work=Promise.resolve(paste());
else if(message.op==='audio.play')work=play(data);
else work=Promise.resolve({ok:false,reason:'no-op'})}catch(err){work=Promise.resolve({ok:false,reason:'offscreen'})}
work.then(sendResponse);
return true});
})()
