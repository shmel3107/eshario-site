export const SUPPORTED_LOCALES=Object.freeze(['en','ru'])
export const DEFAULT_LOCALE='en'
export const RUSSIAN_TIME_ZONES=Object.freeze([
'Europe/Kaliningrad','Europe/Moscow','Europe/Kirov','Europe/Volgograd','Europe/Astrakhan',
'Europe/Saratov','Europe/Ulyanovsk','Europe/Samara','Asia/Yekaterinburg','Asia/Omsk',
'Asia/Novosibirsk','Asia/Barnaul','Asia/Tomsk','Asia/Novokuznetsk','Asia/Krasnoyarsk',
'Asia/Irkutsk','Asia/Chita','Asia/Yakutsk','Asia/Khandyga','Asia/Vladivostok',
'Asia/Ust-Nera','Asia/Magadan','Asia/Sakhalin','Asia/Srednekolymsk','Asia/Kamchatka','Asia/Anadyr',
'Europe/Minsk',
'Asia/Almaty','Asia/Aqtau','Asia/Aqtobe','Asia/Atyrau','Asia/Oral','Asia/Qostanay','Asia/Qyzylorda',
'Asia/Bishkek','Asia/Samarkand','Asia/Tashkent','Asia/Dushanbe',
'Asia/Yerevan','Asia/Tbilisi'])
const ZONE_LOCALE='ru'
export function currentTimeZone(){try{const zone=new Intl.DateTimeFormat().resolvedOptions().timeZone
return typeof zone==='string'&&zone!==''?zone:null}catch{return null}}
export function detectLocale(preferences,timeZone=null){const list=typeof preferences==='string'?[preferences]:(preferences??[])
for(const tag of list){if(typeof tag!=='string') continue
const primary=tag.toLowerCase().split('-')[0]
if(primary!==DEFAULT_LOCALE&&SUPPORTED_LOCALES.includes(primary))return primary}
if(typeof timeZone==='string'&&RUSSIAN_TIME_ZONES.includes(timeZone))return ZONE_LOCALE
return DEFAULT_LOCALE}
export function chooseLocale(chosen,preferences,timeZone=null){
if(typeof chosen==='string'&&chosen!=='')return detectLocale(chosen)
return detectLocale(preferences,timeZone)}
