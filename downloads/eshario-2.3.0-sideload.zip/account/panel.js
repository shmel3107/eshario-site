import { startPanel } from './shell.js';
await startPanel(window).catch(() => null);
