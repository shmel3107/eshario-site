import { startAccountUi } from './account-ui.js';
import { startShell } from './shell.js';
await Promise.all([startShell(window).catch(() => null), startAccountUi()]);
