export const DEFAULT_ACCOUNT_PAGE='https://eshario.com/app/account/'
export const SITE_DOMAINS=['eshario.com','eshario.app']
export const SITE_PROBE_MS=2500
const CHANNEL='fut-companion'
const FROM_PAGE='fut-companion/page'
const FROM_SHELL='fut-companion/content'
export function siteUrl(value){if(typeof value!=='string'||value===''||value.length>500)return null
let url
try{url=new URL(value)}catch{return null}
if(url.protocol!=='https:'||url.username!==''||url.password!=='')return null
if(!SITE_DOMAINS.some((domain)=>url.hostname===domain||url.hostname.endsWith(`.${domain}`)))return null
return url}
export function accountPageOf(config){const raw=config&&typeof config==='object'?config.accountPage:undefined
if(raw===undefined||raw===null||raw==='')return siteUrl(DEFAULT_ACCOUNT_PAGE)
return siteUrl(raw)}
export function panelUrlOf(config){const raw=config&&typeof config==='object'?config.sidePanelUrl:undefined
return typeof raw==='string'&&raw!==''?siteUrl(raw):null}
const GRANT_RE=/^https:\/\/(?:\*\.)?(?:[a-z0-9-]+\.)+[a-z]{2,63}\/\*$/
const GRANT_MAX=20
export function grantHostsOf(config){const raw=config&&typeof config==='object'&&Array.isArray(config.grantHosts)?config.grantHosts:[]
const out=[]
for(const one of raw.slice(0,GRANT_MAX)){if(typeof one==='string'&&GRANT_RE.test(one)&&!out.includes(one))out.push(one)}
return out}
function langOf(win){try{return /^ru/i.test(String(win.navigator?.language??''))?'ru':'en'}catch{return 'en'}}
export function grantLabelOf(config,lang){const raw=config&&typeof config==='object'?config.grantLabel:undefined
const pick=typeof raw==='string'?raw:raw&&typeof raw==='object'?raw[lang]:undefined
if(typeof pick==='string'&&pick.trim()!==''&&pick.length<=60)return pick.trim()
return lang==='ru'?'Разрешить доступ':'Allow access'}
export const PANEL_EMPTY={ru:'ESHArio: панель ещё не включена',en:'ESHArio: the panel is not enabled yet'}
async function readConfig(send){try{const answer=await send({method:'door',params:{name:'config.get',args:null}})
if(answer&&answer.ok===true&&answer.value&&typeof answer.value==='object')return answer.value}catch{/* фон молчит */}
return{}}
async function siteAlive(probe,url){try{let signal
try{signal=AbortSignal.timeout(SITE_PROBE_MS)}catch{signal=undefined}
const response=await probe(url.href,{method:'GET',credentials:'omit',cache:'no-store',signal})
return!!response&&response.ok===true}catch{return false}}
export async function startShell(win,deps={}){const send=deps.send??((message)=>chrome.runtime.sendMessage(message))
const probe=deps.fetch??((url,init)=>win.fetch(url,init))
const perms=deps.permissions??(typeof chrome!=='undefined'?chrome.permissions:undefined)
let asked=''
try{asked=new URL(win.location.href).searchParams.get('ask')??''}catch{asked=''}
if(asked!=='')return{mode:'local',reason:'ask'}
const config=await readConfig(send)
const grant=await mountGrant(win,config,perms)
const url=accountPageOf(config)
if(url===null)return withGrant({mode:'local',reason:'outside-passport'},grant)
if(!await siteAlive(probe,url))return withGrant({mode:'local',reason:'site-silent'},grant)
const frame=mountFrame(win,url)
relay(win,frame,url,send,perms)
return withGrant({mode:'site',url:url.href},grant)}
function withGrant(result,grant){return grant===null?result:{...result,grant:true}}
async function mountGrant(win,config,perms){const hosts=grantHostsOf(config)
if(hosts.length===0||!perms||typeof perms.contains!=='function'||typeof perms.request!=='function')return null
let has=true
try{has=await perms.contains({origins:hosts})}catch{has=true}
if(has===true)return null
const doc=win.document
const button=doc.createElement('button')
button.type='button'
button.className='fx-action fx-grant'
button.dataset.futGrant='1'
button.textContent=grantLabelOf(config,langOf(win))
button.addEventListener('click',()=>{let asked
try{asked=perms.request({origins:hosts})}catch{asked=Promise.resolve(false)}
Promise.resolve(asked).then((given)=>{if(given===true)button.remove()},()=>{})})
doc.body.insertBefore(button,doc.body.firstChild??null)
return button}
export async function startPanel(win,deps={}){const send=deps.send??((message)=>chrome.runtime.sendMessage(message))
const probe=deps.fetch??((url,init)=>win.fetch(url,init))
const perms=deps.permissions??(typeof chrome!=='undefined'?chrome.permissions:undefined)
const doc=win.document
const line=doc.querySelector('[data-panel-line]')
if(line)line.textContent=PANEL_EMPTY[langOf(win)]
const config=await readConfig(send)
const url=panelUrlOf(config)
if(url===null)return{mode:'empty',reason:'no-url'}
if(!await siteAlive(probe,url))return{mode:'empty',reason:'site-silent'}
const frame=mountFrame(win,url)
relay(win,frame,url,send,perms)
return{mode:'site',url:url.href}}
function mountFrame(win,url){const doc=win.document
const main=doc.querySelector('main')
if(main)main.hidden=true
const frame=doc.createElement('iframe')
frame.src=url.href
frame.title='ESHArio'
frame.setAttribute('data-fut-shell','1')
frame.style.border='0'
frame.style.width='100%'
frame.style.minWidth='360px'
const shell=doc.documentElement.dataset.shell
frame.style.height=shell==='tab'||shell==='panel'?'100vh':'580px'
frame.style.display='block'
doc.body.appendChild(frame)
return frame}
function relay(win,frame,url,send,perms){win.addEventListener('message',(event)=>{if(event.source!==frame.contentWindow)return
if(event.origin!==url.origin)return
const msg=event.data
if(!msg||msg.channel!==CHANNEL||msg.from!==FROM_PAGE||msg.kind!=='request'||typeof msg.method!=='string')return
const answer=(value)=>{try{frame.contentWindow.postMessage({channel:CHANNEL,from:FROM_SHELL,kind:'response',id:msg.id,ok:true,value},url.origin)}catch{/* рамка ушла */}}
if(msg.method==='hello'){answer({ok:true,value:{installed:true,shell:true}})
return}
if(msg.method!=='door'){answer({ok:false,reason:'no-method'})
return}
const name=msg.params&&typeof msg.params.name==='string'?msg.params.name:''
if(name==='perm.request'){requestHere(perms,msg.params.args).then(answer)
return}
Promise.resolve().then(()=>send({method:'door',params:{name,args:msg.params?.args??null}})).then((result)=>answer(result&&typeof result.ok==='boolean'?result:{ok:false,reason:'no-response'}),()=>answer({ok:false,reason:'no-port'}))})}
function requestHere(perms,args){const origins=args&&Array.isArray(args.origins)?args.origins:[]
const permissions=args&&Array.isArray(args.permissions)?args.permissions:[]
const good=origins.length+permissions.length>0&&origins.length<=GRANT_MAX&&permissions.length<=GRANT_MAX&&origins.every((one)=>typeof one==='string'&&/^https:\/\/\S{1,200}$/.test(one))&&permissions.every((one)=>typeof one==='string'&&/^[A-Za-z]{2,40}$/.test(one))
if(!good)return Promise.resolve({ok:false,reason:'bad-args'})
if(!perms||typeof perms.request!=='function')return Promise.resolve({ok:false,reason:'permissions'})
const set={}
if(origins.length>0)set.origins=origins.slice()
if(permissions.length>0)set.permissions=permissions.slice()
let asked
try{asked=perms.request(set)}catch{return Promise.resolve({ok:false,reason:'gesture'})}
return Promise.resolve(asked).then((given)=>({ok:true,value:given===true}),()=>({ok:false,reason:'gesture'}))}
