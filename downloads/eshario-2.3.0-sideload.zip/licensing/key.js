import{FREE,PREMIUM} from './features.js'
import{LICENSE_PUBLIC_KEYS,PARTNER_KEYS} from './public-key.js'
import{createCachedProvider} from '../core/storage-provider.js'
export const LICENSE_STORAGE_KEY='license.key'
export const LICENSE_READ='license.read'
export const LICENSE_WRITE='license.write'
export function sanitizeLicenseKey(stored){return typeof stored==='string'?stored:''
}
export function createBridgeLicenseProvider(opts){const bridge=opts?.bridge
if(!bridge||typeof bridge.request!=='function') throw new Error('licensing: мост недоступен')
return createCachedProvider({fetch:()=>bridge.request(LICENSE_READ),push:(value)=>bridge.request(LICENSE_WRITE,value),sanitize:sanitizeLicenseKey,fallback:()=>'',onError:opts.onError})}
export const LICENSE_PREFIX='futc1'
export const ALG=Object.freeze({P256:'p256',ED25519:'ed25519'})
export const REJECT=Object.freeze({EMPTY:'empty',SHAPE:'bad-shape',ALGORITHM:'unknown-algorithm',PAYLOAD:'bad-payload',SIGNATURE:'bad-signature',EXPIRED:'expired',PLAN:'bad-plan',CRYPTO:'no-crypto'
})
export const REJECT_KEYS=Object.freeze({[REJECT.EMPTY]:'license.reason.empty',[REJECT.SHAPE]:'license.reason.bad-shape',[REJECT.ALGORITHM]:'license.reason.unknown-algorithm',[REJECT.PAYLOAD]:'license.reason.bad-payload',[REJECT.SIGNATURE]:'license.reason.bad-signature',[REJECT.EXPIRED]:'license.reason.expired',[REJECT.PLAN]:'license.reason.bad-plan',[REJECT.CRYPTO]:'license.reason.no-crypto'
})
export function rejectLabelKey(reason){return REJECT_KEYS[reason]??REJECT_KEYS[REJECT.SHAPE]}
export function publicKeysOf(value){const list=Array.isArray(value)?value:[value]
return list.filter((key)=>typeof key==='string'&&key!=='')}
export const ACCOUNT_ONLY_FIELDS=Object.freeze(['sub','quota','v'])
export function looksLikeAccountEntitlement(payload){if(!payload||typeof payload!=='object')return false
return ACCOUNT_ONLY_FIELDS.some((field)=>Object.hasOwn(payload,field))}
const ALGORITHMS={[ALG.P256]:{importParams:{name:'ECDSA',namedCurve:'P-256'},verifyParams:{name:'ECDSA',hash:'SHA-256'}},[ALG.ED25519]:{importParams:{name:'Ed25519'},verifyParams:{name:'Ed25519'}}}
export function parseLicenseKey(token){const fail=(reason)=>({ok:false,reason,alg:null,payload:null,signed:null,signature:null})
if(typeof token!=='string'||token.trim()==='') return fail(REJECT.EMPTY)
const parts=token.trim().split('.')
if(parts.length!==4)return fail(REJECT.SHAPE)
const[prefix,alg,payloadPart,signature]=parts
if(prefix!==LICENSE_PREFIX)return fail(REJECT.SHAPE)
if(!Object.hasOwn(ALGORITHMS,alg))return fail(REJECT.ALGORITHM)
if(payloadPart===''||signature==='') return fail(REJECT.SHAPE)
let payload
try{payload=JSON.parse(new TextDecoder().decode(fromBase64Url(payloadPart)))}catch{return fail(REJECT.PAYLOAD)}
if(!payload||typeof payload!=='object'||Array.isArray(payload)) return fail(REJECT.PAYLOAD)
if(!Number.isFinite(payload.exp))return fail(REJECT.PAYLOAD)
if(payload.plan!==PREMIUM)return fail(REJECT.PLAN)
return{ok:true,reason:null,alg,payload,signed:`${prefix}.${alg}.${payloadPart}`,signature}}
export async function verifyLicenseKey(token,opts={}){const parsed=parseLicenseKey(token)
const no=(reason,exp=null)=>({ok:false,reason,plan:FREE,exp,note:null})
if(!parsed.ok)return no(parsed.reason)
const subtle=opts.subtle??globalThis.crypto?.subtle
if(!subtle||typeof subtle.importKey!=='function') return no(REJECT.CRYPTO)
const keys=opts.keys??LICENSE_PUBLIC_KEYS
const candidates=publicKeysOf(keys?.[parsed.alg])
if(candidates.length===0) return no(REJECT.ALGORITHM)
const spec=ALGORITHMS[parsed.alg]
let valid=false,broke=false
for(const publicKey of candidates){try{const key=await subtle.importKey('raw',fromBase64Url(publicKey),spec.importParams,false,['verify'])
valid=await subtle.verify(spec.verifyParams,key,fromBase64Url(parsed.signature),new TextEncoder().encode(parsed.signed))}catch{
broke=true}
if(valid===true)break}
if(valid!==true)return no(broke?REJECT.CRYPTO:REJECT.SIGNATURE)
const now=Number.isFinite(opts.now)?opts.now:Number.NaN
if(!Number.isFinite(now))return no(REJECT.EXPIRED,parsed.payload.exp)
if(parsed.payload.exp<=now)return no(REJECT.EXPIRED,parsed.payload.exp)
return{ok:true,reason:null,plan:PREMIUM,exp:parsed.payload.exp,note:typeof parsed.payload.note==='string'?parsed.payload.note:null}}
export function createKeyProvider(deps={}){const clock=deps.clock
if(!clock||typeof clock.now!=='function'){throw new Error('licensing: нужны часы (правило 6 NIGHT_BRIEF)')}
const storage=deps.provider??null
let state={plan:FREE,exp:null,reason:null,note:null}
const check=(token)=>{const parsed=parseLicenseKey(token)
if(parsed.ok&&looksLikeAccountEntitlement(parsed.payload))return Promise.resolve({ok:false,reason:REJECT.SHAPE,plan:FREE,exp:null,note:null})
return verifyLicenseKey(token,{now:clock.now(),subtle:deps.subtle,keys:deps.keys??PARTNER_KEYS})}
const apply=(result)=>{state={plan:result.ok?PREMIUM:FREE,exp:result.exp,reason:result.reason,note:result.note??null}
return state}
const stored=()=>{if(!storage)return null
try{const value=storage.read()
return typeof value==='string'&&value!==''?value:null}catch{return null}}
const visible=()=>({unlocked:state.plan===PREMIUM,exp:state.exp,reason:state.reason,note:state.note,hasKey:stored()!==null})
return{
getPlan:()=>state.plan,
state:visible,
async load(){const token=stored()
if(token===null){state={plan:FREE,exp:null,reason:null,note:null}
return state}
return apply(await check(token))},
async setKey(token){const value=typeof token==='string'?token.trim():''
if(value===''){if(storage){try{storage.write('')}catch{
}}
state={plan:FREE,exp:null,reason:null,note:null}
return visible()}
const result=await check(value)
apply(result)
if(result.ok&&storage){try{storage.write(value)}catch{
}}
return visible()}}}
export function fromBase64Url(value){const normal=String(value).replace(/-/g,'+').replace(/_/g,'/')
const padded=normal+'='.repeat((4-(normal.length%4))%4)
const binary=atob(padded)
const bytes=new Uint8Array(binary.length)
for(let i=0;i<binary.length;i+=1)bytes[i]=binary.charCodeAt(i);
return bytes}
export function toBase64Url(bytes){let binary=''
for(const byte of new Uint8Array(bytes))binary+=String.fromCharCode(byte);
return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
