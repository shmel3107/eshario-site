export const BUY_URL = Object.freeze({ ru: 'https://eshario.com/ru/buy/', en: 'https://eshario.com/buy/' });
export const buyUrlOf = (locale) => (typeof locale === 'string' && Object.hasOwn(BUY_URL, locale) ? BUY_URL[locale] : BUY_URL.en);
