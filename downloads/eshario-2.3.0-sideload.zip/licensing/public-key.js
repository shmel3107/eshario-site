export const ACCOUNT_PUBLIC_KEY='BOJm0Fcao9nrtLL6IcfITJScrX2s5d3RqEjMb6witprQbtG_qVFZjZKpcB8ctArV8cy4VoBL_I0oWQV7rF6epJU'
export const PARTNER_PUBLIC_KEY='BGyrOlCOLjls9NyLxbpE45WA3EfCU1_eXIesqg009XAZXYWgr40ZGKhR1izDlPlnNegY2QXjmooXkB8cjh_9-Gc'
export const PARTNER_KEYS=Object.freeze({p256:Object.freeze([PARTNER_PUBLIC_KEY]),ed25519:Object.freeze([])})
export const ACCOUNT_KEYS=Object.freeze({p256:Object.freeze([ACCOUNT_PUBLIC_KEY]),ed25519:Object.freeze([])})
export const LICENSE_PUBLIC_KEYS=Object.freeze({p256:Object.freeze([ACCOUNT_PUBLIC_KEY,PARTNER_PUBLIC_KEY]),ed25519:Object.freeze([])
})
