export const FREE='free'
export const PREMIUM='premium'
export const FEATURES=Object.freeze({
autologin:{tier:FREE,phase:2},
hotkeyNav:{tier:FREE,phase:23},
headBar:{tier:FREE,phase:21},
navCenter:{tier:FREE,phase:21},
dropdownSearch:{tier:FREE,phase:24},
priceBadges:{tier:PREMIUM,phase:14},
minBinSearch:{tier:PREMIUM,phase:2},
eaTax:{tier:PREMIUM,phase:2},
hotkeys:{tier:PREMIUM,phase:2},
advancedFilters:{tier:PREMIUM,phase:3},autoBuyer:{tier:PREMIUM,phase:4},autoSeller:{tier:PREMIUM,phase:5},sbcSolver:{tier:PREMIUM,phase:6},clubAnalysis:{tier:PREMIUM,phase:7},priceSources:{tier:PREMIUM,phase:7},
notifications:{tier:PREMIUM,phase:11},enhancedTransferList:{tier:PREMIUM,phase:13},enhancedUnassignedList:{tier:PREMIUM,phase:13},enhancedObjectivesList:{tier:PREMIUM,phase:13},enhancedClubList:{tier:PREMIUM,phase:13},
packGrid:{tier:PREMIUM,phase:15},
sbcAutoBuy:{tier:PREMIUM,phase:16},
pickByPrice:{tier:PREMIUM,phase:17},
cardGrid:{tier:PREMIUM,phase:18},
clubBar:{tier:PREMIUM,phase:19},
hubRewards:{tier:PREMIUM,phase:20},
autoSnipe:{tier:PREMIUM,phase:22},
homeLayout:{tier:FREE,phase:23},
unassignedTools:{tier:PREMIUM,phase:23},
squadScreen:{tier:PREMIUM,phase:24},
packPeek:{tier:PREMIUM,phase:25},
dimOwned:{tier:PREMIUM,phase:26},
packShow:{tier:PREMIUM,phase:27},
gallery:{tier:PREMIUM,phase:28},
hubUnlock:{tier:FREE,phase:29},
promoClose:{tier:FREE,phase:23}})
export const EXPECTED_FREE=Object.freeze(['autologin','dropdownSearch','headBar','homeLayout','hotkeyNav','hubUnlock','navCenter','promoClose'])
export function featuresByTier(tier){return Object.entries(FEATURES)
.filter(([,meta])=>meta.tier===tier)
.map(([id])=>id)
.sort()}
