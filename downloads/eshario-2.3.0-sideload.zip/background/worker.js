(function(){'use strict';
var PRICE_ORIGIN='https://r2.fut.gg';
var PRICE_PATH_RE=/^\/[0-9]+\/(?:manifest\.json|[a-z0-9][a-z0-9-]{0,40}\.v[0-9]+\.[A-Za-z0-9_-]+\.json)$/;
var MANIFEST_PATH_RE=/^\/[0-9]+\/manifest\.json$/;
var METHOD='price.fetch';
var ACCOUNT_ORIGIN='https://api.eshario.com';
function accountOrigin(){if(typeof ACCOUNT_ORIGIN!=='string'||ACCOUNT_ORIGIN==='')return '';
var loader=globalThis.esharioLoader;
var live=loader&&typeof loader.origin==='function'?loader.origin():null;
return typeof live==='string'&&live!==''?live:ACCOUNT_ORIGIN}
var ACCOUNT_SESSION_KEY='account.session';
var ACCOUNT_DEVICE_KEY='account.device';
var ACCOUNT_SNAPSHOT_KEY='account.snapshot';
var ACCOUNT_DENIED_KEY='account.denied';
var ACCOUNT_TIMEOUT_MS=5000;
var ACCOUNT_CACHE_MS=604800000;
var ACCOUNT_CLOCK_SKEW_MS=300000;
var ACCOUNT_FRESH_MS=21600000;
var accountAsked=false;
function isAllowedUrl(url,origin){if(typeof url!=='string'||url==='') return false;
var parsed;
try{parsed=new URL(url)}catch(err){return false}
return parsed.protocol==='https:'&&parsed.origin===origin}
function isAllowedPriceUrl(url){if(!isAllowedUrl(url,PRICE_ORIGIN))return false;
try{var parsed=new URL(url);
return parsed.search===''&&parsed.hash===''&&PRICE_PATH_RE.test(parsed.pathname)}catch(err){return false}}
var SBC_ORIGIN='https://www.fut.gg';
var SBC_LIST_PATH='/api/fut/sbc/';
var SBC_VOTES_PATH='/api/voting/entities/';
var SBC_PAGE_RE=/^page=[1-9][0-9]{0,2}$/;
var SBC_VOTES_RE=/^identifiers=20_[0-9]{1,9}(?:,20_[0-9]{1,9}){0,199}$/;
function isAllowedSbcUrl(url){if(!isAllowedUrl(url,SBC_ORIGIN))return false;
try{var parsed=new URL(url);
if(parsed.hash!=='')return false;
var query=parsed.search===''?'':parsed.search.slice(1);
if(parsed.pathname===SBC_LIST_PATH)return query===''||SBC_PAGE_RE.test(query);
if(parsed.pathname===SBC_VOTES_PATH)return SBC_VOTES_RE.test(query);
return false}catch(err){return false}}
function lastModified(response){try{var value=response.headers.get('last-modified');
return typeof value==='string'?value:null}catch(err){return null}}
function fetchPrice(url){if(!isAllowedPriceUrl(url)&&!isAllowedSbcUrl(url)) return Promise.resolve({ok:false,reason:'forbidden-url'});
var init={credentials:'omit',headers:{accept:'application/json'}};
if(MANIFEST_PATH_RE.test(new URL(url).pathname))init.cache='no-cache';
return fetch(url,init).then(function(response){var modified=lastModified(response);
return response.text().then(function(body){return{ok:true,status:response.status,body:body,modified:modified}},function(){return{ok:true,status:response.status,body:'',modified:modified}})},function(){return{ok:false,reason:'network'}})}
function accountRoot(){var origin=accountOrigin();
if(origin==='')return null;
try{var parsed=new URL(origin);
if(parsed.protocol!=='https:'||parsed.pathname!=='/'||parsed.search||parsed.hash)return null;
return parsed.origin}catch(err){return null}}
function readAccountSession(){return chrome.storage.local.get(ACCOUNT_SESSION_KEY).then(function(stored){var value=stored&&stored[ACCOUNT_SESSION_KEY];
return typeof value==='string'&&/^[A-Za-z0-9_-]{40,}$/.test(value)?value:null})}
var sessionEpoch=0;
function writeAccountSession(value){var payload={};
payload[ACCOUNT_SESSION_KEY]=value;
sessionEpoch+=1;
return chrome.storage.local.set(payload)}
function clearAccountSession(){sessionEpoch+=1;
return chrome.storage.local.remove(ACCOUNT_SESSION_KEY)}
function pinAccountSession(){var epoch=sessionEpoch;
return readAccountSession().then(function(session){return session?{session:session,epoch:epoch}:null})}
function ifSameSession(pin,effect,refused){return readAccountSession().then(function(now){return now===pin.session&&sessionEpoch===pin.epoch?effect():refused()})}
var accountDeniedInMemory=false;
function readAccountDenied(){return chrome.storage.local.get(ACCOUNT_DENIED_KEY).then(function(stored){return !!(stored&&stored[ACCOUNT_DENIED_KEY]===true)},function(){return null})}
function writeAccountDenied(){accountDeniedInMemory=true;
var payload={};
payload[ACCOUNT_DENIED_KEY]=true;
return chrome.storage.local.set(payload).then(function(){},function(){})}
function clearAccountDenied(){accountDeniedInMemory=false;
return chrome.storage.local.remove(ACCOUNT_DENIED_KEY).then(function(){},function(){})}
function randomDeviceId(){var bytes=new Uint8Array(16);
var source=globalThis.crypto;
if(source&&typeof source.getRandomValues==='function')source.getRandomValues(bytes);
else for(var i=0;i<bytes.length;i+=1)bytes[i]=Math.floor(Math.random()*256);
var out='';
for(var j=0;j<bytes.length;j+=1)out+=(bytes[j]+256).toString(16).slice(1);
return out}
var ACCOUNT_DEVICE_RE=/^[a-f0-9]{32}$/;
var accountDeviceInFlight=null;
function readAccountDevice(){if(accountDeviceInFlight)return accountDeviceInFlight;
accountDeviceInFlight=bornAccountDevice();
return accountDeviceInFlight}
function bornAccountDevice(){return chrome.storage.local.get(ACCOUNT_DEVICE_KEY).then(function(stored){var value=stored&&stored[ACCOUNT_DEVICE_KEY];
if(typeof value==='string'&&ACCOUNT_DEVICE_RE.test(value))return value;
var born=randomDeviceId();
var payload={};
payload[ACCOUNT_DEVICE_KEY]=born;
return chrome.storage.local.set(payload).then(function(){return born},function(){return born})},function(){return randomDeviceId()}).then(function(value){accountDeviceInFlight=null;
return value},function(err){accountDeviceInFlight=null;
throw err})}
function accountDeviceLabel(){try{var nav=globalThis.navigator;
if(!nav)return null;
var data=nav.userAgentData;
var platform=typeof data?.platform==='string'&&data.platform!==''?data.platform:null;
var brand=null;
var brands=data&&Array.isArray(data.brands)?data.brands:[];
for(var i=0;i<brands.length;i+=1){var name=brands[i]&&brands[i].brand;
if(typeof name==='string'&&name!==''&&!/not[^a-z]*a[^a-z]*brand/i.test(name))brand=name}
var agent=typeof nav.userAgent==='string'?nav.userAgent:'';
if(brand===null){var known=/(Edg|OPR|Chrome|Firefox|Safari)\/(\d+)/.exec(agent);
if(known)brand=known[1]==='Edg'?'Edge':(known[1]==='OPR'?'Opera':known[1])}
if(platform===null){var host=/\(([^;)]+)/.exec(agent);
if(host)platform=host[1].trim()}
var parts=[platform,brand].filter(function(value){return typeof value==='string'&&value!==''});
return parts.length===0?null:parts.join(' · ').slice(0,64)}catch(err){return null}}
function entitlementIssuedAt(token){try{if(typeof token!=='string')return null;
var parts=token.split('.');
if(parts.length!==4)return null;
var normal=parts[2].replace(/-/g,'+').replace(/_/g,'/');
var padded=normal+'===='.slice((normal.length%4)||4);
var payload=JSON.parse(atob(padded));
return Number.isSafeInteger(payload&&payload.iat)?payload.iat:null}catch(err){return null}}
function writeAccountSnapshot(answer,at){if(entitlementIssuedAt(answer&&answer.entitlement)===null)return clearAccountSnapshot();
var payload={};
payload[ACCOUNT_SNAPSHOT_KEY]={answer:answer,at:at};
return chrome.storage.local.set(payload).then(function(){},function(){})}
function clearAccountSnapshot(){return chrome.storage.local.remove(ACCOUNT_SNAPSHOT_KEY).then(function(){},function(){})}
function readAccountSnapshot(){return chrome.storage.local.get(ACCOUNT_SNAPSHOT_KEY).then(function(stored){var kept=stored&&stored[ACCOUNT_SNAPSHOT_KEY];
if(!kept||typeof kept!=='object')return null;
var answer=kept.answer;
if(!answer||answer.ok!==true||typeof answer.entitlement!=='string'||answer.entitlement==='')return null;
var iat=entitlementIssuedAt(answer.entitlement);
if(iat===null)return null;
var at=Number.isSafeInteger(kept.at)?kept.at:null;
return{answer:answer,iat:iat,at:at}},function(){return null})}
function keptRight(kept,now,offline){if(!kept)return null;
var age=now-kept.iat;
if(age<-ACCOUNT_CLOCK_SKEW_MS)return null;
if(!(age<ACCOUNT_CACHE_MS))return null;
var answer=Object.assign({},kept.answer,{hasSession:true});
if(offline){answer.cached=true;
answer.cachedAt=kept.at}
return answer}
function accountRequest(method,path,params){var root=accountRoot();
if(!root)return Promise.resolve({ok:false,status:0,reason:'not-configured'});
var headers={accept:'application/json','content-type':'application/json'};
if(params&&params.session)headers.authorization='Bearer '+params.session;
if(params&&params.operationId)headers['idempotency-key']=params.operationId;
var init={method:method,credentials:'omit',headers:headers,signal:AbortSignal.timeout(ACCOUNT_TIMEOUT_MS)};
if(params&&params.body!==undefined)init.body=JSON.stringify(params.body);
return fetch(root+path,init).then(function(response){return response.text().then(function(text){var body=null;
try{body=text===''?null:JSON.parse(text)}catch(err){return{ok:false,status:response.status,reason:'invalid-response'}}
if(response.status>=200&&response.status<300)return{ok:true,status:response.status,body:body};
return{ok:false,status:response.status,reason:typeof body?.reason==='string'?body.reason:'http-'+response.status,body:body}},function(){return{ok:false,status:response.status,reason:'invalid-response'}})},function(){return{ok:false,status:0,reason:'network'}})}
function publicAccount(raw,hasSession){if(!raw||raw.ok!==true||!raw.account||typeof raw.account.id!=='string'||raw.account.id===''||typeof raw.account.hint!=='string')return null;
var inactive=raw.entitlement===null&&raw.quota===null;
var active=typeof raw.entitlement==='string'&&raw.entitlement!==''&&raw.quota
&&Number.isSafeInteger(raw.quota.total)&&raw.quota.total>=0
&&Number.isSafeInteger(raw.quota.remaining)&&raw.quota.remaining>=0
&&raw.quota.remaining<=raw.quota.total;
if(!inactive&&!active)return null;
return{ok:true,configured:true,hasSession:hasSession,authenticated:true,account:{id:raw.account.id,hint:raw.account.hint},entitlement:inactive?null:raw.entitlement,quota:inactive?null:{total:raw.quota.total,remaining:raw.quota.remaining}}}
function accountStatus(params){if(!accountRoot())return Promise.resolve({ok:false,configured:false,hasSession:false,reason:'not-configured'});
var now=Date.now();
var force=params?.force===true;
return pinAccountSession().then(function(pin){var session=pin===null?null:pin.session;
if(!session)return clearAccountSnapshot().then(readAccountDenied).then(function(denied){
if(accountDeniedInMemory||denied===true)return{ok:true,configured:true,hasSession:false,authenticated:false,reason:'unauthorized'};
if(denied===null)return{ok:false,configured:true,hasSession:false,authenticated:false,reason:'storage'};
return{ok:true,configured:true,hasSession:false,authenticated:false,reason:'signed-out'}});
return readAccountSnapshot().then(function(kept){var since=kept===null||kept.at===null?null:now-kept.at;
var fresh=!force&&accountAsked&&since!==null&&since>=0&&since<ACCOUNT_FRESH_MS?keptRight(kept,now,false):null;
if(fresh)return fresh;
accountAsked=true;
return accountRequest('GET','/v1/account',{session:session}).then(function(result){if(!result.ok){if(result.reason==='unauthorized'){var denied=function(){return{ok:true,configured:true,hasSession:false,authenticated:false,reason:'unauthorized'}};
var moved=function(){return accountStatus(params)};
return ifSameSession(pin,function(){return writeAccountDenied().then(function(){return ifSameSession(pin,function(){return clearAccountSession().then(clearAccountSnapshot).then(denied)},moved)})},moved)}
return keptRight(kept,now,true)||{ok:false,configured:true,hasSession:true,reason:result.reason}}
var shown=publicAccount(result.body,true);
if(!shown)return keptRight(kept,now,true)||{ok:false,configured:true,hasSession:true,reason:'invalid-response'};
return ifSameSession(pin,function(){return (shown.entitlement===null?clearAccountSnapshot():writeAccountSnapshot(shown,now)).then(function(){return shown})},function(){return accountStatus(params)})})})})}
function accountLogin(params){if(!accountRoot())return Promise.resolve({ok:false,configured:false,hasSession:false,reason:'not-configured'});
if(typeof params?.email!=='string'||typeof params?.password!=='string'||params.password.length<12||params.password.length>256)return Promise.resolve({ok:false,configured:true,hasSession:false,reason:'invalid-input'});
return readAccountDevice().then(function(deviceId){return accountRequest('POST','/v1/session',{body:{email:params.email,password:params.password,deviceId:deviceId,deviceLabel:accountDeviceLabel()}})}).then(function(result){if(!result.ok)return{ok:false,configured:true,hasSession:false,reason:result.reason};
var raw=result.body,session=raw?.sessionToken,shown=publicAccount(raw,true);
if(typeof session!=='string'||!/^[A-Za-z0-9_-]{40,}$/.test(session)||!shown)return{ok:false,configured:true,hasSession:false,reason:'invalid-response'};
accountAsked=true;
return writeAccountSession(session).then(function(){return clearAccountDenied().then(function(){return (shown.entitlement===null?clearAccountSnapshot():writeAccountSnapshot(shown,Date.now())).then(function(){return shown})})},function(){return{ok:false,configured:true,hasSession:false,reason:'storage'}})})}
function accountLogout(){if(!accountRoot())return clearAccountSession().then(clearAccountSnapshot).then(clearAccountDenied).then(function(){return{ok:true,configured:false,hasSession:false,authenticated:false}});
return readAccountSession().then(function(session){var request=session?accountRequest('DELETE','/v1/session',{session:session}):Promise.resolve();
return Promise.resolve(request).then(clearAccountSession,clearAccountSession).then(clearAccountSnapshot).then(clearAccountDenied).then(function(){return{ok:true,configured:true,hasSession:false,authenticated:false}})})}
function accountRecoveryStart(params){if(!accountRoot())return Promise.resolve({ok:false,configured:false,reason:'not-configured'});
if(typeof params?.email!=='string')return Promise.resolve({ok:false,configured:true,reason:'invalid-input'});
return accountRequest('POST','/v1/recovery',{body:{email:params.email}}).then(function(result){return result.ok&&result.body?.accepted===true?{ok:true,accepted:true}:{ok:false,reason:result.reason}})}
function accountRecoveryComplete(params){if(!accountRoot())return Promise.resolve({ok:false,configured:false,reason:'not-configured'});
if(typeof params?.token!=='string'||typeof params?.password!=='string'||params.password.length<12||params.password.length>256)return Promise.resolve({ok:false,configured:true,reason:'invalid-input'});
return accountRequest('POST','/v1/recovery/complete',{body:{token:params.token,password:params.password}}).then(function(result){return result.ok?{ok:true}:{ok:false,reason:result.reason}})}
function accountSettingsRequest(method,body,pin){if(!accountRoot())return Promise.resolve({ok:false,reason:'not-configured'});
if(pin)return accountSettingsSend(method,body,pin);
return pinAccountSession().then(function(own){return own?accountSettingsSend(method,body,own):{ok:false,reason:'signed-out'}})}
function accountSettingsSend(method,body,pin){return accountRequest(method,'/v1/settings',{session:pin.session,body:body}).then(function(result){
if(result.reason==='unauthorized'){var denied=function(){return{ok:false,reason:'unauthorized'}};
return ifSameSession(pin,function(){return writeAccountDenied().then(function(){return ifSameSession(pin,function(){return clearAccountSession().then(denied)},denied)})},denied)}
if(result.ok)return result.body&&typeof result.body==='object'?result.body:{ok:false,reason:'invalid-response'};
return result.body&&typeof result.body==='object'?result.body:{ok:false,reason:result.reason}})}
function accountSettingsRead(){return accountSettingsRequest('GET')}
function accountSettingsWrite(params){if(params?.schema!==1||!Number.isSafeInteger(params?.baseRevision)||params.baseRevision<0||!params.namespaces||typeof params.namespaces!=='object'||Array.isArray(params.namespaces))return Promise.resolve({ok:false,reason:'invalid-input'});
return accountSettingsRequest('PUT',{schema:1,baseRevision:params.baseRevision,namespaces:params.namespaces})}
var TRANSFER_METHOD='settings.transfer';
var TRANSFER_REASONS=['not-signed-in','offline','server','conflict','too-big','empty','no-port'];
var SYNC_STATE_KEY='settings.sync';
var TRANSFER_LOADED_KEY='settings.loadedAt';
var SYNC_STORAGE_KEYS={features:'settings.toggles',filters:'filters.sets',buyerLimits:'automation.limits',buyerOptions:'automation.options',sellerOptions:'seller.options',interface:'ui.state',packLocks:'packs.locks'};
var SYNC_UI_FIELDS=['filters','sbcPolicy','pickPreselect','listing','relist','packShow','soundVolume','solver','hotkeys'];
var TRANSFER_REPLACE_MS=120000;
var transferQueue=Promise.resolve();
var transferReplace=null;
function transferAnswer(ok,revision,reason){var out={ok:ok===true};
if(Number.isSafeInteger(revision)&&revision>=0)out.revision=revision;
if(!out.ok)out.reason=TRANSFER_REASONS.indexOf(reason)>=0?reason:'server';
return out}
function transferReason(raw){var reason=raw&&typeof raw.reason==='string'?raw.reason:'';
if(reason==='signed-out'||reason==='unauthorized')return 'not-signed-in';
if(reason==='network')return 'offline';
if(reason==='revision-conflict')return 'conflict';
if(reason==='settings-too-large')return 'too-big';
return 'server'}
var isPlain=function(value){return !!value&&typeof value==='object'&&!Array.isArray(value)};
function transferRemote(raw){if(!raw||raw.ok!==true||raw.schema!==1||typeof raw.subject!=='string'||raw.subject===''||!Number.isSafeInteger(raw.revision)||raw.revision<0||typeof raw.initialized!=='boolean')return null;
if(!raw.initialized)return raw.namespaces===null?raw:null;
var ns=raw.namespaces;
if(!isPlain(ns)||!isPlain(ns.features)||!Array.isArray(ns.filters)||!isPlain(ns.buyerLimits)||!isPlain(ns.buyerOptions)||!isPlain(ns.sellerOptions)||!isPlain(ns.interface)||!Array.isArray(ns.packLocks))return null;
return raw}
function transferKeys(){var keys=[SYNC_STATE_KEY];
for(var name in SYNC_STORAGE_KEYS)keys.push(SYNC_STORAGE_KEYS[name]);
return keys}
function transferBuyerOptions(value){if(!isPlain(value)||!('moveToClub' in value||'listAfterBuy' in value))return value;
var out=Object.assign({},value);
delete out.moveToClub;
delete out.listAfterBuy;
if(value.moveToClub===true)out.afterBuy='club';
else if(value.listAfterBuy===true)out.afterBuy='transferListNow';
return out}
function transferCollect(stored){var out={};
for(var name in SYNC_STORAGE_KEYS){var value=stored?stored[SYNC_STORAGE_KEYS[name]]:undefined;
if(name==='interface'){var ui={};
if(isPlain(value))SYNC_UI_FIELDS.forEach(function(field){if(Object.prototype.hasOwnProperty.call(value,field))ui[field]=value[field]});
out.interface=ui}
else if(name==='buyerOptions')out.buyerOptions=value===undefined?null:transferBuyerOptions(value);
else out[name]=value===undefined?null:value}
return out}
function transferBase(remote){return{schema:1,subject:remote.subject,revision:remote.revision,initialized:true,namespaces:remote.namespaces}}
function transferRefused(){return transferAnswer(false,null,'server')}
function transferSave(){return pinAccountSession().then(function(pin){if(!pin)return transferAnswer(false,null,'not-signed-in');
return chrome.storage.local.get(transferKeys()).then(function(stored){var namespaces=transferCollect(stored);
var base=stored?stored[SYNC_STATE_KEY]:null;
return accountSettingsRequest('GET',undefined,pin).then(function(raw){var remote=transferRemote(raw);
if(!remote)return transferAnswer(false,null,transferReason(raw));
var seen=isPlain(base)&&base.subject===remote.subject&&base.revision===remote.revision;
var replace=transferReplace!==null&&transferReplace.subject===remote.subject&&transferReplace.revision===remote.revision&&Date.now()-transferReplace.at<TRANSFER_REPLACE_MS;
if(remote.initialized&&!seen&&!replace){transferReplace={subject:remote.subject,revision:remote.revision,at:Date.now()};
return transferAnswer(false,remote.revision,'conflict')}
return ifSameSession(pin,function(){transferReplace=null;
return accountSettingsRequest('PUT',{schema:1,baseRevision:remote.revision,expectedSubject:remote.subject,namespaces:namespaces},pin).then(function(answer){var written=transferRemote(answer);
if(!written||!written.initialized||written.subject!==remote.subject){var why=transferReason(answer);
var current=answer&&answer.current;
if(why==='conflict'&&isPlain(current)&&current.subject===remote.subject&&Number.isSafeInteger(current.revision))transferReplace={subject:current.subject,revision:current.revision,at:Date.now()};
return transferAnswer(false,null,why)}
var payload={};
payload[SYNC_STATE_KEY]=transferBase(written);
return ifSameSession(pin,function(){return chrome.storage.local.set(payload).then(function(){return transferAnswer(true,written.revision)},function(){return transferAnswer(false,written.revision,'server')})},transferRefused)})},transferRefused)})})})}
function transferLoad(){return pinAccountSession().then(function(pin){if(!pin)return transferAnswer(false,null,'not-signed-in');
return accountSettingsRequest('GET',undefined,pin).then(function(raw){var remote=transferRemote(raw);
if(!remote)return transferAnswer(false,null,transferReason(raw));
if(!remote.initialized)return transferAnswer(false,remote.revision,'empty');
var ns=remote.namespaces;
return chrome.storage.local.get(SYNC_STORAGE_KEYS.interface).then(function(stored){var current=stored?stored[SYNC_STORAGE_KEYS.interface]:null;
var ui=isPlain(current)?Object.assign({},current):{};
SYNC_UI_FIELDS.forEach(function(field){if(Object.prototype.hasOwnProperty.call(ns.interface,field))ui[field]=ns.interface[field]});
var payload={};
for(var name in SYNC_STORAGE_KEYS)payload[SYNC_STORAGE_KEYS[name]]=name==='interface'?ui:ns[name];
payload[SYNC_STATE_KEY]=transferBase(remote);
payload[TRANSFER_LOADED_KEY]=Date.now();
return ifSameSession(pin,function(){transferReplace=null;
return chrome.storage.local.set(payload).then(function(){return transferAnswer(true,remote.revision)},function(){return transferAnswer(false,null,'server')})},transferRefused)})})})}
function settingsTransfer(params){var direction=params&&params.direction;
if(direction!=='save'&&direction!=='load')return Promise.resolve(transferAnswer(false,null,'server'));
if(!accountRoot())return Promise.resolve(transferAnswer(false,null,'server'));
var run=function(){return (direction==='save'?transferSave():transferLoad()).then(null,function(){return transferAnswer(false,null,'server')})};
var done=transferQueue.then(run,run);
transferQueue=done.then(function(){},function(){});
return done}
var REPORT_METHOD='report.send';
var REPORT_REASONS=['offline','too-many','too-big','server','no-port'];
function reportAnswer(ok,number,reason){var out={ok:ok===true};
if(out.ok&&Number.isSafeInteger(number)&&number>0)out.number=number;
if(!out.ok)out.reason=REPORT_REASONS.indexOf(reason)>=0?reason:'server';
return out}
function reportSend(params){if(!accountRoot())return Promise.resolve(reportAnswer(false,null,'server'));
var report=params&&params.report;
var words=params&&typeof params.words==='string'?params.words:'';
var contact=params&&typeof params.contact==='string'?params.contact:'';
if(!isPlain(report))return Promise.resolve(reportAnswer(false,null,'server'));
if(words.length>2000||contact.length>64)return Promise.resolve(reportAnswer(false,null,'too-big'));
return Promise.all([readAccountSession().then(null,function(){return null}),readAccountDevice().then(null,function(){return null})]).then(function(both){var session=both[0],deviceId=both[1];
return accountRequest('POST','/v1/reports',{session:session||undefined,body:{schema:1,report:report,words:words,contact:contact,deviceId:deviceId||undefined}}).then(function(result){if(result.ok&&result.body&&Number.isSafeInteger(result.body.number))return reportAnswer(true,result.body.number);
if(result.status===429)return reportAnswer(false,null,'too-many');
if(result.status===413)return reportAnswer(false,null,'too-big');
if(result.reason==='network')return reportAnswer(false,null,'offline');
return reportAnswer(false,null,'server')})},function(){return reportAnswer(false,null,'server')})}
var ACCOUNT_OPEN_METHOD='account.open';
var ACCOUNT_PAGE_PATH='account/popup.html';
var ACCOUNT_OPEN_ASKS=['logout'];
function accountOpen(params){var ask=params&&typeof params==='object'&&ACCOUNT_OPEN_ASKS.indexOf(params.ask)>=0?params.ask:null;
if(ask!==null)return accountOpenTab(ask);
var runtime=chrome.runtime;
if(runtime&&typeof runtime.openOptionsPage==='function'){return new Promise(function(resolve){resolve(runtime.openOptionsPage())})
.then(function(){return{ok:true,via:'options'}},function(){return accountOpenTab()})}
return accountOpenTab()}
function accountOpenTab(ask){if(!chrome.tabs||typeof chrome.tabs.create!=='function'||!chrome.runtime||typeof chrome.runtime.getURL!=='function')return Promise.resolve({ok:false,reason:'no-tabs'});
return new Promise(function(resolve){resolve(chrome.tabs.create({url:chrome.runtime.getURL(ACCOUNT_PAGE_PATH)+(ask?'?ask='+ask:'')}))})
.then(function(){return{ok:true,via:'tab'}},function(){return{ok:false,reason:'open-failed'}})}
var BUDGET_KEY='market.owner';
var BUDGET_RESERVE='budget.reserve';
var BUDGET_SPEND='budget.spend';
var BUDGET_RELEASE='budget.release';
var BUDGET_REST='budget.rest';
var BUDGET_STATE='budget.state';
var MINUTE_CAP=45,MINUTE_MS=60000;
var DAY_CAP=2000;
var SEARCH_HOUR_CAP=1000,HOUR_MS=3600000;
var SEARCH_HOUR_REFUSAL='search-hour';
var BID_CAP=60;
var REST_BAND_MIN_MS=270000,REST_BAND_MAX_MS=360000;
function ownerRestRoll(){var low=REST_BAND_MIN_MS,high=REST_BAND_MAX_MS,roll;
try{roll=Math.random()}catch(err){return high}
if(typeof roll!=='number'||!isFinite(roll))return high;
if(roll<0)roll=0;
if(roll>1)roll=1;
return Math.min(high,low+Math.floor(roll*(high-low+1)))}
var MAX_RESERVE=64;
var PLEDGE_TTL_MS=60000;
var OWNER_GENERATION='g'+Date.now().toString(36)+'-'+Math.floor(Math.random()*1e9).toString(36);
var ownerLeaseSeq=0;
function ownerDayKey(now){var date=new Date(now);
return date.getFullYear()+'-'+String(date.getMonth()+1).padStart(2,'0')+'-'+String(date.getDate()).padStart(2,'0')}
function ownerPrune(list,now,windowMs){var out=[],i,at;
for(i=0;i<list.length;i+=1){at=list[i];
if(typeof at==='number'&&isFinite(at)&&at<=now&&now-at<windowMs)out.push(at)}
out.sort(function(a,b){return a-b});
return out}
function ownerList(value){return Array.isArray(value)?value.slice():[]}
function ownerRead(raw){var day=null,used=0,resting=0;
if(raw&&typeof raw==='object'&&!Array.isArray(raw)){if(typeof raw.day==='string'&&raw.day!=='')day=raw.day;
if(Number.isSafeInteger(raw.used)&&raw.used>=0)used=raw.used;
if(Number.isSafeInteger(raw.restingUntil)&&raw.restingUntil>=0)resting=raw.restingUntil}
return{day:day,used:day===null?0:used,minute:ownerList(raw&&raw.minute),
hour:ownerList(raw&&raw.hour),buy:ownerList(raw&&raw.buy),restingUntil:resting}}
var ownerState=null;
var ownerLoading=null;
var ownerBroken=false;
var ownerLeases={};
var ownerChain=Promise.resolve();
function ownerNoop(){}
function ownerSerial(job){var next=ownerChain.then(job,job);
ownerChain=next.then(ownerNoop,ownerNoop);
return next}
function ownerLoad(){if(ownerState!==null)return Promise.resolve(ownerState);
if(ownerLoading!==null)return ownerLoading;
ownerLoading=chrome.storage.local.get(BUDGET_KEY).then(function(stored){ownerState=ownerRead(stored&&stored[BUDGET_KEY]);
ownerBroken=false;
ownerLoading=null;
return ownerState},function(err){ownerLoading=null;
ownerState=null;
throw err});
return ownerLoading}
function ownerSave(){var payload={};
payload[BUDGET_KEY]={v:1,day:ownerState.day,used:ownerState.used,minute:ownerState.minute,
hour:ownerState.hour,buy:ownerState.buy,restingUntil:ownerState.restingUntil};
return chrome.storage.local.set(payload).then(function(){ownerBroken=false;
return true},function(err){
ownerBroken=true;
throw err})}
function ownerReady(){return ownerLoad().then(function(){if(!ownerBroken)return true;
return ownerSave().then(function(){return true},function(){return false})},function(){return false})}
function ownerFresh(now){var today=ownerDayKey(now),kind;
if(ownerState.day!==today){ownerState.day=today;
ownerState.used=0}
ownerState.minute=ownerPrune(ownerState.minute,now,MINUTE_MS);
ownerState.hour=ownerPrune(ownerState.hour,now,HOUR_MS);
ownerState.buy=ownerPrune(ownerState.buy,now,HOUR_MS);
ownerSweep(now)}
function ownerSweep(now){var id,age;
for(id in ownerLeases){if(!Object.hasOwn(ownerLeases,id))continue;
age=now-ownerLeases[id].at;
if(!(age>=0&&age<PLEDGE_TTL_MS))delete ownerLeases[id]}}
function ownerDropLeases(kind){var id;
for(id in ownerLeases){if(Object.hasOwn(ownerLeases,id)&&ownerLeases[id].kind===kind)delete ownerLeases[id]}}
function ownerPledgedOf(kind){var id,total=0;
for(id in ownerLeases){if(Object.hasOwn(ownerLeases,id)&&ownerLeases[id].kind===kind)total+=ownerLeases[id].left}
return total}
function ownerLeaseTake(id,kind,count){if(typeof id!=='string'||id==='')return false;
if(!Object.hasOwn(ownerLeases,id))return false;
var lease=ownerLeases[id];
if(lease.kind!==kind||lease.left<count)return false;
lease.left-=count;
if(lease.left<=0)delete ownerLeases[id];
return true}
function ownerBusy(kind){if(kind==='minute')return ownerState.minute.length+ownerPledgedOf('minute');
if(kind==='bid')return ownerState.buy.length+ownerPledgedOf('bid');
return ownerState.used+ownerPledgedOf('market')+ownerPledgedOf('other')}
function ownerCapOf(kind){if(kind==='minute')return MINUTE_CAP;
if(kind==='bid')return BID_CAP;
return DAY_CAP}
function ownerHourBusy(){return ownerState.hour.length+ownerPledgedOf('market')}
function ownerWindow(list,cap,windowMs){return{used:list.length,cap:cap,windowMs:windowMs,
oldest:list.length>0?list[0]:null}}
function ownerSnapshot(now){return{day:ownerState.day,used:ownerState.used,cap:DAY_CAP,
minute:ownerWindow(ownerState.minute,MINUTE_CAP,MINUTE_MS),
hour:ownerWindow(ownerState.hour,SEARCH_HOUR_CAP,HOUR_MS),
buy:ownerWindow(ownerState.buy,BID_CAP,HOUR_MS),
pledged:{minute:ownerPledgedOf('minute'),market:ownerPledgedOf('market'),
other:ownerPledgedOf('other'),bid:ownerPledgedOf('bid')},
generation:OWNER_GENERATION,
restingUntil:ownerState.restingUntil,now:now}}
function ownerRefusal(kind,count,now){if(kind==='minute'&&now<ownerState.restingUntil)return 'rest';
return null}
function ownerKindOk(kind){return kind==='minute'||kind==='market'||kind==='other'||kind==='bid'}
function ownerCount(asked){return Number.isSafeInteger(asked)&&asked>0?Math.min(asked,MAX_RESERVE):1}
var OWNER_BAD_REQUEST={ok:false,granted:0,reason:'bad-request',state:null};
var OWNER_UNAVAILABLE={ok:false,granted:0,reason:'counter-unavailable',state:null};
function ownerReserve(params){var kind=params&&params.kind;
if(!ownerKindOk(kind))return Promise.resolve(OWNER_BAD_REQUEST);
var count=ownerCount(params&&params.count);
return ownerSerial(function(){return ownerReady().then(function(ready){if(!ready)return OWNER_UNAVAILABLE;
var now=Date.now(),i;
ownerFresh(now);
var refusal=ownerRefusal(kind,count,now);
if(refusal!==null)return{ok:false,granted:0,reason:refusal,state:ownerSnapshot(now)};
ownerLeaseSeq+=1;
var id=OWNER_GENERATION+'.'+ownerLeaseSeq;
ownerLeases[id]={kind:kind,left:count,at:now};
return{ok:true,granted:count,reason:null,
lease:{id:id,count:count,expiresAt:now+PLEDGE_TTL_MS},
state:ownerSnapshot(now)}},
function(){return OWNER_UNAVAILABLE})})}
function ownerSpend(params){var kind=params&&params.kind;
if(!ownerKindOk(kind))return Promise.resolve(OWNER_BAD_REQUEST);
var count=ownerCount(params&&params.count);
var id=params&&params.lease;
return ownerSerial(function(){return ownerLoad().then(function(){var now=Date.now(),i;
ownerFresh(now);
if(kind==='minute'&&now<ownerState.restingUntil){ownerDropLeases('minute');
return{ok:false,granted:0,reason:'rest',lease:'stale',state:ownerSnapshot(now)}}
var live=ownerLeaseTake(id,kind,count);
if(!live){var refusal=ownerRefusal(kind,count,now);
return{ok:false,granted:0,reason:refusal===null?'counter-unavailable':refusal,lease:'stale',state:ownerSnapshot(now)}}
if(kind==='minute')for(i=0;i<count;i+=1)ownerState.minute.push(now);
if(kind==='bid')for(i=0;i<count;i+=1)ownerState.buy.push(now);
if(kind==='market'||kind==='other')ownerState.used+=count;
if(kind==='market')for(i=0;i<count;i+=1)ownerState.hour.push(now);
var snapshot=ownerSnapshot(now);
var word=live?'live':'stale';
return ownerSave().then(function(){return{ok:true,granted:0,reason:null,lease:word,state:snapshot}},
function(){return OWNER_UNAVAILABLE})},
function(){return OWNER_UNAVAILABLE})})}
function ownerRelease(params){var kind=params&&params.kind;
if(!ownerKindOk(kind))return Promise.resolve(OWNER_BAD_REQUEST);
var count=ownerCount(params&&params.count);
var id=params&&params.lease;
return ownerSerial(function(){return ownerLoad().then(function(){var now=Date.now();
ownerFresh(now);
ownerLeaseTake(id,kind,count);
return{ok:true,granted:0,reason:null,state:ownerSnapshot(now)}},
function(){return OWNER_UNAVAILABLE})})}
function ownerRest(params){var asked=params&&params.ms;
var ms=Number.isSafeInteger(asked)&&asked>0?asked:ownerRestRoll();
return ownerSerial(function(){return ownerLoad().then(function(){var now=Date.now();
ownerFresh(now);
var until=now+ms;
if(until>ownerState.restingUntil)ownerState.restingUntil=until;
ownerDropLeases('minute');
var snapshot=ownerSnapshot(now);
return ownerSave().then(function(){return{ok:true,granted:0,reason:null,state:snapshot}},
function(){return OWNER_UNAVAILABLE})},
function(){return OWNER_UNAVAILABLE})})}
function ownerReport(){return ownerSerial(function(){return ownerLoad().then(function(){var now=Date.now();
ownerFresh(now);
return{ok:true,granted:0,reason:null,state:ownerSnapshot(now)}},
function(){return OWNER_UNAVAILABLE})})}
var LOCKS_KEY='card.locks';
var LOCKS_WRITE='locks.write';
var MAX_LOCK_IDS=500;
function lockIds(raw){var out=[];
if(!Array.isArray(raw))return out;
for(var at=0;at<raw.length;at+=1){var id=Number(raw[at]);
if(!Number.isSafeInteger(id)||id<=0||out.indexOf(id)>=0)continue;
out.push(id)}
return out}
function lockRecord(raw){if(Array.isArray(raw))return{ids:lockIds(raw),recreated:[],names:{}};
if(!raw||typeof raw!=='object')return{ids:[],recreated:[],names:{}};
var names={};
var source=raw.names;
if(source&&typeof source==='object'&&!Array.isArray(source)){for(var key in source){if(!Object.prototype.hasOwnProperty.call(source,key))continue;
if(typeof source[key]==='string')names[key]=source[key]}}
return{ids:lockIds(raw.ids),recreated:lockIds(raw.recreated),names:names}}
function lockWithout(list,id){var out=[];
for(var at=0;at<list.length;at+=1){if(list[at]!==id)out.push(list[at])}
return out}
function mergeLocks(state,params){var at;
var off=lockIds(params&&params.off);
for(at=0;at<off.length;at+=1){state.ids=lockWithout(state.ids,off[at]);
state.recreated=lockWithout(state.recreated,off[at]);
delete state.names[String(off[at])]}
var on=Array.isArray(params&&params.on)?params.on:[];
for(at=0;at<on.length;at+=1){var one=on[at]||{};
var id=Number(one.id);
if(!Number.isSafeInteger(id)||id<=0)continue;
state.ids=[id].concat(lockWithout(state.ids,id));
state.recreated=lockWithout(state.recreated,id);
if(typeof one.name==='string'&&one.name!=='')state.names[String(id)]=one.name}
var mark=lockIds(params&&params.mark);
for(at=0;at<mark.length;at+=1){if(state.ids.indexOf(mark[at])<0)continue;
if(state.recreated.indexOf(mark[at])<0)state.recreated.push(mark[at])}
if(state.ids.length>MAX_LOCK_IDS)state.ids=state.ids.slice(0,MAX_LOCK_IDS);
state.recreated=state.recreated.filter(function(id){return state.ids.indexOf(id)>=0});
var kept={};
for(at=0;at<state.ids.length;at+=1){var name=state.names[String(state.ids[at])];
if(typeof name==='string')kept[String(state.ids[at])]=name}
state.names=kept;
return state}
var locksChain=Promise.resolve();
function locksSerial(job){var next=locksChain.then(job,job);
locksChain=next.then(ownerNoop,ownerNoop);
return next}
var LOCKS_BAD_REQUEST={ok:false,reason:'bad-request'};
function locksWrite(params){if(!params||typeof params!=='object'||Array.isArray(params))return Promise.resolve(LOCKS_BAD_REQUEST);
return locksSerial(function(){return chrome.storage.local.get(LOCKS_KEY).then(function(stored){var state=mergeLocks(lockRecord(stored?stored[LOCKS_KEY]:null),params);
var payload={};
payload[LOCKS_KEY]=state;
return chrome.storage.local.set(payload).then(function(){return{ok:true,reason:null}},
function(){return{ok:false,reason:'save-failed'}})},
function(){return{ok:false,reason:'load-failed'}})})}
var CARDS_METHOD='cards.base';
var CARDS_STATE_KEY='cards.meta';
var CARDS_PATH_RE=/^\/v1\/cards\/([0-9]{2})$/;
var CARDS_TIMEOUT_MS=30000;
var CARDS_SLOTS=[30,390,750,1110];
var CARDS_EVERY_MS=21600000;
var CARDS_STALE_MS=25200000;
var CARDS_JITTER_MAX_MS=600000;
var CARDS_RETRY_MS=1800000;
var CARDS_SOON_MS=1800000;
function cardsGame(value){return Number.isSafeInteger(value)&&value>=20&&value<=99?value:null}
function cardsUrl(game){return accountOrigin()+'/v1/cards/'+game}
function isAllowedCardsUrl(url){if(!isAllowedUrl(url,accountOrigin()))return false;
try{var parsed=new URL(url);
return parsed.search===''&&parsed.hash===''&&CARDS_PATH_RE.test(parsed.pathname)}catch(err){return false}}
function londonMinutes(at){try{var parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date(at));
var hour=null;
var minute=null;
for(var i=0;i<parts.length;i+=1){if(parts[i].type==='hour')hour=parseInt(parts[i].value,10);
else if(parts[i].type==='minute')minute=parseInt(parts[i].value,10)}
if(hour===null||minute===null||isNaN(hour)||isNaN(minute))return null;
if(hour===24)hour=0;
return hour*60+minute}catch(err){return null}}
function nextCardsAt(at,jitterMs){var minutes=londonMinutes(at);
if(minutes===null)return at+CARDS_EVERY_MS;
var jitter=Number.isSafeInteger(jitterMs)&&jitterMs>=0?jitterMs:0;
var best=null;
for(var i=0;i<CARDS_SLOTS.length;i+=1){var away=CARDS_SLOTS[i]-minutes;
if(away<=0)away+=1440;
if(best===null||away<best)best=away}
return at+best*60000+jitter}
function cardsJitter(){return Math.floor(Math.random()*CARDS_JITTER_MAX_MS)}
function readCardsMeta(){return chrome.storage.local.get(CARDS_STATE_KEY).then(function(stored){var kept=stored&&stored[CARDS_STATE_KEY];
return kept&&typeof kept==='object'&&!Array.isArray(kept)?kept:null},function(){return null})}
function writeCardsMeta(meta){var payload={};
payload[CARDS_STATE_KEY]=meta;
return chrome.storage.local.set(payload).then(function(){return meta},function(){return meta})}
function cardsDue(meta,now,game,soon){if(!meta)return 'no-base';
if(cardsGame(meta.game)!==game)return 'other-season';
if(!Number.isSafeInteger(meta.at))return 'no-base';
if(now<meta.at)return 'clock-back';
if(now-meta.at>=CARDS_STALE_MS)return 'stale';
if(Number.isSafeInteger(meta.nextAt)&&now>=meta.nextAt)return 'schedule';
if(soon===true&&now-meta.at>=CARDS_SOON_MS)return 'incomplete';
return null}
function cardsBytes(){try{var used=chrome.storage.local.getBytesInUse;
if(typeof used!=='function')return Promise.resolve(null);
return chrome.storage.local.getBytesInUse(null).then(function(value){return Number.isSafeInteger(value)?value:null},function(){return null})}catch(err){return Promise.resolve(null)}}
function cardsReport(meta,bytes,due,status,reason){return{game:meta?cardsGame(meta.game):null,
etag:meta&&typeof meta.etag==='string'?meta.etag:null,
at:meta&&Number.isSafeInteger(meta.at)?meta.at:null,
nextAt:meta&&Number.isSafeInteger(meta.nextAt)?meta.nextAt:null,
jitterMs:meta&&Number.isSafeInteger(meta.jitter)?meta.jitter:null,
bytes:meta&&Number.isSafeInteger(meta.bytes)?meta.bytes:null,
storageBytes:bytes,due:due||null,status:Number.isSafeInteger(status)?status:null,
reason:typeof reason==='string'?reason:null}}
var cardsInFlight={};
function cardsBase(params){var game=cardsGame(params&&params.game);
if(game===null)return Promise.resolve({ok:false,status:0,reason:'bad-season',state:null});
var known=params&&typeof params.etag==='string'&&params.etag!==''?params.etag:null;
var soon=params&&params.soon===true;
var key=game+'|'+(known===null?'':known);
if(cardsInFlight[key])return cardsInFlight[key];
var work=cardsAsk(game,known,soon).then(function(answer){delete cardsInFlight[key];
return answer},function(err){delete cardsInFlight[key];
throw err});
cardsInFlight[key]=work;
return work}
function cardsAsk(game,known,soon){var now=Date.now();
return readCardsMeta().then(function(meta){var due=cardsDue(meta,now,game,soon);
if(known!==null&&due===null)return cardsBytes().then(function(bytes){return{ok:true,status:304,fresh:false,
state:cardsReport(meta,bytes,null,304,'fresh')}});
var jitter=meta&&Number.isSafeInteger(meta.jitter)?meta.jitter:cardsJitter();
var url=cardsUrl(game);
if(!isAllowedCardsUrl(url))return Promise.resolve({ok:false,status:0,reason:'forbidden-url',state:null});
var headers={accept:'application/json'};
if(known!==null)headers['if-none-match']=known;
var init={method:'GET',credentials:'omit',headers:headers,signal:AbortSignal.timeout(CARDS_TIMEOUT_MS)};
return fetch(url,init).then(function(response){var status=response.status;
var etag=null;
try{etag=response.headers.get('etag')}catch(err){etag=null}
if(status===304)return cardsSave({game:game,etag:known,at:now,nextAt:nextCardsAt(now,jitter),jitter:jitter,
bytes:meta&&Number.isSafeInteger(meta.bytes)?meta.bytes:null}).then(function(saved){return cardsBytes().then(function(bytes){return{ok:true,status:304,fresh:true,
state:cardsReport(saved,bytes,due,304,'not-modified')}})});
if(status<200||status>=300){
var reason=status===503?'building':(status===404?'no-season-file':'http-'+status);
var again=status===404?nextCardsAt(now,jitter):now+CARDS_RETRY_MS;
return cardsSave(Object.assign({},meta||{},{game:game,jitter:jitter,nextAt:again})).then(function(saved){return cardsBytes().then(function(bytes){return{ok:false,status:status,reason:reason,
state:cardsReport(saved,bytes,due,status,reason)}})})}
return response.text().then(function(body){var text=typeof body==='string'?body:'';
if(text===''){return cardsSave(Object.assign({},meta||{},{game:game,jitter:jitter,nextAt:now+CARDS_RETRY_MS})).then(function(saved){return cardsBytes().then(function(bytes){return{ok:false,status:status,reason:'empty-body',
state:cardsReport(saved,bytes,due,status,'empty-body')}})})}
return cardsSave({game:game,etag:typeof etag==='string'&&etag!==''?etag:null,at:now,
nextAt:nextCardsAt(now,jitter),jitter:jitter,bytes:text.length}).then(function(saved){return cardsBytes().then(function(bytes){return{ok:true,status:status,fresh:true,
etag:typeof etag==='string'&&etag!==''?etag:null,body:text,
state:cardsReport(saved,bytes,due,status,null)}})})},function(){return cardsSave(Object.assign({},meta||{},{game:game,jitter:jitter,nextAt:now+CARDS_RETRY_MS})).then(function(saved){return cardsBytes().then(function(bytes){return{ok:false,status:status,reason:'unreadable-body',
state:cardsReport(saved,bytes,due,status,'unreadable-body')}})})})},
function(){return cardsSave(Object.assign({},meta||{},{game:game,jitter:jitter,nextAt:now+CARDS_RETRY_MS})).then(function(saved){return cardsBytes().then(function(bytes){return{ok:false,status:0,reason:'network',
state:cardsReport(saved,bytes,due,0,'network')}})})})})}
function cardsSave(meta){return writeCardsMeta(meta).then(function(){return meta},function(){return meta})}
var UPDATE_METHOD='update.check';
var UPDATE_RELOAD_METHOD='update.reload';
var UPDATE_STATE_KEY='update.meta';
var UPDATE_PATH='/v1/version';
var UPDATE_SITE_ORIGIN='https://eshario.com';
var UPDATE_EVERY_MS=3600000;
var UPDATE_RETRY_MS=3600000;
var UPDATE_FORCE_FLOOR_MS=60000;
var UPDATE_TIMEOUT_MS=5000;
var UPDATE_VERSION_RE=/^(0|[1-9][0-9]{0,3})\.(0|[1-9][0-9]{0,3})\.(0|[1-9][0-9]{0,3})$/;
function isAllowedUpdateUrl(url){if(!isAllowedUrl(url,accountOrigin()))return false;
try{var parsed=new URL(url);
return parsed.search===''&&parsed.hash===''&&parsed.pathname===UPDATE_PATH}catch(err){return false}}
function updateSelf(){try{var manifest=chrome.runtime.getManifest();
var version=manifest&&typeof manifest.version==='string'?manifest.version:null;
var store=!manifest||(typeof manifest.update_url==='string'&&manifest.update_url!=='');
return{version:version,sideload:!store}}catch(err){return{version:null,sideload:false}}}
function updateParts(text){var match=typeof text==='string'?UPDATE_VERSION_RE.exec(text):null;
return match?[Number(match[1]),Number(match[2]),Number(match[3])]:null}
function updateNewer(latest,own){var a=updateParts(latest);
var b=updateParts(own);
if(a===null||b===null)return false;
for(var i=0;i<3;i+=1){if(a[i]!==b[i])return a[i]>b[i]}
return false}
function updateDownload(value){if(typeof value!=='string'||value===''||value.length>300)return null;
try{var parsed=new URL(value);
return parsed.protocol==='https:'&&parsed.origin===UPDATE_SITE_ORIGIN&&parsed.username===''&&parsed.password===''?parsed.href:null}catch(err){return null}}
function updateZip(value,latest){var href=updateDownload(value);
if(href===null||typeof latest!=='string'||updateParts(latest)===null)return null;
try{var parsed=new URL(href);
var name=parsed.pathname.split('/').pop()||'';
return parsed.search===''&&parsed.hash===''&&/\.zip$/.test(name)&&name.slice(0,-4).split('-').indexOf(latest)!==-1?href:null}catch(err){return null}}
function updateOnDisk(){try{return fetch(chrome.runtime.getURL('manifest.json'),{cache:'no-store'}).then(function(response){return response.json()}).then(function(body){var value=body&&typeof body.version==='string'?body.version:null;
return value!==null&&updateParts(value)!==null?value:null},function(){return null})}catch(err){return Promise.resolve(null)}}
function withDisk(self,answer){if(self.sideload!==true)return Promise.resolve(answer);
return updateOnDisk().then(function(disk){answer.disk=disk;
answer.ready=disk!==null&&updateNewer(disk,self.version);
return answer})}
function updateReload(){var self=updateSelf();
if(self.sideload!==true)return Promise.resolve({ok:false,reason:'store-copy'});
return updateOnDisk().then(function(disk){if(disk===null||!updateNewer(disk,self.version))return{ok:false,reason:'same-version',own:self.version,disk:disk};
reloadSoon();
return{ok:true,reloading:true,own:self.version,disk:disk}})}
function reloadSoon(){setTimeout(function(){try{chrome.runtime.reload()}catch(err){}},100)}
function readUpdateMeta(){return chrome.storage.local.get(UPDATE_STATE_KEY).then(function(stored){var kept=stored&&stored[UPDATE_STATE_KEY];
return kept&&typeof kept==='object'&&!Array.isArray(kept)?kept:null},function(){return null})}
function writeUpdateMeta(meta){var payload={};
payload[UPDATE_STATE_KEY]=meta;
return chrome.storage.local.set(payload).then(function(){return meta},function(){return meta})}
function updateDue(meta,now,force){if(!meta||!Number.isSafeInteger(meta.at))return 'first';
if(now<meta.at)return 'clock-back';
if(force===true&&now-meta.at>=UPDATE_FORCE_FLOOR_MS)return 'force';
if(!Number.isSafeInteger(meta.nextAt)||now>=meta.nextAt)return 'daily';
if(meta.nextAt-meta.at>UPDATE_EVERY_MS)return 'step-shrunk';
return null}
function updateAnswer(self,meta,due){var latest=meta&&typeof meta.latest==='string'?meta.latest:null;
var download=meta?updateDownload(meta.download):null;
var show=self.sideload===true&&latest!==null&&download!==null&&updateNewer(latest,self.version);
var zip=show&&meta?updateZip(meta.zip,latest):null;
return{ok:true,show:show,latest:latest,download:download,zip:zip,own:self.version,sideload:self.sideload===true,
state:{at:meta&&Number.isSafeInteger(meta.at)?meta.at:null,nextAt:meta&&Number.isSafeInteger(meta.nextAt)?meta.nextAt:null,
status:meta&&Number.isSafeInteger(meta.status)?meta.status:null,reason:meta&&typeof meta.reason==='string'?meta.reason:null,
asked:typeof due==='string'?due:null}}}
var updateInFlight=null;
function updateCheck(params){var self=updateSelf();
if(!self.sideload)return Promise.resolve(updateAnswer(self,null,null));
if(updateInFlight)return updateInFlight;
var force=!!(params&&params.force===true);
var work=readUpdateMeta().then(function(meta){var now=Date.now();
var due=updateDue(meta,now,force);
if(due===null)return updateAnswer(self,meta,null);
return updateAsk(meta,now).then(function(saved){return updateAnswer(self,saved,due)})}).then(function(answer){return withDisk(self,answer)}).then(withNeeds);
updateInFlight=work.then(function(answer){updateInFlight=null;
return answer},function(){updateInFlight=null;
return{ok:false,show:false,reason:'worker-error'}});
return updateInFlight}
function updateAsk(meta,now){var kept={latest:meta&&typeof meta.latest==='string'?meta.latest:null,
download:meta&&typeof meta.download==='string'?meta.download:null,
zip:meta&&typeof meta.zip==='string'?meta.zip:null,
updatedAt:meta&&Number.isSafeInteger(meta.updatedAt)?meta.updatedAt:null};
var url=accountOrigin()+UPDATE_PATH;
if(!isAllowedUpdateUrl(url))return writeUpdateMeta(Object.assign({},kept,{at:now,nextAt:now+UPDATE_EVERY_MS,status:0,reason:'forbidden-url'}));
var init={method:'GET',credentials:'omit',cache:'no-store',headers:{accept:'application/json'},signal:AbortSignal.timeout(UPDATE_TIMEOUT_MS)};
return fetch(url,init).then(function(response){var status=response.status;
if(status!==200)return writeUpdateMeta(Object.assign({},kept,{at:now,nextAt:now+UPDATE_EVERY_MS,status:status,reason:'http-'+status}));
return response.json().then(function(body){var latest=body&&typeof body.latest==='string'&&updateParts(body.latest)!==null?body.latest:null;
var download=body?updateDownload(body.download):null;
if(latest===null||download===null)return writeUpdateMeta(Object.assign({},kept,{at:now,nextAt:now+UPDATE_EVERY_MS,status:status,reason:'bad-body'}));
return writeUpdateMeta({latest:latest,download:download,zip:updateZip(body.zip,latest),updatedAt:Number.isSafeInteger(body.updatedAt)?body.updatedAt:null,
at:now,nextAt:now+UPDATE_EVERY_MS,status:status,reason:null})},
function(){return writeUpdateMeta(Object.assign({},kept,{at:now,nextAt:now+UPDATE_EVERY_MS,status:status,reason:'bad-body'}))})},
function(){return writeUpdateMeta(Object.assign({},kept,{at:now,nextAt:now+UPDATE_RETRY_MS,status:0,reason:'network'}))})}
function withNeeds(answer){var loader=globalThis.esharioLoader;
if(!answer||!loader||typeof loader.needsLoader!=='function')return answer;
return loader.needsLoader().then(function(needs){if(!needs){answer.needsLoader=null;
return answer}
return readUpdateMeta().then(function(meta){var latest=meta&&typeof meta.latest==='string'?meta.latest:null;
var fits=latest!==null&&!updateNewer(needs.minLoader,latest);
answer.needsLoader={minLoader:needs.minLoader,version:needs.version,archive:fits?latest:needs.minLoader,
zip:fits?updateZip(meta.zip,latest):null,download:meta?updateDownload(meta.download):null};
return answer})},function(){return answer})}
if(typeof importScripts==='function'){try{importScripts('../loader/code-public-key.js')}catch(err){}
try{importScripts('../loader/code.js','../loader/doors.js')}catch(err){}}
chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){if(!message)return false;
var work=null;
if(message.method===METHOD)work=fetchPrice(message.url);
else if(message.method==='account.status')work=accountStatus(message.params);
else if(message.method==='account.login')work=accountLogin(message.params);
else if(message.method==='account.logout')work=accountLogout();
else if(message.method==='account.recovery.start')work=accountRecoveryStart(message.params);
else if(message.method==='account.recovery.complete')work=accountRecoveryComplete(message.params);
else if(message.method==='account.settings.read')work=accountSettingsRead();
else if(message.method==='account.settings.write')work=accountSettingsWrite(message.params);
else if(message.method===TRANSFER_METHOD)work=settingsTransfer(message.params);
else if(message.method===REPORT_METHOD)work=reportSend(message.params);
else if(message.method===ACCOUNT_OPEN_METHOD)work=accountOpen(message.params);
else if(message.method===BUDGET_RESERVE)work=ownerReserve(message.params);
else if(message.method===BUDGET_SPEND)work=ownerSpend(message.params);
else if(message.method===BUDGET_RELEASE)work=ownerRelease(message.params);
else if(message.method===BUDGET_REST)work=ownerRest(message.params);
else if(message.method===BUDGET_STATE)work=ownerReport();
else if(message.method===LOCKS_WRITE)work=locksWrite(message.params);
else if(message.method===CARDS_METHOD)work=cardsBase(message.params);
else if(message.method===UPDATE_METHOD)work=updateCheck(message.params);
else if(message.method===UPDATE_RELOAD_METHOD)work=updateReload();
if(work===null)return false;
work.then(sendResponse,function(){sendResponse({ok:false,reason:'worker-error'})});
return true})})()
