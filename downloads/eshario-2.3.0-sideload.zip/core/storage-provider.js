export const STORAGE_PENDING='pending'
export const STORAGE_LOADED='loaded'
export const STORAGE_LOAD_FAILED='loaded-failed'
export const STORAGE_SAVE_FAILED='save-failed'
export function storageFailed(provider){try{const state=provider?.status?.()
return state===STORAGE_LOAD_FAILED||state===STORAGE_SAVE_FAILED}catch{return true}}
export function createCachedProvider(opts){const{fetch,push,sanitize,fallback}=opts
const onError=typeof opts.onError==='function'?opts.onError:()=>{}
let cache=fallback()
let status=STORAGE_PENDING
const report=(stage,err)=>{try{onError(stage,err)}catch{
}}
const failed=(stage,err)=>{status=stage==='load'?STORAGE_LOAD_FAILED:STORAGE_SAVE_FAILED
report(stage,err)
return false}
let tail=null
const send=(value,note)=>{try{const result=push(value,note)
if(result&&typeof result.then==='function')return Promise.resolve(result).then(()=>true,(err)=>failed('save',err))
return Promise.resolve(true)}catch(err){return Promise.resolve(failed('save',err))}}
return{
read:()=>clone(cache),
write(next,note){cache=sanitize(next)
const value=cache
let mine=null
mine=(tail===null?send(value,note):tail.then(()=>send(value,note))).then((ok)=>{if(tail===mine)tail=null
return ok})
tail=mine
return mine},
adopt(raw){if(status!==STORAGE_LOADED)return false
cache=sanitize(raw)
return true},
async load(){try{cache=sanitize(await fetch())
status=STORAGE_LOADED}catch(err){cache=fallback()
failed('load',err)}
return clone(cache)},
isLoaded:()=>status!==STORAGE_PENDING&&status!==STORAGE_LOAD_FAILED,
status:()=>status}}
function clone(value){if(Array.isArray(value))return[...value]
if(value&&typeof value==='object') return{...value}
return value}
